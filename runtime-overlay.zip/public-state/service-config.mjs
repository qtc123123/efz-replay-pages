// Deployment-owned, no query/storage/UI overrides. Parent must verify endpoint before publishing.
export const RELAY_ORIGIN = 'https://efz.16-192-153-4.sslip.io';
