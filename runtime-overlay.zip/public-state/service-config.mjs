// Deployment-owned, no query/storage/UI overrides. Parent must verify endpoint before publishing.
export const RELAY_ORIGIN = 'https://geo-front-athletic-organize.trycloudflare.com';
