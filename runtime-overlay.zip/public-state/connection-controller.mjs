import {createTargetConnection} from './player-target.mjs';
/** Service polling and explicit user intent share one cancellation boundary. */
export function createConnectionController(io){
 let revision=0,timer=null,binding=null,bindingRetirement=Promise.resolve();
 const schedule=io.schedule??setTimeout,clear=io.clear??clearTimeout;
 function stop(){const n=++revision;clear(timer);timer=null;io.resetTransport();return n;}
 async function poll(n){if(n!==revision)return;await io.flow.refresh();if(n===revision)timer=schedule(()=>poll(n),io.pollDelay?.()??1000);}
 function continuePolling(n){if(n===revision)timer=schedule(()=>poll(n),1000);}
 async function bind(id){const n=revision,pending=io.flow.choose(id);binding=pending;try{await pending;continuePolling(n);}finally{if(binding===pending)binding=null;}}
 function cancelBinding(){stop();const pending=binding,closing=io.flow.close();bindingRetirement=Promise.all([bindingRetirement,pending,closing]);bindingRetirement.catch(()=>{});return bindingRetirement;}
 const target=createTargetConnection({
  request:(...args)=>io.watch.request(...args),status:(...args)=>io.watch.status(...args),
  async reset(){stop();const closing=io.flow.close();await Promise.all([bindingRetirement,closing]);},cancelBinding,
  async lookup(sid,signal){const rows=await io.catalog(signal);if(signal.aborted)return false;io.showCatalog(rows,null);return rows.some(row=>row.session_id===sid);},
  choose:bind,onState:io.onTargetState,createId:io.createId,wait:io.wait,now:io.now,deadlineSchedule:io.deadlineSchedule,deadlineClear:io.deadlineClear
 });
 return Object.freeze({target,
  async choose(id){const retired=target.cancel();if(io.flow.selected()===id){await io.flow.choose(id);return;}const n=stop();await retired;await bindingRetirement;if(n!==revision)return;await io.flow.choose(id);continuePolling(n);},
  async reconnect(){if(target.hasIntent()&&!target.isBound()){await target.retry();return;}const n=stop();await io.flow.reconnect();continuePolling(n);},
  async disconnect(){const retired=target.cancel(),n=stop(),closing=io.flow.close();await Promise.all([retired,bindingRetirement,closing]);if(n===revision)io.onDisconnect();},
  async suspend(){const retired=target.cancel({preserve:true});stop();const closing=io.flow.suspend();await Promise.all([retired,bindingRetirement,closing]);}
 });
}
