// One listener pair per document. Restored BFCache documents reuse the module,
// but never reuse disposed art/audio/worker owners.
export function attachPageLifecycle(target,{retire,restore,reconnect,onError=()=>{}}){
 let hidden=false,closed=false,ownersLive=true,revision=0,retirement=Promise.resolve();
 function hide(){if(closed||hidden)return;hidden=true;revision++;if(ownersLive){ownersLive=false;try{retirement=Promise.resolve(retire()).catch(onError);}catch(error){retirement=Promise.resolve();onError(error);}}}
 async function show(event){if(closed||!event.persisted||!hidden)return;hidden=false;const mine=++revision;await retirement;if(closed||hidden||mine!==revision)return;try{restore();ownersLive=true;await reconnect();}catch(error){if(!closed&&!hidden&&mine===revision)onError(error);}}
 target.addEventListener('pagehide',hide);target.addEventListener('pageshow',show);
 return Object.freeze({isHidden:()=>hidden||closed,dispose(){if(closed)return retirement;hide();closed=true;revision++;target.removeEventListener('pagehide',hide);target.removeEventListener('pageshow',show);return retirement;}});
}
export function resetPlaybackLabels({audio,position,play}){audio.textContent='Sound muted.';position.textContent='0.0s / 0.0s received';play.textContent='Play';play.setAttribute('aria-label','Play');play.title='Play';}
