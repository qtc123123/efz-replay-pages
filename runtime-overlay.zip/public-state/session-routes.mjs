/** Fixed origin plus opaque IDs; only the artifact API may be translated. */
const need=v=>{if(!v)throw Error('Unsupported session route.');};
const uuid=/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
/** @param {string} origin @param {string} sid */
export function sessionRoutes(origin,sid){
 const base=new URL(origin);need(base.protocol==='https:'&&!base.username&&!base.password&&base.pathname==='/'&&!base.search&&!base.hash);need(/^[a-f0-9]{32}$/.test(sid));const root=base.origin+'/api/sessions/'+sid;
 return Object.freeze({catalog:()=>base.origin+'/api/sessions/v2',live:()=>root+'/live',
 game(id,from){need(uuid.test(id)&&Number.isSafeInteger(from)&&from>=0&&from<=524288);return root+'/games/'+id+'?from='+from+'&limit=1024';},
 artifact(value){const u=new URL(value);need(u.origin===base.origin&&!u.username&&!u.password&&!u.hash&&/^\/api\/live\/artifacts\/[a-f0-9]{64}$/.test(u.pathname));need([...u.searchParams.keys()].sort().join(',')==='epoch,length,offset');for(const [key,min,max]of [['epoch',1,2147483647],['offset',0,1048576],['length',1,4096]]){const v=u.searchParams.get(key);need(/^(0|[1-9][0-9]*)$/.test(v)&&Number(v)>=min&&Number(v)<=max);}need(Number(u.searchParams.get('offset'))+Number(u.searchParams.get('length'))<=1048576);return root+'/artifacts/'+u.pathname.split('/').at(-1)+u.search;}
 });
}
