import {parseCatalog} from './catalog.mjs';
import {sessionRoutes} from './session-routes.mjs';
import {createSessionFlow} from './session-flow.mjs';
import {attachPageLifecycle,resetPlaybackLabels} from './page-lifecycle.mjs';
import {createGameCards} from './cards.mjs';
import {mountScene} from './spectating-scene.mjs';
import {RELAY_ORIGIN} from './service-config.mjs';
import {validateExperimentalGame as validateBattleDescriptor,validateExperimentalChunk as validateFeedChunk,validateExperimentalManifest}from'./m/688f1fd0af5f4d3259e0c88b.mjs';
import {fetchInitialArtifact}from'./m/a9843933b91c59bcdb549a05.mjs';
const need=(ok,message)=>{if(!ok)throw Error(message);};
export function feedOrigin(value){const u=new URL(value);need(u.protocol==='https:'&&!u.username&&!u.password&&u.pathname==='/'&&!u.search&&!u.hash,'Use an HTTPS feed origin without credentials or a path.');return u.origin;}
export async function reconnectService({disconnect,isCurrent,start,note}){
 const mine=await disconnect();if(!isCurrent(mine))return;
 if(RELAY_ORIGIN===null){note('Spectating is temporarily offline. Please try Reconnect later.');return;}
 try{await start(feedOrigin(RELAY_ORIGIN),mine);}catch{if(isCurrent(mine))note('Spectating is unavailable. Please try Reconnect.');}
}
export async function fetchJSON(url,{fetcher=fetch,signal,max=262144,expected=null}={}){
 const response=await fetcher(url,{signal,credentials:'omit',redirect:'error',cache:'no-store'});need(response.ok&&response.body,'Feed or resource request failed.');
 const reader=response.body.getReader(),parts=[];let size=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;need(size<=max,'Response exceeds its limit.');parts.push(value);}}catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let at=0;for(const p of parts){bytes.set(p,at);at+=p.length;}
 if(expected){const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');need(size===expected.bytes&&sha===expected.sha256,'Resource integrity check failed.');}
 return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
export function validateManifest(v){return validateExperimentalManifest(v);}
export function createWorkerClient(worker,{timeout=90000}={}){
 let nextId=0,closed=false,retiring=null;const pending=new Map();
 function rejectAll(error){for(const p of pending.values()){clearTimeout(p.timer);p.reject(error);}pending.clear();}
 function finish(){closed=true;rejectAll(Error('Worker closed.'));worker.removeEventListener('message',message);worker.removeEventListener('error',failed);worker.removeEventListener('messageerror',failed);worker.terminate();}
 function failed(){finish();}
 function message({data}){const p=pending.get(data?.id);if(!p)return;if(data.type==='error'){clearTimeout(p.timer);pending.delete(data.id);p.reject(Error(data.message||'Worker failed.'));finish();return;}if(data.type!=='result'||data.operation!==p.type){p.reject(Error('Invalid worker response.'));finish();return;}clearTimeout(p.timer);pending.delete(data.id);p.resolve(data.value);}
 worker.addEventListener('message',message);worker.addEventListener('error',failed);worker.addEventListener('messageerror',failed);
 function send(type,payload={},duration=timeout){return new Promise((resolve,reject)=>{const id=++nextId,timer=setTimeout(()=>{pending.delete(id);reject(Error('Worker timed out.'));finish();},duration);pending.set(id,{type,resolve,reject,timer});try{worker.postMessage({id,type,...payload});}catch(error){clearTimeout(timer);pending.delete(id);reject(error);finish();}});}
 return Object.freeze({request(type,payload){if(closed)return Promise.reject(Error('Worker closed.'));if(pending.size>=2)return Promise.reject(Error('Worker busy.'));return send(type,payload);},close(){if(retiring)return retiring;if(closed)return Promise.resolve();closed=true;rejectAll(Error('Worker closed.'));retiring=send('dispose',{},3000).catch(()=>{}).finally(finish);return retiring;}});
}
export function rgbaPixels(image){need(image?.width===320&&image.height===240&&image.pixels instanceof Uint8Array&&image.pixels.length===76800&&image.palette instanceof Uint8Array&&image.palette.length===1024,'Invalid game image.');const out=new Uint8ClampedArray(307200);for(let i=0;i<76800;i++){const c=image.pixels[i]*4,o=i*4;out[o]=image.palette[c];out[o+1]=image.palette[c+1];out[o+2]=image.palette[c+2];out[o+3]=255;}return out;}

export function createLiveAudio({sounds,music}){
 let generation=1,seekRevision=0,nextFrame=0,muted=true,ready=false,closed=false,retiring=null,playing=false,preparing=null;
 const tasks=new Set(),ids=()=>({generation,replayId:1,seekRevision});
 const track=p=>{const promise=Promise.resolve(p);tasks.add(promise);promise.then(()=>tasks.delete(promise),()=>tasks.delete(promise));return promise;};
 sounds.bindReplay(ids());music.prepareSeekCommit({...ids(),nextFrame:0,musicState:{schema:'efz-local-music/1',nextUpdate:0,volume:0,stopped:false}})();sounds.setVolume(0);music.setVolume(0);
 function pause(){playing=false;sounds.pause();music.pause();}
 function resume(){if(closed||muted||!ready||playing)return Promise.resolve();playing=true;return track(Promise.all([sounds.play(),music.play()]));}
 return Object.freeze({
  status:()=>({muted,ready,closed}),
  prepare(){if(!preparing)preparing=track(Promise.all([sounds.prepare(),music.prepare()]).then(()=>{if(!closed)ready=true;}));return preparing;},
  enable(){need(!closed&&ready,'Audio is still preparing.');muted=false;sounds.setVolume(.7);music.setVolume(.5);return resume();},
  mute(){if(closed)return;muted=true;sounds.setVolume(0);music.setVolume(0);pause();},
  pause,
  resume,
  present(frame,{playing:visiblePlaying,silent=false}){
   if(closed)return;const n=frame.nextFrame;need(Number.isInteger(n)&&n>nextFrame,'Audio frame order.');
   if(silent||n!==nextFrame+1){pause();generation++;seekRevision++;sounds.prepareSeekCommit({...ids(),nextFrame:n})();music.prepareSeekCommit({...ids(),nextFrame:n,musicState:frame.result.musicState})();nextFrame=n;return;}
   const audible=visiblePlaying&&!muted&&ready;
   if(!audible&&playing)pause();
   const packet={...ids(),status:{state:audible?'playing':'paused',nextFrame:n},result:frame.result};sounds.present(packet);music.present(packet);nextFrame=n;
  },
  close(){if(retiring)return retiring;closed=true;muted=true;ready=false;try{pause();}catch{}const disposal=Promise.allSettled([Promise.resolve().then(()=>sounds.dispose()),Promise.resolve().then(()=>music.dispose())]);retiring=(async()=>{const results=await disposal;await Promise.allSettled([...tasks]);const failed=results.find(r=>r.status==='rejected');if(failed)throw failed.reason;})();return retiring;}
 });
}

export function stopLivePlayback(audio,stop){stop();audio?.pause();}
export async function resumeCurrentAudio(audio,isCurrent,onError){
 try{await audio?.resume();}catch{if(isCurrent())onError();}
}

export async function restoreAudioPreference(audio,{wanted,isCurrent,isPlaying,onEnabled}){
 if(!wanted)return;
 const activated=audio.enable();
 if(!isPlaying())audio.pause();
 await activated;
 if(!isCurrent())return;
 if(!isPlaying())audio.pause();
 onEnabled();
}

export function renderPaletteWarning(element,descriptor){
 const sides=descriptor.paletteFallbackSides??[];
 need(Array.isArray(sides)&&sides.length<=2&&sides.every(side=>side===0||side===1)&&new Set(sides).size===sides.length,'Invalid palette provenance.');
 element.textContent=sides.length?`Custom palette unavailable for ${sides.slice().sort().map(side=>'P'+(side+1)).join('/')}; stock colours shown`:'';
 element.hidden=sides.length===0;
}

export function clearPublicPresentation({context,canvas,placeholder,match,details}){context.clearRect(0,0,canvas.width,canvas.height);placeholder.hidden=false;placeholder.textContent='Choose a match to watch';match.textContent='Waiting for a game';match.removeAttribute?.('aria-label');details.textContent='';}

async function mount(){
 const $=id=>document.getElementById(id),canvas=$('screen'),context=canvas.getContext('2d',{alpha:false});
 let scene,cards;
 function createPresentationOwners(){scene=mountScene($('spectating-background'),{skyUrl:new URL('./assets/spectating-sky.png',import.meta.url),objectsUrl:new URL('./assets/spectating-objects.png',import.meta.url)});scene.ready.catch(()=>{});
 cards=createGameCards($('cards'),{onChoose:id=>void flow.choose(id),loadArt:async()=>{const data=await assets(AbortSignal.timeout(30000));try{const {createReplayArt}=await import('../src/pages/replay-art.mjs');return createReplayArt(data);}finally{data.key.fill(0);}}});
 }
 createPresentationOwners();
 let soundWanted=false;
 let epoch=0,abort=null,owner=null,audio=null,origin=RELAY_ORIGIN===null?null:feedOrigin(RELAY_ORIGIN),routes=null,selected=null,buffered=0,available=0,frame=0,playing=false,busy=false,pollTimer=null,tickTimer=null,catchingUp=false,nextTick=0;
 const audioRetirements=new Set();
 function retireAudio(value){if(!value)return Promise.resolve();const result=value.close();audioRetirements.add(result);result.then(()=>audioRetirements.delete(result),()=>audioRetirements.delete(result));return result;}
 const note=text=>{$('status').textContent=text;};
 function stopTimers(){clearTimeout(tickTimer);tickTimer=null;}
 async function resetGame(){const mine=++epoch;clearPublicPresentation({context,canvas,placeholder:$('placeholder'),match:$('match'),details:$('details')});playing=false;catchingUp=false;stopTimers();abort?.abort();abort=null;const old=owner,oldAudio=audio;owner=null;audio=null;selected=null;busy=false;buffered=available=frame=0;resetPlaybackLabels({audio:$('audio-status'),position:$('position'),play:$('play')});$('play').disabled=true;$('catch-up').disabled=true;$('sound').disabled=true;$('sound').textContent='🔇';$('sound').setAttribute('aria-pressed','false');renderPaletteWarning($('palette-warning'),{});await Promise.allSettled([old?.close(),retireAudio(oldAudio),...audioRetirements]);if(mine!==epoch)return mine;$('play').disabled=true;$('catch-up').disabled=true;$('sound').disabled=true;$('sound').textContent='🔇';$('sound').setAttribute('aria-pressed','false');renderPaletteWarning($('palette-warning'),{});return mine;}
 function request(url,options={}){return fetchJSON(url,{...options,signal:AbortSignal.any([abort.signal,AbortSignal.timeout(15000)])});}
 let connectionAbort=new AbortController();
 function serviceRequest(url){return fetchJSON(url,{signal:AbortSignal.any([connectionAbort.signal,AbortSignal.timeout(15000)])});}
 async function assets(signal){
  const configURL=new URL('../deployment/config.json',import.meta.url);const config=await fetchJSON(configURL,{signal,max:65536});
  need(['miracle-replay-pages/2','miracle-replay-pages/3'].includes(config.schema)&&config.manifestUrl==='./assets/manifest.json'&&/^[a-f0-9]{64}$/.test(config.manifestSha256)&&Number.isInteger(config.manifestBytes)&&config.manifestBytes>0&&config.manifestBytes<=4194304,'Unsupported resource configuration.');
  const manifest=await fetchJSON(new URL(config.manifestUrl,configURL),{signal,max:4194304,expected:{bytes:config.manifestBytes,sha256:config.manifestSha256}});
  const {resourceKey}=await import('../deployment/resource-access.mjs');return {manifest,key:resourceKey(config.manifestSha256),assetRoot:new URL('./assets/',configURL).href};
 }

 function audioFailed(mine){if(mine!==epoch)return;const old=audio;audio=null;$('sound').disabled=true;$('sound').textContent='🔇';$('audio-status').textContent='Audio unavailable; video continues.';void retireAudio(old).catch(()=>{});}
 async function setupAudio(data,descriptor,mine){
  try{
   const [{createReplaySounds},{createReplayMusic},{STAGE_MUSIC_PATHS}]=await Promise.all([import('../src/pages/replay-sounds.mjs'),import('../src/pages/replay-music.mjs'),import('../src/asset-selection.mjs')]);
   if(mine!==epoch)return;
   let sounds=null,music=null;
   try{sounds=createReplaySounds({...data,characters:descriptor.initialization.characters});music=createReplayMusic({...data,path:STAGE_MUSIC_PATHS[descriptor.initialization.stage]});audio=createLiveAudio({sounds,music});}
   catch(error){await Promise.allSettled([sounds?.dispose(),music?.dispose()]);throw error;}
   const current=audio;$('sound').disabled=true;$('audio-status').textContent='Preparing audio…';
   current.prepare().then(()=>{if(mine===epoch&&audio===current){$('sound').disabled=false;$('audio-status').textContent='Sound muted. Tap the speaker to enable.';void restoreAudioPreference(current,{wanted:soundWanted,isCurrent:()=>mine===epoch&&audio===current&&soundWanted&&!current.status().muted,isPlaying:()=>playing,onEnabled:()=>{$('sound').textContent='🔊';$('sound').setAttribute('aria-pressed','true');$('audio-status').textContent='Sound enabled.';}}).catch(()=>audioFailed(mine));}},()=>audioFailed(mine));
  }catch{audioFailed(mine);}
 }
 function render(f){context.putImageData(new ImageData(rgbaPixels(f.image),320,240),0,0);$('placeholder').hidden=true;const chars=f.inspection.characters?.every(Boolean)?f.inspection.characters:f.inspection.lastCharacters;if(chars)$('details').textContent=chars.map((c,i)=>`${selected.names?.[i]||`P${i+1}`} · HP ${Math.max(0,Math.ceil(c.life))} · SP ${Math.floor(c.meter)} · RF ${Math.floor(c.rf)} · Wins ${c.wins}`).join('  |  ');}
 function controls(){ $('play').textContent=playing?'Ⅱ':'▶';$('play').setAttribute('aria-label',playing?'Pause':'Play');$('play').title=playing?'Pause':'Play';$('position').textContent=`${(frame/64).toFixed(1)}s / ${(available/64).toFixed(1)}s received`; }
 async function step(count=catchingUp&&available-frame>32?16:1){if(!owner||busy||!playing)return;const mine=epoch,current=owner;busy=true;try{const value=await current.request('step',{count});if(mine!==epoch)return;frame=value.status.nextFrame;if(value.frame){render(value.frame);try{audio?.present(value.frame,{playing,silent:count>1});if(count===1&&playing&&audio?.status().ready&&!audio.status().muted)void audio.resume().catch(()=>audioFailed(mine));}catch{audioFailed(mine);}}if(value.kind==='waiting'){audio?.pause();note('Waiting for received inputs…');}else if(value.kind==='advanced')note(selected.terminal?'Playing received game':'Watching live game');else{playing=false;audio?.pause();note(value.kind==='complete'?'Game finished.':`Stream ${value.kind}.`);if(['complete','interrupted'].includes(value.kind))flow.complete(selected.id);}controls();}catch(error){if(mine===epoch){playing=false;audio?.pause();note('Playback could not continue. Please reconnect.');}}finally{if(mine===epoch){busy=false;if(playing){if(catchingUp&&available-frame<=32)catchingUp=false;nextTick=Math.max(nextTick+1000/64,performance.now()-1000/64);tickTimer=setTimeout(()=>step(),catchingUp?0:Math.max(0,nextTick-performance.now()));}}}}
 async function append(){if(!owner||!selected)return;const mine=epoch,current=owner;const chunk=validateFeedChunk(await request(routes.game(selected.id,buffered)),{id:selected.id,from:buffered});if(mine!==epoch)return;await current.request('append',{chunk});if(mine!==epoch)return;buffered+=chunk.pairs.length;available=chunk.availableFrames;selected={...selected,terminal:chunk.terminal};controls();return chunk.pairs.length;}
 async function startGame(session,descriptor){
  const mine=epoch;abort=new AbortController();selected=descriptor;routes=sessionRoutes(origin,session.session_id);
  const currentRoutes=routes;renderPaletteWarning($('palette-warning'),descriptor);available=descriptor.availableFrames;
  note('Preparing selected game assets…');$('disconnect').disabled=false;
  const prepareSignal=AbortSignal.any([abort.signal,AbortSignal.timeout(90000)]);
  const material=await Promise.allSettled([assets(prepareSignal),fetchInitialArtifact(origin,descriptor.initialArtifact,{signal:prepareSignal,fetcher:(url,options)=>fetch(currentRoutes.artifact(url),options)})]);
  if(material.some(r=>r.status==='rejected')){if(material[0].status==='fulfilled')material[0].value.key.fill(0);if(material[1].status==='fulfilled')material[1].value.fill(0);throw material.find(r=>r.status==='rejected').reason;}
  const data=material[0].value,initialBytes=material[1].value;
  try{
   if(mine!==epoch)return;await setupAudio(data,descriptor,mine);if(mine!==epoch)return;
   const current=createWorkerClient(new Worker(new URL('./viewer-worker.mjs',import.meta.url),{type:'module'}));owner=current;
   await current.request('init',{descriptor,initialBytes,...data});if(mine!==epoch)return;
   await append();if(mine!==epoch)return;heading(session);
   $('play').disabled=false;$('catch-up').disabled=false;playing=!document.hidden;nextTick=performance.now();controls();if(playing)void step();
  }finally{data.key.fill(0);initialBytes.fill(0);}
 }
 function heading(session){const element=$('match');element.replaceChildren();element.classList.add('match-row');const score=session.score===null?'—':session.score.join(' : ');for(const [index,text]of [session.names[0]||'P1',score,session.names[1]||'P2'].entries()){const part=document.createElement('span');part.textContent=text;if(index===1){part.className='score';part.title=session.score===null?'Session score unavailable':'Verified session score';}element.append(part);}element.setAttribute('aria-label',`${session.names.join(' versus ')}; session score ${score}`);}
 const flow=createSessionFlow({
  catalog:async()=>{need(origin!==null,'Offline');return parseCatalog(await serviceRequest(origin+'/api/sessions/v2')).sessions;},
  manifest:async sid=>validateManifest(await serviceRequest(sessionRoutes(origin,sid).live())),
  reset:resetGame,start:startGame,append:async()=>{if(owner&&buffered-frame<2048)await append();},
  metadata:session=>{if(selected)heading(session);},
  show:(sessions,sid)=>{cards.render(sessions,sid);$('session').textContent=`${sessions.length} current session${sessions.length===1?'':'s'}`;},
  note,pause:()=>{stopLivePlayback(audio,()=>{playing=false;});clearTimeout(tickTimer);controls();},healthy:()=>{if(owner){$('play').disabled=false;$('catch-up').disabled=false;}},unavailable:()=>{cards.unavailable();$('play').disabled=true;$('catch-up').disabled=true;}
 });
 let connectionRevision=0;
 async function pollConnection(mine){if(mine!==connectionRevision)return;await flow.refresh();if(mine===connectionRevision)pollTimer=setTimeout(()=>pollConnection(mine),buffered<available?100:1000);}
 async function reconnect(){const mine=++connectionRevision;clearTimeout(pollTimer);connectionAbort.abort();connectionAbort=new AbortController();$('disconnect').disabled=false;await flow.reconnect();if(mine===connectionRevision)pollTimer=setTimeout(()=>pollConnection(mine),1000);}
 async function disconnect(){const mine=++connectionRevision;clearTimeout(pollTimer);connectionAbort.abort();await flow.close();if(mine!==connectionRevision)return false;cards.clear();$('disconnect').disabled=true;$('session').textContent='Session: disconnected';return true;}
 $('reconnect').addEventListener('click',()=>void reconnect());
 $('disconnect').addEventListener('click',async()=>{if(await disconnect()){note('Disconnected.');controls();}});
 $('play').addEventListener('click',()=>{playing=!playing;controls();if(!playing)audio?.pause();else{const currentAudio=audio,mine=epoch;void resumeCurrentAudio(currentAudio,()=>mine===epoch&&audio===currentAudio,()=>audioFailed(mine));}if(playing&&!busy){clearTimeout(tickTimer);step();}});
 $('catch-up').addEventListener('click',()=>{audio?.pause();playing=true;catchingUp=true;nextTick=performance.now();clearTimeout(tickTimer);if(!busy)step(16);controls();});
 $('sound').addEventListener('click',()=>{if(!audio)return;const current=audio,mine=epoch;if(current.status().muted){soundWanted=true;const activated=current.enable();if(!playing)current.pause();void activated.then(()=>{if(mine===epoch&&audio===current&&!current.status().muted){$('sound').textContent='🔊';$('sound').setAttribute('aria-pressed','true');$('audio-status').textContent='Sound enabled.';}},()=>audioFailed(mine));}else{soundWanted=false;current.mute();$('sound').textContent='🔇';$('sound').setAttribute('aria-pressed','false');$('audio-status').textContent='Sound muted.';}});
 $('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await $('player').requestFullscreen();}catch{note('Fullscreen is unavailable in this browser.');}});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){audio?.pause();playing=false;clearTimeout(tickTimer);controls();}});attachPageLifecycle(window,{retire(){connectionRevision++;clearTimeout(pollTimer);connectionAbort.abort();const retiring=flow.suspend();scene.dispose();cards.dispose();return retiring;},restore:createPresentationOwners,reconnect,onError:()=>note('Spectating is unavailable. Please try Reconnect.')});
 await reconnect();
}
if(typeof document!=='undefined')mount().catch(()=>{const status=document.getElementById('status');if(status)status.textContent='The experimental viewer could not start.';});
