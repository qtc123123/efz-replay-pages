import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./62d688cb05fea0c19aa52424.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./1d012cc8875ecbb32aaeb678.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
const LEVEL_PAT = [
    0x44,
    0x45,
    0x46
];
const LEVEL_SOUND = [
    0x13,
    5,
    0x40
];
function superFreeze(c, level) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - (level + 1) * 1000);
    c.superDarken(0xb0, 3);
}
function superEffect(d, level, x, y) {
    d.w04 = LEVEL_PAT[level];
    d.b2c = LEVEL_SOUND[level];
    d.x = x;
    d.y = y;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function dustEffect(c, d, x, y) {
    d.w04 = 0x1f;
    d.x = x;
    d.y = y;
    d.b20 = 0;
    d.b21 = 0;
    d.d1c = c.facing === -1 ? 1 : 0;
    frameEffect(d);
}
function spawnOwned(c, d, pat, x, y, layer) {
    d.w04 = pat;
    d.x = x;
    d.y = y;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = layer;
    d.b18 = c.facing;
    frameChild(c, d);
}
const DEG = 57.29579143313326;
function setPolarVelocity(c, angle, speed) {
    c.vx = __numerics.cos(angle / DEG) * speed;
    c.vy = __numerics.sin(angle / DEG) * speed;
}
const DASH_SPEED = 2.2;
function chainInput(c) {
    if (c.pressed[0] !== 1 && c.pressed[1] !== 1 && c.pressed[2] !== 1 && c.pressed[3] !== 1) return false;
    const go = (state, turn)=>{
        c.onStateChange();
        c.state = state;
        if (turn) c.facing = -c.facing;
        c.f3150++;
        return true;
    };
    if (c.inputY === -1) {
        if (c.inputX === 0) return go(0x132, false);
        if (c.inputX === c.facing) return go(0x133, false);
        if (c.inputX === -c.facing) return go(0x133, true);
        return false;
    }
    if (c.inputY === 0) {
        if (c.inputX === c.facing) return go(0x134, false);
        if (c.inputX === -c.facing) return go(0x134, true);
        return false;
    }
    if (c.inputY === 1) {
        if (c.inputX === 0) return go(0x136, false);
        if (c.inputX === c.facing) return go(0x135, false);
        if (c.inputX === -c.facing) return go(0x135, true);
    }
    return false;
}
function rushScatter(c, d, pat) {
    d.w04 = pat;
    d.x = ftol(c.x) + (c.random(0, 0x6e) - 0x14) * c.facing;
    d.y = ftol(c.y) - c.random(0, 0x5a);
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function rushSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.b158 = 0;
        superFreeze(c, p.level);
        superEffect(d, p.level, ftol(c.x) - c.facing * 0x14, ftol(c.y) - 0x2a);
        c.w16c = 0x63;
        c.f3150 = 0;
        if (p.level === 2) c.seRequest = 0x25;
        c.stopMotion();
    }
    if (p.level === 2) c.showAltBackground(0xf);
    if (c.vx > 0.0) {
        c.vx = c.vx - p.decel;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.d168 === 3 && c.f3150 === 0) {
        o.hitstop = 0xb4;
        c.hitstop = 0x5a;
        c.f3150++;
        if (p.level === 2) c.showAltBackground(0x5d);
    }
    if (c.d168 === 3 && o.y < 0.0 && c.frame < 10) {
        o.onStateChange();
        o.stopMotion();
        o.y = 0.0;
        o.state = 0x37;
        return;
    }
    if (p.level >= 1 && c.frame > 0x15 && c.frame < 0x1f && c.random(0, 0x64) < 10) rushScatter(c, d, 0x19a);
    if (p.level === 2 && c.frame > 0x15 && c.frame < 0x1f && c.random(0, 0x64) < 5) rushScatter(c, d, 0x19b);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame < 2) c.d168 = 0;
    const f = c.frame;
    if (f === 13 || f === 16 || f === 19 || f === 22 || f === 25 || f === 28 || f === 31) c.d168 = 0;
    if (c.frame === 8) {
        dustEffect(c, d, ftol(c.x) + c.facing * 0x28, ftol(c.y));
        c.vx = p.dashVx;
    }
    if (c.frame === 10 && c.f3138 < 2) {
        c.f3138++;
        c.frame -= 2;
        return;
    }
    if (c.frame === 10 && c.d168 !== 3) {
        c.frame = p.missFrame;
        return;
    }
    if (c.frame === 0x14 && c.f313c < p.loopB) {
        c.frame = 0xb;
        c.f313c++;
    }
    if (c.frame === 0x1f && c.f3140 < p.loopC) {
        c.frame = 0x16;
        c.f3140++;
        c.d168 = 0;
    }
    if (c.frame >= cnt || c.frame === 0x28) {
        c.state = 0;
        c.onStateChange();
        if (c.f3158 === 1) c.f3158 = 0;
    }
}
function launchSuper(c, level) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (level === 2) c.showAltBackground(0xf);
    if (atStart(c)) {
        c.f3154 = level + 1;
        c.f3150 = 0;
        c.stopMotion();
        superFreeze(c, level);
        superEffect(d, level, ftol(c.x) - c.facing * 0x14, ftol(c.y) - 0x2a);
        if (level === 2) c.seRequest = 0x25;
    }
    if (c.frame > 8 && c.frame < 0xb && chainInput(c)) return;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (atFrame(c, 9)) {
        c.voiceRequest = 0xa;
        c.w16c = 1;
        setPolarVelocity(c, -45.0, DASH_SPEED);
        if (level === 2) c.w13c = 0x2d;
        dustEffect(c, d, ftol(c.x), ftol(c.y));
        spawnOwned(c, d, 0x19e, ftol(c.x), ftol(c.y), 1);
    }
    if (c.frame === 0xb && c.f3138 < 4) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame >= cnt) {
        c.frame = 0;
        c.state = 0x137;
        c.onStateChange();
    }
}
function dashSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const fs = p.dashFrame;
    if (c.f3154 === 3) c.showAltBackground(0xf);
    if (p.air && c.y + c.vy > 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
        c.frame = 7;
        c.timer = 0;
        c.state = 0x137;
        return;
    }
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame > fs - 1 && c.frame < fs + 2 && c.f3150 < c.f3154 + 1 && chainInput(c)) return;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (atFrame(c, fs)) {
        c.voiceRequest = 0xa;
        c.w16c = 1;
        setPolarVelocity(c, p.angle, DASH_SPEED);
        spawnOwned(c, d, p.child, ftol(c.x), ftol(c.y), 1);
    }
    if (c.frame === 4 && c.f3138 < 0) {
        c.f3138++;
        c.frame -= 2;
        return;
    }
    if (c.frame === fs + 2 && c.f3138 < 4) {
        c.f3138++;
        c.frame -= 2;
        return;
    }
    if (c.frame >= cnt) {
        c.state = 0x137;
        c.frame = 0;
        c.f313c++;
    }
}
function state311(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.f3154 === 3) c.showAltBackground(0xf);
    if (c.f3140 === 0) {
        c.vx = c.vx * 0.5;
        if (c.vy < 0.0) c.vy = c.vy * 0.75;
        c.f3140++;
    }
    if (c.f3150 < c.f3154 + 1 && c.frame < 5 && chainInput(c)) return;
    if (c.frame < 7) {
        c.vy = c.vy + 0.035;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.vy = 0.0;
            c.timer = 0;
            c.frame = 7;
        }
    }
    if (c.frame > 6) {
        c.vx = c.vx - 0.05;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 7) c.frame -= 2;
    if (c.frame >= cnt) {
        c.state = 7;
        if (c.inputY === 1) c.state = 3;
        c.onStateChange();
        c.faceOpponent();
        if (c.f3158 === 1) c.f3158 = 0;
    }
}
function chargeSuper(c, level) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (level === 2 && c.frame > 2) c.showAltBackground(0xf);
    if (atStart(c)) {
        c.stopMotion();
        c.b158 = 0;
    }
    if (atFrame(c, 2)) {
        c.b158 = 0;
        superFreeze(c, level);
        superEffect(d, level, ftol(c.x) + c.facing * 0x43, ftol(c.y) - 0x29);
        if (level === 2) c.seRequest = 0x25;
        c.stopMotion();
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 6) {
        if (level === 1) c.w13c = 0xf;
        if (level === 2) c.w13c = 0x1e;
        c.voiceRequest = 6;
        spawnOwned(c, d, 0x1a1, ftol(c.x) + c.facing * 0xf, ftol(c.y) - 0x94, 1);
        spawnOwned(c, d, 0x1ad, ftol(c.x) + c.facing * 0xf, ftol(c.y) - 0x94, 1);
    }
    if (c.frame === 0xa) {
        if (c.f3138 > 8) {
            spawnOwned(c, d, 0x1a5, ftol(c.x) + c.facing * 0xf, ftol(c.y) - 0x94, 1);
            return;
        }
        if (c.isHeld(level) > 0) {
            c.f3138++;
            c.frame -= 4;
        }
    }
    if (c.frame === 0xd) c.voiceRequest = 8;
    if (c.frame === 0xf) {
        d.w04 = 0x1a2 + level;
        if (c.f3138 > 8) d.w04 = 0x1ae + level;
        d.x = ftol(c.x) + c.facing * 0x68;
        d.y = ftol(c.y) - 0x32;
        if (c.f313c === 1) d.y = ftol(c.y) - 0x3c;
        if (c.f313c === 2) d.y = ftol(c.y) - 0x28;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.frame === 0x10 && c.f313c < 2) {
        c.frame -= 2;
        c.f313c++;
    }
    if (c.frame === 0x12 && c.f313c < 6) {
        c.f313c++;
        c.frame -= 2;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
        if (c.f3158 === 2) c.f3158 = 0;
    }
}
function beamPair(c, d) {
    d.x = ftol(c.x) + c.facing * 0x32;
    d.y = ftol(c.y) - 0x20;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
    spawnOwned(c, d, 0x1a5, ftol(c.x) + c.facing * 0x32, ftol(c.y) - 0x20, 1);
}
function beamSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (p.level === 2 && c.frame > 2) c.showAltBackground(3);
    if (atStart(c)) {
        c.stopMotion();
        c.b158 = 0;
    }
    if (atFrame(c, 2) && c.f3140 === 0) {
        c.b158 = 0;
        superFreeze(c, p.level);
        superEffect(d, p.level, ftol(c.x) - c.facing * 0x1f, ftol(c.y) - 0x61);
        if (p.level === 2) c.seRequest = 0x25;
        c.stopMotion();
        c.f3140++;
    }
    if (c.frame > 9 && c.y < 0.0) {
        c.vy = c.vy + 0.02;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.timer = 0;
            c.frame = 0x10;
            return;
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame === 5 && c.f3138 < 5) {
        c.frame -= 3;
        c.f3138++;
    }
    if (c.frame === 0xa) {
        c.voiceRequest = 9;
        c.vx = -1.3;
        c.vy = -0.8;
        d.w04 = p.first;
        beamPair(c, d);
    }
    if (p.extra.length > 0 && c.frame === 0xe && c.f313c < p.extra.length) {
        c.voiceRequest = 9;
        c.f313c++;
        c.frame -= 4;
        for(let k = 1; k <= p.extra.length; k++){
            if (c.f313c === k) d.w04 = p.extra[k - 1];
        }
        beamPair(c, d);
    }
    if (c.frame === 0x10) c.frame -= 2;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
        if (c.f3158 === 2) c.f3158 = 0;
    }
}
function state318(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (atStart(c)) {
        c.biasCameraY(0x32, 3);
        superFreeze(c, 2);
        superEffect(d, 2, ftol(c.x) + c.facing * 0xd, ftol(c.y) - 0x34);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
        d.w04 = 0x1b4;
        d.x = ftol(c.x) + c.facing * 0xd;
        d.y = ftol(c.y) - 0x34;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        d.d30 = 1;
        frameChild(c, d);
    }
    if (atFrame(c, 7)) {
        c.voiceRequest = 0xb;
        c.shakeScreen(5, 0);
        c.f3158 = 3;
        c.f3168 = 0x1194;
        spawnOwned(c, d, 0x1b3, ftol(c.x) + c.facing * 5, ftol(c.y) - 0x2d, 0);
        spawnOwned(c, d, 0x1ad, ftol(c.x) + c.facing * 5, ftol(c.y), 0);
        spawnOwned(c, d, 0x1ad, ftol(c.x) + c.facing * 0x2d, ftol(c.y), 0);
        spawnOwned(c, d, 0x1ad, ftol(c.x) - c.facing * 0x23, ftol(c.y), 0);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 0xa && c.f3138 < 5) {
        c.f3138++;
        c.frame -= 2;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
registerStates({
    300: (c)=>rushSuper(c, {
            level: 0,
            decel: 0.035,
            dashVx: 3.5,
            loopB: 2,
            loopC: 3,
            missFrame: 0x22
        }),
    301: (c)=>rushSuper(c, {
            level: 1,
            decel: 0.04,
            dashVx: 4.0,
            loopB: 3,
            loopC: 4,
            missFrame: 0x28
        }),
    302: (c)=>rushSuper(c, {
            level: 2,
            decel: 0.045,
            dashVx: 5.0,
            loopB: 3,
            loopC: 8,
            missFrame: 0x28
        }),
    303: (c)=>launchSuper(c, 0),
    304: (c)=>launchSuper(c, 1),
    305: (c)=>launchSuper(c, 2),
    306: (c)=>dashSuper(c, {
            angle: -90.0,
            child: 0x19c,
            dashFrame: 7,
            air: false
        }),
    307: (c)=>dashSuper(c, {
            angle: -45.0,
            child: 0x19e,
            dashFrame: 7,
            air: false
        }),
    308: (c)=>dashSuper(c, {
            angle: 0.0,
            child: 0x19d,
            dashFrame: 7,
            air: false
        }),
    309: (c)=>dashSuper(c, {
            angle: 45.0,
            child: 0x19f,
            dashFrame: 8,
            air: true
        }),
    310: (c)=>dashSuper(c, {
            angle: 90.0,
            child: 0x1a0,
            dashFrame: 8,
            air: true
        }),
    311: state311,
    312: (c)=>chargeSuper(c, 0),
    313: (c)=>chargeSuper(c, 1),
    314: (c)=>chargeSuper(c, 2),
    315: (c)=>beamSuper(c, {
            level: 0,
            first: 0x1a6,
            extra: []
        }),
    316: (c)=>beamSuper(c, {
            level: 1,
            first: 0x1a8,
            extra: [
                0x1b1,
                0x1a7
            ]
        }),
    317: (c)=>beamSuper(c, {
            level: 2,
            first: 0x1ac,
            extra: [
                0x1ab,
                0x1b2,
                0x1aa,
                0x1a9
            ]
        }),
    318: state318
});
function childStep(c, i, resetHit) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    if (resetHit) ch.hitState = 0;
    return true;
}
function childOnce(c, i, resetHit) {
    if (childStep(c, i, resetHit) && c.children[i].frame >= childCount) c.freeChild(i);
}
function hitOnce(c, i) {
    if (c.a3174[i] === 0) {
        c.children[i].hitsLeft = 1;
        c.a3174[i]++;
    }
}
function childTrail(c, i, p) {
    const ch = c.children[i];
    if (ch.frame < 0x1a) {
        ch.x = c.x;
        ch.y = c.y;
        c.a3174[i]--;
        if (!(c.a3174[i] > 0)) {
            const d = childSpawnFrame;
            d.w04 = 0x19b;
            d.x = ftol(c.x) + (c.random(0, 0x32) + p.dx) * c.facing;
            d.y = ftol(c.y) + p.dy - c.random(0, 0x32);
            d.b20 = 2;
            d.b21 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
            c.a3174[i] = 0xc;
        }
    }
    if (p.cut(c) && ch.frame < 0x1a) {
        ch.timer = 0;
        ch.frame = 0x1a;
        return;
    }
    childOnce(c, i, true);
}
function cut412(c) {
    if (c.state !== 0x132) return true;
    return c.frame < 6;
}
function cut414(c) {
    const s = c.state;
    if (s !== 0x12f && s !== 0x130 && s !== 0x131 && s !== 0x133) return true;
    if (s !== 0x133) return false;
    return c.frame < 6;
}
function cutState(state) {
    return (c)=>{
        if (c.state !== state) return true;
        return c.frame < 6;
    };
}
function child417(c, i) {
    const ch = c.children[i];
    const s = c.state;
    if (s !== 0x138 && s !== 0x139 && s !== 0x13a && ch.frame < 0x1a) {
        ch.timer = 0;
        ch.frame = 0x1a;
        ch.hitsLeft = 0;
        return;
    }
    hitOnce(c, i);
    if (c.frame < 0xa && ch.frame < 0x1a) {
        ch.x = c.facing * 0xf + c.x;
        ch.y = c.y - 148.0;
    }
    if (c.frame === 0xb && ch.frame < 0x1a) {
        ch.x = (c.facing << 4) + c.x;
        ch.y = c.y - 147.0;
        ch.hitsLeft = 0;
    }
    if (c.frame === 0xc && ch.frame < 0x1a) {
        ch.x = c.facing * 0x68 + c.x;
        ch.y = c.y - 54.0;
    }
    if (c.frame > 0xc && c.frame < 0x12 && ch.frame < 0x1a) {
        ch.x = c.facing * 0x68 + c.x;
        ch.y = c.y - 53.0;
    }
    if (!childStep(c, i, false)) return;
    if (ch.frame === 0x1a && c.f313c < 4) {
        ch.frame = 0xb;
        ch.hitState = 0;
        c.voiceRequest = 7;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child429(c, i) {
    const ch = c.children[i];
    const s = c.state;
    if (s === 0x138 || s === 0x139 || s === 0x13a) {
        ch.x = c.facing * 0xf + c.x;
        ch.y = c.y - 148.0;
    }
    childOnce(c, i, false);
}
function child435(c, i) {
    const ch = c.children[i];
    if (c.state === 0x13e) {
        ch.x = c.facing * 5 + c.x;
        ch.y = c.y - 45.0;
    }
    hitOnce(c, i);
    childOnce(c, i, false);
}
function childHitOnce(c, i) {
    hitOnce(c, i);
    childOnce(c, i, false);
}
registerChildren({
    410: (c, i)=>childOnce(c, i, true),
    411: (c, i)=>childOnce(c, i, true),
    412: (c, i)=>childTrail(c, i, {
            dx: 0x1e,
            dy: -0x50,
            cut: cut412
        }),
    413: (c, i)=>childTrail(c, i, {
            dx: 0x23,
            dy: -0x14,
            cut: cutState(0x134)
        }),
    414: (c, i)=>childTrail(c, i, {
            dx: 7,
            dy: -0x32,
            cut: cut414
        }),
    415: (c, i)=>childTrail(c, i, {
            dx: 0x14,
            dy: 0x19,
            cut: cutState(0x135)
        }),
    416: (c, i)=>childTrail(c, i, {
            dx: -0x1e,
            dy: 0x14,
            cut: cutState(0x136)
        }),
    417: child417,
    418: childHitOnce,
    419: childHitOnce,
    420: childHitOnce,
    421: (c, i)=>childOnce(c, i, false),
    429: child429,
    430: childHitOnce,
    431: childHitOnce,
    432: childHitOnce,
    435: child435,
    436: (c, i)=>childOnce(c, i, false)
});

export function __logicState(){return {LEVEL_PAT,LEVEL_SOUND};}

export function __installInitialRoots(s){
if(LEVEL_PAT!==s["LEVEL_PAT"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_PAT');
if(LEVEL_SOUND!==s["LEVEL_SOUND"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_SOUND');
}
