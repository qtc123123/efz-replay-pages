import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { registerChildren } from "./9410f25ccc5489d02b4dd080.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild } from "./1d4a8932dc5ab92063658a65.mjs";
import { s8 } from "./7596266716c972d06fe8897a.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function dashForward(c) {
    return c.facing === 1 ? 1 : 0;
}
function jumpRandom(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = s8(rnd(c, 0, 2) - 1);
}
function comboFollowUp(c, n6, n8, n12, n14, near, dx) {
    c.aiMode = 1;
    if (rnd(c, 0, n6) === 0) c.aiMode = 6;
    if (rnd(c, 0, n8) === 0) c.aiMode = 8;
    if (rnd(c, 0, n12) === 0) c.aiMode = 0xc;
    if (rnd(c, 0, n14) === 0) c.aiMode = 0xe;
    if (near && dx < 50.0 && rnd(c, 0, 2) === 0) c.aiMode = 0x14;
}
function oppHit(c) {
    const s = c.opponent.state;
    return s > 0x31 && s < 0x9c ? 1 : 0;
}
export function thinkMisuzu(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25.0 * c.aiLevel + air * 0x1e * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 0x190 + (c.state === 0xaa ? 1 : 0) * 0x12c;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 0x95 && c.state < 0x9d ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40.0 * c.aiLevel > r && c.state > 0xc7) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 0xc8) c.aiMode = 0;
        return;
    }
    if (o.state === 0x60) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 0x32 && c.state <= 0x96 && c.timer === 0) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 0x32 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 0xf0) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 0x140) < dx ? 1 : 0;
        if (o.state > 0xc7 && o.state < 0xfa && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 0xa && c.state <= 0xc) && c.y === 0.0) return;
    if (o.state >= 0x32 && o.state < 0x96 && c.state === 0x108 && c.w16c > 1) return;
    if (c.state === 0xa8 && c.timer < 6) {
        if (o.state !== 0xc8 && o.state !== 0xcc && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx < 45.0 && c.aiLevel + c.aiLevel > rnd(c, 0, 100)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && c.aiLevel * 1.0 > rnd(c, 0, 100)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
        }
        if ((o.state === 0xc9 || o.state === 0xca || o.state === 0xcd) && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx > 60.0 && dx < 80.0 && c.aiLevel * 1.0 > rnd(c, 0, 100)) {
                c.pressed[1] = 1;
                c.inputY = 1;
                c.inputX = 0;
                return;
            }
        }
    }
    if (c.state === 0xa8 || c.state === 0xa9) {
        if (dx < 100.0) {
            if (c.aiLevel * 4.0 > rnd(c, 0, 100) && c.rfGauge > 500.0) {
                c.command = 0x20;
                return;
            }
            if (c.aiLevel + c.aiLevel > rnd(c, 0, 100) && c.rfGauge > 500.0) {
                c.command = 0xc;
                return;
            }
            if (dx < 60.0 && c.aiLevel * 1.0 > rnd(c, 0, 100)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiLevel * 1.0 > rnd(c, 0, 100) && c.meter === 0xbb8) {
                c.command = 0x5c;
                return;
            }
            if (c.aiLevel * 3.0 > rnd(c, 0, 100) && dx < 80.0 && c.meter >= 0x7d0) {
                c.command = rnd(c, 0, 2) + 0x65;
                return;
            }
        }
        if (dx < 150.0 && dx > 100.0) {
            if (c.aiLevel * 3.0 > rnd(c, 0, 100) && c.rfGauge > 500.0) {
                c.command = 0xc;
                return;
            }
            if (dx < 120.0 && c.aiLevel * 1.0 > rnd(c, 0, 100)) {
                c.pressed[0] = 2;
                c.inputY = 0;
                return;
            }
            if (c.aiLevel * 1.0 > rnd(c, 0, 100)) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiLevel * 1.0 > rnd(c, 0, 100) && c.meter === 0xbb8 && o.state < 0xdc) {
                c.command = 0x5c;
                return;
            }
        }
        if (dx > 150.0) {
            if (c.aiLevel * 1.0 > rnd(c, 0, 100) && c.rfGauge > 500.0) {
                c.command = rnd(c, 0, 2) + 0x1e;
                return;
            }
            if (c.aiLevel * 1.0 > rnd(c, 0, 100)) {
                c.command = rnd(c, 0, 2) + 0xb;
                return;
            }
        }
    }
    if (c.state === 0xaa && c.frame === 1 && c.timer === 0) {
        if (c.aiLevel * 5.0 > rnd(c, 0, 100)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -40.0 && dx < 80.0 && c.aiLevel * 5.0 > rnd(c, 0, 100)) {
            c.pressed[0] = 1;
            return;
        }
        if (c.y - o.y > -100.0 && c.y - o.y < -50.0 && dx < 80.0 && c.aiLevel * 5.0 > rnd(c, 0, 100)) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y > -50.0 && c.y - o.y < -50.0 && dx < 120.0 && c.aiLevel * 5.0 > rnd(c, 0, 100)) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return;
        }
        if (dy < 50.0 && dx < 100.0 && c.aiLevel + c.aiLevel > rnd(c, 0, 100)) {
            c.command = rnd(c, 0, 2) + 0x1f;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y === 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0) {
            c.command = 0x20;
            return;
        }
        if (c.aiRoll < 5 && c.rfGauge > 500.0) {
            c.command = 0xc;
            return;
        }
        if (c.aiRoll < 0x11 && c.aiRoll > 0xc && c.meter >= 0x3e8) {
            c.command = rnd(c, 0, 3) + 0x64;
            return;
        }
        if (c.aiRoll < 0x12 && c.aiRoll > 0x14 && c.meter === 0xbb8) {
            c.command = 0x5c;
            return;
        }
        if (c.aiRoll > 0x41) {
            c.aiMode = 2;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y < 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 2 && c.rfGauge > 500.0) {
            c.command = 0x20;
            return;
        }
        if (c.aiRoll > 0x3a) {
            c.aiMode = 2;
            return;
        }
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 8.0 * c.aiLevel > rnd(c, 0, 100) && o.state > 0x95 && o.state < 0x9d) {
        if (c.state === 0xfb || c.state === 0xe8 && rnd(c, 0, 0xa) === 0 || c.state === 0xfa && rnd(c, 0, 100) < 2 || c.state === 0xeb && rnd(c, 0, 7) === 0) {
            c.command = 0x34;
            return;
        }
    }
    if (c.aiMode > 0 && c.state > 0x31 && c.state < 0x9e) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 0xc8) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = s8(rnd(c, 0, 2) - 1);
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = dashForward(c);
            if (c.state === 0xa5) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6 && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 7;
        return;
    }
    if (c.aiMode === 7 && c.state === 0xa3) {
        c.pressed[0] = 1;
        if (c.state === 0xe6) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 8 && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 9;
        return;
    }
    if (c.aiMode === 9 && c.state === 0xa3) {
        c.pressed[1] = 1;
        if (c.state === 0xe7) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0xa && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 0xb;
        return;
    }
    if (c.aiMode === 0xb && c.state === 0xa3) {
        c.pressed[2] = 1;
        if (c.state === 0xe8) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0xc && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 0xd;
        return;
    }
    if (c.aiMode === 0xd && c.state === 0xa3) {
        c.pressed[0] = 1;
        c.inputY = 1;
        if (c.state === 0xe6) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0xe && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 0xf;
        return;
    }
    if (c.aiMode === 0xf && c.state === 0xa3) {
        c.pressed[1] = 1;
        c.inputY = 1;
        if (c.state === 0xe7) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0x10 && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 0x11;
        return;
    }
    if (c.aiMode === 0x11 && c.state === 0xa3) {
        c.pressed[2] = 1;
        c.inputY = 1;
        if (c.state === 0xe8) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0x14 && c.state < 0x32) {
        c.pressed[0] = 1;
        c.inputY = 1;
        if (c.state === 0xcc) c.aiMode = 0;
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && c.aiLevel * 25.0 > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.state === 0xc8) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (o.y < 0.0 && dx < 90.0 && c.aiRoll < 0x258 && c.aiRoll > 0x12c) {
                c.aiMode = 6;
                return;
            }
            if (dx < 80.0 && c.aiRoll > 0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 70.0 && c.aiRoll > 0x12c && c.aiRoll < 0x258) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x3ca) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x258) {
                comboFollowUp(c, 3, 3, 3, 3, true, dx);
                return;
            }
        }
        if (c.state === 0xc9) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x14;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x12c && c.aiRoll < 0x226) {
                c.command = 0x1f;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x226 && c.aiRoll < 0x258 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 3) + 0x64;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x258 && c.aiRoll < 0x2ee) {
                c.inputX = c.facing;
                c.inputY = -1;
                return;
            }
            if (c.aiRoll < 0x64) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x64 && c.aiRoll < 0x15e && dx < 110.0) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x1c2 && c.aiRoll < 0x258 && dx < 80.0) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x258) {
                comboFollowUp(c, 2, 2, 3, 3, true, dx);
                return;
            }
        }
        if (c.state === 0xca) {
            if (o.y < 0.0 && c.aiRoll > 0 && c.aiRoll < 0x96) {
                c.command = 0x1f;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x96 && c.aiRoll < 0xc8 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 3) + 0x64;
                return;
            }
            if (c.aiRoll > 0xc8 && c.aiRoll < 0x190) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x1f4) {
                comboFollowUp(c, 2, 2, 3, 3, false, dx);
                return;
            }
        }
        if (c.state === 0xcb) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = rnd(c, 0, 3) + 0x1e;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0x12c) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x12c && c.rfGauge > 350.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x258) {
                c.command = 0x1e;
                return;
            }
            if (c.aiRoll > 0x258 && c.aiRoll < 0x28a && c.rfGauge > 500.0) {
                c.command = 0x1f;
                return;
            }
            if (c.aiRoll > 0x384) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcc) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (o.y < 0.0 && dx < 90.0 && c.aiRoll < 0x258 && c.aiRoll > 0x12c) {
                c.aiMode = 6;
                return;
            }
            if (dx < 70.0 && c.aiRoll > 0 && c.aiRoll < 0xc8) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 80.0 && c.aiRoll > 0xc8 && c.aiRoll < 0x258) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x3ca) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x320) {
                comboFollowUp(c, 2, 2, 4, 4, true, dx);
                return;
            }
        }
        if (c.state === 0xcd) {
            if (o.y < 0.0 && c.aiRoll > 0x12c && c.aiRoll < 0x226) {
                c.command = 0x1f;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x226 && c.aiRoll < 0x258 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 3) + 0x64;
                return;
            }
            if (c.aiRoll < 0x64) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x64 && c.aiRoll < 0x15e && dx < 110.0) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x15e && c.aiRoll < 0x226 && dx < 90.0) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x226 && c.aiRoll < 0x276 && c.d168 === 2) {
                c.command = 0x1e;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x1f4) {
                comboFollowUp(c, 2, 2, 4, 4, true, dx);
                return;
            }
        }
        if (c.state === 0xce) {
            if (c.aiRoll > 0 && c.aiRoll < 0x258) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x28a && c.aiRoll < 0x258 && c.rfGauge > 350.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x28a && c.aiRoll < 0x320) {
                c.command = 0x1e;
                return;
            }
            if (c.aiRoll > 0x320 && c.aiRoll < 0x352 && c.rfGauge > 500.0) {
                c.command = 0x1f;
                return;
            }
            if (c.aiRoll > 0x384) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcf) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                return;
            }
            if (dx < 60.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x18f && c.aiRoll < 0x2bc) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 4) === 0) c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd0) {
            if (c.aiRoll > 0x14 && c.aiRoll < 0x3c && c.d168 === 3 && o.y < 0.0) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x50 && c.aiRoll < 0x12c) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd1) {
            if (c.aiRoll < 0xc8 && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x1f;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xe7) {
            if (c.aiRoll > 0 && c.aiRoll < 0x190) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x1c2 && c.aiRoll < 0x190 && c.rfGauge > 350.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x1c2 && c.aiRoll < 0x258) {
                c.command = 0x1e;
                return;
            }
            if (c.aiRoll > 0x258 && c.aiRoll < 0x28a && c.rfGauge > 500.0) {
                c.command = 0x1f;
                return;
            }
            if (c.aiRoll > 0x2bb) {
                comboFollowUp(c, 2, 2, 4, 4, true, dx);
                return;
            }
        }
        if (c.state === 0xfa && c.aiRoll > 0x258 && c.y === 0.0) {
            c.aiMode = 1;
            if (dx < 50.0) c.aiMode = 0x14;
            return;
        }
        if (c.state === 0xe9 && c.aiRoll > 0x1f4) {
            c.aiMode = 1;
            if (dx < 50.0) c.aiMode = 0x14;
            return;
        }
        if (c.state === 0xea) {
            if (c.aiRoll > 0 && c.aiRoll < 0x190 && c.d168 === 3) {
                c.command = 0x14;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0x190) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x1c2 && c.aiRoll < 0x190 && c.rfGauge > 350.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x1c2 && c.aiRoll < 0x258) {
                c.command = 0x1e;
                return;
            }
            if (c.aiRoll > 0x258 && c.aiRoll < 0x28a && c.rfGauge > 500.0) {
                c.command = 0x1f;
                return;
            }
            if (c.aiRoll > 0x2bc) {
                comboFollowUp(c, 2, 2, 4, 4, true, dx);
                return;
            }
        }
        if (c.state === 0xeb && c.aiRoll > 0x1c2 && c.aiRoll < 0x258) {
            c.command = 0x1e;
            return;
        }
    }
    if (25.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 0x63) {
                if (dx < 40.0 && o.y === 0.0 && c.aiRoll < 5) {
                    c.pressed[2] = 1;
                    c.inputX = s8(-c.facing);
                    c.inputY = 0;
                    return;
                }
                if (dx < 50.0 && c.aiRoll < oppHit(c) * 0xf + 0xf) {
                    c.pressed[0] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 65.0 && c.aiRoll < oppHit(c) * 0xf + 0x14) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx > 60.0 && dx < 90.0 && c.aiRoll < oppHit(c) * 0xf + 0x23 && c.aiRoll > 0x1e) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (0x46 - oppHit(c) * 0x46 < dx && dx < 100.0) {
                    const h = oppHit(c);
                    if (c.aiRoll < h + h + 0x54 && c.aiRoll > 0x50) {
                        c.aiMode = 0xc;
                        return;
                    }
                }
                if (0x46 - oppHit(c) * 0x46 < dx && dx < 120.0 && c.aiRoll < oppHit(c) * 0xf + 0x80 && c.aiRoll > 0x78) {
                    c.aiMode = 8;
                    return;
                }
                if (dx < 150.0 && dx > 120.0 && c.aiRoll < 0x7e && c.aiRoll > 0x78) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 120.0 && dx > 70.0 && c.aiRoll < 0x91 && c.aiRoll > 0x82) {
                    c.pressed[2] = 1;
                    c.inputY = 0;
                    return;
                }
                if (0x50 - oppHit(c) * 0x50 < dx && dx < 130.0 && c.aiRoll < oppHit(c) * 0xf + 0x9b && c.aiRoll > 0x91) {
                    c.aiMode = 0xe;
                    return;
                }
                if (0x5a - oppHit(c) * 0x5a < dx && dx < 140.0 && c.aiRoll < oppHit(c) * 0xf + 0xb4 && c.aiRoll > 0xa5) {
                    c.aiMode = 0xa;
                    return;
                }
                if (dx > 110.0 && dx < 160.0 && c.aiRoll < 0xcd && c.aiRoll > 0xc8) {
                    c.aiMode = 0xa;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 0xeb && c.aiRoll > 0xdc && c.rfGauge > 500.0 && o.state > 0xc7) {
                    c.command = 0x20;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 0xf0 && c.aiRoll > 0xeb && c.meter >= 0x7d0 && o.state > 0xc7) {
                    c.command = rnd(c, 0, 3) + 0x65;
                    return;
                }
                if (dx < 100.0 && c.aiRoll < 0xf2 && c.aiRoll > 0xf0 && c.meter === 0xbb8 && o.state > 0xc7) {
                    c.command = 0x5c;
                    return;
                }
                if (dx > 100.0 && dx < 130.0 && c.aiRoll < 0x136 && c.aiRoll > 0x12c) {
                    c.command = 0xa;
                    return;
                }
                if (dx > 130.0 && dx < 180.0 && c.aiRoll < 0x13b && c.aiRoll > 0x136) {
                    c.command = 0xb;
                    return;
                }
                if (dx > 90.0 && dx < 140.0 && c.aiRoll < 0x14a && c.aiRoll > 0x140) {
                    c.command = 0x1e;
                    return;
                }
                if (dx > 90.0 && dx < 140.0 && c.aiRoll < 0x154 && c.aiRoll > 0x14a && c.rfGauge > 500.0) {
                    c.command = 0x1f;
                    return;
                }
                if (c.aiRoll < 0x2ee && c.aiRoll > 0x2bc && o.state > 0x31 && o.state < 0x9c && dx > 100.0) {
                    c.aiMode = 5;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < 0xa) {
                        c.inputY = -1;
                        c.inputX = s8(-c.facing);
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 90.0 && dy < 140.0 && dy > 80.0 && c.aiRoll < 6 && (c.rfGauge > 500.0 || c.rfBlue > 0)) {
                        c.command = 0x16;
                        return;
                    }
                    if (dx < 80.0 && dy < 140.0 && dy > 100.0 && c.aiRoll < 0x2d && c.aiRoll > 0xa) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx < 90.0 && dy < 170.0 && dy > 150.0 && c.aiRoll < 0x50 && c.aiRoll > 0x2d) {
                        c.pressed[2] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx > 120.0 && dx < 140.0 && dy < 150.0 && dy > 120.0 && c.aiRoll < 0x6e && c.aiRoll > 0x50) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx < 70.0 && c.aiRoll < 0xd2 && c.aiRoll > 0xc8 && o.y < -50.0 && dy < 90.0 && c.meter >= 0x7d0) {
                        c.command = rnd(c, 0, 2) + 0x65;
                        return;
                    }
                    if (dx < 100.0 && c.aiRoll < 0x12e && c.aiRoll > 0x12c && o.y < -50.0 && dy < 100.0 && c.meter === 0xbb8) {
                        c.command = 0x5c;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 80.0 && dy < 100.0 && c.aiRoll < 0x64) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 80.0 && dy > 90.0 && dy < 120.0 && o.y < c.y && c.aiRoll > 0x64 && c.aiRoll < 0xb4) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx > 80.0 && dx < 110.0 && dy > 0.0 && dy < 70.0 && c.aiRoll > 0xb4 && c.aiRoll < 0xf0) {
                    c.pressed[2] = 1;
                    return;
                }
                if (dx < 80.0 && c.aiRoll > 0xf0 && c.aiRoll < 0xf2 && dy > 80.0) {
                    c.command = rnd(c, 0, 3) + 0x6e;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 80.0 && dy < 100.0 && c.aiRoll < 0x14) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx > 20.0 && dx < 90.0 && dy > 90.0 && dy < 120.0 && o.y < c.y && c.aiRoll > 0x14 && c.aiRoll < 0x28) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx > 80.0 && dx < 110.0 && dy > 0.0 && dy < 50.0 && c.aiRoll > 0x28 && c.aiRoll < 0x32) {
                    c.pressed[2] = 1;
                    return;
                }
            }
        }
    }
    if (c.state < 0x32 && (o.state > 0x95 && o.state < 0x9c || o.state > 0x31 && o.state < 0x3b) && c.y === 0.0 && 4.0 * c.aiLevel > rnd(c, 0, 100) && dx > 120.0) {
        c.command = dashForward(c);
        return;
    }
    if (c.state < 0x32 && o.state < 0x32 && dx > 800.0 && dx < 120.0 && 2.0 * c.aiLevel > rnd(c, 0, 100) && c.x > 150.0 && c.x < 490.0) {
        c.command = c.facing !== 1 ? 1 : 0;
        return;
    }
    if (rnd(c, 0, 1000) < 2) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 180.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 170.0 && dx > 140.0 && c.y === 0.0 && o.state < 0x32) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 0xf) c.aiTimer1a0 = 0xf;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 0xf) c.aiTimer1a4 = 0xf;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 0x32 && dx < 120.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x3c;
        else c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x3c;
    }
    if (rnd(c, 0, 100) < 0x32) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x3c;
        else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x3c;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x3c;
    else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x3c;
}
function childEndTo424(c, i) {
    const ch = c.children[i];
    ch.timer = 0;
    ch.frame = 0;
    ch.pattern = 424;
    ch.vx = 0.0;
    ch.vy = 0.0;
    if (ch.hitState === 3) {
        c.f3460++;
        if (c.f345c === 0) {
            c.f345c = 3000;
        } else {
            c.f345c += 1000;
            if (c.f345c > 3000) c.f345c = 3000;
        }
    }
    if (c.f3460 > 5) c.f3460 = 5;
}
function childShouldEnd(c, i, maxLoops) {
    const ch = c.children[i];
    if (c.state > 0x31 && c.state < 0x96) return true;
    if (c.a3358[i] > maxLoops) return true;
    if (ch.hitState > 0) return true;
    if (c.a3258[i] > 0x4b0) return true;
    if (c.state > 0x108 && c.state < 0x10c && c.frame === 0) return true;
    if (ch.x > 760.0) return true;
    if (ch.x < -120.0) return true;
    return false;
}
function childLoopAnim(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame < childCount) return;
    ch.frame = 0;
    c.a3358[i]++;
}
function spawnFromChild(c, i, pattern) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    f.w04 = pattern;
    f.x = ch.x;
    f.y = ch.y;
    f.b18 = c.facing;
    f.b20 = 2;
    f.b21 = 1;
    frameChild(c, f);
}
function childInterrupted(c) {
    if (c.state > 0x31 && c.state < 0x96) return true;
    return c.state > 0x108 && c.state < 0x10c && c.frame === 0;
}
function childStopTo424(c, i) {
    const ch = c.children[i];
    ch.timer = 0;
    ch.frame = 0;
    ch.pattern = 424;
    ch.vx = 0.0;
    ch.vy = 0.0;
}
function child453(c, i) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        ch.vy = 0.15;
        ch.vx = -1.0;
        c.a3158[i]++;
        ch.hitsLeft = 1;
    }
    c.a3258[i]++;
    if (ch.vy + ch.y >= -75.0 || childShouldEnd(c, i, 0x14)) {
        childEndTo424(c, i);
        return;
    }
    if (c.a3158[i] === 1) {
        ch.vx = ch.vx + 0.01;
        if (ch.vx > 0.0) {
            c.a3158[i]++;
            ch.ax = 0.01;
        }
    }
    if (ch.vx > 0.7) ch.ax = -0.01;
    if (ch.vx < -0.7) ch.ax = 0.01;
    if (c.a3158[i] > 1) ch.vx = ch.vx + ch.ax;
    childLoopAnim(c, i);
}
function child454(c, i) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        ch.vx = -0.3;
        ch.vy = 0.0;
        c.a3158[i]++;
        ch.hitsLeft = 1;
    }
    c.a3258[i]++;
    if (childShouldEnd(c, i, 6)) {
        childEndTo424(c, i);
        return;
    }
    if (c.a3158[i] === 1) {
        ch.vy = ch.vy + 0.01;
        if (ch.vy > 0.0) {
            c.a3158[i]++;
            ch.ay = 0.01;
        }
    }
    if (ch.vy > 0.7) ch.ay = -0.01;
    if (ch.vy < -0.7) ch.ay = 0.01;
    if (c.a3158[i] > 1) ch.vy = ch.vy + ch.ay;
    childLoopAnim(c, i);
}
function child455(c, i) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        ch.vy = (c.random(0, 0x14) & 0xffff) * 0.01 + 0.05;
        ch.vx = (c.random(0, 0xc8) & 0xffff) * 0.01 - 1.0;
        c.a3158[i]++;
        ch.hitsLeft = 1;
        if (ch.vx > 0.0) ch.ax = -0.01;
        else ch.ax = 0.01;
    }
    c.a3258[i]++;
    if (ch.vy + ch.y >= -75.0 || childShouldEnd(c, i, 0x14)) {
        childEndTo424(c, i);
        return;
    }
    if (ch.vx > 1.0) ch.ax = -0.01;
    if (ch.vx < -1.0) ch.ax = 0.01;
    if (c.a3158[i] > 0) ch.vx = ch.vx + ch.ax;
    childLoopAnim(c, i);
}
function child456(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 4.0;
        ch.vy = -2.5;
    }
    if (childInterrupted(c)) {
        childStopTo424(c, i);
        return;
    }
    if (ch.frame === 1) {
        const d = ch.x - c.opponent.x;
        if (d < 5.0 && d > -5.0) {
            spawnFromChild(c, i, 459);
            c.freeChild(i);
            return;
        }
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame < childCount) return;
    spawnFromChild(c, i, 459);
    c.freeChild(i);
}
function child457(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.vx = 4.0;
    if (ch.frame === 1) {
        const d = ch.x - c.opponent.x;
        if (d > 0.0 && ch.facing === 1 || d < 0.0 && ch.facing === -1) {
            ch.timer = 0;
            ch.frame = 2;
        }
    }
    if (childInterrupted(c)) {
        childStopTo424(c, i);
        return;
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame < childCount) return;
    spawnFromChild(c, i, 460);
    c.freeChild(i);
}
function child458(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 4.0;
        ch.vy = -2.5;
    }
    if (ch.frame === 1) {
        const d = ch.x - c.opponent.x;
        if (d < 5.0 && d > -5.0) {
            spawnFromChild(c, i, 461);
            c.freeChild(i);
            return;
        }
    }
    if (childInterrupted(c)) {
        childStopTo424(c, i);
        return;
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame < childCount) return;
    spawnFromChild(c, i, 461);
    c.freeChild(i);
}
function childSummon(c, i, pattern, spawnTwice) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) c.a3158[i] = 0;
    if (childInterrupted(c)) c.a3158[i] = 1;
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame === 0xa && c.a3158[i] !== 1) {
        spawnFromChild(c, i, pattern);
        if (spawnTwice) frameChild(c, childSpawnFrame);
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child459(c, i) {
    childSummon(c, i, 453, false);
}
function child460(c, i) {
    childSummon(c, i, 454, false);
}
function child461(c, i) {
    childSummon(c, i, 455, true);
}
registerChildren({
    453: child453,
    454: child454,
    455: child455,
    456: child456,
    457: child457,
    458: child458,
    459: child459,
    460: child460,
    461: child461
});
