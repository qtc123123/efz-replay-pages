const need=(ok,code)=>{if(!ok)throw Error('BATTLE_PLAYBACK_'+code);};
/** Bounded per-battle custody. External protocol/hash admission occurs before append. */
export function createBattlePlayback({sourceStart,adapter,close}){
 need(Number.isSafeInteger(sourceStart)&&sourceStart>=0,'SOURCE_START');
 need(adapter&&['step','status','retainedFrame'].every(k=>typeof adapter[k]==='function')&&typeof close==='function','DEPENDENCY');
 const pairs=new Uint16Array(8192);let head=0,size=0,next=0,received=0,state='battle',terminal=null,busy=false,retirement=null,operation=null;
 function retire(){if(!retirement)retirement=Promise.resolve(operation).catch(()=>{}).then(close);return retirement;}
 function clear(){pairs.fill(0);size=0;head=0;}
 return Object.freeze({
  status:()=>({state,nextFrame:next,nextSourceIndex:sourceStart+next,buffered:size,received}),
  append(chunk){
   need(state==='battle'&&!terminal,'CLOSED');need(chunk&&chunk.from===sourceStart+received,'ORDER');
   need(Array.isArray(chunk.pairs)&&chunk.pairs.length<=4096-size,'CAPACITY');
   need([null,'complete','interrupted','error'].includes(chunk.terminal),'TERMINAL');
   for(const pair of chunk.pairs)need(Array.isArray(pair)&&pair.length===2&&pair.every(v=>Number.isInteger(v)&&v>=0&&v<=65535&&(v&~0x23ff)===0),'INPUT');
   for(const pair of chunk.pairs){const at=((head+size++)%4096)*2;pairs[at]=pair[0];pairs[at+1]=pair[1];}
   received+=chunk.pairs.length;terminal=chunk.terminal;
  },
  step(){
   need(!busy,'BUSY');
   operation=(async()=>{
    if(state!=='battle'){need(['complete','interrupted','error'].includes(state),'CLOSED');return {kind:state,nextFrame:next};}
    if(size===0){need(terminal!=='complete','TERMINAL_MISMATCH');if(terminal){state=terminal;return {kind:state,nextFrame:next};}return {kind:'waiting',nextFrame:next};}
    busy=true;
    try{
     const at=head*2,pair=[pairs[at],pairs[at+1]];await adapter.step(pair);need(state!=='closed','CLOSED');
     pairs[at]=pairs[at+1]=0;head=(head+1)%4096;size--;next++;
     if(adapter.status()==='terminal'){need(size===0&&['complete','interrupted'].includes(terminal),'TERMINAL_MISMATCH');state=terminal;}
     else if(size===0&&terminal){need(terminal!=='complete','TERMINAL_MISMATCH');state=terminal;}
     return {kind:state==='battle'?'advanced':state,nextFrame:next};
    }finally{busy=false;}
   })();
   return operation.catch(async error=>{if(state!=='closed')state='failed';clear();await retire().catch(()=>{});throw error;});
  },
  retainedFrame(){need(state!=='closed'&&state!=='failed','CLOSED');return adapter.retainedFrame();},
  close(){state='closed';clear();return retire();}
 });
}
