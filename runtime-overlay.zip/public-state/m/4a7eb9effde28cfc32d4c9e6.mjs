import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerStates } from "./65b7ada33d910b3c78926926.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./e2bb73ea5d34f44e96511e06.mjs";
import { spawnEffect } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
const w16 = (v)=>v & 0xffff;
class Desc {
    d0 = 0;
    w4 = 0;
    x = 0;
    y = 0;
    b18 = 0;
    d1c = 0;
    b20 = 0;
    b21 = 0;
    d24 = 0;
    d28 = 0;
    b2c = 0xff;
    d30 = 0;
    clip = [
        0,
        0,
        0,
        0
    ];
}
function fx(d) {
    spawnEffect({
        owner: d.d0,
        pat: d.w4,
        x: d.x,
        y: d.y,
        b18: d.b18,
        mirror: d.d1c,
        blend: d.b20,
        layer: d.b21,
        fixed: d.d24,
        sound: d.b2c
    });
}
function child(c, d) {
    c.spawnChild({
        type: d.d0,
        pattern: d.w4,
        x: d.x,
        y: d.y,
        facing: d.b18,
        d4c: d.d1c,
        blend: d.b20,
        layer: d.b21,
        fixed: d.d24,
        shadow: d.d28,
        b6c: d.b2c,
        moveWhileFrozen: d.d30,
        clip: [
            ...d.clip
        ]
    });
}
function fxAtSelf(c, d, pat, blend, layer) {
    d.w4 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    fx(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function groundJumpCancel(c, ok) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && ok) {
        c.state = 4;
        if (c.inputX === c.facing) c.state = 5;
        if (c.inputX === -c.facing) c.state = 6;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a === 0) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function attackStart(c, meter, se) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = 1;
}
function landTo13(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return true;
    }
    return false;
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0x63);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.timer = w16(c.timer + 1);
    if (c.life > 0 && c.timer > 0x63 && c.frame === 0) c.setState(0x60);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(0x60);
    }
}
function sEmpty(_c) {}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 0x99, 0x96, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 0x9a, 0x97, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 0x9b, 0x98, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 0x99, 0x96, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 0x9a, 0x97, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 0x9b, 0x98, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy += c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(0xd);
    }
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy += c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(0xd);
    }
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c)) {
        c.stopMotion();
        d.w4 = 9;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x3c;
        d.b20 = 2;
        d.b21 = 1;
        fx(d);
        c.w16c = 1;
        c.seRequest = 0x3e;
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 3)) {
        c.stopMotion();
        d.w4 = 9;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x3c;
        d.b20 = 2;
        d.b21 = 1;
        fx(d);
        c.w16c = 1;
        c.seRequest = 0x3e;
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 0xd;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 0xc) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function dashSparks(c, d, list) {
    for (const [threshold, pattern, dx, dy] of list){
        if (rand("src/game/chars/ayu/states_template_b.ts:386:6", {
            consumer: "src/game/chars/ayu/states_template_b.ts"
        }) > threshold) {
            d.w4 = pattern;
            d.x = ftol(c.x) + c.facing * dx;
            d.y = ftol(c.y) - dy;
            d.b18 = c.facing;
            d.b21 = 0;
            child(c, d);
        }
    }
}
const SPARKS_FORWARD = [
    [
        0x2710,
        0x191,
        -0xb,
        0x32
    ],
    [
        0x4e20,
        0x192,
        -0x19,
        0x46
    ],
    [
        0x3a98,
        0x191,
        6,
        0x50
    ]
];
const SPARKS_BACK = [
    [
        0x2710,
        0x191,
        -0x46,
        0x25
    ],
    [
        0x3a98,
        0x192,
        -0x22,
        0x3a
    ],
    [
        0x4e20,
        0x191,
        0x18,
        0x2e
    ]
];
function dashDust(c, d, mirror) {
    d.w4 = 0x1f;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 0;
    d.b21 = 0;
    d.d1c = mirror;
    fx(d);
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c)) c.startAfterimage(2);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 0 && c.timer === 0) dashSparks(c, d, SPARKS_FORWARD);
    c.vy += c.ay;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 1) {
            dashDust(c, d, c.facing === -1 ? 1 : 0);
            c.vx = 1.8;
            c.vy = -1.3;
            c.ay = 0.01;
            c.seRequest = 0x11;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 0x78) {
        c.setState(9);
        c.vx = 0.5;
        c.ay = 0.03;
    }
    if (c.inputX !== c.facing && c.f3138 >= 0x27) {
        c.setState(9);
        c.vx = 0.5;
        c.ay = 0.03;
    }
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(2);
    }
    if (c.frame > 0 && c.timer === 0) dashSparks(c, d, SPARKS_BACK);
    c.vy += c.ay;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 1) {
            c.vx = -1.8;
            c.vy = -1.3;
            c.ay = 0.01;
            c.seRequest = 0x11;
            dashDust(c, d, c.facing === 1 ? 1 : 0);
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX !== -c.facing) c.f3138 = 0;
    if (c.f313c > 0x27 && c.inputX !== -c.facing || c.f313c >= 0x78) {
        c.setState(9);
        c.vx = -0.5;
        c.ay = 0.03;
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c) && c.f3140 === 0) {
        c.vx = 1.8;
        c.vy = -0.3;
        c.seRequest = 0x11;
        c.f3140++;
    }
    if (c.timer === 0) dashSparks(c, d, SPARKS_FORWARD);
    c.vy += 0.01;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 0x78) {
        c.setState(9);
        c.vx = 1.3;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
    if (c.inputX !== c.facing && c.f3138 >= 0x30) {
        c.setState(9);
        c.vx = 1.3;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c) && c.f3140 === 0) {
        c.vx = -1.8;
        c.vy = -0.3;
        c.seRequest = 0x11;
        c.f3140++;
    }
    if (c.timer === 0) dashSparks(c, d, SPARKS_BACK);
    c.vy += 0.01;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 0x78) {
        c.setState(9);
        c.vx = -0.9;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
    if (c.inputX !== -c.facing && c.f3138 >= 0x2a) {
        c.setState(9);
        c.vx = -0.9;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 0x5a;
    c.superDarken(0xb0, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 0x12;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 0x3c;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 0xa9;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 0x12;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            if (c.f3140 < 7) {
                c.frame = w16(c.frame - 2);
                c.f3140++;
                return;
            }
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 7) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 7;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 1) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 0x15);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) c.vx = 0.5;
    if (atFrame(c, 2)) attackStart(c, 15, 0x14);
    if (c.frame > 1) {
        c.vx -= 0.02;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (advance(c, dur)) {
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) attackStart(c, 15, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) attackStart(c, 0x23, 0x14);
    if (atFrame(c, 3)) {
        d.w4 = 3;
        d.x = ftol(c.x) + c.facing * 0x37;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        fx(d);
        c.voiceRequest = 8;
    }
    if (advance(c, dur)) {
        if (c.frame < 5) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 0x15);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atFrame(c, 2)) attackStart(c, 0xd, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 5) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atFrame(c, 3)) attackStart(c, 0x19, 0x14);
    if (atFrame(c, 4)) {
        d.w4 = 0;
        d.x = ftol(c.x) + c.facing * 0x46;
        d.y = ftol(c.y) - 0xa;
        d.b20 = 2;
        d.b2c = 1;
        d.b21 = 1;
        fx(d);
    }
    if (advance(c, dur)) {
        if (c.frame < 6) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function airNormal(c, startFrame, meter, se, resetBefore) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, startFrame)) attackStart(c, meter, se);
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame < resetBefore) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s207 = (c)=>airNormal(c, 1, 5, 0x15, 3);
const s208 = (c)=>airNormal(c, 2, 0xd, 0x14, 2);
const s209 = (c)=>airNormal(c, 3, 0x1e, 0x14, 5);
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) {
        c.vx = 1.4;
        c.vy = -1.5;
        c.ay = 0.08;
    }
    if (atFrame(c, 2)) attackStart(c, 15, 0x14);
    if (atFrame(c, 5)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 0) c.vy += c.ay;
    if (advance(c, dur)) {
        if (c.frame < 6) c.d168 = 0;
        if (c.frame === 5) {
            if (c.y + c.vy < 0.0) c.frame = w16(c.frame - 1);
            else c.y = 0.0;
        }
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atFrame(c, 3)) attackStart(c, 0x1e, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 9) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function impactFx(c, d) {
    c.shakeScreen(3, 0);
    d.w4 = 3;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 0;
    d.b2c = 7;
    fx(d);
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    c.vy += c.ay;
    if (atStart(c)) {
        attackStart(c, 0x1e, 0x14);
        c.vx = c.vx / 2.0;
        c.ay = 0.07;
    }
    if (c.d168 > 1) {
        c.setState(0xd5);
        c.stopMotion();
        return;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.vy = 0.0;
        impactFx(c, d);
        c.seRequest = 7;
        c.setState(0xd6);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) impactFx(c, d);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 0xdd;
        o.state = 0x6e;
        o.d128 = 1;
        d.w4 = 0;
        d.x = ftol(c.x) + c.facing * 0x29;
        d.y = ftol(c.y) - 0x2c;
        d.b20 = 2;
        d.b21 = 1;
        fx(d);
    }
    if (atFrame(c, 2)) c.w16c = 1;
    if (atFrame(c, 3)) {
        d.w4 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        d.b2c = 7;
        fx(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (atStart(c)) {
        o.state = 0x64;
        o.stopMotion();
        o.y = 0.0;
        o.x = c.facing * 0x2a + c.x;
        o.onStateChange();
    }
    if (atFrame(c, 4)) {
        o.onStateChange();
        o.state = 0x3b;
        o.knockX = 1.0;
        o.knockY = -2.0;
        o.ay = 0.035;
        o.y = -59.0;
        o.x = c.facing * 0xf + c.x;
        o.d128 = 1;
        applyDirectDamage(c, 0x4b0, 750.0);
        c.comboCount = s16(c.comboCount - 1);
        c.comboDisplay = s16(c.comboDisplay - 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) {
            o.state = 0x64;
            o.y = -33.0;
            o.x = c.facing * 0x1e + c.x;
        }
        if (c.frame === 2) {
            o.state = 0x68;
            o.y = -27.0;
            o.x = c.facing * 0x22 + c.x;
        }
        if (c.frame === 3) {
            o.y = -54.0;
            o.x = c.facing * 0xe + c.x;
        }
        if (c.frame >= cnt) {
            c.state = 0x62;
            c.faceOpponent();
            c.onStateChange();
            c.frame = 2;
            c.x = c.x - c.facing * 0x14;
        }
    }
}
function airNormalB(c, startFrame, meter, se) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = 0.5;
        c.ay = 0.03;
    }
    if (atFrame(c, startFrame)) attackStart(c, meter, se);
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s230 = (c)=>airNormalB(c, 1, 5, 0x15);
const s231 = (c)=>airNormalB(c, 2, 0xa, 0x15);
const s232 = (c)=>airNormalB(c, 1, 0xa, 0x14);
function s240(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = new Desc();
    const o = c.opponent;
    c.vy += c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 0xf1;
        o.state = 0x64;
        d.w4 = 0;
        d.x = ftol(c.x) + c.facing * 0x13;
        d.y = ftol(c.y) - 0x32;
        d.b20 = 2;
        d.b21 = 1;
        fx(d);
        o.x = c.facing * 0x13 + c.x;
        o.y = c.y - 50.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 0x32 || o.state > 0x95)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0xd1;
            c.frame = 2;
        }
    }
}
function s241(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 6) c.biasCamera(0x32, 3);
    if (c.frame < 6) c.biasCameraY(0x32, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy += c.ay;
    if (c.vy > 0.0 && c.frame === 1) {
        c.frame = 2;
        c.timer = 0;
        return;
    }
    if (c.vy + c.y > 0.0 && c.frame === 4) {
        c.stopMotion();
        c.y = 0.0;
        c.frame = 5;
        c.timer = 0;
        c.shakeScreen(4, 0);
        o.x = c.x;
        o.y = 0.0;
        o.state = 0x62;
        applyDirectDamage(c, 0x44c, 500.0);
        o.onStateChange();
    }
    if (c.vy + c.y > 0.0 && c.frame > 8) {
        c.stopMotion();
        c.onStateChange();
        c.y = 0.0;
        c.state = 0xd;
        return;
    }
    if (c.frame === 1) {
        o.y = c.y - 86.0;
        o.x = c.facing * 0x26 + c.x;
        o.state = 0x67;
    }
    if (c.frame === 2) {
        o.y = c.y - 15.0;
        o.x = c.facing * 0x19 + c.x;
        o.state = 0x75;
    }
    if (c.frame === 3) {
        o.y = c.y;
        o.x = c.facing * 0xf + c.x;
        o.state = 0x75;
    }
    if (c.frame === 4) {
        o.y = c.y + 1.0;
        o.x = c.facing * 0xd + c.x;
        o.state = 0x75;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) {
            c.vy = -3.5;
            c.ay = 0.045;
        }
        if (c.frame === 5) c.frame = w16(c.frame - 1);
        if (c.frame === 6) {
            c.vx = -1.0;
            c.vy = -2.0;
            c.ay = 0.035;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    103: sEmpty,
    107: sEmpty,
    113: sEmpty,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    240: s240,
    241: s241
});

export function __logicState(){return {SPARKS_FORWARD,SPARKS_BACK};}

export function __installInitialRoots(s){
if(SPARKS_FORWARD!==s["SPARKS_FORWARD"])throw Error('INITIAL_CONST_IDENTITY:SPARKS_FORWARD');
if(SPARKS_BACK!==s["SPARKS_BACK"])throw Error('INITIAL_CONST_IDENTITY:SPARKS_BACK');
}
