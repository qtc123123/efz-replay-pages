import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./5ebc1d602888d5d1fbd12f34.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./1ced9d0c06b49387c5b9e1d5.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function groundJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2) {
        jumpTo456(c);
        return true;
    }
    return false;
}
function airJumpCancel(c, checkD15c) {
    if (c.inputY !== -1 || c.frame <= 0) return false;
    if (checkD15c && c.d15c >= 3) return false;
    if (c.d168 < 2 || c.b15a !== 0) return false;
    c.b15a = c.b15a + 1 & 0xff;
    c.state = 14;
    if (c.inputX === c.facing) c.state = 15;
    if (c.inputX === -c.facing) c.state = 16;
    c.d168 = 0;
    c.onStateChange();
    return true;
}
function attackStart(c, meter, se, hits) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = hits;
}
function groundNormalPrologue(c) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - 0.03;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function burstFx(c, d) {
    d.w04 = 9;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 70;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    c.w16c = 1;
    c.seRequest = 62;
}
function airLand(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function landShockFx(c, d) {
    c.shakeScreen(3, 0);
    d.w04 = 3;
    d.x = ftol(c.x) + c.facing * 0x1e;
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 0;
    frameEffect(d);
    c.seRequest = 7;
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atFrame(c, 1) && c.f3148 > 0) c.f3148 = c.f3148 - 1;
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(99);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.life > 0 && c.timer > 99) c.setState(96);
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(96);
    }
}
function s123(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (advance(c, dur) && c.frame >= cnt) c.setState(99);
}
function guardGround(c, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx = c.vx + 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy = c.vy + c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy = c.vy + c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        burstFx(c, d);
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 7)) {
        c.stopMotion();
        burstFx(c, d);
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 13) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(1);
        c.stopMotion();
    }
    if (c.frame < 11 && c.frame > 4) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 11) {
        c.timer = 0;
        c.stopMotion();
        c.frame = 11;
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 5) {
            c.vx = 1.4;
            c.vy = -0.75;
            c.ay = 0.015;
        }
        if (c.frame === 11) c.frame = w16(c.frame - 4);
        if (c.frame >= cnt) c.setState(3);
    }
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(2);
    if (atStart(c)) c.stopMotion();
    if (c.frame > 3) {
        c.vx = c.vx + 0.02;
        c.vy = c.vy + 0.035;
    }
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.y + c.vy > 0.0 && c.frame < 11) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 11;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 4) {
            c.vx = -2.0 - c.f3148 * 0.1;
            c.vy = -1.2;
        }
        if (c.frame === 11) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 3;
        }
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.w16c = c.f3148 > 7 ? 1 : 0;
        c.stopMotion();
        d.w04 = 400;
        d.x = ftol(c.x) - c.facing * 0x24;
        d.y = ftol(c.y) - 62;
        d.b18 = c.facing;
        d.b21 = 0;
        d.b20 = 0;
        frameChild(c, d);
    }
    if (c.f3138 === 1 && c.frame === 0) {
        c.vx = 1.9;
        c.vy = -0.2;
        c.ay = 0.035;
        c.timer = 0;
        c.frame = 1;
        return;
    }
    if (c.frame > 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.onStateChange();
        c.state = 179;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 2);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = c.f3148 > 4 ? 1 : 0;
        d.w04 = 400;
        d.x = ftol(c.x) + c.facing * 0x24;
        d.y = ftol(c.y) - 62;
        d.b18 = -c.facing;
        d.b21 = 1;
        d.b20 = 0;
        frameChild(c, d);
    }
    if (c.f3138 === 1 && c.frame === 0) {
        c.vx = -1.9;
        c.vy = -0.2;
        c.ay = 0.035;
        c.timer = 0;
        c.frame = 1;
        return;
    }
    if (c.frame > 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.onStateChange();
        c.state = 179;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 2);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.faceOpponent();
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s179(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 11) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 11;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 4) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 11) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundNormalPrologue(c);
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 2)) attackStart(c, 5, 21, 1);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundNormalPrologue(c);
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 15, 20, 1);
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur || c.timer >= dur - 3 && c.frame === 2 && c.f3148 > 4) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 3) c.frame = 4;
        if (c.frame === 2 && c.f3148 > 3) c.frame = 3;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) c.w16c = 0;
    if (atFrame(c, 4)) {
        addMeter(c, 15);
        c.seRequest = 20;
        if (c.f3148 > 5) c.w16c = 1;
    }
    if (atFrame(c, 5)) c.w16c = 8;
    if (c.frame < 10 && c.frame > 5) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.timer = 0;
        if (c.frame < 10 && c.frame > 5) {
            c.frame = 10;
            landShockFx(c, d);
        }
        c.vy = 0.0;
    }
    if (c.frame >= 10) {
        c.vx = c.vx - 0.035;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 5) {
            c.vy = -1.5;
            c.vx = c.f3148 * 0.05 + 1.0;
            c.ay = 0.06;
        }
        if (c.frame === 10) c.frame = w16(c.frame - 4);
        if (c.frame === 11) c.w16c = c.f3148 > 4 ? 1 : 0;
        if (c.frame === 4 || c.frame === 5 || c.frame === 7 || c.frame === 9 || c.frame === 11) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 0;
    }
    if (c.inputY === -1 && c.frame > 0 && c.f3148 > 4 && c.y === 0.0 && c.d15c < 3 && c.d168 >= 2 && c.f3148 > 6) {
        jumpTo456(c);
        return;
    }
    if (atFrame(c, 8)) {
        addMeter(c, 35);
        c.seRequest = 20;
        if (c.f3148 > 5) c.w16c = 1;
    }
    if (atFrame(c, 10)) c.w16c = 1;
    if (c.frame > 13) c.vy = c.vy + c.ay;
    if (c.frame > 13 && c.vy + c.y > 0.0) {
        c.onStateChange();
        c.state = 13;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 10) c.voiceRequest = 3;
        if (c.frame < 9) c.d168 = 0;
        if (c.frame === 8 || c.frame === 9 || c.frame === 10) c.x = c.facing * 0x28 + c.x;
        if (c.frame === 14) {
            c.vy = -1.0;
            c.vx = 0.7;
            c.ay = 0.033;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 1);
    }
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundNormalPrologue(c);
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 21, 1);
    if (advance(c, dur)) {
        if (c.frame === 3) c.frame = 4;
        if (c.frame === 2 && c.f3148 > 4) c.frame = 3;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundNormalPrologue(c);
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 2)) attackStart(c, 13, 20, 1);
    c.timer = w16(c.timer + 1);
    const early = c.timer >= 3 && (c.frame === 1 && c.f3148 > 0 || c.frame === 2 && c.f3148 > 1 || c.frame === 3 && c.f3148 > 3 || c.frame === 4 && c.f3148 > 5);
    if (c.timer >= dur || early) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        c.d168 = 0;
        if (c.frame === 1) c.x = c.facing * 0xf + c.x;
        if (c.frame === 2) c.x = c.facing * 0xf + c.x;
        if (c.frame >= cnt) {
            c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundNormalPrologue(c);
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 3)) attackStart(c, 25, 20, 1);
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur || c.timer >= dur - 3 && c.frame < c.f3148 - 4 && c.frame < 4) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 3)) attackStart(c, 30, 20, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function airNormal(c, checkD15c, atk, meter, se, hits, clearBelow) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c, checkD15c)) return;
    if (atFrame(c, atk)) attackStart(c, meter, se, hits(c));
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return;
    }
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const hitsByLevel = (c)=>Math.trunc(c.f3148 / 2) + 2;
const s207 = (c)=>airNormal(c, true, 2, 5, 21, ()=>1, 2);
const s208 = (c)=>airNormal(c, true, 1, 13, 20, hitsByLevel, 6);
const s230 = (c)=>airNormal(c, false, 2, 5, 21, ()=>1, 2);
const s231 = (c)=>airNormal(c, false, 1, 13, 20, hitsByLevel, 6);
function airHeavy(c, checkD15c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c, checkD15c)) return;
    if (atFrame(c, 2)) attackStart(c, 30, 20, 3);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur || c.timer >= dur - 3 && c.frame < c.f3148 - 3 && c.frame < 4) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s209 = (c)=>airHeavy(c, true);
const s232 = (c)=>airHeavy(c, false);
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 4)) {
        c.ay = 0.055;
        c.vy = -1.7;
        c.vx = 0.5;
        c.w16c = 1;
    }
    if (c.frame > 4) c.vy = c.vy + c.ay;
    if (atFrame(c, 8)) c.seRequest = 20;
    if (advance(c, dur) && c.frame >= cnt) {
        c.onStateChange();
        c.state = 3;
        c.faceOpponent();
        return;
    }
    if (c.y + c.vy >= 0.0 && c.frame > 4 && c.frame < 11) {
        c.y = 0.0;
        c.seRequest = 9;
        c.frame = 11;
        c.timer = 0;
        c.stopMotion();
    }
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atFrame(c, 2)) {
        attackStart(c, 15, 20, 1);
        c.vy = c.vy - -1.0;
        c.ay = 0.035;
    }
    c.vy = c.vy + c.ay;
    if (c.d168 > 1) {
        c.timer = 0;
        c.frame = 0;
        c.state = 257;
        c.vx = -c.vx;
        c.vy = -2.5;
        c.ay = 0.025;
        return;
    }
    if (c.vy + c.y > 0.0 && c.frame < 5 && c.frame > 1) {
        c.y = 0.0;
        c.timer = 0;
        c.frame = 5;
        landShockFx(c, d);
        c.vx = 0.0;
        c.vy = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 5) c.frame = w16(c.frame - 1);
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.04;
    c.vx = 0.0;
    c.vy = c.vy + c.ay;
    if (atFrame(c, 3)) attackStart(c, 30, 20, 1);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.state = 97;
        c.stopMotion();
        c.onStateChange();
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (atFrame(c, 2)) attackStart(c, 30, 20, 3);
    if (c.y + c.vy > 0.0) {
        c.y = 0.0;
        c.timer = 0;
        c.stopMotion();
        c.frame = 10;
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(7);
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        if (c.x > 600.0) c.x = 600.0;
        if (c.x < 40.0) c.x = 40.0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 221;
        o.state = 107;
        o.x = c.facing * 0xf + c.x;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x25;
        d.y = ftol(c.y) - 22;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (atFrame(c, 4)) {
        applyDirectDamage(c, 1000, 750.0);
        o.state = 63;
        o.onStateChange();
        o.stopMotion();
        o.knockX = 1.0;
        o.knockY = -2.5;
        o.y = -50.0;
        o.x = c.x;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) o.x = o.x - c.facing;
        if (c.frame === 2) o.x = o.x - c.facing;
        if (c.frame === 3) o.x = o.x - c.facing;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function s248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 249;
        o.state = 100;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x21;
        d.y = ftol(c.y) - 51;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.x = c.facing * 0x21 + c.x;
        o.y = c.y - 61.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 209;
            c.frame = 2;
        }
    }
}
const S249_HOLD = [
    [
        66.0,
        0x17
    ],
    [
        69.0,
        0x15
    ],
    [
        73.0,
        0x13
    ],
    [
        74.0,
        0x13
    ],
    [
        71.0,
        0x11
    ],
    [
        70.0,
        0x10
    ]
];
function s249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 7) c.biasCamera(50, 3);
    if (c.frame < 7) c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 5) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.state = 13;
        return;
    }
    for(let f = 1; f <= 6; f++){
        if (c.frame === f) {
            const [dy, dx] = S249_HOLD[f - 1];
            o.y = c.y - dy;
            o.x = c.facing * dx + c.x;
        }
    }
    if (atFrame(c, 7)) {
        o.facing = c.facing;
        o.y = c.y - 60.0;
        o.x = c.x - c.facing * 0x25;
        o.state = 63;
        applyDirectDamage(c, 1300, 500.0);
        o.onStateChange();
        o.knockX = -2.0;
        o.knockY = -1.0;
    }
    if (atFrame(c, 11)) c.ay = 0.035;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 11) c.facing = -c.facing;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    123: s123,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    179: s179,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    248: s248,
    249: s249
});
function child400(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 5 && c.f3138 === 0) {
        c.f3138 = 1;
        const d = childSpawnFrame;
        d.w04 = 0;
        d.x = ftol(ch.x) + ch.facing * 0x17;
        d.y = ftol(ch.y) - 9;
        d.b20 = 2;
        d.b21 = 1;
        d.b2c = 2;
        frameEffect(d);
        ch.vx = -0.9;
        ch.vy = -1.0;
        ch.ay = 0.035;
    }
    ch.vy = ch.vy + ch.ay;
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= dur) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame === 7) ch.blend = 1;
        if (ch.frame >= cnt) c.freeChild(i);
    }
}
registerChildren({
    400: child400
});

export function __logicState(){return {S249_HOLD};}

export function __installInitialRoots(s){
if(S249_HOLD!==s["S249_HOLD"])throw Error('INITIAL_CONST_IDENTITY:S249_HOLD');
}
