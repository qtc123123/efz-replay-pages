import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./c2c7a57dacaa46758b7f3f58.mjs";
import { updateChildrenAkiko } from "./7b1ab9c36f2b6b5ca7dcee6a.mjs";
import { parseCommandAkiko, dispatchMovesAkiko } from "./ae9e4e5a283a21da20a3720a.mjs";
import { thinkAkiko } from "./9b9414a3999602b0e9ed5833.mjs";
import { renderOverlayAkiko, tickHookAkiko } from "./7292524e46076faaab3b4092.mjs";
import "./09b1e222379c4ec7ba335e06.mjs";
import "./c573fa003da0c072062edf43.mjs";
import "./292e16d99685291f60fadf69.mjs";
const POINTS_X = [
    -6,
    -22,
    12,
    22,
    27
];
const POINTS_Y = [
    -72,
    0,
    -14,
    -19,
    -41
];
export class Akiko extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    f3154 = 0;
    f3158 = 0;
    f315c = 0;
    f3160 = 0;
    a3164 = new Int32Array(64);
    a3264 = new Int32Array(64);
    a3364 = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        4,
        0x10,
        1,
        0xa,
        3,
        0x17,
        0x13,
        0x11
    ];
    w0dc = 0;
    b0de = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = 0;
        this.f314c = 0;
        this.f3150 = 0;
        this.f3154 = 0;
        this.f3158 = 0;
        this.f315c = 0;
        this.f3160 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a3164.fill(0);
        this.a3264.fill(0);
        this.a3364.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3164[i] = 0;
        this.a3264[i] = 0;
        this.a3364[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayAkiko(this);
    }
    tickHook() {
        tickHookAkiko(this);
    }
    parseCommand() {
        parseCommandAkiko(this);
    }
    dispatchMoves() {
        dispatchMovesAkiko(this);
    }
    think() {
        thinkAkiko(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenAkiko(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
