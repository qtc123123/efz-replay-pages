import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./63e7d3d2e4c75abee840f38e.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./3a237fcb73b1d38bd3b629bc.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function superFreeze(c, cost) {
    c.stopMotion();
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function superEffect(d, c, pat, sound, dx, dy) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) + dx;
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function advance(c, dur, cnt) {
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function rushStart(c, cost, pat, sound, next, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (big && c.frame > 0) c.showAltBackground(0xf);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (atStart(c)) {
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, c.facing * 8, 0x1b);
        c.w16c = 1;
    }
    if (c.frame < 8) c.biasCameraY(0x32, 0xa);
    if (c.frame === 6 && c.d168 === 3) {
        c.screenFlash(1, 9, 0x24, 9);
        c.onStateChange();
        c.state = next;
        o.hitstop = 0xb4;
        return;
    }
    advance(c, dur, cnt);
}
function rushHit(c, w16c, child, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.biasCameraY(0x32, 0xa);
    if (big) c.showAltBackground(0xf);
    if (atStart(c)) c.w16c = w16c;
    if (atFrame(c, 1)) {
        c.facing = 1;
        o.facing = -1;
        if (o.x < 40.0) o.x = o.x + 40.0;
        c.x = o.x - 40.0;
        spawnAtSelf(c, d, child);
    }
    if (atFrame(c, 0xa)) spawnAtSelf(c, d, child + 1);
    if (atFrame(c, 0x12)) spawnAtSelf(c, d, child + 2);
    advance(c, dur, cnt);
}
function spawnAtSelf(c, d, pat) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function slideStart(c, cost, pat, sound, speed, next, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.b158 = 0;
    if (big) c.showAltBackground(0x3c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (atStart(c)) {
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, 0, 0x28);
        c.w16c = 1;
    }
    if (atFrame(c, 0xa)) c.vx = speed;
    if (c.vx > 0.0) c.vx -= 0.08;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame < 0xd) c.biasCameraY(0x32, 0xa);
    if (c.frame === 0xc && c.d168 === 3) {
        o.onStateChange();
        o.state = 0x48;
        o.stopMotion();
        o.y = 0.0;
        c.onStateChange();
        c.state = next;
        o.hitstop = 0xb4;
        return;
    }
    advance(c, dur, cnt);
}
function slideHit(c, w16c, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.b158 = 0;
    if (big) c.showAltBackground(0xf);
    c.vx -= 0.08;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atStart(c)) {
        o.y = 0.0;
        c.w16c = w16c;
        c.faceOpponent();
    }
    if (c.frame < 0x24) c.biasCameraY(0x32, 0xa);
    advance(c, dur, cnt);
}
function jumpSuper(c, cost, pat, sound, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 8)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, -(c.facing * 0x1f), 0x48);
        c.w16c = 2;
    }
    if (big && c.frame > 7) c.showAltBackground(0xf);
    if (c.frame === 0xc && c.d168 > 0 && c.f3140 === 0) {
        o.hitstop = 0xb4;
        c.stopMotion();
        c.f3140++;
    }
    if (c.frame === 0x10 && c.d168 > 0 && c.f3140 === 1) {
        o.hitstop = 0xb4;
        c.stopMotion();
        c.f3140++;
    }
    if (c.frame === 8) c.biasCameraY(0x32, 3);
    if (c.frame === 0xd && c.y + c.vy > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 0x20;
        return;
    }
    if ((c.frame === 0x1e || c.frame === 0x1f) && c.y + c.vy > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 0x20;
        return;
    }
    c.vy += c.ay;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 1 || c.frame === 0xf) c.d168 = 0;
    if (c.frame === 3) {
        c.vx = 0.7;
        c.vy = -1.8;
        c.ay = 0.028;
    }
    if (c.frame === 9) {
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
        c.ay = 0.025;
    }
    if (c.frame === 0xe) c.frame = 0xd;
    if (c.frame === 0xd && c.d168 > 0) c.frame = 0xe;
    if (c.frame === 0xf) o.hitstop = 0;
    if (c.frame === 0x11 && c.d168 === 0) {
        c.ay = 0.035;
        o.hitstop = 0;
    }
    if (c.frame === 0x12 && c.d168 > 0) {
        o.hitstop = 0;
        c.vx = -2.5;
        c.vy = -2.5;
        c.ay = 0.035;
    }
    if (c.frame === 0x20) c.frame -= 2;
    if (c.frame >= cnt) {
        c.state = 3;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state315(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.showAltBackground(0xf);
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        c.biasCameraY(0x32, 0x2d);
        c.freeze = 0x78;
        c.superDarken(0xb0, 3);
        c.meter = s16(c.meter - 0xbb8);
        superEffect(d, c, 0x46, 0x40, -c.facing, 0x34);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (c.d168 === 6 && c.frame === 6) {
        c.onStateChange();
        c.d168 = 0;
        c.freeze = 0xa0;
        c.seRequest = 3;
        c.state = 0x13c;
        c.screenFlash(1, 0x14, 0x3c, 0x3c);
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0xa;
        d.y = ftol(c.y) - 0x28;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    advance(c, dur, cnt);
}
function state316(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame < 3) c.showAltBackground(3);
    c.b158 = 0;
    if (c.frame < 3) c.superDarken(0xb1, 3);
    if (atFrame(c, 1)) {
        gs.specialTimerE = 0x7530;
        gs.specialTimerE = 0x7530;
        gs.specialTimerC = 0x7530;
        applyDirectDamage(c, 0x1388, 1000.0);
        o.onStateChange();
        o.stopMotion();
        o.state = 0x57;
        o.d128 = 1;
        c.seRequest = 0x24;
        d.w04 = 0x198;
        d.x = 0.0;
        d.y = 0.0;
        d.b20 = 0;
        d.d24 = 1;
        d.b18 = 1;
        d.b21 = 0;
        frameChild(c, d);
        d.w04 = 0x199;
        d.x = 0.0;
        d.y = 0.0;
        d.b20 = 0;
        d.d24 = 1;
        d.b18 = 1;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (atFrame(c, 2)) c.screenFlash(1, 0x28, 0x32, 0x28);
    if (c.frame === 3) c.biasCameraY(0x32, 3);
    if (atFrame(c, 3)) {
        gs.specialTimerE = 0;
        gs.specialTimerE = 0;
        gs.specialTimerC = 0;
        o.frame = 0;
        o.facing = 0;
        o.d128 = 1;
        o.state = 0x3f;
        o.ay = 0.035;
        o.facing = c.facing;
        o.y = -640.0;
        o.x = c.x - c.facing * 0x3c;
        o.knockX = 1.5;
    }
    advance(c, dur, cnt);
}
registerStates({
    300: (c)=>rushStart(c, 0x3e8, 0x44, 0x13, 0x12d, false),
    301: (c)=>rushHit(c, 2, 0x192, false),
    302: (c)=>rushStart(c, 0x7d0, 0x45, 5, 0x12f, false),
    303: (c)=>rushHit(c, 2, 0x192, false),
    304: (c)=>rushStart(c, 0xbb8, 0x46, 0x40, 0x131, true),
    305: (c)=>rushHit(c, 3, 0x195, true),
    306: (c)=>slideStart(c, 0x3e8, 0x44, 0x13, 4.0, 0x133, false),
    307: (c)=>slideHit(c, 6, false),
    308: (c)=>slideStart(c, 0x7d0, 0x45, 5, 4.3, 0x135, false),
    309: (c)=>slideHit(c, 0xf, false),
    310: (c)=>slideStart(c, 0xbb8, 0x46, 0x40, 4.6, 0x137, true),
    311: (c)=>slideHit(c, 0xf, true),
    312: (c)=>jumpSuper(c, 0x3e8, 0x44, 0x13, false),
    313: (c)=>jumpSuper(c, 0x7d0, 0x45, 5, false),
    314: (c)=>jumpSuper(c, 0xbb8, 0x46, 0x40, true),
    315: state315,
    316: state316
});
function childStep(c, i, dur) {
    const ch = c.children[i];
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function child402(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.timer++;
    if (c.state < 0x12c || c.state > 0x131 || c.frame > 0x15) c.freeChild(i);
    if (!childStep(c, i, dur)) return;
    if (ch.frame >= cnt) c.freeChild(i);
}
function child405(c, i, pts) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.timer++;
    if (c.state < 0x12c || c.state > 0x131) c.freeChild(i);
    if (c.frame === 0x16) {
        c.freeChild(i);
        const d = childSpawnFrame;
        d.w04 = 0x191;
        for(let k = 0; k < 3; k++){
            const [dx, y] = pts[k];
            d.x = ftol(ch.x) + c.facing * dx;
            d.y = y;
            if (k === 0) {
                d.b18 = c.facing;
                d.b20 = 2;
                d.b21 = 1;
            }
            frameChild(c, d);
        }
        return;
    }
    if (!childStep(c, i, dur)) return;
    if (ch.frame >= cnt) c.freeChild(i);
}
function child408(c, i, vx) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (vx !== null) {
        ch.vx = vx;
        ch.drawWhileFrozen = 0x7530;
        ch.timer++;
    } else {
        ch.timer++;
        ch.drawWhileFrozen = 0x7530;
    }
    if (c.state === 0x13c && c.frame === 3) c.freeChild(i);
    if (!childStep(c, i, dur)) return;
    if (ch.frame >= cnt) ch.frame = 0;
}
registerChildren({
    402: child402,
    403: child402,
    404: child402,
    405: (c, i)=>child405(c, i, [
            [
                0x24,
                -47.0
            ],
            [
                0x3f,
                -62.0
            ],
            [
                0x5a,
                -77.0
            ]
        ]),
    406: (c, i)=>child405(c, i, [
            [
                0x1e,
                -59.0
            ],
            [
                0x36,
                -33.0
            ],
            [
                0x4e,
                -7.0
            ]
        ]),
    407: (c, i)=>child405(c, i, [
            [
                0x1e,
                -32.0
            ],
            [
                0x20,
                -72.0
            ],
            [
                0x22,
                -112.0
            ]
        ]),
    408: (c, i)=>child408(c, i, null),
    409: (c, i)=>child408(c, i, 0.08)
});
