import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
export const CHARACTER_PATTERN_SLOTS = 505;
class Reader {
    data;
    pos = 0;
    view;
    constructor(data){
        this.data = data;
        this.view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    }
    i32() {
        if (this.pos + 4 > this.data.length) {
            this.pos += 4;
            return 0;
        }
        const v = this.view.getInt32(this.pos, true);
        this.pos += 4;
        return v;
    }
    i16() {
        if (this.pos + 2 > this.data.length) {
            this.pos += 2;
            return 0;
        }
        const v = this.view.getInt16(this.pos, true);
        this.pos += 2;
        return v;
    }
    get eof() {
        return this.pos >= this.data.length;
    }
}
const s16 = (v)=>v << 16 >> 16;
const s8 = (v)=>v << 24 >> 24;
function readBox(r) {
    return {
        left: r.i32(),
        top: r.i32(),
        right: r.i32(),
        bottom: r.i32()
    };
}
function emptyBox() {
    return {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0
    };
}
function readHitFrame(r) {
    const damage = s16(r.i32());
    const attackFlags = s16(r.i32()) & 0xffff;
    const airHitState = s16(r.i32());
    const defenseFlags = s16(r.i32()) & 0xffff;
    const hitstun = s16(r.i32());
    const chip = s16(r.i32());
    const meterOnHit = s16(r.i32());
    const meterOnGuard = s16(r.i32());
    const knockbackY = Math.fround(Math.fround(r.i16()) / 100.0);
    const knockbackX = Math.fround(Math.fround(r.i16()) / -100.0);
    const hitEffectParam = r.i16() & 0xff;
    const hitEffect = s8(r.i16());
    const attackerHitstop = s16(r.i32());
    const defenderHitstop = s16(r.i32());
    const proration = Math.fround(r.i32());
    const groundHitState = s16(r.i32());
    const b = Array.from({
        length: 10
    }, ()=>readBox(r));
    return {
        body: b[0],
        hurt: [
            b[1],
            b[2],
            b[4],
            b[5],
            b[6]
        ],
        attack: [
            b[3],
            b[7],
            b[8],
            b[9]
        ],
        damage,
        proration,
        chip,
        attackFlags,
        airHitState,
        groundHitState,
        defenseFlags,
        hitstun,
        meterOnHit,
        meterOnGuard,
        knockbackX,
        knockbackY,
        hitEffect,
        hitEffectParam,
        attackerHitstop,
        defenderHitstop
    };
}
function readFrame(r, durationScale) {
    const duration = s16(s16(r.i32()) * durationScale);
    const sprite = r.i32() & 0xffff;
    const width = s16(r.i32());
    const height = s16(r.i32());
    const offsetX = s16(r.i32());
    const offsetY = s16(r.i32());
    return {
        duration,
        sprite,
        offsetX,
        offsetY,
        width,
        height
    };
}
export function parseCharacterPat(data) {
    const r = new Reader(data);
    const patterns = new Array(CHARACTER_PATTERN_SLOTS);
    const count = r.i32();
    for(let i = 0; i < count && !r.eof; i++){
        const idx = r.i32();
        const hdrA = s16(r.i32());
        const hdrB = s16(r.i32());
        const frameCount = r.i32() & 0xff;
        const frames = [];
        const hits = [];
        for(let f = 0; f < frameCount; f++){
            frames.push(readFrame(r, 3));
            hits.push(readHitFrame(r));
        }
        if (idx >= 0 && idx < CHARACTER_PATTERN_SLOTS) patterns[idx] = {
            count: frameCount,
            frames,
            hdrA,
            hdrB,
            hits
        };
    }
    return patterns;
}
export function parseEffectPat(data) {
    const r = new Reader(data);
    const patterns = [];
    const count = r.i32();
    for(let i = 0; i < count && !r.eof; i++){
        r.i32();
        r.i32();
        r.i32();
        const frameCount = r.i32() & 0xff;
        const frames = [];
        for(let f = 0; f < frameCount; f++){
            frames.push(readFrame(r, 1));
            for(let k = 0; k < 14; k++)r.i32();
            r.pos += 16 * 10;
        }
        patterns.push({
            count: frameCount,
            frames,
            hdrA: 0,
            hdrB: 0,
            hits: []
        });
    }
    return patterns;
}
export { emptyBox };
