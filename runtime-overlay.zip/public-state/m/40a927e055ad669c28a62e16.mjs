import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./d80c43470aa1f91788a9cb77.mjs";
import { updateChildrenNagamori } from "./8b7e65180486b4c98515924a.mjs";
import { parseCommandNagamori, dispatchMovesNagamori, tickHookNagamori } from "./25ad0caa669975b54f5d368e.mjs";
import { thinkNagamori } from "./b20445a7e91a0f54ad1301bb.mjs";
import { renderOverlayNagamori } from "./9f3e265651d7bf3314bab6c8.mjs";
import "./529ce4ec415989e29bb61281.mjs";
import "./5e570020b4762a178d72329a.mjs";
import "./a06b3d69d39b2dbf8aa72c1b.mjs";
const POINTS_X = [
    -2,
    21,
    12,
    22,
    25
];
const POINTS_Y = [
    -61,
    0,
    -5,
    -18,
    -23
];
export class Nagamori extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    f3154 = 0;
    f3158 = 0;
    f315c = 0;
    f3160 = 0;
    f3164 = 0;
    f3168 = 0;
    a316c = new Uint8Array(64);
    a31ac = new Int32Array(64);
    a32ac = new Int32Array(64);
    a33ac = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        0,
        5,
        10,
        1,
        0xff,
        0xff,
        0xff
    ];
    wF2 = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = this.f313c = this.f3140 = 0;
        this.f3148 = this.f3144 = this.f314c = this.f3150 = 0;
        this.f3158 = this.f3160 = this.f315c = this.f3164 = this.f3168 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a316c.fill(0);
        this.a31ac.fill(0);
        this.a32ac.fill(0);
        this.a33ac.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a316c[i] = 0;
        this.a31ac[i] = 0;
        this.a32ac[i] = 0;
        this.a33ac[i] = 0;
        super.freeChild(i);
    }
    markChildrenNear(x, y, rx, ry) {
        let i = this.childTail;
        while(i !== this.childHead){
            if (this.childActive[i] !== 0) {
                const ch = this.children[i];
                if (rx > Math.abs(x - ch.x)) {
                    if (ry > Math.abs(y - ch.y)) {
                        this.a316c[i] = 1;
                    }
                }
            }
            i++;
            if (i >= 64) i = 0;
        }
    }
    renderOverlay() {
        renderOverlayNagamori(this);
    }
    tickHook() {
        tickHookNagamori(this);
    }
    parseCommand() {
        parseCommandNagamori(this);
    }
    dispatchMoves() {
        dispatchMovesNagamori(this);
    }
    think() {
        thinkNagamori(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenNagamori(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
