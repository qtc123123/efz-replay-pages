import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./6a48da560917c25ba78d9332.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./a955fd4a77ee18da4a262fee.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function spawn309(c, d, pat, facing) {
    d.w04 = pat;
    d.x = ftol(c.x) + c.facing * 0x3c;
    d.y = ftol(c.y) - 0x50;
    d.b20 = 0;
    d.d00 = 1;
    d.b21 = 1;
    d.b18 = facing;
    frameChild(c, d);
}
function state309(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame < 0x10 && c.frame > 0xa) c.showAltBackground(0xf);
    if (c.frame > 1) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy >= 0.0 && c.frame > 0xe) {
            c.y = 0.0;
            c.stopMotion();
            c.onStateChange();
            c.state = 0;
            return;
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 2) {
        c.vx = 0.5;
        c.vy = -1.7;
        c.ay = 0.015;
    }
    if (c.frame === 0xa && c.timer === 0) {
        c.f3138 = ftol(c.vy * 100.0);
        c.f313c = ftol(c.vx * 100.0);
        c.stopMotion();
        c.seRequest = 0x25;
        c.freeze = 0x78;
        c.meter = s16(c.meter - 0xbb8);
        c.superDarken(0xb0, 3);
        d.w04 = 0x46;
        d.b2c = 0x40;
        d.x = ftol(c.x) + c.facing * 5;
        d.y = ftol(c.y) - 0x38;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        c.w16c = 0x13;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (c.frame === 0xc && c.timer === 0) {
        c.vx = c.f313c * 0.01;
        c.vy = c.f3138 * 0.01;
        c.ay = 0.015;
    }
    if (c.frame === 0xe) {
        d.d28 = 1;
        spawn309(c, d, 0x19c, c.facing);
        spawn309(c, d, 0x19d, c.facing);
        spawn309(c, d, 0x19e, c.facing);
        spawn309(c, d, 0x19f, c.facing);
        spawn309(c, d, 0x1a1, c.facing);
        spawn309(c, d, 0x1a2, c.facing);
        spawn309(c, d, c.facing === -1 ? 0x1a4 : 0x1a3, 1);
        spawn309(c, d, 0x1a5, 1);
        spawn309(c, d, 0x1a7, c.facing);
        spawn309(c, d, 0x1a9, c.facing);
    }
    c.d168 = 0;
    if (c.frame >= cnt) c.frame -= 2;
}
function state310(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.ay = 0.0;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 2 && c.f3138 < 8) {
        c.f3138++;
        c.frame -= 2;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
registerStates({
    309: state309,
    310: state310
});
function childTick(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
const DEG = 57.29579143313326;
function setPolarVelocity(c, i, angle, speed) {
    const ch = c.children[i];
    ch.vx = __numerics.cos(angle / DEG) * speed;
    ch.vy = __numerics.sin(angle / DEG) * speed;
}
const HEAD_BASE = {
    vxMode: 0,
    clearHits: false,
    clearArrays: false,
    spawn431: 0,
    bounceVx: false,
    fixedFrames: false,
    bounceLate: false,
    hitVx: 1.0
};
function wallBounce(c, i, negateVx) {
    const ch = c.children[i];
    if (ch.x > 600.0 && ch.facing * ch.vx > 0.0) {
        if (negateVx) ch.vx = -ch.vx;
        else ch.facing = -ch.facing;
    }
    if (ch.x < 40.0 && ch.facing * ch.vx < 0.0) {
        if (negateVx) ch.vx = -ch.vx;
        else ch.facing = -ch.facing;
    }
}
function critterHead(c, i, p) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        const r = c.random(0, 0x14);
        let vx = r * 0.1;
        if (p.vxMode === 2) vx = vx * c.facing;
        vx = vx + 0.25;
        if (p.vxMode === 1) vx = -vx;
        ch.vx = vx;
        ch.vy = -0.5 - c.random(0, 0xa) * 0.05;
        c.a3158[i] = 0;
        if (p.clearArrays) {
            c.a3258[i] = 0;
            c.a3358[i] = 0;
        }
        if (p.clearHits) ch.hitsLeft = 0;
    }
    if (p.spawn431 !== 0 && ch.frame === 0xb && ch.timer === 0) {
        const d = childSpawnFrame;
        d.w04 = 0x1af;
        d.x = p.spawn431 === 1 ? ch.facing * 4 + ch.x : ch.x - ch.facing * 4;
        d.y = ch.y - 38.0;
        d.d00 = 1;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = p.spawn431 === 1 ? ch.facing : -ch.facing;
        frameChild(c, d);
    }
    if (ch.frame < 5) {
        ch.vy = ch.vy + 0.025;
        wallBounce(c, i, p.bounceVx);
        if (ch.y + ch.vy >= 0.0) {
            ch.vx = 0.0;
            ch.vy = 0.0;
            ch.y = 0.0;
            ch.timer = 0;
            ch.frame = p.fixedFrames ? 5 : c.random(0, 3) + 5;
        }
    }
    if (p.bounceLate && (ch.frame === 0xb || ch.frame === 0xc)) wallBounce(c, i, false);
    if (ch.hitState === 5) {
        ch.frame = p.fixedFrames ? 1 : c.random(0, 3) + 1;
        ch.timer = 0;
        ch.vx = ch.facing * p.hitVx * c.opponent.facing;
        ch.vy = -1.0;
        ch.hitState = 0;
        return false;
    }
    return true;
}
function critterAdvance(c, i) {
    if (!childTick(c, i)) return false;
    const ch = c.children[i];
    if (ch.frame === 5) ch.frame = 1;
    return true;
}
function critterSparkle(c, i, last) {
    const ch = c.children[i];
    if (ch.frame < 6 || ch.frame > last) return;
    const d = childSpawnFrame;
    d.w04 = 0x1b1 + (ch.frame - 6);
    d.x = ch.x;
    d.y = ch.y - 50.0;
    d.b20 = 0;
    d.b21 = 1;
    d.b18 = 1;
    frameChild(c, d);
}
function critterEnd(c, i) {
    const ch = c.children[i];
    if (ch.frame === childCount - 1) ch.blend = 1;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child412(c, i, voice) {
    const ch = c.children[i];
    if (!critterHead(c, i, HEAD_BASE)) return;
    if (!critterAdvance(c, i)) return;
    critterSparkle(c, i, 0xa);
    if (ch.frame === 0xb) c.voiceRequest = voice;
    if (ch.frame === 0xd && c.a3158[i] < 0x14) {
        ch.frame = 0xb;
        c.a3158[i]++;
    }
    if (ch.frame === 0xb) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
    }
    critterEnd(c, i);
}
function child415(c, i) {
    const ch = c.children[i];
    if (!critterHead(c, i, {
        ...HEAD_BASE,
        clearArrays: true,
        fixedFrames: true
    })) return;
    if (ch.frame === 5 && ch.timer === 0) {
        if (c.a3358[i] === 6) {
            c.a3258[i] = 0;
            c.a3358[i] = 0;
            ch.frame = 7;
            ch.timer = 0;
            const d = childSpawnFrame;
            d.w04 = 0x1ab;
            d.x = ch.x;
            d.y = ch.y - 25.0;
            d.b20 = 2;
            d.b21 = 1;
            d.d00 = 1;
            d.b18 = ch.facing;
            for(let k = 0; k < 9; k++)frameChild(c, d);
            d.w04 = 0x1ad;
            for(let k = 0; k < 3; k++)frameChild(c, d);
            ch.hitsLeft = 1;
            ch.hitState = 0;
            c.seRequest = 0x16;
            c.shakeScreen(5, 5);
            return;
        }
        if (c.a3258[i] === 0xf) {
            if (c.a3358[i] < 5) {
                const d = childSpawnFrame;
                d.w04 = c.a3358[i] + 0x1b1;
                d.x = ch.x;
                d.y = ch.y - 50.0;
                d.b20 = 0;
                d.b21 = 1;
                d.b18 = 1;
                frameChild(c, d);
            }
            c.a3358[i]++;
            c.a3258[i] = 0;
        }
    }
    if (!critterAdvance(c, i)) return;
    if (ch.frame === 7) {
        ch.frame = 5;
        c.a3258[i]++;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child417(c, i) {
    const ch = c.children[i];
    if (!critterHead(c, i, {
        ...HEAD_BASE,
        bounceLate: true
    })) return;
    if (!critterAdvance(c, i)) return;
    critterSparkle(c, i, 0xa);
    if (ch.frame === 0xb) {
        c.voiceRequest = 0xc;
        ch.vx = 2.0;
    }
    if (ch.frame === 0xd && c.a3158[i] < 0x14) {
        ch.frame = 0xb;
        c.a3158[i]++;
    }
    if (ch.frame === 0xb) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
    }
    if (ch.frame === 0xd) ch.vx = 0.0;
    critterEnd(c, i);
}
function spawn430(c, i) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    d.w04 = 0x1ae;
    d.x = ch.x;
    d.y = 0.0;
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = ch.facing;
    frameChild(c, d);
}
function child418(c, i) {
    const ch = c.children[i];
    if (!critterHead(c, i, {
        ...HEAD_BASE,
        clearHits: true
    })) return;
    if (!critterAdvance(c, i)) return;
    critterSparkle(c, i, 0xa);
    if (ch.frame === 0xf) {
        c.voiceRequest = 0x10;
        spawn430(c, i);
    }
    if (ch.frame === 0x10 && c.a3158[i] < 0xa) {
        ch.frame = 0xf;
        ch.hitsLeft = 1;
        ch.hitState = 0;
        c.a3158[i]++;
        spawn430(c, i);
    }
    critterEnd(c, i);
}
function child419(c, i, left) {
    const ch = c.children[i];
    const p = left ? {
        ...HEAD_BASE,
        vxMode: 1,
        spawn431: -1,
        bounceVx: true,
        hitVx: -1.0
    } : {
        ...HEAD_BASE,
        spawn431: 1,
        bounceVx: true
    };
    if (!critterHead(c, i, p)) return;
    if (!critterAdvance(c, i)) return;
    critterSparkle(c, i, 0xa);
    if (ch.frame === 0xb) c.voiceRequest = 0xf;
    if (ch.frame === 0xd && c.a3158[i] < 0x14) {
        ch.frame = 0xb;
        c.a3158[i]++;
    }
    if (ch.frame === 0xb) {
        ch.hitsLeft = 0;
        ch.hitState = 0;
    }
    critterEnd(c, i);
}
function child421(c, i) {
    const ch = c.children[i];
    if (!critterHead(c, i, {
        ...HEAD_BASE,
        vxMode: 2,
        clearHits: true,
        bounceVx: true
    })) return;
    if (!critterAdvance(c, i)) return;
    critterSparkle(c, i, 0xa);
    if (ch.frame === 0xb) {
        c.voiceRequest = 0xe;
        const d = childSpawnFrame;
        d.w04 = 0x1a6;
        d.x = ch.x;
        d.y = 0.0;
        d.d00 = 1;
        d.b20 = 0;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
    }
    critterEnd(c, i);
}
function child423(c, i) {
    const ch = c.children[i];
    if (!critterHead(c, i, HEAD_BASE)) return;
    if (!critterAdvance(c, i)) return;
    critterSparkle(c, i, 9);
    if (ch.frame === 0x10) {
        const d = childSpawnFrame;
        d.w04 = 0x1a8;
        d.d00 = 1;
        d.x = ch.facing * 5 + ch.x;
        d.y = ch.y - 10.0;
        d.b20 = 0;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
        c.voiceRequest = 0x12;
    }
    if (ch.frame === 0x10 && c.a3158[i] < 8) {
        ch.frame = 0xf;
        c.a3158[i]++;
    }
    critterEnd(c, i);
}
function child425(c, i) {
    const ch = c.children[i];
    if (!critterHead(c, i, HEAD_BASE)) return;
    if (!critterAdvance(c, i)) return;
    critterSparkle(c, i, 0xa);
    if (ch.frame === 0x10 && c.a3158[i] < 0xf) {
        ch.frame = 0xc;
        c.a3158[i]++;
    }
    if (ch.frame === 0xc) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
        c.voiceRequest = 0x11;
    }
    critterEnd(c, i);
}
function child422(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vy = -0.5;
        c.a3158[i] = 0;
        c.a3258[i] = 0;
        ch.hitState = 0;
        ch.hitsLeft = 1;
    }
    c.a3158[i]++;
    if (c.a3158[i] === 2) {
        const d = childSpawnFrame;
        d.w04 = 0x1ac;
        d.x = ch.x;
        d.y = ch.y - 10.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
        c.a3158[i] = 0;
    }
    if (!childTick(c, i)) return;
    ch.hitState = 0;
    ch.hitsLeft = 1;
    if (ch.frame < childCount) return;
    if (c.a3258[i] < 0xa) {
        c.a3258[i]++;
        ch.frame -= 4;
        return;
    }
    const d = childSpawnFrame;
    d.w04 = 0x1ab;
    d.x = ch.x;
    d.y = ch.y - 25.0;
    d.b20 = 2;
    d.b21 = 1;
    d.d00 = 1;
    d.b18 = ch.facing;
    for(let k = 0; k < 9; k++)frameChild(c, d);
    d.w04 = 0x1ad;
    for(let k = 0; k < 3; k++)frameChild(c, d);
    c.seRequest = 0x16;
    c.shakeScreen(5, 5);
    c.freeChild(i);
}
function child424(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
        ch.vx = 0.5;
        ch.vy = -1.0;
        c.a3158[i]++;
    }
    if (ch.y < 0.0) ch.vy = ch.vy + 0.025;
    if (ch.y >= 0.0) {
        if (ch.frame < 2) ch.frame += 2;
        ch.y = 0.0;
        ch.vx = 1.0;
        ch.vy = 0.0;
    }
    if (ch.x > 650.0 || ch.x < -10.0) {
        c.freeChild(i);
        return;
    }
    if (!childTick(c, i)) return;
    ch.hitState = 0;
    if (ch.frame === 2) ch.frame -= 2;
    if (ch.frame >= childCount) ch.frame -= 2;
}
function childShard(c, i, speedRange, decay, speedMin) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        c.a3158[i] = c.random(0, 0x168);
        c.a3258[i] = c.random(0, speedRange);
    }
    c.a3258[i] = c.a3258[i] - decay;
    if (c.a3258[i] < speedMin) c.a3258[i] = speedMin;
    setPolarVelocity(c, i, c.a3158[i], c.a3258[i] * 0.1);
    if (childTick(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function child429(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = c.random(0, 0xa0) * 0.1 + -8.0;
        ch.vy = -8.0;
    }
    if (!childTick(c, i)) return;
    if (ch.frame < childCount) return;
    if (c.a3158[i] < 0x10) {
        c.a3158[i]++;
        ch.frame -= 1;
        const d = childSpawnFrame;
        d.w04 = 0x1ac;
        d.x = ch.x;
        d.y = ch.y;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
        return;
    }
    c.freeChild(i);
}
function child430(c, i) {
    const ch = c.children[i];
    ch.vx = 0.0;
    ch.vy = 0.0;
    if (!childTick(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child431(c, i) {
    const ch = c.children[i];
    ch.vx = 2.0;
    ch.vy = 0.0;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
    }
    if (!childTick(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childRise(c, i) {
    const ch = c.children[i];
    ch.vx = 0.0;
    ch.vy = -0.15;
    if (!childTick(c, i)) return;
    ch.hitState = 0;
    if (ch.frame === 1) ch.blend = 1;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    412: (c, i)=>child412(c, i, 9),
    413: (c, i)=>child412(c, i, 0xa),
    414: (c, i)=>child412(c, i, 0xb),
    415: child415,
    417: child417,
    418: child418,
    419: (c, i)=>child419(c, i, false),
    420: (c, i)=>child419(c, i, true),
    421: child421,
    422: child422,
    423: child423,
    424: child424,
    425: child425,
    427: (c, i)=>childShard(c, i, 0x64, 3, 0xa),
    428: (c, i)=>childShard(c, i, 0x1e, 4, 5),
    429: child429,
    430: child430,
    431: child431,
    433: childRise,
    434: childRise,
    435: childRise,
    436: childRise,
    437: childRise
});

export function __logicState(){return {HEAD_BASE};}

export function __installInitialRoots(s){
if(HEAD_BASE!==s["HEAD_BASE"])throw Error('INITIAL_CONST_IDENTITY:HEAD_BASE');
}
