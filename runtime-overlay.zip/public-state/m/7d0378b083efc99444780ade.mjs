import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { parseCharacterPat } from "./fc9672cb87477a10c4e4290f.mjs";
import { readSync } from "./197efe2647ca25903d217eb5.mjs";
import { defaultStateHandler, defaultStateHandler2, stateHandlers, stateHandlers2 } from "./00697db762b413ef9f6a1cba.mjs";
import { updateChildrenNanase } from "./0a57f8c3d343150e3ded7bb7.mjs";
import { parseCommandNanase, dispatchMovesNanase } from "./bc6169df82e92da812317275.mjs";
import { thinkNanase } from "./13ddc62b5bcc0f7c50a1ac7d.mjs";
import { renderOverlayNanase } from "./2c3ade4867bab20618409c36.mjs";
import "./67412c85ef67a034a8fd9978.mjs";
import "./0566a4c6b178febfb8486d5b.mjs";
import "./4446530bf5d3c63bd57f5d56.mjs";
const PAT2_PATH = "nanase\\nanase2.pat";
const POINTS_X = [
    -12,
    18,
    16,
    21,
    33
];
const POINTS_Y = [
    -58,
    0,
    -9,
    -14,
    -26
];
export class Nanase extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    a314c = new Int32Array(64);
    a324c = new Int32Array(64);
    a334c = new Int32Array(64);
    f344c = 0;
    f3450 = 0;
    f3454 = 0;
    form = 0;
    patterns2 = [];
    savedPatterns = [];
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        6,
        2,
        5,
        12,
        0xff,
        0xff,
        0xff
    ];
    wF2 = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    files() {
        return [
            ...super.files(),
            PAT2_PATH
        ];
    }
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = this.f313c = this.f3140 = this.f3144 = this.f3148 = 0;
        this.f344c = this.f3450 = this.f3454 = 0;
        this.setForm(0);
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a314c.fill(0);
        this.a324c.fill(0);
        this.a334c.fill(0);
        super.resetRound();
    }
    load() {
        this.loadPatterns2();
        super.load();
        this.savedPatterns = this.patterns;
    }
    loadPatterns2() {
        const data = readSync(PAT2_PATH);
        this.patterns2 = data ? parseCharacterPat(data) : [];
    }
    setForm(mode) {
        if (mode === 1 && this.form === 0) {
            this.patterns = this.patterns2;
            this.form = 1;
        } else if (mode === 0 && this.form === 1) {
            this.patterns = this.savedPatterns;
            this.form = 0;
        }
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a314c[i] = 0;
        this.a324c[i] = 0;
        this.a334c[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayNanase(this);
    }
    tickHook() {}
    parseCommand() {
        parseCommandNanase(this);
    }
    dispatchMoves() {
        dispatchMovesNanase(this);
    }
    think() {
        thinkNanase(this);
    }
    updateState() {
        if (this.form === 1) {
            this.updateState2();
            return;
        }
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateState2() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers2.get(this.state) ?? defaultStateHandler2;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenNanase(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
