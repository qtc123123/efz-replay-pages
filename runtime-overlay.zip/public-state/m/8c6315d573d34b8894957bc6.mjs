import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { parseCharacterPat } from "./fc9672cb87477a10c4e4290f.mjs";
import { readSync } from "./197efe2647ca25903d217eb5.mjs";
import { defaultStateHandler, defaultStateHandler2, stateHandlers, stateHandlers2 } from "./81433295782a220b1d5e4d42.mjs";
import { parseCommandIkumi, dispatchMovesIkumi, renderOverlayIkumi } from "./76021c47869134529b38183a.mjs";
import { thinkIkumi, tickHookIkumi } from "./d5274daf6fcfc2b1f9cb46dc.mjs";
import { updateChildrenIkumi } from "./2ed079700202e720d67705c7.mjs";
import "./b8e116d817acc53678cf99b1.mjs";
import "./27da61974853c054a1ed49f8.mjs";
import "./37aeece2bef86e80cdf752c2.mjs";
const PAT2_PATH = "ikumi\\ikumi2.pat";
const CTOR_POINTS_X = [
    -22,
    -25,
    -25,
    5,
    32
];
const CTOR_POINTS_Y = [
    -50,
    0,
    -10,
    -9,
    -27
];
const RESET_POINTS_X = [
    -4,
    -25,
    21,
    18,
    38
];
const RESET_POINTS_Y = [
    -57,
    0,
    -12,
    -15,
    -39
];
export class Ikumi extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    f3154 = 0;
    f3158 = 0;
    f315c = 0;
    a3160 = new Int32Array(64);
    a3260 = new Int32Array(64);
    a3360 = new Int32Array(64);
    form = 0;
    patterns2 = [];
    savedPatterns = [];
    pointsX = [
        ...CTOR_POINTS_X
    ];
    pointsY = [
        ...CTOR_POINTS_Y
    ];
    params = [
        7,
        8,
        0xd,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    files() {
        return [
            ...super.files(),
            PAT2_PATH
        ];
    }
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3154 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.setForm(0);
        this.form = 0;
        this.f3138 = this.f313c = this.f3140 = this.f3144 = this.f3148 = 0;
        this.f314c = this.f3150 = this.f3154 = this.f3158 = this.f315c = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = RESET_POINTS_X[i];
            this.pointsY[i] = RESET_POINTS_Y[i];
        }
        this.a3160.fill(0);
        this.a3260.fill(0);
        this.a3360.fill(0);
        super.resetRound();
    }
    load() {
        this.loadPatterns2();
        super.load();
        this.savedPatterns = this.patterns;
    }
    loadPatterns2() {
        const data = readSync(PAT2_PATH);
        this.patterns2 = data ? parseCharacterPat(data) : [];
    }
    setForm(mode) {
        if (mode === 1 && this.form === 0) {
            this.patterns = this.patterns2;
            this.form = 1;
        } else if (mode === 0 && this.form === 1) {
            this.patterns = this.savedPatterns;
            this.form = 0;
        }
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3160[i] = 0;
        this.a3260[i] = 0;
        this.a3360[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayIkumi(this);
    }
    tickHook() {
        tickHookIkumi(this);
    }
    parseCommand() {
        parseCommandIkumi(this);
    }
    dispatchMoves() {
        dispatchMovesIkumi(this);
    }
    think() {
        thinkIkumi(this);
    }
    updateState() {
        if (this.form === 1) {
            this.updateState2();
            return;
        }
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateState2() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers2.get(this.state) ?? defaultStateHandler2;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenIkumi(this);
    }
}

export function __logicState(){return {CTOR_POINTS_X,CTOR_POINTS_Y,RESET_POINTS_X,RESET_POINTS_Y};}

export function __installInitialRoots(s){
if(CTOR_POINTS_X!==s["CTOR_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_X');
if(CTOR_POINTS_Y!==s["CTOR_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_Y');
if(RESET_POINTS_X!==s["RESET_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_X');
if(RESET_POINTS_Y!==s["RESET_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_Y');
}
