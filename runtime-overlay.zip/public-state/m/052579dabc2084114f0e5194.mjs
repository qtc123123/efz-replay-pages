import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
function chance2(c) {
    const r = rnd(c, 0, 100);
    return c.aiLevel + c.aiLevel > r;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = rnd(c, 0, 2) - 1;
}
function jumpForward(c) {
    c.inputY = -1;
    c.inputX = c.facing;
    if (rnd(c, 0, 3) === 0) c.aiMode = 18;
}
function dashCommand(c) {
    return c.facing === 1 ? 1 : 0;
}
function backDashCommand(c) {
    return c.facing === -1 ? 1 : 0;
}
function comboChain(c) {
    c.aiMode = 1;
    if (rnd(c, 0, 1) !== 0) return false;
    c.aiMode = 6;
    if (rnd(c, 0, 100) < 20) c.aiMode = 8;
    if (rnd(c, 0, 100) < 40) c.aiMode = 14;
    return true;
}
function comboChainShort(c) {
    c.aiMode = 1;
    if (rnd(c, 0, 1) === 0) c.aiMode = 6;
}
export function thinkMio(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25.0 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 170 ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 149 && c.state < 157 ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40.0 * c.aiLevel > r && c.state > 199) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 200) c.aiMode = 0;
        return;
    }
    if (o.state === 96) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 50 && c.state <= 150 && c.timer === 0) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 50 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 240) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 320) < dx ? 1 : 0;
        if (o.state > 199 && o.state < 250 && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 10 && c.state <= 12) && c.y === 0.0) return;
    if (o.state >= 50 && o.state < 150 && c.state === 264 && c.w16c > 1) return;
    if (c.state === 168 && c.timer < 6) {
        if (o.state !== 200 && o.state !== 204 && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx < 40.0 && chance(c, 3.0) && c.f3150 === 0) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && chance(c, 3.0) && c.f3150 === 0) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
        }
        if ((o.state === 201 || o.state === 202 || o.state === 205) && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx > 40.0 && dx < 80.0 && chance(c, 3.0) && c.f3150 === 0) {
                c.pressed[1] = 1;
                c.inputY = 1;
                c.inputX = 0;
                return;
            }
            if (dx > 60.0 && dx < 120.0 && chance(c, 3.0) && c.f3150 === 0) {
                c.pressed[0] = 3;
                c.inputY = 1;
                return;
            }
        }
    }
    if (c.state === 168 || c.state === 169) {
        if (dx < 100.0) {
            if (dx < 60.0 && chance(c, 1.0) && c.f3150 === 1 && c.meter === 3000) {
                c.command = 94;
                return;
            }
            if (dx < 80.0 && chance(c, 3.0) && c.f3150 === 1 && c.meter >= 2000) {
                c.command = rnd(c, 0, 2) + 101;
                return;
            }
            if (chance(c, 3.0) && c.rfGauge > 500.0 && c.f3150 === 0) {
                c.command = 12;
                return;
            }
            if (chance(c, 1.0) && c.rfGauge > 500.0 && c.f3150 === 1) {
                c.command = 42;
                return;
            }
            if (chance(c, 3.0) && c.rfGauge > 500.0 && c.f3150 === 0) {
                c.command = 32;
                return;
            }
        }
        if (dx < 160.0 && chance(c, 3.0) && c.rfGauge > 500.0) {
            c.command = 12;
            return;
        }
        if (dx < 80.0 && dx > 160.0) {
            if (chance(c, 1.0) && c.f3150 === 0 && c.rfGauge > 500.0) {
                c.command = 12;
                return;
            }
            if (chance(c, 1.0) && c.f3150 === 1) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (chance2(c) && c.f3150 === 1 && c.rfGauge > 500.0) {
                c.command = 42;
                return;
            }
        }
        if (dx > 160.0 && chance(c, 1.0) && c.f3150 === 1) {
            c.command = 10;
            return;
        }
    }
    if (c.state === 170 && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5.0)) {
            c.aiMode = 3;
            return;
        }
        if (dy < 50.0 && c.y > o.y && dx < 80.0 && chance(c, 5.0)) {
            c.pressed[0] = 1;
            return;
        }
        if (c.y - o.y > -30.0 && c.y - o.y < 0.0 && dx < 100.0 && chance(c, 5.0)) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y > -50.0 && c.y - o.y < 50.0 && dy < 60.0 && dx < 120.0 && chance(c, 5.0)) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return;
        }
        if (dy < 50.0 && dx < 100.0 && chance2(c)) {
            c.command = 22;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y === 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0 && c.f3150 === 0) {
            c.command = 12;
            return;
        }
        if (c.aiRoll < 7 && c.rfGauge > 500.0 && c.f3150 === 0) {
            c.command = rnd(c, 0, 2) + 20;
            return;
        }
        if (c.aiRoll < 10 && c.rfGauge > 500.0 && c.f3150 === 1) {
            c.command = 72;
            return;
        }
        if (c.aiRoll < 13 && c.rfGauge > 500.0) {
            c.command = 22;
            return;
        }
        if (c.aiRoll < 17 && c.aiRoll > 12 && c.meter >= 2000) {
            c.command = rnd(c, 0, 1) + 101;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y < 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < (c.f3150 === 1 ? 1 : 0) * 20 + 20) {
            c.aiMode = 2;
            return;
        }
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 8.0 * c.aiLevel > rnd(c, 0, 100) && o.state > 149 && o.state < 157 && (c.state === 223 || c.state === 250 || c.state === 251 || c.state === 252 || c.state === 270 || c.state === 271 || c.state === 272)) {
        c.command = 52;
        return;
    }
    if (c.aiMode > 0 && c.state > 49 && c.state < 158) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 200) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = rnd(c, 0, 2) - 1;
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = dashCommand(c);
            if (c.state === 165) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.state === 254 && c.d168 > 0 && 24.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.command = 10;
        return;
    }
    if (c.aiMode === 5 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 7;
        return;
    }
    if (c.aiMode === 7 && c.state === 163) {
        c.pressed[0] = 1;
        if (c.state === 230) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 8 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 9;
        return;
    }
    if (c.aiMode === 9 && c.state === 163) {
        c.pressed[1] = 1;
        if (c.state === 231) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 10 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 11;
        return;
    }
    if (c.aiMode === 11 && c.state === 163) {
        c.pressed[2] = 1;
        if (c.state === 232) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 12 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 13;
        return;
    }
    if (c.aiMode === 13 && c.state === 163) {
        c.pressed[0] = 1;
        c.inputY = 1;
        if (c.state === 230) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 14 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 15;
        return;
    }
    if (c.aiMode === 15 && c.state === 163) {
        c.pressed[1] = 1;
        c.inputY = 1;
        if (c.state === 231) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 16 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 17;
        return;
    }
    if (c.aiMode === 17 && c.state === 163) {
        c.pressed[2] = 1;
        c.inputY = 1;
        if (c.state === 232) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 18 && c.f3150 === 0) {
        c.inputX = c.facing;
        c.inputY = -1;
        if (c.y < 0.0) {
            c.pressed[2] = 1;
            c.inputY = 1;
            if (c.state === 223) c.aiMode = 0;
        }
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && c.aiLevel * 25.0 > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (comboMio(c, dx)) return;
    }
    if (25.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.y === 0.0) {
            if (groundActions(c, dx, dy)) return;
        }
        if (airActions(c, dx, dy)) return;
    }
    if (c.state < 50 && (o.state > 149 && o.state < 156 || o.state > 49 && o.state < 59) && c.y === 0.0) {
        const r = rnd(c, 0, 100);
        if ((c.f3150 === 0 ? 1 : 0) * 3 * c.aiLevel + 1.0 > r) {
            c.command = dashCommand(c);
            return;
        }
    }
    if (c.state < 50 && (o.state > 149 && o.state < 156 || o.state > 49 && o.state < 59 || o.state < 50) && c.y === 0.0 && dx < 90.0) {
        const r = rnd(c, 0, 100);
        if ((c.f3150 === 1 ? 1 : 0) * 4 * c.aiLevel > r) {
            c.command = backDashCommand(c);
            return;
        }
    }
    if (rnd(c, 0, 1000) < (c.f3150 === 0 ? 1 : 0) + 1) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 160.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 100.0 && c.y === 0.0 && rnd(c, 0, 100) < 1 && o.state < 50) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 170.0 && dx > 120.0 && c.y === 0.0) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 15) c.aiTimer1a0 = 15;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 15) c.aiTimer1a4 = 15;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < (c.f3150 === 1 ? 1 : 0) * 30 + 40 && dx < 110.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 200) + 30;
        else c.aiTimer1a0 = rnd(c, 0, 200) + 30;
    }
    if (rnd(c, 0, 100) < (c.f3150 === 0 ? 1 : 0) * 30 + 40) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 200) + 30;
        else c.aiTimer1a4 = rnd(c, 0, 200) + 30;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 200) + 30;
    else c.aiTimer1a4 = rnd(c, 0, 200) + 30;
}
function groundActions(c, dx, dy) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (o.y === 0.0 && o.state !== 99 && c.f3150 === 0) {
        if (dx < 40.0 && o.y === 0.0 && roll < 5) {
            c.pressed[2] = 1;
            c.inputX = -c.facing;
            c.inputY = 0;
            return true;
        }
        if (dx < 45.0 && roll < 25) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 60.0 && roll < 35) {
            c.pressed[0] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 80.0 && dx > 40.0 && roll < 60 && roll > 35) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 100.0 && roll < 80 && roll > 60) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 90.0 && dx > 50.0 && roll > 80 && roll < 87) {
            c.aiMode = 6;
            return true;
        }
        if (dx < 110.0 && dx > 70.0 && roll > 87 && roll < 95) {
            c.aiMode = 8;
            if (rnd(c, 0, 30) < 15) c.aiMode = 14;
            return true;
        }
        if (dx > 120.0 && dx < 190.0 && roll > 95 && roll < 98) {
            c.aiMode = 16;
            return true;
        }
        if (dx > 80.0 && dx < 120.0 && roll > 100 && roll < 103) {
            c.aiMode = 10;
            return true;
        }
        if (dx < 80.0 && roll < 120 && roll > 105) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 60.0 && roll < 125 && roll > 120 && o.state > 199 && c.rfGauge > 500.0) {
            c.command = 22;
            return true;
        }
        if (dx < 80.0 && roll < 130 && roll > 125 && o.state > 199 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 100;
            return true;
        }
        if (roll < 135 && roll > 130) {
            c.command = c.facing & 0xffff;
            c.aiMode = 5;
            return true;
        }
    }
    if (o.y === 0.0 && o.state !== 99 && c.f3150 === 1) {
        if (dx < 40.0 && o.y === 0.0 && roll < 5) {
            c.pressed[2] = 1;
            c.inputX = -c.facing;
            c.inputY = 0;
            return true;
        }
        if (dx < 55.0 && roll < 10) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 70.0 && roll < 15) {
            c.pressed[0] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 150.0 && dx > 80.0 && roll < 60 && roll > 35) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 180.0 && dx > 100.0 && roll < 80 && roll > 60 && o.inputY !== 1) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 100.0 && dx > 0.0 && roll < 95 && roll > 80) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 150.0 && dx > 120.0 && roll < 110 && roll > 95) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx > 80.0 && dx < 130.0 && roll > 110 && roll < 115) {
            c.aiMode = 16;
            return true;
        }
        if (dx > 100.0 && dx < 180.0 && roll > 115 && roll < 125) {
            c.aiMode = 10;
            return true;
        }
        if (dx < 60.0 && roll < 130 && roll > 125 && o.state > 199 && c.rfGauge > 500.0) {
            c.command = 42;
            return true;
        }
        if (dx < 80.0 && roll < 133 && roll > 130 && o.state > 199 && c.meter === 3000) {
            c.command = 94;
            return true;
        }
        if (dx > 100.0 && dx * 0.1 + 140.0 > roll && roll > 135) {
            c.command = rnd(c, 0, 3) + 10;
            return true;
        }
        if (dx > 120.0 && roll < 200 && roll > 193) {
            c.command = rnd(c, 0, 3) + 10;
            return true;
        }
        if (dx > 80.0 && roll < 208 && roll > 200) {
            c.command = rnd(c, 0, 3) + 40;
            return true;
        }
    }
    if (o.y < 0.0 && c.f3150 === 0) {
        if (o.vy < 0.0) {
            if (dx < 80.0 && dy < 120.0 && roll < 10) {
                c.inputY = -1;
                c.inputX = -c.facing;
                return true;
            }
        }
        if (o.vy > 0.0) {
            if (dx < 60.0 && dy < 120.0) {
                const g = c.rfGauge > 500.0 || c.rfBlue > 0 ? 1 : 0;
                if (roll < g * 5 + 6) {
                    c.command = (rnd(c, 0, 3) === 0 ? 1 : 0) * 2 + 20;
                    return true;
                }
            }
            if (dx < 60.0 && dy < 120.0 && dy > 80.0 && roll < 15) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return true;
            }
            if (dx < 80.0 && dy < 150.0 && dy > 100.0 && roll < 30) {
                c.inputY = -1;
                c.inputX = -c.facing;
                return true;
            }
        }
    }
    if (o.y < 0.0 && c.f3150 === 1) {
        if (o.vy < 0.0) {
            if (dx < 100.0 && dy < 120.0 && roll < 10) {
                c.inputY = -1;
                c.inputX = -c.facing;
                return true;
            }
            if (dx < 100.0 && dy < 120.0 && roll < 15 && c.x > 80.0 && c.x < 560.0) {
                c.command = backDashCommand(c);
                return true;
            }
        }
        if (o.vy > 0.0) {
            if (dx < 110.0 && dy < 210.0 && roll < 10) {
                c.command = rnd(c, 0, 3) + 110;
                return true;
            }
            if (dx < 100.0 && dy < 120.0 && roll < 4) {
                c.inputY = -1;
                c.inputX = -c.facing;
                return true;
            }
            if (dx < 100.0 && dx < 180.0 && dy < 140.0 && roll < 20) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return true;
            }
            if (dx < 100.0 && dy < 140.0 && dy > 80.0 && roll < 40) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return true;
            }
        }
    }
    return false;
}
function airActions(c, dx, dy) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (c.y < 0.0 && c.aiMode !== 3 && c.f3150 === 0) {
        if (o.y === 0.0) {
            if (dx < 60.0 && dy < 70.0 && roll < 100) {
                c.pressed[0] = 1;
                return true;
            }
            if (dx < 80.0 && dy > 50.0 && dy < 90.0 && roll > 200 && roll < 260) {
                c.pressed[1] = 1;
                return true;
            }
            if (dx < 70.0 && dy > 60.0 && dy < 110.0 && roll > 260 && roll < 285) {
                c.pressed[2] = 1;
                return true;
            }
            if (dy + 30.0 > dx && dy - 30.0 < dx && dy < 110.0 && roll > 300 && roll < 310) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return true;
            }
        }
        if (o.y < 0.0) {
            if (dx < 80.0 && dy < 80.0 && c.y > o.y && roll < 310) {
                c.pressed[0] = 1;
                return true;
            }
            if (dx < 90.0 && dy < 100.0 && c.y < o.y && roll > 310 && roll < 400) {
                c.pressed[1] = 1;
                return true;
            }
        }
    }
    if (c.y < 0.0 && c.aiMode !== 3 && c.f3150 === 1) {
        if (o.y === 0.0) {
            if (dx < 60.0 && dy < 70.0 && roll < 100) {
                c.pressed[0] = 1;
                return true;
            }
            if (dx < 160.0 && dx > 110.0 && dy > 20.0 && dy < 50.0 && roll > 200 && roll < 260) {
                c.pressed[1] = 1;
                return true;
            }
            if (dx < 90.0 && dy < 150.0 && roll > 260 && roll < (dy > 100.0 ? 1 : 0) * 40 + 290) {
                c.pressed[2] = 1;
                return true;
            }
            if (dx < 130.0 && dx > 80.0 && dy < 80.0 && roll > 380 && roll < 400) {
                c.command = rnd(c, 0, 3) + 40;
                return true;
            }
        }
        if (o.y < 0.0) {
            if (dx < 80.0 && dx > 60.0 && dy < 60.0 && c.y > o.y && roll < 210) {
                c.pressed[0] = 1;
                return true;
            }
            if (dx < 180.0 && dx > 100.0 && dy < 70.0 && c.y > o.y && roll < 310) {
                c.pressed[0] = 1;
                return true;
            }
            if (dx < 90.0 && dy > 100.0 && dy < 150.0 && c.y < o.y && roll > 310 && roll < 450) {
                c.pressed[1] = 1;
                return true;
            }
            if (dx < 140.0 && dx > 80.0 && dy < 80.0 && roll > 380 && roll < 400) {
                c.command = rnd(c, 0, 3) + 40;
                return true;
            }
        }
    }
    return false;
}
function comboMio(c, dx) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (c.state === 200) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (combo2A(c, dx, roll, 500, 550)) return true;
        if (roll > 550 && roll < 560) {
            c.aiMode = 12;
            return true;
        }
        if (roll > 980) {
            startJump(c);
            return true;
        }
        if (roll > 960) {
            jumpForward(c);
            return true;
        }
        if (roll > 699) {
            comboChainShort(c);
            return true;
        }
    }
    if (c.state === 201) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (o.y < 0.0 && roll > 299 && roll < 320) {
            c.pressed[3] = 1;
            c.inputY = 0;
            c.inputX = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 320 && roll < 420 && dx < 100.0) {
            jumpForward(c);
            return true;
        }
        if (roll < 100) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 100 && roll < 350 && dx < 80.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 350 && roll < 700) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 700 && roll < 750) {
            c.aiMode = 18;
            return true;
        }
        if (roll > 980) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            if (comboChain(c)) return true;
        }
    }
    if (c.state === 202) {
        if (o.y < 0.0 && roll > 299 && roll < 320) {
            c.pressed[3] = 1;
            c.inputY = 0;
            c.inputX = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 320 && roll < 700 && dx < 100.0) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll < 450 && dx < 110.0) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 549 && roll < 600) {
            const f = rnd(c, 0, 3) === 0 && c.rfGauge > 500.0 ? 1 : 0;
            c.command = f + f + 30;
            return true;
        }
        if (roll > 600 && roll < 700) {
            c.pressed[3] = 1;
            c.inputX = 0;
            c.inputY = 0;
            return true;
        }
        if (roll > 980) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            if (comboChain(c)) return true;
        }
    }
    if (c.state === 203) {
        if (o.y < 0.0 && roll > 299 && roll < 320) {
            c.pressed[3] = 1;
            return true;
        }
        if (comboCommand10(c, roll)) return true;
        if (roll > 200 && roll < 275) {
            const f = rnd(c, 0, 4) === 0 && c.rfGauge > 500.0 ? 1 : 0;
            c.command = f + f + 30;
            return true;
        }
        if (roll > 350 && roll < 400 && c.rfGauge > 450.0) {
            c.command = 52;
            return true;
        }
        if (roll > 400 && roll < 550) {
            c.pressed[3] = 1;
            return true;
        }
        if (roll > 649) {
            c.aiMode = 1;
            return true;
        }
    }
    if (c.state === 204) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (combo2A(c, dx, roll, 500, 550)) return true;
        if (roll > 550 && roll < 560) {
            c.aiMode = 12;
            return true;
        }
        if (roll > 700 && roll < 750) {
            c.aiMode = 18;
            return true;
        }
        if (roll > 980) {
            startJump(c);
            return true;
        }
        if (roll > 960) {
            jumpForward(c);
            return true;
        }
        if (roll > 699) {
            comboChainShort(c);
            return true;
        }
    }
    if (c.state === 205) {
        if (o.y < 0.0 && roll < 100 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (o.y < 0.0 && roll > 100 && roll < 120) {
            c.pressed[3] = 1;
            c.inputY = 0;
            c.inputX = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 120 && roll < 140 && dx < 100.0) {
            jumpForward(c);
            return true;
        }
        if (roll < 40) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 40 && roll < 50 && dx < 80.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 50 && roll < 60) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 700 && roll < 750) {
            c.aiMode = 18;
            return true;
        }
        if (roll > 995) {
            startJump(c);
            return true;
        }
        if (roll > 970) {
            if (comboChain(c)) return true;
        }
    }
    if (c.state === 206) {
        if (o.y < 0.0 && roll > 299 && roll < 320) {
            c.pressed[3] = 1;
            return true;
        }
        if (roll > 100 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 3) + 20;
            return true;
        }
        if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
        if (roll > 400 && roll < 650) {
            c.pressed[3] = 1;
            return true;
        }
        if (roll > 649) {
            c.aiMode = 1;
            return true;
        }
    }
    if (combo207(c, dx, roll)) return true;
    if (combo208(c, roll)) return true;
    if (combo209(c, roll)) return true;
    if (c.state === 230) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (roll > 200 && roll < 250 && dx < 90.0 && c.d168 === 3) {
            c.command = 20;
            return true;
        }
        if (roll > 910) {
            if (comboChain(c)) return true;
        }
    }
    if (c.state === 231) {
        if (comboJ2C(c, dx, roll, 300)) return true;
        if (roll > 910) {
            if (comboChain(c)) return true;
        }
    }
    if (c.state === 235) {
        if (o.y < 0.0 && roll < 200 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (o.y < 0.0 && roll > 299 && roll < 320) {
            c.command = 31;
            return true;
        }
        if (roll > 0 && roll < 300) {
            c.command = rnd(c, 0, 3) + 10;
            return true;
        }
        if (roll > 300 && roll < 350 && dx < 90.0 && c.d168 === 3) {
            c.command = 20;
            return true;
        }
        if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
    }
    if (c.state === 210) {
        if (combo210(c, dx, roll)) return true;
    }
    if (c.state === 211) {
        if (combo211(c, dx, roll)) return true;
    }
    if (c.state === 212) {
        if (combo212(c, roll, false)) return true;
    }
    if (c.state === 213) {
        if (combo210(c, dx, roll)) return true;
    }
    if (c.state === 214) {
        if (combo211(c, dx, roll)) return true;
    }
    if (c.state === 215) {
        if (combo212(c, roll, true)) return true;
    }
    if (combo207(c, dx, roll)) return true;
    if (combo208(c, roll)) return true;
    if (combo209(c, roll)) return true;
    if (c.state === 237) {
        if (comboJ2C(c, dx, roll, 300)) return true;
        if (roll > 910) c.aiMode = 1;
    }
    if (c.state === 238) {
        if (combo212(c, roll, true)) return true;
    }
    if (c.state === 240) {
        if (comboJ2C(c, dx, roll, 300)) return true;
        if (roll > 910) c.aiMode = 1;
    }
    if (c.state === 241) {
        if (combo212(c, roll, true)) return true;
    }
    return false;
}
function combo2A(c, dx, roll, bMax, b2Max) {
    if (dx < 40.0 && roll < 400) {
        c.pressed[0] = 1;
        c.inputY = 1;
        return true;
    }
    if (dx < 50.0 && roll < 400) {
        c.pressed[0] = 1;
        c.inputY = 0;
        if (c.d168 === 2 && rnd(c, 0, 100) < 30) {
            c.pressed[2] = 1;
            c.inputY = 1;
        }
        return true;
    }
    if (dx < 80.0 && roll > 399 && roll < bMax) {
        c.pressed[1] = 1;
        c.inputY = 0;
        return true;
    }
    if (roll > bMax && roll < b2Max) {
        c.pressed[1] = 1;
        c.inputY = 1;
        return true;
    }
    return false;
}
function comboCommand10(c, roll) {
    if (roll > 0 && roll < 200) {
        const g = c.rfGauge > 500.0 ? 1 : 0;
        c.command = (rnd(c, 0, 3) === 0 ? 1 : 0) * 2 * g + 10;
        return true;
    }
    return false;
}
function comboJ2C(c, dx, roll, airMax) {
    const o = c.opponent;
    if (o.y < 0.0 && roll < airMax && c.d168 === 3) {
        c.command = rnd(c, 0, 2) + 20;
        return true;
    }
    if (o.y < 0.0 && roll > 299 && roll < 320) {
        c.command = 31;
        return true;
    }
    if (comboCommand10(c, roll)) return true;
    if (roll > 200 && roll < 250 && dx < 90.0 && c.d168 === 3) {
        c.command = 20;
        return true;
    }
    if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
        c.command = 52;
        return true;
    }
    return false;
}
function combo207(c, dx, roll) {
    if (c.state !== 207) return false;
    const o = c.opponent;
    if (o.y < 0.0 && roll < 400) {
        c.pressed[1] = 1;
        return true;
    }
    if (dx < 60.0 && roll < 500) {
        c.pressed[0] = 1;
        return true;
    }
    if (dx < 125.0 && roll > 399 && roll < 700) {
        c.pressed[2] = 1;
        c.inputY = 0;
        return true;
    }
    if (roll > 699) {
        c.aiMode = 1;
        if (rnd(c, 0, 4) === 0) c.aiMode = 3;
        return true;
    }
    return false;
}
function combo208(c, roll) {
    if (c.state !== 208) return false;
    if (roll > 80 && roll < 300) {
        c.pressed[2] = 1;
        return true;
    }
    if (roll > 950) {
        c.inputX = rnd(c, 0, 2) - 1;
        return true;
    }
    if (roll > 649) {
        c.aiMode = 3;
        return true;
    }
    return false;
}
function combo209(c, roll) {
    if (c.state !== 209) return false;
    if (roll > 950) {
        c.inputX = rnd(c, 0, 2) - 1;
        return true;
    }
    if (roll > 649) {
        c.aiMode = 3;
        return true;
    }
    return false;
}
function combo210(c, dx, roll) {
    if (c.opponent.y < 0.0 && roll < 300) {
        c.pressed[1] = 1;
        c.inputY = 0;
        return true;
    }
    if (combo2A(c, dx, roll, 450, 600)) return true;
    if (roll > 960) {
        jumpForward(c);
        return true;
    }
    if (roll > 699) {
        comboChainShort(c);
        return true;
    }
    return false;
}
function combo211(c, dx, roll) {
    const o = c.opponent;
    if (o.y < 0.0 && roll < 50 && c.d168 === 3 && c.meter >= 1000) {
        c.command = rnd(c, 0, 2) + 110;
        return true;
    }
    if (o.y < 0.0 && roll > 299 && roll < 320) {
        c.pressed[3] = 1;
        c.inputY = 0;
        c.inputX = 0;
        return true;
    }
    if (o.y < 0.0 && roll > 320 && roll < 420 && dx < 100.0) {
        jumpForward(c);
        return true;
    }
    if (roll < 100 && dx < 90.0) {
        c.pressed[2] = 1;
        c.inputY = 1;
        return true;
    }
    if (roll > 100 && roll < 350 && dx < 120.0) {
        c.pressed[2] = 1;
        c.inputY = 0;
        return true;
    }
    if (roll > 350 && roll < 400) {
        c.command = rnd(c, 0, 2) + 40;
        return true;
    }
    if (roll > 400 && roll < 600) {
        c.command = rnd(c, 0, 2) + 10;
        return true;
    }
    if (roll > 600 && roll < 650 && dx > 100.0) {
        c.command = rnd(c, 0, 2) + 10;
        return true;
    }
    if (roll > 990) {
        startJump(c);
        return true;
    }
    if (roll > 900) {
        if (comboChain(c)) return true;
    }
    return false;
}
function combo212(c, roll, withSuper) {
    const o = c.opponent;
    if (withSuper && o.y < 0.0 && roll > 299 && roll < 320 && c.d168 === 3 && c.meter >= 1000) {
        c.command = rnd(c, 0, 3) + 110;
        return true;
    }
    if (o.y < 0.0 && roll > 299 && roll < 320) {
        c.pressed[3] = 1;
        return true;
    }
    if (roll > 0 && roll < 200) {
        c.command = 10;
        return true;
    }
    if (roll > 200 && roll < 275) {
        c.command = 70;
        return true;
    }
    if (roll > 350 && roll < 400 && c.rfGauge > 450.0) {
        c.command = 52;
        return true;
    }
    if (roll > 400 && roll < 650) {
        c.pressed[3] = 1;
        return true;
    }
    if (roll > 649) {
        c.aiMode = 1;
        return true;
    }
    return false;
}
