import {normalPath} from "./a9f14d8bd4a6a5d44caf9d3f.mjs";
import {integer} from "./ebf033feb11a338744b4587b.mjs";
import {validateResourceInitialization as validateInitialization} from "./36df6c8c461e9048c62434d5.mjs";

// Static observations from pinned upstream fcdbd920af0b746badf56ad3af62446d1007329ea4ad630453f3b4adde6980ff.
// tL names and concrete $w character classes cover IDs 0..24; IDs 10/22 share media.
export const CHARACTER_RESOURCE_NAMES=Object.freeze(['nanase','ayu','mai','makoto','akane','mayu','nagamori','misaki','shiori','sayuri','nayuki','mio','exnanase','kaori','ikumi','mishio','akiko','nayukib','mizukab','kanna','kano','minagi','nayuki','misuzu','mizuka']);
// $X's loading transition calls ev(e1.stage+10); ev formats wave/bgm/bgmNN.wav.
export const STAGE_MUSIC_PATHS=Object.freeze(Array.from({length:23},(_,stage)=>'wave/bgm/bgm'+String(stage+10).padStart(2,'0')+'.wav'));
const COMMON=Object.freeze(['system/object.dat','system/effect/effect.dat','system/effect/effect.pat']);
// eK/eU/e$/e_ constructors supply eE's inclusive last-image indices.
const ANIMATED_LAST_IMAGE=Object.freeze({1:57,10:4,12:1,16:3});
const stageRoot=stage=>'system/bg/bg'+String(stage).padStart(2,'0');

/** Known direct-battle namespaces, including optional selected media. */
export function isBattleAssetPath(path){
 const name=normalPath(path);
 if(!/\.(dat|pat|pal|wav)$/.test(name))return false;
 if(COMMON.includes(name)||CHARACTER_RESOURCE_NAMES.some(character=>name.startsWith(character+'/'))||
  name.startsWith('wave/se/')&&name.endsWith('.wav'))return true;
 for(let stage=0;stage<23;stage++){
  const root=stageRoot(stage);if(name===root+'.dat'||name===root+'b.dat'||name.startsWith(root+'/'))return true;
 }
 return false;
}

export function stageMusicPath(stage){return STAGE_MUSIC_PATHS[integer(stage,0,22,'stage')];}

function required(init){
 const stage=stageRoot(init.stage),paths=new Set([...COMMON,stage+'.dat',stage+'b.dat']);
 for(const id of init.characters){
  const name=CHARACTER_RESOURCE_NAMES[id];paths.add(name+'/'+name+'.dat');paths.add(name+'/'+name+'.pat');
  // Character files() adds these alternate-form patterns to the common files.
  if(id===0)paths.add('nanase/nanase2.pat');if(id===14)paths.add('ikumi/ikumi2.pat');
 }
 const last=ANIMATED_LAST_IMAGE[init.stage];
 if(last!==undefined){
  paths.add(stage+'/bg'+String(init.stage).padStart(2,'0')+'.pat');
  for(let image=0;image<=last;image++)paths.add(stage+'/'+String(image).padStart(3,'0')+'.dat');
 }
 return [...paths].sort();
}

/** Mandatory battle resources only. Palette indices select DAT colors; a
 * recording does not supply the separate external-palette opt-in flag. */
export function requiredAssetPaths(rawInitialization){return required(validateInitialization(rawInitialization));}

/** Select one battle from a validated deployment inventory. Sound declarations
 * retain existence semantics; their presence here does not authorize payloads. */
export function selectAssetPaths(rawInitialization,pathsIterable){
 const init=validateInitialization(rawInitialization),characters=init.characters.map(id=>CHARACTER_RESOURCE_NAMES[id]);
 const available=new Set();
 for(const item of pathsIterable){const name=normalPath(item);if(available.has(name))throw Error('duplicate normalized asset');available.add(name);}
 const mandatory=new Set(required(init));
 for(const name of mandatory)if(!available.has(name))throw Error('missing required asset '+name);
 const stage=stageRoot(init.stage)+'/';
 return [...available].filter(name=>/\.(dat|pat|wav|pal)$/.test(name)&&
  (mandatory.has(name)||characters.some(character=>name.startsWith(character+'/'))||name.startsWith(stage)||
   name.startsWith('wave/se/')&&name.endsWith('.wav'))).sort();
}
