import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./4ab9307bcb6cd4f39f8feacd.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./98eccc84a6920bb332239618.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function groundJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2) {
        jumpTo456(c);
        return true;
    }
    return false;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a === 0) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function attackStart(c, meter, se) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = 1;
}
function landTo13(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return true;
    }
    return false;
}
function dashSlide(c, decel) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - decel;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGroundNormal(c, end, crouchable) {
    c.state = end;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function groundNormalAdvance(c, dur, cnt, crouchable) {
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, 0, crouchable);
    }
}
function spawnKid(c, d, pattern, dx, dy) {
    d.w04 = pattern;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - dy;
    d.b18 = c.facing;
    d.b21 = 1;
    d.b20 = 2;
    frameChild(c, d);
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(99);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    if (c.life > 0 && c.timer > 99) {
        c.setState(96);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(96);
    }
}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        c.b158 = 0;
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx = c.vx + 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, false);
function airLand(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy = c.vy + c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    c.b158 = 0;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy = c.vy + c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 2);
    airLand(c);
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function burstFx(c, d) {
    d.w04 = 9;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 60;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    c.w16c = 1;
    c.seRequest = 62;
}
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        burstFx(c, d);
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 7)) {
        c.stopMotion();
        burstFx(c, d);
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 18) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.startAfterimage(3);
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (atStart(c)) {
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.vx = 2.2;
    c.b158 = 1;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) {
            c.frame = w16(c.frame - 6);
            return;
        }
    }
    if (c.inputX === c.facing && c.f313c >= 80 && c.frame < 4) c.setState(178);
    if (c.inputX !== c.facing && c.f3138 >= 60 && c.frame < 4) c.setState(178);
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) c.vx = -2.2;
    c.vx = c.vx + 0.02;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        if (c.frame === 4 && c.f3138 < 2) {
            c.frame = w16(c.frame - 2);
            c.f3138++;
        }
        if (c.frame >= cnt) {
            c.faceOpponent();
            c.setState(0);
            c.stopMotion();
        }
    }
}
function airDashEnd(c) {
    c.setState(9);
    c.ay = 0.03;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function airDashAdvance(c, dur, cnt) {
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = 1.9;
        c.vy = 1.3;
        c.startAfterimage(3);
        c.ax = -0.015;
        c.ay = -0.038;
        c.seRequest = 17;
    }
    c.vy = c.vy + c.ay;
    c.vx = c.vx + c.ax;
    if (c.vx < 0.5) c.vx = 0.5;
    if (c.vy < -1.5) c.vy = -1.5;
    airDashAdvance(c, dur, cnt);
    if (c.inputX === c.facing && c.f313c >= 120) airDashEnd(c);
    if (c.inputX !== c.facing && c.f3138 >= 48) airDashEnd(c);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -1.9;
        c.vy = 1.3;
        c.startAfterimage(3);
        c.ax = 0.015;
        c.ay = -0.038;
        c.seRequest = 17;
    }
    c.vy = c.vy + c.ay;
    c.vx = c.vx + c.ax;
    if (c.vx > -0.5) c.vx = -0.5;
    if (c.vy < -1.5) c.vy = -1.5;
    airDashAdvance(c, dur, cnt);
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c);
    if (c.inputX !== -c.facing && c.f3138 >= 48) airDashEnd(c);
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(7);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 10) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 10;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 1) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 10) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    dashSlide(c, 0.03);
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 2)) attackStart(c, 5, 21);
    groundNormalAdvance(c, dur, cnt, false);
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    dashSlide(c, 0.03);
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 15, 20);
    groundNormalAdvance(c, dur, cnt, false);
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    dashSlide(c, 0.03);
    if (atFrame(c, 3)) attackStart(c, 15, 20);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 4) {
            c.voiceRequest = 0;
            spawnKid(c, d, 413, 0x22, 31);
        }
        if (c.frame >= cnt) endGroundNormal(c, 0, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    dashSlide(c, 0.06);
    if (atStart(c)) c.w16c = 1;
    if (c.frame === 10 && c.pressed[2] === 1 && c.f3138 < 2) {
        c.voiceRequest = 0;
        c.timer = 0;
        c.frame = 6;
        c.voiceRequest = 0;
        c.d168 = 0;
        c.w16c = 1;
        addMeter(c, 15);
        c.f3138++;
        spawnKid(c, d, 400, 0x5a, 50);
    }
    if (advance(c, dur)) {
        if (c.frame < 7) c.d168 = 0;
        if (c.frame === 6) {
            c.w16c = 1;
            c.voiceRequest = 0;
            spawnKid(c, d, 400, 0x5a, 50);
        }
        if (c.frame >= cnt) endGroundNormal(c, 0, false);
    }
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    dashSlide(c, 0.03);
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 21);
    groundNormalAdvance(c, dur, cnt, true);
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    dashSlide(c, 0.03);
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 2)) attackStart(c, 13, 20);
    groundNormalAdvance(c, dur, cnt, true);
}
function multiHitAdvance(c, dur, cnt, vxAt2) {
    if (advance(c, dur)) {
        if (c.frame === 1) c.d168 = 0;
        if (vxAt2 !== null && c.frame === 2) c.vx = vxAt2;
        if (c.frame === 6 && c.f3138 < 4) {
            c.frame = w16(c.frame - 3);
            c.f3138++;
            if (c.f3138 > 2) c.w16c = 0;
        }
        if (c.frame >= cnt) {
            c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame < 2) dashSlide(c, 0.03);
    if (c.vx > 0.0) {
        c.b158 = 0;
        c.vx = c.vx - 0.02;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (atFrame(c, 2)) attackStart(c, 25, 20);
    multiHitAdvance(c, dur, cnt, 1.9);
}
function airNormalAdvance(c, dur, cnt) {
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s207(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 2)) attackStart(c, 5, 21);
    if (landTo13(c)) return;
    airNormalAdvance(c, dur, cnt);
}
function s208(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 3)) attackStart(c, 13, 20);
    if (landTo13(c)) return;
    airNormalAdvance(c, dur, cnt);
}
function s209(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c)) return;
    if (c.frame > 4 && c.pressed[2] === 1 && c.f3138 < 2) {
        c.timer = 0;
        c.frame = 3;
        c.f3138++;
        c.d168 = 0;
    }
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame === 4) {
            attackStart(c, 15, 20);
            c.voiceRequest = 0;
            spawnKid(c, d, 401, 0x1b, 28);
        }
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (atFrame(c, 3)) {
        c.vx = 0.6;
        c.vy = -1.4;
        c.ay = 0.036;
    }
    if (atFrame(c, 6)) attackStart(c, 20, 20);
    if (c.frame > 2) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 9 && c.frame > 3) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 9;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c)) return;
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame === 5) {
            attackStart(c, 15, 20);
            c.voiceRequest = 0;
            spawnKid(c, d, 400, 0x2d, 62);
        }
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vy = c.vy + c.ay;
    if (atStart(c)) {
        attackStart(c, 30, 20);
        c.vx = c.vx / 2.0;
        c.ay = 0.07;
    }
    if (c.d168 > 1) {
        c.setState(213);
        c.stopMotion();
        return;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.shakeScreen(3, 0);
        d.w04 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        d.b2c = 7;
        frameEffect(d);
        c.seRequest = 7;
        c.setState(214);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy = c.vy + c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        d.w04 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        d.b2c = 7;
        frameEffect(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, 7, true);
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 221;
        o.state = 107;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x19;
        d.y = ftol(c.y) - 51;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, 0, false);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (atFrame(c, 1)) {
        o.onStateChange();
        o.stopMotion();
        o.state = 50;
    }
    if (c.frame > 2) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - 0.045;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame < 9 && c.frame > 2 && c.vy + c.y > 0.0) {
        c.frame = 9;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 2) {
            c.vx = 1.5;
            c.vy = -1.6;
            c.ay = 0.05;
            const d = openSpawnFrame();
            d.w04 = 31;
            d.x = ftol(c.x);
            d.y = 0.0;
            d.b20 = 0;
            d.b21 = 0;
            d.d1c = c.facing - 1 !== 0 ? 1 : 0;
            frameEffect(d);
        }
        if (c.frame === 4) {
            c.seRequest = 21;
            c.w16c = 1;
            addMeter(c, 30);
        }
        if (c.frame >= cnt) c.setState(0);
    }
}
function dashAttackSlide(c) {
    if (c.vx > 0.0) {
        c.vx = c.vx - 0.03;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.vx < 0.0) c.vx = 0.0;
}
function dashAttack(c, afterimageFirst, startFrame, meter, se, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (afterimageFirst) {
        c.startAfterimage(3);
        c.b158 = 0;
    } else {
        c.b158 = 0;
        c.startAfterimage(3);
    }
    dashAttackSlide(c);
    if (atStart(c)) c.vy = 0.0;
    if (atFrame(c, startFrame)) attackStart(c, meter, se);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(end);
    }
}
const s230 = (c)=>dashAttack(c, true, 1, 5, 21, 0);
const s231 = (c)=>dashAttack(c, true, 2, 10, 20, 0);
const s233 = (c)=>dashAttack(c, false, 1, 5, 21, 3);
const s234 = (c)=>dashAttack(c, true, 2, 10, 20, 3);
function s232(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.startAfterimage(3);
    if (atStart(c)) {
        c.ax = 0.0;
        c.w16c = 1;
    }
    if (c.frame < 3) {
        c.vx = c.vx - 0.035;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (atFrame(c, 3)) {
        addMeter(c, 25);
        c.seRequest = 20;
    }
    if (c.frame === 3) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.timer = 0;
            c.frame = 4;
            return;
        }
    }
    if (advance(c, dur)) {
        if (c.frame === 3) {
            c.vx = 1.8;
            c.vy = -1.5;
            c.ay = 0.045;
        }
        if (c.frame >= cnt) endGroundNormal(c, 0, false);
    }
}
function s235(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.startAfterimage(3);
    if (atStart(c)) {
        c.ax = 0.0;
        c.w16c = 1;
    }
    if (c.vx > 0.0) {
        c.vx = c.vx - 0.01;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (atFrame(c, 2)) {
        addMeter(c, 25);
        c.seRequest = 20;
    }
    multiHitAdvance(c, dur, cnt, null);
}
function s248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.stopMotion();
        o.d128 = 1;
        c.frame = 0;
        c.timer = 0;
        c.state = 249;
        o.state = 110;
        o.y = c.y;
        o.x = c.facing * 0x13 + c.x;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 211;
            c.frame = 1;
        }
    }
}
function s249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.w13e = 30;
    o.w13e = 30;
    c.b158 = 0;
    if (atStart(c)) {
        c.vx = -2.5;
        c.vy = -4.5;
        c.ay = 0.045;
    }
    c.vy = c.vy + c.ay;
    if (c.frame < 8) {
        c.vx = c.vx + 0.035;
        if (c.vx > 0.0) c.vx = 0.0;
        o.y = c.y;
        o.x = c.facing * 0x13 + c.x;
        if (c.vy + c.y > 0.0) {
            c.y = 0.0;
            o.y = 0.0;
            o.x = c.x;
            c.timer = 0;
            c.frame = 8;
            const d = openSpawnFrame();
            d.w04 = 0;
            d.b2c = 2;
            d.x = ftol(c.x);
            d.y = ftol(c.y);
            d.b20 = 2;
            d.b21 = 1;
            frameEffect(d);
            o.onStateChange();
            o.state = 98;
            return;
        }
    }
    if (atFrame(c, 8)) {
        c.hitstop = 60;
        o.hitstop = 60;
        applyDirectDamage(c, 1100, 500.0);
    }
    if (atFrame(c, 9)) {
        c.vy = -1.5;
        c.vx = -1.3;
        c.ay = 0.035;
    }
    if (c.frame > 9 && c.y + c.vy > 0.0) {
        c.onStateChange();
        c.stopMotion();
        c.y = 0.0;
        c.state = 13;
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 3) o.state = 121;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function childSimpleHit(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child413(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    if (ch.frame >= childCount) {
        const d = childSpawnFrame;
        d.w04 = 414;
        d.x = ftol(ch.x) + ch.facing * 0x3c;
        d.y = 5.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.freeChild(i);
    }
}
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    234: s234,
    235: s235,
    248: s248,
    249: s249
});
registerChildren({
    400: childSimpleHit,
    401: childSimpleHit,
    402: childSimpleHit,
    413: child413,
    414: childSimpleHit
});
