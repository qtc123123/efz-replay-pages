import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { HISTORY_LENGTH, NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
function hist(c, i) {
    return c.history[i - (i >= HISTORY_LENGTH ? 1 : 0) * HISTORY_LENGTH];
}
function buttonCommand(base, v) {
    return base + ((v & 0xe0) > 0 ? 1 : 0) + ((v & 0xc0) > 0 ? 1 : 0) + ((v & 0x80) > 0 ? 1 : 0);
}
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function cancelable(c) {
    return ((c.currentHit()?.defenseFlags ?? 0) & 8) > 0;
}
function priorityOk(c, target) {
    return (c.patterns[c.state]?.hdrB ?? 0) <= (c.patterns[target]?.hdrA ?? 0);
}
function cancelOk(c) {
    if (c.state >= 200 && c.d168 >= 2 && c.d168 !== 6) return true;
    return c.state < 200;
}
function rfOk(c) {
    return c.rfGauge >= 500.0 || c.rfBlue > 0;
}
function enter(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function normalOk(c, target) {
    return priorityOk(c, target) && cancelable(c) && cancelOk(c);
}
export function parseCommandAyu(c) {
    c.command = NO_COMMAND;
    const idx = c.historyIndex;
    const end = idx + HISTORY_LENGTH;
    const left = c.facing === -1 ? 1 : 0;
    const BACK = 2 - left;
    const FWD = 1 + left;
    const DOWN_BACK = 6 - left;
    const DOWN_FWD = 5 + left;
    let step;
    let v;
    step = 0;
    for(let i = idx + 0x2d; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 5) {
            c.command = 0x5d;
            return;
        }
        if (v & 0x20 && step === 4) step = 5;
        if (v & 0xd0 && step === 4) break;
        if ((v & 0xf) === BACK && step === 3) step = 4;
        if (v & 0xe0 && step === 2) break;
        if (v & 0x10 && step === 2) step = 3;
        if (v === 0 && step === 1) step = 2;
        if (v & 0xe0 && step === 1) break;
        if (v & 0x10 && step === 0 && c.meter === 3000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x69; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 4) {
            c.command = buttonCommand(0x78, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 3) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x78, v);
                return;
            }
            step = 4;
        }
        if ((v & 0xf) === DOWN_BACK && step === 2) step = 3;
        if ((v & 0xf) === BACK && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x6e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x6e, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_BACK && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x64, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x64, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_FWD && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x14, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x14, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x1e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x1e, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0xaf; i < end; i++){
        v = hist(c, i);
        if (v & 8 && step === 1) {
            c.command = 6;
            return;
        }
        if (!(v & 8) && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 4) {
            c.command = 53;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0 && c.state === 96) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 4) {
            c.command = 52;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 4) {
            c.command = 51;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 4) {
            c.command = 50;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 1 && step === 3) {
            c.command = 1;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 1 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 2 && step === 3) {
            c.command = 0;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 2 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
}
export function dispatchMovesAyu(c) {
    if (c.state < 200) c.bufferedA = 0;
    if (c.bufferTimer > 0) {
        c.bufferTimer = c.bufferTimer - 1 & 0xff;
    } else {
        c.bufferedB = 0;
    }
    if (c.bufferedB === 0) c.bufferTimer = 0;
    if (c.command === 52) {
        let ok = false;
        if (c.rfGauge >= 500.0 && c.d168 > 1 && c.d168 !== 6) ok = true;
        else if (c.rfBlue > 0 && c.d168 > 1) ok = true;
        if (ok && cancelable(c) && priorityOk(c, 167)) {
            enter(c, 167);
            if (c.y < 0.0) c.state = 171;
            return;
        }
    }
    if (c.d15c < 2) {
        if (c.life < 3333 && c.command === 93 && c.meter >= 3000 && c.y === 0.0 && c.d168 !== 6 && cancelable(c) && priorityOk(c, 318)) {
            enter(c, 318);
            return;
        }
        if (c.command === 122 && c.meter >= 3000 && c.y === 0.0 && cancelable(c) && cancelOk(c) && priorityOk(c, 308)) {
            enter(c, 308);
            return;
        }
        if ((c.command === 121 || c.command === 122) && c.meter >= 2000 && c.y === 0.0 && cancelable(c) && cancelOk(c) && priorityOk(c, 307)) {
            enter(c, 307);
            return;
        }
        if ((c.command === 120 || c.command === 121 || c.command === 122) && c.meter >= 1000 && c.y === 0.0 && cancelable(c) && cancelOk(c) && priorityOk(c, 306)) {
            enter(c, 306);
            return;
        }
        if (c.command === 112 && c.meter >= 3000 && cancelable(c) && cancelOk(c) && priorityOk(c, 302)) {
            enter(c, 302);
            if (c.y < 0.0) c.state = 305;
            return;
        }
        if ((c.command === 111 || c.command === 112) && c.meter >= 2000 && cancelable(c) && cancelOk(c) && priorityOk(c, 301)) {
            enter(c, 301);
            if (c.y < 0.0) c.state = 304;
            return;
        }
        if ((c.command === 110 || c.command === 111 || c.command === 112) && c.meter >= 1000 && cancelable(c) && cancelOk(c) && priorityOk(c, 300)) {
            enter(c, 300);
            if (c.y < 0.0) c.state = 303;
            return;
        }
        if (c.command === 102 && c.meter >= 3000 && c.y === 0.0 && cancelable(c) && cancelOk(c) && priorityOk(c, 317)) {
            enter(c, 317);
            return;
        }
        if ((c.command === 101 || c.command === 102) && c.meter >= 2000 && c.y === 0.0 && cancelable(c) && cancelOk(c) && priorityOk(c, 316)) {
            enter(c, 316);
            return;
        }
        if ((c.command === 100 || c.command === 101 || c.command === 102) && c.meter >= 1000 && c.y === 0.0 && cancelable(c) && cancelOk(c) && priorityOk(c, 315)) {
            enter(c, 315);
            return;
        }
        if (c.command === 120 && c.meter >= 3000 && c.y === 0.0 && cancelable(c) && cancelOk(c) && priorityOk(c, 306)) {
            enter(c, 306);
            return;
        }
        if (c.command === 22 && rfOk(c) && cancelable(c) && cancelOk(c) && priorityOk(c, 251)) {
            enter(c, 251);
            if (c.y < 0.0) c.state = 267;
            return;
        }
        if ((c.command === 21 || c.command === 22) && cancelable(c) && cancelOk(c) && priorityOk(c, 252)) {
            enter(c, 252);
            return;
        }
        if (c.command === 20 && cancelable(c) && cancelOk(c) && priorityOk(c, 250)) {
            enter(c, 250);
            return;
        }
        if (c.command === 32 && rfOk(c) && cancelable(c) && cancelOk(c) && priorityOk(c, 258)) {
            enter(c, 258);
            return;
        }
        if ((c.command === 31 || c.command === 32) && cancelable(c) && cancelOk(c) && priorityOk(c, 257)) {
            enter(c, 257);
            return;
        }
        if (c.command === 30 && cancelable(c) && cancelOk(c) && priorityOk(c, 256)) {
            enter(c, 256);
            return;
        }
        if (c.command === 12 && rfOk(c) && cancelable(c) && c.y === 0.0 && cancelOk(c) && priorityOk(c, 262)) {
            enter(c, 262);
            return;
        }
        if ((c.command === 11 || c.command === 12) && cancelable(c) && c.y === 0.0 && cancelOk(c) && priorityOk(c, 261)) {
            enter(c, 261);
            return;
        }
        if (c.command === 10 && cancelable(c) && c.y === 0.0 && cancelOk(c) && priorityOk(c, 260)) {
            enter(c, 260);
            return;
        }
    }
    if (c.d15c < 3 && c.command === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && priorityOk(c, 14) && cancelOk(c)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return;
    }
    if (c.d15c < 1 && (c.command === 0 || c.command === 1)) {
        const dir = 1 - (c.command << 1);
        const dx = c.opponent.x - c.x;
        if (c.y < 0.0 && c.b159 < 2) {
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 165) && c.state !== 170 && c.y < -40.0 && cancelable(c) && cancelOk(c)) {
                airDash(c, 165);
                return;
            }
            if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && priorityOk(c, 166) && c.state !== 170 && cancelable(c) && cancelOk(c)) {
                airDash(c, 166);
                return;
            }
        }
        if (c.y === 0.0 && cancelable(c)) {
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 163) && cancelOk(c)) {
                groundDash(c, 163);
                return;
            }
            if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && priorityOk(c, 164) && cancelOk(c)) {
                groundDash(c, 164);
                return;
            }
        }
    }
    if (c.pressed[0] === 1 || c.bufferedA & 0x10 || c.bufferedB & 0x10) {
        if (c.y < 0.0) {
            if (normalOk(c, 207)) enter(c, 207);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 204)) {
            enter(c, 204);
            return;
        }
        if ((c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) && normalOk(c, 200)) {
            enter(c, 200);
            return;
        }
    }
    if (c.pressed[1] === 1 || c.bufferedA & 0x20 || c.bufferedB & 0x20) {
        if (c.y < 0.0) {
            if (normalOk(c, 208)) enter(c, 208);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 205)) {
            enter(c, 205);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (priorityOk(c, 210) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 210);
                return;
            }
            if (priorityOk(c, 201) && cancelable(c) && c.x - c.opponent.x > -70.0 && c.x - c.opponent.x < 70.0 && cancelOk(c)) {
                enter(c, 201);
                return;
            }
            if (normalOk(c, 202)) {
                enter(c, 202);
                return;
            }
        }
    }
    if (c.pressed[2] === 1 || c.bufferedA & 0x40 || c.bufferedB & 0x40) {
        if (c.y < 0.0) {
            if (c.inputX === c.facing && c.inputY === 0 && c.x - c.opponent.x > -100.0 && c.x - c.opponent.x < 100.0 && c.opponent.y < 0.0 && priorityOk(c, 240) && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 240);
                return;
            }
            if (priorityOk(c, 212) && cancelable(c) && c.inputY === 1 && cancelOk(c)) {
                enter(c, 212);
            }
            if (normalOk(c, 209)) enter(c, 209);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 206)) {
            enter(c, 206);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (c.inputX !== 0 && c.opponent.y === 0.0 && c.x - c.opponent.x > -30.0 && c.x - c.opponent.x < 30.0 && priorityOk(c, 220) && c.opponent.y === 0.0 && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 220);
                return;
            }
            if (priorityOk(c, 211) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 211);
                return;
            }
            if (normalOk(c, 203)) {
                enter(c, 203);
                return;
            }
        }
    }
    if (c.d15c >= 1) return;
    if (c.pressed[3] === 1 || c.bufferedA & 0x80 || c.bufferedB & 0x80) {
        if (priorityOk(c, 40) && cancelable(c) && c.y < 0.0 && cancelOk(c)) {
            enter(c, 40);
        }
    }
}
function airDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    c.b159 = c.b159 + 1 & 0xff;
    c.b15a = c.b15a + 1 & 0xff;
    c.bufferedA = 0;
}
function groundDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    c.b158 = c.b158 + 1 & 0xff;
    c.bufferedA = 0;
}
