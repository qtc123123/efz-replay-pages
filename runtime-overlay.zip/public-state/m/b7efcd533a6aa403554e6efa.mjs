import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { registerChildren, registerStates, setDefaultStateHandler } from "./9410f25ccc5489d02b4dd080.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./1d4a8932dc5ab92063658a65.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const w16 = (v)=>v & 0xffff;
const JUMP_GRAVITY = 0.048;
const JUMP_VY = -3.0;
function advance(c, dur, cnt) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return c.frame >= cnt;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function landFromHit(c) {
    c.y = 0.0;
    if (c.d12c !== 0) c.setState(0x61);
    else c.setState(0x62);
}
function wallPush(c, y, k) {
    if (c.x - 20.0 <= 0.0 || !(c.x + 20.0 < 639.0)) {
        c.pushToOpponent = (1.0 - (y < 0.0 ? 1 : 0) * k) * c.vx;
    } else {
        c.pushToOpponent = 0.0;
    }
}
function rfDrain(c, v) {
    if (c.rfBlue !== 0) c.rfGauge -= v;
}
function jumpLanding(c, minFrame) {
    if (c.y + c.vy >= 0.0 && c.frame > minFrame) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function stateDefault(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (advance(c, dur, cnt)) c.frame = 0;
}
function walk(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = vx;
    c.vy = 0.0;
    if (advance(c, dur, cnt)) c.frame = 0;
}
function state3(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.frame = 0;
}
function jump(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.faceOpponent();
        c.vx = 0.0;
    }
    if (c.frame === 2 && c.timer === 0) {
        c.ay = JUMP_GRAVITY;
        c.vy = JUMP_VY;
        if (vx !== null) c.vx = vx;
    }
    if (c.frame > 1) c.vy += c.ay;
    if (advance(c, dur, cnt)) c.setState(9);
    jumpLanding(c, 2);
}
function transition(c, next) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(next);
}
function state9(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.seRequest = 9;
        c.setState(13);
    }
}
function state13(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.stopMotion();
    c.y = 0.0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(c.inputY === 1 ? 3 : 7);
}
function quickJump(c, vx0) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = JUMP_GRAVITY;
    if (atStart(c)) {
        c.vy = JUMP_VY;
        c.vx = vx0;
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.setState(9);
    jumpLanding(c, 3);
}
function state47(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.3;
        c.ay = 0.035;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 2) {
        c.timer = 0;
        c.frame = 2;
        c.seRequest = 7;
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.vx = 0.0;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 2) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) c.frame = w16(c.frame - 1);
    }
}
function hitStand(c, meter, k, guard, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    if (atStart(c)) {
        c.meter = s16(c.meter + meter);
        c.vx = (2.0 - c.opponent.proration / 10000.0) * k;
        rfDrain(c, guard);
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    wallPush(c, c.y, 0.2);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 0);
        else c.setState(3);
    }
}
function hitAir(c, wall, mix, clamp, ay) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (wall && c.frame > 0 && c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (atStart(c)) {
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = mix ? c.vy * 0.75 + c.knockY : c.knockY;
        if (clamp !== null) {
            if (c.vy < clamp) c.vy = clamp;
            else if (c.vy > -0.5) c.vy = -0.5;
        }
        c.ay = ay;
    }
    if (!(c.vy > 0.0)) {
        c.frame = 1;
        c.timer = 0;
    }
    if (c.vy >= 0.0 && c.frame <= 1) {
        c.frame = 2;
        c.timer = 0;
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = w16(c.frame - 2);
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function state68(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    c.timer = w16(c.timer + 1);
    if (c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state69(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    if (advance(c, dur, cnt)) c.frame = w16(c.frame - 2);
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state70(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (atStart(c) && c.f3138 === 0) {
        c.meter = s16(c.meter + 30);
        c.f3138++;
        c.hitstun = s16(c.hitstun + 120);
        c.vx = 0.5;
        c.vy = -2.5;
        c.ay = 0.025;
        c.seRequest = 0x1f;
        const f = openSpawnFrame();
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function grounded(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    c.vx = 0.0;
    c.vy = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function slide(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    if (atStart(c)) {
        c.meter = s16(c.meter + 30);
        rfDrain(c, 30.0);
        c.vx = 2.2;
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.ay = 0.0;
    c.ax = 0.06;
    c.vx -= c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function state81(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (atStart(c)) {
        const d = openSpawnFrame();
        d.w04 = 0x1f3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    c.vx += 0.02;
    c.vy += c.ay;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) c.frame = w16(c.frame - 1);
    if (c.y + c.vy >= 0.0 && c.frame === 1) landFromHit(c);
}
function state82(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (atStart(c) && c.f3138 === 0) {
        c.seRequest = 0x1e;
        c.vy = -0.45;
        c.vx = -0.1;
        c.f3138++;
        c.meter = s16(c.meter + 30);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    if (c.vy > 0.0 && c.frame === 4) {
        c.frame = 5;
        c.timer = 0;
    }
    if (c.frame > 3) c.vy += c.ay;
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 4 && c.f3138 < 8) {
            c.frame = 0;
            c.f3138++;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.y + c.vy >= 0.0 && c.frame > 4) landFromHit(c);
}
function spawn496(c) {
    if (c.f3144 === 0) {
        const d = openSpawnFrame();
        d.w04 = 0x1f0;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 0;
        d.d00 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.f3144 = 1;
    }
}
function state83(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vy = -1.5;
        c.vx = -0.8;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (c.frame === 0 && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.timer = 0;
        c.frame = 1;
        return;
    }
    if (c.frame === 1) c.vx += 0.01;
    if (c.frame === 2 && c.timer === 0) c.vx = -2.0;
    if (c.frame > 1) c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
}
function state85(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state86(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        spawn496(c);
        if (c.f3138 === 0) {
            rfDrain(c, 30.0);
            c.seRequest = 0x21;
            c.vx = c.knockX;
            c.vy = c.knockY;
            c.meter = s16(c.meter + 30);
            c.f3138++;
        }
    }
    c.vy += 0.06;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state87(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        const d = openSpawnFrame();
        d.w04 = 0x1ef;
        d.x = 60.0;
        d.y = 40.0;
        d.d24 = 1;
        d.b18 = 1;
        d.b20 = 0;
        d.b21 = 0;
        frameChild(c, d);
    }
    if (advance(c, dur, cnt)) c.setState(0);
}
function state96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    if (c.frame === cnt - 1) c.faceOpponent();
    if (c.frame >= cnt) c.setState(c.inputY === 1 ? 3 : 0);
}
function state97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        const d = openSpawnFrame();
        d.w04 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        frameEffect(d);
        c.seRequest = 7;
    }
    if (advance(c, dur, cnt)) c.setState(0x63);
}
function state99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.timer = w16(c.timer + 1);
    if (c.life > 0 && c.timer > 0x63 && c.frame === 0) c.setState(0x60);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(0x60);
    }
}
setDefaultStateHandler(stateDefault);
registerStates({
    1: (c)=>walk(c, 0.8),
    2: (c)=>walk(c, -0.8),
    3: state3,
    4: (c)=>jump(c, null),
    5: (c)=>jump(c, 0.9),
    6: (c)=>jump(c, -0.9),
    7: (c)=>transition(c, 0),
    8: (c)=>transition(c, 3),
    9: state9,
    13: state13,
    14: (c)=>quickJump(c, 0.0),
    15: (c)=>quickJump(c, 0.9),
    16: (c)=>quickJump(c, -0.9),
    47: state47,
    50: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    51: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    52: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    53: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    54: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    55: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    56: (c)=>hitStand(c, 10, -1.1, 10.0, false),
    57: (c)=>hitStand(c, 15, -1.5, 20.0, false),
    58: (c)=>hitStand(c, 20, -1.8, 30.0, false),
    59: (c)=>hitAir(c, false, true, -2.0, 0.032),
    60: (c)=>hitAir(c, false, true, -4.0, 0.032),
    61: (c)=>hitAir(c, false, true, -6.0, 0.032),
    62: (c)=>hitAir(c, false, true, null, 0.032),
    63: (c)=>hitAir(c, false, false, null, 0.032),
    64: (c)=>hitAir(c, true, true, -2.0, 0.032),
    65: (c)=>hitAir(c, true, true, -4.0, 0.032),
    66: (c)=>hitAir(c, true, true, null, 0.032),
    67: (c)=>hitAir(c, true, false, null, 0.032),
    68: state68,
    69: state69,
    70: state70,
    71: (c)=>hitAir(c, false, false, null, 0.072),
    72: (c)=>grounded(c, true),
    73: (c)=>grounded(c, true),
    74: (c)=>grounded(c, false),
    75: (c)=>slide(c, true),
    76: (c)=>slide(c, true),
    77: (c)=>slide(c, false),
    81: state81,
    82: state82,
    83: state83,
    84: state83,
    85: state85,
    86: state86,
    87: state87,
    96: state96,
    97: state97,
    98: state97,
    99: state99
});
function childAdvance(c, i) {
    const ch = c.children[i];
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    return ch.frame >= childCount;
}
function coin() {
    return rand("src/game/chars/misuzu/states_template_a.ts:787:8", {
        consumer: "src/game/chars/misuzu/states_template_a.ts"
    }) > 0x3e80 ? 1 : 0;
}
function child495(c, i) {
    const ch = c.children[i];
    ch.vx = -0.02;
    ch.drawWhileFrozen = 30000;
    ch.timer = w16(ch.timer + 1);
    if (c.state !== 0x57) c.freeChild(i);
    if (childAdvance(c, i)) ch.frame = 0;
}
function child496(c, i) {
    const ch = c.children[i];
    const s = c.state;
    const inStates = s === 0x53 || s === 0x54 || s === 0x55 || s === 0x56;
    const burst = !inStates || (s === 0x53 || s === 0x54) && c.frame > 1;
    if (burst) {
        const f = childSpawnFrame;
        const pieces = [
            [
                0x1f1,
                23,
                -4
            ],
            [
                0x1f1,
                -4,
                -6
            ],
            [
                0x1f1,
                -14,
                -26
            ],
            [
                0x1f1,
                0,
                0
            ],
            [
                0x1f1,
                30,
                -40
            ],
            [
                0x1f1,
                -25,
                -80
            ],
            [
                0x1f2,
                -35,
                -42
            ],
            [
                0x1f2,
                -18,
                -20
            ],
            [
                0x1f2,
                2,
                -65
            ],
            [
                0x1f2,
                16,
                -80
            ]
        ];
        for (const [pattern, dx, dy] of pieces){
            f.w04 = pattern;
            f.x = ftol(c.x) + c.facing * dx;
            f.y = ftol(c.y) + dy;
            f.b20 = 0;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        c.seRequest = 0x22;
        c.freeChild(i);
        c.f3144 = 0;
        return;
    }
    ch.timer = w16(ch.timer + 1);
    if (childAdvance(c, i)) ch.frame = 0;
}
function debris(c, i, init, gravity) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) init();
    ch.vy = ch.vy + gravity;
    if (ch.y > 0.0 && ch.vy > 0.0) ch.vy = -ch.vy;
    if (c.a3258[i] < 10) ch.blend = 1;
    if (c.a3258[i] < 0) {
        c.freeChild(i);
        return;
    }
    ch.timer = w16(ch.timer + 1);
    c.a3258[i]--;
    if (childAdvance(c, i)) ch.frame = 0;
}
function child497(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 40;
        c.a3258[i] = r1 + coin() * 20 + 80;
        c.a3158[i]++;
        const t1 = coin() * 1.2;
        const t2 = coin() * 0.7 + t1;
        ch.vx = coin() * 1.7 + t2 + -1.8;
        const u1 = coin() * 0.6;
        const u2 = coin() * 0.9 + u1;
        ch.vy = -1.2 - (coin() * 1.4 + u2);
    }, 0.05);
}
function child498(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 60;
        c.a3258[i] = r1 + coin() * 40 + 120;
        c.a3158[i]++;
        const t1 = coin();
        const t2 = coin() * 0.5 + t1;
        ch.vx = coin() * 1.5 + t2 + -1.5;
        const u1 = coin() * 0.5;
        const u2 = coin() * 0.8 + u1;
        ch.vy = -1.0 - (coin() * 1.2 + u2);
    }, 0.03);
}
function child499(c, i) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y;
    ch.timer = w16(ch.timer + 1);
    if (childAdvance(c, i)) c.freeChild(i);
}
registerChildren({
    495: child495,
    496: child496,
    497: child497,
    498: child498,
    499: child499
});

export function __logicState(){return {JUMP_VY};}

export function __installInitialRoots(s){
if(JUMP_VY!==s["JUMP_VY"])throw Error('INITIAL_CONST_IDENTITY:JUMP_VY');
}
