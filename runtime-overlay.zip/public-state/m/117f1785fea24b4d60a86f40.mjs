import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, blitBlend, BlendTable, fillRect, makeRect, present } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { GROUND_Y } from "./7f2701ba2d6ce15107cdc8f7.mjs";
const FONTS = [
    [
        0,
        234,
        8,
        10
    ],
    [
        0,
        210,
        16,
        15
    ],
    [
        0,
        225,
        7,
        9
    ],
    [
        0,
        282,
        14,
        22
    ],
    [
        0,
        352,
        8,
        12
    ],
    [
        0,
        340,
        8,
        12
    ],
    [
        0,
        328,
        8,
        12
    ],
    [
        0,
        316,
        8,
        12
    ],
    [
        0,
        304,
        8,
        12
    ],
    [
        0,
        364,
        7,
        10
    ],
    [
        0,
        374,
        7,
        10
    ],
    [
        0,
        384,
        7,
        10
    ],
    [
        0,
        394,
        7,
        10
    ],
    [
        0,
        404,
        7,
        10
    ],
    [
        0,
        414,
        7,
        10
    ],
    [
        0,
        424,
        7,
        10
    ],
    [
        0,
        434,
        7,
        10
    ]
];
function objBlit(dst, src, blend = false) {
    if (blend) blitBlend(dst, gs.objectSurf, src, gs.objectKey, false, BlendTable.Average);
    else blit(dst, gs.objectSurf, src, gs.objectKey, false);
}
function drawNumber(xRight, y, value, font, spacing, blend) {
    const [, top, cw, h] = FONTS[font];
    let x = xRight;
    let v = value >>> 0;
    do {
        const d = v % 10;
        objBlit({
            left: x - cw,
            top: y,
            right: x,
            bottom: y + h
        }, {
            left: cw * d,
            top,
            right: cw * (d + 1),
            bottom: top + h
        }, blend);
        x -= cw + spacing;
        v = Math.trunc(v / 10);
    }while (v > 0)
}
export function drawBackground(view) {
    const [p1, p2] = gs.chars;
    const z = gs.bgZoom;
    let sx = Math.trunc(-view.camX * z + (160 - 160 * z));
    let sy = Math.trunc((240 - view.camY) * z + (120 - 120 * z));
    let dx = 0;
    let dy = 0;
    if (sx > 320) {
        dx = 320 - sx;
        sx = 320;
    } else if (sx < 0) {
        dx = -sx;
        sx = 0;
    }
    if (sy > 240) {
        dy = 240 - sy;
        sy = 240;
    } else if (sy < 0) {
        dy = -sy;
        sy = 0;
    }
    const src = makeRect(sx, sy, 320, 240);
    const dst = makeRect(dx, dy, 320, 240);
    const hs = p1.freeze === 0 && p2.freeze === 0;
    if (p1.darkenFrames > 0 && p2.darkenFrames > 0) {
        fillRect(dst, gs.darkenSide === 0 ? p1.darkenColor : p2.darkenColor);
        if (hs) {
            p1.darkenFrames--;
            p2.darkenFrames--;
        }
    } else if (p1.darkenFrames > 0) {
        fillRect(dst, p1.darkenColor);
        if (hs) p1.darkenFrames--;
    } else if (p2.darkenFrames > 0) {
        fillRect(dst, p2.darkenColor);
        if (hs) p2.darkenFrames--;
    } else if (gs.bgbFrames > 0) {
        blit(dst, gs.bgbSurf, src, 0, false);
        if (hs) gs.bgbFrames--;
    } else {
        blit(dst, gs.bgSurf, src, 0, false);
        gs.stageObject?.draw(view.camX, view.camY, 0);
    }
}
function drawCharImage(c, pattern, x, y, flip) {
    const f = c.patterns[pattern]?.frames[0];
    const surf = f && c.sprites[f.sprite];
    if (!f || !surf) return;
    blit(makeRect(x(f.width), y, f.width, f.height), surf, makeRect(0, 0, f.width, f.height), c.colorKey, flip);
}
export function drawTopHud(view) {
    const chars = gs.chars;
    for(let i = 0; i < 2; i++){
        const c = chars[i];
        const opp = chars[1 - i];
        if (c.shownLife > c.life) {
            c.shownLife -= 200;
            if (c.shownLife < c.life) c.shownLife = c.life;
        }
        if (c.shownLife < c.life) {
            c.shownLife += 200;
            if (c.shownLife > c.life) c.shownLife = c.life;
        }
        if (opp.comboCount === 0) {
            c.redLife -= c.redLife > c.life ? 100 : 0;
            if (c.redLife < c.life) c.redLife = c.life;
        }
    }
    if (gs.specialTimerC > 0) return;
    const [p1, p2] = chars;
    drawCharImage(p1, 48, ()=>0, 14, false);
    drawCharImage(p2, 48, (w)=>320 - w, 14, true);
    objBlit(makeRect(0, 0, 320, 44), makeRect(0, 0, 320, 44));
    drawCharImage(p1, 45, ()=>1, 40, false);
    drawCharImage(p2, 45, (w)=>319 - w, 40, false);
    const width = (v)=>Math.trunc(v * 120.0 / 9999.0);
    const lifeY = (c, w)=>w >= 40 ? 73 : Math.trunc(c.cycle % 36 / 18) * 6 + 79;
    let w = width(p1.redLife);
    if (w > 0) objBlit(makeRect(138 - w, 18, w, 6), makeRect(120 - w, 91, w, 6));
    w = width(p1.shownLife);
    if (w > 0) objBlit(makeRect(138 - w, 18, w, 6), makeRect(120 - w, lifeY(p1, w), w, 6));
    w = width(p2.redLife);
    if (w > 0) objBlit(makeRect(182, 18, w, 6), makeRect(120, 91, w, 6));
    w = width(p2.shownLife);
    if (w > 0) objBlit(makeRect(182, 18, w, 6), makeRect(120, lifeY(p2, w), w, w >= 40 ? 6 : 8));
    const n = gs.winRounds;
    const p1x = [
        123,
        131,
        139
    ];
    const p2x = [
        190,
        182,
        174
    ];
    for(let k = 0; k < 3; k++){
        if (n >= k + 1) {
            objBlit(makeRect(p1x[k], 33, 7, 13), makeRect(83, 147, 7, 13));
            objBlit(makeRect(p2x[k], 33, 7, 13), makeRect(83, 147, 7, 13));
        }
    }
    for(let k = 0; k < 3; k++){
        if (p1.wins >= k + 1) objBlit(makeRect(p1x[k], 33, 7, 13), makeRect(76, 147, 7, 13));
        if (p2.wins >= k + 1) objBlit(makeRect(p2x[k], 33, 7, 13), makeRect(76, 147, 7, 13));
    }
    drawNumber(169, 9, view.fps, 0, 2, false);
}
export function drawBottomHud(view) {
    if (gs.specialTimerC > 0) return;
    const chars = gs.chars;
    objBlit(makeRect(0, 206, 320, 33), makeRect(0, 40, 320, 33));
    for(let i = 0; i < 2; i++){
        const c = chars[i];
        const m = c.meter << 16 >> 16;
        const w = Math.trunc(m * 108 / 3000);
        let y;
        let icon = -1;
        if (m < 1000) {
            y = 115;
        } else if (m < 2000) {
            y = 119;
            icon = 0;
        } else if (m < 3000) {
            y = 123;
            icon = 24;
        } else {
            y = Math.trunc(c.cycle % 90 / 18) * 4 + 127;
            icon = 48;
        }
        if (icon >= 0) objBlit(i === 0 ? makeRect(6, 209, 24, 24) : makeRect(290, 209, 24, 24), makeRect(icon, 148, 24, 24));
        if (i === 0) objBlit(makeRect(140 - w, 224, w, 4), makeRect(108 - w, y, w, 4));
        else objBlit(makeRect(180, 224, w, 4), makeRect(108, y, w, 4));
        const g = c.rfGauge;
        const bar = (gw, srcY)=>{
            if (i === 0) objBlit(makeRect(139 - gw, 232, gw, 2), makeRect(60 - gw, srcY, gw, 2));
            else objBlit(makeRect(181, 232, gw, 2), makeRect(60, srcY, gw, 2));
        };
        if (c.rfBlue === 0) {
            if (g < 500) {
                bar(Math.trunc(60 * g * 2 / 1000), 102);
            } else {
                if (i === 0) objBlit(makeRect(79, 232, 60, 2), makeRect(0, 102, 60, 2));
                else objBlit(makeRect(181, 232, 60, 2), makeRect(60, 102, 60, 2));
                bar(Math.trunc((g - 500) * 60 * 2 / 1000), 100);
            }
        } else {
            bar(Math.trunc(60 * g / 1000), Math.trunc(c.cycle % 90 / 18) * 2 + 104);
        }
    }
    if (gs.roundOver !== 0) return;
    for (const c of chars){
        const X = Math.trunc(c.x) + view.camX;
        const yb = view.camY + Math.trunc(c.y) + GROUND_Y - (c.y < 0 ? 1 : 0);
        const v = c.hitstun << 16 >> 16;
        const flags = c.currentHit()?.attackFlags ?? 0;
        if (v > 0 && c.d128 === 0 && c.y < 0 && c.state >= 50 && c.state < 150 && !(flags & 0x400)) {
            const len = v < 100 ? v : 100;
            const col = 211 - (v > 30 ? 3 : 0) - (v > 60 ? 7 : 0);
            for(let k = 0; k < 3; k++){
                const L = c.facing === 1 ? X + k : X - len - k;
                const T = yb + k;
                fillRect({
                    left: L,
                    top: T,
                    right: L + len,
                    bottom: T + 1
                }, col);
                fillRect({
                    left: L,
                    top: T + 2,
                    right: L + len,
                    bottom: T + 3
                }, 194);
            }
        }
        if (c.guardGauge !== 0 && c.isGuarding()) {
            const lenF = Math.fround(Math.fround(c.guardGauge * 100) / 360);
            for(let k = 0; k < 3; k++){
                const L = c.facing === 1 ? X + k : Math.trunc(X - lenF - k);
                const R = Math.trunc(L + lenF);
                const T = yb + k;
                fillRect({
                    left: L,
                    top: T,
                    right: R,
                    bottom: T + 1
                }, 220);
                fillRect({
                    left: L,
                    top: T + 2,
                    right: R,
                    bottom: T + 3
                }, 194);
            }
        }
    }
}
export function drawComboPanel(_view, c) {
    const hits = Math.min(c.comboDisplay << 16 >> 16, 99);
    const fade = c.comboTimer << 16 >> 16 <= 6;
    const right = c.side > 0;
    objBlit(right ? makeRect(258, 63, 61, 38) : makeRect(6, 63, 61, 38), makeRect(0, 172, 61, 38), fade);
    drawNumber(right ? 286 : 34, 59, hits, 1, 0, fade);
    drawNumber(right ? 285 : 33, 82, c.comboDamage, 2, 0, fade);
    drawNumber(right ? 275 : 23, 92, Math.trunc(c.dblF8), 2, 0, fade);
    drawNumber(right ? 285 : 33, 92, Math.trunc(c.dblF8 * 10.0) % 10, 2, 0, fade);
    objBlit(makeRect(right ? 275 : 23, 92, 3, 9), makeRect(70, 225, 3, 9), fade);
}
export function drawFinalMask(view) {
    let sx = -view.camX;
    let sy = 240 - view.camY;
    let dx = 0;
    let dy = 0;
    if (sx > 320) {
        dx = 320 - sx;
        sx = 320;
    } else if (sx < 0) {
        dx = -sx;
        sx = 0;
    }
    if (sy > 240) {
        dy = 240 - sy;
        sy = 240;
    } else if (sy < 0) {
        dy = -sy;
        sy = 0;
    }
    fillRect(makeRect(0, dy < 0 ? dy + 240 : 0, 320, Math.abs(dy)), 0);
    fillRect(makeRect(dx < 0 ? dx + 320 : 0, dy >= 0 ? dy : 0, Math.abs(dx), 240 - Math.abs(dy)), 0);
    view.applyPalette();
    present();
}

export function __logicState(){return {FONTS};}
