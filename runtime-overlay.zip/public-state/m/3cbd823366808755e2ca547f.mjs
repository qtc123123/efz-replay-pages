import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./f72d22da4bca50f9c6c4bb45.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame, setPolarVelocity } from "./3a3de9c9ca972e4115fbd40f.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function stepFrame(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    return true;
}
function endToNeutral(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function bodyEffectPos(c, d, offX, offY) {
    d.x = ftol(c.x) + c.facing * offX;
    d.y = ftol(c.y) - offY;
}
function groundSuper(c, cost, effPat, effSound, spawnMax, loopMax, is302) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 3 && c.timer === 0) {
        c.stopMotion();
        superFreeze(c, cost);
        d.w04 = effPat;
        d.b2c = effSound;
        bodyEffectPos(c, d, -0xe, 0x32);
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        if (is302) c.seRequest = 0x25;
    }
    if (is302 && c.frame > 2) c.showAltBackground(0xf);
    if (c.frame > 2) c.biasCameraY(0x32, 3);
    if (c.frame === 5 && c.timer === 0 && c.f313c < spawnMax) {
        d.d00 = 1;
        d.w04 = c.f3138 + 0x19b & 0xffff;
        const base = ftol(c.x);
        d.x = base - (c.random(0, 0x14) + c.f313c * 8 + 0x154) * c.facing;
        d.y = 4 - c.random(0, 4);
        d.d28 = 1;
        d.b18 = c.facing;
        d.b20 = 0;
        d.b21 = 1;
        c.f3138++;
        if (c.f3138 > 5) c.f3138 = 0;
        frameChild(c, d);
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 7 && c.f313c < loopMax) {
        c.frame -= 2;
        c.f313c++;
    }
    endToNeutral(c, cnt);
}
function catchSuper(c, cost, effPat, effSound, next, is305) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame === 7 && c.timer === 0) {
        superFreeze(c, cost);
        d.w04 = effPat;
        d.b2c = effSound;
        bodyEffectPos(c, d, 0, 0x28);
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        c.biasCameraY(0x32, 0x2d);
        if (is305) c.seRequest = 0x25;
    }
    if (is305 && c.frame > 6) c.showAltBackground(0xf);
    if (c.frame === 8 && c.timer === 0) {
        d.w04 = 0x1b8;
        d.d28 = 1;
        d.x = ftol(c.opponent.x);
        d.y = -480.0;
        d.b18 = c.facing;
        d.b20 = 0;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (c.frame > 7 && c.f3448 === 1) {
        c.screenFlash(1, 9, 0x50, 9);
        c.onStateChange();
        c.state = next;
        return;
    }
    if (!stepFrame(c, dur)) return;
    endToNeutral(c, cnt);
}
function catchSetup(c) {
    const o = c.opponent;
    c.f3448 = 2;
    c.x = 230.0;
    c.facing = 1;
    o.state = 0x7a;
    o.facing = 1;
    o.onStateChange();
    o.stopMotion();
    o.x = 420.0;
    o.y = -17.0;
}
function spawnCatchShot(c, d, pat) {
    d.w04 = pat;
    d.b20 = 0;
    d.x = c.x + 20.0;
    d.y = -50.0;
    d.d00 = 1;
    d.b21 = 0;
    d.b18 = c.facing;
    frameChild(c, d);
}
function state306(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.biasCameraY(0x32, 0xf);
    if (c.frame === 1 && c.timer === 0) catchSetup(c);
    if (c.frame === 6 && c.timer === 0) c.voiceRequest = 2;
    if (c.frame === 0xa && c.timer === 0) {
        c.voiceRequest = 3;
        spawnCatchShot(c, d, 0x1c6);
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 0x11 && (c.f3448 === 2 || c.f3448 === 4 || c.f313c > 0)) {
        c.frame -= 3;
        c.f313c--;
    }
    if (c.frame === 0x11 && c.f3448 === 5) c.frame = 0x15;
    if (c.frame >= cnt) {
        c.state = 0;
        c.f3448 = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state307(c, is308) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.biasCameraY(0x32, 0xf);
    if (is308) c.showAltBackground(0xf);
    if (c.frame === 1 && c.timer === 0) catchSetup(c);
    if (c.frame === 1 && c.timer === 0) {
        d.w04 = 0x1b7;
        d.x = ftol(c.x) + c.facing * 0x10;
        d.y = 0.0;
        d.b20 = 0;
        d.d00 = 1;
        d.d28 = 1;
        d.b21 = 0;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.frame === 6 && c.timer === 0) c.voiceRequest = 2;
    if (c.frame === 0x10 && c.timer === 0) {
        c.voiceRequest = 3;
        let pat = 0x1c6;
        if (c.f3138 === 1) pat = 0x1c7;
        if (c.f3138 === 2) pat = 0x1c5;
        spawnCatchShot(c, d, pat);
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 0xa) c.frame = 0x10;
    if (c.frame === 0xd) c.frame = 0x10;
    if (c.frame === 7) {
        if (c.f3138 === 1) c.frame = 0xa;
        if (c.f3138 === 2) c.frame = 0xd;
    }
    if (c.frame === 0x17 && (c.f3448 === 2 || c.f3448 === 4 || c.f313c > 0)) {
        c.frame -= 3;
        c.f313c--;
    }
    if (c.frame === 0x1e) {
        c.frame = 2;
        c.f3448 = 2;
        c.f3138++;
    }
    if (c.frame === 0x1b && c.f3138 === (is308 ? 2 : 1)) c.frame = 0x1e;
    if (c.frame === 0x17 && c.f3448 === 5) c.frame = 0x1e;
    if (c.frame >= cnt) {
        c.state = 0;
        c.f3448 = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state309(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.startAfterimage(2);
    if (c.frame < 6) c.biasCameraY(0x32, 3);
    if (c.frame < 0xe && o.state === 0x63) o.onStateChange();
    if (c.frame > 8) {
        if (c.vy + c.y > 0.0 && c.frame < 0xe) {
            c.y = 0.0;
            c.frame = 0xe;
            c.timer = 0;
            c.stopMotion();
            c.shakeScreen(0xf, 0xa);
            c.seRequest = 0x16;
            applyDirectDamage(c, 0x320, 900.0);
            o.onStateChange();
            o.state = 0x62;
            d.w04 = 0x190;
            d.x = ftol(c.x);
            d.y = ftol(c.y);
            d.b20 = 2;
            d.b21 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
            d.w04 = 0;
            frameEffect(d);
            o.hitstop = 0xb4;
            return;
        }
        c.vy = c.vy + c.ay;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 1) {
        o.onStateChange();
        o.state = 0x67;
        o.y = -98.0;
        o.x = c.facing * 0x23 + c.x;
    }
    if (c.frame === 2) {
        o.y = -98.0;
        o.x = c.facing * 0x21 + c.x;
        if (c.f3138 > 0) c.timer = 0x96;
    }
    if (c.frame === 3) {
        o.y = 0.0;
        o.x = c.facing * 0x21 + c.x;
        o.facing = -c.facing;
        o.onStateChange();
        o.state = 0x61;
        o.d12c = 1;
        applyDirectDamage(c, 0x12c, 980.0);
        if (o.life <= 0) o.life = 1;
    }
    if (c.frame === 6 && c.f3138 < 3) {
        c.f3138++;
        c.frame = 0;
    }
    if (c.frame === 9) {
        c.vy = -7.0;
        c.vx = 0.3;
        c.ay = 0.15;
    }
    c.d168 = 0;
    endToNeutral(c, cnt);
}
function grabCamera(c) {
    if (c.frame < 7) {
        c.biasCameraY(0x32, 0x2d);
        c.opponent.hitstop = 3;
    }
    if (c.frame === 7) c.biasCameraY(0, 0);
}
function grabHitEffect(c, d) {
    if (c.frame === 3 || c.frame === 6) {
        d.w04 = 0;
        d.b2c = 2;
        bodyEffectPos(c, d, 0x1d, 0x53);
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
    }
}
function grabHold(c, d) {
    const o = c.opponent;
    if (c.frame === 1) {
        o.state = 0x67;
        o.onStateChange();
        o.y = -101.0;
        o.x = c.facing * 0x15 + c.x;
    }
    if (c.frame === 2) {
        o.y = -99.0;
        o.x = c.facing * 0xf + c.x;
        c.seRequest = 0x16;
        d.w04 = 0x193;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0xfa;
        d.b20 = 2;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
    }
    for (const [f, s] of [
        [
            3,
            0x64
        ],
        [
            4,
            0x67
        ],
        [
            5,
            0x64
        ],
        [
            6,
            0x67
        ]
    ]){
        if (c.frame === f) {
            o.state = s;
            o.y = -99.0;
            o.x = c.facing * 0xf + c.x;
        }
    }
}
function state310(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) o.onStateChange();
    if (c.frame === 1 && c.timer === 0) {
        c.stopMotion();
        superFreeze(c, 0xbb8);
        d.w04 = 9;
        d.b2c = 5;
        bodyEffectPos(c, d, 0x17, 0x1e);
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        c.biasCameraY(0x32, 0x2d);
    }
    grabCamera(c);
    if (!stepFrame(c, dur)) return;
    grabHitEffect(c, d);
    grabHold(c, d);
    if (c.frame === 7 && c.f3138 > 0xa) {
        o.state = 0x3e;
        o.knockX = 0.0;
        o.knockY = -5.0;
        o.ay = 0.035;
        applyDirectDamage(c, 0xdac, 700.0);
        o.hitstun = 0xb4;
    }
    if (c.frame === 7 && c.f3138 < 0xb) {
        c.f3138++;
        c.frame = 2;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
        c.faceOpponent();
    }
}
function state311(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) o.onStateChange();
    grabCamera(c);
    if (!stepFrame(c, dur)) return;
    grabHitEffect(c, d);
    grabHold(c, d);
    if (c.frame === 7 && c.f3138 > 8) {
        o.onStateChange();
        o.state = 0x3f;
        o.knockX = 0.2;
        o.knockY = -1.9;
        applyDirectDamage(c, 0x3e8, 1000.0);
        c.w16c = 1;
    }
    if (c.frame === 7 && c.f3138 < 9) {
        c.f3138++;
        c.frame = 2;
    }
    if (c.frame === 0x10) {
        d.w04 = 0x1f;
        d.x = ftol(c.x);
        d.y = ftol(c.y) + 4;
        d.b20 = 0;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 1;
        frameEffect(d);
        d.w04 = 0x191;
        d.x = ftol(c.x) + c.facing * 0x28;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b18 = c.facing;
        d.d00 = 1;
        d.b21 = 1;
        frameChild(c, d);
        c.shakeScreen(0xa, 0x3c);
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
        c.faceOpponent();
    }
}
function spawnImpact(c, d, pat, offX) {
    d.w04 = 0x1f;
    d.x = ftol(c.x);
    d.y = ftol(c.y) + 4;
    d.b20 = 0;
    d.d00 = 1;
    d.b18 = c.facing;
    d.b21 = 1;
    frameEffect(d);
    d.w04 = pat;
    d.x = ftol(c.x) + c.facing * offX;
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b18 = c.facing;
    d.d00 = 1;
    d.b21 = 1;
    frameChild(c, d);
}
function state312(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 2;
    }
    if (c.frame === 6 && c.timer === 0) {
        c.biasCameraY(0x32, 0x2d);
        c.freeze = 0x78;
        c.superDarken(0xb0, 3);
        d.w04 = 9;
        d.b2c = 5;
        bodyEffectPos(c, d, 0x17, 0x1e);
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
    }
    if (c.frame === 2 && c.timer === 0) spawnImpact(c, d, 0x192, 0x2d);
    if (c.frame === 8 && c.timer === 0) spawnImpact(c, d, 0x191, 0x28);
    if (c.frame === 2 && c.d168 === 3) {
        c.shakeScreen(6, 0x3c);
        c.opponent.hitstop = 0x1f4;
    }
    if (c.frame === 0xa && c.timer === 0) c.shakeScreen(0xa, 0x3c);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.d168 !== 3 && c.frame === 6) c.frame = 0xc;
    if (c.frame === 9 || c.frame === 1) c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state313(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        if (c.frame === 1 && c.timer === 0) c.meter = s16(c.meter - 0xbb8);
        c.biasCameraY(0x32, 0x2d);
        c.freeze = 0x78;
        c.superDarken(0xb0, 3);
        d.w04 = 9;
        d.b2c = 5;
        bodyEffectPos(c, d, 0x17, 0x1e);
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
    }
    if (c.d168 === 6) {
        c.onStateChange();
        c.frame = 2;
        c.d168 = 0;
        c.freeze = 0x78;
        return;
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 2) {
        c.frame = 3;
        return;
    }
    if (c.frame === 3) {
        c.onStateChange();
        c.state = 0x138;
        return;
    }
    endToNeutral(c, cnt);
}
function state314(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 1 && c.timer === 0) {
        c.stopMotion();
        superFreeze(c, 0xbb8);
        d.w04 = 0x46;
        d.b2c = 0x40;
        bodyEffectPos(c, d, -0x17, 0x33);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameEffect(d);
        d.w04 = 0x47;
        frameEffect(d);
        c.f3138++;
        c.seRequest = 0x25;
        c.w16c = 1;
    }
    if (c.frame > 0) c.showAltBackground(0xf);
    if (c.frame > 0) c.biasCameraY(0x32, 3);
    if (c.frame > 2 && c.frame < 8) {
        c.vy = c.vy + c.ay;
        if (c.frame === 7 && c.vy + c.y > 0.0) {
            c.timer = 0;
            c.frame = 9;
            c.y = 0.0;
            c.stopMotion();
            return;
        }
    }
    if (c.frame === 0xc && c.timer === 0 && c.d168 === 3) c.screenFlash(1, 9, 0xf, 9);
    if (c.frame === 0xd && c.timer === 0 && c.d168 === 3) {
        c.onStateChange();
        c.state = 0x13b;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 1) c.d168 = 0;
    if (c.frame === 3) {
        c.vx = 2.0;
        c.vy = -2.0;
        c.ay = 0.08;
    }
    endToNeutral(c, cnt);
}
function spawn315Center(c, d, pat) {
    d.w04 = pat;
    d.x = 320.0;
    d.y = 200.0;
    d.b20 = 0;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function spawn315Side(c, d, pat) {
    d.w04 = pat;
    d.x = c.x - c.facing * 0xf0;
    d.y = -20.0;
    d.b20 = 0;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function state315(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.w13e = 3;
    if (o.state === 0x63) o.timer = 0;
    if (c.frame < 2) c.superDarken(0xb0, 3);
    if (c.frame < 2) c.biasCameraY(0x32, 3);
    if (c.frame < 2) c.biasCamera(0x32, 3);
    if (c.frame === 0 && c.timer === 0) {
        c.x = 320.0;
        c.stopMotion();
        d.w04 = 0x1b2;
        d.d24 = 1;
        d.x = 0.0;
        d.y = 0.0;
        d.b20 = 0;
        d.b21 = 0;
        d.b18 = 1;
        frameChild(c, d);
        d.d24 = 0;
        spawn315Center(c, d, 0x1a5);
        o.x = 320.0;
        o.y = -160.0;
        o.onStateChange();
        o.stopMotion();
        o.state = 0x3b;
    }
    if (c.frame === 0) {
        c.f3138++;
        if (c.f3138 === 0x50) spawn315Center(c, d, 0x1a6);
        if (c.f3138 === 0xa0) spawn315Center(c, d, 0x1a7);
        if (c.f3138 === 0xf0) spawn315Center(c, d, 0x1a8);
        if (c.f3138 === 0x140) spawn315Center(c, d, 0x1a9);
        if (c.f3138 === 0x190) spawn315Center(c, d, 0x1aa);
    }
    if (c.frame === 0 && c.timer === dur - 0x1e) {
        c.screenFlash(-1, 9, 0x1e, 9);
        c.f3138 = 0;
        o.x = 320.0;
        o.y = 0.0;
        o.state = 0x79;
        o.onStateChange();
        o.stopMotion();
    }
    if (c.frame === 1) {
        c.f3138++;
        if (c.f313c > 0) {
            c.frame = 2;
            c.timer = 0;
            c.facing = -o.facing;
            c.x = c.f313c;
            c.y = c.f3140;
            c.vx = -0.9;
            c.vy = -1.5;
        }
        if (c.f3138 === 0x96) spawn315Side(c, d, 0x1b6);
        if (c.f3138 === 0xae) spawn315Side(c, d, 0x1ac);
        if (c.f3138 === 0xc6) spawn315Side(c, d, 0x1ad);
        if (c.f3138 === 0xde) spawn315Side(c, d, 0x1ae);
        if (c.f3138 === 0xf6) spawn315Side(c, d, 0x1af);
        if (c.f3138 === 0x10e) spawn315Side(c, d, 0x1b0);
    }
    if (c.frame > 1) {
        c.vy = c.vy + 0.035;
        if (c.vy + c.y > 0.0) {
            c.onStateChange();
            c.stopMotion();
            c.state = 0xd;
            c.y = 0.0;
            return;
        }
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame >= cnt) c.frame -= 2;
}
function state316(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 4 && c.timer === 0 && c.f3138 === 0) {
        c.stopMotion();
        superFreeze(c, 0xbb8);
        d.w04 = 0x46;
        d.b2c = 0x40;
        bodyEffectPos(c, d, -0xe, 0x32);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameEffect(d);
        d.w04 = 0x47;
        frameEffect(d);
        c.f3138++;
        c.seRequest = 0x25;
    }
    if (c.frame > 3) c.showAltBackground(0xf);
    c.biasCameraY(0x32, 3);
    if (c.frame === 9 && c.timer === 0) {
        d.d00 = 1;
        d.w04 = 0x1c4;
        d.x = ftol(c.x) + c.facing * 0x50;
        d.y = 15.0;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 7 && c.f3138 < 6) {
        c.frame -= 3;
        c.f3138++;
    }
    endToNeutral(c, cnt);
}
registerStates({
    300: (c)=>groundSuper(c, 0x3e8, 0x44, 0x13, 7, 0xa, false),
    301: (c)=>groundSuper(c, 0x7d0, 0x45, 5, 0x11, 0x14, false),
    302: (c)=>groundSuper(c, 0xbb8, 0x46, 0x40, 0x23, 0x23, true),
    303: (c)=>catchSuper(c, 0x3e8, 0x44, 0x13, 0x132, false),
    304: (c)=>catchSuper(c, 0x7d0, 0x45, 5, 0x133, false),
    305: (c)=>catchSuper(c, 0xbb8, 0x46, 0x40, 0x134, true),
    306: state306,
    307: (c)=>state307(c, false),
    308: (c)=>state307(c, true),
    309: state309,
    310: state310,
    311: state311,
    312: state312,
    313: state313,
    314: state314,
    315: state315,
    316: state316
});
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function child421(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        if (c.a3148[i] === 0) {
            ch.vy = -1.1;
            ch.vx = 0.3;
            c.a3148[i]++;
        }
    }
    if (c.frame === 1 && c.f3138 === 0x1e) c.freeChild(i);
    ch.vx = ch.vx - 0.002;
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) ch.frame = 0;
}
function child428(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vy = 0.5;
        ch.vx = 2.5;
    }
    if (c.f3140 === 1 && c.a3348[i] === 0) {
        ch.hitsLeft = 1;
        c.a3148[i] = ftol(ch.vx * 100.0);
        c.a3248[i] = ftol(ch.vy * 100.0);
        c.a3348[i] = 1;
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    if (c.f3140 === 0 && c.a3348[i] === 1) {
        ch.hitsLeft = 1;
        ch.vx = c.a3148[i] * 0.01;
        ch.vy = c.a3248[i] * 0.01;
        c.a3348[i] = 2;
    }
    if (c.frame > 1) c.freeChild(i);
    if (c.f3140 !== 1) ch.vy = ch.vy - 0.01;
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child434(c, i) {
    const ch = c.children[i];
    if (c.frame === 1) c.freeChild(i);
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) ch.frame = 0;
}
function child438(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vy = 0.5;
        ch.vx = 2.5;
    }
    if (ch.frame === 2 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.a3148[i] = ftol(ch.vx * 100.0);
        c.a3248[i] = ftol(ch.vy * 100.0);
        ch.vx = 0.0;
        ch.vy = 0.0;
        o.state = 0x45;
        o.y = ch.y - 81.0;
        o.x = ch.x;
        o.onStateChange();
        o.stopMotion();
        o.knockX = -6.0;
        o.knockY = 4.0;
        o.facing = -ch.facing;
    }
    if (ch.frame === 2 || ch.frame === 3) c.f3138--;
    if (o.y === 0.0 && c.a3348[i] === 0 && ch.frame === 2) {
        applyDirectDamage(c, 0x170c, 500.0);
        c.a3348[i]++;
        c.seRequest = 0x16;
    }
    if (o.state === 0x63) o.timer = 0;
    if (ch.frame === 4 && ch.timer === 0) {
        ch.vx = c.a3148[i] * 0.01;
        ch.vy = c.a3248[i] * 0.01;
    }
    if (ch.frame === 4 && ch.timer === childDuration - 0xc) {
        if (c.wins === 0 || c.wins === 1 && o.life > 0) c.screenFlash(1, 9, 3, 0xc);
    }
    if (ch.frame !== 2) ch.vy = ch.vy - 0.01;
    if (!childStep(c, i)) return;
    if (ch.frame === 2) c.f3140 = 1;
    if (ch.frame === 4) c.f3140 = 0;
    if (ch.frame >= childCount) {
        c.freeChild(i);
        c.f313c = ftol(ch.x);
        c.f3140 = ftol(ch.y - 130.0);
    }
}
function child439(c, i) {
    const ch = c.children[i];
    const s = c.state;
    if (s === 0x132 || s === 0x133 || s === 0x134) {
        if (c.frame === 0x1c) ch.frame = 2;
        if (c.frame !== 0x1c && ch.frame === 2) ch.frame = 1;
    }
    if (s < 0x132 || s > 0x134) {
        if (ch.frame < 4) {
            ch.frame = 4;
            ch.timer = 0;
        }
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame >= childCount) c.freeChild(i);
}
function at440(f, t, t1, t2) {
    return (f === 8 || f === 0xb) && t === t1 || f === 0xe && t === t2;
}
function child440(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    const s = c.state;
    if (s < 0x132 || s > 0x134) c.f3448 = 0;
    if (ch.frame === 9) o.frame = 1;
    if (ch.frame === 0xa) o.frame = 2;
    if (ch.frame === 0xc) o.frame = 3;
    if (ch.frame === 0xd) o.frame = 4;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vy = 1.5;
        c.voiceRequest = 5;
    }
    if (ch.frame === 0) {
        ch.vy = ch.vy + 0.035;
        if (ch.hitState === 3 && o.life > 0) {
            ch.layer = 0;
            c.f3448 = 1;
            ch.hitstop = 0x3c;
            o.hitstop = 0x3c;
            ch.hitState = 0;
            return;
        }
        if (ch.y + ch.vy > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.frame = 1;
            ch.timer = 0;
        }
    }
    if (ch.frame === 2 && ch.timer === 0) ch.vy = -0.8;
    if (ch.frame === 2 || ch.frame === 3) {
        ch.vy = ch.vy + 0.035;
        if (ch.vy + ch.y > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.frame = 4;
            ch.timer = 0;
        }
    }
    if (s === 0x132 || s === 0x133 || s === 0x134) {
        if (ch.frame === 1 && ch.timer === 0) {
            ch.x = 420.0;
            ch.frame = 7;
            ch.timer = 0;
            ch.facing = c.facing;
        }
        if (ch.frame === 7 && c.f344c === 1) {
            ch.frame = 8;
            ch.timer = 0;
            return;
        }
        if (ch.frame === 0xa && c.f344c === 1) {
            ch.frame = 0xb;
            ch.timer = 0;
            return;
        }
        if (ch.frame === 0xd && c.f344c === 1) {
            ch.frame = 0xe;
            ch.timer = 0;
            return;
        }
        if (c.f344c === 1 && (ch.frame === 8 || ch.frame === 0xb || ch.frame === 0xe)) {
            ch.hitstop = 0x1e;
            o.hitstop = 0x1e;
            c.f344c = 0;
            if (ch.frame === 0xe) c.voiceRequest = 9;
        }
        if (at440(ch.frame, ch.timer, 0xd2, 0x294)) {
            if (c.random(0, 9) < 5) {
                c.voiceRequest = 6;
                c.f3448 = 3;
                ch.timer++;
                return;
            }
            c.voiceRequest = 7;
            c.f3448 = 4;
        }
        if (at440(ch.frame, ch.timer, 0x14a, 0x30c)) {
            if (c.f3448 === 4) {
                const d = childSpawnFrame;
                d.w04 = 0;
                d.x = ftol(o.x);
                d.y = -80.0;
                d.b20 = 2;
                d.b21 = 1;
                d.b2c = 0x16;
                frameEffect(d);
                c.f3448 = 5;
                ch.layer = 1;
                o.state = 0x47;
                o.onStateChange();
                o.knockY = -13.0;
                o.knockX = 0.0;
                if (ch.frame === 8) {
                    applyDirectDamage(c, 0x708, 50.0);
                    ch.frame = 0xf;
                }
                if (ch.frame === 0xb) {
                    applyDirectDamage(c, 0xdac, 50.0);
                    ch.frame = 0x12;
                }
                if (ch.frame === 0xe) {
                    applyDirectDamage(c, 0x1964, 50.0);
                    ch.frame = 0x15;
                }
                ch.timer = 0;
                c.f313c = 0xb;
            }
            if (c.f3448 === 3) {
                if (s === 0x132 || s === 0x133 && c.f3138 === 1 || s === 0x134 && c.f3138 === 2) {
                    ch.blend = 1;
                    o.state = 0x3b;
                    o.onStateChange();
                    o.knockY = -2.0;
                    o.knockX = 0.0;
                }
            }
        }
        if (at440(ch.frame, ch.timer, 0x159, 0x31b)) {
            if (ch.blend === 1) {
                c.freeChild(i);
                return;
            }
        }
        if (s === 0x133 || s === 0x134) {
            if (c.frame === 0x1c && c.timer === 0) {
                c.voiceRequest = 8;
                ch.timer = 0;
                ch.frame++;
            }
        }
    }
    ch.timer++;
    const last = ch.frame === 0x11 || ch.frame === 0x14 || ch.frame === 0x17;
    if (last && ch.timer === childDuration - 0xf) ch.blend = 1;
    if (last && ch.timer === childDuration) {
        c.freeChild(i);
        c.f3448 = 5;
        return;
    }
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 6) ch.blend = 1;
    if (ch.frame === 7) c.freeChild(i);
    if (ch.frame >= childCount) c.freeChild(i);
}
function child452(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 4;
    }
    if (ch.frame === 4 && ch.timer === 0 && c.frame < 0xc && c.a3148[i] === 2) {
        const d = childSpawnFrame;
        d.w04 = 0x1c4;
        d.x = ftol(ch.x) + ch.facing * 0x3c;
        d.y = ch.y;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 5 && c.a3148[i] < 4) {
        c.a3148[i]++;
        ch.frame -= 2;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child453(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) setPolarVelocity(c, i, 0.0, 3.6);
    if (ch.x > 370.0) {
        const d = childSpawnFrame;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x14;
        d.y = ftol(ch.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b2c = 2;
        frameEffect(d);
        c.freeChild(i);
        c.f344c = 1;
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 1) ch.frame -= 1;
    if (ch.frame >= childCount) ch.frame = 0;
}
registerChildren({
    421: child421,
    422: child421,
    423: child421,
    424: child421,
    425: child421,
    426: child421,
    428: child428,
    429: child428,
    430: child428,
    431: child428,
    432: child428,
    434: child434,
    438: child438,
    439: child439,
    440: child440,
    452: child452,
    453: child453,
    454: child453,
    455: child453
});
