import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerStates } from "./1f5919024557a92ec3a28767.mjs";
import { frameEffect, openSpawnFrame } from "./6bb9439be7e0aefdefc21b73.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function advanceEx(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur - (c.exOn() << 1)) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function jumpTo(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function groundJumpCancel(c, ok) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && ok) {
        jumpTo(c);
        return true;
    }
    return false;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a === 0) {
        c.faceOpponent();
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function groundSlide(c) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx -= 0.03;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(99);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.life > 0 && c.timer > 99 && c.frame === 0) {
        c.setState(96);
        c.b158 = 0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(96);
    }
}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        c.b158 = 0;
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy += c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy += c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.startAfterimage(3);
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo(c);
        return;
    }
    if (atStart(c)) {
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.vx = c.exOn() * 0.2 + 1.7;
    c.b158 = 1;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur - (c.exOn() << 1)) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) {
            c.frame = 0;
            return;
        }
    }
    if (c.inputX === c.facing && c.f313c >= 120) c.setState(178);
    if (c.inputX !== c.facing && c.f3138 >= 60) c.setState(178);
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(2);
    c.b158 = 0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) {
        c.vx = -1.6 - c.exOn() * 0.2;
        c.vy = -1.0;
        c.ay = 0.04;
    }
    if (c.y < 0.0) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 9) {
        c.seRequest = 9;
        c.stopMotion();
        c.y = 0.0;
        c.frame = 9;
        c.timer = 0;
        return;
    }
    if (advanceEx(c, dur)) {
        if (c.frame === 9) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) c.setState(0);
    }
}
function airDashEnd(c, vx) {
    c.setState(9);
    c.vx = vx;
    c.ay = 0.03;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function airDashTick(c, dur, cnt) {
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur - (c.exOn() << 1)) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.seRequest = 21;
        if (c.f3138 === 0) {
            c.vx = c.exOn() * 0.2 + 1.5;
            c.startAfterimage(3);
            c.vy = 0.0;
            c.ay = 0.0;
        }
    }
    airDashTick(c, dur, cnt);
    if (c.inputX === c.facing && c.f313c >= 100) airDashEnd(c, 1.3);
    if (c.inputX !== c.facing && c.f3138 >= 48) airDashEnd(c, 1.3);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.seRequest = 21;
        if (c.f3138 === 0) {
            c.vx = -1.5 - c.exOn() * 0.2;
            c.vy = 0.0;
            c.ay = 0.0;
            c.startAfterimage(3);
        }
    }
    airDashTick(c, dur, cnt);
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9);
    if (c.inputX !== -c.facing && c.f3138 >= 40) airDashEnd(c, -0.9);
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.b158 = 0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx -= 0.03;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 9) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 9;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 2) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 9) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function groundNormalAdvance(c, dur, cnt, crouchable) {
    if (advanceEx(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, crouchable);
    }
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundSlide(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) c.w16c = 1;
    if (atFrame(c, 1)) {
        addMeter(c, 5);
        c.seRequest = 21;
    }
    groundNormalAdvance(c, dur, cnt, false);
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundSlide(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) {
        addMeter(c, 15);
        c.seRequest = 20;
        c.w16c = 1;
    }
    groundNormalAdvance(c, dur, cnt, false);
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundSlide(c);
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atFrame(c, 2)) {
        addMeter(c, 15);
        c.seRequest = 20;
        c.w16c = 1;
    }
    if (advanceEx(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 3) c.x = c.facing * 10 + c.x;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.b158 === 0 && c.frame < 2) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1 && c.frame < 2) {
        c.vx -= 0.06;
    } else {
        c.b158 = 0;
    }
    if (atFrame(c, 2)) {
        addMeter(c, 35);
        c.seRequest = 20;
        c.w16c = 1;
        c.vx = 2.0;
    }
    if (c.frame > 2 && c.vx > 0.0) {
        c.vx -= 0.08;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (advanceEx(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundSlide(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) {
        addMeter(c, 5);
        c.seRequest = 21;
        c.w16c = 1;
    }
    groundNormalAdvance(c, dur, cnt, true);
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundSlide(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 2)) {
        addMeter(c, 13);
        c.seRequest = 20;
        c.w16c = 1;
    }
    groundNormalAdvance(c, dur, cnt, true);
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundSlide(c);
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atFrame(c, 2)) {
        addMeter(c, 25);
        c.seRequest = 20;
        c.w16c = 2;
    }
    if (advanceEx(c, dur)) {
        if (c.frame < 6) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function airNormal(c, startFrame, meter, se, endJump) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, startFrame)) {
        addMeter(c, meter);
        c.seRequest = se;
        c.w16c = 1;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return;
    }
    if (advanceEx(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) {
            if (endJump) {
                c.setState(4);
                c.frame = 7;
            } else {
                c.setState(9);
            }
        }
    }
}
const s207 = (c)=>airNormal(c, 2, 5, 21, false);
const s208 = (c)=>airNormal(c, 3, 13, 20, true);
const s209 = (c)=>airNormal(c, 4, 30, 20, true);
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 3)) c.vx = 3.0;
    c.vx -= 0.055;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atFrame(c, 4)) {
        addMeter(c, 20);
        c.seRequest = 20;
        c.w16c = 1;
    }
    if (advanceEx(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 3)) {
        addMeter(c, 30);
        c.seRequest = 20;
        c.w16c = 1;
    }
    if (advanceEx(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function impactFx(c, d) {
    c.shakeScreen(3, 0);
    d.w04 = 3;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 0;
    d.b2c = 7;
    frameEffect(d);
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vy += c.ay;
    if (atStart(c)) {
        addMeter(c, 30);
        c.seRequest = 20;
        c.w16c = 1;
        c.vx = c.vx / 2.0;
        c.ay = 0.07;
    }
    if (c.d168 > 1) {
        c.setState(213);
        c.stopMotion();
        return;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        impactFx(c, d);
        c.seRequest = 7;
        c.setState(214);
        return;
    }
    if (advanceEx(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advanceEx(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) impactFx(c, d);
    if (advanceEx(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        if (c.x > 580.0) c.x = 580.0;
        if (c.x < 60.0) c.x = 60.0;
        c.stopMotion();
        c.onStateChange();
        o.stopMotion();
        o.onStateChange();
        c.state = 221;
        o.state = 107;
        o.x = c.facing * 40 + c.x;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 37;
        d.y = ftol(c.y) - 42;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.biasCameraY(50, 3);
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        c.vx = 1.0;
        c.vy = -2.0;
        c.ay = 0.04;
    }
    c.vy += c.ay;
    if (c.vy + c.y > 0.0 && c.frame === 4) {
        c.y = 0.0;
        c.stopMotion();
        c.frame = 5;
        c.timer = 0;
        return;
    }
    if (c.x > 600.0 || c.x < 40.0) c.vx = 0.0;
    if (c.frame === 1) o.x = c.facing * 35 + c.x;
    if (c.frame === 2) {
        o.x = c.facing * 30 + c.x;
        o.y = c.y - 68.0;
        o.state = 101;
        o.onStateChange();
    }
    if (c.frame === 3) {
        o.x = c.facing * 25 + c.x;
        o.y = c.y - 80.0;
        o.state = 101;
        o.onStateChange();
    }
    if (c.frame === 4) {
        o.x = c.facing * 10 + c.x;
        o.y = c.y - 90.0;
        o.state = 118;
        o.onStateChange();
    }
    if (c.frame === 5) {
        o.x = c.facing * 30 + c.x;
        o.y = c.y - 60.0;
        o.state = 105;
        o.onStateChange();
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 6) {
            o.x = c.facing * 40 + c.x;
            o.y = 0.0;
            o.state = 98;
            o.onStateChange();
            applyDirectDamage(c, 1200, 750.0);
        }
        if (c.frame >= cnt) {
            c.setState(0);
            c.faceOpponent();
        }
    }
}
function normalB(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (p.afterimageFirst) {
        c.startAfterimage(3);
        c.b158 = 0;
    } else {
        c.b158 = 0;
        c.startAfterimage(3);
    }
    if (p.jumpCancel && groundJumpCancel(c, c.d168 >= 2)) return;
    if (c.vx > 0.0 && (p.decelMinFrame < 0 || c.frame > p.decelMinFrame)) c.vx -= p.decel;
    else c.b158 = 0;
    if (p.clampFirst && c.vx < 0.0) c.vx = 0.0;
    if (atFrame(c, p.startFrame)) {
        c.w16c = 1;
        c.seRequest = 20;
        addMeter(c, p.meter);
    }
    if (!p.clampFirst && c.vx < 0.0) c.vx = 0.0;
    if (advanceEx(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) c.setState(p.endState);
    }
}
const NB_DEFAULT = {
    afterimageFirst: true,
    decel: 0.03,
    decelMinFrame: -1,
    startFrame: 1,
    meter: 20,
    clampFirst: false,
    endState: 0,
    jumpCancel: false
};
const NB = {
    230: {
        ...NB_DEFAULT
    },
    231: {
        ...NB_DEFAULT,
        startFrame: 3
    },
    232: {
        ...NB_DEFAULT,
        afterimageFirst: false,
        decel: 0.035,
        decelMinFrame: 3,
        startFrame: 2,
        meter: 35,
        clampFirst: true
    },
    233: {
        ...NB_DEFAULT,
        endState: 3
    },
    234: {
        ...NB_DEFAULT,
        endState: 3
    },
    235: {
        ...NB_DEFAULT,
        jumpCancel: true
    }
};
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: (c)=>normalB(c, NB[230]),
    231: (c)=>normalB(c, NB[231]),
    232: (c)=>normalB(c, NB[232]),
    233: (c)=>normalB(c, NB[233]),
    234: (c)=>normalB(c, NB[234]),
    235: (c)=>normalB(c, NB[235])
});

export function __logicState(){return {NB_DEFAULT,NB};}

export function __installInitialRoots(s){
if(NB_DEFAULT!==s["NB_DEFAULT"])throw Error('INITIAL_CONST_IDENTITY:NB_DEFAULT');
if(NB!==s["NB"])throw Error('INITIAL_CONST_IDENTITY:NB');
}
