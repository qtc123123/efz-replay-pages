import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./2d89f5a5c2e93d6456ad7e4a.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./59adbef650633f2bfaadb9d3.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function superBegin(c) {
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.voiceRequest = 0;
    }
}
function stopAt(c, f) {
    if (c.frame === f && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
}
function charge(c, inc, jump) {
    if (c.frame > 2 && c.frame < 7) c.f3150 = c.f3150 + inc;
    if (c.frame > 2 && c.frame < 7 && c.f3150 >= 10000) {
        c.f3150 = 0;
        c.frame = jump;
        c.timer = 0;
        return true;
    }
    return false;
}
function spawnAura(c, d) {
    if (c.frame === 3 && c.timer === 0) {
        d.w04 = 0x196;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        d.w04 = 0x197;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        d.b18 = c.facing;
        frameChild(c, d);
    }
}
function superFreeze(c, cost, darken) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, darken);
}
function superEffect(c, d, pat, sound, dx, dy) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function spawnBody(c, d, pat, dx, dy) {
    d.w04 = pat;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) + dy;
    d.b20 = 2;
    d.b21 = 1;
    d.d00 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function stepFrame(c, dur, hit) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = hit;
    return true;
}
function endIfDone(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state300(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    if (c.frame === 0xd && c.timer === 0) {
        superFreeze(c, 0x3e8, 3);
        superEffect(c, d, 0x44, 0x13, 0, 0x64);
        c.w16c = 5;
        c.stopMotion();
    }
    stopAt(c, 7);
    if (charge(c, 0x64, 8)) return;
    spawnAura(c, d);
    if (c.frame === 0x10 && c.timer === 0) c.voiceRequest = 0x1d;
    if (!stepFrame(c, dur, 3)) return;
    if (c.frame === 7) c.frame -= 4;
    if (c.frame === 0x10 && c.timer === 0 && c.f3138 < 1) {
        d.w04 = 0x1c7;
        d.x = ftol(c.x) + c.facing * 0x4b;
        d.y = 0.0;
        if (c.f3138 === 1) d.x = c.facing * 0x1e + c.x;
        if (c.f3138 === 2) d.x = c.facing * 0x78 + c.x;
        if (c.f3138 === 3) d.x = c.facing * 0x50 + c.x;
        if (c.f3138 === 4) d.x = c.facing * 0x91 + c.x;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.frame === 0x12 && c.f3138 < 3) {
        c.frame -= 1;
        c.f3138++;
    }
    endIfDone(c, cnt);
}
function state301(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    if (c.frame === 0xd && c.timer === 0) {
        superFreeze(c, 0x7d0, 3);
        superEffect(c, d, 0x45, 5, 0, 0x64);
        c.w16c = 5;
        c.stopMotion();
    }
    stopAt(c, 7);
    if (charge(c, 0x64, 7)) return;
    spawnAura(c, d);
    if (c.frame === 0xf && c.timer === 0) spawnBody(c, d, 0x1a3, 0x28, -0x28);
    if (!stepFrame(c, dur, 3)) return;
    if (c.frame === 7) c.frame -= 4;
    if (c.frame === 0x13 && c.f3138 < 6) {
        c.frame -= 3;
        c.f3138++;
    }
    endIfDone(c, cnt);
}
function state302(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    c.biasCameraY(0x32, 3);
    stopAt(c, 7);
    if (charge(c, 0x64, 7)) return;
    spawnAura(c, d);
    if (c.frame === 0xa && c.timer === 0) {
        superFreeze(c, 0xbb8, 0xa4);
        superEffect(c, d, 0x46, 0x40, 0, 0x2b);
        c.seRequest = 0x25;
    }
    if (c.frame === 0xd && c.timer === 0) {
        d.w04 = 0x1c1;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b18 = c.facing;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.d30 = 1;
        frameChild(c, d);
    }
    if (!stepFrame(c, dur, 0)) return;
    if (c.frame === 7) c.frame -= 4;
    endIfDone(c, cnt);
}
function state303(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    if (c.frame === 0xd && c.timer === 0) {
        superFreeze(c, 0x3e8, 3);
        superEffect(c, d, 0x44, 0x13, 0, 0x64);
        c.w16c = 5;
        c.stopMotion();
    }
    stopAt(c, 7);
    if (charge(c, 0x64, 8)) return;
    spawnAura(c, d);
    if (c.frame === 0xe && c.timer === 0) spawnBody(c, d, 0x19c, 0, -0x6e);
    if (!stepFrame(c, dur, 3)) return;
    if (c.frame === 7) c.frame -= 4;
    endIfDone(c, cnt);
}
function state304(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    if (c.frame === 9 && c.timer === 0) {
        superFreeze(c, 0x7d0, 3);
        superEffect(c, d, 0x45, 5, -0xe, 0x40);
        c.w16c = 5;
        c.stopMotion();
    }
    stopAt(c, 7);
    if (charge(c, 0x96, 8)) return;
    spawnAura(c, d);
    if (c.frame === 0xd && c.timer === 0) {
        spawnBody(c, d, 0x1ad, 0x3c, 0);
        d.x = ftol(c.x) + c.facing * 0x2d;
        d.y = ftol(c.y) + 0xa;
        d.d00 = 1;
        frameChild(c, d);
        d.x = ftol(c.x) + c.facing * 0x4b;
        d.y = ftol(c.y) - 0xa;
        d.d00 = 1;
        frameChild(c, d);
        d.x = ftol(c.x) + c.facing * 0x3c;
        d.y = ftol(c.y);
        d.d00 = 1;
        d.w04 = 0x19d;
        frameChild(c, d);
        c.shakeScreen(4, 0);
    }
    if (!stepFrame(c, dur, 3)) return;
    if (c.frame === 7) c.frame -= 4;
    endIfDone(c, cnt);
}
function state305(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    c.biasCameraY(0x32, 3);
    stopAt(c, 7);
    if (charge(c, 0x64, 7)) return;
    spawnAura(c, d);
    if (c.frame === 9 && c.timer === 0) {
        superFreeze(c, 0xbb8, 3);
        superEffect(c, d, 0x46, 0x40, 0, 0x2b);
        c.seRequest = 0x25;
    }
    if (c.frame === 0xd && c.timer === 0) {
        spawnBody(c, d, 0x1c2, 0xa, -0x37);
        c.f315c++;
        c.f3160 = 0x258;
        c.f3164 = c.facing;
    }
    if (c.frame > 0xd) c.showAltBackground(0xf);
    if (!stepFrame(c, dur, 0)) return;
    if (c.frame === 7) c.frame -= 4;
    if (c.frame === 0xc && c.f3140 < 8) {
        c.frame -= 2;
        c.f3140++;
    }
    if (c.frame === 0x11 && c.f313c < 5) {
        c.frame -= 4;
        c.f313c++;
    }
    endIfDone(c, cnt);
}
function state306(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    if (p.alt && c.frame > 2) c.showAltBackground(0xf);
    if (c.frame === 2 && c.timer === 0) {
        superFreeze(c, p.cost, 3);
        superEffect(c, d, p.effect, p.sound, 0, 0x32);
        c.w16c = 5;
        c.stopMotion();
        if (p.alt) c.seRequest = 0x25;
    }
    stopAt(c, 6);
    if (c.frame > 2 && c.frame < 0xd) {
        c.f3150 = c.f3150 + 0xc8;
        if (c.f3150 > 0x2710) c.f3150 = 0x2710;
    }
    if (c.frame > 0xf && c.frame < 0x13) c.f313c--;
    if (c.f313c <= 0 && c.f3140 < p.max && c.frame > 0xf) {
        c.f3150 = 0;
        c.voiceRequest = 0xe;
        spawnBody(c, d, p.child, 0x1e, -0x28);
        c.f313c = 0x1e;
        c.f3140++;
    }
    if (!stepFrame(c, dur, 3)) return;
    if (c.frame === 0x10) c.w13c = p.w13c;
    if (c.frame === 0x13 && c.f3138 < 6) {
        c.frame -= 3;
        c.f3138++;
    }
    endIfDone(c, cnt);
}
const S306 = {
    cost: 0x3e8,
    effect: 0x44,
    sound: 0x13,
    max: 3,
    child: 0x19e,
    w13c: 0xf,
    alt: false
};
const S307 = {
    cost: 0x7d0,
    effect: 0x45,
    sound: 5,
    max: 4,
    child: 0x19f,
    w13c: 0x2d,
    alt: false
};
const S308 = {
    cost: 0xbb8,
    effect: 0x46,
    sound: 0x40,
    max: 5,
    child: 0x1a0,
    w13c: 0xb4,
    alt: true
};
function state309(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    if (c.frame === 9 && c.timer === 0) {
        superFreeze(c, 0x7d0, 3);
        superEffect(c, d, 0x45, 5, -0xe, 0x40);
        c.stopMotion();
    }
    stopAt(c, 7);
    if (charge(c, 0x96, 8)) return;
    spawnAura(c, d);
    if (c.frame === 0xc && c.timer === 0) {
        spawnBody(c, d, 0x1ae, 0, 0);
        c.voiceRequest = 0x12;
    }
    if (!stepFrame(c, dur, 3)) return;
    if (c.frame === 7) c.frame -= 4;
    endIfDone(c, cnt);
}
function state312(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    if (c.frame === 0xd && c.timer === 0) {
        superFreeze(c, 0x3e8, 3);
        superEffect(c, d, 0x44, 0x13, -0xe, 0x40);
        c.stopMotion();
    }
    stopAt(c, 7);
    if (charge(c, 0x96, 8)) return;
    spawnAura(c, d);
    if (c.frame === 0x11 && c.timer === 0) {
        spawnBody(c, d, 0x1a7, 0x1e, 0);
        c.voiceRequest = 0x11;
    }
    if (!stepFrame(c, dur, 3)) return;
    if (c.frame === 7) c.frame -= 4;
    endIfDone(c, cnt);
}
function state313(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    if (c.frame === 9 && c.timer === 0) {
        superFreeze(c, 0x7d0, 3);
        superEffect(c, d, 0x45, 5, -0xe, 0x40);
        c.stopMotion();
    }
    stopAt(c, 7);
    if (charge(c, 0x96, 8)) return;
    spawnAura(c, d);
    if (c.frame === 0xc && c.timer === 0) {
        spawnBody(c, d, 0x1ac, 0, -0x3c);
        c.voiceRequest = 0xf;
    }
    if (!stepFrame(c, dur, 3)) return;
    if (c.frame === 7) c.frame -= 4;
    endIfDone(c, cnt);
}
function state314(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    superBegin(c);
    c.biasCameraY(0x32, 3);
    stopAt(c, 7);
    if (charge(c, 0x64, 7)) return;
    spawnAura(c, d);
    if (c.frame === 8 && c.timer === 0) {
        c.freeze = 0x78;
        c.w16c = 1;
        c.meter = s16(c.meter - 0xbb8);
        c.superDarken(0xb0, 0xa4);
        superEffect(c, d, 0x46, 0x40, 0, 0x2b);
        c.seRequest = 0x25;
    }
    if (c.frame === 0xd && c.timer === 0) spawnBody(c, d, 0x1b2, 0, 0);
    if (!stepFrame(c, dur, 0)) return;
    if (c.frame === 7) c.frame -= 4;
    endIfDone(c, cnt);
}
function state315(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.biasCameraY(0x32, 3);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.voiceRequest = 0;
        c.freeze = 0x78;
        c.w16c = 1;
        c.meter = s16(c.meter - 0xbb8);
        c.superDarken(0xb0, 3);
        superEffect(c, d, 0x46, 0x40, 0, 0x2b);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (c.frame === 7 && c.d168 === 3) {
        c.frame = 0;
        c.state = 0x13c;
        o.stopMotion();
        o.frame = 0;
        o.timer = 0;
        o.state = 0x6b;
        return;
    }
    if (!stepFrame(c, dur, 0)) return;
    if (c.frame === 7) {
        if (o.y === 0.0) c.w16c = 1;
        else c.w16c = 0;
    }
    endIfDone(c, cnt);
}
function state316(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.biasCameraY(0x32, 3);
    if (c.frame === 0 && c.timer === 0) c.voiceRequest = 0x1b;
    if (c.frame > 0x11 && o.state === 0x63) o.timer = 0;
    if (!stepFrame(c, dur, 0)) return;
    if (c.frame === 4) {
        o.state = 0x64;
        o.x = c.facing * 0x37 + c.x;
        o.y = -61.0;
    }
    if (c.frame === 5) {
        o.state = 0x64;
        o.x = c.facing * 0x2e + c.x;
        o.y = -74.0;
    }
    if (c.frame === 6) {
        o.state = 0x64;
        o.x = c.facing * 0x21 + c.x;
        o.y = -86.0;
    }
    if (c.frame === 7) {
        o.state = 0x64;
        o.x = (c.facing << 5) + c.x;
        o.y = -87.0;
        d.w04 = 0x1c8;
        d.x = 0.0;
        d.y = 200.0;
        d.b20 = 0;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = 1;
        d.d24 = 1;
        d.d30 = 1;
        frameChild(c, d);
    }
    if (c.frame === 8) {
        o.state = 0x64;
        o.x = c.facing * 0x1f + c.x;
        o.y = -87.0;
    }
    if (c.frame === 0xb && c.f3138 === 0) c.frame -= 3;
    if (c.frame === 0x11) {
        o.hitstop = 0;
        o.state = 0x3b;
        o.y = -20.0;
        o.ay = 0.035;
    }
    endIfDone(c, cnt);
}
registerStates({
    300: state300,
    301: state301,
    302: state302,
    303: state303,
    304: state304,
    305: state305,
    306: (c)=>state306(c, S306),
    307: (c)=>state306(c, S307),
    308: (c)=>state306(c, S308),
    309: state309,
    312: state312,
    313: state313,
    314: state314,
    315: state315,
    316: state316
});
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function firstHits(c, i, n) {
    if (c.a3174[i] !== 0) return false;
    c.children[i].hitsLeft = n;
    c.a3174[i]++;
    return true;
}
function spawnAt(c, i, pat, dx, dy) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    d.w04 = pat;
    d.x = ftol(ch.x) + c.facing * dx;
    d.y = ftol(ch.y) + dy;
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function child412(c, i) {
    const ch = c.children[i];
    if (firstHits(c, i, 1)) {
        c.voiceRequest = 0xa;
        ch.vx = 3.5;
        ch.vy = 2.0;
    }
    if (ch.hitState > 0 && ch.hitState !== 6 || ch.y > 0.0) {
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 0x19d;
        spawnAt(c, i, 0x1a5, 0, 0);
        return;
    }
    if (childStep(c, i) && ch.frame >= childCount) ch.frame = 0;
}
const C413_OFFSETS = [
    [
        0,
        0
    ],
    [
        0x32,
        -0x28
    ],
    [
        -0x1e,
        -0x46
    ],
    [
        0x14,
        0xa
    ],
    [
        -0xa,
        -0x14
    ],
    [
        0x1e,
        0
    ]
];
function child413(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        if (c.state === 0x130) ch.vy = -1.5;
        for(let k = 0; k < C413_OFFSETS.length; k++){
            if (c.a3174[i] === k) spawnAt(c, i, 0x1a5, C413_OFFSETS[k][0], C413_OFFSETS[k][1]);
        }
        c.a3274[i] = c.random(0, 3);
        if (c.a3274[i] === 0) c.voiceRequest = 0xb;
        if (c.a3274[i] === 1) c.voiceRequest = 0xc;
        if (c.a3274[i] === 2) c.voiceRequest = 0xd;
    }
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        if (c.a3174[i] < 6) {
            ch.frame = 0;
            c.a3174[i]++;
        } else {
            c.freeChild(i);
        }
    }
}
function child414(c, i) {
    const ch = c.children[i];
    if (firstHits(c, i, 1)) {
        ch.vx = -2.5;
        ch.vy = -1.5;
    }
    if (ch.frame < 0xe) {
        ch.vx = ch.vx + 0.025;
        if (c.opponent.y - 50.0 > ch.y) ch.vy = ch.vy + 0.035;
        if (c.opponent.y - 50.0 < ch.y) ch.vy = ch.vy - 0.035;
        if (ch.vy < -1.5) ch.vy = -1.5;
        if (ch.vy > 1.5) ch.vy = 1.5;
        c.a3274[i]--;
        if (c.a3274[i] <= 0) {
            spawnAt(c, i, 0x1a6, 0, 0);
            c.a3274[i] = 6;
        }
    }
    if (ch.hitState > 0 && ch.hitState !== 6 || ch.y > 0.0) {
        if (ch.frame < 0xe) {
            ch.frame = 0xe;
            ch.timer = 0;
            ch.vx = 0.0;
            ch.vy = 0.0;
            return;
        }
    }
    if (ch.x < -80.0 || ch.x > 720.0) c.freeChild(i);
    if (!childStep(c, i)) return;
    if (ch.frame === 0xe) ch.frame = 4;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child419(c, i) {
    const ch = c.children[i];
    if (firstHits(c, i, 1)) {
        c.voiceRequest = 7;
        ch.vx = 0.0;
    }
    ch.vx = ch.vx + 0.005;
    if (childStep(c, i) && ch.frame >= childCount) {
        ch.frame = 0;
        ch.pattern = 0x1a4;
    }
}
function child420(c, i) {
    const ch = c.children[i];
    if (c.a3274[i] === 0) {
        ch.hitsLeft = 0x63;
        c.a3274[i]++;
        ch.vx = 4.0;
        c.voiceRequest = 8;
    }
    if (ch.hitState > 0 && c.a3374[i] === 0) {
        c.voiceRequest = 9;
        c.a3374[i]++;
    }
    if (ch.x > 740.0 || ch.x < -100.0) c.freeChild(i);
    if (childStep(c, i) && ch.frame >= childCount) ch.frame = 0;
}
function child421(c, i) {
    const ch = c.children[i];
    firstHits(c, i, 1);
    if (childStep(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function child422(c, i) {
    const ch = c.children[i];
    if (childStep(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function child423(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 1;
        ch.vx = 4.0;
        c.a3174[i]++;
    }
    c.a3274[i]--;
    if ((ch.x > 640.0 || ch.x < 0.0) && ch.hitState === 0) c.freeChild(i);
    if (ch.hitState > 0) {
        ch.vx = 0.5;
        ch.vy = -2.5;
        c.a3274[i]--;
        if (c.a3174[i] < 8 && c.a3274[i] <= 0) {
            const d = childSpawnFrame;
            d.w04 = 0x195;
            const bx = ftol(ch.x);
            d.x = bx + c.random(0, 0x64) - 0x32;
            const by = ftol(ch.y);
            d.y = by + c.random(0, 0x14);
            d.b20 = 2;
            d.b21 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
            c.a3174[i]++;
            c.a3274[i] = 0xf;
        }
        if (c.a3174[i] > 7) c.freeChild(i);
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame < childCount) return;
    ch.frame = 0;
    if (ch.hitState === 0) {
        const d = childSpawnFrame;
        d.w04 = c.random(0, 4) + 0x1a8;
        const bx = ftol(ch.x);
        d.x = bx + c.random(0, 0xa);
        const by = ftol(ch.y);
        d.y = by + c.random(0, 0xa) - 5;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
}
function child424(c, i) {
    const ch = c.children[i];
    firstHits(c, i, 1);
    if (childStep(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function child428(c, i) {
    const ch = c.children[i];
    if (firstHits(c, i, 7)) ch.vx = 4.5;
    if (ch.hitState > 0 && ch.frame === 0) {
        ch.frame = 1;
        ch.timer = 0;
        ch.vx = 0.0;
        c.voiceRequest = 0x10;
    }
    if (ch.x > 680.0 || ch.x < -40.0) c.freeChild(i);
    if (!childStep(c, i)) return;
    if (c.a3374[i] <= 0) {
        const d = childSpawnFrame;
        d.w04 = 0x195;
        const bx = ftol(ch.x);
        d.x = bx + c.random(0, 0x64) - 0x32;
        const by = ftol(ch.y);
        d.y = by + c.random(0, 0x64) - 0x32;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.a3374[i] = 2;
    }
    c.a3374[i]--;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child429(c, i) {
    const ch = c.children[i];
    firstHits(c, i, 5);
    c.a3274[i]++;
    if (ch.hitsLeft === 0 || c.a3274[i] > 0x4b0) c.freeChild(i);
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 8 || ch.frame === 0xe || ch.frame === 0x14 || ch.frame === 0x1a) ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = 8;
}
function child430(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0xb && ch.timer === 0) {
        spawnAt(c, i, 0x1af, 0, 0);
        c.voiceRequest = 0x13;
    }
    if (childStep(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function child431(c, i) {
    const ch = c.children[i];
    if (ch.hitState > 1 && (ch.frame === 0xa || ch.frame === 0xb)) {
        ch.timer = 0;
        ch.frame = 0xc;
        c.a3374[i] = 2;
        c.a3274[i]++;
    }
    if (ch.frame > 9 && ch.frame < 0xe) {
        if (c.y === 0.0 && ch.x + 30.0 > c.x && ch.x - 30.0 < c.x && c.a3374[i] <= 0) {
            if (ch.frame > 0xb) {
                ch.timer = 0;
                ch.frame = 0xa;
                return;
            }
        } else if (ch.frame !== 0xc && ch.frame !== 0xd) {
            ch.timer = 0;
            ch.frame = 0xc;
            return;
        }
    }
    c.a3174[i]++;
    if (c.a3174[i] > 0x960 || c.a3274[i] > 9) {
        if (ch.frame < 0xe) {
            ch.timer = 0;
            ch.frame = 0xe;
            return;
        }
    }
    if (!childStep(c, i)) return;
    if (ch.frame === 0xc) ch.frame -= 2;
    if (ch.frame === 0xe) {
        ch.frame -= 2;
        c.a3374[i]--;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child432(c, i) {
    const ch = c.children[i];
    ch.timer++;
    ch.hitsLeft = 1;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame === 0xe && c.random(0, 3) < 2) {
        const d = childSpawnFrame;
        d.w04 = 0x1b1;
        d.x = ftol(ch.x);
        const by = ftol(ch.y);
        d.y = by - c.random(0, 0x96);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child433(c, i) {
    const ch = c.children[i];
    if (childStep(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function child434(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        c.voiceRequest = 0x17;
        ch.hitsLeft = 0x63;
        c.a3174[i] = 1;
        ch.vx = 3.0;
        ch.vy = -1.2;
    }
    if (c.a3174[i] === 1) {
        ch.vy = ch.vy + 0.05;
        if (ch.vy > 0.0) {
            ch.vy = 0.0;
            c.a3174[i] = 2;
            ch.timer = 0;
            ch.frame = 1;
        }
    }
    if (c.a3174[i] === 2) ch.vx = ch.vx + 0.0;
    if (ch.x < -40.0 || ch.x > 680.0) c.freeChild(i);
    if (ch.timer === 0) {
        const d = childSpawnFrame;
        d.w04 = 0x1b0;
        const bx = ftol(ch.x);
        d.x = bx + c.random(0, 0x28);
        const by = ftol(ch.y);
        d.y = by + c.random(0, 0x14);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.hitState = 0;
}
registerChildren({
    412: child412,
    413: child413,
    414: child414,
    415: child414,
    416: child414,
    417: child414,
    418: child414,
    419: child419,
    420: child420,
    421: child421,
    422: child422,
    423: child423,
    424: child424,
    425: child424,
    426: child424,
    427: child424,
    428: child428,
    429: child429,
    430: child430,
    431: child431,
    432: child432,
    433: child433,
    434: child434
});

export function __logicState(){return {S306,S307,S308,C413_OFFSETS};}

export function __installInitialRoots(s){
if(S306!==s["S306"])throw Error('INITIAL_CONST_IDENTITY:S306');
if(S307!==s["S307"])throw Error('INITIAL_CONST_IDENTITY:S307');
if(S308!==s["S308"])throw Error('INITIAL_CONST_IDENTITY:S308');
if(C413_OFFSETS!==s["C413_OFFSETS"])throw Error('INITIAL_CONST_IDENTITY:C413_OFFSETS');
}
