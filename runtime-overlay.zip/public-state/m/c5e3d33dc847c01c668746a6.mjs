import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { canWriteOpfs, writeOpfsFile } from "./839f183fad63314b72a571b8.mjs";
const ROOT_DIR = "efz-game";
const COMPLETE_MARK = ".complete";
const GAME_EXTENSIONS = [
    ".dat",
    ".pat",
    ".wav",
    ".ini",
    ".rec",
    ".pal",
    ".rep"
];
export function isGameFile(path) {
    const p = path.toLowerCase();
    return GAME_EXTENSIONS.some((ext)=>p.endsWith(ext));
}
export function isStorageSupported() {
    return canWriteOpfs();
}
async function rootDir(create) {
    const opfs = await navigator.storage.getDirectory();
    try {
        return await opfs.getDirectoryHandle(ROOT_DIR, {
            create
        });
    } catch  {
        return null;
    }
}
export async function hasStoredGame() {
    if (!isStorageSupported()) return false;
    const dir = await rootDir(false);
    if (!dir) return false;
    try {
        await dir.getFileHandle(COMPLETE_MARK);
        return true;
    } catch  {
        return false;
    }
}
export async function storeGame(list, onProgress) {
    await clearStoredGame();
    await navigator.storage.persist?.().catch(()=>false);
    const targets = list.filter((e)=>isGameFile(e.path));
    let done = 0;
    for (const { path, file } of targets){
        await writeOpfsFile([
            ROOT_DIR,
            ...path.split("/").filter(Boolean)
        ], file);
        onProgress(++done, targets.length);
    }
    await writeOpfsFile([
        ROOT_DIR,
        COMPLETE_MARK
    ], String(targets.length));
}
export async function loadStoredGame() {
    const root = await rootDir(false);
    if (!root) return [];
    const result = [];
    async function walk(dir, prefix) {
        for await (const [name, handle] of dir.entries()){
            if (handle.kind === "directory") {
                await walk(handle, `${prefix}${name}/`);
            } else if (!(prefix === "" && name === COMPLETE_MARK)) {
                result.push({
                    path: `${prefix}${name}`,
                    file: await handle.getFile()
                });
            }
        }
    }
    await walk(root, "");
    return result;
}
export async function clearStoredGame() {
    if (!isStorageSupported()) return;
    const opfs = await navigator.storage.getDirectory();
    try {
        await opfs.removeEntry(ROOT_DIR, {
            recursive: true
        });
    } catch  {}
}

export function __logicState(){return {GAME_EXTENSIONS};}
