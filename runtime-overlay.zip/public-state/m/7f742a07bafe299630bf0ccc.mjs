import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./65b7ada33d910b3c78926926.mjs";
import { parseCommandAyu, dispatchMovesAyu } from "./217698f12f791bf162fe7ba1.mjs";
import { thinkAyu } from "./15623b23e6c2ebd7599a5667.mjs";
import { updateChildrenAyu } from "./a8b80a095bfa4aebc7efbc76.mjs";
import "./14b6d839696dba5950d442ab.mjs";
import "./4a7eb9effde28cfc32d4c9e6.mjs";
import "./3c4b2ee1166e07729a46ff87.mjs";
import "./0bf38db5ab471e4bc9d45ff5.mjs";
const POINTS_X = [
    -17,
    13,
    12,
    22,
    27
];
const POINTS_Y = [
    -51,
    0,
    -14,
    -19,
    -41
];
export class Ayu extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    a3150 = new Int32Array(64);
    a3250 = new Int32Array(64);
    a3350 = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        4,
        1,
        0xff,
        2,
        3,
        4,
        10,
        16
    ];
    w0dc = 0;
    b0de = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = this.f313c = this.f3140 = this.f3144 = this.f3148 = this.f314c = 0;
        this.a3150.fill(0);
        this.a3250.fill(0);
        this.a3350.fill(0);
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3150[i] = 0;
        this.a3250[i] = 0;
        this.a3350[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {}
    parseCommand() {
        parseCommandAyu(this);
    }
    dispatchMoves() {
        dispatchMovesAyu(this);
    }
    think() {
        thinkAyu(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenAyu(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
