import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./6a48da560917c25ba78d9332.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./a955fd4a77ee18da4a262fee.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function patFrame0(c, pattern) {
    return c.patterns[pattern]?.frames[0];
}
function drawPart(c, f, x, y, w) {
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    blit(makeRect(x, y, w, f.height), surf, makeRect(0, 0, w, f.height), c.colorKey, false);
}
export function renderOverlayNayukiB(c) {
    if (c.f314c > 0) {
        const f = patFrame0(c, 43);
        if (f) drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - f.width, 0x1f - f.offsetY, f.width);
    }
    if (c.f314c > 0) {
        const f = patFrame0(c, 44);
        if (f) {
            const w = Math.trunc(Math.imul(f.width, c.f3150) / 0xbb8);
            drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - w, 0x1f - f.offsetY, w);
        }
    }
}
export function tickHookNayukiB(c) {
    if (c.f3150 <= 0 || c.life <= 0 || c.opponent.life <= 0 || c.state > 0x31 && c.state < 0x96) {
        c.f3150 = 0;
        c.f314c = 0;
    }
    if (c.f3150 <= 0) return;
    c.f3148 = c.f3148 + c.f3154;
    if (c.f3148 > 0x167) c.f3148 = c.f3148 - 0x168;
    c.f3150 = c.f3150 - 2;
    if (c.f3150 <= 0) {
        c.f3150 = 0;
        c.f314c = 0;
    }
}
const atStart = (c)=>c.frame === 0 && c.timer === 0;
function advance(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return true;
}
function finish(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function addMeter(c, v) {
    c.meter = s16(c.meter + v);
}
function dustEffect(c, d) {
    d.w04 = 0x1f;
    d.x = ftol(c.x);
    d.y = 0.0;
    d.b20 = 0;
    d.b21 = 0;
    d.d1c = c.facing - 1 !== 0 ? 1 : 0;
    frameEffect(d);
}
function rfCostEffect(c, d) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    d.w04 = 0x21;
    d.b2c = 0xb;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 0x32;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
}
function state248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.stopMotion();
        o.d128 = 1;
        c.frame = 0;
        c.timer = 0;
        c.state = 0xf9;
        o.onStateChange();
        o.stopMotion();
        o.state = 0x67;
        o.x = c.facing * 0x17 + c.x;
        o.y = c.y - 65.0;
        return;
    }
    if (!advance(c, dur)) return;
    if (c.frame === 1 && o.y < 0.0 && (o.state < 0x32 || o.state > 0x95)) {
        c.w16c = 1;
    } else {
        c.w16c = 0;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0xd1;
        c.frame = 1;
    }
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.w13e = 0x1e;
    o.w13e = 0x1e;
    c.b158 = 0;
    if (c.frame < 9 && c.frame > 2) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.timer = 0;
            c.frame = 9;
            return;
        }
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 1) {
        c.vx = 1.0;
        c.vy = -1.0;
        c.ay = 0.035;
        o.onStateChange();
        o.state = 0x3c;
        o.knockX = 2.5;
        o.knockY = -0.8;
        o.ay = 0.035;
        applyDirectDamage(c, 0x3e8, 500.0);
        c.comboCount = s16(c.comboCount - 1);
        c.comboDisplay = s16(c.comboDisplay - 1);
        o.d128 = 1;
    }
    if (c.frame === 9) c.frame = c.frame - 2;
    if (c.frame >= cnt) {
        c.onStateChange();
        c.state = 7;
    }
}
function jumpState(c, vx, vy, ay) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.frame < 0xb && c.frame > 0) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y >= 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.onStateChange();
            c.frame = 0xb;
            return;
        }
    }
    if (!advance(c, dur)) return;
    if (c.frame === 1) {
        addMeter(c, 0x2d);
        c.d168 = 0;
        dustEffect(c, d);
        c.vx = vx;
        c.vy = vy;
        c.ay = ay;
        c.voiceRequest = 0;
    }
    if (c.frame === 0xb) c.frame = 9;
    finish(c, cnt);
}
function state250(c) {
    jumpState(c, 0.0, -1.5, 0.035);
}
function state251(c) {
    jumpState(c, -0.5, -2.5, 0.045);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
        rfCostEffect(c, d);
    }
    if (c.frame < 0x13 && c.frame > 0) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y >= 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.onStateChange();
            c.frame = 0x13;
            return;
        }
    }
    if (!advance(c, dur)) return;
    if (c.frame === 1) {
        addMeter(c, 0x2d);
        c.d168 = 0;
        dustEffect(c, d);
        c.vx = 0.5;
        c.vy = -3.0;
        c.ay = 0.05;
        c.w16c = 1;
        c.voiceRequest = 0;
    }
    if (c.frame === 0xa) {
        c.d168 = 0;
        c.w16c = 1;
        c.voiceRequest = 0;
    }
    if (c.frame === 0x13) c.frame = 0x11;
    finish(c, cnt);
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 2;
    }
    if (!advance(c, dur)) return;
    if (c.frame === 3) {
        addMeter(c, 0x2d);
        c.d168 = 0;
        c.voiceRequest = 2;
    }
    if (c.frame === 6) {
        c.d168 = 0;
        c.voiceRequest = 3;
    }
    finish(c, cnt);
}
function state256(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame === 2 && c.timer === 0) {
        c.vx = 1.0;
        c.vy = -1.5;
        c.ay = 0.03;
        if (c.y === 0.0) dustEffect(c, d);
    }
    if (c.frame > 1 && c.frame < 7) c.vy = c.vy + c.ay;
    if ((c.frame === 8 || c.frame === 9) && c.vy + c.y > 0.0) {
        c.frame = 0xa;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    if (!advance(c, dur)) return;
    if (c.frame < 2) c.d168 = 0;
    if (c.frame === 7) c.stopMotion();
    if (c.frame === 8) {
        c.vx = 2.0;
        c.vy = 1.0;
        c.seRequest = 0x15;
        c.w16c = 1;
        addMeter(c, 0x1e);
        c.voiceRequest = 1;
    }
    if (c.frame === 0xa) c.frame = 8;
    finish(c, cnt);
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame === 2 && c.timer === 0) {
        c.vx = 1.5;
        c.vy = -1.55;
        c.ay = 0.03;
        if (c.y === 0.0) dustEffect(c, d);
    }
    if (c.frame > 1) c.vy = c.vy + c.ay;
    if (c.frame > 8 && c.frame < 0x10 && c.vy + c.y > 0.0) {
        c.frame = 0x10;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    if (!advance(c, dur)) return;
    if (c.frame < 2) c.d168 = 0;
    if (c.frame === 8) {
        c.seRequest = 0x15;
        c.w16c = 1;
        addMeter(c, 0x1e);
        c.voiceRequest = 1;
    }
    if (c.frame === 0x10) c.frame = 0xe;
    finish(c, cnt);
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 1;
        c.d168 = 0;
        rfCostEffect(c, d);
    }
    if (c.frame === 2 && c.timer === 0) {
        if (c.y < 0.0) {
            rfCostEffect(c, d);
            c.w16c = 1;
        }
        if (c.y === 0.0) dustEffect(c, d);
        c.vx = 1.5;
        c.vy = -1.0;
        c.ay = 0.015;
    }
    if (c.frame > 1 && c.frame < 0x10) c.vy = c.vy + c.ay;
    if (c.frame < 0x10 && c.frame > 2 && c.vy + c.y > 0.0) {
        c.frame = 0x10;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    if (!advance(c, dur)) return;
    if (c.frame === 3 || c.frame === 6 || c.frame === 9) {
        c.seRequest = 0x15;
        c.w16c = 1;
        c.d168 = 0;
        c.voiceRequest = 1;
    }
    if (c.frame === 0xd) c.ay = 0.035;
    if (c.frame === 0x10) c.frame = c.frame - 2;
    finish(c, cnt);
}
function riseState(c, hits, guard, vx, vy, ay) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = hits;
        if (guard) rfCostEffect(c, d);
    }
    if (c.frame < 8 && c.frame > 2) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.frame = 8;
            c.timer = 0;
            c.y = 0.0;
            c.stopMotion();
            return;
        }
    }
    if (!advance(c, dur)) return;
    if (c.frame === 3) {
        c.vx = vx;
        c.vy = vy;
        c.ay = ay;
        dustEffect(c, d);
        addMeter(c, 0x2d);
    }
    if (c.frame === 5) {
        c.voiceRequest = 4;
        c.d168 = 0;
    }
    if (c.frame === 7) {
        c.voiceRequest = 4;
        c.d168 = 0;
    }
    if (c.frame === 8) c.frame = 4;
    finish(c, cnt);
}
function state259(c) {
    riseState(c, 4, false, 1.0, -1.5, 0.04);
}
function state260(c) {
    riseState(c, 4, false, 0.75, -2.0, 0.03);
}
function state261(c) {
    riseState(c, 8, true, 0.75, -2.0, 0.02);
}
function airState(c, hits, guard, dvy, ay) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.w16c = hits;
        if (guard) rfCostEffect(c, d);
    }
    if (c.frame < 8) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.frame = 8;
            c.timer = 0;
            c.y = 0.0;
            c.stopMotion();
            return;
        }
    }
    if (!advance(c, dur)) return;
    if (c.frame === 1) {
        c.vx = c.vx * 0.5;
        c.vy = c.vy - dvy;
        if (!(c.vy > -2.0)) c.vy = -2.0;
        c.ay = ay;
        addMeter(c, 0x2d);
    }
    if (c.frame === 3) {
        c.voiceRequest = 4;
        c.d168 = 0;
    }
    if (c.frame === 5) {
        c.voiceRequest = 4;
        c.d168 = 0;
    }
    if (c.frame === 6) c.frame = 2;
    if (c.frame === 8) c.frame = 6;
    finish(c, cnt);
}
function state262(c) {
    airState(c, 4, false, 1.5, 0.03);
}
function state263(c) {
    airState(c, 4, false, 3.0, 0.03);
}
function state264(c) {
    airState(c, 8, true, 3.0, 0.02);
}
const LEVEL_COST = [
    0x3e8,
    0x7d0,
    0xbb8
];
const LEVEL_PAT = [
    0x44,
    0x45,
    0x46
];
const LEVEL_SOUND = [
    0x13,
    5,
    0x40
];
function superStart(c, d, level, dx, dy) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - LEVEL_COST[level]);
    c.superDarken(0xb0, 3);
    d.w04 = LEVEL_PAT[level];
    d.b2c = LEVEL_SOUND[level];
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
    if (level === 2) c.seRequest = 0x25;
}
function rushSuper(c, level, hits) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = hits;
        superStart(c, d, level, 0, 0x37);
    }
    if (level === 2 && c.frame < 0xa) c.showAltBackground(0xf);
    if (c.frame < 5) c.biasCameraY(0x32, 3);
    if ((c.frame === 6 || c.frame === 7) && c.w16c === 1) c.frame = c.frame + 2;
    if (c.frame > 9 && c.frame < 0x13) c.vy = c.vy + c.ay;
    if (c.frame < 0x13 && c.y + c.vy >= 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 0x13;
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 6) {
        if (level === 1) c.w13c = 5;
        c.vx = 4.0;
        c.vy = 2.0;
        c.voiceRequest = 6;
        if (level === 2) c.w13c = 0xf;
    }
    if (c.frame === 8 && c.w16c > 1) c.frame = c.frame - 2;
    if (c.frame === 0xa) c.frame = c.frame - 2;
    if (c.frame === 0x13) c.frame = c.frame - 2;
    finish(c, cnt);
}
function shotSuper(c, level) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 0;
        c.f3138 = 0;
        superStart(c, d, level, 0, 0x37);
    }
    if (c.frame < 4) c.biasCameraY(0x32, 3);
    if (level === 2 && c.frame < 0xa) c.showAltBackground(0xf);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 5 && c.timer === 0) {
        d.w04 = 0x190 + level;
        d.x = ftol(c.x) + c.facing * 0x2c;
        d.y = ftol(c.y) - 0x28;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.voiceRequest = 5;
        dustEffect(c, d);
    }
    if (c.frame === 8 && c.f3138 < 0) {
        c.frame = c.frame - 2;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame === 0xa && c.f3138 < 3) {
        c.frame = c.frame - 2;
        c.f3138 = c.f3138 + 1;
    }
    finish(c, cnt);
}
function orbitSuper(c, level) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (level === 2 && c.frame > 2 && c.frame < 8) c.showAltBackground(0xf);
    if (atStart(c)) c.stopMotion();
    if (c.frame > 2 && c.frame < 5) c.biasCameraY(0x32, 3);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 4) superStart(c, d, level, 5, 0x2b);
    if (c.frame === 6) {
        d.w04 = 0x198;
        d.x = ftol(c.x) + c.facing * 0x32;
        d.y = ftol(c.y) - 0x3c;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        d.w04 = 0x199;
        d.x = ftol(c.x) - c.facing * 0x32;
        d.y = ftol(c.y) - 0x3c;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.f3154 = c.facing;
        c.f314c = level + 1;
        c.f3150 = 0xbb8;
        c.voiceRequest = 7;
    }
    if (c.frame === 8 && c.f3138 < 4) {
        c.frame = c.frame - 2;
        c.f3138 = c.f3138 + 1;
    }
    finish(c, cnt);
}
registerStates({
    248: state248,
    249: state249,
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state253,
    255: state253,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    300: (c)=>rushSuper(c, 0, 3),
    301: (c)=>rushSuper(c, 1, 6),
    302: (c)=>rushSuper(c, 2, 0xa),
    303: (c)=>shotSuper(c, 0),
    304: (c)=>shotSuper(c, 1),
    305: (c)=>shotSuper(c, 2),
    306: (c)=>orbitSuper(c, 0),
    307: (c)=>orbitSuper(c, 1),
    308: (c)=>orbitSuper(c, 2)
});
const DEG = 57.29579143313326;
function setPolarVelocity(c, i, angle, speed) {
    const ch = c.children[i];
    ch.vx = __numerics.cos(angle / DEG) * speed;
    ch.vy = __numerics.sin(angle / DEG) * speed;
}
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function childShot(c, i, p) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.vx = 1.2;
        ch.vy = -2.1;
        ch.hitsLeft = p.hits;
        c.a3158[i] = c.a3158[i] + 1;
        if (p.interval > 0) c.a3258[i] = 0;
    }
    if (p.interval > 0) {
        c.a3258[i] = c.a3258[i] + 1;
        if (c.a3258[i] > p.interval) {
            c.a3258[i] = 0;
            const d = childSpawnFrame;
            d.w04 = 0x193;
            d.x = ftol(ch.x);
            d.y = ftol(ch.y);
            d.b20 = 2;
            d.b21 = 1;
            d.b18 = ch.facing;
            frameChild(c, d);
        }
    }
    if (ch.y < -600.0) {
        c.freeChild(i);
        return;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) ch.frame = 0;
    if (p.resetFrames.includes(ch.frame)) ch.hitState = 0;
}
const SHOT_400 = {
    hits: 3,
    interval: 0,
    resetFrames: [
        0,
        0xa
    ]
};
const SHOT_401 = {
    hits: 6,
    interval: 0xa,
    resetFrames: [
        0,
        5,
        0xa,
        0xf
    ]
};
const SHOT_402 = {
    hits: 0xf,
    interval: 3,
    resetFrames: [
        0,
        4,
        8,
        0xc,
        0x10
    ]
};
function child403(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.vx = 1.0;
        ch.vy = -2.2;
        ch.hitsLeft = 0;
        c.a3158[i] = c.a3158[i] + 1;
        const speed = (c.random(0, 3) & 0xffff) + 2;
        const angle = c.random(0, 0x168) & 0xffff;
        setPolarVelocity(c, i, angle, speed);
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame === 1 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function orbitPlace(c, i, angle) {
    const ch = c.children[i];
    setPolarVelocity(c, i, angle, 50.0);
    ch.x = c.f3154 * ch.vx + c.x;
    ch.y = c.y - 50.0 + ch.vy * 0.25;
    ch.layer = ch.vy < 0.0 ? 0 : 1;
    ch.vx = 0.0;
    ch.vy = 0.0;
}
function childOrbitHit(c, i, offset, next) {
    const ch = c.children[i];
    if (c.f3150 <= 0) {
        c.freeChild(i);
        return;
    }
    ch.facing = c.facing;
    orbitPlace(c, i, c.f3148 + offset);
    if (ch.frame === 0 && c.a3158[i] === 0) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
    }
    if (ch.frame === 1 && ch.hitsLeft === 0) {
        ch.timer = 0;
        ch.frame = 0;
        ch.pattern = next;
        ch.blend = 2;
        c.f3150 = c.f3150 - (0x3e8 - c.f314c * 0x15e);
        return;
    }
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = ch.frame - 1;
}
function childOrbitFade(c, i, offset, next) {
    const ch = c.children[i];
    if (c.f3150 <= 0) {
        c.freeChild(i);
        return;
    }
    ch.facing = c.facing;
    orbitPlace(c, i, c.f3148 + offset);
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.pattern = next;
        ch.blend = 2;
    }
}
function childOrbitSpawn(c, i, offset, next) {
    const ch = c.children[i];
    if (c.f3150 <= 0) {
        c.freeChild(i);
        return;
    }
    orbitPlace(c, i, c.f3148 + offset);
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame < childCount) return;
    ch.frame = 0;
    ch.pattern = next;
    ch.blend = 0;
    ch.facing = c.facing;
    const d = childSpawnFrame;
    d.w04 = 0x19b;
    d.x = ch.x;
    d.y = ch.y;
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = ch.facing;
    frameChild(c, d);
    c.voiceRequest = 8;
}
function child411(c, i) {
    const ch = c.children[i];
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    400: (c, i)=>childShot(c, i, SHOT_400),
    401: (c, i)=>childShot(c, i, SHOT_401),
    402: (c, i)=>childShot(c, i, SHOT_402),
    403: child403,
    404: (c, i)=>childOrbitHit(c, i, 0, 0x196),
    405: (c, i)=>childOrbitHit(c, i, 0xb4, 0x197),
    406: (c, i)=>childOrbitFade(c, i, 0, 0x198),
    407: (c, i)=>childOrbitFade(c, i, 0xb4, 0x199),
    408: (c, i)=>childOrbitSpawn(c, i, 0, 0x194),
    409: (c, i)=>childOrbitSpawn(c, i, 0xb4, 0x195),
    411: child411
});

export function __logicState(){return {LEVEL_COST,LEVEL_PAT,LEVEL_SOUND,SHOT_400,SHOT_401,SHOT_402};}

export function __installInitialRoots(s){
if(LEVEL_COST!==s["LEVEL_COST"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_COST');
if(LEVEL_PAT!==s["LEVEL_PAT"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_PAT');
if(LEVEL_SOUND!==s["LEVEL_SOUND"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_SOUND');
if(SHOT_400!==s["SHOT_400"])throw Error('INITIAL_CONST_IDENTITY:SHOT_400');
if(SHOT_401!==s["SHOT_401"])throw Error('INITIAL_CONST_IDENTITY:SHOT_401');
if(SHOT_402!==s["SHOT_402"])throw Error('INITIAL_CONST_IDENTITY:SHOT_402');
}
