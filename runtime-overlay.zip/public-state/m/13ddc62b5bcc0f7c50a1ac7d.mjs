import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { registerChildren, registerChildren2 } from "./00697db762b413ef9f6a1cba.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild } from "./0a57f8c3d343150e3ded7bb7.mjs";
import { ftol, s8 } from "./7596266716c972d06fe8897a.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
function forwardDash(c) {
    return c.facing === 1 ? 1 : 0;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = s8(rnd(c, 0, 2) - 1);
}
export function thinkNanase(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 0xaa ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 0x95 && c.state < 0x9d ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking * 2 + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40 * c.aiLevel > r && c.state > 0xc7) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 0xc8) c.aiMode = 0;
        return;
    }
    if (o.state === 0x60) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 0x32 && c.state <= 0x96 && c.timer === 0) {
        c.aiMode = 8 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 0x32 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 0xf0) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 0x140) < dx ? 1 : 0;
        if (o.state > 0xc7 && o.state < 0xfa && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 0xa && c.state <= 0xc) && c.y === 0.0) return;
    if (o.state >= 0x32 && o.state < 0x96 && c.state === 0x108 && c.w16c > 1) return;
    if (c.state === 0xfb && c.f344c === 0) {
        if (o.vy > 0.0 && o.y > -280.0 && o.y < -20.0 && rnd(c, 0, 1000) < 2) {
            c.command = 0xa;
            return;
        }
        if (o.vy > 0.0 && o.y > -220.0 && o.y < -20.0) {
            if (rnd(c, 0, 1000) < 0x1e) c.command = 0xb;
            if (rnd(c, 0, 1000) < 0xa && c.meter === 0xbb8 && o.y < -100.0) c.command = 0xc;
            return;
        }
    }
    if (c.state === 0xa8 && c.timer < 6) {
        if (o.state !== 0xc8 && o.state !== 0xcc && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx < 40.0 && chance(c, 3) && o.y === 0.0) {
                c.command = 0x46;
                return;
            }
            if (dx < 60.0 && chance(c, 3) && c.f344c === 0) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 60.0 && chance(c, 3) && c.f344c === 1) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
        }
        if ((o.state === 0xc9 || o.state === 0xca || o.state === 0xcd) && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx > 40.0 && dx < 80.0 && chance(c, 3)) {
                c.pressed[1] = 1;
                c.inputY = 0;
                c.inputX = 0;
                return;
            }
            if (dx > 60.0 && dx < 120.0 && chance(c, 3)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
        }
    }
    if (c.state === 0xa8 || c.state === 0xa9) {
        if (dx < 100.0) {
            if (c.aiLevel + c.aiLevel > rnd(c, 0, 100) && o.y === 0.0 && dx < 40.0 && o.y === 0.0) {
                c.command = 0x46;
                return;
            }
            if (chance(c, 3) && c.rfGauge > 500.0 && c.f344c === 0) {
                c.command = 0x14;
                return;
            }
            {
                const g = c.rfGauge > 500.0 ? 1 : 0;
                if (c.aiLevel * 3 + g * 2 > rnd(c, 0, 100) && c.f344c === 0 && o.y === 0.0) {
                    c.command = 0xc;
                    return;
                }
            }
            {
                const g = c.rfGauge > 500.0 ? 1 : 0;
                if (c.aiLevel * 3 + g * 2 > rnd(c, 0, 100) && c.f344c === 0) {
                    c.command = rnd(c, 0, 1) === 1 ? 0x20 : 0x1f;
                    return;
                }
            }
            if (chance(c, 3) && c.meter >= 0x3e8 && c.f344c === 0 && o.y === 0.0) {
                c.command = 0x6e;
                return;
            }
            if (chance(c, 3) && dx < 150.0 && c.meter >= 0x3e8 && c.f344c === 1 && o.y === 0.0) {
                c.command = 0x64;
                return;
            }
        }
        if (dx < 160.0 && chance(c, 3) && c.rfGauge > 500.0) {
            c.command = 0xc;
            return;
        }
        if (dx < 220.0 && dx > 160.0 && chance(c, 1)) {
            c.command = rnd(c, 0, 2) + 0xa;
            return;
        }
        if (dx > 220.0 && chance(c, 1) && c.rfGauge > 500.0) {
            c.command = rnd(c, 0, 2) + 0xa;
            return;
        }
    }
    if (c.state === 0xaa && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -60.0 && dx < 80.0 && chance(c, 5)) {
            c.pressed[0] = 1;
            return;
        }
        if (dy < 80.0 && dx < 100.0 && chance(c, 5) && c.f344c === 0) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -60.0 && dx < 80.0 && chance(c, 5)) {
            c.pressed[2] = 1;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y === 0.0 && 15 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0 && c.f344c === 0) {
            c.command = 0x14;
            return;
        }
        if (c.aiRoll < 7 && c.rfGauge > 500.0 && c.f344c === 0) {
            c.command = 0xc;
            return;
        }
        if (c.aiRoll < 0xa && c.rfGauge > 500.0 && c.f344c === 0) {
            c.command = 0x20;
            return;
        }
        if (c.aiRoll < 0xd && c.rfGauge > 500.0 && c.f344c === 0) {
            c.command = 0x16;
            return;
        }
        if (c.aiRoll < 0x11 && c.aiRoll > 0xc && c.meter >= 0x3e8 && c.f344c === 0) {
            c.command = rnd(c, 0, 2) + 0x6e;
            return;
        }
        if (c.aiRoll < 0x12 && c.aiRoll > 0x16 && c.meter >= 0x3e8 && c.f344c === 1) {
            c.command = rnd(c, 0, 2) + 0x64;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y < 0.0 && 15 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 0x14) {
            c.aiMode = 2;
            return;
        }
        if (dx < 200.0 && c.aiRoll < 0x20 && o.y === 0.0 && dx * 0.5 > dy && dx * 0.3 < dy) {
            c.command = 0x16;
            return;
        }
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 8 * c.aiLevel > rnd(c, 0, 100) && o.state > 0x95 && o.state < 0x9d && (c.state === 0x100 || c.state === 0x101 || c.state === 0x103 || c.state === 0x12c || c.state === 0x12d || c.state === 0x12e)) {
        c.command = 0x34;
        return;
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 1 * c.aiLevel > rnd(c, 0, 100) && c.d168 === 3 && (c.state === 0xfd && c.frame === 0xd || c.state === 0xfe && c.frame === 0xd)) {
        c.command = 0x34;
        return;
    }
    if (c.aiMode > 0 && c.state > 0x31 && c.state < 0x9e) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 0xc8) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = s8(rnd(c, 0, 2) - 1);
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = forwardDash(c);
            if (c.state === 0xa5) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 0x32) {
        c.command = forwardDash(c);
        if (c.state === 0xa3) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6 && c.state < 0x32) {
        c.command = forwardDash(c);
        if (c.state === 0xa3) c.aiMode = 7;
        return;
    }
    if (c.aiMode === 7 && c.state === 0xa3) {
        c.pressed[0] = 1;
        if (c.state === 0xe6) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 8 && c.state < 0x32) {
        c.command = forwardDash(c);
        if (c.state === 0xa3) c.aiMode = 9;
        return;
    }
    if (c.aiMode === 9 && c.state === 0xa3) {
        c.pressed[0] = 2;
        if (c.state === 0xe7) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 10 && c.state < 0x32) {
        c.command = forwardDash(c);
        if (c.state === 0xa3) c.aiMode = 11;
        return;
    }
    if (c.aiMode === 11 && c.state === 0xa3) {
        c.pressed[0] = 3;
        if (c.state === 0xe8) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 12 && c.state < 0x32) {
        c.command = 0x46;
        if (c.state === 0xfa) c.aiMode = 0;
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && c.aiLevel * 25 > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.state === 0xc8) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 40.0 && c.aiRoll < 0xa) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x64 && c.aiRoll < 0x190) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x190 && c.aiRoll < 0x1b8) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 1) === 0) c.aiMode = 6;
                if (c.d168 === 3 && rnd(c, 0, 3) === 0) c.aiMode = 12;
                return;
            }
        }
        if (c.state === 0xc9) {
            if (o.y < 0.0 && c.aiRoll < 0xc8 && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x14;
                return;
            }
            if (o.y < 0.0 && c.aiRoll < 0xc8 && c.d168 === 3) {
                c.inputX = c.facing;
                c.inputY = -1;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x140 && c.aiRoll < 0x258 && dx < 100.0) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll < 0xc8 && c.d168 === 3 && o.y === 0.0 && dx < 80.0) {
                c.command = 0x1e;
                return;
            }
            if (c.aiRoll < 0x190 && c.d168 === 3 && o.y === 0.0 && dx < 80.0) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll < 0x15e && o.y === 0.0) {
                c.command = rnd(c, 0, 2) + 0xa;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x226 && dx < 90.0) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x226 && c.aiRoll < 0x2bc) {
                c.pressed[2] = 1;
                c.inputY = rnd(c, 0, 1) === 0 ? 1 : 0;
                return;
            }
            if (c.aiRoll > 0x398) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                if (rnd(c, 0, 1) === 0) {
                    c.aiMode = 6;
                    if (dx > 110.0) c.aiMode = 8;
                    return;
                }
            }
        }
        if (c.state === 0xca) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x14;
                return;
            }
            if (c.aiRoll < 0x64) {
                c.pressed[2] = 1;
                c.inputY = rnd(c, 0, 1) === 0 ? 1 : 0;
                return;
            }
            if (c.aiRoll > 0x64 && c.aiRoll < 0x190 && c.d168 === 3) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x64 && c.aiRoll < 0x12c) {
                c.command = rnd(c, 0, 2) + 0xa;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                if (rnd(c, 0, 1) === 0) {
                    c.aiMode = 6;
                    if (dx > 110.0) c.aiMode = 8;
                    return;
                }
            }
        }
        if (c.state === 0xcb) {
            if (c.aiRoll > 0x15e && c.aiRoll < 0x190 && c.rfGauge > 500.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0x190 && c.f344c === 1) {
                c.command = 0x46;
                return;
            }
        }
        if (c.state === 0xcc) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 40.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 50.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                c.inputY = 0;
                if (c.d168 === 2 && rnd(c, 0, 100) < 0x14) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                }
                return;
            }
            if (dx < 135.0 && c.aiRoll < 0x258) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 1) === 0) c.aiMode = 5;
                return;
            }
        }
        if (c.state === 0xcd) {
            if (c.aiRoll < 0x190 && dx < 80.0 && c.d168 === 3) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll < 0x64 && o.y === 0.0) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x12c && c.aiRoll < 0x258) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x384) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xce) {
            if (c.aiRoll > 0 && c.aiRoll < 0x190 && c.f344c === 1) {
                c.command = 0x46;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0x12c) {
                c.command = rnd(c, 0, 2) + 0xa;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x190 && c.rfGauge > 500.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x190 && c.aiRoll < 0x1c2 && c.d168 === 3 && c.meter >= 0x3e8 && dx < 90.0) {
                c.command = rnd(c, 0, 2) + 0x6e;
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcf) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                return;
            }
            if (dx < 60.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x18f && c.aiRoll < 0x2bc) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 4) === 0) c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd0) {
            if (c.aiRoll > 0x50 && c.aiRoll < 0x12c) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd1) {
            if (c.aiRoll > 0x3b6) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xe7) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x14;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0x190 && c.f344c === 1) {
                c.command = 0x46;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0xc8) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x190 && c.rfGauge > 500.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x190 && c.aiRoll < 0x2bc) {
                c.command = rnd(c, 0, 2) + 0x1e;
                return;
            }
            if (c.aiRoll > 0x289 && rnd(c, 0, 3) === 0) {
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
            }
        }
    }
    if (25 * c.aiLevel > rnd(c, 0, 100)) {
        if (c.f344c === 1) c.pressed[3] = 1;
        c.aiRoll = rnd(c, 0, 1000);
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 0x63) {
                if (dx < 40.0 && o.y === 0.0 && c.aiRoll < 3) {
                    c.pressed[2] = 1;
                    c.inputX = s8(-c.facing);
                    c.inputY = 0;
                    return;
                }
                if (dx < 50.0 && o.y === 0.0 && c.aiRoll < 8) {
                    c.command = 0x46;
                    return;
                }
                if (100 - (c.f344c === 1 ? 1 : 0) * 0x1e > dx && c.aiRoll < 0x14) {
                    c.pressed[0] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 0x1e) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if ((c.f344c === 1 ? 1 : 0) * 0xa + 100 > dx && dx > 70.0 && c.aiRoll < 0xf) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (140 - (c.f344c === 1 ? 1 : 0) * 0x28 > dx && c.aiRoll < 0x14) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx > 160.0 && c.aiRoll < 0x1a) {
                    c.aiMode = 8;
                    return;
                }
                if (dx > 160.0 && c.aiRoll < 0x20) {
                    c.aiMode = 10;
                    return;
                }
                if (170 - (c.f344c === 1 ? 1 : 0) * 0x3c > dx && 120 - (c.f344c === 1 ? 1 : 0) * 0x28 < dx && c.aiRoll < 0x25) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 220.0 && dx > 70.0 && c.aiRoll < 0x28) {
                    c.pressed[2] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 0x2a && c.aiRoll > 0x28) {
                    c.command = 0x14;
                    return;
                }
                if (c.aiRoll < 0x2a && c.aiRoll > 0x32) {
                    c.command = c.facing & 0xffff;
                    c.aiMode = 5;
                    return;
                }
                if (dx > 180.0 && c.aiRoll > 0xfa && c.aiRoll < 0xfc && c.meter >= 0x3e8) {
                    c.command = rnd(c, 0, 2) + 0x6e;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < 0xa) {
                        c.inputY = -1;
                        c.inputX = s8(-c.facing);
                        return;
                    }
                    if (dx < 120.0 && c.aiRoll < 0x1e && c.f344c === 0) {
                        c.pressed[1] = 1;
                        c.inputY = 1;
                        return;
                    }
                    if (dx > 80.0 && dx < 120.0 && dy > 70.0 && c.aiRoll < 0x1e && c.f344c === 1) {
                        c.pressed[1] = 1;
                        c.inputY = 1;
                        return;
                    }
                    if (dx > 120.0 && dx < 180.0 && dy > 90.0 && c.aiRoll < 0x1e && c.f344c === 1) {
                        c.aiMode = 10;
                        return;
                    }
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < 0x23) {
                        c.command = 0x15;
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < (c.rfGauge > 500.0 || c.rfBlue > 0 ? 1 : 0) * 5 + 6) {
                        c.command = 0x14;
                        return;
                    }
                    if (dx < 90.0 && dy < 120.0 && dy > 90.0 && c.aiRoll < 0xf) {
                        c.pressed[1] = 1;
                        c.inputY = 1;
                        return;
                    }
                    if (dx < 120.0 && dy < 100.0 && c.aiRoll < 0x11 && c.meter === 0xbb8) {
                        c.command = 0x99;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 100.0 && dy < 100.0 && c.aiRoll < (o.y === 0.0 ? 1 : 0) * 0x64 + 0x64) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 120.0 && dy < 100.0 && c.aiRoll > 0xc8 && c.aiRoll < 0x104) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 140.0 && dx > 80.0 && dy > 40.0 && dy < 80.0 && c.aiRoll > 0x104 && c.aiRoll < 0x109) {
                    c.pressed[2] = 1;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 120.0 && dy < 90.0 && o.y > c.y && c.aiRoll < 0x6e) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 120.0 && dy < 90.0 && c.aiRoll < 0x136) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 150.0 && dx > 100.0 && dy < 90.0 && c.aiRoll < 0x190) {
                    c.pressed[2] = 1;
                    return;
                }
            }
        }
    }
    if (c.state < 0x32 && (o.state > 0x95 && o.state < 0x9c || o.state > 0x31 && o.state < 0x3b) && c.y === 0.0 && 3 * c.aiLevel > rnd(c, 0, 100)) {
        c.command = forwardDash(c);
        return;
    }
    if (c.state < 0x32 && o.state < 0x32 && dx > 60.0 && dx < 100.0 && 1 * c.aiLevel > rnd(c, 0, 100)) {
        c.command = c.facing === 1 ? 0 : 1;
        return;
    }
    if (rnd(c, 0, 1000) < 2) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 160.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 100.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 170.0 && dx > 120.0 && c.y === 0.0) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 0xf) c.aiTimer1a0 = 0xf;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 0xf) c.aiTimer1a4 = 0xf;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 0x32 && dx < 120.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x3c;
        else c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x3c;
    }
    if (rnd(c, 0, 100) < 0x3c) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x1e;
        else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x1e;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x1e;
    else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x1e;
}
function loopAnim(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = 0;
}
function shard(c, i, p) {
    const ch = c.children[i];
    if (c.state > 0x31 && c.state < 0x96) ch.hitsLeft = 0;
    if (c.a314c[i] === 0) {
        ch.vx = rnd(c, 0, p.rx) * 0.1;
        ch.vy = p.vy0 - rnd(c, 0, 10) * 0.1;
        ch.hitsLeft = 1;
        c.a314c[i]++;
    }
    ch.vy = ch.vy + 0.035;
    const hit = ch.vy + ch.y > 0.0 || p.form === 0 && ch.hitState > 1;
    if (hit && ch.blend === 0) {
        ch.vy = -ch.vy * 0.5;
        ch.blend = 1;
        ch.hitsLeft = 0;
        const f = childSpawnFrame;
        for(let k = 0; k < 3; k++){
            f.w04 = rnd(c, 0, 1) + 0x199 & 0xffff;
            f.x = ftol(ch.x);
            f.y = p.form === 0 ? ftol(ch.y) : 0.0;
            if (k === 0) {
                f.b18 = c.facing;
                f.b21 = 1;
                f.b20 = 0;
            }
            frameChild(c, f);
        }
        if (p.freeFirst) {
            c.freeChild(i);
            c.voiceRequest = 1;
        } else {
            c.voiceRequest = 1;
            c.freeChild(i);
        }
        return;
    }
    loopAnim(c, i);
}
function chip0(c, i, r, g) {
    const ch = c.children[i];
    if (c.a314c[i] === 0) {
        ch.vx = rnd(c, 0, r) * 0.1;
        ch.vy = -1.0 - rnd(c, 0, r) * 0.05;
        c.a314c[i] = 1;
    }
    ch.vy = ch.vy + g;
    if (ch.vy + ch.y > 0.0 && c.a314c[i] === 1) {
        ch.vy = -ch.vy * 0.5;
        ch.y = 0.0;
        ch.blend = 1;
        c.a314c[i] = 2;
    }
    if (ch.vy + ch.y > 0.0 && c.a314c[i] === 2) {
        c.freeChild(i);
        return;
    }
    loopAnim(c, i);
}
function chip1(c, i) {
    const ch = c.children[i];
    if (c.state > 0x31 && c.state < 0x96) ch.hitsLeft = 0;
    if (c.a314c[i] === 0) {
        ch.vx = rnd(c, 0, 10) * 0.1;
        ch.vy = -1.0 - rnd(c, 0, 10) * 0.05;
        c.a314c[i]++;
    }
    ch.vy = ch.vy + 0.035;
    if (ch.vy + ch.y > 0.0 && ch.blend === 0) {
        ch.vy = -ch.vy * 0.5;
        ch.y = 0.0;
        ch.blend = 1;
        ch.hitsLeft = 0;
    }
    if (ch.vy + ch.y > 0.0 && ch.blend === 1) {
        c.freeChild(i);
        return;
    }
    loopAnim(c, i);
}
function child411(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    405: (c, i)=>shard(c, i, {
            rx: 10,
            vy0: -2.0,
            form: 0,
            freeFirst: false
        }),
    406: (c, i)=>shard(c, i, {
            rx: 5,
            vy0: -2.3,
            form: 0,
            freeFirst: false
        }),
    407: (c, i)=>shard(c, i, {
            rx: 4,
            vy0: -2.5,
            form: 0,
            freeFirst: true
        }),
    408: (c, i)=>shard(c, i, {
            rx: 13,
            vy0: -1.7,
            form: 0,
            freeFirst: false
        }),
    409: (c, i)=>chip0(c, i, 10, 0.035),
    410: (c, i)=>chip0(c, i, 15, 0.045),
    411: child411
});
registerChildren2({
    405: (c, i)=>shard(c, i, {
            rx: 10,
            vy0: -2.0,
            form: 1,
            freeFirst: false
        }),
    406: (c, i)=>shard(c, i, {
            rx: 5,
            vy0: -2.3,
            form: 1,
            freeFirst: false
        }),
    407: (c, i)=>shard(c, i, {
            rx: 4,
            vy0: -2.5,
            form: 1,
            freeFirst: true
        }),
    408: (c, i)=>shard(c, i, {
            rx: 13,
            vy0: 1.7,
            form: 1,
            freeFirst: false
        }),
    409: chip1,
    410: chip1,
    411: child411
});
