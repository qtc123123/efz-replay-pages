import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { HISTORY_LENGTH, NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
function hist(c, i) {
    return c.history[i - (i >= HISTORY_LENGTH ? 1 : 0) * HISTORY_LENGTH];
}
function buttonCommand(base, v) {
    return base + ((v & 0xe0) > 0 ? 1 : 0) + ((v & 0xc0) > 0 ? 1 : 0) + ((v & 0x80) > 0 ? 1 : 0);
}
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function cancelable(c) {
    return ((c.currentHit()?.defenseFlags ?? 0) & 8) > 0;
}
function priorityOk(c, target) {
    return (c.patterns[c.state]?.hdrB ?? 0) <= (c.patterns[target]?.hdrA ?? 0);
}
function cancelOk(c) {
    if (c.state >= 200 && c.d168 >= 2 && c.d168 !== 6) return true;
    return c.state < 200;
}
function rfOk(c) {
    return c.rfGauge >= 500.0 || c.rfBlue > 0;
}
function enter(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function moveOk(c, target) {
    return cancelable(c) && cancelOk(c) && priorityOk(c, target);
}
function level13(c) {
    return c.f3158 === 1 || c.f3158 === 3;
}
function level23(c) {
    return c.f3158 === 2 || c.f3158 === 3;
}
function drawPart(c, pattern, frame, baseL, baseR, baseY, len) {
    const f = c.patterns[pattern]?.frames[frame];
    if (!f) return;
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    const w = len(f.width);
    const src = makeRect(0, 0, w, f.height);
    const dst = c.side === 0 ? makeRect(baseL - f.offsetX, baseY - f.offsetY, w, f.height) : makeRect(f.offsetX + baseR - w, baseY - f.offsetY, w, f.height);
    blit(dst, surf, src, c.colorKey, false);
}
export function renderOverlayMishio(c) {
    c.f3164 = c.f3164 + 1;
    if (c.f3164 > 29) c.f3164 = 0;
    const anim = Math.trunc(c.f3164 / 6);
    if (c.f3158 === 0) drawPart(c, 39, 0, 11, 310, 196, (w)=>w);
    if (c.f3158 === 1) drawPart(c, 40, anim, 11, 310, 196, (w)=>w);
    if (c.f3158 === 2) drawPart(c, 41, anim, 11, 310, 196, (w)=>w);
    if (c.f3158 === 3) drawPart(c, 42, anim, 11, 310, 196, (w)=>w);
    if (c.f3168 > 0) drawPart(c, 43, 0, 0x31, 0x10f, 0x1f, (w)=>w);
    if (c.f3168 > 0) drawPart(c, 44, 0, 0x31, 0x10f, 0x1f, (w)=>Math.trunc(w * c.f3168 / 0x1194));
}
export function parseCommandMishio(c) {
    c.command = NO_COMMAND;
    const idx = c.historyIndex;
    const end = idx + HISTORY_LENGTH;
    const left = c.facing === -1 ? 1 : 0;
    const BACK = 2 - left;
    const FWD = 1 + left;
    const DOWN_BACK = 6 - left;
    const DOWN_FWD = 5 + left;
    let step;
    let v;
    step = 0;
    for(let i = idx; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 6) {
            c.command = 98;
            return;
        }
        if (v & 0x40 && step === 5) step = 6;
        if (v & 0xb0 && step === 4) break;
        if (v === 0 && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if (v & 0xd0 && step === 2) break;
        if (v & 0x20 && step === 2) step = 3;
        if (v === 0 && step === 1) step = 2;
        if (v & 0xd0 && step === 1) break;
        if (v & 0x20 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 5) {
            c.command = buttonCommand(0xaa, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 4) {
            if (v & 0xf0) {
                c.command = buttonCommand(0xa0, v);
                return;
            }
            step = 5;
        }
        if ((v & 0xf) === DOWN_FWD && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x69; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 4) {
            c.command = buttonCommand(0x78, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 3) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x78, v);
                return;
            }
            step = 4;
        }
        if ((v & 0xf) === DOWN_BACK && step === 2) step = 3;
        if ((v & 0xf) === BACK && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x64; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x64, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x64, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_FWD && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x6e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x6e, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_BACK && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x14, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x14, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x28, v);
            return;
        }
        if ((v & 0xf) === 4 && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x28, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x1e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x1e, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0xaf; i < end; i++){
        v = hist(c, i);
        if (v & 8 && step === 1) {
            c.command = 6;
            return;
        }
        if (!(v & 8) && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 4) {
            c.command = 53;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0 && c.state === 96) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 4) {
            c.command = 52;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 4) {
            c.command = 51;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 4) {
            c.command = 50;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 1 && step === 3) {
            c.command = 1;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 1 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 2 && step === 3) {
            c.command = 0;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 2 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
}
export function dispatchMovesMishio(c) {
    if (c.state < 200) c.bufferedA = 0;
    if (c.bufferTimer > 0) {
        c.bufferTimer = c.bufferTimer - 1 & 0xff;
    } else {
        c.bufferedB = 0;
    }
    if (c.bufferedB === 0) c.bufferTimer = 0;
    if (c.command === 52 && (c.rfGauge >= 500.0 && c.d168 > 1 || c.rfBlue > 0 && c.d168 > 1 && c.d168 !== 6) && cancelable(c) && priorityOk(c, 167)) {
        enter(c, 167);
        if (c.y < 0.0) c.state = 171;
        return;
    }
    if (c.d15c < 2) {
        if (c.life < 3333 && c.command === 98 && c.meter >= 3000 && cancelable(c) && c.y === 0.0 && c.d168 !== 6 && priorityOk(c, 318)) {
            enter(c, 318);
            return;
        }
        if (level23(c) && c.command === 122 && c.meter >= 3000 && c.y === 0.0 && moveOk(c, 314)) {
            enter(c, 314);
            return;
        }
        if (level23(c) && (c.command === 122 || c.command === 121) && c.meter >= 2000 && c.y === 0.0 && moveOk(c, 313)) {
            enter(c, 313);
            return;
        }
        if (level23(c) && (c.command === 120 || c.command === 121 || c.command === 122) && c.meter >= 1000 && c.y === 0.0 && moveOk(c, 312)) {
            enter(c, 312);
            return;
        }
        if (level13(c) && c.command === 112 && c.meter >= 3000 && c.y === 0.0 && moveOk(c, 305)) {
            enter(c, 305);
            return;
        }
        if (level13(c) && (c.command === 112 || c.command === 111) && c.meter >= 2000 && c.y === 0.0 && moveOk(c, 304)) {
            enter(c, 304);
            return;
        }
        if (level13(c) && (c.command === 110 || c.command === 111 || c.command === 112) && c.meter >= 1000 && c.y === 0.0 && moveOk(c, 303)) {
            enter(c, 303);
            return;
        }
        if (level23(c) && c.command === 102 && c.meter >= 3000 && c.y < 0.0 && moveOk(c, 302)) {
            enter(c, 317);
            return;
        }
        if (level23(c) && (c.command === 102 || c.command === 101) && c.meter >= 2000 && c.y < 0.0 && moveOk(c, 301)) {
            enter(c, 316);
            return;
        }
        if (level23(c) && (c.command === 100 || c.command === 101 || c.command === 102) && c.meter >= 1000 && c.y < 0.0 && moveOk(c, 300)) {
            enter(c, 315);
            return;
        }
        if (level13(c) && c.command === 102 && c.meter >= 3000 && c.y === 0.0 && moveOk(c, 302)) {
            enter(c, 302);
            return;
        }
        if (level13(c) && (c.command === 102 || c.command === 101) && c.meter >= 2000 && c.y === 0.0 && moveOk(c, 301)) {
            enter(c, 301);
            return;
        }
        if (level13(c) && (c.command === 100 || c.command === 101 || c.command === 102) && c.meter >= 1000 && c.y === 0.0 && moveOk(c, 300)) {
            enter(c, 300);
            return;
        }
        if (level23(c) && c.f314c === 0 && c.command === 51 && c.y === 0.0 && moveOk(c, 272)) {
            enter(c, 272);
            return;
        }
        if (level23(c) && c.f314c === 0 && c.command === 50 && c.y === 0.0 && moveOk(c, 271)) {
            enter(c, 271);
            return;
        }
        if (level23(c) && c.f3148 === 0 && rfOk(c) && c.command === 42 && c.y === 0.0 && moveOk(c, 270)) {
            enter(c, 270);
            return;
        }
        if (level23(c) && c.f3148 === 0 && (c.command === 41 || c.command === 42) && c.y === 0.0 && moveOk(c, 269)) {
            enter(c, 269);
            return;
        }
        if (level23(c) && c.f3148 === 0 && c.command === 40 && c.y === 0.0 && moveOk(c, 256)) {
            enter(c, 268);
            return;
        }
        if (c.command === 22 && rfOk(c) && cancelable(c) && c.y === 0.0 && cancelOk(c) && priorityOk(c, 252)) {
            c.onStateChange();
            clearBufferedInput(c);
            if (c.f3158 === 0) c.state = 252;
            if (c.f3158 === 1) c.state = 275;
            if (c.f3158 === 2) c.state = 278;
            if (c.f3158 === 3) c.state = 281;
            return;
        }
        if ((c.command === 21 || c.command === 22) && cancelable(c) && c.y === 0.0 && cancelOk(c) && priorityOk(c, 251)) {
            c.onStateChange();
            clearBufferedInput(c);
            if (c.f3158 === 0) c.state = 251;
            if (c.f3158 === 1) c.state = 274;
            if (c.f3158 === 2) c.state = 277;
            if (c.f3158 === 3) c.state = 279;
            return;
        }
        if (c.command === 20 && cancelable(c) && c.y === 0.0 && cancelOk(c) && priorityOk(c, 250)) {
            c.onStateChange();
            clearBufferedInput(c);
            if (c.f3158 === 0) c.state = 250;
            if (c.f3158 === 1) c.state = 273;
            if (c.f3158 === 2) c.state = 276;
            if (c.f3158 === 3) c.state = 279;
            return;
        }
        if (level13(c) && c.command === 32 && moveOk(c, 258)) {
            enter(c, 256);
            if (c.y < 0.0) c.state = 261;
            return;
        }
        if (level13(c) && (c.command === 31 || c.command === 32) && moveOk(c, 257)) {
            enter(c, 258);
            if (c.y < 0.0) c.state = 260;
            return;
        }
        if (level13(c) && c.command === 30 && moveOk(c, 257)) {
            enter(c, 257);
            if (c.y < 0.0) c.state = 259;
            return;
        }
        if (level13(c) && c.command === 12 && rfOk(c) && c.y === 0.0 && moveOk(c, 255)) {
            enter(c, 255);
            return;
        }
        if (level13(c) && (c.command === 11 || c.command === 12) && c.y === 0.0 && moveOk(c, 253)) {
            enter(c, 253);
            return;
        }
        if (level13(c) && c.state !== 254 && c.command === 10 && c.y === 0.0 && moveOk(c, 254)) {
            enter(c, 254);
            return;
        }
    }
    if (c.d15c === 0 && (c.command === 0 || c.command === 1)) {
        const dir = 1 - (c.command << 1);
        if (c.y < 0.0 && c.b159 < 1) {
            const dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 165) && c.state !== 170 && c.y < -40.0 && cancelable(c) && cancelOk(c)) {
                airDash(c, 165);
                return;
            }
            const dx2 = c.opponent.x - c.x;
            if ((dx2 * dir > 0.0 || dx2 === 0.0 && c.facing === dir) && priorityOk(c, 166) && c.state !== 170 && cancelable(c) && cancelOk(c)) {
                airDash(c, 166);
                return;
            }
        }
        if (c.y === 0.0 && cancelable(c)) {
            const dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 163) && cancelOk(c)) {
                if (c.state !== 163) c.onStateChange();
                c.state = 163;
                c.faceOpponent();
                c.b158 = c.b158 + 1 & 0xff;
                c.bufferedA = 0;
                return;
            }
            const dx2 = c.opponent.x - c.x;
            if ((dx2 * dir > 0.0 || dx2 === 0.0 && c.facing === dir) && priorityOk(c, 164) && cancelOk(c)) {
                if (c.state !== 164) c.onStateChange();
                c.state = 164;
                c.faceOpponent();
                c.bufferedA = 0;
                return;
            }
        }
    }
    if (c.d15c < 3 && c.command === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && priorityOk(c, 14) && cancelOk(c)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return;
    }
    if (c.pressed[0] === 1 || c.bufferedA & 0x10 || c.bufferedB & 0x10) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 230);
            if (c.inputY === 1) c.state = 233;
            return;
        }
        if (c.y < 0.0) {
            if (moveOk(c, 207)) enter(c, 207);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && moveOk(c, 204)) {
            enter(c, 204);
            return;
        }
        if ((c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) && moveOk(c, 200)) {
            enter(c, 200);
            return;
        }
    }
    if (c.pressed[1] === 1 || c.bufferedA & 0x20 || c.bufferedB & 0x20) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 231);
            if (c.inputY === 1) c.state = 234;
            return;
        }
        if (c.y < 0.0) {
            if (moveOk(c, 208)) enter(c, 208);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && moveOk(c, 205)) {
            enter(c, 205);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (level23(c) && c.inputX === c.facing && moveOk(c, 210)) {
                enter(c, 210);
                return;
            }
            if (priorityOk(c, 201) && cancelable(c) && c.x - c.opponent.x > -90.0 && c.x - c.opponent.x < 90.0 && cancelOk(c)) {
                enter(c, 201);
                return;
            }
            if (moveOk(c, 202)) {
                enter(c, 202);
                return;
            }
        }
    }
    if (c.pressed[2] === 1 || c.bufferedA & 0x40 || c.bufferedB & 0x40) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 232);
            if (c.inputY === 1) c.state = 235;
            return;
        }
        if (c.y < 0.0) {
            if (c.inputX === c.facing && c.inputY === 0 && c.x - c.opponent.x > -100.0 && c.x - c.opponent.x < 100.0 && c.opponent.y < 0.0 && priorityOk(c, 248) && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 248);
                return;
            }
            if (moveOk(c, 209)) enter(c, 209);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && moveOk(c, 206)) {
            enter(c, 206);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (c.inputX !== 0 && c.opponent.y === 0.0 && c.x - c.opponent.x > -30.0 && c.x - c.opponent.x < 30.0 && priorityOk(c, 220) && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 220);
                return;
            }
            if (level13(c) && priorityOk(c, 211) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 211);
                return;
            }
            if (moveOk(c, 203)) {
                enter(c, 203);
                return;
            }
        }
    }
}
function airDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    c.b159 = c.b159 + 1 & 0xff;
    c.b15a = c.b15a + 1 & 0xff;
    c.bufferedA = 0;
}
