import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./da358c15d9881aea726bad32.mjs";
import { registerChildren, registerStates } from "./8eb7102cae7a3c1156bb8cc7.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { frameCount, frameDuration, s16 } from "./7596266716c972d06fe8897a.mjs";
function rfCostEffect(c, f) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function jumpEffect(f, c) {
    f.w04 = 8;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y);
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function dustEffect(f, c, mirror) {
    f.w04 = 0x1f;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y);
    f.b20 = 0;
    f.b21 = 1;
    f.d1c = mirror;
    frameEffect(f);
}
function spawnFromBody(c, f, pattern, dx, dy) {
    f.w04 = pattern;
    f.x = Math.trunc(c.x) + c.facing * dx;
    f.y = Math.trunc(c.y) - dy;
    f.b20 = 2;
    f.b21 = 1;
    f.b18 = c.facing;
    frameChild(c, f);
}
function hopStart(c) {
    c.b158 = 0;
    if (c.y === 0.0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    c.meter = s16(c.meter + 0x2d);
    c.w16c = 0;
    if (c.y < 0.0) {
        c.frame = 2;
        c.timer = 0;
    }
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) hopStart(c);
    if (c.frame === 6 && c.timer === 0) {
        if (c.y === 0.0) {
            dustEffect(f, c, c.facing - 1 !== 0 ? 1 : 0);
        }
        c.w16c = 0;
    }
    if (c.frame === 6 && c.timer === 0) {
        jumpEffect(f, c);
        c.vx = 1.4;
        c.vy = -1.5;
        c.ay = 0.03;
    }
    if (c.frame > 5 && c.vy > 0.2 && c.f3138 === 0) {
        c.frame = 13;
        c.w16c = 1;
        c.timer = 0;
        c.f3138 = 1;
    }
    if (c.frame === 14 && c.timer === 0) c.w16c = 1;
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.frame > 6 && c.y + c.vy > 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
        c.state = 0xfd;
        c.frame = 0;
        c.timer = 0;
        c.f3138 = 0;
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 3) c.d168 = 0;
        if (c.frame === 13) c.frame = 7;
        if (c.frame === 5 || c.frame === 14) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0xfd;
            c.onStateChange();
        }
    }
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) hopStart(c);
    if (c.frame === 2 && c.timer === 0) {
        if (c.y === 0.0) {
            dustEffect(f, c, c.facing - 1 !== 0 ? 1 : 0);
        }
        c.w16c = 1;
    }
    if (c.frame === 6 && c.timer === 0) {
        jumpEffect(f, c);
        c.vx = 1.4;
        c.vy = -1.5;
        c.ay = 0.03;
    }
    if (c.frame > 5 && c.vy > 0.8 && c.f3138 === 0) {
        c.frame = 13;
        c.w16c = 1;
        c.timer = 0;
        c.f3138 = 1;
    }
    if (c.frame === 14 && c.timer === 0) c.w16c = 1;
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.frame > 6 && c.y + c.vy > 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
        c.state = 0xfd;
        c.frame = 0;
        c.timer = 0;
        c.f3138 = 0;
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 3) c.d168 = 0;
        if (c.frame === 5 || c.frame === 14) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0xfd;
            c.onStateChange();
        }
    }
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.startAfterimage(3);
        rfCostEffect(c, f);
        c.w16c = 1;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.w16c = 1;
        if (c.y < 0.0) c.frame = 6;
    }
    if (c.frame === 2 && c.timer === 0) {
        dustEffect(f, c, c.facing + 1 !== 0 ? 0 : 1);
    }
    if (c.frame === 6 && c.timer === 0) {
        f.w04 = 8;
        f.x = Math.trunc(c.x);
        f.y = Math.trunc(c.y);
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        frameEffect(f);
        c.vx = 1.2;
        c.vy = -2.9;
        c.ay = 0.035;
    }
    if (c.frame > 5 && c.vy > 0.2 && c.f3138 === 0) {
        if (s16(c.w16c) === 1) {
            c.state = 0xfd;
            c.onStateChange();
            return;
        }
        c.frame = 13;
        c.timer = 0;
        c.f3138 = 1;
    }
    if (c.frame === 18 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = -1.8;
        c.seRequest = 0x12;
        spawnFromBody(c, f, 0x199, 0, 0x14);
        c.w16c = 1;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 13) c.frame = 7;
        if (c.frame === 6) c.w13c = 0x3c;
        if (c.frame === 5 || c.frame === 17) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0xfd;
            c.frame = 0;
            c.timer = 0;
            c.f3138 = 0;
        }
    }
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (c.y + c.vy >= 0.0 && c.frame < 2 && c.f3138 === 0) {
        c.y = 0.0;
        c.f3138 = c.f3138 + 1;
        c.seRequest = 9;
        c.frame = 2;
        c.timer = 0;
        c.ay = 0.0;
        c.vx = 0.0;
        c.vy = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 2) c.frame = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function shotTail(c, dur, cnt) {
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 12 && c.f3138 !== 0) {
            c.f3138 = c.f3138 - 1;
            c.frame = c.frame - 2;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function groundShot(c, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (c.frame === 3 && c.timer === 0) {
        spawnFromBody(c, f, pattern, 0, 0);
        c.seRequest = 0x12;
        c.meter = s16(c.meter + 0x19);
    }
    shotTail(c, dur, cnt);
}
function state254(c) {
    groundShot(c, 0x196);
}
function state255(c) {
    groundShot(c, 0x197);
}
function state256(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.startAfterimage(3);
        rfCostEffect(c, f);
    }
    if (c.frame === 3 && c.timer === 0) {
        spawnFromBody(c, f, 0x1a1, 0x14, 0);
        c.meter = s16(c.meter + 0xf);
    }
    shotTail(c, dur, cnt);
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        rfCostEffect(c, f);
        c.startAfterimage(3);
        c.w16c = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.frame === 4 && c.d168 === 3) {
        c.f3138 = 0;
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        o.d128 = 1;
        o.y = -85.0;
        o.x = c.facing * 0x27 + c.x;
        f.w04 = 0;
        f.x = Math.trunc(c.x) + c.facing * 0x24;
        f.y = Math.trunc(c.y) - 0x29;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.state = 0x103;
        o.state = 0x67;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 4 && o.y < 0.0) {
            c.w16c = 1;
        } else {
            c.w16c = 0;
        }
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 6) c.biasCameraY(0x32, 3);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 1) {
        o.onStateChange();
        o.state = 0x67;
        o.y = -98.0;
        o.x = c.facing * 0x23 + c.x;
    }
    if (c.frame === 2) {
        o.onStateChange();
        o.y = -98.0;
        o.x = c.facing * 0x21 + c.x;
    }
    if (c.frame === 3) {
        if (c.f3138 < 3) {
            o.y = 0.0;
            o.x = c.facing * 0x21 + c.x;
            o.facing = -c.facing;
            o.onStateChange();
            o.state = 0x61;
            o.d12c = 1;
            applyDirectDamage(c, 0x15e, 960.0);
        } else {
            c.frame = 6;
            o.y = -75.0;
            o.state = 0x3f;
            o.onStateChange();
            c.w16c = 1;
            c.d168 = 0;
        }
    }
    if (c.frame === 6 && c.f3138 < 3) {
        c.f3138 = c.f3138 + 1;
        c.frame = 0;
        o.y = -85.0;
        o.x = c.facing * 0x27 + c.x;
        o.state = 0x67;
        o.onStateChange();
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function airThrow(c, jumpVy, knockX, knockY, damage) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.b158 = 0;
    if (c.y >= 0.0) c.w16c = 0;
    if (c.frame > 6) c.d168 = 3;
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.meter = s16(c.meter + 0x2d);
        if (c.y < 0.0) c.frame = 5;
    }
    if (c.frame > 4 && c.frame < 7 && c.d168 === 3 && o.y < 0.0) {
        o.stopMotion();
        o.onStateChange();
        c.stopMotion();
        o.d128 = 1;
        f.w04 = 0;
        f.x = Math.trunc(c.x) + c.facing * 0x36;
        f.y = Math.trunc(c.y) - 0x54;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.frame = 7;
        c.timer = 0;
        o.state = 0x64;
        o.y = c.y - 61.0;
        o.x = c.facing * 0x13 + c.x;
        return;
    }
    if (c.frame > 4 && c.frame < 7 && c.vy > 0.0 && c.y < 0.0) {
        c.vx = 0.0;
        c.onStateChange();
        c.state = 0xfd;
        return;
    }
    if (c.frame === 5 && c.timer === 0 && c.f3138 === 0) {
        jumpEffect(f, c);
        c.vx = 1.4;
        c.vy = jumpVy;
        c.ay = 0.059;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.y < -40.0 && o.y < 0.0) {
        c.w16c = 1;
    } else {
        c.w16c = 0;
    }
    if (c.frame === 7 && c.f3138 < 10) {
        c.frame = 5;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame === 8) {
        o.state = 0x64;
        o.y = c.y - 59.0;
        o.x = c.facing * 0xf + c.x;
    }
    if (c.frame === 9) {
        o.y = c.y - 67.0;
        o.x = c.facing * 0xb + c.x;
    }
    if (c.frame === 10) {
        o.y = c.y - 64.0;
        o.x = c.x;
    }
    if (c.frame === 11) {
        o.state = 0x65;
        o.y = c.y - 66.0;
        o.x = c.x - c.facing * 0x16;
        o.facing = -c.facing;
    }
    if (c.frame === 12) {
        o.y = c.y - 59.0;
        o.x = c.x - (c.facing << 4);
    }
    if (c.frame === 13) {
        o.onStateChange();
        o.state = 0x3c;
        o.knockX = knockX;
        o.knockY = knockY(c);
        o.ay = 0.035;
        applyDirectDamage(c, damage, 890.0);
        c.comboCount = s16(c.comboCount - 1);
        c.comboDisplay = s16(c.comboDisplay - 1);
        o.d128 = 1;
        o.y = c.y - 69.0;
        o.x = c.x - c.facing * 0x27;
    }
    if (c.frame >= cnt) {
        c.facing = -c.facing;
        c.ay = 0.035;
        c.state = 0xfd;
        c.onStateChange();
    }
}
function state257(c) {
    airThrow(c, -3.0, 2.5, ()=>-0.3, 0x352);
}
function state260(c) {
    airThrow(c, -4.0, 0.8, (m)=>-5.0 * m.proration / 10000.0, 0x28a);
}
function counterStance(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 3 && c.timer === 0) c.meter = s16(c.meter + 0x14);
    if (c.d168 === 6 && c.frame === 3) {
        c.onStateChange();
        c.d168 = 0;
        c.freeze = 0x5a;
        c.seRequest = 3;
        c.state = 0x106;
        f.w04 = 0;
        f.x = Math.trunc(c.x) - (c.facing << 3);
        f.y = Math.trunc(c.y) - 0x35;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state261(c) {
    counterStance(c);
}
function state265(c) {
    counterStance(c);
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 3 && c.timer === 0) {
        c.meter = s16(c.meter + 0xf);
        c.seRequest = 0x14;
        c.w16c = 1;
        f.w04 = 0x191;
        f.x = Math.trunc(c.x) + c.facing * 0x28;
        f.y = Math.trunc(c.y);
        f.b20 = 2;
        f.b18 = c.facing;
        f.d00 = 1;
        f.b21 = 1;
        frameChild(c, f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function airArc(c, w16cAt2, land, hit13) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 2 && c.timer === 0) c.w16c = w16cAt2;
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.frame > 3 && c.y + c.vy > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.frame = land;
        c.timer = 0;
        c.f3138 = 0;
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 3) c.d168 = 0;
        if (c.frame === 4 && c.timer === 0) {
            jumpEffect(f, c);
            c.vx = 1.4;
            c.vy = -1.5;
            c.ay = 0.03;
        }
        if (c.frame === 11 && c.f3138 < 1) {
            c.frame = 4;
            c.f3138 = c.f3138 + 1;
        }
        if (hit13 && c.frame === 13) {
            c.w16c = 1;
            c.d168 = 0;
        }
        if (c.frame === land) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state263(c) {
    airArc(c, 0, 19, true);
}
function state264(c) {
    airArc(c, 1, 15, false);
}
registerStates({
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    265: state265
});
function childAnimFree(c, i, clearHit) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (clearHit) ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child400(c, i) {
    childAnimFree(c, i, true);
}
function child401(c, i) {
    childAnimFree(c, i, true);
}
function child402(c, i) {
    childAnimFree(c, i, true);
}
function child403(c, i) {
    const ch = c.children[i];
    ch.hitsLeft = 1;
    if (ch.frame === 1 && ch.timer === 0 && c.a3248[i] === 0) {
        const f = childSpawnFrame;
        if (ch.y < -80.0) {
            f.w04 = 0x193;
            f.x = Math.trunc(ch.x);
            f.y = Math.trunc(ch.y) + 0x28;
            f.b20 = 2;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        if (ch.y >= -80.0) {
            f.w04 = 0x194;
            f.x = Math.trunc(ch.x);
            f.y = 0.0;
            f.b20 = 2;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        c.a3248[i] = c.a3248[i] + 1;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            if (c.a3248[i] === 1) ch.frame = 0;
            if (c.a3248[i] === 2) c.freeChild(i);
            c.a3248[i] = c.a3248[i] + 1;
        }
    }
}
function child404(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3248[i] === 0) {
        const f = childSpawnFrame;
        f.w04 = 0x195;
        f.x = Math.trunc(ch.x);
        f.y = Math.trunc(ch.y);
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            if (c.a3248[i] > 1) c.freeChild(i);
            ch.frame = 0;
            c.a3248[i] = c.a3248[i] + 1;
        }
    }
}
function child405(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 1) ch.hitsLeft = 1;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (c.a3148[i] < 0xf) {
            ch.frame = 0;
            c.a3148[i] = c.a3148[i] + 1;
        }
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function slidingShot(c, i, initVx, minVx) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = initVx;
        ch.vy = 0.0;
    }
    if (ch.hitState >= 2 || c.state > 0x31 && c.state < 0x96) {
        ch.pattern = 0x19a;
        ch.hitsLeft = 0;
        return;
    }
    ch.vx = ch.vx - 0.015;
    if (ch.vx < minVx) ch.vx = minVx;
    childAnimFree(c, i, false);
}
function child406(c, i) {
    slidingShot(c, i, 1.5, 0.2);
}
function child407(c, i) {
    slidingShot(c, i, 2.2, 0.4);
}
function child408(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    childAnimFree(c, i, false);
}
function child409(c, i) {
    childAnimFree(c, i, true);
}
function child410(c, i) {
    childAnimFree(c, i, true);
}
function child417(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        c.seRequest = 0x12;
        ch.vx = 1.0;
        const f = childSpawnFrame;
        f.w04 = 0x198;
        f.x = Math.trunc(ch.x);
        f.y = 0.0;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        c.a3148[i] = c.a3148[i] + 1;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            if (c.a3148[i] === 5) {
                c.freeChild(i);
                return;
            }
            ch.frame = 0;
        }
    }
}
registerChildren({
    400: child400,
    401: child401,
    402: child402,
    403: child403,
    404: child404,
    405: child405,
    406: child406,
    407: child407,
    408: child408,
    409: child409,
    410: child410,
    417: child417
});
