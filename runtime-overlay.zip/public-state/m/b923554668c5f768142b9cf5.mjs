import {CUSTOM_PALETTE_PROFILE,validatePaletteBinding}from"./palette-binding-v1.mjs?v=d355b42976748de04657d399b4f2b176b0a0b577f5a7587f3d5bed6450b834f7";
import {applyPaletteRanges}from"./palette-rgb0-v1.mjs?v=8b04c1035cc13242c7f0e4b8f775b429d8773c92e4a0c1de511a97d3f00e1a6e";
import {createPublicCapabilities}from"./c55be0cadf6ca862cb29af33.mjs";
import {admitPublicBattle,installPublicBattle}from"./1095e97f2f4a6605a8fbd33f.mjs";
import {publicClassKeys}from"./53f1cc2f52c41342a5e4fc99.mjs";
import manifest from"./355780e02cb82f235a1e61e5.mjs";
import {createCharacter}from"./3c855c5012961734a479c319.mjs";
import {createStageObject}from"./c6d7e3bfd7316f9666e0cf6b.mjs";
import * as vfs from"./197efe2647ca25903d217eb5.mjs";
import * as pat from"./fc9672cb87477a10c4e4290f.mjs";
import * as graphics from"./f0fa1d17b22aa5b0aa75bc83.mjs";
import * as game from"./11a8544a0f705ad2a3ee4f96.mjs";
const need=(v,c)=>{if(!v)throw Error('PUBLIC_RENDER_'+c);};
const filtered=(obj,keys)=>Object.assign(Object.create(Object.getPrototypeOf(obj)),Object.fromEntries(keys.map(k=>[k,obj[k]])));
export async function prepareRenderedPublicBattle(port,host,bytes,expected,{hashBytes,visualProfile='raw-source/1',paletteBinding,gameId}={}){
 need(['raw-source/1','historical-stock-fallback/1',CUSTOM_PALETTE_PROFILE].includes(visualProfile),'VISUAL_PROFILE');
 need(bytes instanceof Uint8Array&&bytes.length<=1048576&&typeof hashBytes==='function','BYTES');
 const bindingContext={gameId,epoch:expected.epoch,sourceStart:expected.sourceStart,artifactSha256:expected.sha256};
 const binding=visualProfile===CUSTOM_PALETTE_PROFILE?validatePaletteBinding(paletteBinding,bindingContext):null;
 need(binding||paletteBinding===undefined,'UNEXPECTED_PALETTE_BINDING');
 const owned=bytes.slice(),digest=await hashBytes(owned);
 const exactHash=value=>{need(value===owned,'HASH_OWNER');return digest;};
 const byId=new Map(),byValue=new WeakMap(),raster=[],validations=[];let used=false;
 const remember=(v,id)=>{need(byId.has(id)||byId.size<8,'RESOURCE_LIMIT');byId.set(id,v);byValue.set(v,id);return v;};
 const known=id=>{const [kind,name,hash]=id.split(':');return kind==='pat'?manifest.patterns[name]?.sha256===hash:kind==='sprite'&&!!manifest.characters[name]&&hash===(manifest.sha256??manifest.format);};
 const resource={identify:v=>byValue.get(v)??null,knows:known,has:id=>byId.has(id),resolve:id=>{need(byId.has(id),'RESOURCE_NOT_PREPARED');return byId.get(id);},stats:()=>({strongResources:byId.size})};
 const initial=port.snapshot(),battle=initial.machine.scenes[3];
 const logicalBattle=filtered(battle,publicClassKeys('Scene:BattleScene'));
 const facade={...port,snapshot(){const raw=port.snapshot();return {...raw,machine:{...raw.machine,scenes:raw.machine.scenes.map(s=>s===battle?logicalBattle:s)}};}};
 const caps=createPublicCapabilities(facade,resource);
 caps.classObjects.get('Scene:BattleScene').obj=battle;
 // Stable identity compares the same Battle prototype, without importing menu objects.
 const register=(type,obj)=>{const keys=publicClassKeys(type);need(keys,'CLASS');caps.registerClass(type,filtered(obj,keys));caps.classObjects.get(type).obj=obj;};
 const save=(obj,keys)=>raster.push([obj,Object.fromEntries(keys.filter(k=>Object.hasOwn(obj,k)).map(k=>[k,obj[k]]))]);
 save(battle,['palette']);
 const inspection=admitPublicBattle(owned,expected,exactHash,caps),selection=inspection.selection;
 if(binding)validatePaletteBinding(binding,bindingContext,selection);
 const stagePrefix='system/bg/bg'+String(selection.stage).padStart(2,'0');
 await vfs.preload(vfs.mountedFiles().map(e=>e.path).filter(p=>p.startsWith(stagePrefix+'.')||p.startsWith(stagePrefix+'b.')||p.startsWith(stagePrefix+'/')));
 game.gameState.mode=4;game.gameState.stage=selection.stage;game.gameState.usePal=[...selection.usePal];game.loadStageBackground(selection.stage);
 const fallbackSides=[];
 for(let side=0;side<2;side++){
  const c=createCharacter(selection.characters[side],side);c.color=selection.palettes[side];await vfs.preload(c.files());
  const customPath=c.name+'/'+c.name+(c.color+1)+'.pal',customPresent=vfs.readSync(customPath)!==null;
  if(selection.usePal[side]&&!customPresent&&!binding){need(visualProfile==='historical-stock-fallback/1','PALETTE_PROVENANCE_REQUIRED');fallbackSides.push(side);}
  c.load();
  if(visualProfile==='historical-stock-fallback/1'&&selection.usePal[side]){need(graphics.loadPalette(game.gameState.palette,c.name+'/'+c.name+'.dat',40*c.color,c.paletteBase,40),'STOCK_PALETTE');if(!fallbackSides.includes(side))fallbackSides.push(side);}
  const info=manifest.characters[c.name],raw=vfs.readSync(c.name+'/'+c.name+'.dat');need(info&&raw&&await hashBytes(raw)===info.spriteSourceSha256&&c.sprites.length===info.spriteCount,'SPRITE_PIN');
  // Metadata fixture proves every authored slot is present. Assert the loaded
  // actual source raster set rather than silently broadening presence.
  need(c.sprites.every(Boolean)&&Object.keys(c.sprites).length===info.spriteCount,'SPRITE_PRESENCE');
  c.spritePresence=remember(Object.freeze({count:info.spriteCount,retainedBytes:0,has:i=>Number.isInteger(i)&&i>=0&&i<info.spriteCount}),'sprite:'+c.name+':'+(manifest.sha256??manifest.format));
  save(c,['sprites','colorKey']);register('Actor:'+c.id+':'+side,c);
 }
 for(const type of new Set(inspection.doc.nodes.filter(n=>n.kind==='class').map(n=>n.type)))if(type.startsWith('Stage:')){const obj=createStageObject(Number(type.slice(6)));save(obj,['images','colorKey']);register(type,obj);}
 for(const id of inspection.resourceIds){
  if(byId.has(id))continue;const [kind,name]=id.split(':');need(kind==='pat','RESOURCE_KIND');const info=manifest.patterns[name];await vfs.preload([name]);const raw=vfs.readSync(name);need(raw&&await hashBytes(raw)===info.sourceSha256,'PAT_PIN');
  const bank=name==='system/effect/effect.pat'?initial.modules['src/game/effects.mjs'].patterns:info.kind===2?pat.parseCharacterPat(raw):pat.parseEffectPat(raw);remember(bank,id);validations.push({path:name,sha256:info.sourceSha256});
 }
 if(binding)applyPaletteRanges(game.gameState.palette,binding.ranges.map(r=>({...r,custom:true,rgb0:Uint8Array.from(r.rgb0)})));
 graphics.buildBlendTables(game.gameState.palette);
 return Object.freeze({sourceStart:inspection.sourceStart,selection,visualProfile,fallbackSides,relativeToNativeVisualExactness:visualProfile==='raw-source/1'?null:false,validations,
  install(){need(!used,'INSTALL_ONCE');used=true;try{const result=installPublicBattle(port,host,owned,expected,caps,exactHash);for(const [obj,fields]of raster)Object.assign(obj,fields);return result;}catch(error){port.__failBattleInstall();throw error;}},
  resourceIdentity:v=>resource.identify(v),
 });
}
