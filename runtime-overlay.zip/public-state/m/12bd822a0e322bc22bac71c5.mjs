import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { s8 } from "./7596266716c972d06fe8897a.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
function chance2(c) {
    const r = rnd(c, 0, 100);
    return c.aiLevel + c.aiLevel > r;
}
function dashCommand(c) {
    return c.facing === 1 ? 1 : 0;
}
function backdashCommand(c) {
    return c.facing !== 1 ? 1 : 0;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = s8(rnd(c, 0, 2) - 1);
}
export function thinkMizuka(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25.0 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 170 ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 149 && c.state < 157 ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40.0 * c.aiLevel > r && c.state > 199) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 200) c.aiMode = 0;
        return;
    }
    if (o.state === 96) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 50 && c.state <= 150 && c.timer === 0) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 50 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 240) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 320) < dx ? 1 : 0;
        if (o.state > 199 && o.state < 250 && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 10 && c.state <= 12) && c.y === 0.0) return;
    if (o.state >= 50 && o.state < 150 && c.state === 264 && c.w16c > 1) return;
    if (c.state === 168 && c.timer < 6) {
        if (o.state !== 200 && o.state !== 204 && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx < 40.0 && chance(c, 3.0)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && chance2(c)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
        }
        if ((o.state === 201 || o.state === 202 || o.state === 205) && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx > 20.0 && dx < 60.0 && chance2(c)) {
                c.pressed[1] = 1;
                c.inputY = 1;
                c.inputX = 0;
                return;
            }
            if (dx > 60.0 && dx < 80.0 && chance2(c)) {
                c.pressed[0] = 3;
                c.inputY = 1;
                return;
            }
        }
    }
    if (c.state === 168 || c.state === 169) {
        if (dx < 100.0) {
            if (chance(c, 3.0)) {
                c.command = 20;
                return;
            }
            if (chance(c, 1.0) && c.rfGauge > 500.0) {
                c.command = 22;
                return;
            }
            if (chance(c, 1.0) && c.rfGauge > 500.0) {
                c.command = 12;
                return;
            }
            if (chance2(c) && dx < 80.0 && c.meter >= 3000) {
                c.command = 112;
                return;
            }
            if (chance(c, 1.0) && dx < 150.0 && c.meter === 3000) {
                c.command = 132;
                return;
            }
        }
        if (dx < 320.0) {
            if (chance(c, 3.0) && c.rfGauge > 500.0) {
                c.command = 32;
                return;
            }
            if (chance(c, 1.0) && c.meter === 3000) {
                c.command = 132;
                return;
            }
        }
    }
    if (c.state === 170 && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5.0)) {
            c.aiMode = 3;
            return;
        }
        const rel = c.y - o.y;
        if (rel < 0.0 && rel > -40.0 && dx < 80.0 && chance(c, 5.0)) {
            c.pressed[0] = 1;
            return;
        }
        if (rel > -100.0 && rel < -50.0 && dx < 100.0 && chance(c, 5.0)) {
            c.pressed[1] = 1;
            return;
        }
        if (rel > -100.0 && rel < -50.0 && dx < 120.0 && chance(c, 5.0)) {
            c.pressed[2] = 1;
            c.inputY = 0;
            c.inputX = c.facing;
            return;
        }
        if (chance2(c)) {
            c.command = 12;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y === 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0) {
            c.command = 20;
            return;
        }
        if (c.aiRoll < 4 && c.rfGauge > 500.0) {
            c.command = 12;
            return;
        }
        if (c.aiRoll < 17 && c.aiRoll > 12 && c.meter >= 3000) {
            c.command = 112;
            return;
        }
        if (c.aiRoll < 30 && c.aiRoll > 17 && c.meter >= 3000) {
            c.command = 132;
            return;
        }
        if (c.aiRoll > 50) {
            c.aiMode = 2;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y < 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0) {
            c.command = 22;
            return;
        }
        if (c.aiRoll < 17 && c.aiRoll > 12 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 120;
            return;
        }
        if (c.aiRoll > 85) {
            c.aiMode = 2;
            return;
        }
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 8.0 * c.aiLevel > rnd(c, 0, 100) && o.state > 149 && o.state < 157 && (c.state === 259 || c.state === 260 || c.state === 261 || c.state === 314)) {
        c.command = 52;
        return;
    }
    if (c.f3458 > 0) {
        special3458(c, dx, dy);
        return;
    }
    if (c.aiMode === 0 && c.aiLevel > rnd(c, 0, 100) && (c.state > 149 && c.state < 157 || c.state === 96)) {
        c.aiMode = 13;
    }
    if (c.aiMode > 0 && c.state > 49 && c.state < 158) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 200) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = s8(rnd(c, 0, 2) - 1);
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = dashCommand(c);
            if (c.state === 165) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 7;
        return;
    }
    if (c.aiMode === 7 && c.state === 163) {
        c.pressed[0] = 1;
        if (c.state === 230) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 8 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 9;
        return;
    }
    if (c.aiMode === 9 && c.state === 163) {
        c.pressed[1] = 1;
        if (c.state === 231) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 10 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 11;
        return;
    }
    if (c.aiMode === 11 && c.state === 163) {
        c.pressed[2] = 1;
        if (c.state === 232) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 12 && c.state < 50) {
        c.pressed[0] = 1;
        c.inputY = 1;
        if (c.state === 204) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 13) {
        c.command = 20;
        if (c.state === 259) c.aiMode = 0;
    }
    if (c.d168 > 1 && c.hitstop === 0 && 25.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (comboMizuka(c, dx)) return;
    }
    if (25.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 99) {
                if (groundVsGround(c, dx)) return;
            }
            if (o.y < 0.0) {
                if (groundVsAir(c, dx, dy)) return;
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (airAttack(c, dx, dy)) return;
        }
    }
    if (c.state < 50 && (o.state > 149 && o.state < 156 || o.state > 49 && o.state < 59) && c.y === 0.0 && 3.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.command = dashCommand(c);
        return;
    }
    if (c.state < 50 && o.state < 50 && dx > 60.0 && dx < 140.0 && 2.0 * c.aiLevel > rnd(c, 0, 100) && c.x > 120.0 && c.x < 520.0) {
        c.command = backdashCommand(c);
        return;
    }
    if (rnd(c, 0, 1000) < 1) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 180.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 170.0 && dx > 140.0 && c.y === 0.0 && o.state < 50) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    walk(c, dx);
}
function walk(c, dx) {
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 15) c.aiTimer1a0 = 15;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 15) c.aiTimer1a4 = 15;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 50 && dx < 120.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 200) + 45;
        else c.aiTimer1a0 = rnd(c, 0, 200) + 45;
    }
    if (rnd(c, 0, 100) < 50) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 200) + 45;
        else c.aiTimer1a4 = rnd(c, 0, 200) + 45;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 200) + 45;
    else c.aiTimer1a4 = rnd(c, 0, 200) + 45;
}
function special3458(c, dx, dy) {
    const o = c.opponent;
    c.aiRoll = rnd(c, 0, 1000);
    const roll = c.aiRoll;
    if (o.y === 0.0) {
        if (dx < 110.0 && dy < 60.0 && roll < 50) {
            c.pressed[0] = 1;
            return;
        }
        if (dx > 50.0 && dx < 100.0 && dy < 80.0 && roll > 50 && roll < 120) {
            c.pressed[1] = 1;
            return;
        }
        if (dx < 70.0 && dy > 60.0 && dy < 90.0 && roll > 120 && roll < 170) {
            c.pressed[2] = 1;
            return;
        }
        if (dx - 100.0 > rnd(c, 0, 320) && roll > 170 && roll < 220) {
            c.command = rnd(c, 0, 3) + 10;
            return;
        }
        if (dx > 100.0 && roll > 240 && roll < 330 && dy < 40.0) {
            c.command = rnd(c, 0, 3) + 30;
            return;
        }
    }
    if (o.y < 0.0) {
        if (dx < 110.0 && dy < 100.0 && roll < 50) {
            c.pressed[0] = 1;
            return;
        }
        if (dx > 50.0 && dx < 100.0 && dy < 100.0 && roll > 50 && roll < 120) {
            c.pressed[1] = 1;
            return;
        }
        if (dx < 90.0 && dy > 100.0 && dy < 180.0 && roll > 120 && roll < 170) {
            c.pressed[2] = 1;
            return;
        }
        if (dx - 100.0 > rnd(c, 0, 320) && roll > 170 && roll < 220) {
            c.command = rnd(c, 0, 3) + 10;
            return;
        }
        if (dx > 100.0 && roll > 240 && roll < 330 && dy < 60.0) {
            c.command = rnd(c, 0, 3) + 30;
            return;
        }
    }
    if (c.state < 50 && (o.state > 149 && o.state < 156 || o.state > 49 && o.state < 59) && c.y === 0.0 && 3.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.command = dashCommand(c);
        return;
    }
    if (c.state < 50 && o.state < 50 && dx > 60.0 && dx < 140.0 && 2.0 * c.aiLevel > rnd(c, 0, 100) && c.x > 120.0 && c.x < 520.0) {
        c.command = backdashCommand(c);
        return;
    }
    if (rnd(c, 0, 1000) < 1) {
        c.aiMode = 4;
        return;
    }
    c.inputY = 1;
    if (rnd(c, 0, 100) < 50) c.inputY = -1;
    if (dy > 200.0) c.inputY = 1;
    walk(c, dx);
}
function comboMizuka(c, dx) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (c.state === 200) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 50.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 0;
            if (c.d168 === 2 && rnd(c, 0, 100) < 30) {
                c.pressed[2] = 1;
                c.inputY = 1;
            }
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 970) {
            startJump(c);
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 2) === 0) c.aiMode = 6;
            if (rnd(c, 0, 2) === 0) c.aiMode = 8;
            return true;
        }
    }
    if (c.state === 201) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (o.y < 0.0 && roll > 299 && roll < 320 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 120;
            return true;
        }
        if (o.y < 0.0 && roll > 320 && roll < 600 && c.d168 === 3) {
            c.inputX = c.facing;
            c.inputY = -1;
            return true;
        }
        if (roll < 200) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 200 && roll < 450 && dx < 90.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 450 && roll < 700) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 900) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 80.0) c.aiMode = 8;
                return true;
            }
        }
    }
    if (c.state === 202) {
        if (o.y < 0.0 && roll > 299 && roll < 320) {
            c.command = 10;
            return true;
        }
        if (o.y < 0.0 && roll > 320 && roll < 600 && dx < 100.0) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll < 500 && c.d168 === 3 && dx < 80.0) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
                return true;
            }
        }
    }
    if (c.state === 203) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = 20;
            return true;
        }
        if (o.y < 0.0 && roll > 299 && roll < 305 && c.meter >= 3000 && dx < 90.0 && c.d168 === 3) {
            c.command = 132;
            return true;
        }
        if (roll > 200 && roll < 350) {
            c.command = 30;
            return true;
        }
        if (roll > 350 && roll < 500) {
            c.command = rnd(c, 0, 3) + 10;
            return true;
        }
        if (roll > 500 && roll < 600) {
            c.command = rnd(c, 0, 3) + 70;
            return true;
        }
        if (roll > 670 && roll < 700) {
            c.pressed[3] = 1;
            return true;
        }
    }
    if (c.state === 204) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 50.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 0;
            if (c.d168 === 2 && rnd(c, 0, 100) < 20) {
                c.pressed[2] = 1;
                c.inputY = 1;
            }
            return true;
        }
        if (dx < 135.0 && roll < 600) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
            }
            return true;
        }
    }
    if (c.state === 205) {
        if (o.y < 0.0 && roll > 320 && roll < 600 && dx < 100.0) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll < 100) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 100 && roll < 300 && dx < 100.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 300 && roll < 600) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 900) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
            }
            return true;
        }
    }
    if (c.state === 206) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = 20;
            return true;
        }
        if (o.y < 0.0 && roll > 299 && roll < 305 && c.meter >= 3000 && dx < 90.0 && c.d168 === 3) {
            c.command = 132;
            return true;
        }
        if (o.y < 0.0 && roll > 305 && roll < 350 && c.meter >= 1000 && c.d168 === 3) {
            c.command = rnd(c, 0, 3) + 100;
            return true;
        }
        if (roll > 200 && roll < 350) {
            c.command = 30;
            return true;
        }
        if (roll > 350 && roll < 500) {
            c.command = rnd(c, 0, 3) + 10;
            return true;
        }
        if (roll > 500 && roll < 600) {
            c.command = rnd(c, 0, 3) + 70;
            return true;
        }
        if (roll > 670 && roll < 700) {
            c.pressed[3] = 1;
            return true;
        }
    }
    if (c.state === 207) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            return true;
        }
        if (dx < 60.0 && roll < 400) {
            c.pressed[0] = 1;
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 4) === 0) c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 208) {
        if (roll > 20 && roll < 60 && c.d168 === 3 && o.y < 0.0) {
            c.command = 10;
            return true;
        }
        if (roll > 80 && roll < 300) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 950) {
            c.inputX = s8(rnd(c, 0, 2) - 1);
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 209) {
        if (roll > 950) {
            c.inputX = s8(rnd(c, 0, 2) - 1);
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 231) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (roll > 200 && roll < 220 && dx < 90.0 && c.d168 === 3 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 120;
            return true;
        }
        if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
        if (roll > 649 && rnd(c, 0, 2) === 0) {
            c.aiMode = 12;
            if (dx > 110.0) c.aiMode = 8;
        }
    }
    if (c.state === 232) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = 10;
            return true;
        }
        if (o.y < 0.0 && roll > 299 && roll < 320 && c.meter >= 1000 && dx < 90.0) {
            c.command = rnd(c, 0, 3) + 120;
            return true;
        }
        if (roll > 0 && roll < 200 && c.d168 === 3) {
            c.command = 10;
            return true;
        }
        if (roll > 200 && roll < 250) {
            c.command = rnd(c, 0, 3) + 30;
            return true;
        }
        if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
        if (roll > 400 && roll < 430 && c.d168 === 3 && c.meter === 3000) {
            c.command = 95;
            return true;
        }
        if (roll > 430 && roll < 540 && c.d168 !== 3) {
            c.command = 40;
            if (dx > 120.0) c.command = 41;
            return true;
        }
        if (roll > 910 && c.d168 === 3) {
            startJump(c);
            return true;
        }
        if (roll > 649) {
            c.aiMode = 1;
            return true;
        }
    }
    return false;
}
function groundVsGround(c, dx) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (dx < 40.0 && o.y === 0.0 && roll < 5) {
        c.pressed[2] = 1;
        c.inputX = s8(-c.facing);
        c.inputY = 0;
        return true;
    }
    if (dx < 50.0 && roll < 20) {
        c.pressed[0] = 1;
        c.inputY = 1;
        return true;
    }
    if (dx < 75.0 && roll < 25) {
        c.pressed[0] = 1;
        c.inputY = 0;
        return true;
    }
    if (dx < 120.0 && roll < 60 && roll > 30) {
        c.pressed[1] = 1;
        c.inputY = 1;
        return true;
    }
    if (dx < 80.0 && roll < 52 && roll > 40 || dx > 90.0 && dx < 150.0 && roll < 80 && roll > 52) {
        c.pressed[1] = 1;
        c.inputY = 0;
        return true;
    }
    if (dx > 80.0 && dx < 120.0 && roll < 85 && roll > 80) {
        c.aiMode = 8;
        return true;
    }
    if (dx > 70.0 && dx < 120.0 && roll < 120 && roll > 90) {
        c.aiMode = 8;
        return true;
    }
    if (dx < 160.0 && dx > 70.0 && roll < 130 && roll > 120) {
        c.pressed[2] = 1;
        c.inputY = 1;
        return true;
    }
    if (dx < 100.0 && dx > 70.0 && roll < 145 && roll > 130) {
        c.pressed[2] = 1;
        c.inputY = 0;
        return true;
    }
    if (dx > 100.0 && dx < 140.0 && roll < 152 && roll > 145) {
        c.aiMode = 10;
        return true;
    }
    if (dx < 70.0 && roll < 185 && roll > 145 && c.rfGauge > 500.0 && o.state > 199) {
        c.command = 20;
        return true;
    }
    if (dx < 100.0 && dx > 40.0 && roll < 190 && roll > 185 && c.meter >= 3000 && o.state > 199) {
        c.command = 132;
        return true;
    }
    if (dx > 120.0 && roll < 200 && roll > 190 && c.meter >= 3000 && o.state > 199) {
        c.command = 112;
        return true;
    }
    if (dx > 200.0 && roll < 190 && roll > 170) {
        c.command = rnd(c, 0, 3) + 10;
        return true;
    }
    if (dx > 180.0 && roll < 200 && roll > 190) {
        c.command = 70;
        return true;
    }
    if (dx > 180.0 && roll < 210 && roll > 200) {
        c.command = 71;
        return true;
    }
    if (dx > 80.0 && dx < 120.0 && roll < 220 && roll > 210) {
        c.command = 30;
        return true;
    }
    if (dx > 140.0 && dx < 180.0 && roll < 240 && roll > 230) {
        c.command = 31;
        return true;
    }
    if ((c.rfGauge > 500.0 || c.rfBlue === 1) && roll < 245 && roll > 240) {
        c.command = 32;
        return true;
    }
    if (dx > 140.0 && roll < 260 && roll > 250 && c.meter >= 1000) {
        c.command = rnd(c, 0, 3) + 120;
        return true;
    }
    return false;
}
function groundVsAir(c, dx, dy) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (o.vy < 0.0) {
        if (dx < 80.0 && dy < 120.0 && roll < 10) {
            c.inputY = -1;
            c.inputX = s8(-c.facing);
            return true;
        }
        if (dx < 150.0 && dx > 50.0 && roll < 40 && c.meter >= 3000) {
            c.command = 132;
            return true;
        }
    }
    if (!(o.vy > 0.0)) return false;
    if (dx < 90.0 && dy < 140.0 && roll < 6 && (c.rfGauge > 500.0 || c.rfBlue > 0)) {
        c.command = 22;
        return true;
    }
    if (dx < 90.0 && dy < 140.0 && roll < 30) {
        c.command = 22;
        return true;
    }
    if (dx < 80.0 && dx > 30.0 && dy < 140.0 && dy > 100.0 && roll < 65 && roll > 30) {
        c.pressed[1] = 1;
        c.inputY = 0;
        return true;
    }
    if (dx > 100.0 && dx < 140.0 && dy < 140.0 && dy > 100.0 && roll < 80 && roll > 60) {
        c.pressed[1] = 1;
        c.inputY = 0;
        return true;
    }
    if (dx < 160.0 && dx > 30.0 && roll < 110 && roll > 80 && o.y < -50.0 && c.meter >= 3000) {
        c.command = 132;
        return true;
    }
    return false;
}
function airAttack(c, dx, dy) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (o.y === 0.0) {
        if (dx < 110.0 && dy < 100.0 && roll < 50) {
            c.pressed[0] = 1;
            return true;
        }
        if (dx > 50.0 && dx < 100.0 && dy < 100.0 && roll > 50 && roll < 120) {
            c.pressed[1] = 1;
            return true;
        }
        if (dx < 90.0 && dy > 100.0 && dy < 180.0 && roll > 120 && roll < 170) {
            c.pressed[2] = 1;
            return true;
        }
        if (dx - 100.0 > rnd(c, 0, 320) && dy < 90.0 && roll > 170 && roll < 220) {
            c.command = rnd(c, 0, 3) + 10;
            return true;
        }
        if (dx > 100.0 && roll > 240 && roll < 330 && dy + 40.0 > dx && dy - 40.0 < dx) {
            c.command = rnd(c, 0, 3) + 30;
            return true;
        }
    }
    if (o.y < 0.0) {
        if (dx < 110.0 && dy < 100.0 && roll < 50) {
            c.pressed[0] = 1;
            return true;
        }
        if (dx > 50.0 && dx < 100.0 && dy < 100.0 && roll > 50 && roll < 120) {
            c.pressed[1] = 1;
            return true;
        }
        if (dx < 90.0 && dy > 100.0 && dy < 180.0 && roll > 120 && roll < 170) {
            c.pressed[2] = 1;
            return true;
        }
        if (dx - 100.0 > rnd(c, 0, 320) && dy < 90.0 && roll > 170 && roll < 220) {
            c.command = rnd(c, 0, 3) + 10;
            return true;
        }
        if (dx > 100.0 && roll > 240 && roll < 330 && dy + 40.0 > dx && dy - 40.0 < dx) {
            c.command = rnd(c, 0, 3) + 30;
            return true;
        }
    }
    return false;
}
