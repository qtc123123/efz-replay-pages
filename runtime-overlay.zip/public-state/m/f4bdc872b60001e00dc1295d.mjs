import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerStates, setDefaultStateHandler } from "./1f5919024557a92ec3a28767.mjs";
import { frameChild, frameEffect, openSpawnFrame } from "./6bb9439be7e0aefdefc21b73.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const WALK_FWD = 0.9;
const WALK_BACK = -0.9;
const WALK_EX = 0.15;
const JUMP_AY = 0.045;
const JUMP_AY_EX = 0.015;
const JUMP_VY = -2.7;
const JUMP_VY_EX = 0.6;
const JUMP_FWD = 0.8;
const JUMP_BACK = -0.8;
const JUMP_X_EX = 0.1;
const DASH_JUMP_NEUTRAL = 0.4;
const DASH_JUMP_FWD = 1.2;
function advance(c, dur, cnt) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return c.frame >= cnt;
}
function advanceEx(c, dur, cnt) {
    c.timer++;
    if (c.timer < dur - (c.exOn() << 1)) return false;
    c.timer = 0;
    c.frame++;
    return c.frame >= cnt;
}
function landFromHit(c) {
    c.y = 0.0;
    if (c.d12c !== 0) c.setState(0x61);
    else c.setState(0x62);
}
function wallPush(c, y, k) {
    if (c.x - 20.0 <= 0.0 || !(c.x + 20.0 < 639.0)) {
        c.pushToOpponent = (1.0 - (y < 0.0 ? 1 : 0) * k) * c.vx;
    } else {
        c.pushToOpponent = 0.0;
    }
}
function rfDrain(c, v) {
    if (c.rfBlue !== 0) c.rfGauge -= v;
}
function stateDefault(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (advanceEx(c, dur, cnt)) c.frame = 0;
}
function state1(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.vx = c.exOn() * WALK_EX + WALK_FWD;
    c.vy = 0.0;
    if (advanceEx(c, dur, cnt)) c.frame = 0;
}
function state2(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.vx = WALK_BACK - c.exOn() * WALK_EX;
    c.vy = 0.0;
    if (advanceEx(c, dur, cnt)) c.frame = 0;
}
function state3(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advanceEx(c, dur, cnt)) c.frame = 0;
}
function jumpLanding(c) {
    if (c.y + c.vy >= 0.0 && c.frame > 3) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function jumpLaunch(c) {
    c.ay = c.exOn() * JUMP_AY_EX + JUMP_AY;
    c.vy = JUMP_VY - c.exOn() * JUMP_VY_EX;
}
function jump(c, vx, dashVx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        if (c.b158 === 0) c.faceOpponent();
        c.vx = 0.0;
    }
    if (c.frame === 2 && c.timer === 0) {
        jumpLaunch(c);
        if (vx !== null) c.vx = vx(c);
        if (dashVx !== null && c.b158 === 1) {
            c.vx = dashVx;
            c.b158 = 0;
        }
    }
    if (c.frame > 2) c.vy += c.ay;
    if (advanceEx(c, dur, cnt)) c.setState(9);
    jumpLanding(c);
}
function jumpFwdVx(c) {
    return c.exOn() * JUMP_X_EX + JUMP_FWD;
}
function jumpBackVx(c) {
    return JUMP_BACK - c.exOn() * JUMP_X_EX;
}
function quickJump(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = c.exOn() * JUMP_AY_EX + JUMP_AY;
    if (c.frame === 0 && c.timer === 0) {
        c.vy = JUMP_VY - c.exOn() * JUMP_VY_EX;
        c.vx = vx(c);
        c.b158 = 0;
    }
    c.vy += c.ay;
    if (advanceEx(c, dur, cnt)) c.setState(9);
    jumpLanding(c);
}
function transition(c, next) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(next);
}
function state9(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    c.b158 = 0;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.setState(13);
    }
}
function state13(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(c.inputY === 1 ? 3 : 0);
}
function state47(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.6;
        c.ay = 0.035;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 2) {
        c.timer = 0;
        c.frame = 2;
        c.seRequest = 7;
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2) c.frame = c.frame - 2 & 0xffff;
        if (c.frame >= cnt) c.frame = c.frame - 1 & 0xffff;
    }
}
function hitStand(c, meter, k, guard, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + meter);
        c.vx = (2.0 - c.opponent.proration / 10000.0) * k;
        rfDrain(c, guard);
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    wallPush(c, c.y, 0.2);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 0);
        else c.setState(3);
    }
}
function hitAir(c, wall, mix, clamp, ay) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (wall && c.frame > 0 && c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = mix ? c.vy * 0.75 + c.knockY : c.knockY;
        if (clamp !== null) {
            if (c.vy < clamp) c.vy = clamp;
            else if (c.vy > -0.5) c.vy = -0.5;
        }
        c.ay = ay;
    }
    if (!(c.vy > 0.0)) {
        c.frame = 1;
        c.timer = 0;
    }
    if (c.vy >= 0.0 && c.frame <= 1) {
        c.frame = 2;
        c.timer = 0;
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = c.frame - 2 & 0xffff;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function state68(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    c.timer++;
    if (c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state69(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    if (advance(c, dur, cnt)) c.frame = c.frame - 2 & 0xffff;
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state70(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0 && c.f3138 === 0) {
        c.meter = s16(c.meter + 30);
        c.f3138++;
        c.hitstun = s16(c.hitstun + 120);
        c.vx = 0.5;
        c.vy = -2.5;
        c.ay = 0.025;
        c.seRequest = 0x1f;
        const f = openSpawnFrame();
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function grounded(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    c.b158 = 0;
    c.vx = 0.0;
    c.vy = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function slide(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + 30);
        rfDrain(c, 30.0);
        c.vx = 2.2;
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.ay = 0.0;
    c.ax = 0.06;
    c.vx -= c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function state81(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0) {
        const f = openSpawnFrame();
        f.w04 = 0x1f3;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    c.vx += 0.02;
    c.vy += c.ay;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) c.frame = c.frame - 1 & 0xffff;
    if (c.y + c.vy >= 0.0 && c.frame === 1) landFromHit(c);
}
function state82(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0 && c.f3138 === 0) {
        c.seRequest = 0x1e;
        c.vy = -0.45;
        c.vx = -0.1;
        c.f3138++;
        c.meter = s16(c.meter + 30);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    if (c.vy > 0.0 && c.frame === 4) {
        c.frame = 5;
        c.timer = 0;
    }
    if (c.frame > 3) c.vy += c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 4 && c.f3138 < 8) {
            c.frame = 0;
            c.f3138++;
        }
        if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
    }
    if (c.y + c.vy >= 0.0 && c.frame > 4) landFromHit(c);
}
function spawn496(c) {
    if (c.f3144 === 0) {
        const f = openSpawnFrame();
        f.w04 = 0x1f0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 0;
        f.b21 = 0;
        f.d00 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        c.f3144 = 1;
    }
}
function state83(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vy = -1.5;
        c.vx = -0.8;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (c.frame === 0 && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.timer = 0;
        c.frame = 1;
        return;
    }
    if (c.frame === 1) c.vx += 0.01;
    if (c.frame === 2 && c.timer === 0) c.vx = -2.0;
    if (c.frame > 1) c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
}
function state85(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state86(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        spawn496(c);
        if (c.f3138 === 0) {
            rfDrain(c, 30.0);
            c.seRequest = 0x21;
            c.vx = c.knockX;
            c.vy = c.knockY;
            c.meter = s16(c.meter + 30);
            c.f3138++;
        }
    }
    c.vy += 0.06;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state87(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        const f = openSpawnFrame();
        f.w04 = 0x1ef;
        f.x = 60.0;
        f.y = 40.0;
        f.d24 = 1;
        f.b18 = 1;
        f.b20 = 0;
        f.b21 = 0;
        frameChild(c, f);
    }
    if (advance(c, dur, cnt)) c.setState(0);
}
setDefaultStateHandler(stateDefault);
registerStates({
    1: state1,
    2: state2,
    3: state3,
    4: (c)=>jump(c, null, DASH_JUMP_NEUTRAL),
    5: (c)=>jump(c, jumpFwdVx, DASH_JUMP_FWD),
    6: (c)=>jump(c, jumpBackVx, null),
    7: (c)=>transition(c, 0),
    8: (c)=>transition(c, 3),
    9: state9,
    13: state13,
    14: (c)=>quickJump(c, ()=>0.0),
    15: (c)=>quickJump(c, jumpFwdVx),
    16: (c)=>quickJump(c, jumpBackVx),
    47: state47,
    50: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    51: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    52: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    53: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    54: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    55: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    56: (c)=>hitStand(c, 10, -1.1, 10.0, false),
    57: (c)=>hitStand(c, 15, -1.5, 20.0, false),
    58: (c)=>hitStand(c, 20, -1.8, 30.0, false),
    59: (c)=>hitAir(c, false, true, -2.0, 0.032),
    60: (c)=>hitAir(c, false, true, -4.0, 0.032),
    61: (c)=>hitAir(c, false, true, -6.0, 0.032),
    62: (c)=>hitAir(c, false, true, null, 0.032),
    63: (c)=>hitAir(c, false, false, null, 0.032),
    64: (c)=>hitAir(c, true, true, -2.0, 0.032),
    65: (c)=>hitAir(c, true, true, -4.0, 0.032),
    66: (c)=>hitAir(c, true, true, null, 0.032),
    67: (c)=>hitAir(c, true, false, null, 0.032),
    68: state68,
    69: state69,
    70: state70,
    71: (c)=>hitAir(c, false, false, null, 0.072),
    72: (c)=>grounded(c, true),
    73: (c)=>grounded(c, true),
    74: (c)=>grounded(c, false),
    75: (c)=>slide(c, true),
    76: (c)=>slide(c, true),
    77: (c)=>slide(c, false),
    81: state81,
    82: state82,
    83: state83,
    84: state83,
    85: state85,
    86: state86,
    87: state87
});

export function __logicState(){return {WALK_BACK,JUMP_VY,JUMP_BACK};}

export function __installInitialRoots(s){
if(WALK_BACK!==s["WALK_BACK"])throw Error('INITIAL_CONST_IDENTITY:WALK_BACK');
if(JUMP_VY!==s["JUMP_VY"])throw Error('INITIAL_CONST_IDENTITY:JUMP_VY');
if(JUMP_BACK!==s["JUMP_BACK"])throw Error('INITIAL_CONST_IDENTITY:JUMP_BACK');
}
