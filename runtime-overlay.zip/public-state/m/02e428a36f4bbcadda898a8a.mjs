import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./4ab9307bcb6cd4f39f8feacd.mjs";
import { updateChildrenMakoto } from "./98eccc84a6920bb332239618.mjs";
import { parseCommandMakoto, dispatchMovesMakoto } from "./13c8829ca12c03194623fc4a.mjs";
import { thinkMakoto } from "./074f16ab4b7e2c95b8dd7581.mjs";
import "./df45196782ed795b266caf1b.mjs";
import "./bc3f01f1ba0d43c026ca696c.mjs";
import "./a29f89742d0c8eeb39af6d1b.mjs";
import "./90dfacdb3570b5420f8868b0.mjs";
const POINTS_X = [
    -7,
    6,
    17,
    19,
    22
];
const POINTS_Y = [
    -51,
    0,
    -15,
    -11,
    -30
];
export class Makoto extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    a314c = new Int32Array(64);
    a324c = new Int32Array(64);
    a334c = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        1,
        5,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    wF2 = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = this.f313c = this.f3140 = this.f3144 = this.f3148 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a314c.fill(0);
        this.a324c.fill(0);
        this.a334c.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a314c[i] = 0;
        this.a324c[i] = 0;
        this.a334c[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {}
    parseCommand() {
        parseCommandMakoto(this);
    }
    dispatchMoves() {
        dispatchMovesMakoto(this);
    }
    think() {
        thinkMakoto(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMakoto(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
