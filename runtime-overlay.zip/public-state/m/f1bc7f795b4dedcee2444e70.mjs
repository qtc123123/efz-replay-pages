import {encodeUTF8,decodeUTF8,utf8ByteLength} from "./14b4a6885fe2874a9aa921e1.mjs";
// Runtime-neutral binary candidate. No I/O, hashing, source text, host pointers,
// or dynamic constructors. Format definition is SPEC-CODEC.md.
export const FORMAT='efz-typed-initial-graph/2';
export const DEFAULT_LIMITS=Object.freeze({maxBytes:1048576,maxNodes:16384,maxEdges:131072,maxArrayLength:65536,maxStringBytes:4096,maxBufferBytes:262144,maxTotalBufferBytes:524288,maxDepth:128,maxResidentBytes:12582912});
const TYPES=Object.freeze({Int8Array,Uint8Array,Uint8ClampedArray,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array,DataView});
function strictEncode(s){for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);if(c>=0xd800&&c<=0xdbff){const next=s.charCodeAt(++i);if(!(next>=0xdc00&&next<=0xdfff))throw Error('INITIAL_GRAPH_STRING_SCALAR');}else if(c>=0xdc00&&c<=0xdfff)throw Error('INITIAL_GRAPH_STRING_SCALAR');}return encodeUTF8(s,4096);}
const encoder={encode:strictEncode},decoder={decode:b=>decodeUTF8(b,4096)},validated=new WeakMap();
const MAGIC=[69,70,90,73,83,2,0,0];
const fail=c=>{throw Error('INITIAL_GRAPH_'+c);};
const need=(v,c)=>{if(!v)fail(c);};
const integer=(v,hi)=>Number.isSafeInteger(v)&&v>=0&&v<=hi;
const own=(v,k)=>Object.prototype.hasOwnProperty.call(v,k);
const keys=v=>Object.keys(v).sort();
const safeKey=k=>typeof k==='string'&&!['__proto__','constructor','prototype'].includes(k);
function exact(v,want){need(v&&typeof v==='object'&&!Array.isArray(v)&&JSON.stringify(keys(v))===JSON.stringify([...want].sort()),'KEYS');}
function limits(value){const l={...DEFAULT_LIMITS,...value};for(const k of keys(DEFAULT_LIMITS))need(integer(l[k],DEFAULT_LIMITS[k])&&l[k]>0,'LIMIT');return l;}
function numberValue(s){if(s==='nan')return NaN;need(typeof s==='string'&&/^[0-9a-f]{16}$/.test(s),'F64');const b=new Uint8Array(8);for(let i=0;i<8;i++)b[i]=parseInt(s.slice(i*2,i*2+2),16);return new DataView(b.buffer).getFloat64(0,false);}
function numberToken(v){if(Number.isNaN(v))return 'nan';const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,v,false);let s='';for(let i=0;i<8;i++)s+=b.getUint8(i).toString(16).padStart(2,'0');return s;}
function buildDocument(root,caps,l){
 const seen=new Map(),nodes=[];let edges=0,wireBudget=16,residentBudget=256;const charge=(wire,resident)=>{wireBudget+=wire;residentBudget+=resident;need(wireBudget<=l.maxBytes,'BYTE_BOUND');need(residentBudget<=l.maxResidentBytes,'RESIDENT_BOUND');};
 function token(v,depth){need(depth<=l.maxDepth,'DEPTH_BOUND');need(++edges<=l.maxEdges,'EDGE_BOUND');charge(1,48);
  if(v===null)return ['null'];if(v===undefined)return ['undefined'];
  if(typeof v==='boolean')return ['boolean',v];if(typeof v==='number'){charge(8,32);return ['number',numberToken(v)];}
  if(typeof v==='string'){const len=encoder.encode(v).length;need(len<=l.maxStringBytes,'STRING_BOUND');charge(4+len,2*len);return ['string',v];}
  if(typeof v==='bigint')return ['bigint',v.toString()];
  need(typeof v!=='symbol','SYMBOL');const cap=caps.identify(v);if(cap!==null){charge(4+encoder.encode(cap).length,cap.length*2);return ['cap',cap];}
  need(typeof v!=='function','FUNCTION');need(typeof v==='object','TYPE');if(seen.has(v)){charge(4,0);return ['ref',seen.get(v)];}
  need(nodes.length<l.maxNodes,'NODE_BOUND');charge(9,192);const id=nodes.length;seen.set(v,id);const n={};nodes.push(n);
  if(v instanceof ArrayBuffer){n.kind='buffer';need(v.byteLength<=l.maxBufferBytes,'BUFFER_BOUND');charge(v.byteLength,v.byteLength*8);n.bytes=Array.from(new Uint8Array(v));}
  else if(ArrayBuffer.isView(v)){need(own(TYPES,v.constructor.name),'VIEW_TYPE');n.kind='view';charge(12+v.constructor.name.length,64);n.type=v.constructor.name;n.buffer=token(v.buffer,depth+1);n.offset=v.byteOffset;n.length=v instanceof DataView?v.byteLength:v.length;}
  else if(v instanceof Map){n.kind='map';n.entries=Array.from(v,([k,x])=>[token(k,depth+1),token(x,depth+1)]);}
  else if(v instanceof Set){n.kind='set';n.entries=Array.from(v,x=>token(x,depth+1));}
  else {
   const p=Object.getPrototypeOf(v),type=caps.type(v);
   if(Array.isArray(v)){n.kind='array';n.length=v.length;need(v.length<=l.maxArrayLength,'ARRAY_BOUND');charge(4,v.length*8);}
   else if(type!==null){n.kind='class';charge(4+encoder.encode(type).length,64+type.length*2);n.type=type;}
   else {need(p===Object.prototype||p===null,'PROTOTYPE');n.kind=p===null?'nullObject':'object';}
   n.props=[];for(const k of Reflect.ownKeys(v).filter(k=>!(Array.isArray(v)&&k==='length')).sort()){
    need(safeKey(k),'PROPERTY');charge(4+encoder.encode(k).length,64+k.length*2);const d=Object.getOwnPropertyDescriptor(v,k);need('value'in d,'ACCESSOR');
    need(d.enumerable&&d.writable&&d.configurable,'DESCRIPTOR');n.props.push([k,token(d.value,depth+1)]);
   }
  }
  return ['ref',id];
 }
 return {format:FORMAT,root:token(root,0),nodes};
}
export function validateDocument(doc,caps,options){const l=limits(options);exact(doc,['format','root','nodes']);need(doc.format===FORMAT,'FORMAT');need(Array.isArray(doc.nodes)&&doc.nodes.length<=l.maxNodes,'NODE_BOUND');let edges=0,totalBuffers=0;
 const str=s=>need(typeof s==='string'&&encoder.encode(s).length<=l.maxStringBytes,'STRING_BOUND');
 function tok(t){need(++edges<=l.maxEdges,'EDGE_BOUND');need(Array.isArray(t)&&typeof t[0]==='string','TOKEN');const kind=t[0];
  need(t.length===(['null','undefined'].includes(kind)?1:2),'TOKEN_LENGTH');
  switch(kind){case 'null':case 'undefined':break;case 'boolean':need(typeof t[1]==='boolean','BOOLEAN');break;case 'number':numberValue(t[1]);break;case 'string':str(t[1]);break;case 'bigint':str(t[1]);need(/^(0|-?[1-9][0-9]*)$/.test(t[1]),'BIGINT');break;case 'ref':need(integer(t[1],doc.nodes.length-1),'REF');break;case 'cap':str(t[1]);need(caps.has(t[1]),'CAPABILITY');break;default:fail('TOKEN_KIND');}
 }
 tok(doc.root);
 for(const n of doc.nodes){need(n&&typeof n==='object','NODE');switch(n.kind){
  case 'buffer':exact(n,['kind','bytes']);need(Array.isArray(n.bytes)&&n.bytes.length<=l.maxBufferBytes,'BUFFER_BOUND');totalBuffers+=n.bytes.length;need(totalBuffers<=l.maxTotalBufferBytes,'TOTAL_BUFFER_BOUND');for(const v of n.bytes)need(integer(v,255),'BYTE');break;
  case 'view':{exact(n,['kind','type','buffer','offset','length']);need(own(TYPES,n.type),'VIEW_TYPE');tok(n.buffer);need(n.buffer[0]==='ref','VIEW_BUFFER');const b=doc.nodes[n.buffer[1]];need(b?.kind==='buffer'&&Array.isArray(b.bytes),'VIEW_BUFFER');const width=TYPES[n.type].BYTES_PER_ELEMENT??1;need(integer(n.offset,l.maxBufferBytes)&&integer(n.length,l.maxArrayLength)&&n.offset%width===0&&n.offset+n.length*width<=b.bytes.length,'VIEW_RANGE');break;}
  case 'map':exact(n,['kind','entries']);need(Array.isArray(n.entries)&&n.entries.length<=l.maxArrayLength,'MAP_BOUND');for(const e of n.entries){need(Array.isArray(e)&&e.length===2,'MAP_ENTRY');tok(e[0]);tok(e[1]);}break;
  case 'set':exact(n,['kind','entries']);need(Array.isArray(n.entries)&&n.entries.length<=l.maxArrayLength,'SET_BOUND');n.entries.forEach(tok);break;
  case 'class':case 'object':case 'nullObject':case 'array':{
   exact(n,['kind','props',...(n.kind==='class'?['type']:n.kind==='array'?['length']:[])]);
   if(n.kind==='array')need(integer(n.length,l.maxArrayLength),'ARRAY_BOUND');need(Array.isArray(n.props)&&n.props.length<=l.maxEdges,'FIELD_BOUND');let previous=null;
   for(const e of n.props){need(Array.isArray(e)&&e.length===2,'PROPERTY');str(e[0]);need(safeKey(e[0])&&(previous===null||previous<e[0]),'PROPERTY_ORDER');previous=e[0];if(n.kind==='array')need(/^(0|[1-9][0-9]*)$/.test(e[0])&&Number(e[0])<n.length,'ARRAY_KEY');tok(e[1]);}
   if(n.kind==='class'){str(n.type);need(caps.checkType(n.type,n.props.map(p=>p[0])),'CLASS_SCHEMA');}break;
  }
  default:fail('NODE_KIND');
 }}
 // Explicit iterative depth/reachability check bounds hostile chains and rejects
 // extra unreachable allocations. Backedges are legal, including opponent cycles.
 const seen=new Set(),stack=[[doc.root,0]];
 while(stack.length){const [t,d]=stack.pop();if(t[0]!=='ref'||seen.has(t[1]))continue;need(d<=l.maxDepth,'DEPTH_BOUND');seen.add(t[1]);const n=doc.nodes[t[1]],children=n.props?.map(e=>e[1])??(n.kind==='map'?n.entries.flat():n.kind==='set'?n.entries:n.kind==='view'?[n.buffer]:[]);for(const x of children)stack.push([x,d+1]);}
 need(seen.size===doc.nodes.length,'UNREACHABLE');let resident=256+edges*80;for(const n of doc.nodes){resident+=192;if(n.kind==='array')resident+=n.length*8;if(n.kind==='buffer')resident+=n.bytes.length*9;if(n.props)for(const [k,t]of n.props)resident+=80+k.length*2+(t[0]==='string'||t[0]==='cap'?t[1].length*2:0);if(n.kind==='map')resident+=n.entries.length*128;if(n.kind==='set')resident+=n.entries.length*48;}need(resident<=l.maxResidentBytes,'RESIDENT_BOUND');const freeze=v=>{if(v&&typeof v==='object'&&!Object.isFrozen(v)){for(const x of Object.values(v))freeze(x);Object.freeze(v);}};freeze(doc);validated.set(doc,{caps,estimatedResidentBytes:resident,methods:[caps.has,caps.resolve,caps.checkType,caps.construct]});return doc;
}
class Writer{constructor(sink,l){this.sink=sink;this.l=l;this.chunk=new Uint8Array(4096);this.used=0;this.size=0;}byte(v){need(this.size<this.l.maxBytes,'BYTE_BOUND');this.chunk[this.used++]=v;this.size++;if(this.used===4096)this.flush();}flush(){if(this.used){this.sink(this.chunk.subarray(0,this.used));this.used=0;}}u32(v){for(let i=0;i<4;i++)this.byte(v>>>(i*8)&255);}str(s){const b=encoder.encode(s);this.u32(b.length);for(const x of b)this.byte(x);}token(t){const tags={null:0,undefined:1,boolean:t[1]?3:2,number:4,string:5,ref:6,cap:7,bigint:8};this.byte(tags[t[0]]);if(t[0]==='number'){const s=t[1]==='nan'?'7ff8000000000000':t[1];for(let i=0;i<8;i++)this.byte(parseInt(s.slice(i*2,i*2+2),16));}else if(t[0]==='ref')this.u32(t[1]);else if(['string','cap','bigint'].includes(t[0]))this.str(t[1]);}}
function writeDocument(doc,sink,l){const w=new Writer(sink,l);for(const b of MAGIC)w.byte(b);w.u32(doc.nodes.length);w.token(doc.root);const kinds=['object','array','buffer','view','map','set','class','nullObject'];for(const n of doc.nodes){w.byte(kinds.indexOf(n.kind));switch(n.kind){
 case 'buffer':w.u32(n.bytes.length);for(const b of n.bytes)w.byte(b);break;
 case 'view':w.str(n.type);w.token(n.buffer);w.u32(n.offset);w.u32(n.length);break;
 case 'map':w.u32(n.entries.length);for(const e of n.entries){w.token(e[0]);w.token(e[1]);}break;
 case 'set':w.u32(n.entries.length);for(const t of n.entries)w.token(t);break;
 default:if(n.kind==='class')w.str(n.type);if(n.kind==='array')w.u32(n.length);w.u32(n.props.length);for(const [k,t]of n.props){w.str(k);w.token(t);}
 }}w.flush();return {byteLength:w.size,nodes:doc.nodes.length};}
export function encodeGraphTo(root,caps,sink,options){need(typeof sink==='function','SINK');const l=limits(options),doc=validateDocument(buildDocument(root,caps,l),caps,l);return writeDocument(doc,sink,l);}
export function encodeGraph(root,caps,options){const chunks=[];const r=encodeGraphTo(root,caps,b=>chunks.push(b.slice()),options);const out=new Uint8Array(r.byteLength);let p=0;for(const b of chunks){out.set(b,p);p+=b.length;}return out;}
export function inspectGraph(bytes,options){const l=limits(options);need(bytes instanceof Uint8Array&&bytes.length<=l.maxBytes,'BYTE_BOUND');let p=0,edges=0;const byte=()=>{need(p<bytes.length,'TRUNCATED');return bytes[p++];},u32=()=>{let v=0;for(let i=0;i<4;i++)v+=byte()*2**(i*8);return v;},str=()=>{const n=u32();need(n<=l.maxStringBytes&&p+n<=bytes.length,'STRING_BOUND');const s=decoder.decode(bytes.subarray(p,p+n));p+=n;return s;};
 function token(){need(++edges<=l.maxEdges,'EDGE_BOUND');const t=byte();if(t===0)return ['null'];if(t===1)return ['undefined'];if(t===2||t===3)return ['boolean',t===3];if(t===4){let s='';for(let i=0;i<8;i++)s+=byte().toString(16).padStart(2,'0');return ['number',Number.isNaN(numberValue(s))?'nan':s];}if(t===6)return ['ref',u32()];if([5,7,8].includes(t))return [[5,7,8].indexOf(t)===0?'string':t===7?'cap':'bigint',str()];fail('TOKEN_KIND');}
 for(const b of MAGIC)need(byte()===b,'MAGIC');const count=u32();need(count<=l.maxNodes,'NODE_BOUND');const root=token(),nodes=[];let resident=256+bytes.length*3;const charge=n=>{resident+=n;need(resident<=l.maxResidentBytes,'RESIDENT_BOUND');};const kinds=['object','array','buffer','view','map','set','class','nullObject'];
 for(let i=0;i<count;i++){charge(192);const kind=kinds[byte()];need(kind,'NODE_KIND');const n={kind};nodes.push(n);if(kind==='buffer'){const size=u32();need(size<=l.maxBufferBytes&&p+size<=bytes.length,'BUFFER_BOUND');charge(size*9);n.bytes=Array.from(bytes.subarray(p,p+size));p+=size;}else if(kind==='view'){n.type=str();n.buffer=token();n.offset=u32();n.length=u32();}else if(kind==='map'||kind==='set'){const size=u32();need(size<=l.maxArrayLength,'COLLECTION_BOUND');charge(size*(kind==='map'?208:96));n.entries=[];for(let j=0;j<size;j++)n.entries.push(kind==='map'?[token(),token()]:token());}else{if(kind==='class')n.type=str();if(kind==='array'){n.length=u32();need(n.length<=l.maxArrayLength,'ARRAY_BOUND');charge(n.length*8);}const size=u32();need(size<=l.maxEdges,'FIELD_BOUND');charge(size*160);n.props=[];for(let j=0;j<size;j++){const k=str();charge(k.length*2);n.props.push([k,token()]);}}}
 need(p===bytes.length,'TRAILING_BYTES');return {format:FORMAT,root,nodes};
}
export function validateGraph(bytes,caps,options){return validateDocument(inspectGraph(bytes,options),caps,options);}
export function decodeGraph(doc,caps,anchors=new Map()){need(validated.has(doc),'NOT_VALIDATED');const admission=validated.get(doc);need(admission.caps===caps&&admission.methods.every((f,i)=>f===[caps.has,caps.resolve,caps.checkType,caps.construct][i]),'CAPABILITY_REGISTRY');const values=new Array(doc.nodes.length);
 const token=t=>{switch(t[0]){case 'null':return null;case 'undefined':return undefined;case 'boolean':case 'string':return t[1];case 'number':return numberValue(t[1]);case 'bigint':return BigInt(t[1]);case 'cap':return caps.resolve(t[1]);case 'ref':return values[t[1]];}};
 for(let i=0;i<doc.nodes.length;i++){const n=doc.nodes[i];if(anchors.has(i)){values[i]=anchors.get(i);continue;}values[i]=n.kind==='buffer'?Uint8Array.from(n.bytes).buffer:n.kind==='array'?new Array(n.length):n.kind==='map'?new Map():n.kind==='set'?new Set():n.kind==='class'?caps.construct(n.type,n.props.map(e=>e[0])):n.kind==='nullObject'?Object.create(null):n.kind==='view'?null:{};}
 for(let i=0;i<doc.nodes.length;i++){const n=doc.nodes[i];if(n.kind==='view'&&!anchors.has(i))values[i]=new TYPES[n.type](token(n.buffer),n.offset,n.length);}
 for(let i=0;i<doc.nodes.length;i++){const n=doc.nodes[i],v=values[i];if(anchors.has(i)){if(n.kind==='buffer')new Uint8Array(v).set(n.bytes);if(n.kind==='array')v.length=n.length;if(n.kind==='map'||n.kind==='set')v.clear();if(n.props)for(const k of Object.keys(v))if(!n.props.some(e=>e[0]===k))delete v[k];}if(n.props)for(const [k,t]of n.props)Object.defineProperty(v,k,{value:token(t),writable:true,enumerable:true,configurable:true});else if(n.kind==='map')for(const [k,t]of n.entries)v.set(token(k),token(t));else if(n.kind==='set')for(const t of n.entries)v.add(token(t));}
 return token(doc.root);
}
