import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./2997ced5c6273385064924f8.mjs";
import { updateChildrenSayuri } from "./d2cd6c2c9053eff29ff0ef4e.mjs";
import { parseCommandSayuri, dispatchMovesSayuri, tickHookSayuri } from "./295c369bd92a7f5119a6805f.mjs";
import { thinkSayuri } from "./33a0046f275e19b365ec14c7.mjs";
import "./ead9c46a72b10595f5b541d5.mjs";
import "./951629ddc4cd9a2279e90db1.mjs";
import "./982be4fa7db445d5acb8c7a6.mjs";
import "./bab48200b50b1f039b9dfadf.mjs";
const POINTS_X = [
    0,
    19,
    -24,
    12,
    21
];
const POINTS_Y = [
    -64,
    0,
    -13,
    -16,
    -47
];
const F3150_INIT = 999;
export class Sayuri extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = F3150_INIT;
    a3154 = new Int32Array(64);
    a3254 = new Int32Array(64);
    a3354 = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        1,
        2,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f314c = 0;
        this.f3148 = 0;
        this.f3150 = F3150_INIT;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a3154.fill(0);
        this.a3254.fill(0);
        this.a3354.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3154[i] = 0;
        this.a3254[i] = 0;
        this.a3354[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {
        tickHookSayuri(this);
    }
    parseCommand() {
        parseCommandSayuri(this);
    }
    dispatchMoves() {
        dispatchMovesSayuri(this);
    }
    think() {
        thinkSayuri(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenSayuri(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
