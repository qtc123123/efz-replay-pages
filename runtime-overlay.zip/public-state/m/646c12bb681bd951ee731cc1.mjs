import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { gameState as gs, setBgmRamp } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { registerChildren, registerStates } from "./9410f25ccc5489d02b4dd080.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./1d4a8932dc5ab92063658a65.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function superFreeze(c, cost) {
    c.meter = s16(c.meter - cost);
    c.biasCameraY(0x32, 0x2d);
    c.freeze = 0x78;
    c.superDarken(0xb0, 3);
}
function superEffect(c, d, pat, sound, dy) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function stepFrame(c, dur, d168 = 0) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = d168;
    return true;
}
function finish(c, cnt, next = 0) {
    if (c.frame >= cnt) {
        c.state = next;
        c.faceOpponent();
        c.onStateChange();
    }
}
function catchHit(c, d) {
    c.onStateChange();
    c.frame = 8;
    c.d168 = 0;
    c.freeze = 0x9f;
    c.seRequest = 3;
    d.w04 = 0;
    d.x = ftol(c.x) + c.facing * 0xa;
    d.y = ftol(c.y) - 0x28;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
}
function launchChaser(c, d, pat) {
    c.onStateChange();
    c.state = 0x12f;
    d.w04 = pat;
    d.x = ftol(c.x) - c.facing * 0xf;
    d.y = ftol(c.y) - 0x2c;
    d.b20 = 0;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
const LEVEL_PAT = [
    0x44,
    0x45,
    0x46
];
const LEVEL_SOUND = [
    0x13,
    5,
    0x40
];
const LEVEL_COST = [
    0x3e8,
    0x7d0,
    0xbb8
];
function groundSuper(c, level, chaser) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (level === 2) c.showAltBackground(0xf);
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        superFreeze(c, LEVEL_COST[level]);
        superEffect(c, d, LEVEL_PAT[level], LEVEL_SOUND[level], 0x2c);
        if (level === 2) c.seRequest = 0x25;
    }
    if (c.d168 === 6 && c.frame === 7) {
        catchHit(c, d);
        return;
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 8) {
        c.frame = 9;
        return;
    }
    if (c.frame === 9) {
        launchChaser(c, d, chaser);
        return;
    }
    finish(c, cnt);
}
function state303(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 1)) {
        d.w04 = 0x1b3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.y < 0.0) c.vy += c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2) {
            c.y = 0.0;
            c.vy = -2.9;
            c.ay = 0.035;
        }
        if (c.frame === 0xa) c.frame -= 2;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
            return;
        }
    }
    if (c.y + c.vy > 0.0 && c.frame > 3 && c.frame < 0xa) {
        c.y = 0.0;
        c.frame = 0xa;
        c.ay = 0.0;
        c.stopMotion();
    }
}
function state304(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.f3140 = ftol(c.ay * 1000.0);
        c.stopMotion();
        superFreeze(c, 0x3e8);
        superEffect(c, d, 0x44, 0x13, 0x2c);
    }
    if (atFrame(c, 6)) {
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
        c.ay = c.f3140 * 0.001;
        c.f3138 = 0;
    }
    if (c.frame > 5 && c.frame < 0xb && c.frame !== 8) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.y < 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 0xb;
    }
    if (c.d168 === 6 && (c.frame === 7 || c.frame === 6)) {
        c.stopMotion();
        catchHit(c, d);
        return;
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 8) {
        if (c.f3138 < 1) {
            c.frame = 9;
            return;
        }
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame === 9) {
        launchChaser(c, d, 0x1a9);
        return;
    }
    finish(c, cnt, 3);
}
function summonSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (p.level === 2 && c.frame > 3) c.showAltBackground(0xf);
    c.stopMotion();
    if (atFrame(c, 4)) {
        superFreeze(c, LEVEL_COST[p.level]);
        superEffect(c, d, LEVEL_PAT[p.level], LEVEL_SOUND[p.level], 0x2c);
        if (p.level === 2) c.seRequest = 0x25;
        d.w04 = p.child;
        d.x = ftol(c.x) + c.facing * p.dx;
        d.y = ftol(c.y) + p.dy;
        d.b20 = 0;
        d.b21 = 1;
        if (p.level === 2) d.d00 = 1;
        d.b18 = c.facing;
        d.d30 = 1;
        d.d28 = 1;
        frameChild(c, d);
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 9 && c.f3138 < p.loops) {
        c.f3138++;
        c.frame -= 3;
    }
    finish(c, cnt);
}
function chargeSuper(c, level) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (level === 2 && c.frame > 3) c.showAltBackground(0xf);
    if (atStart(c)) {
        c.stopMotion();
        superFreeze(c, LEVEL_COST[level]);
        superEffect(c, d, LEVEL_PAT[level], LEVEL_SOUND[level], 0x39);
        if (level === 2) c.seRequest = 0x25;
    }
    if (atFrame(c, 9)) {
        c.f3464 += level + 1;
        if (c.f3464 > 3) c.f3464 = 3;
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 0xf && c.f3138 < 1) {
        c.frame -= 4;
        c.f3138++;
        return;
    }
    finish(c, cnt);
}
function spendSuper(c, fireFrame, d168) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atFrame(c, fireFrame)) {
        c.stopMotion();
        c.biasCameraY(0x32, 3);
        c.freeze = 0xb4;
        c.superDarken(0xb0, 3);
        superEffect(c, d, 0x44, 0x13, 0x39);
        c.f3464--;
    }
    if (!stepFrame(c, dur, d168)) return;
    finish(c, cnt);
}
function setSpecialTimers(v) {
    gs.specialTimerE = v;
    gs.specialTimerE = v;
    gs.specialTimerC = v;
}
function state316(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.b158 = 0;
    c.stopMotion();
    if (atStart(c)) {
        d.w04 = 0x1c2;
        d.x = c.facing * 7 + c.x;
        d.y = -42.0;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = 1;
        d.d30 = 1;
        frameChild(c, d);
    }
    if (c.frame > 6 && c.frame < 0x2a) c.freeze = 2;
    if (atFrame(c, 7)) {
        c.meter = s16(c.meter - 0xbb8);
        c.biasCameraY(0x32, 0x2d);
        c.superDarken(0xb0, 3);
        superEffect(c, d, 0x46, 0x40, 0x2c);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (atFrame(c, 0xa)) c.vy = -0.9;
    if (atFrame(c, 0xc)) {
        c.vy = 0.7;
        c.superDarken(0xb1, 3);
        setSpecialTimers(0x7530);
    }
    if (c.frame === 0x26) setSpecialTimers(0x7530);
    if (c.frame > 0xb && c.frame < 0xe && c.vy + c.y > 0.0) {
        c.timer = 0;
        c.frame = 0xe;
        c.y = 0.0;
        c.vy = 0.0;
    }
    if (c.frame === 0x25 && c.d168 === 3) {
        c.frame = 0x26;
        c.timer = 0;
        o.state = 0x6b;
        o.frame = 0;
        o.timer = 0;
        o.stopMotion();
    }
    if (c.frame === 0x26 && c.timer === 0x3c) c.screenFlash(1, 0xf, 0x78, 0x78);
    if (c.frame === 0x26 && c.timer === 0x78) {
        d.w04 = 0x1c1;
        d.x = 0.0;
        d.y = 0.0;
        d.b20 = 0;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = 1;
        d.d24 = 1;
        d.d30 = 1;
        frameChild(c, d);
    }
    if (atFrame(c, 0x29)) setSpecialTimers(0);
    if (!stepFrame(c, dur)) return;
    if (c.frame === 7 && c.f3140 < 1) {
        c.frame -= 4;
        c.f3140++;
    }
    if (c.frame === 0xc) {
        if (c.f3138 === 5) {
            c.screenFlash(1, 0xf, 0x2d, 0xb4);
            setBgmRamp(-10000, 0xa);
        }
        if (c.f3138 < 0xa) {
            c.f3138++;
            c.frame -= 2;
        }
    }
    if (c.frame === 0xe) c.frame -= 2;
    if (c.frame === 0x25) {
        if (!(o.state >= 0x32 && o.state <= 0x95) && o.y === 0.0) c.w16c = 1;
        else c.w16c = 0;
    }
    if (c.frame === 0x26) c.frame = 0x27;
    if (c.frame === 0x29) {
        c.x = c.facing * 0x61 + c.x;
        c.shakeScreen(3, 0);
        d.w04 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        frameEffect(d);
        c.seRequest = 7;
        setBgmRamp(0, 0x3e8);
    }
    if (c.frame >= cnt) {
        c.state = 0x60;
        c.onStateChange();
    }
}
function state317(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.b158 = 0;
    if (c.frame < 4) o.timer = 0;
    if (atStart(c) && c.f313c === 0) {
        setBgmRamp(0, 0x14);
        c.f313c++;
    }
    if (atFrame(c, 4)) o.w140 = 0;
    if (!stepFrame(c, dur)) return;
    if (c.frame === 4 && c.f313c < 0x13) {
        c.frame = 0;
        c.f313c++;
    }
    finish(c, cnt);
}
registerStates({
    300: (c)=>groundSuper(c, 0, 0x1a9),
    301: (c)=>groundSuper(c, 1, 0x1aa),
    302: (c)=>groundSuper(c, 2, 0x1ab),
    303: state303,
    304: state304,
    307: (c)=>summonSuper(c, {
            level: 0,
            child: 0x1b4,
            dx: 0x3c,
            dy: 0,
            loops: 6
        }),
    308: (c)=>summonSuper(c, {
            level: 1,
            child: 0x1b6,
            dx: 0x3c,
            dy: -0x2d,
            loops: 5
        }),
    309: (c)=>summonSuper(c, {
            level: 2,
            child: 0x1b8,
            dx: -0x32,
            dy: 0xc8,
            loops: 0xa
        }),
    310: (c)=>chargeSuper(c, 0),
    311: (c)=>chargeSuper(c, 1),
    312: (c)=>chargeSuper(c, 2),
    313: (c)=>spendSuper(c, 2, 0),
    314: (c)=>spendSuper(c, 2, 3),
    315: (c)=>spendSuper(c, 1, 0),
    316: state316,
    317: state317
});
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    if (childStep(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function childLoop(c, i) {
    if (childStep(c, i) && c.children[i].frame >= childCount) c.children[i].frame = 0;
}
function scatter(c, i, n, base, kinds, off, span) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    for(let k = 0; k < n; k++){
        d.w04 = (c.random(0, kinds) & 0xffff) + base;
        const bx = ch.x - off;
        d.x = (c.random(0, span) & 0xffff) + bx;
        const by = ch.y - off;
        d.y = (c.random(0, span) & 0xffff) + by;
        if (k === 0) {
            d.b18 = c.facing;
            d.b20 = 0;
            d.b21 = 1;
        }
        frameChild(c, d);
    }
}
function childChaser(c, i, add) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        ch.hitsLeft = 1;
        c.a3158[i]++;
        ch.vy = -1.5;
    }
    ch.vy += 0.035;
    if (ch.hitState === 3) {
        c.f3460 += add;
        c.f345c = 0xbb8;
        if (c.f3460 > 5) c.f3460 = 5;
        ch.hitState = 0;
    }
    if (ch.timer === 0 && ch.frame === 1) scatter(c, i, 6, 0x1ac, 3, 50.0, 0x64);
    childOnce(c, i);
}
function childShard(c, i) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        c.a3158[i]++;
        ch.vx = (c.random(0, 0x28) & 0xffff) * 0.1 + -2.0;
        ch.vy = -0.8 - (c.random(0, 0x28) & 0xffff) * 0.1;
    }
    if (ch.y < 0.0) ch.vy += 0.04;
    if (ch.vy + ch.y > 0.0) {
        scatter(c, i, 4, 0x1af, 4, 10.0, 0x14);
        c.voiceRequest = 0xb;
        c.freeChild(i);
        return;
    }
    childLoop(c, i);
}
function childChip(c, i) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        c.a3158[i]++;
        ch.vx = (c.random(0, 0x14) & 0xffff) * 0.1 + -1.0;
        ch.vy = -0.8 - (c.random(0, 0xa) & 0xffff) * 0.1;
    }
    if (ch.y < 0.0) ch.vy += 0.035;
    childLoop(c, i);
}
function child435(c, i) {
    const ch = c.children[i];
    if (ch.timer === 0 && ch.frame === 0xa) {
        const d = childSpawnFrame;
        d.w04 = 0x1c0;
        d.x = ch.x;
        d.y = ch.y - 120.0;
        d.b18 = c.facing;
        d.b20 = 0;
        d.b21 = 1;
        frameChild(c, d);
    }
    childOnce(c, i);
}
function toFade(c, i) {
    const ch = c.children[i];
    ch.vx = 0.0;
    ch.vy = 0.0;
    ch.frame = 0;
    ch.timer = 0;
    ch.pattern = 0x1ba;
}
function childEmitter(c, i, p) {
    const ch = c.children[i];
    if (c.state !== p.state) {
        toFade(c, i);
        return;
    }
    if (ch.frame === p.shotFrame && ch.timer === 0) {
        const d = childSpawnFrame;
        d.w04 = p.shot;
        d.x = ch.facing * p.dx + ch.x;
        d.y = ch.y - p.dy;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (!childStep(c, i)) return;
    if (ch.frame === p.loopFrame && c.a3158[i] < 0x14) {
        c.a3158[i]++;
        ch.frame -= 1;
    }
    if (ch.frame >= childCount) toFade(c, i);
}
function child437(c, i) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        c.a3158[i]++;
        ch.vx = (c.random(0, 0xa) & 0xffff) * 0.1 + 1.0;
        ch.vy = -(c.random(0, 5) & 0xffff) * 0.1;
        ch.hitsLeft = 1;
    }
    ch.vy -= 0.007;
    childOnce(c, i);
}
function child439(c, i) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        c.a3158[i]++;
        ch.vx = (c.random(0, 0xa) & 0xffff) * 0.1 + 1.5;
        ch.vy = (c.random(0, 0xa) & 0xffff) * 0.1;
        ch.hitsLeft = 1;
    }
    ch.vy -= 0.01;
    childOnce(c, i);
}
const DEG = 57.29579143313326;
function setPolarVelocity(c, i, angle, speed) {
    const ch = c.children[i];
    ch.vx = __numerics.cos(angle / DEG) * speed;
    ch.vy = __numerics.sin(angle / DEG) * speed;
}
function child440(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.vy = -6.8;
    if (ch.frame === 0) {
        ch.vy += 0.059;
        if (ch.vy > 0.0) ch.vy = 0.0;
    }
    if (ch.frame === 4) ch.vy = 5.0;
    if (c.state !== 0x135 && ch.frame < 4) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.frame = 4;
        ch.timer = 0;
        return;
    }
    if ((ch.frame === 1 || ch.frame === 2) && ch.timer === 0) {
        const d = childSpawnFrame;
        d.w04 = 0x1b9;
        d.x = ch.facing * 0x14 + ch.x;
        d.y = ch.y + 55.0;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 0;
        frameChild(c, d);
        c.f3154++;
    }
    if (!childStep(c, i)) return;
    if (ch.frame === 3 && c.a3158[i] < 0xf) {
        c.a3158[i]++;
        ch.frame -= 2;
    }
    if (ch.frame >= childCount) {
        c.freeChild(i);
        c.f3154 = 0;
    }
}
function child441(c, i) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        c.a3158[i]++;
        setPolarVelocity(c, i, 0x2d - (c.f3154 << 1) | 0, 4.0);
        ch.vx = (c.random(0, 0xa) & 0xffff) * 0.1 + ch.vx;
        ch.vy = (c.random(0, 0xa) & 0xffff) * 0.1 + ch.vy;
        ch.hitsLeft = 1;
    }
    ch.vy -= 0.03;
    ch.vx -= 0.025;
    if (ch.vx < 0.5) ch.vx = 0.5;
    childOnce(c, i);
}
function child442(c, i) {
    childOnce(c, i);
}
registerChildren({
    425: (c, i)=>childChaser(c, i, 1),
    426: (c, i)=>childChaser(c, i, 3),
    427: (c, i)=>childChaser(c, i, 5),
    428: childShard,
    429: childShard,
    430: childShard,
    431: childChip,
    432: childChip,
    433: childChip,
    434: childChip,
    435: child435,
    436: (c, i)=>childEmitter(c, i, {
            state: 0x133,
            shotFrame: 7,
            loopFrame: 8,
            shot: 0x1b5,
            dx: 0x23,
            dy: 6.0
        }),
    437: child437,
    438: (c, i)=>childEmitter(c, i, {
            state: 0x134,
            shotFrame: 8,
            loopFrame: 9,
            shot: 0x1b7,
            dx: 0x14,
            dy: 30.0
        }),
    439: child439,
    440: child440,
    441: child441,
    442: child442
});

export function __logicState(){return {LEVEL_PAT,LEVEL_SOUND,LEVEL_COST};}

export function __installInitialRoots(s){
if(LEVEL_PAT!==s["LEVEL_PAT"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_PAT');
if(LEVEL_SOUND!==s["LEVEL_SOUND"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_SOUND');
if(LEVEL_COST!==s["LEVEL_COST"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_COST');
}
