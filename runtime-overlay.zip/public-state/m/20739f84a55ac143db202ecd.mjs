import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./63e7d3d2e4c75abee840f38e.mjs";
import { parseCommandKaori, dispatchMovesKaori } from "./06ad268f61080d8fb7912699.mjs";
import { thinkKaori } from "./956295e590eadaeb604dd277.mjs";
import { updateChildrenKaori } from "./3a237fcb73b1d38bd3b629bc.mjs";
import "./4f2436d936a63efaee1d9a1b.mjs";
import "./aabba782aed14d963f4d8498.mjs";
import "./9a890e1bea0f587702638e77.mjs";
const POINTS_X = [
    -8,
    -25,
    0,
    2,
    31
];
const POINTS_Y = [
    -53,
    0,
    -5,
    -13,
    -29
];
export class Kaori extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    a314c = new Int32Array(64);
    a324c = new Int32Array(64);
    a334c = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        8,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a314c.fill(0);
        this.a324c.fill(0);
        this.a334c.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a314c[i] = 0;
        this.a324c[i] = 0;
        this.a334c[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {}
    parseCommand() {
        parseCommandKaori(this);
    }
    dispatchMoves() {
        dispatchMovesKaori(this);
    }
    think() {
        thinkKaori(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenKaori(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
