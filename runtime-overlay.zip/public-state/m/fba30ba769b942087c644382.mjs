/** Read-only complete-recording analysis. No engine calls or retained frame/event
 * arrays: each traversal owns only its coverage and current combat episode. */
const MAX_FRAMES=1000000,MAX_EVENTS=64;
const PHASES=new Set(['loading','intro','round-transition','round-ko','combat','finish','cleanup']);
const STAGES=new Set(['entry','render','post-intro','round-judge','post-effects','post-stage','complete']);
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
const need=(ok,message)=>{if(!ok)throw Error('Round analysis: '+message);};
export function validateRoundSummary(value,{frames,winRounds}={}){
 const keys=['schema','frames','winRounds','roundsPlayed','matchStatus'];
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain summary required');
 const own=Reflect.ownKeys(value);need(own.length===keys.length&&keys.every(key=>own.includes(key)),'summary fields');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'summary data fields');out[key]=d.value;}
 need(['finished','interrupted','unknown'].includes(out.matchStatus),'match status');
 need(out.schema==='efz-round-summary/1'&&integer(out.frames,1,MAX_FRAMES)&&integer(out.winRounds,1,5)&&integer(out.roundsPlayed,0,out.frames*MAX_EVENTS),'summary extent/version');
 need((frames===undefined||out.frames===frames)&&(winRounds===undefined||out.winRounds===winRounds),'summary configuration/coverage');return Object.freeze(out);
}
export function createRoundAccumulator(){
 let coveredThrough=0,phase=null,round=null,roundsPlayed=0,valid=true;
 function transition(nextPhase,nextRound){
  need(PHASES.has(nextPhase)&&integer(nextRound,0,0xffffffff),'phase observation');
  // A changed label while still in combat does not establish a new episode.
  // Source hooks must expose the intervening noncombat transition, or unknown.
  need(phase!=='combat'||nextPhase!=='combat'||nextRound===round,'ambiguous combat label');
  if(nextPhase==='combat'&&phase!=='combat')roundsPlayed++;
  phase=nextPhase;round=nextRound;
 }
 function observe(result){
  if(!valid)return;
  try{
   need(result&&['advanced','end'].includes(result.kind)&&result.nextFrame===coveredThrough+1&&integer(result.nextFrame,1,MAX_FRAMES),'contiguous complete update');
   const o=result.observation;need(o&&o.nextUpdate===result.nextFrame&&Array.isArray(o.engineEvents)&&o.engineEvents.length<=MAX_EVENTS,'complete phase coverage');
   if(coveredThrough===0)need(o.engineEvents[0]?.stage==='entry','initial phase coverage');
   for(const event of o.engineEvents){need(event&&STAGES.has(event.stage)&&(event.innerTick===null||integer(event.innerTick,-1,MAX_FRAMES)),'ordered engine event');transition(event.phase,event.round);}
   need(o.phase===phase&&o.round===round,'missing phase transition');coveredThrough=result.nextFrame;
  }catch{valid=false;}
 }
 function complete(frames,winRounds,terminalState){
  if(!valid||coveredThrough!==frames)return null;
  try{
   let matchStatus='unknown';
   if(terminalState?.nextFrame===frames&&terminalState.failed===false){
    const current=terminalState.characters;
    const players=current===undefined||Array.isArray(current)&&current.length===2&&current.every(p=>p===null)?terminalState.lastCharacters:current;
    // Missing characters at cleanup may use the engine's retained last-live
    // score. Malformed current data never silently falls back to another score.
    if(Array.isArray(players)&&players.length===2&&players.every(p=>p&&integer(p.wins,0,5)))matchStatus=players.some(p=>p.wins>=winRounds)?'finished':'interrupted';
   }
   return validateRoundSummary({schema:'efz-round-summary/1',frames,winRounds,roundsPlayed,matchStatus},{frames,winRounds});
  }catch{return null;}
 }
 return Object.freeze({observe,complete});
}
