import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { CHARACTER_FOLDERS } from "./ed94471e7e2b500bb335f7ed.mjs";
import { GameMode } from "./11a8544a0f705ad2a3ee4f96.mjs";
const MODE_NAMES = {
    [GameMode.Arcade]: "arcade",
    [GameMode.Practice]: "practice",
    [GameMode.Score]: "score",
    [GameMode.VsCom]: "vs_com",
    [GameMode.VsPlayer]: "vs_player",
    [GameMode.Replay]: "replay",
    [GameMode.Demo]: "demo"
};
function track(name, params) {
    if (typeof gtag !== "function") return;
    gtag("event", name, params);
}
export function trackLaunch() {
    track("launch_game");
}
export function trackStartGame(characterId, mode) {
    track("start_game", {
        character: CHARACTER_FOLDERS[characterId] ?? String(characterId),
        game_mode: MODE_NAMES[mode]
    });
}

export function __logicState(){return {MODE_NAMES};}
