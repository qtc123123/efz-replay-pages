import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
let seed = 1;
export function srand(value) {
    if (__session.activeSession()) throw Error("RESEED_UNQUALIFIED");
    seed = value >>> 0;
}
export function getRandState() {
    if (__session.activeSession()) return __session.rngState();
    return seed;
}
export function rand() {
    if (__session.activeSession()) return __session.random(arguments[0], arguments[1]);
    __session.beforeSeedRandom();
    seed = Math.imul(seed, 214013) + 2531011 >>> 0;
    return seed >>> 16 & 0x7fff;
}

export function __logicState(){return {seed};}

export function __installInitialRoots(s){
seed=s["seed"];
}
