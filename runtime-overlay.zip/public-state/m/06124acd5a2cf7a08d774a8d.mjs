import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { keyIniData, readKeyIniByte } from "./7f6020a950d8c30e51948660.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
export var InputBit = /*#__PURE__*/ function(InputBit) {
    InputBit[InputBit["Right"] = 1] = "Right";
    InputBit[InputBit["Left"] = 2] = "Left";
    InputBit[InputBit["Down"] = 4] = "Down";
    InputBit[InputBit["Up"] = 8] = "Up";
    InputBit[InputBit["A"] = 16] = "A";
    InputBit[InputBit["B"] = 32] = "B";
    InputBit[InputBit["C"] = 64] = "C";
    InputBit[InputBit["D"] = 128] = "D";
    return InputBit;
}({});
const DIK_TO_CODE = {
    0x01: "Escape",
    0x02: "Digit1",
    0x03: "Digit2",
    0x04: "Digit3",
    0x05: "Digit4",
    0x06: "Digit5",
    0x07: "Digit6",
    0x08: "Digit7",
    0x09: "Digit8",
    0x0a: "Digit9",
    0x0b: "Digit0",
    0x0c: "Minus",
    0x0d: "Equal",
    0x0e: "Backspace",
    0x0f: "Tab",
    0x10: "KeyQ",
    0x11: "KeyW",
    0x12: "KeyE",
    0x13: "KeyR",
    0x14: "KeyT",
    0x15: "KeyY",
    0x16: "KeyU",
    0x17: "KeyI",
    0x18: "KeyO",
    0x19: "KeyP",
    0x1a: "BracketLeft",
    0x1b: "BracketRight",
    0x1c: "Enter",
    0x1d: "ControlLeft",
    0x1e: "KeyA",
    0x1f: "KeyS",
    0x20: "KeyD",
    0x21: "KeyF",
    0x22: "KeyG",
    0x23: "KeyH",
    0x24: "KeyJ",
    0x25: "KeyK",
    0x26: "KeyL",
    0x27: "Semicolon",
    0x28: "Quote",
    0x29: "Backquote",
    0x2a: "ShiftLeft",
    0x2b: "Backslash",
    0x2c: "KeyZ",
    0x2d: "KeyX",
    0x2e: "KeyC",
    0x2f: "KeyV",
    0x30: "KeyB",
    0x31: "KeyN",
    0x32: "KeyM",
    0x33: "Comma",
    0x34: "Period",
    0x35: "Slash",
    0x36: "ShiftRight",
    0x37: "NumpadMultiply",
    0x38: "AltLeft",
    0x39: "Space",
    0x47: "Numpad7",
    0x48: "Numpad8",
    0x49: "Numpad9",
    0x4a: "NumpadSubtract",
    0x4b: "Numpad4",
    0x4c: "Numpad5",
    0x4d: "Numpad6",
    0x4e: "NumpadAdd",
    0x4f: "Numpad1",
    0x50: "Numpad2",
    0x51: "Numpad3",
    0x52: "Numpad0",
    0x53: "NumpadDecimal",
    0x9c: "NumpadEnter",
    0x9d: "ControlRight",
    0xb5: "NumpadDivide",
    0xb8: "AltRight",
    0x91: "BracketLeft",
    0xc8: "ArrowUp",
    0xd0: "ArrowDown",
    0xcb: "ArrowLeft",
    0xcd: "ArrowRight",
    0xc7: "Home",
    0xcf: "End",
    0xc9: "PageUp",
    0xd1: "PageDown",
    0xd2: "Insert",
    0xd3: "Delete"
};
const bindings = [
    [
        0x24,
        0x22,
        0x31,
        0x15,
        0x10,
        0x11,
        0x12,
        0x20
    ],
    [
        0xcd,
        0xcb,
        0xd0,
        0xc8,
        0x19,
        0x91,
        0x1b,
        0x2b
    ]
];
const keys = new Set();
let quitRequested = false;
let touchMask = 0;
const touchQueue = [];
const TOUCH_QUEUE_MAX = 4;
export function setTouchMask(mask) {
    if (mask === touchMask) return;
    touchMask = mask;
    touchQueue.push(mask);
    if (touchQueue.length > TOUCH_QUEUE_MAX) touchQueue.splice(0, touchQueue.length - TOUCH_QUEUE_MAX);
}
function readTouchMask() {
    return touchQueue.shift() ?? touchMask;
}
export function setVirtualKey(code, down) {
    if (down) keys.add(code);
    else keys.delete(code);
}
const prevHeld = [
    [
        0,
        0,
        0,
        0
    ],
    [
        0,
        0,
        0,
        0
    ]
];
export function initInput() {
    loadStartupKeyConfig();
}
function loadKeyConfig(profile) {
    const data = keyIniData();
    if (!data) return;
    const slotOf = [
        3,
        2,
        1,
        0,
        4,
        5,
        6,
        7
    ];
    for(let p = 0; p < 2; p++){
        const base = 39 * profile + 16 * p;
        for(let i = 0; i < 8; i++){
            const dev = data[base + i * 2] ?? 0;
            const code = data[base + i * 2 + 1] ?? 0;
            bindings[p][slotOf[i]] = (dev << 8 | code) - (dev > 0 ? 1 : 0);
        }
    }
}
function loadStartupKeyConfig() {
    const profile = readKeyIniByte(0x9c);
    loadKeyConfig(profile > 0 ? profile : 0);
}
export function checkFunctionKeys() {
    if (keys.has("F1")) loadKeyConfig(0);
    const profiles = [
        [
            "F2",
            1
        ],
        [
            "F3",
            2
        ],
        [
            "F4",
            3
        ]
    ];
    for (const [code, n] of profiles){
        if (keys.has(code) && readKeyIniByte(0x98) > 0) loadKeyConfig(n);
    }
}
function isBindingHeld(binding, pads) {
    const dev = binding >> 8;
    const lo = binding & 0xff;
    if (dev === 0) {
        const code = DIK_TO_CODE[lo];
        return code !== undefined && keys.has(code);
    }
    const pad = pads[dev - 1];
    if (!pad) return false;
    if (lo < 16) return pad.buttons[lo]?.pressed ?? false;
    const ax = pad.axes[0] ?? 0;
    const ay = pad.axes[1] ?? 0;
    switch(lo){
        case 16:
            return ay <= -0.501 || (pad.buttons[12]?.pressed ?? false);
        case 17:
            return ay >= 0.501 || (pad.buttons[13]?.pressed ?? false);
        case 18:
            return ax <= -0.501 || (pad.buttons[14]?.pressed ?? false);
        case 19:
            return ax >= 0.501 || (pad.buttons[15]?.pressed ?? false);
    }
    return false;
}
function connectedPads() {
    const pads = navigator.getGamepads?.() ?? [];
    return [
        ...pads
    ].filter((p)=>p !== null).slice(0, 2);
}
export function readMask(player) {
    return __session.readInput(player);
}
export function pollInput() {
    for(let p = 0; p < 2; p++){
        const m = readMask(p);
        const input = gs.input[p];
        input.moveX = m & 2 ? -1 : m & 1 ? 1 : 0;
        input.moveY = m & 8 ? -1 : m & 4 ? 1 : 0;
        const held = [
            m & 16,
            m & 32,
            m & 64,
            m & 128
        ].map((v)=>v ? 1 : 0);
        const pressed = held.map((h, i)=>h && !prevHeld[p][i] ? 1 : 0);
        input.a = pressed[0];
        input.b = pressed[1];
        input.c = pressed[2];
        input.d = pressed[3];
        prevHeld[p] = held;
    }
}
export function isKeyDown(code) {
    return __session.auxiliary(code);
}
export function checkEscapeKey() {
    return __session.auxiliary("Escape");
}
export function requestQuit() {
    quitRequested = true;
}
export function isQuitRequested() {
    return quitRequested;
}
export function __inputState() {
    return {
        prevHeld,
        quitRequested,
        touchMask,
        touchQueue,
        keys: [
            ...keys
        ],
        bindings
    };
}

export function __logicState(){return {InputBit,DIK_TO_CODE,bindings,keys,quitRequested,touchMask,touchQueue,prevHeld};}

export function __installInitialRoots(s){
InputBit=s["InputBit"];
if(DIK_TO_CODE!==s["DIK_TO_CODE"])throw Error('INITIAL_CONST_IDENTITY:DIK_TO_CODE');
if(bindings!==s["bindings"])throw Error('INITIAL_CONST_IDENTITY:bindings');
if(keys!==s["keys"])throw Error('INITIAL_CONST_IDENTITY:keys');
quitRequested=s["quitRequested"];
touchMask=s["touchMask"];
if(touchQueue!==s["touchQueue"])throw Error('INITIAL_CONST_IDENTITY:touchQueue');
if(prevHeld!==s["prevHeld"])throw Error('INITIAL_CONST_IDENTITY:prevHeld');
}
