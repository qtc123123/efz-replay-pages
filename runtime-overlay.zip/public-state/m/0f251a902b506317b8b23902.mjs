import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./6eb1fb66adb5d5a47cd5c7ec.mjs";
import { abortChildWalk, childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./746d3a93e9a50814987814cf.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function drawGauge(c, pattern, len) {
    const f = c.patterns[pattern]?.frames[0];
    if (!f) return;
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    const w = len(f.width);
    const src = makeRect(0, 0, w, f.height);
    const dst = c.side === 0 ? makeRect(0x31 - f.offsetX, 0x1f - f.offsetY, w, f.height) : makeRect(f.offsetX + 0x10f - w, 0x1f - f.offsetY, w, f.height);
    blit(dst, surf, src, c.colorKey, false);
}
export function renderOverlayMai(c) {
    if (c.f3148 > 0 && c.f3144 !== 3) drawGauge(c, 41, (w)=>w);
    if (c.f3144 === 3) drawGauge(c, 42, (w)=>w);
    if (c.f3148 > 0 && c.f3144 !== 3) drawGauge(c, 43, (w)=>Math.trunc(w * c.f3148 / 0x2710));
    if (c.f3144 === 3) drawGauge(c, 44, (w)=>Math.trunc(w * c.f3148 / 0x4b0));
}
export function tickHookMai(c) {
    const d = openSpawnFrame();
    if (c.f3148 > 0) {
        c.f3148--;
        if (c.f3144 === 3) c.f3148--;
        if (c.f3150 === 1) c.f3148 -= 4;
        if (c.f3150 === 2) c.f3148++;
        if (c.f3150 === 3) c.f3148--;
        if (c.f3150 === 4) c.f3148--;
    }
    if (c.f3144 === 4) {
        c.meter = 0;
        c.showAltBackground(3);
    }
    if (c.f3148 > 0) return;
    if (c.f3144 === 3) {
        d.w04 = 1;
        d.b2c = 0xb;
        d.x = ftol(c.x);
        d.y = ftol(c.y - 40.0);
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.f3144 = 0;
        c.f3148 = 0;
        c.f314c = 0;
        c.f3150 = 0;
    }
    if (c.f3144 === 4 && c.state !== 0x144 && c.state !== 0x145) {
        c.f3148 = 0x4b0;
        c.f3144 = 3;
        c.f314c = 0;
        c.f3150 = 2;
    }
}
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function stepFrame(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    return true;
}
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function superEffect(d, c, pat, sound, backX, offY) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) - c.facing * backX;
    d.y = ftol(c.y) - offY;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function endToNeutral(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function rushMiddle(c, rushVx) {
    if (atFrame(c, 4)) c.voiceRequest = 0;
    if (atFrame(c, 8)) c.vx = rushVx;
    if (atFrame(c, 9)) {
        c.vx = 1.8;
        c.ax = -0.05;
    }
    if (c.frame > 8) {
        c.vx += c.ax;
        if (c.vx < 0.0) c.vx = 0.0;
    }
}
function rushCheck(c, next, onGrab) {
    if (c.frame !== 8) return false;
    if (c.d168 === 2 || c.d168 === 5) {
        c.timer = 0;
        c.frame = 9;
        return true;
    }
    if (c.d168 !== 3) return false;
    const o = c.opponent;
    o.hitstop = 0x270f;
    c.onStateChange();
    o.onStateChange();
    o.y = 0.0;
    o.state = 0x6c;
    c.state = next;
    onGrab?.();
    return true;
}
function rushTail(c, dur, cnt) {
    if (c.frame > 0 && c.frame < 0x12) c.biasCameraY(0x32, 3);
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function rushSuper(c, cost, pat, sound, rushVx, next) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame === 2) c.biasCameraY(0x32, 3);
    if (atFrame(c, 2)) {
        c.w16c = 1;
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, 0, 0x28);
    }
    rushMiddle(c, rushVx);
    if (rushCheck(c, next)) return;
    rushTail(c, dur, cnt);
}
function state303(c) {
    rushSuper(c, 0x3e8, 0x44, 0x13, 5.0, 0x132);
}
function state304(c) {
    rushSuper(c, 0x7d0, 0x45, 5, 7.0, 0x133);
}
function state305(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40, 0, 0x28);
        c.seRequest = 0x25;
    }
    if (c.frame > 1) c.showAltBackground(0xf);
    if (c.frame <= 2) c.biasCameraY(0x32, 3);
    rushMiddle(c, 10.0);
    const grabbed = rushCheck(c, 0x134, ()=>{
        d.w04 = 0x1a3;
        d.x = 0.0;
        d.y = 20.0;
        d.b20 = 0;
        d.d00 = 1;
        d.b18 = 1;
        d.b21 = 0;
        d.d30 = 1;
        frameChild(c, d);
        d.w04 = 0x1a4;
        d.x = 0.0;
        d.y = 38.0;
        d.b20 = 0;
        d.d00 = 1;
        d.b18 = 1;
        d.b21 = 1;
        d.d30 = 1;
        frameChild(c, d);
    });
    if (grabbed) return;
    rushTail(c, dur, cnt);
}
function throwHead(c, resetF3138, resetD168, voiceFrame) {
    if (atStart(c)) {
        if (resetF3138) c.f3138 = 0;
        c.vx = 0.3;
        c.x = c.facing * 0x1e + c.opponent.x;
        if (resetD168) c.d168 = 0;
    }
    if (atFrame(c, 9)) {
        c.x = c.x + 0.0;
        c.vx = 0.0;
    }
    if (atFrame(c, 0xb)) c.seRequest = 0x14;
    if (atFrame(c, voiceFrame)) c.voiceRequest = 2;
}
function throwHit(c, d, knockY, setD168, damage, proration, hitstun) {
    const o = c.opponent;
    o.state = 0x47;
    o.hitstop = 0;
    o.knockX = 0.0;
    o.knockY = knockY;
    if (setD168) c.d168 = 2;
    applyDirectDamage(c, damage, proration);
    if (hitstun) o.hitstun = s16(ftol(200.0 * c.proration / 10000.0));
    d.w04 = 0x34;
    d.x = o.x;
    d.b2c = 0x16;
    d.y = o.y - 40.0;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
}
function throwLoop(c, dur, cnt) {
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 6 && c.f3138 < 9) {
            c.frame = 4;
            c.f3138++;
        }
        if (c.frame === 9) {
            c.x = c.facing * 0x50 + c.x;
            c.f3138 = 0;
        }
        if (c.frame === 0xd && c.f3138 < 0xc) {
            c.frame = 0xb;
            c.f3138++;
        }
        if (c.frame === 0xe) c.f3138 = 0xc;
    }
    if (c.frame >= cnt) {
        if (c.f3138 > 0) {
            c.frame -= 2;
            c.f3138--;
        } else {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state306(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    throwHead(c, false, true, 0xf);
    if (c.frame === 0xf && c.timer === 0x5a) throwHit(c, d, -4.0, true, 0x960, 400.0, false);
    if (c.frame > 0 && c.frame < 0xf) c.biasCameraY(0x32, 0xa);
    if (stepFrame(c, dur)) {
        if (c.frame === 6 && c.f3138 < 9) {
            c.frame -= 2;
            c.f3138++;
        }
        if (c.frame === 9) {
            c.x = c.facing * 0x50 + c.x;
            c.f3138 = 0;
        }
        if (c.frame === 0xd && c.f3138 < 0xc) {
            c.frame -= 2;
            c.f3138++;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state307(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    throwHead(c, true, true, 0xe);
    if (atFrame(c, 0xf) && c.f3138 === 7) throwHit(c, d, -4.0, true, 0xc80, 400.0, false);
    if (c.frame > 0 && c.frame < 0xf) c.biasCameraY(0x32, 0xa);
    throwLoop(c, dur, cnt);
}
function state308(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    throwHead(c, true, true, 0xe);
    if (atFrame(c, 0xf) && c.f3138 === 7) throwHit(c, d, -4.0, true, 0x1194, 400.0, true);
    if (c.frame > 0 && c.frame < 0xf) c.biasCameraY(0x32, 0xa);
    throwLoop(c, dur, cnt);
}
function state312(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    throwHead(c, true, false, 0xe);
    if (atFrame(c, 0xf) && c.f3138 === 7) throwHit(c, d, -8.0, false, 0x1068, 750.0, true);
    if (c.frame > 0 && c.frame < 0xf) c.biasCameraY(0x32, 0xa);
    throwLoop(c, dur, cnt);
}
function state309(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.biasCameraY(0x32, 3);
    if (atStart(c)) {
        c.voiceRequest = 3;
        c.stopMotion();
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40, 0, 0x28);
        d.w04 = 0x47;
        frameEffect(d);
        c.seRequest = 0x25;
        d.w04 = 0x1ab;
        d.x = ftol(c.x) + c.facing * 0x14;
        d.y = 0.0;
        d.d30 = 1;
        d.b18 = c.facing;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (stepFrame(c, dur)) {
        if (c.frame === 6 && c.freeze > 0) {
            c.frame -= 4;
            c.f3138++;
        }
        endToNeutral(c, cnt);
    }
}
function holdPose(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) c.f3148 = 0;
    if (stepFrame(c, dur) && c.frame >= cnt) {
        if (c.f3144 === 1) {
            c.frame = 0;
            return;
        }
        c.state = 0;
        c.onStateChange();
    }
}
function summonSuper(c, cost, pat, sound, child) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 3)) {
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, 0xd, 0x33);
        d.w04 = child;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0xf;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 0;
        d.b18 = c.facing;
        d.d30 = 300;
        frameChild(c, d);
        c.f3144 = 2;
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function simpleMove(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function state324(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame < 5) c.biasCameraY(0x32, 3);
    if (atStart(c)) {
        c.stopMotion();
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40, 0x13, 0x32);
        d.w04 = 0x47;
        frameEffect(d);
        c.seRequest = 0x25;
        c.w16c = 0;
    }
    if (c.frame === 4 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.stopMotion();
        o.onStateChange();
        c.state = 0x145;
        o.state = 0x79;
        c.superDarken(0xb0, 3);
    }
    if (atFrame(c, 5)) {
        c.f3148 = 0;
        c.w16c = 1;
    }
    if (stepFrame(c, dur)) {
        if (c.frame === 4) c.w16c = o.y === 0.0 ? 1 : 0;
        endToNeutral(c, cnt);
    }
}
function state325(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.biasCameraY(0x32, 3);
    if (c.frame < 2) c.superDarken(0xb0, 3);
    if (c.frame > 1 && c.frame < 0xa) {
        c.superDarken(0xb1, 3);
        o.requestFlash(0xb0, 3);
    }
    if (atFrame(c, 1)) {
        c.voiceRequest = 3;
        d.w04 = 0x1c2;
        d.x = 0.0;
        d.y = 0.0;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.d24 = 1;
        d.b18 = 1;
        frameChild(c, d);
    }
    if (atFrame(c, 2)) o.state = 0x6b;
    if (atFrame(c, 0xb)) c.voiceRequest = 2;
    if (atFrame(c, 0xc)) {
        o.state = 0x47;
        o.knockX = 0.0;
        o.knockY = -5.0;
        o.frame = 0;
        o.timer = 0;
        o.d128 = 1;
        applyDirectDamage(c, ftol(c.f3148 * 0.15 + 3500.0), 500.0);
        c.seRequest = 0x16;
        o.facing = -c.facing;
        o.hitstop = 0;
        d.w04 = 0x34;
        d.x = ftol(o.x);
        d.y = ftol(o.y) - 0x28;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.f3148 = 0;
    }
    if (stepFrame(c, dur)) {
        if (c.frame === 6 && c.f3138 < 4) {
            c.frame -= 4;
            c.f3138++;
        }
        endToNeutral(c, cnt);
    }
}
registerStates({
    303: state303,
    304: state304,
    305: state305,
    306: state306,
    307: state307,
    308: state308,
    309: state309,
    312: state312,
    315: holdPose,
    316: holdPose,
    317: holdPose,
    318: (c)=>summonSuper(c, 0x3e8, 0x44, 0x13, 0x1b6),
    319: simpleMove,
    320: (c)=>summonSuper(c, 0x7d0, 0x45, 5, 0x1ba),
    321: simpleMove,
    322: (c)=>summonSuper(c, 0xbb8, 0x46, 0x40, 0x1be),
    323: simpleMove,
    324: state324,
    325: state325
});
function childStep(c, i, dur) {
    const ch = c.children[i];
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function child419(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    if (c.state !== 0x134) {
        if (c.a3158[i] < 9) {
            ch.blend = 1;
            c.a3158[i]++;
            return;
        }
        c.freeChild(i);
        return;
    }
    ch.timer++;
    childStep(c, i, dur);
}
function child427(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const d = childSpawnFrame;
    c.showAltBackground(0xf);
    c.freeze = 2;
    c.superDarken(0xb0, 1);
    ch.vy += 0.05;
    if (ch.vy > -0.1) ch.vy = -0.1;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame === 7) {
        ch.vy = -1.5;
        ch.vx = 0.0;
    }
    if (ch.frame < cnt) return;
    if (c.a3158[i] < 6) {
        c.a3158[i]++;
        ch.frame -= 2;
        return;
    }
    c.voiceRequest = 4;
    d.w04 = 1;
    d.b2c = 0;
    d.x = ftol(ch.x);
    d.y = ftol(ch.y - 40.0);
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    c.f3148 = 0x2710;
    c.f3144 = 4;
    c.freeze = 0x3c;
    c.superDarken(0xb0, 0x14);
    c.freeChild(i);
}
function summonRevert(c, i) {
    const ch = c.children[i];
    c.f3144 = 2;
    if (c.state > 0x31 && c.state < 0x96 || ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 0x192;
        ch.frame = 0;
        ch.timer = 0;
        abortChildWalk();
        return true;
    }
    return false;
}
function summonShot(c, i, pattern, offY) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    d.w04 = pattern;
    d.x = ftol(ch.facing * 0x1c + ch.x);
    const y = offY();
    if (y !== null) d.y = y;
    d.d00 = 1;
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = ch.facing;
    frameChild(c, d);
}
function summonEnd(c, i) {
    const ch = c.children[i];
    c.f3144 = 3;
    c.f3148 = 0x4b0;
    c.a3158[i] = 0;
    c.a3258[i] = 0;
    ch.frame = 0;
    ch.vx = 0.0;
    c.freeChild(i);
}
function summonA(c, i, shot) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (summonRevert(c, i)) return;
    if (ch.frame === 0 && ch.timer === 0) ch.vx = -1.5;
    if (ch.vx < 0.0) ch.vx += 0.03;
    if (ch.vy < 0.0) ch.vy += 0.025;
    if (ch.vx > 0.0) ch.vx = 0.0;
    if (ch.vy > 0.0) ch.vy = 0.0;
    if (ch.frame === 7 && ch.timer === 0) summonShot(c, i, shot, ()=>ftol(ch.y - 57.0));
    ch.timer++;
    if (ch.timer < dur) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 0xa && c.a3158[i] < 0xa) {
        ch.frame -= 2;
        c.a3158[i]++;
    }
    ch.hitState = 0;
    if (ch.frame >= cnt) summonEnd(c, i);
}
function summonB(c, i, cost, pat, sound, loops, shotY) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const d = childSpawnFrame;
    if (summonRevert(c, i)) return;
    if (ch.frame === 0 && ch.timer === 0) {
        c.freeze = 0x78;
        c.meter = s16(c.meter - cost);
        c.superDarken(0xb0, 3);
        d.w04 = pat;
        d.b2c = sound;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y) - 0x32;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        ch.moveWhileFrozen = 0x78;
    }
    if (ch.frame === 7 && ch.timer === 0) summonShot(c, i, 0x1b9, shotY);
    ch.timer++;
    if (ch.timer < dur) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 0xa && c.a3258[i] < loops) {
        ch.frame = 5;
        c.a3258[i]++;
    }
    if (ch.frame === 0xa && c.a3158[i] < 0xa) {
        ch.frame -= 2;
        c.a3158[i]++;
    }
    ch.hitState = 0;
    if (ch.frame >= cnt) summonEnd(c, i);
}
function shotOut(c, i) {
    const x = c.children[i].x;
    if (x > 740.0 || x < -100.0) {
        c.freeChild(i);
        return true;
    }
    return false;
}
function shotInit(c, i, hits, vx) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.hitsLeft = hits;
        ch.vx = vx;
        c.a3158[i]++;
    }
}
function child440(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    shotInit(c, i, 5, 2.8);
    if (ch.hitState > 0 && ch.hitsLeft === 0 && ch.frame < 0x15) {
        ch.timer = 0;
        ch.frame = 0x15;
        ch.vx = 0.0;
        return;
    }
    if (shotOut(c, i)) return;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame === 0x15) ch.frame = 1;
    if (ch.frame >= cnt) c.freeChild(i);
}
function shotLoop11(c, i, hits, vx, decel) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    shotInit(c, i, hits, vx);
    if (decel) {
        ch.vx -= 0.035;
        if (ch.vx < 1.0) ch.vx = 1.0;
    }
    if (ch.hitState > 0 && ch.hitsLeft === 0 && ch.frame < 0xb) {
        ch.timer = 0;
        ch.frame = 0xb;
        ch.vx = 0.0;
        return;
    }
    if (shotOut(c, i)) return;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame === 0xb) ch.frame = 0;
    if (ch.frame >= cnt) c.freeChild(i);
}
function shotRepeat(c, i, hits, vx) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    shotInit(c, i, hits, vx);
    if (shotOut(c, i)) return;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame >= cnt) ch.frame = 1;
}
function child450(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame >= cnt) c.freeChild(i);
}
registerChildren({
    419: child419,
    420: child419,
    427: child427,
    438: (c, i)=>summonA(c, i, 0x1b8),
    439: (c, i)=>summonB(c, i, 0x3e8, 0x44, 0x13, 1, ()=>ftol(c.children[i].y - 57.0)),
    440: child440,
    441: (c, i)=>shotLoop11(c, i, 1, 4.0, true),
    442: (c, i)=>summonA(c, i, 0x1bc),
    443: (c, i)=>summonB(c, i, 0x7d0, 0x45, 5, 3, ()=>{
            const ch = c.children[i];
            const k = c.a3258[i];
            if (k === 0 || k === 2) return ftol(ch.y - 27.0);
            if (k === 1 || k === 3) return ftol(ch.y - 87.0);
            return null;
        }),
    444: (c, i)=>shotRepeat(c, i, 7, 3.5),
    445: (c, i)=>shotLoop11(c, i, 2, 1.3, false),
    446: (c, i)=>summonA(c, i, 0x1c0),
    447: (c, i)=>summonB(c, i, 0xbb8, 0x46, 0x40, 5, ()=>{
            const base = c.children[i].y - 107.0;
            return ftol((c.random(0, 0x64) & 0xffff) + base);
        }),
    448: (c, i)=>shotRepeat(c, i, 0xa, 4.2),
    449: (c, i)=>shotLoop11(c, i, 3, 1.9, false),
    450: child450
});
