import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./4bfdef0d515a63cf0e27cdb5.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame, setPolarVelocity } from "./7d17e301343a90178a9cad8e.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
function advance(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return true;
}
function addMeter(c, v) {
    c.meter = s16(c.meter + v);
}
function rfCostEffect(c, d) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    d.w04 = 0x21;
    d.b2c = 0xb;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 0x32;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
}
function dustEffect(c, d) {
    d.w04 = 0x1f;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 0;
    d.b21 = 1;
    d.d1c = c.facing !== 1 ? 1 : 0;
    frameEffect(d);
}
function spawn404(c, d) {
    d.w04 = 0x194;
    d.x = ftol(c.x) - c.facing * 0x50;
    d.y = ftol(c.y) - 0x28;
    d.b20 = 2;
    d.b21 = 1;
    d.d00 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function spawn441(c, d) {
    d.w04 = 0x1b9;
    d.x = c.x;
    d.y = c.y;
    d.d00 = 1;
    d.b18 = c.facing;
    d.b20 = 2;
    d.b21 = 1;
    frameChild(c, d);
}
function airLanding(c) {
    if (c.y < 0.0) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y >= 0.0) {
            c.y = 0.0;
            c.onStateChange();
            c.stopMotion();
            c.state = 0x103;
            return true;
        }
    }
    return false;
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.w0dc = 4;
        c.b0de = 0xec;
        c.vx = 0.0;
        c.w16c = 1;
        c.backWindow = 0;
        c.freeze = 0x3c;
        d.w04 = 0x28;
        d.x = ftol(c.x) + c.facing * 0xa;
        d.y = ftol(c.y) - 0x28;
        d.b20 = 2;
        d.b21 = 1;
        d.b2c = 0x13;
        frameEffect(d);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (c.frame === 4 && c.timer === 0) {
        dustEffect(c, d);
        c.w16c = 1;
        addMeter(c, 0x2d);
        c.voiceRequest = 1;
    }
    if (c.frame === 4 && c.timer === 0) spawn404(c, d);
    if (!advance(c, dur)) return;
    if (c.frame < 5) c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = c.vx * 0.3;
        c.vy = c.vy * 0.3;
    }
    c.vy = c.vy + 0.01;
    if (c.vy > 0.3) c.vy = 0.3;
    if (c.frame === 4 && c.timer === 0) {
        c.w16c = 1;
        addMeter(c, 0x2d);
        c.voiceRequest = 1;
    }
    if (c.frame === 4 && c.timer === 0) spawn404(c, d);
    if (!advance(c, dur)) return;
    if (c.frame < 5) c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 9;
        c.onStateChange();
    }
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        c.startAfterimage(3);
        rfCostEffect(c, d);
        c.w16c = 1;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.w16c = 1;
        if (c.y < 0.0) c.frame = 6;
    }
    if (c.frame === 4 && c.timer === 0) {
        dustEffect(c, d);
        c.w16c = 1;
        addMeter(c, 0x2d);
        c.voiceRequest = 1;
    }
    if (c.frame === 2 && c.timer === 0) {
        d.w04 = 0x1ab;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (!advance(c, dur)) return;
    if (c.frame < 5) c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state256(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 2;
    }
    if (airLanding(c)) return;
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 3) {
        c.vy = -2.5;
        c.ay = 0.045;
        spawn441(c, d);
    }
    if (c.frame >= cnt) c.frame = c.frame - 2;
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.startAfterimage(1);
        if (c.f313c === 0) {
            c.stopMotion();
            rfCostEffect(c, d);
            c.f313c = c.f313c + 1;
        }
        c.w16c = 1;
    }
    if (c.frame === 1 && c.timer === 0) spawn441(c, d);
    if (airLanding(c)) return;
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 3 && c.f313c === 1) {
        c.vy = -3.5;
        c.ay = 0.015;
        c.f313c = c.f313c + 1;
    }
    if (c.frame === 8 && c.f3138 < 5) {
        c.frame = 0;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame === 9) c.w16c = 1;
    if (c.frame >= cnt) {
        c.onStateChange();
        c.state = 9;
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 3;
        c.faceOpponent();
        c.onStateChange();
    }
}
function stateThrow(c, pat) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atStart(c)) {
        d.w04 = pat;
        d.x = ftol(c.x) + c.facing * 0x1e;
        d.y = ftol(c.y) - 0x28;
        d.b20 = 0;
        d.b21 = 1;
        d.d1c = c.facing !== 1 ? 1 : 0;
        d.b18 = c.facing;
        d.d28 = 1;
        d.d00 = 1;
        frameChild(c, d);
        addMeter(c, 0x2d);
        c.voiceRequest = 2;
    }
    if (!advance(c, dur)) return;
    if (c.frame > 9) c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state266(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (c.frame === 7 && c.timer === 0) {
        d.w04 = 0x195;
        d.x = ftol(c.x) + c.facing * 0x23;
        d.y = ftol(c.y) - 0x3f;
        d.b20 = 2;
        d.b21 = 1;
        d.d1c = c.facing !== 1 ? 1 : 0;
        d.b18 = c.facing;
        d.d28 = 0;
        d.d00 = 1;
        frameChild(c, d);
    }
    if (c.frame === 8 && c.timer === 0) {
        d.w04 = 0x196;
        d.x = ftol(c.x) + c.facing * 0x50;
        d.y = ftol(c.y) - 0x3f;
        d.b20 = 2;
        d.b21 = 1;
        d.d1c = c.facing !== 1 ? 1 : 0;
        d.b18 = c.facing;
        d.d28 = 0;
        d.d00 = 1;
        frameChild(c, d);
        addMeter(c, 0x2d);
        c.voiceRequest = 2;
    }
    if (!advance(c, dur)) return;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state267(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        c.startAfterimage(3);
        rfCostEffect(c, d);
    }
    if (c.frame === 7 && c.timer === 0) {
        d.w04 = 0x1ad;
        d.x = ftol(c.x) + c.facing * 0x23;
        d.y = ftol(c.y) - 0x3f;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.d1c = c.facing !== 1 ? 1 : 0;
        d.b18 = c.facing;
        d.d28 = 0;
        frameChild(c, d);
    }
    if (c.frame === 8 && c.timer === 0) {
        addMeter(c, 0x2d);
        c.voiceRequest = 2;
    }
    if (!advance(c, dur)) return;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
registerStates({
    249: state249,
    250: state250,
    251: state251,
    253: state253,
    256: state256,
    257: state257,
    259: state259,
    263: (c)=>stateThrow(c, 0x190),
    264: (c)=>stateThrow(c, 0x191),
    265: (c)=>stateThrow(c, 0x192),
    266: state266,
    267: state267
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function childSimple(c, i) {
    const ch = c.children[i];
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childDrop(c, i, dx) {
    const ch = c.children[i];
    if (c.a3154[i] === 0) {
        c.a3154[i] = c.a3154[i] + 1;
        ch.vy = -3.0;
    }
    if (ch.vy < 0.0 && ch.frame < 8) {
        ch.vy = ch.vy + 0.105;
        if (ch.vy > 0.0) ch.vy = 0.0;
    }
    if (ch.frame < 8 && c.state > 0x31 && c.state < 0x9d) {
        c.freeChild(i);
        return;
    }
    if (ch.frame === 8) {
        ch.vy = ch.vy + 0.055;
        if (ch.vy + ch.y > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.timer = 0;
            ch.frame = 9;
            const d = childSpawnFrame;
            d.w04 = 0x193;
            d.x = ftol(ch.x) + c.facing * dx;
            d.y = 0.0;
            d.b20 = 0;
            d.d28 = 1;
            d.d00 = 1;
            d.b21 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
            return;
        }
    }
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame === 8 && c.a3254[i] < 1) {
        ch.frame = 0;
        c.a3254[i] = c.a3254[i] + 1;
    }
    if (ch.frame === 8) ch.vy = 7.0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child403(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.shakeScreen(5, 0);
        c.voiceRequest = 3;
    }
    childSimple(c, i);
}
function child406(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3154[i] === 0) {
        ch.hitsLeft = 0x63;
        ch.vx = 3.0;
        ch.vy = 0.0;
        c.a3154[i] = c.a3154[i] + 1;
    }
    if (ch.hitState >= 2) {
        ch.pattern = 0x199;
        ch.hitsLeft = 0;
        ch.frame = 0;
        ch.timer = 0;
        return;
    }
    if (ch.x < -100.0 || ch.frame > 0x2e4) c.freeChild(i);
    ch.vx = ch.vx - 0.025;
    if (ch.vx < 1.2) ch.vx = 1.2;
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) ch.frame = 0;
}
function child407(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3154[i] === 0) {
        ch.hitsLeft = 1;
        ch.vx = 3.0;
        ch.vy = 0.0;
    }
    if (ch.hitState >= 2 || c.state > 0x31 && c.state < 0x96) {
        ch.pattern = 0x19a;
        ch.hitsLeft = 0;
        return;
    }
    ch.vx = ch.vx - 0.015;
    if (ch.vx < 0.4) ch.vx = 0.4;
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child408(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childShardBounce(c, i, init, next) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        init();
    }
    ch.vy = ch.vy + 0.05;
    if (ch.y >= 0.0 && ch.vy > 0.0 && ch.frame === 1) {
        c.freeChild(i);
        return;
    }
    if ((ch.y >= 0.0 || ch.hitState > 1) && ch.frame === 0) {
        ch.y = ch.y - 1.0;
        ch.frame = 1;
        ch.vy = -1.5;
        const d = childSpawnFrame;
        d.w04 = next;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y);
        d.b20 = 0;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.voiceRequest = 1;
    }
    childSimple(c, i);
}
function childShardFall(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = (c.random(0, 0xa) & 0xffff) * 0.1 + 1.5;
        ch.vy = -1.5;
    }
    ch.vy = ch.vy + 0.05;
    if (ch.y >= 0.0 && ch.vy > 0.0) {
        c.freeChild(i);
        return;
    }
    childSimple(c, i);
}
function child411(c, i) {
    const ch = c.children[i];
    childShardBounce(c, i, ()=>{
        ch.vx = (c.random(0, 0xa) & 0xffff) * 0.1 + 2.5;
        ch.vy = -1.2 - (c.random(0, 0x14) & 0xffff) * 0.1;
    }, 0x19c);
}
function child413(c, i) {
    const ch = c.children[i];
    childShardBounce(c, i, ()=>{
        ch.vx = (c.random(0, 0x14) & 0xffff) * 0.1 + 1.7;
        ch.vy = -0.5 - (c.random(0, 0xa) & 0xffff) * 0.1;
    }, 0x19e);
}
function child419(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (c.state === 0x100 && c.hitstop > 0) ch.timer--;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child427(c, i) {
    const ch = c.children[i];
    if (!childAdvance(c, i)) return;
    if (ch.frame === 4) {
        const d = childSpawnFrame;
        d.w04 = 0x1ac;
        d.x = gs.viewLeft;
        d.y = ftol(ch.y) - 0x3c;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = 1;
        frameChild(c, d);
    }
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child428(c, i) {
    const ch = c.children[i];
    ch.x = gs.viewLeft;
    childSimple(c, i);
}
function child429(c, i) {
    const ch = c.children[i];
    if (!childAdvance(c, i)) return;
    if (ch.frame === 4) {
        const d = childSpawnFrame;
        d.w04 = 0x1ae;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = ch.facing;
        d.d00 = 1;
        for(let k = 0; k < 6; k++)frameChild(c, d);
    }
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
const ANGLES_430 = [
    -140.0,
    -165.0,
    -170.0,
    140.0,
    165.0,
    170.0
];
function child430(c, i) {
    const ch = c.children[i];
    if (c.a3154[i] === 0) {
        c.a3154[i] = c.a3154[i] + 1;
        ch.hitsLeft = 1;
        for(let k = 0; k < 6; k++){
            if (c.f3138 === k) setPolarVelocity(c, i, ANGLES_430[k], 3.0);
        }
        c.f3138 = c.f3138 + 1;
        if (c.f3138 === 6) c.f3138 = 0;
    }
    ch.vx = ch.vx + 0.025;
    if (c.opponent.y - 45.0 < ch.y) ch.vy = ch.vy - 0.015;
    if (c.opponent.y - 45.0 > ch.y) ch.vy = ch.vy + 0.015;
    if (ch.timer === 0) {
        const d = childSpawnFrame;
        d.w04 = 0x1af;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
    }
    if (ch.x > 900.0 || ch.x < -360.0 || ch.hitState > 0) {
        ch.pattern = 0x1af;
        ch.frame = 0;
        ch.timer = 0;
        return;
    }
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = 0;
}
function child431(c, i) {
    const ch = c.children[i];
    ch.vx = 0.0;
    ch.vy = 0.0;
    childSimple(c, i);
}
registerChildren({
    400: (c, i)=>childDrop(c, i, 0x32),
    401: (c, i)=>childDrop(c, i, 0x7d),
    402: (c, i)=>childDrop(c, i, 0xc8),
    403: child403,
    404: childSimple,
    405: childSimple,
    406: child406,
    407: child407,
    408: child408,
    409: childSimple,
    410: childSimple,
    411: child411,
    412: childShardFall,
    413: child413,
    414: childShardFall,
    419: child419,
    427: child427,
    428: child428,
    429: child429,
    430: child430,
    431: child431,
    441: childSimple
});

export function __logicState(){return {ANGLES_430};}

export function __installInitialRoots(s){
if(ANGLES_430!==s["ANGLES_430"])throw Error('INITIAL_CONST_IDENTITY:ANGLES_430');
}
