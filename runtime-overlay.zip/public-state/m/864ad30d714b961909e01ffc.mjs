import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./72fceafa5789cf9e4e3cf0ff.mjs";
import { updateChildrenShiori } from "./f2e83919002a3a51b71740fe.mjs";
import { parseCommandShiori, dispatchMovesShiori } from "./511d212ed3c1ff9414b61a8f.mjs";
import { thinkShiori } from "./2b3f7fe6d6bddfb17525396c.mjs";
import { renderOverlayShiori } from "./901b6aa7d92080b0d01fcb15.mjs";
import "./0daa7587cfc661b11314f09e.mjs";
import "./67fc22d94ff23dc102ac9049.mjs";
import "./d99149809521bbf12d34c17f.mjs";
const POINTS_X = [
    -4,
    18,
    21,
    18,
    38
];
const POINTS_Y = [
    -57,
    0,
    -12,
    -15,
    -39
];
export class Shiori extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    f3154 = 0;
    a3158 = new Int32Array(64);
    a3258 = new Int32Array(64);
    a3358 = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        1,
        11,
        0,
        13,
        0xff,
        0xff,
        0xff
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = 0;
        this.f314c = 0;
        this.f3150 = 0;
        this.f3154 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a3158.fill(0);
        this.a3258.fill(0);
        this.a3358.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3158[i] = 0;
        this.a3258[i] = 0;
        this.a3358[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayShiori(this);
    }
    tickHook() {}
    parseCommand() {
        parseCommandShiori(this);
    }
    dispatchMoves() {
        dispatchMovesShiori(this);
    }
    think() {
        thinkShiori(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenShiori(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
