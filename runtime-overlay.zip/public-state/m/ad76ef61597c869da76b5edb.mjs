import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { readSync } from "./197efe2647ca25903d217eb5.mjs";
const STORAGE_PREFIX = "efz.rec.";
const REC_INTS = 8;
const REC_BYTES = 0x24;
function decode(bytes) {
    const rec = new Int32Array(REC_INTS);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for(let i = 0; i < REC_INTS && i * 4 + 4 <= bytes.length; i++)rec[i] = view.getInt32(i * 4, true);
    return rec;
}
export function readRec(name) {
    try {
        const saved = __session.storage.getItem(STORAGE_PREFIX + name);
        if (saved) return decode(Uint8Array.from(atob(saved), (c)=>c.charCodeAt(0)));
    } catch  {}
    const data = readSync(`system\\${name}\\${name}.rec`);
    return data ? decode(data) : new Int32Array(REC_INTS);
}
export function writeRec(name, rec) {
    const bytes = new Uint8Array(REC_BYTES);
    const view = new DataView(bytes.buffer);
    for(let i = 0; i < REC_INTS; i++)view.setInt32(i * 4, rec[i] ?? 0, true);
    try {
        __session.storage.setItem(STORAGE_PREFIX + name, btoa(String.fromCharCode(...bytes)));
    } catch  {}
}
