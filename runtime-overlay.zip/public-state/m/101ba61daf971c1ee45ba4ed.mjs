import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./f72d22da4bca50f9c6c4bb45.mjs";
import { angleOf, childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame, setPolarVelocity } from "./3a3de9c9ca972e4115fbd40f.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
function advance(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return true;
}
function finish(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function finishAir(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 9;
        c.onStateChange();
        if (c.f3458 > 0) {
            c.frame = 7;
            c.state = 0xb3;
        }
    }
}
function addMeter(c, v) {
    c.meter = s16(c.meter + v);
}
function dustEffect(c, d) {
    d.w04 = 0x1f;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 0;
    d.b21 = 0;
    d.d1c = c.facing === -1 ? 1 : 0;
    frameEffect(d);
}
function rfCostEffect(c, d) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    d.w04 = 0x21;
    d.b2c = 0xb;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 0x32;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
}
function spawnFront(c, d, pat, dx, dy) {
    d.w04 = pat;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.b21 = 1;
    d.d00 = 1;
    c.voiceRequest = 0xb;
    d.b18 = c.facing;
    frameChild(c, d);
}
function spawnQuad419(c, d) {
    d.w04 = 0x1a3;
    d.x = ftol(c.x) + c.facing * 0x3c;
    d.y = ftol(c.y) - 0x64;
    d.b18 = c.facing;
    d.b20 = 2;
    d.b21 = 1;
    frameChild(c, d);
    d.x = ftol(c.x) - c.facing * 0x3c;
    d.y = ftol(c.y) - 0x64;
    frameChild(c, d);
    d.x = ftol(c.x) + c.facing * 0x64;
    d.y = ftol(c.y) - 0x28;
    frameChild(c, d);
    d.x = ftol(c.x) - c.facing * 0x64;
    d.y = ftol(c.y) - 0x28;
    c.voiceRequest = 0xb;
    frameChild(c, d);
    addMeter(c, 0x2d);
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.w0dc = 4;
        c.b0de = 0xec;
        c.vx = 0.0;
        c.w16c = 1;
        c.backWindow = 0;
        c.freeze = 0x3c;
        d.w04 = 0x28;
        d.x = ftol(c.x) + c.facing * 0xa;
        d.y = ftol(c.y) - 0x28;
        d.b20 = 2;
        d.b21 = 1;
        d.b2c = 0x13;
        frameEffect(d);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (c.frame === 9 && c.timer === 0) dustEffect(c, d);
    if (c.frame === 9 && c.timer === 0) {
        spawnFront(c, d, 0x1a1, 0x19, 0x26);
        addMeter(c, 0x2d);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    finish(c, cnt);
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (c.frame === 9 && c.timer === 0) dustEffect(c, d);
    if (c.frame === 9 && c.timer === 0) {
        d.w04 = 0x1a2;
        d.x = ftol(c.x) + c.facing * 0x19;
        d.y = ftol(c.y) - 0x21;
        d.b20 = 2;
        c.voiceRequest = 0xb;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
        addMeter(c, 0x2d);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    finish(c, cnt);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) {
        c.startAfterimage(3);
        c.stopMotion();
        rfCostEffect(c, d);
        c.f3454 = 0;
    }
    if (c.frame === 5 && c.timer === 0) {
        d.w04 = 0x1f;
        d.b18 = c.facing;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 0;
        d.d1c = 1;
        frameEffect(d);
        d.w04 = 0x1f;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 0;
        d.d1c = 0;
        frameEffect(d);
    }
    if (c.frame === 5 && c.timer === 0) spawnQuad419(c, d);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 9 && c.f3138 < 5) {
        c.frame = c.frame - 3;
        c.f3138 = c.f3138 + 1;
    }
    finish(c, cnt);
}
function groundShot(c, pat, dx, guard) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        if (guard) rfCostEffect(c, d);
    }
    if (c.frame === 6 && c.timer === 0) {
        d.w04 = pat;
        d.x = ftol(c.x) + c.facing * dx;
        d.y = 0.0;
        d.b20 = 0;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
        addMeter(c, 0x2d);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    finish(c, cnt);
}
function spawnTriple(c, d, list) {
    list.forEach(([pat, dx, dy], k)=>{
        d.w04 = pat;
        d.x = ftol(c.x) + c.facing * dx;
        d.y = ftol(c.y) - dy;
        if (k === 0) {
            d.b20 = 0;
            d.b21 = 1;
            d.b18 = c.facing;
        }
        frameChild(c, d);
    });
    c.voiceRequest = 3;
    addMeter(c, 0xf);
}
function scatterState(c, first, second) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (c.frame === 4 && c.timer === 0) c.voiceRequest = 2;
    if (c.frame === 9 && c.timer === 0) spawnTriple(c, d, first);
    if (c.frame === 0xe && c.timer === 0) spawnTriple(c, d, second);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
        c.faceOpponent();
    }
}
function state256(c) {
    scatterState(c, [
        [
            0x1bc,
            0x1f,
            0x33
        ],
        [
            0x1bf,
            0x1a,
            0x1f
        ],
        [
            0x1be,
            0x15,
            0xb
        ]
    ], [
        [
            0x1bd,
            0xd,
            0x3a
        ],
        [
            0x1bf,
            0x12,
            0x26
        ],
        [
            0x1be,
            0x15,
            0x12
        ]
    ]);
}
function state257(c) {
    scatterState(c, [
        [
            0x1bc,
            0x1f,
            0x33
        ],
        [
            0x1bf,
            0x1a,
            0x1f
        ],
        [
            0x1be,
            0x15,
            0xb
        ]
    ], [
        [
            0x1c3,
            6,
            0x47
        ],
        [
            0x1c1,
            0x10,
            0x3d
        ],
        [
            0x1c0,
            0x1a,
            0x33
        ]
    ]);
}
function state258(c) {
    scatterState(c, [
        [
            0x1c3,
            6,
            0x47
        ],
        [
            0x1c2,
            0x10,
            0x3d
        ],
        [
            0x1c0,
            0x1a,
            0x33
        ]
    ], [
        [
            0x1c3,
            6,
            0x47
        ],
        [
            0x1c1,
            0x10,
            0x3d
        ],
        [
            0x1c0,
            0x1a,
            0x33
        ]
    ]);
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (!advance(c, dur)) return;
    if (c.frame === 1) c.d168 = 0;
    if (c.frame === 4 && c.timer === 0) {
        d.w04 = 0x1b5;
        d.x = ftol(c.x);
        d.y = 0.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        addMeter(c, 0x2d);
    }
    if (c.frame === 7 && c.f3138 < 4) {
        c.frame = c.frame - 3;
        c.f3138 = c.f3138 + 1;
    }
    finish(c, cnt);
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
        rfCostEffect(c, d);
    }
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 3;
    }
    if (c.frame === 5 && c.timer === 0 && c.f3138 < 2) {
        d.w04 = 0x1b5;
        const x = ftol(c.x);
        d.x = x + (c.random(0, 0x46) & 0xffff) - 0x23;
        d.y = 0.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        addMeter(c, 0x14);
    }
    if (!advance(c, dur)) return;
    if (c.frame === 7 && c.f3138 < 4) {
        c.frame = c.frame - 3;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame === 4 && c.f3138 < 2) c.d168 = 0;
    finish(c, cnt);
}
function airShotState(c, pat, dx, dy) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.frame === 7 && c.timer === 0) {
        spawnFront(c, d, pat, dx, dy);
        addMeter(c, 0x2d);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    finishAir(c, cnt);
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    if (atStart(c)) {
        c.startAfterimage(3);
        c.vx = 0.0;
        c.vy = 0.0;
        rfCostEffect(c, d);
        c.f3454 = 0;
    }
    if (c.frame === 5 && c.timer === 0) spawnQuad419(c, d);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 0xb && c.f3138 < 2) {
        c.frame = c.frame - 3;
        c.f3138 = c.f3138 + 1;
    }
    finishAir(c, cnt);
}
registerStates({
    249: state249,
    250: state250,
    251: state251,
    252: state252,
    253: (c)=>groundShot(c, 0x196, 0x3c, false),
    254: (c)=>groundShot(c, 0x196, 0xa0, false),
    255: (c)=>groundShot(c, 0x198, 0x3c, true),
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state259,
    261: state261,
    262: (c)=>airShotState(c, 0x1a1, 0x19, 0x26),
    263: (c)=>airShotState(c, 0x1a4, 0x19, 0x26),
    264: state264,
    265: (c)=>airShotState(c, 0x1cb, 0x26, 0x37)
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function childRelay(c, i, next) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 0;
    }
    if (ch.frame === 9 && ch.timer === 0 && ch.x > 0.0 && ch.x < 640.0) {
        const d = childSpawnFrame;
        d.w04 = next;
        d.x = ftol(ch.x) + ch.facing * 0x3c;
        d.y = 0.0;
        d.b20 = 0;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childRunner(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3148[i] === 0) {
        ch.vx = (c.random(0, 0x14) & 0xffff) * 0.01 + 0.7;
        ch.hitsLeft = 1;
        c.a3148[i] = c.a3148[i] + 1;
    }
    if (childAdvance(c, i)) {
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
    if (ch.x < -30.0 && ch.facing === -1 || ch.x > 670.0 && ch.facing === 1) c.freeChild(i);
}
function childCatchBody(c, i, is419) {
    const ch = c.children[i];
    const o = c.opponent;
    if (ch.hitState === 3 && ch.frame < 0x25) {
        ch.timer = 0;
        ch.frame = 0x25;
        ch.vx = 0.0;
        if (is419) {
            ch.vy = 0.0;
            c.f3454 = 1;
        }
        c.voiceRequest = 0xc;
        return false;
    }
    if (ch.hitState > 1 && ch.frame < 0x25) {
        ch.timer = 0;
        ch.frame = 0x28;
        ch.vx = 0.0;
        return false;
    }
    if (ch.frame === 0x25 && ch.hitState === 3) {
        o.stopMotion();
        o.onStateChange();
        o.state = 0x79;
        ch.hitState = 0;
    }
    if (!childAdvance(c, i)) return true;
    ch.hitState = 0;
    if (ch.frame === 0x25) {
        if (c.a3148[i] < 6) {
            ch.frame = 4;
            c.a3148[i] = c.a3148[i] + 1;
        } else {
            ch.vx = 0.0;
            ch.frame = 0x28;
        }
    }
    if (ch.frame >= childCount) {
        c.freeChild(i);
        if (o.state === 0x79) {
            o.onStateChange();
            o.stopMotion();
            o.y = -480.0;
            o.x = c.x;
            o.state = 0x3b;
        }
    }
    return true;
}
function childCatch(c, i, vx, vy) {
    const ch = c.children[i];
    if (ch.frame === 4 && ch.timer === 0) {
        ch.vx = vx;
        ch.vy = vy;
        ch.hitsLeft = 1;
    }
    childCatchBody(c, i, false);
}
function child419(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    if (ch.frame >= 4 && ch.frame < 0x25) {
        const ang = angleOf(o.x - ch.x, o.y - 50.0 - ch.y);
        c.a3348[i] = ftol(ang);
        setPolarVelocity(c, i, c.a3348[i], -0.00875);
        ch.ax = ch.vx;
        ch.ay = ch.vy;
        setPolarVelocity(c, i, c.a3348[i], 1.4);
        if (ch.facing === -1) {
            ch.ax = -ch.ax;
            ch.vx = -ch.vx;
        }
        ch.hitsLeft = 1;
    }
    if (!childCatchBody(c, i, true)) return;
    if (c.f3454 === 1 && ch.frame < 0x25) {
        ch.frame = 0x25;
        ch.timer = 0;
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
}
function child437(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 1;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childShard(c, i, angle) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        setPolarVelocity(c, i, angle, 3.6);
    }
    if (ch.hitState > 0 && ch.frame === 0) {
        ch.frame = 1;
        ch.timer = 0;
        ch.vx = -0.9;
        ch.vy = -2.7;
        return;
    }
    if (ch.frame > 0) ch.vy = ch.vy + 0.045;
    if (ch.y + ch.vy > 0.0) {
        ch.y = 0.0;
        ch.vy = -0.5 * ch.vy;
        if (ch.blend === 0) {
            ch.blend = 1;
        } else {
            c.freeChild(i);
            return;
        }
    }
    if (childAdvance(c, i)) {
        if (ch.frame === 1) ch.frame = ch.frame - 1;
        if (ch.frame >= childCount) ch.frame = 1;
    }
    if (ch.x < -30.0 || ch.x > 670.0 || ch.y < -510.0) c.freeChild(i);
}
function child459(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 0x63;
        c.voiceRequest = 0xd;
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.hitState = 0;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    408: (c, i)=>childRelay(c, i, 0x199),
    409: (c, i)=>childRelay(c, i, 0x19a),
    410: (c, i)=>childRelay(c, i, 0x198),
    411: childRunner,
    412: childRunner,
    413: childRunner,
    414: childRunner,
    415: childRunner,
    416: childRunner,
    417: (c, i)=>childCatch(c, i, 0.5, 0.0),
    418: (c, i)=>childCatch(c, i, 0.35, -0.35),
    419: child419,
    420: (c, i)=>childCatch(c, i, 0.35, 0.35),
    437: child437,
    444: (c, i)=>childShard(c, i, 0.0),
    445: (c, i)=>childShard(c, i, 0.0),
    446: (c, i)=>childShard(c, i, 0.0),
    447: (c, i)=>childShard(c, i, 0.0),
    448: (c, i)=>childShard(c, i, -35.0),
    449: (c, i)=>childShard(c, i, -60.0),
    450: (c, i)=>childShard(c, i, -60.0),
    451: (c, i)=>childShard(c, i, -85.0),
    459: child459
});
