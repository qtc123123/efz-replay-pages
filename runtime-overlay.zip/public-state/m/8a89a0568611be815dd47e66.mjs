import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { registerChildren, registerStates } from "./1f5919024557a92ec3a28767.mjs";
import { childCount, childDuration, frameChild, frameEffect, openSpawnFrame } from "./6bb9439be7e0aefdefc21b73.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
export function tickHookExNanase(c) {
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.f3454 === 0 && c.meter === 0xbb8 && c.life < 0x682 && c.life > 0 && o.life > 0 && o.wins + 1 === gs.winRounds && c.wins + 1 === gs.winRounds && c.y === 0.0 && c.state < 8 && c.state !== 0x140) {
        c.onStateChange();
        c.stopMotion();
        c.state = 0x140;
    }
    if (c.f3454 !== 1) return;
    c.meter = s16(c.meter + 1);
    c.startAfterimage(1);
    c.f3150--;
    c.f314c++;
    if (c.f314c > 0x90) c.f314c = 0;
    if (c.f314c === 0x12) c.requestFlash(0xd1, 0x1b);
    if (c.f314c === 0x24) c.requestFlash(0xd0, 0x1b);
    if (c.f314c === 0x36) c.requestFlash(0xcf, 0x1b);
    if (c.f314c === 0x48) c.requestFlash(0xb1, 0x1b);
    if (c.f314c === 0x5a) c.requestFlash(0xcf, 0x1b);
    if (c.f314c === 0x6c) c.requestFlash(0xd0, 0x1b);
    if (c.f314c === 0x7e) c.requestFlash(0xd1, 0x1b);
    if (c.f314c === 0x90) c.requestFlash(0xd2, 0x1b);
    if (c.f3150 > 0) return;
    if (c.state >= 0x32 && c.state <= 0x95) return;
    d.w04 = 0x22;
    d.x = ftol(c.x) + (0x14 - (c.random(0, 0x28) & 0xffff)) * c.facing;
    d.y = ftol(c.y) - (c.random(0, 0x5a) & 0xffff);
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    c.f3150 = 2;
}
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function stepFrame(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    return true;
}
function endToNeutral(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function superFreeze(c, cost, darken = 3) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, darken);
}
function superEffect(d, c, pat, sound, offX, offY) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) + c.facing * offX;
    d.y = ftol(c.y) - offY;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function readOpponentButton(c) {
    const o = c.opponent;
    if (c.frame < 0xa && c.f3138 === 0) {
        if (o.pressed[0] === 1) c.f3138 = 1;
        if (o.pressed[1] === 1) c.f3138 = 2;
        if (o.pressed[2] === 1) c.f3138 = 3;
    }
}
function counterThrow(c, clearHitstop) {
    const o = c.opponent;
    c.onStateChange();
    c.state = 0x102;
    c.seRequest = 0x1a;
    o.state = 0x9e;
    if (clearHitstop) o.hitstop = 0;
    o.onStateChange();
    o.stopMotion();
}
function holdOpponent(c, dx, y, st) {
    const o = c.opponent;
    o.x = c.facing * dx + c.x;
    o.y = y;
    o.state = st;
}
function grabFinish(c, d, dx, p) {
    const o = c.opponent;
    d.w04 = p.child ?? 0x198;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - 0x57;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
    o.state = 0x3f;
    o.onStateChange();
    o.stopMotion();
    o.knockX = p.knockX;
    o.knockY = -2.0;
    o.x = c.facing * 0x1e + c.x;
    o.y = -40.0;
    c.shakeScreen(p.shakeAmp, p.shakeHold);
    applyDirectDamage(c, p.damage, 850.0);
    c.voiceRequest = 2;
    c.w140 = 0;
    if (p.clearHitstop) o.hitstop = 0;
    c.superDarken(0xb0, 0);
}
function chargeChildren(c, d, frame) {
    if (c.frame === frame && c.timer === 0xb4) {
        d.w04 = 0x19a;
        d.x = ftol(c.x) + c.facing * 0x25;
        d.y = ftol(c.y) - 0x57;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = 1;
        frameChild(c, d);
        c.voiceRequest = 4;
    }
    if (c.frame === frame) {
        const t = c.timer;
        if (t === 0x10e || t === 0x13b || t === 0x168 || t === 0x186 || t === 0x1a4 || t === 0x1c2 || t === 0x1d1 || t === 0x1e0) {
            d.w04 = 0x199;
            d.x = ftol(c.x) + ((c.random(0, 0x50) & 0xffff) + 7) * c.facing;
            d.y = ftol(c.y) - 0x39 - (c.random(0, 0x50) & 0xffff);
            d.b20 = 2;
            d.d00 = 1;
            d.b21 = 1;
            d.b18 = 1;
            frameChild(c, d);
            c.voiceRequest = 3;
        }
    }
}
function state300(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
        c.f3138 = 0;
    }
    if (o.state === 0x63) o.timer = 0;
    readOpponentButton(c);
    c.biasCameraY(0x32, 3);
    if (atFrame(c, 1)) {
        superFreeze(c, 0x3e8);
        superEffect(d, c, 0x44, 0x13, 0xf, 0x38);
    }
    if (c.frame < 0xe) c.w140 = 3;
    const f = c.frame;
    if ((f === 2 || f === 5 || f === 8 || f === 0xb || f === 0xe) && c.timer === 0) {
        c.seRequest = 2;
        d.w04 = 0;
        d.x = ftol(c.x);
        d.y = ftol(c.y) + 7;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        if (c.frame === 2 || c.frame === 5 || c.frame === 8 || c.frame === 0xb) {
            applyDirectDamage(c, 0x32, 1000.0);
            c.shakeScreen(2, 2);
        }
        if (c.frame === 0xe) {
            applyDirectDamage(c, 0x1f4, 1000.0);
            c.shakeScreen(0xa, 0xa);
            c.w140 = 0;
        }
    }
    if (c.frame > 1 && c.frame < 8 && (c.command === 0x64 || c.command === 0x6e) && c.meter >= 0x3e8) {
        if (c.f3138 === 3) {
            counterThrow(c, false);
            return;
        }
        c.onStateChange();
        c.state = 0x12e;
        return;
    }
    if (c.frame > 1 && c.frame < 8 && (c.command === 0x65 || c.command === 0x6f) && c.meter >= 0x3e8) {
        if (c.f3138 === 2) {
            counterThrow(c, false);
            return;
        }
        c.onStateChange();
        c.state = 0x133;
        c.facing = -c.facing;
        return;
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 8 && c.f313c < 0xa) {
        c.f313c++;
        c.frame = 2;
    }
    endToNeutral(c, cnt);
}
function state301(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        if (c.f3138 === 1) {
            counterThrow(c, false);
            return;
        }
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
    }
    if (o.state === 0x63) o.timer = 0;
    c.biasCameraY(0x32, 3);
    if (atFrame(c, 2)) {
        superFreeze(c, 0x7d0);
        superEffect(d, c, 9, 5, -6, 0x24);
    }
    if (atFrame(c, 5)) {
        applyDirectDamage(c, 0x960, 600.0);
        c.shakeScreen(5, 5);
        o.state = 0x3f;
        o.onStateChange();
        o.stopMotion();
        o.knockX = -3.0;
        o.knockY = -8.0;
        c.voiceRequest = 2;
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function state302(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame < 7) c.w140 = 3;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.biasCameraY(0x32, 3);
    if (c.frame === 6 && c.timer === 0x3c) {
        superFreeze(c, 0x3e8, 0x708);
        superEffect(d, c, 0x46, 0x40, 0x25, 0x57);
    }
    chargeChildren(c, d, 6);
    if (!stepFrame(c, dur)) return;
    if (c.frame === 3) {
        o.facing = -c.facing;
        holdOpponent(c, 0x2e, -38.0, 0x67);
        o.onStateChange();
    }
    if (c.frame === 4) {
        holdOpponent(c, 0x31, -56.0, 0x67);
        o.onStateChange();
    }
    if (c.frame === 5) {
        holdOpponent(c, 0x28, -93.0, 0x65);
        o.onStateChange();
    }
    if (c.frame === 6) {
        holdOpponent(c, 0x25, -87.0, 0x65);
        o.onStateChange();
    }
    if (c.frame === 7) {
        grabFinish(c, d, 0x25, {
            knockX: -6.0,
            shakeAmp: 0x14,
            shakeHold: 0xa,
            damage: 0x1068,
            clearHitstop: false
        });
    }
    endToNeutral(c, cnt);
}
function state314(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame < 4) c.superDarken(0xb0, 3);
    chargeChildren(c, d, 3);
    c.biasCameraY(0x32, 3);
    if (!stepFrame(c, dur)) return;
    if (c.frame === 1) holdOpponent(c, 0x1c, -56.0, 0x67);
    if (c.frame === 2) holdOpponent(c, 0x28, -93.0, 0x65);
    if (c.frame === 3) holdOpponent(c, 0x10, -92.0, 0x65);
    if (c.frame === 4) {
        grabFinish(c, d, 0xc, {
            knockX: -4.0,
            shakeAmp: 0x14,
            shakeHold: 0xa,
            damage: 0x1324,
            clearHitstop: true
        });
    }
    endToNeutral(c, cnt);
}
function rushSuper(c, cost, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (atFrame(c, 4)) {
        c.biasCameraY(0x32, 0x78);
        superFreeze(c, cost);
        superEffect(d, c, 9, 5, 0x13, 0x22);
        if (big) c.seRequest = 0x25;
    }
    if (big) {
        if (c.frame >= 4) c.showAltBackground(0xf);
    } else if (c.frame >= 1) {
        c.wF2 = 0xa;
    }
    if (atFrame(c, 5)) c.vx = 6.0;
    if (c.frame > 8) {
        c.vx = c.vx - 0.2;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.d168 === 3) c.shakeScreen(0xa, 0);
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function state306(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
        c.f3138 = 0;
    }
    readOpponentButton(c);
    if (o.state === 0x63 && c.frame < 9) o.timer = 0;
    c.biasCameraY(0x32, 3);
    if (atFrame(c, 1)) {
        superFreeze(c, 0x3e8);
        superEffect(d, c, 0x44, 0x13, 0xf, 0x38);
    }
    if (atFrame(c, 4)) {
        applyDirectDamage(c, 0x708, 1000.0);
        c.shakeScreen(0xa, 0xa);
        o.hitstop = 0xb4;
        c.seRequest = 0x16;
        d.w04 = 0x197;
        d.x = ftol(c.x) + c.facing * 0xf;
        d.y = ftol(c.y) + 8;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.frame === 8 && (c.command === 0x64 || c.command === 0x6e) && c.meter >= 0x3e8) {
        if (c.f3138 === 3) {
            counterThrow(c, true);
            return;
        }
        c.onStateChange();
        c.state = 0x13e;
        return;
    }
    if (c.frame === 8 && (c.command === 0x65 || c.command === 0x6f) && c.meter >= 0x3e8) {
        if (c.f3138 === 2) {
            counterThrow(c, true);
            return;
        }
        c.onStateChange();
        c.state = 0x13f;
        c.faceOpponent();
        return;
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function state307(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (o.state === 0x63 && c.frame < 9) o.timer = 0;
    if (c.frame < 4 && c.vy > 0.0) {
        c.timer = 0;
        c.frame = 4;
    }
    if (c.y < 0.0 && c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.frame === 4 && c.freeze === 0 && c.f3138 === 1) {
        c.vy = 10.0;
        c.f3138++;
    }
    if (c.frame === 4 && c.vy > 0.0 && c.y > -90.0 && c.f3138 === 0) {
        c.f3138++;
        c.vy = 0.0;
        superFreeze(c, 0x3e8, 0x708);
        superEffect(d, c, 0x46, 0x40, -0x19, 0x3c);
    }
    if (c.frame === 4 && c.y + c.vy > 0.0) {
        c.stopMotion();
        c.timer = 0;
        c.frame = 5;
        c.y = 0.0;
        applyDirectDamage(c, 0x1194, 1000.0);
        c.shakeScreen(0xa, 0xa);
        o.hitstop = 0x12c;
        c.seRequest = 0x16;
        d.w04 = 0x19b;
        d.x = ftol(c.x) + c.facing * 0x11;
        d.y = ftol(c.y) + 0xb;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    c.biasCameraY(-0x32, 3);
    if (!stepFrame(c, dur)) return;
    if (c.frame === 2) {
        c.vy = -10.0;
        c.ay = 0.045;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
        c.superDarken(0xb0, 0);
    }
}
function dashGrab(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
        c.b158 = 0;
        superFreeze(c, p.cost);
        superEffect(d, c, p.pat, p.sound, 0, 0x55);
        if (p.big) c.seRequest = 0x25;
    }
    if (c.frame > 0xa) c.vx = c.vx - 0.015;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame < 0xa && c.frame > 5) {
        if (o.x - c.x < 80.0 && c.facing === 1 || c.x - o.x < 80.0 && c.facing === -1) {
            c.timer = 0;
            c.frame = 0xa;
            return;
        }
    }
    if (c.d168 === 3 && c.frame === 0xc) {
        o.hitstop = s16(o.hitstop + 0x708);
        c.stopMotion();
        c.biasCameraY(0x32, 3);
        c.d168 = 0;
        o.facing = -c.facing;
        o.x = c.facing * 0x18 + c.x;
        o.y = -40.0;
        o.state = 0x67;
        o.onStateChange();
        o.stopMotion();
        o.d128 = 1;
        c.onStateChange();
        c.state = p.next;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x45;
        d.y = ftol(c.y) - 0x23;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (p.big) c.showAltBackground(0xf);
    if (!stepFrame(c, dur)) return;
    if (c.frame === 6) c.vx = p.speed;
    if (c.frame === 0xa && c.f3138 < p.loops) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function grabSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.biasCameraY(0x32, 3);
    if (!stepFrame(c, dur)) return;
    if (c.frame === 1) holdOpponent(c, 0x1c, -56.0, 0x67);
    if (c.frame === 2) holdOpponent(c, 0x28, -93.0, 0x65);
    if (c.frame === 3) holdOpponent(c, 0x10, -92.0, 0x65);
    if (c.frame === 4) grabFinish(c, d, 0xc, p);
    endToNeutral(c, cnt);
}
function pillarSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.biasCameraY(0x32, 3);
    if (atFrame(c, 1)) {
        superFreeze(c, p.cost);
        superEffect(d, c, p.pat, p.sound, -6, 0x2d);
    }
    if (p.altBg && c.frame > 0) c.showAltBackground(0xf);
    if (c.frame === 5 && p.times.includes(c.timer)) {
        c.shakeScreen(5, 0);
        c.seRequest = 0x16;
        const off = (c.timer + 0x3c) * c.facing;
        d.w04 = p.child;
        d.x = ftol(c.x) + off;
        if (off + c.x > 620.0) d.x = 620.0;
        if (off + c.x < 20.0) d.x = 20.0;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        d.w04 = 0x19f;
        d.d00 = 1;
        d.b21 = 0;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (p.launch && c.frame === 5 && c.timer === 0xf) {
        o.state = 0x3f;
        o.frame = 0;
        o.timer = 0;
        o.y = -2.0;
        o.knockY = -1.0;
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function state318(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.biasCameraY(0x32, 3);
    if (atFrame(c, 3)) {
        superFreeze(c, 0x3e8);
        superEffect(d, c, 0x46, 0x40, -0x17, 0x39);
    }
    if (c.frame > 2) c.showAltBackground(0xf);
    if (c.frame > 4 && c.frame < 0xb) {
        o.state = 0x63;
        o.frame = 0;
        o.timer = 0;
        o.y = 0.0;
        o.x = c.facing * 0x28 + c.x;
        if (c.x > 610.0 || c.x < 30.0) {
            o.state = 0x3f;
            o.onStateChange();
            o.stopMotion();
            o.knockX = -6.0;
            o.knockY = -3.5;
            o.y = -5.0;
            c.shakeScreen(0x14, 0xa);
            applyDirectDamage(c, 0xbb8, 1000.0);
            c.voiceRequest = 2;
            c.frame = 0xb;
            c.timer = 0;
            c.vx = -6.0;
            c.vy = -3.5;
            d.w04 = 0x198;
            d.x = ftol(c.x) + c.facing * 0x28;
            d.y = ftol(c.y) - 0xb;
            d.b20 = 2;
            d.d00 = 1;
            d.b21 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
        }
    }
    if ((c.frame === 6 || c.frame === 8 || c.frame === 0xa) && c.timer === 0) {
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x3c;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b2c = 2;
        frameEffect(d);
        applyDirectDamage(c, 0x50, 1000.0);
    }
    if (c.y < 0.0) {
        c.vy = c.vy + 0.035;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.onStateChange();
            c.state = 0x62;
            return;
        }
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 5) {
        c.vx = 3.5;
        d.w04 = 0x1a0;
        d.x = ftol(c.x) + c.facing * 0x50;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.frame === 0xb) {
        c.frame -= 6;
        d.w04 = 0x1a1;
        d.x = ftol(c.x) + c.facing * 0x28;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.frame >= cnt) c.frame -= 2;
}
function state320(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (c.frame < 4) c.f3138--;
    if (atStart(c)) {
        c.f3454 = 1;
        c.f3138 = 0x42;
        c.biasCameraY(0x32, 0x78);
        c.freeze = 0xb4;
        c.superDarken(0xb0, 3);
        superEffect(d, c, 0x46, 0x40, 7, 0x35);
        c.seRequest = 0x25;
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
registerStates({
    300: state300,
    301: state301,
    302: state302,
    303: (c)=>rushSuper(c, 0x3e8, false),
    304: (c)=>rushSuper(c, 0x7d0, false),
    305: (c)=>rushSuper(c, 0xbb8, true),
    306: state306,
    307: state307,
    309: (c)=>dashGrab(c, {
            cost: 0x3e8,
            pat: 0x44,
            sound: 0x13,
            big: false,
            speed: 1.3,
            loops: 2,
            next: 0x136
        }),
    310: (c)=>grabSuper(c, {
            knockX: -4.0,
            shakeAmp: 0xa,
            shakeHold: 5,
            damage: 0x8fc,
            clearHitstop: true,
            child: 0x190
        }),
    311: (c)=>dashGrab(c, {
            cost: 0x7d0,
            pat: 0x45,
            sound: 5,
            big: false,
            speed: 1.7,
            loops: 4,
            next: 0x138
        }),
    312: (c)=>grabSuper(c, {
            knockX: -4.0,
            shakeAmp: 0xf,
            shakeHold: 0xa,
            damage: 0xce4,
            clearHitstop: true
        }),
    313: (c)=>dashGrab(c, {
            cost: 0xbb8,
            pat: 0x46,
            sound: 0x40,
            big: true,
            speed: 2.1,
            loops: 6,
            next: 0x13a
        }),
    314: state314,
    315: (c)=>pillarSuper(c, {
            cost: 0x3e8,
            pat: 0x44,
            sound: 0x13,
            altBg: false,
            times: [
                0
            ],
            child: 0x19c,
            launch: false
        }),
    316: (c)=>pillarSuper(c, {
            cost: 0x7d0,
            pat: 0x45,
            sound: 5,
            altBg: false,
            times: [
                0,
                0x3c
            ],
            child: 0x19d,
            launch: false
        }),
    317: (c)=>pillarSuper(c, {
            cost: 0xbb8,
            pat: 0x46,
            sound: 0x40,
            altBg: true,
            times: [
                0,
                0x3c,
                0x78
            ],
            child: 0x19e,
            launch: false
        }),
    318: state318,
    319: (c)=>pillarSuper(c, {
            cost: 0x3e8,
            pat: 0x46,
            sound: 0x40,
            altBg: true,
            times: [
                0,
                0x3c,
                0x78
            ],
            child: 0x1a2,
            launch: true
        }),
    320: state320
});
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    if (childStep(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function childHoldLast(c, i) {
    const ch = c.children[i];
    if (childStep(c, i) && ch.frame >= childCount) ch.frame--;
}
function child408(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) c.f3148 = 1;
    if (childStep(c, i) && ch.frame >= childCount) {
        c.freeChild(i);
        c.f3148 = 0;
    }
}
function child409(c, i) {
    if (c.f3148 > 0) {
        c.freeChild(i);
        return;
    }
    childHoldLast(c, i);
}
function childPillar(c, i) {
    const ch = c.children[i];
    if (ch.frame === 1) ch.hitsLeft = 1;
    childOnce(c, i);
}
function child416(c, i) {
    const ch = c.children[i];
    ch.x = c.facing * 0x50 + c.x;
    if (c.state !== 0x13e || c.frame > 0xa) c.freeChild(i);
    if (childStep(c, i) && ch.frame >= childCount) ch.frame = 5;
}
registerChildren({
    408: child408,
    409: child409,
    410: child409,
    411: childOnce,
    412: childPillar,
    413: childPillar,
    414: childPillar,
    415: childOnce,
    416: child416,
    417: childOnce,
    418: childPillar
});
