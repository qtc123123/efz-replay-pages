import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { gameState as gs, setBgmRamp } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./c2c7a57dacaa46758b7f3f58.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./7b1ab9c36f2b6b5ca7dcee6a.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
const LEVEL_PAT = [
    0x44,
    0x45,
    0x46
];
const LEVEL_SOUND = [
    0x13,
    5,
    0x40
];
function superFreeze(c, level) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - (level + 1) * 1000);
    c.superDarken(0xb0, 3);
}
function superEffect(c, d, level, dy) {
    d.w04 = LEVEL_PAT[level];
    d.b2c = LEVEL_SOUND[level];
    d.x = ftol(c.x);
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function stopVelocity(c) {
    c.vx = 0.0;
    c.vy = 0.0;
}
function burstSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        stopVelocity(c);
        c.w16c = 1;
        d.w04 = p.lead;
        d.d28 = 1;
        d.x = c.x - c.facing * 0x168;
        d.y = 0.0;
        d.b18 = c.facing;
        d.b20 = 0;
        d.b21 = 1;
        d.d00 = 1;
        frameChild(c, d);
        c.voiceRequest = 9;
    }
    if (c.frame < 3) c.biasCameraY(0x19, 0xa);
    if (p.level === 2 && c.frame > 4) c.showAltBackground(0xf);
    if (atFrame(c, 4)) {
        c.f3138 = 0;
        superFreeze(c, p.level);
        superEffect(c, d, p.level, 0x42);
        if (p.level === 2) c.seRequest = 0x25;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (atFrame(c, 7)) {
        c.voiceRequest = 0xc;
        c.shakeScreen(7, 0xa);
        d.x = ftol(c.x) + c.facing * p.dx;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 1;
        for (const [pat, n] of p.spawns){
            d.w04 = pat;
            for(let k = 0; k < n; k++)frameChild(c, d);
        }
    }
    if (atFrame(c, 0xa) && c.f3138 < 6) {
        c.f3138++;
        c.frame -= 2;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function grabSuper(c, level, next) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        stopVelocity(c);
        c.w16c = 1;
    }
    if (c.frame < 3) c.biasCameraY(0x19, 0xa);
    if (level === 2 && c.frame > 1) c.showAltBackground(0xf);
    if (atStart(c)) {
        superFreeze(c, level);
        superEffect(c, d, level, 0x42);
        if (level === 2) c.seRequest = 0x25;
    }
    if (c.frame === 5 && c.d168 === 3) {
        c.onStateChange();
        c.stopMotion();
        c.state = next;
        c.opponent.hitstop = 0x1c2;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function grabHit(c, level) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        stopVelocity(c);
        c.voiceRequest = 0x13;
    }
    if (level === 2 && c.frame < 2) c.showAltBackground(0xf);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (atFrame(c, 1)) {
        c.shakeScreen(5, 5);
        o.onStateChange();
        o.state = 0x3f;
        o.knockX = -3.5;
        o.knockY = -1.5;
        o.ay = 0.035;
        applyDirectDamage(c, 0x3e8, 500.0);
        o.d128 = 1;
        d.w04 = 0x34;
        c.seRequest = 0x16;
        d.x = ftol(c.x) + c.facing * 0x28;
        d.y = ftol(c.y) - 0x46;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        o.d15c = level + 1;
        c.f3148 = 0x3e8;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function stopSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.stopMotion();
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 6 && c.f3138 < p.loopA) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame === p.fireFrame) {
        superFreeze(c, p.level);
        superEffect(c, d, p.level, 0x32);
        if (p.level === 2) {
            c.f3138 = 0;
            c.seRequest = 0x25;
            setBgmRamp(-10000, 0x64);
        } else {
            setBgmRamp(-10000, 0x64);
            c.f3138 = 0;
        }
    }
    if (c.frame === 8 && c.f3138 < p.loopB) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame === 8) c.d160 = p.level + 1;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state318(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 6) c.showAltBackground(0xf);
    if (c.frame > 5) c.biasCameraY(0x32, 3);
    if (c.frame === 0xa && c.d168 === 3) {
        c.onStateChange();
        c.state = 0x13f;
        o.onStateChange();
        o.state = 0x79;
        c.superDarken(0xb0, 0x1770);
        setBgmRamp(-10000, 0x3e8);
        gs.specialTimerE = 0x7530;
        gs.specialTimerE = 0x7530;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 6) {
        c.x = c.facing * 0x28 + o.x;
        c.facing = -c.facing;
        c.freeze = 0x96;
        c.meter = s16(c.meter - 0xbb8);
        c.superDarken(0xb0, 0xa);
        d.w04 = 0x46;
        d.b2c = 0x40;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x3f;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (c.frame === 0xa) {
        if (o.y === 0.0) c.w16c = 1;
        else c.w16c = 0;
    }
    if (c.frame >= cnt) {
        c.faceOpponent();
        c.onStateChange();
        c.state = 0;
    }
}
function state319(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.showAltBackground(0);
        if (c.x > 450.0 && c.facing === 1) c.x = 450.0;
        if (c.x < 190.0 && c.facing === -1) c.x = 190.0;
        o.x = c.facing * 0x3c + c.x;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.f3138 = 0;
    }
    if (c.frame > 2) o.timer = 0;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (atFrame(c, 1)) {
        c.superDarken(0xb0, 0);
        o.onStateChange();
        o.state = 0x7b;
        o.facing = c.facing;
        d.w04 = 0x1a9;
        d.x = ftol(c.x) + c.facing * 0x3c;
        d.y = ftol(c.y);
        d.b18 = c.facing;
        d.b20 = 0;
        d.d00 = 1;
        d.b21 = 0;
        frameChild(c, d);
        c.voiceRequest = 0x11;
    }
    if (c.frame === 2) {
        gs.specialTimerE = 0x7530;
        gs.specialTimerE = 0x7530;
        gs.specialTimerC = 0x7530;
        o.onStateChange();
        o.state = 0x79;
        d.w04 = 0x1aa;
        d.x = 0.0;
        d.y = 0.0;
        d.b20 = 0;
        d.b21 = 1;
        d.d00 = 1;
        d.d28 = 0;
        d.b18 = 1;
        d.d24 = 1;
        frameChild(c, d);
        c.voiceRequest = 0x10;
    }
    if (c.frame === 3) {
        gs.specialTimerE = 0;
        gs.specialTimerE = 0;
        gs.specialTimerC = 0;
        c.voiceRequest = 0xe;
        applyDirectDamage(c, 0x157c, 1000.0);
        o.onStateChange();
        o.state = 0x63;
    }
    if (c.frame === 5 && c.f3138 < 0x14) {
        c.f3138++;
        c.frame = 3;
    }
    if (c.frame === 5) {
        if (!(o.life <= 0 && c.wins === gs.winRounds)) setBgmRamp(0, 0x3e8);
    }
    if (c.frame >= cnt) {
        c.faceOpponent();
        c.onStateChange();
        c.state = 0;
    }
}
registerStates({
    300: (c)=>burstSuper(c, {
            level: 0,
            lead: 0x1a6,
            dx: 0x6e,
            spawns: [
                [
                    0x1ad,
                    3
                ],
                [
                    0x1af,
                    3
                ],
                [
                    0x1ae,
                    5
                ]
            ]
        }),
    301: (c)=>burstSuper(c, {
            level: 1,
            lead: 0x1ab,
            dx: 0x82,
            spawns: [
                [
                    0x1ad,
                    5
                ],
                [
                    0x1af,
                    5
                ],
                [
                    0x1b0,
                    5
                ]
            ]
        }),
    302: (c)=>burstSuper(c, {
            level: 2,
            lead: 0x1ac,
            dx: 0xc8,
            spawns: [
                [
                    0x1ad,
                    7
                ],
                [
                    0x1af,
                    3
                ],
                [
                    0x1b0,
                    5
                ],
                [
                    0x1b1,
                    3
                ]
            ]
        }),
    303: (c)=>grabSuper(c, 0, 0x130),
    304: (c)=>grabHit(c, 0),
    305: (c)=>grabSuper(c, 1, 0x132),
    306: (c)=>grabHit(c, 1),
    307: (c)=>grabSuper(c, 2, 0x134),
    308: (c)=>grabHit(c, 2),
    309: (c)=>stopSuper(c, {
            level: 0,
            loopA: 2,
            fireFrame: 6,
            loopB: 3
        }),
    310: (c)=>stopSuper(c, {
            level: 1,
            loopA: 0,
            fireFrame: 6,
            loopB: 3
        }),
    311: (c)=>stopSuper(c, {
            level: 2,
            loopA: 0,
            fireFrame: 2,
            loopB: 1
        }),
    318: state318,
    319: state319
});
function childStep(c, i, resetHit) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    if (resetHit) ch.hitState = 0;
    return true;
}
function childOnce(c, i, resetHit) {
    if (childStep(c, i, resetHit) && c.children[i].frame >= childCount) c.freeChild(i);
}
function childStill(c, i) {
    const ch = c.children[i];
    ch.vx = 0.0;
    ch.vy = 0.0;
    childOnce(c, i, true);
}
function child409(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    childOnce(c, i, true);
}
function child410(c, i) {
    const ch = c.children[i];
    ch.hitsLeft = 1;
    if (ch.frame === 0 && ch.timer === 0) c.voiceRequest = 3;
    childOnce(c, i, true);
}
function childLead(c, i, state) {
    const ch = c.children[i];
    ch.vx = 5.0;
    if (ch.frame === 0 && ch.timer === 0) c.a3164[i] = 0;
    if (c.state !== state) c.a3164[i] = 1;
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 1 && ch.timer === 0 && c.a3164[i] === 0) {
        c.freeChild(i);
        return;
    }
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child319Fx(c, i, lastFrame) {
    const ch = c.children[i];
    ch.drawWhileFrozen = 3;
    ch.timer++;
    if (c.state === 0x13f && c.frame > lastFrame) {
        c.freeChild(i);
        return;
    }
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = 0;
}
const DEG = 57.29579143313326;
function setPolarVelocity(c, i, angle, speed) {
    const ch = c.children[i];
    ch.vx = __numerics.cos(angle / DEG) * speed;
    ch.vy = __numerics.sin(angle / DEG) * speed;
}
function sprayMove(c, i, p) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        const a = c.random(0, p.angleMax) & 0xffff;
        c.a3164[i] = p.neg ? -a : a;
        c.a3264[i] = (c.random(0, p.speedRange) & 0xffff) + p.speedBase;
        c.a3364[i] = 0;
    }
    setPolarVelocity(c, i, c.a3164[i], c.a3264[i] * 0.1);
    c.a3264[i] = c.a3264[i] - 1;
    if (c.a3264[i] <= p.speedMin) c.a3264[i] = p.speedMin;
}
function childSpray(c, i, p) {
    sprayMove(c, i, p);
    childOnce(c, i, false);
}
function childSprayBurst(c, i, p, loops, pat) {
    const ch = c.children[i];
    sprayMove(c, i, p);
    if (!childStep(c, i, false)) return;
    if (ch.frame < childCount) return;
    if (c.a3364[i] < loops) {
        c.a3364[i] = c.a3364[i] + 1;
        ch.frame--;
        const d = childSpawnFrame;
        d.w04 = pat;
        d.x = ch.x;
        d.y = ch.y;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
        return;
    }
    c.freeChild(i);
}
const SPRAY_429 = {
    angleMax: 0xb4,
    neg: true,
    speedRange: 0x14,
    speedBase: 0x1e,
    speedMin: 5
};
const SPRAY_431 = {
    angleMax: 0x168,
    neg: false,
    speedRange: 0xf,
    speedBase: 0x1e,
    speedMin: 5
};
const SPRAY_430 = {
    angleMax: 0x168,
    neg: false,
    speedRange: 0x28,
    speedBase: 0x32,
    speedMin: 0
};
const SPRAY_432 = {
    angleMax: 0xb4,
    neg: true,
    speedRange: 0x14,
    speedBase: 0x46,
    speedMin: 0
};
registerChildren({
    401: childStill,
    405: childStill,
    409: child409,
    410: child410,
    422: (c, i)=>childLead(c, i, 0x12c),
    425: (c, i)=>child319Fx(c, i, 1),
    426: (c, i)=>child319Fx(c, i, 2),
    427: (c, i)=>childLead(c, i, 0x12d),
    428: (c, i)=>childLead(c, i, 0x12e),
    429: (c, i)=>childSpray(c, i, SPRAY_429),
    430: (c, i)=>childSprayBurst(c, i, SPRAY_430, 6, 0x191),
    431: (c, i)=>childSpray(c, i, SPRAY_431),
    432: (c, i)=>childSprayBurst(c, i, SPRAY_432, 0xa, 0x191),
    433: (c, i)=>childSprayBurst(c, i, SPRAY_432, 7, 0x195),
    434: (c, i)=>childSpray(c, i, SPRAY_431)
});
function patFrame(c, pattern, frame) {
    return c.patterns[pattern]?.frames[frame];
}
function drawPart(c, f, x, y, w) {
    if (!f) return;
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    blit(makeRect(x, y, w, f.height), surf, makeRect(0, 0, w, f.height), c.colorKey, false);
}
function drawDigit(c, digit, x1, x2) {
    let f = patFrame(c, 40, digit);
    if (c.f3160 > 0) f = patFrame(c, 40, 10);
    if (!f) return;
    drawPart(c, f, (c.side === 0 ? x1 : x2) - f.offsetX, 0xc5 - f.offsetY, f.width);
}
export function renderOverlayAkiko(c) {
    let f;
    if (c.f3148 > 0) {
        f = patFrame(c, 43, 0);
        if (f) drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - f.width, 0x1f - f.offsetY, f.width);
    }
    if (c.f3148 > 0) {
        f = patFrame(c, 44, 0);
        if (f) {
            const w = Math.trunc(Math.imul(f.width, c.f3148) / 0x3e8);
            drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - w, 0x1f - f.offsetY, w);
        }
    }
    if (c.d160 <= 0) return;
    drawDigit(c, c.f3154, 0x5c, 0x10d);
    drawDigit(c, c.f3158, 0x4a, 0xfb);
    drawDigit(c, c.f315c, 0x38, 0xe9);
    f = patFrame(c, 41, c.f3160 > 0 ? 1 : 0);
    if (f) drawPart(c, f, (c.side === 0 ? 0x24 : 0xd5) - f.offsetX, 0xb0 - f.offsetY, f.width);
    if (c.f3160 <= 0) return;
    f = patFrame(c, 42, 0);
    if (f) {
        const t = ftol(c.f3160 * 0.1);
        const x = c.side === 0 ? t + 0x1f - f.offsetX : 0xda - t - f.offsetX;
        drawPart(c, f, x, 0xb9 - f.offsetY, f.width);
    }
}
function opponentFree(c) {
    const v = c.opponent.d160;
    return v === 0 || v === 4;
}
function clearStop(c) {
    c.d160 = 0;
    c.f3160 = 0;
    c.f315c = 0;
    c.f3158 = 0;
    c.f3154 = 0;
}
export function tickHookAkiko(c) {
    const o = c.opponent;
    if ((c.life <= 0 || o.life <= 0) && c.f3148 > 0) {
        c.f3148 = 0;
        o.d15c = 0;
    }
    if ((c.life <= 0 || o.life <= 0) && c.d160 > 0) {
        if (c.state !== 0x13f) setBgmRamp(0, 0x2710);
        clearStop(c);
    }
    if (c.f3148 > 0) {
        o.requestFlash(0xcb, 3);
        c.f3148 = c.f3148 - 1;
        if (c.f3148 <= 0) o.d15c = 0;
    }
    if (c.d160 <= 0) return;
    c.f3154 = c.f3154 + (4 - c.d160);
    if (c.f3160 === 0) {
        if (c.f3154 > 9) {
            c.f3154 -= 0xa;
            c.f3158++;
        }
        if (c.f3158 > 9) {
            c.f3158 -= 0xa;
            c.f315c++;
        }
        if (c.f315c > 9) {
            c.f315c -= 0xa;
            c.f3160++;
        }
        c.showAltBackground(3);
        const k = c.f314c;
        if (k >= 2 && k <= 0x24 && (k & 1) === 0) {
            if (c.f314c >= 0x24) {
                c.f314c = 0;
                if (o.d160 === 0 || o.d160 === 4 || c.side === 0) c.voiceRequest = 0xf;
            }
            if (opponentFree(c)) c.freeze = 1;
        }
        c.f314c++;
    }
    if (c.f3160 > 0) {
        if (c.f3160 === 1) {
            c.d160 = 4;
            if (opponentFree(c)) setBgmRamp(0, 0x2710);
            c.voiceRequest = 0x12;
        }
        c.f3160++;
        if (c.f3160 > 0xb4) {
            c.f3160 = 0;
            c.f315c = 0;
            c.f3158 = 0;
            c.f3154 = 0;
            c.d160 = 0;
        }
    }
    if (c.state > 0x31 && c.state < 0x96) {
        if (opponentFree(c)) setBgmRamp(0, 0x2710);
        clearStop(c);
    }
}

export function __logicState(){return {LEVEL_PAT,LEVEL_SOUND,SPRAY_429,SPRAY_431,SPRAY_430,SPRAY_432};}

export function __installInitialRoots(s){
if(LEVEL_PAT!==s["LEVEL_PAT"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_PAT');
if(LEVEL_SOUND!==s["LEVEL_SOUND"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_SOUND');
if(SPRAY_429!==s["SPRAY_429"])throw Error('INITIAL_CONST_IDENTITY:SPRAY_429');
if(SPRAY_431!==s["SPRAY_431"])throw Error('INITIAL_CONST_IDENTITY:SPRAY_431');
if(SPRAY_430!==s["SPRAY_430"])throw Error('INITIAL_CONST_IDENTITY:SPRAY_430');
if(SPRAY_432!==s["SPRAY_432"])throw Error('INITIAL_CONST_IDENTITY:SPRAY_432');
}
