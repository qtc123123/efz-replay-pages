import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./f72d22da4bca50f9c6c4bb45.mjs";
import { updateChildrenMizuka } from "./3a3de9c9ca972e4115fbd40f.mjs";
import { parseCommandMizuka, dispatchMovesMizuka } from "./cbce02bc129317c292b2025e.mjs";
import { thinkMizuka } from "./12bd822a0e322bc22bac71c5.mjs";
import "./700498cf713567ebb3f80d85.mjs";
import "./576636ff961f05fd9942fd65.mjs";
import "./101ba61daf971c1ee45ba4ed.mjs";
import "./3cbd823366808755e2ca547f.mjs";
const POINTS_X = [
    -13,
    14,
    0,
    0,
    0
];
const POINTS_Y = [
    -60,
    0,
    0,
    0,
    0
];
export class Mizuka extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    a3148 = new Int32Array(64);
    a3248 = new Int32Array(64);
    a3348 = new Int32Array(64);
    f3448 = 0;
    f344c = 0;
    f3450 = 0;
    f3454 = 0;
    f3458 = 0;
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        6,
        6,
        1,
        7,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    w0dc = 0;
    b0de = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.pointsX[0] = POINTS_X[0];
        this.pointsY[0] = POINTS_Y[0];
        this.pointsX[1] = POINTS_X[1];
        this.pointsY[1] = POINTS_Y[1];
        this.f3448 = 0;
        this.f344c = 0;
        this.f3450 = 0;
        this.f3454 = 0;
        this.f3458 = 0;
        this.a3148.fill(0);
        this.a3248.fill(0);
        this.a3348.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3148[i] = 0;
        this.a3248[i] = 0;
        this.a3348[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {}
    parseCommand() {
        parseCommandMizuka(this);
    }
    dispatchMoves() {
        dispatchMovesMizuka(this);
    }
    think() {
        thinkMizuka(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMizuka(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
