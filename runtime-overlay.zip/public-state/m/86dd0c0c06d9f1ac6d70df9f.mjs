import {createPageReplayCatalog}from"./1c1d6b1a00aaf6316b9ad6b2.mjs";
import {createRenderedBattlePort}from"./02e8e326e9dee42a21b53773.mjs";
import {prepareRenderedPublicBattle}from"./b923554668c5f768142b9cf5.mjs?v=a54931da184cccd1665edf3e13b464c1e6f3c45d8078fcc82d849c978c0a36b5";
import {createHookHost}from"./8a80ef8661fb0f339adebb18.mjs";
import {createRetainedFrameAdapter}from"./f7d5d132b3a814b8087da6d1.mjs";
import {createBattlePlayback}from"./65f0ae5ffcc921498f53d82f.mjs";
import {createSummaryObserver}from"./23ee11c5b56460adca2b837d.mjs";
import {validateExperimentalGame,validateExperimentalChunk}from"./688f1fd0af5f4d3259e0c88b.mjs?v=d3f03141d0869ce3100c1aa48f23b3eb742e23df4ba3a2a0c0156a6e646bbed3";
import {webSHA256}from"./a9843933b91c59bcdb549a05.mjs";
const need=(v,c)=>{if(!v)throw Error('PUBLIC_SESSION_'+c);};
const ownCharacter=c=>c?{id:c.id,color:c.color,life:c.life,meter:c.meter,rf:c.rfGauge,wins:c.wins,x:c.x,y:c.y}:null;
export async function createBrowserBattleSession(message,signal,{catalogFactory=createPageReplayCatalog,hashBytes=webSHA256,location=globalThis.location?.href}={}){
 const d=validateExperimentalGame(message.descriptor);signal?.throwIfAborted();let assets,port,retirement=null,playback=null;
 const retire=()=>{if(!retirement)retirement=(async()=>{signal?.removeEventListener('abort',abort);await port?.dispose();assets?.dispose();})();return retirement;};
 const abort=()=>{assets?.dispose();};signal?.addEventListener('abort',abort,{once:true});
 try{
  try{assets=await catalogFactory(message.manifest,d.initialization,message.assetRoot,message.key,undefined,location);}finally{message.key.fill(0);}
  signal?.throwIfAborted();need(assets&&['paths','has','load','bytes','dispose'].every(k=>typeof assets[k]==='function'),'CATALOG');
  const resources=assets.paths().map(path=>({path,file:{async arrayBuffer(){signal?.throwIfAborted();await assets.load(path);signal?.throwIfAborted();return assets.bytes(path).buffer;}}}));
  port=createRenderedBattlePort(resources);const host=createHookHost(1,()=>port.phase());await port.prepare(host.hooks);
  const bridge=await prepareRenderedPublicBattle(port,host,message.initialBytes,d.initialArtifact,{hashBytes,visualProfile:d.visualPolicy,paletteBinding:d.paletteBinding,gameId:d.id});signal?.throwIfAborted();
  need(JSON.stringify(bridge.selection.characters)===JSON.stringify(d.initialization.characters)&&JSON.stringify(bridge.selection.palettes)===JSON.stringify(d.initialization.palettes)&&bridge.selection.stage===d.initialization.stage,'SELECTION');
  need(JSON.stringify(bridge.fallbackSides)===JSON.stringify(d.paletteFallbackSides),'PALETTE_POLICY');bridge.install();
  const adapter=createRetainedFrameAdapter(port,host),observer=createSummaryObserver(),checks=new Map();let frame=0,received=0,available=d.availableFrames,terminal=null,lastFrame=null,lastCharacters=[],musicStopped=false;
  const checkedAdapter={status:adapter.status,retainedFrame:adapter.retainedFrame,async step(pair){
   await adapter.step(pair);const snap=port.snapshot(),h=host.snapshot(),row=observer.observe(frame,snap.gameState,h),expected=checks.get(frame);
   if(expected!==undefined){need(await hashBytes(new TextEncoder().encode(JSON.stringify(row)))===expected,'SUMMARY_DESYNC');checks.delete(frame);}
   signal?.throwIfAborted();const chars=snap.gameState.chars.map(ownCharacter);if(chars.every(Boolean))lastCharacters=chars;
   const soundEvents=[];
   for(const e of h.events){
    if(e.kind==='stopBGM')musicStopped=true;
    if(e.kind==='playBGM')throw Error('PUBLIC_SESSION_TRACK_SWITCH');
    let path,kind;
    if(e.kind==='playSE'){path='wave/se/'+String(e.args[0]).padStart(2,'0')+'.wav';kind='effect';}
    else if(e.kind==='playWave'){path=String(e.args[0]).replaceAll('\\','/').toLowerCase();kind='voice';}
    else continue;
    if(!assets.has(path))continue;need(soundEvents.length<2048,'SOUND_BOUND');soundEvents.push({update:frame,ordinal:soundEvents.length,innerTick:-1,kind,path,volume:-500,pan:0});
   }
   frame++;const image=adapter.retainedFrame();lastFrame={frame:frame-1,nextFrame:frame,result:{nextFrame:frame,soundEvents,musicState:{schema:'efz-local-music/1',nextUpdate:frame,volume:h.volume,stopped:musicStopped}},inspection:{ended:adapter.status()==='terminal',characters:chars,lastCharacters},image:{width:image.width,height:image.height,pixels:image.pixels,palette:image.palette}};
  }};
  playback=createBattlePlayback({sourceStart:d.sourceStart,adapter:checkedAdapter,close:retire});
  return Object.freeze({
   status:()=>({...playback.status(),availableFrames:available,terminal}),
   append(raw){const c=validateExperimentalChunk(raw,{id:d.id,from:received});need(c.availableFrames>=available&&c.availableFrames<=524288-d.sourceStart,'REGRESSION');need(terminal===null||terminal===c.terminal,'TERMINAL_CHANGE');
    if(terminal!==null&&playback.status().state!=='battle'){need(c.pairs.length===0,'TERMINAL_DATA');return;}
    need(playback.status().buffered+c.pairs.length<=4096,'CAPACITY');for(const check of c.checks)checks.set(check.frame,check.sha256);
    const end=c.from+c.pairs.length,atEnd=end===c.availableFrames;playback.append({from:d.sourceStart+c.from,pairs:c.pairs,terminal:atEnd?c.terminal:null});received=end;available=c.availableFrames;if(atEnd)terminal=c.terminal;
   },
   async step(){lastFrame=null;const result=await playback.step();return {...result,...(lastFrame?{frame:lastFrame}:{})};},
   retainedFrame:()=>playback.retainedFrame(),
   close(){checks.clear();lastFrame=null;return playback.close();}
  });
 }catch(error){await retire().catch(()=>{});throw error;}
}
