import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { normalizePath, preload, readSync } from "./197efe2647ca25903d217eb5.mjs";
import { isStorageSupported } from "./c5e3d33dc847c01c668746a6.mjs";
import { writeOpfsFile } from "./839f183fad63314b72a571b8.mjs";
const REPLAY_DIR = "efz-replay";
const saved = new Map();
export function replayPath(a, b) {
    return `replay\\data${a}-${b}.rep`;
}
function storageName(path) {
    const p = normalizePath(path);
    return p.slice(p.lastIndexOf("/") + 1);
}
async function replayDir(create) {
    if (!isStorageSupported()) return null;
    try {
        const opfs = await navigator.storage.getDirectory();
        return await opfs.getDirectoryHandle(REPLAY_DIR, {
            create
        });
    } catch  {
        return null;
    }
}
export async function preloadReplays(paths) {
    await preload(paths);
    const dir = await replayDir(false);
    if (!dir) return;
    await Promise.all(paths.map(async (path)=>{
        try {
            const handle = await dir.getFileHandle(storageName(path));
            const file = await handle.getFile();
            saved.set(normalizePath(path), new Uint8Array(await file.arrayBuffer()));
        } catch  {}
    }));
}
export function replayPayloadLength(data) {
    if (data.length >= 20) {
        const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
        const len = view.getUint32(data.length - 8, true);
        if (view.getInt32(data.length - 4, true) === -1 && len >= 12 && len < data.length) return len;
    }
    return data.length;
}
function readReplay(path) {
    return saved.get(normalizePath(path)) ?? readSync(path);
}
function saveReplay(path, data) {
    saved.set(normalizePath(path), data);
    if (!isStorageSupported()) {
        console.warn("[replay] 瀏覽器不支援 OPFS，錄影只保留到關閉頁面為止");
        return;
    }
    writeOpfsFile([
        REPLAY_DIR,
        storageName(path)
    ], new Blob([
        data.slice().buffer
    ])).catch((err)=>console.warn("[replay] 錄影保存失敗", err));
}
export class ReplayFile {
    eof = 0;
    opened = false;
    remaining = 0;
    path = "";
    data = null;
    pos = 0;
    out = null;
    openRead(path) {
        this.path = path;
        this.data = readReplay(path);
        this.pos = 0;
        this.out = null;
        this.opened = true;
        this.remaining = this.data ? replayPayloadLength(this.data) : 0;
        this.eof = 0;
        return this.remaining;
    }
    remainingBytes() {
        return this.remaining;
    }
    create(path) {
        this.path = path;
        this.data = null;
        this.pos = 0;
        this.out = [];
        this.opened = true;
        this.eof = 0;
    }
    close() {
        if (!this.opened) return;
        if (this.out) {
            const bytes = new Uint8Array(this.out.length * 2);
            const view = new DataView(bytes.buffer);
            this.out.forEach((w, i)=>view.setInt16(i * 2, w, true));
            saveReplay(this.path, bytes);
        }
        this.out = null;
        this.data = null;
        this.opened = false;
    }
    readWord() {
        if (this.remaining === 0) {
            this.eof = 1;
            return 0;
        }
        const d = this.data;
        const lo = d?.[this.pos] ?? 0;
        const hi = d?.[this.pos + 1] ?? 0;
        this.pos += 2;
        this.remaining = this.remaining - 2 >>> 0;
        return (hi << 8 | lo) & 0xffff;
    }
    writeWord(value) {
        this.out?.push(value << 16 >> 16);
    }
}

export function __logicState(){return {saved};}

export function __installInitialRoots(s){
if(saved!==s["saved"])throw Error('INITIAL_CONST_IDENTITY:saved');
}
