import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerChildren2, registerStates, registerStates2 } from "./81433295782a220b1d5e4d42.mjs";
import { childCount, childDuration, frameChild, frameEffect, openSpawnFrame } from "./2ed079700202e720d67705c7.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
var Jc = /*#__PURE__*/ function(Jc) {
    Jc[Jc["Ge2"] = 0] = "Ge2";
    Jc[Jc["Eq3"] = 1] = "Eq3";
    Jc[Jc["Ge2NoD15c"] = 2] = "Ge2NoD15c";
    return Jc;
}(Jc || {});
function groundJumpCancel(c, kind) {
    if (c.inputY !== -1 || c.frame <= 0) return false;
    if (kind !== 2 && c.d15c >= 3) return false;
    if (kind === 1 ? c.d168 !== 3 : c.d168 < 2) return false;
    jumpTo456(c);
    return true;
}
function airJumpCancel(c, d168ok) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && d168ok && c.b15a === 0) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function attackStart(c, meter, se, hits) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = hits;
}
function stopIfNotDashing(c) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
}
function dashSlide(c, k) {
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - k;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function airDashEnd(c, vx) {
    c.setState(9);
    c.vx = vx;
    c.ay = 0.03;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function airLand(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(99);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.timer = w16(c.timer + 1);
    c.b158 = 0;
    if (c.life > 0 && c.timer > 99 && c.frame === 0) c.setState(96);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(96);
    }
}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        c.b158 = 0;
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx = c.vx + 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy = c.vy + c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy = c.vy + c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.startAfterimage(1);
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (atStart(c)) {
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.vx = 2.5;
    c.b158 = 1;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 4) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.setState(0);
            return;
        }
    }
    if (c.inputX === c.facing && c.f313c >= 80 && c.frame < 4) c.setState(178);
    if (c.inputX !== c.facing && c.f3138 >= 60 && c.frame < 4) c.setState(178);
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) {
        c.vx = -1.9;
        c.vy = -1.0;
        c.ay = 0.04;
    }
    if (c.frame > 0 && c.frame < 4) c.vy = c.vy + c.ay;
    if (c.frame > 1 && c.vy + c.y >= 0.0 && c.f3138 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.y = 0.0;
        c.f3138++;
        c.seRequest = 9;
        c.frame = 4;
        c.timer = 0;
    }
    if (advance(c, dur)) {
        if (c.frame === 4) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.faceOpponent();
            c.setState(0);
        }
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = 1.3;
        c.startAfterimage(3);
        c.vy = 0.0;
        c.ay = 0.0;
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 120) airDashEnd(c, 1.6);
    if (c.inputX !== c.facing && c.f3138 >= 40) airDashEnd(c, 1.3);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -1.3;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9);
    if (c.inputX !== -c.facing && c.f3138 >= 40) airDashEnd(c, -0.9);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        if (c.ay === 0.0) c.ay = 0.035;
        c.vx = 0.0;
        c.vy = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(1);
    c.vx = c.vx - 0.07;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 4) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 4;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 1) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 4) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function groundNormal(c, jc, atk, meter, se, clearBelow, crouchable) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c, 0.03);
    if (groundJumpCancel(c, jc)) return;
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, crouchable);
    }
}
const s200 = (form)=>(c)=>groundNormal(c, form === 0 ? 0 : 2, 1, 5, 21, 3, false);
const s204 = (c)=>groundNormal(c, 0, 1, 5, 21, 3, true);
const s205 = (c)=>groundNormal(c, 0, 2, 13, 20, 4, true);
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c, 0.03);
    if (groundJumpCancel(c, 1)) return;
    if (atFrame(c, 1)) attackStart(c, 15, 20, 1);
    if (advance(c, dur)) {
        if (c.frame === 3) c.x = c.facing * 5 + c.x;
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, 1)) return;
    stopIfNotDashing(c);
    dashSlide(c, 0.03);
    if (atFrame(c, 4)) attackStart(c, 15, 20, 1);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, 1)) return;
    if (c.frame < 2) dashSlide(c, 0.06);
    if (groundJumpCancel(c, 2)) return;
    if (atFrame(c, 2)) {
        attackStart(c, 35, 20, 1);
        c.vx = 1.0;
    }
    if (c.vx > 0.0) c.vx = c.vx - 0.035;
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        if (c.frame < 1) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame < 2) dashSlide(c, 0.03);
    if (atFrame(c, 2)) {
        attackStart(c, 25, 20, 1);
        c.vx = 1.5;
    }
    if (c.frame > 4) c.vx = c.vx - 0.035;
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 5 && c.f3138 < 2) {
            c.frame = w16(c.frame - 2);
            c.f3138++;
        }
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function airNormalHead(c, start) {
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c, c.d168 >= 2)) return false;
    start();
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.state = 13;
        c.onStateChange();
        return false;
    }
    return true;
}
function s207(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!airNormalHead(c, ()=>{
        if (atFrame(c, 2)) attackStart(c, 5, 21, 1);
    })) return;
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s208(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!airNormalHead(c, ()=>{
        if (atFrame(c, 1)) attackStart(c, 7, 20, 1);
        if (atFrame(c, 5)) attackStart(c, 7, 20, 1);
    })) return;
    if (advance(c, dur)) {
        if (c.frame === 1 || c.frame === 5) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s209(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!airNormalHead(c, ()=>{
        if (atFrame(c, 2)) attackStart(c, 30, 20, 3);
    })) return;
    if (advance(c, dur)) {
        if (s16(c.w16c) > 0) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 2) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 2 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 221;
        o.state = 103;
        o.x = c.facing * 0x19 + c.x;
        o.y = -68.0;
        c.biasCameraY(50, 30);
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x19;
        d.y = ftol(c.y) - 68;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 2) c.biasCameraY(50, 3);
    if (atFrame(c, 1)) {
        o.hitstop = 60;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x19;
        d.y = ftol(c.y) - 68;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        applyDirectDamage(c, 900, 750.0);
        c.voiceRequest = 0;
    }
    if (atFrame(c, 2)) {
        o.onStateChange();
        o.state = 63;
        o.knockX = -1.2;
        o.knockY = -1.0;
        o.y = -15.0;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function dashAdvance(c, dur, cnt, clearBelow, end) {
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) c.setState(end);
    }
}
function s230(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (c.vx < 0.0) c.vx = 0.0;
    c.vx = c.vx - 0.03;
    if (atStart(c)) c.vy = 0.0;
    if (atFrame(c, 1)) attackStart(c, 5, 21, 1);
    dashAdvance(c, dur, cnt, 3, 0);
}
function dashAttack(c, jumpCancel, atk, meter, se, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (jumpCancel && groundJumpCancel(c, 1)) return;
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atStart(c)) c.vy = 0.0;
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    dashAdvance(c, dur, cnt, 3, end);
}
const s231 = (c)=>dashAttack(c, true, 2, 10, 20, 0);
const s233 = (c)=>dashAttack(c, false, 1, 5, 21, 3);
const s234 = (c)=>dashAttack(c, false, 2, 5, 21, 3);
function s232(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(1);
    c.b158 = 0;
    c.vx = c.vx - 0.045;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atFrame(c, 4)) attackStart(c, 25, 20, 1);
    dashAdvance(c, dur, cnt, 2, 0);
}
function s235(c, form) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (airJumpCancel(c, form === 0 ? c.d168 === 3 : c.d168 >= 2)) return;
    c.startAfterimage(3);
    c.b158 = 0;
    if (c.frame === 0) c.vx = c.vx - 0.03;
    if (c.vx < 0.0 && c.frame === 0) c.vx = 0.0;
    if (atFrame(c, 1)) {
        c.vy = -1.2;
        c.vx = 1.0;
    }
    if (atFrame(c, 3)) attackStart(c, 10, 21, 1);
    if (c.y < 0.0) {
        c.vy = c.vy + 0.025;
        if (c.y + c.vy > 0.0) {
            c.timer = 0;
            c.frame = 11;
            c.y = 0.0;
            c.stopMotion();
            return;
        }
    }
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame === 11) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) c.setState(3);
    }
}
function superFlash(c, d, dx, dy) {
    d.w04 = 70;
    d.b2c = 64;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
    c.seRequest = 37;
    d.w04 = 71;
    frameEffect(d);
}
function s321(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.w16c = 1;
        c.stopMotion();
        c.freeze = 120;
        addMeter(c, -3000);
        c.superDarken(176, 3);
        superFlash(c, d, 0x12, 25);
        c.w16c = 1;
    }
    c.showAltBackground(15);
    if (c.frame < 4) c.biasCameraY(50, 10);
    if (c.frame === 13 && c.d168 === 3) {
        c.startAfterimage(0);
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 322;
        c.w13e = 3;
        c.w140 = 3;
        return;
    }
    if (c.frame === 13 && c.d168 !== 3 && c.d168 > 0) {
        c.startAfterimage(0);
        c.timer = 0;
        c.frame = 14;
        return;
    }
    if (atFrame(c, 13)) c.vx = 5.0;
    if (atFrame(c, 14)) c.vx = 1.5;
    if (c.frame > 3 && c.vx > 0.0) {
        c.vx = c.vx - 0.03;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function spawn322(c, d, pattern, x, y, facing, layer) {
    d.w04 = pattern;
    d.x = x;
    d.y = y;
    d.b20 = 0;
    d.d00 = 1;
    d.b18 = facing;
    d.b21 = layer;
    frameChild(c, d);
}
function s322(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    const d = openSpawnFrame();
    c.w13e = 3;
    if (c.f313c === 0) o.w140 = 3;
    if (atStart(c)) c.x = o.x;
    if (o.state === 99) o.timer = 0;
    if (c.frame < 6) {
        o.biasCameraY(50, 5);
        o.biasCamera(50, 5);
    }
    if (c.frame > 5) {
        c.biasCameraY(50, 5);
        c.biasCamera(50, 5);
    }
    if (c.frame < 6) c.showAltBackground(15);
    if (atFrame(c, 6)) {
        c.b158 = 0;
        c.stopMotion();
        c.freeze = 120;
        c.superDarken(176, 3);
        superFlash(c, d, 6, 48);
    }
    if (atFrame(c, 1)) spawn322(c, d, 431, ftol(o.x) - c.facing * 0x140, ftol(o.y) + 160, c.facing, 1);
    if (atFrame(c, 2)) spawn322(c, d, 432, ftol(o.x) + c.facing * 0x140, ftol(o.y) + 120, -c.facing, 1);
    if (atFrame(c, 3)) spawn322(c, d, 433, ftol(o.x) - c.facing * 0xa0, ftol(o.y) + 280, c.facing, 1);
    if (atFrame(c, 4)) spawn322(c, d, 434, ftol(o.x) + c.facing * 0xa0, ftol(o.y) + 280, -c.facing, 1);
    if (atFrame(c, 21)) {
        d.d28 = 1;
        spawn322(c, d, 435, ftol(c.x) - c.facing * 0x186, ftol(c.y) - 330, c.facing, 1);
        spawn322(c, d, 436, ftol(c.x) - c.facing * 0xc3, ftol(c.y) - 495, c.facing, 1);
        spawn322(c, d, 437, ftol(c.x) + c.facing * 0x186, ftol(c.y) - 330, -c.facing, 1);
        spawn322(c, d, 438, ftol(c.x) + c.facing * 0xc3, ftol(c.y) - 495, -c.facing, 0);
    }
    if (atFrame(c, 8)) {
        d.w04 = 439;
        d.x = ftol(c.x) + c.facing * 0xe;
        d.y = ftol(c.y) + 8;
        d.b20 = 2;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (c.frame === 22 && c.f3138 === 1) {
        c.frame = 23;
        c.timer = 0;
        c.f3138 = 2;
    }
    if (advance(c, dur)) {
        if (c.frame === 12 && c.f3138 < 5) {
            c.f3138++;
            c.frame = w16(c.frame - 2);
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.w13e = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function childAdvanceFree(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    if (ch.frame >= childCount) c.freeChild(i);
}
function rush(c, i, vx, vy) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = vx;
        ch.vy = vy;
    }
    childAdvanceFree(c, i);
}
function drop(c, i, vx, vy, setFlag) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = vx;
        ch.vy = vy;
    }
    if (ch.y > 0.0 && ch.frame === 0) {
        ch.y = 0.0;
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.frame = 1;
        ch.timer = 0;
        if (setFlag) c.f3138 = 1;
    }
    if (c.frame === 24 && ch.frame === 1) {
        ch.frame = 2;
        ch.timer = 0;
        return;
    }
    if (ch.frame === 2) {
        ch.vx = vx;
        ch.vy = -vy;
    }
    childAdvanceFree(c, i);
}
function child439(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    if (ch.hitState > 0) c.f313c = 1;
    childAdvanceFree(c, i);
}
function child439b(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    childAdvanceFree(c, i);
}
const common = {
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    234: s234
};
function formCases(form) {
    return {
        200: s200(form),
        235: (c)=>s235(c, form)
    };
}
registerStates({
    ...common,
    ...formCases(0),
    321: s321,
    322: s322
});
registerStates2({
    ...common,
    ...formCases(1)
});
const commonChildren = {
    431: (c, i)=>rush(c, i, 7.0, -3.5),
    432: (c, i)=>rush(c, i, 7.0, -3.5),
    433: (c, i)=>rush(c, i, 3.5, -7.0),
    434: (c, i)=>rush(c, i, 3.5, -7.0),
    435: (c, i)=>drop(c, i, 4.0, 4.0, true),
    436: (c, i)=>drop(c, i, 2.0, 6.0, false),
    437: (c, i)=>drop(c, i, 4.0, 4.0, true),
    438: (c, i)=>drop(c, i, 2.0, 6.0, false)
};
registerChildren({
    ...commonChildren,
    439: child439
});
registerChildren2({
    ...commonChildren,
    439: child439b
});

export function __logicState(){return {Jc,common,commonChildren};}

export function __installInitialRoots(s){
Jc=s["Jc"];
if(common!==s["common"])throw Error('INITIAL_CONST_IDENTITY:common');
if(commonChildren!==s["commonChildren"])throw Error('INITIAL_CONST_IDENTITY:commonChildren');
}
