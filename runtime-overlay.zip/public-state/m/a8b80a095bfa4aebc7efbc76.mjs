import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { spawnEffect } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { childHandlers, registerChildren } from "./65b7ada33d910b3c78926926.mjs";
import { childFrameCount, childFrameDuration } from "./e2bb73ea5d34f44e96511e06.mjs";
export function newSpawnFrame() {
    const f = {
        d00: 0,
        w04: 0,
        x: 0,
        y: 0,
        b18: 0,
        d1c: 0,
        b20: 0,
        b21: 0,
        d24: 0,
        d28: 0,
        b2c: 0,
        d30: 0,
        clip: [
            0,
            0,
            0,
            0
        ]
    };
    return f;
}
export function resetSpawnFrame(f) {
    f.d00 = 0;
    f.b20 = 0;
    f.b2c = 0xff;
    f.d24 = 0;
    f.d28 = 0;
    f.d30 = 0;
    f.clip = [
        0,
        0,
        0,
        0
    ];
}
export function frameEffect(f) {
    spawnEffect({
        owner: f.d00,
        pat: f.w04,
        x: f.x,
        y: f.y,
        b18: f.b18,
        mirror: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        sound: f.b2c
    });
}
export function frameChild(c, f) {
    return c.spawnChild({
        type: f.d00,
        pattern: f.w04,
        x: f.x,
        y: f.y,
        facing: f.b18,
        d4c: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        shadow: f.d28,
        b6c: f.b2c,
        moveWhileFrozen: f.d30,
        clip: [
            ...f.clip
        ]
    });
}
export const childSpawnFrame = newSpawnFrame();
export let childDuration = 0;
export let childCount = 0;
let walkAborted = false;
export function abortChildWalk() {
    walkAborted = true;
}
export function updateChildrenAyu(c) {
    if (c.opponent.freeze > 0) return;
    let i = c.childTail;
    Object.assign(childSpawnFrame, newSpawnFrame());
    walkAborted = false;
    while(i !== c.childHead){
        const ch = c.children[i];
        if (c.childActive[i] !== 0 && ch.hitstop === 0) {
            let run = true;
            if (c.freeze !== 0) {
                if (c.freeze <= 0 || ch.moveWhileFrozen === 0) run = false;
            }
            if (run) {
                childDuration = childFrameDuration(c, i);
                childCount = childFrameCount(c, i);
                resetSpawnFrame(childSpawnFrame);
                const k = ch.pattern - 400;
                if (k >= 0 && k <= 0x63) {
                    const handler = childHandlers.get(ch.pattern);
                    handler?.(c, i);
                    if (walkAborted) return;
                }
            }
        }
        i++;
        if (i >= 64) i = 0;
    }
}
function advance(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return null;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return ch.frame >= childCount;
}
function freeIfOffscreen(c, i) {
    const ch = c.children[i];
    if (ch.x < -100.0 || ch.x > 800.0 || ch.y < -480.0) c.freeChild(i);
}
function child400(c, i) {
    const ch = c.children[i];
    ch.vx = 2.0;
    ch.vy = -4.0;
    if (ch.frame === 0 && ch.timer === 0 && c.a3150[i] === 0) {
        ch.hitsLeft = 3;
        c.a3150[i]++;
    }
    if (advance(c, i)) ch.frame -= 4;
    freeIfOffscreen(c, i);
}
function child401(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = rand("src/game/chars/ayu/children.ts:187:11", {
            consumer: "src/game/chars/ayu/children.ts"
        }) * -0.2 / 32768.0 - 0.3;
        ch.vy = rand("src/game/chars/ayu/children.ts:188:11", {
            consumer: "src/game/chars/ayu/children.ts"
        }) * -0.1 / 32768.0 - 0.1;
        ch.ax = rand("src/game/chars/ayu/children.ts:189:11", {
            consumer: "src/game/chars/ayu/children.ts"
        }) * -0.005 / 32768.0 - 0.001;
        ch.ay = rand("src/game/chars/ayu/children.ts:190:11", {
            consumer: "src/game/chars/ayu/children.ts"
        }) * 0.005 / 32768.0 + 0.003;
    }
    ch.vx = ch.vx + ch.ax;
    ch.vy = ch.vy + ch.ay;
    if (advance(c, i)) c.freeChild(i);
    freeIfOffscreen(c, i);
}
function child402(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = rand("src/game/chars/ayu/children.ts:203:11", {
            consumer: "src/game/chars/ayu/children.ts"
        }) * -0.2 / 32768.0 - 0.03;
        ch.vy = rand("src/game/chars/ayu/children.ts:204:11", {
            consumer: "src/game/chars/ayu/children.ts"
        }) * -0.2 / 32768.0 + 0.1;
        ch.ax = rand("src/game/chars/ayu/children.ts:205:11", {
            consumer: "src/game/chars/ayu/children.ts"
        }) * -0.03 / 32768.0 - 0.005;
        ch.ay = rand("src/game/chars/ayu/children.ts:206:11", {
            consumer: "src/game/chars/ayu/children.ts"
        }) * 0.005 / 32768.0 + 0.005;
    }
    ch.vx = ch.vx + ch.ax;
    ch.vy = ch.vy + ch.ay;
    if (advance(c, i)) c.freeChild(i);
    freeIfOffscreen(c, i);
}
function childPlayOnce(c, i) {
    if (advance(c, i)) c.freeChild(i);
}
function child405(c, i) {
    const ch = c.children[i];
    ch.vy = 0.0;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 0x63;
        ch.vx = 3.0;
    }
    ch.vx = ch.vx - 0.05;
    if (ch.vx <= 0.3) ch.vx = 0.3;
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    if (ch.frame === 6 || ch.frame === 12 || ch.frame === 18) ch.hitState = 0;
    ch.frame++;
    if (ch.frame < childCount) return;
    if (c.a3150[i] < 1) {
        ch.frame = 1;
        c.a3150[i]++;
        return;
    }
    c.freeChild(i);
}
function child406(c, i) {
    const ch = c.children[i];
    if (c.state === 0x133 || c.state === 0x134) {
        ch.x = ch.facing * 10 + c.x + 0.0;
    }
    if (advance(c, i) === null) return;
    if (ch.frame === 7) {
        if (c.state === 0x133 && c.frame < 0xd || c.state === 0x134 && c.frame < 0x1d) ch.frame -= 2;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child407(c, i) {
    const ch = c.children[i];
    if (c.state === 0x134) {
        ch.x = ch.facing * 10 + c.x + 0.0;
    }
    if (advance(c, i) === null) return;
    if (ch.frame === 7 && c.frame < 0x2d && c.state === 0x134) ch.frame -= 2;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child408(c, i) {
    const ch = c.children[i];
    ch.vx = 2.0;
    ch.vy = -4.0;
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 8;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.y > -480.0) ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame -= 4;
    }
    if (ch.y < -680.0) c.freeChild(i);
}
function child409(c, i) {
    const ch = c.children[i];
    ch.vx = 2.0;
    ch.vy = 4.0;
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 4;
    if (advance(c, i)) ch.frame -= 4;
    if (ch.y > 0.0) {
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.y = 0.0;
        ch.pattern = 0x19a;
        ch.blend = 2;
        ch.frame = 0;
        ch.timer = 0;
        abortChildWalk();
    }
}
function child410(c, i) {
    const ch = c.children[i];
    ch.hitsLeft = 1;
    if (ch.frame === 0 && ch.timer === 0) c.voiceRequest = 3;
    if (advance(c, i)) c.freeChild(i);
}
registerChildren({
    400: child400,
    401: child401,
    402: child402,
    403: childPlayOnce,
    404: childPlayOnce,
    405: child405,
    406: child406,
    407: child407,
    408: child408,
    409: child409,
    410: child410
});

export function __logicState(){return {childSpawnFrame,childDuration,childCount,walkAborted};}

export function __installInitialRoots(s){
if(childSpawnFrame!==s["childSpawnFrame"])throw Error('INITIAL_CONST_IDENTITY:childSpawnFrame');
childDuration=s["childDuration"];
childCount=s["childCount"];
walkAborted=s["walkAborted"];
}
