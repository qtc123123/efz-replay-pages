import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./4ab9307bcb6cd4f39f8feacd.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./98eccc84a6920bb332239618.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function superEffect(d, c, pat, sound, dx, offY) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - offY;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function summonSuper(c, child) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame < 5) c.biasCameraY(0x32, 3);
    if (c.frame >= 1) c.wF2 = 0xa;
    if (atFrame(c, 5) && c.f3138 === 0) {
        d.w04 = child;
        d.x = ftol(c.x) + c.facing * 0x4d;
        d.y = ftol(c.y) - 0x2b;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 2) {
        superFreeze(c, 0x3e8);
        superEffect(d, c, 0x44, 0x13, 0x2f, 0x2b);
    }
    if (c.frame === 5 && c.freeze > 0) c.frame -= 3;
    if (c.frame === 8 && c.f3138 < 3) {
        c.frame -= 3;
        c.f3138++;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function rushSpawns(c, d, spread, own) {
    d.w04 = 3;
    const r = c.random(0, spread) & 0xffff;
    d.x = ftol(c.facing * r + c.x);
    d.y = 0.0;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    if (own !== null) {
        d.d00 = 1;
        d.w04 = own;
        d.x = ftol(c.x);
        d.y = 0.0;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
    }
    d.w04 = 0x191;
    d.x = ftol(c.x) + c.facing * 0x1b;
    d.y = ftol(c.y) - 0x1c;
    d.b18 = c.facing;
    d.b21 = 1;
    d.b20 = 2;
    frameChild(c, d);
    d.w04 = 0x1a5;
    d.x = ftol(c.x) + c.facing * 0x10;
    d.y = ftol(c.y) - 0x2b;
    d.b21 = 1;
    d.b20 = 0;
    frameChild(c, d);
    d.x = ftol(c.x) + c.facing * 0x15;
    d.y = ftol(c.y) - 0x33;
    d.b21 = 0;
    frameChild(c, d);
    c.voiceRequest = 0;
}
function rushSuper(c, cost, pat, sound, spread, own, loops, big, clearOwner14) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 0x63;
    }
    if (atFrame(c, 3)) {
        c.vy = -2.4;
        c.vx = -0.4;
        c.ay = 0.029;
        c.w16c = 0x63;
    }
    if (c.frame === 3) c.biasCameraY(0x32, 3);
    if (c.frame > 0xb) c.opponent.biasCameraY(0x32, 3);
    if (atFrame(c, 3)) {
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, 0, 0x28);
        if (big) c.seRequest = 0x25;
    }
    if (atFrame(c, 0xb)) c.stopMotion();
    if (big && c.frame > 0xa) c.showAltBackground(0xf);
    if (atFrame(c, 0xc)) {
        c.vx = -0.2;
        c.vy = -0.8;
        c.ay = 0.015;
    }
    if (atFrame(c, 0xe)) {
        if (clearOwner14) d.d00 = 0;
        rushSpawns(c, d, spread, own);
    }
    if (atFrame(c, 0x12)) {
        d.d00 = 0;
        rushSpawns(c, d, spread, null);
    }
    c.vy += c.ay;
    if (c.frame < 0x14 && c.vy > 0.15) c.vy = 0.15;
    if (c.frame > 0xe && c.frame < 0x16 && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.frame = 0x16;
        c.timer = 0;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 0x14 && c.f3138 < loops) {
        c.f3138++;
        c.frame -= 3;
    }
    if (c.frame === 0x16) c.frame -= 2;
    if (c.frame >= cnt) {
        c.state = 7;
        c.onStateChange();
    }
}
function dashSuper(c, cost, pat, sound, w16c, big, onLaunch) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) {
        if (c.f3138 === 0) {
            superFreeze(c, cost);
            superEffect(d, c, pat, sound, 5, 0x2b);
            c.f3138++;
            c.w16c = w16c;
            if (big) c.seRequest = 0x25;
        }
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (big) {
        c.showAltBackground(0xf);
        if (c.frame === 5 && c.f3140 < 0) {
            trailEffect(d, c);
            c.f3140 = 0xc;
        }
        c.f3140--;
    }
    if (atFrame(c, 4)) {
        d.w04 = 0x1a7;
        d.x = ftol(c.x) + c.facing * 0x2d;
        d.y = ftol(c.y) - 0x2b;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 0;
        d.b18 = -c.facing;
        frameChild(c, d);
    }
    if (c.frame < 5) c.biasCameraY(0x32, 3);
    if (c.frame === 5) c.vy += 0.01;
    if (c.frame === 5 && c.y + c.vy > 0.0) {
        c.frame = 6;
        c.timer = 0;
        c.y = 0.0;
        c.vy = 0.0;
    }
    if (c.frame > 5) {
        c.vx -= 0.025;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame >= 1) c.wF2 = 0xa;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 2 && c.f313c < 9) {
        c.frame -= 2;
        c.f313c++;
    }
    if (c.frame === 5) onLaunch(d);
    if (c.frame === 6) c.frame -= 1;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function trailEffect(d, c) {
    d.w04 = 0x1f;
    d.x = ftol(c.x);
    d.y = 0.0;
    d.b20 = 0;
    d.b21 = 0;
    d.d1c = c.facing !== 1 ? 1 : 0;
    frameEffect(d);
}
function launch(c, vx, vy) {
    c.vx = vx;
    c.vy = vy;
    c.x = c.facing * 0x1e + c.x;
    c.voiceRequest = 4;
}
function state306(c) {
    dashSuper(c, 0x3e8, 0x44, 0x13, 5, false, ()=>launch(c, 1.9, -0.4));
}
function state307(c) {
    dashSuper(c, 0x7d0, 0x45, 5, 0xc, false, (d)=>{
        c.w13c = 3;
        launch(c, 2.3, -0.65);
        trailEffect(d, c);
    });
}
function state308(c) {
    dashSuper(c, 0xbb8, 0x46, 0x40, 0x13, true, ()=>launch(c, 2.5, -0.8));
}
function state309(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.b158 = 0;
    if (atStart(c)) {
        c.w16c = 1;
        c.seRequest = 0x25;
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40, 5, 0x38);
        c.f3138++;
        c.w16c = 0x13;
        d.w04 = 0x47;
        frameEffect(d);
    }
    c.showAltBackground(0xf);
    c.vx = 0.0;
    c.vy = 0.0;
    c.ay = 0.0;
    o.d0d0 = 0;
    c.d0d0 = 0;
    if (c.f313c === 1 && c.frame === 5) {
        c.frame = 6;
        c.voiceRequest = 3;
        c.timer = 0;
        return;
    }
    if (c.f313c === 2 && c.frame === 5) {
        c.onStateChange();
        c.state = 0x136;
        return;
    }
    if (c.frame > 8 && c.frame < 0xd) c.life += 0x14;
    if (c.life > 0x2710) c.life = 0x2710;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 3) {
        d.w04 = 0x1a6;
        d.x = ftol(c.x) + c.facing * 6;
        d.y = ftol(c.y) - 0x50;
        d.b20 = 0;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.frame === 6) c.frame -= 1;
    if (c.frame === 0xd && c.f3138 < 2) {
        c.f3138++;
        c.frame -= 2;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state310(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.ay = 0.0;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 2 && c.f3138 < 8) {
        c.f3138++;
        c.frame -= 2;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
registerStates({
    300: (c)=>summonSuper(c, 0x1a2),
    301: (c)=>summonSuper(c, 0x1a3),
    302: (c)=>summonSuper(c, 0x1a4),
    303: (c)=>rushSuper(c, 0x3e8, 0x44, 0x13, 0xb4, 0x19f, 8, false, false),
    304: (c)=>rushSuper(c, 0x7d0, 0x45, 5, 0xf0, 0x1a0, 0xf, false, true),
    305: (c)=>rushSuper(c, 0xbb8, 0x46, 0x40, 0x140, 0x1a1, 0x19, true, true),
    306: state306,
    307: state307,
    308: state308,
    309: state309,
    310: state310
});
function childStep(c, i, dur) {
    const ch = c.children[i];
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function rushHit(c, i, state) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.hitsLeft = 0x63;
    if (c.state !== state || c.frame > 0x13) c.freeChild(i);
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame >= cnt) ch.frame -= 1;
}
function shotInit(c, i, init) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a314c[i] === 0) {
        ch.hitsLeft = 5;
        init();
        c.a314c[i]++;
    }
}
function shotRehit(c, i) {
    if (c.a324c[i] > 0x5a) {
        c.children[i].hitState = 0;
        c.a324c[i] = 0;
    }
    c.a324c[i]++;
}
function child418(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    shotInit(c, i, ()=>{
        ch.vy = -0.45;
        ch.vx = 0.02;
    });
    if (ch.hitsLeft === 0) {
        c.freeChild(i);
        return;
    }
    ch.vy += 0.0012;
    ch.vx -= 1e-5;
    if (ch.vx < 0.0) ch.vx = 0.0;
    shotRehit(c, i);
    if (ch.y + ch.vy > 0.0) c.freeChild(i);
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame >= cnt) ch.frame = 0;
}
function child419(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    shotInit(c, i, ()=>{
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.ay = 0.005;
    });
    if (ch.hitsLeft === 0) {
        c.freeChild(i);
        return;
    }
    shotRehit(c, i);
    if (ch.vy > 0.3) ch.ay = -0.005;
    if (ch.vy < -0.3) ch.ay = 0.005;
    ch.vy += ch.ay;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame < cnt) return;
    if (c.a334c[i] < 0xc) {
        ch.frame = 0;
        c.a334c[i]++;
        return;
    }
    c.freeChild(i);
}
function child420(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    shotInit(c, i, ()=>{
        ch.vy = -0.5;
        ch.vx = 0.3;
    });
    if (ch.hitsLeft === 0) {
        c.freeChild(i);
        return;
    }
    ch.vy += 0.0015;
    shotRehit(c, i);
    if (ch.y + ch.vy > 0.0) c.freeChild(i);
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame >= cnt) ch.frame = 0;
}
function child421(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (c.a314c[i] === 0) {
        ch.vy = (c.random(0, 0x14) & 0xffff) * 0.01 + -2.6;
        ch.vx = -1.0 - (c.random(0, 0x14) & 0xffff) * 0.01;
    }
    if (ch.y + ch.vy > 0.0) {
        c.voiceRequest = 2;
        ch.y = 0.0;
        ch.vy = -ch.vy * 0.5;
        if (ch.vy > -1.0) {
            c.freeChild(i);
            return;
        }
    }
    c.a314c[i]++;
    ch.vy += 0.05;
    if (c.a314c[i] > 0xb4) {
        c.freeChild(i);
        return;
    }
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame >= cnt) ch.frame = 0;
}
function child422(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (c.a314c[i] === 0) {
        ch.vy = -3.2;
        ch.vx = -0.07;
    }
    if (ch.hitState === 5 && ch.frame === 0) {
        ch.frame = 1;
        ch.timer = 0;
        c.f313c = 2;
        ch.vx = c.facing * 1.5 * c.opponent.facing;
        ch.vy = -1.5;
        return;
    }
    if (ch.y + ch.vy > -70.0 && ch.frame === 0) {
        c.f313c = 1;
        c.freeChild(i);
        return;
    }
    c.a314c[i]++;
    ch.vy += 0.035;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame === 1) ch.frame -= 1;
    if (ch.frame >= cnt) c.freeChild(i);
}
function child423(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const d = childSpawnFrame;
    if (ch.frame < 0x1d) {
        ch.x = c.facing * 0xc + c.x;
        ch.y = c.y - 50.0;
    }
    if (ch.frame < 0x1d && c.a324c[i] <= 0) {
        d.w04 = 0x22;
        const bx = ftol(ch.x) + -ch.facing * 0x2f;
        d.x = bx + (c.random(0, 0xa) & 0xffff);
        const by = ftol(ch.y);
        d.y = by + (c.random(0, 0xa) & 0xffff) + 0xc;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.a324c[i] = 2;
    }
    if (ch.frame < 0x1d) {
        const r = c.random(0, c.state === 0x134 ? 0x32 : 0x64) & 0xffff;
        if (r < 0xa && c.state > 0x132) {
            d.w04 = 0x1a8;
            const bx = ftol(ch.x) + -ch.facing * 0x3c;
            d.x = bx + (c.random(0, 0x28) & 0xffff);
            const by = ftol(ch.y);
            d.y = by + (c.random(0, 0x3c) & 0xffff) - 0x20;
            d.b20 = 2;
            d.b18 = c.facing;
            d.b21 = 1;
            frameChild(c, d);
        }
    }
    c.a324c[i]--;
    if (!(c.y + c.vy < 0.0) && c.frame > 5 && c.a314c[i] === 0) {
        ch.timer = 0;
        ch.frame = 0x1d;
        c.a314c[i]++;
    }
    if ((c.state < 0x132 || c.state > 0x134) && ch.frame < 0x1d) c.freeChild(i);
    ch.timer++;
    if (c.hitstop > 0) ch.timer--;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame === 0x1d) ch.frame -= 2;
    if (ch.frame >= cnt) c.freeChild(i);
}
function child424(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.timer++;
    if (c.hitstop > 0) ch.timer--;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame >= cnt) c.freeChild(i);
}
registerChildren({
    415: (c, i)=>rushHit(c, i, 0x12f),
    416: (c, i)=>rushHit(c, i, 0x130),
    417: (c, i)=>rushHit(c, i, 0x131),
    418: child418,
    419: child419,
    420: child420,
    421: child421,
    422: child422,
    423: child423,
    424: child424
});
