import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./8eb7102cae7a3c1156bb8cc7.mjs";
import { updateChildrenMisaki } from "./da358c15d9881aea726bad32.mjs";
import { parseCommandMisaki, dispatchMovesMisaki } from "./0598197b975ec9635fb275f4.mjs";
import { thinkMisaki } from "./8e0c2af506ce211f2ad3d421.mjs";
import "./20fc4b71ea9276fe0c3d2b9c.mjs";
import "./98dce4d022e31225e3e705e7.mjs";
import "./3dc234d11b56fa621affc180.mjs";
import "./75f713b8101ff36a36ac13b6.mjs";
const POINTS_X = [
    -13,
    14,
    17,
    7,
    27
];
const POINTS_Y = [
    -60,
    0,
    -6,
    -25,
    -25
];
export class Misaki extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    a3148 = new Int32Array(64);
    a3248 = new Int32Array(64);
    a3348 = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        1,
        11,
        18,
        7,
        0xff,
        0xff,
        0xff
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a3148.fill(0);
        this.a3248.fill(0);
        this.a3348.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3148[i] = 0;
        this.a3248[i] = 0;
        this.a3348[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {}
    parseCommand() {
        parseCommandMisaki(this);
    }
    dispatchMoves() {
        dispatchMovesMisaki(this);
    }
    think() {
        thinkMisaki(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMisaki(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
