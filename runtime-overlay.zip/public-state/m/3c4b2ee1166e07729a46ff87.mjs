import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { frameChild, frameEffect, newSpawnFrame, resetSpawnFrame } from "./a8b80a095bfa4aebc7efbc76.mjs";
import { registerStates } from "./65b7ada33d910b3c78926926.mjs";
import { frameCount, frameDuration, s16 } from "./e2bb73ea5d34f44e96511e06.mjs";
function openFrame() {
    const f = newSpawnFrame();
    resetSpawnFrame(f);
    return f;
}
function rfCost(c) {
    if (c.rfBlue === 0) c.rfGauge = c.rfGauge - 500.0;
    else c.rfGauge = c.rfGauge - 250.0;
}
function effect21(f, x, y) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = x;
    f.y = y - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function landingImpact(c, f) {
    c.shakeScreen(3, 0);
    f.w04 = 3;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y);
    f.b20 = 2;
    f.b21 = 0;
    frameEffect(f);
    c.seRequest = 7;
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.w0dc = 4;
        c.b0de = 0xec;
        c.vx = 0.0;
        c.w16c = 1;
        c.backWindow = 0;
        c.freeze = 0x3c;
        f.w04 = 0x28;
        f.x = Math.trunc(c.x) + c.facing * 10;
        f.y = Math.trunc(c.y) - 0x28;
        f.b20 = 2;
        f.b21 = 1;
        f.b2c = 0x13;
        frameEffect(f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 0 && c.timer === 0) {
        if (c.y === 0.0) c.stopMotion();
        c.w16c = 1;
    }
    if (c.frame === 5 && c.timer === 0) {
        if (c.y === 0.0) {
            f.w04 = 0x1f;
            f.x = c.x;
            f.y = c.y;
            f.d1c = c.facing === -1 ? 1 : 0;
            f.b20 = 0;
            f.b21 = 0;
            frameEffect(f);
        }
        c.vx = 0.5;
        c.vy = -2.5;
        c.ay = 0.03428571428571429;
        c.voiceRequest = 4;
        c.meter = s16(c.meter + 0x1e);
        f.w04 = 0x190;
        f.x = c.facing * 0x28 + c.x;
        f.y = c.y + -54.0;
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
    }
    c.timer++;
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 8 && c.frame > 5) {
        c.frame = 8;
        c.y = 0.0;
        c.stopMotion();
        c.seRequest = 9;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 4) c.d168 = 0;
        if (c.frame === 8 && c.y < 0.0) c.frame -= 2;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 0 && c.timer === 0) {
        if (c.y === 0.0) c.stopMotion();
        rfCost(c);
        effect21(f, Math.trunc(c.x) + c.facing * 0x14, Math.trunc(c.y));
        c.w16c = 2;
    }
    if (c.frame === 5 && c.timer === 0) {
        if (c.y === 0.0) {
            f.w04 = 0x1f;
            f.x = Math.trunc(c.x);
            f.y = Math.trunc(c.y);
            f.b20 = 0;
            f.b21 = 0;
            f.d1c = c.facing !== 1 ? 1 : 0;
            frameEffect(f);
        }
        c.vx = 0.5;
        c.vy = -2.5;
        c.ay = 0.03428571428571429;
        c.voiceRequest = 4;
        c.meter = s16(c.meter + 0x1e);
        f.d00 = 0;
        f.w04 = 0x198;
        f.x = Math.trunc(c.x) + c.facing * 0x28;
        f.y = Math.trunc(c.y) - 0x36;
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
    }
    if (c.y + c.vy > 0.0 && c.frame < 8 && c.frame > 5) {
        c.frame = 8;
        c.y = 0.0;
        c.stopMotion();
        c.seRequest = 9;
    }
    c.timer++;
    c.vy = c.vy + c.ay;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 4) c.d168 = 0;
        if (c.frame === 8 && c.y < 0.0) c.frame -= 2;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx + c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame === 0 && c.timer === 0) {
        c.w16c = 6;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.frame === 2 || c.frame === 3) {
        if (c.pressed[3] === 1 && c.f3138 > 0) {
            c.onStateChange();
            c.state = 0xff;
            return;
        }
        if ((c.pressed[0] === 1 || c.pressed[1] === 1 || c.pressed[2] === 1) && c.f3138 > 0) {
            c.timer = 0;
            c.frame = 4;
            return;
        }
    }
    if (c.frame === 6 && c.timer === 0) {
        c.vx = 2.5;
        c.ax = -0.03;
        c.meter = s16(c.meter + 0x2d);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 4) {
            c.frame = 2;
            c.f3138++;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    c.vx = c.vx + c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame === 0 && c.timer === 0) {
        effect21(f, Math.trunc(c.x) - c.facing * 0x14, Math.trunc(c.y));
        rfCost(c);
        c.w16c = 1;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.frame >= 2 && c.frame <= 3 && c.w16c === 7) {
        c.frame = 4;
        c.timer = 0;
    }
    if (c.frame === 6 && c.timer === 0) {
        c.vx = c.w16c * 0.2 + 1.3;
        c.ax = -0.03;
    }
    if (c.frame === 6 && c.timer === 0) {
        c.vx = 2.5;
        c.ax = -0.03;
        c.meter = s16(c.meter + 0x2d);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 4) {
            c.frame = 2;
            c.w16c = s16(c.w16c + 2);
            return;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function diveAirborne(c, f, cancelTo259) {
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 3) {
        c.y = 0.0;
        c.frame = 7;
        c.timer = 0;
        c.vy = 0.0;
        c.ay = 0.0;
        landingImpact(c, f);
        return true;
    }
    if (cancelTo259 && c.d168 > 0 && c.frame > 3 && c.frame < 7) {
        c.onStateChange();
        c.state = 0x103;
        return true;
    }
    if (c.vy > 0.0 && c.frame === 4) {
        c.timer = 0;
        c.frame = 5;
        c.d168 = 0;
        return true;
    }
    if (c.frame > 6) {
        c.vx = c.vx - 0.02;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    return false;
}
function state256(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.d168 = 3;
        if (c.y === 0.0) {
            c.vx = 0.0;
            c.vy = 0.0;
        }
        c.w16c = 1;
        if (c.y < 0.0) {
            c.frame = 2;
            c.f313c = 1;
        }
    }
    if (diveAirborne(c, f, true)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame > 3) c.d168 = 0;
        if (c.frame === 3) {
            c.meter = s16(c.meter + 0x23);
            c.vx = 1.5;
            c.vy = -3.0;
            c.ay = 0.065;
        }
        if (c.frame >= cnt) {
            c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 0 && c.timer === 0) {
        if (c.y === 0.0) {
            c.vx = 0.0;
            c.vy = 0.0;
        }
        c.w16c = 1;
        if (c.y < 0.0) {
            c.frame = 2;
            c.f313c = 1;
        }
        c.d168 = 3;
    }
    if (diveAirborne(c, f, true)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame > 3) c.d168 = 0;
        if (c.frame === 3) {
            c.meter = s16(c.meter + 0x23);
            c.vx = 1.5;
            c.vy = -4.0;
            c.ay = 0.065;
        }
        if (c.frame >= cnt) {
            c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 0 && c.timer === 0) {
        effect21(f, Math.trunc(c.x), Math.trunc(c.y));
        c.vx = 0.0;
        rfCost(c);
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 0x63;
        if (c.y < 0.0) c.frame = 2;
    }
    if (c.frame === 0 && c.timer === 0) {
        if (c.y === 0.0) {
            c.vx = 0.0;
            c.vy = 0.0;
        }
        c.w16c = 0x63;
        if (c.y < 0.0) {
            c.frame = 2;
            c.f313c = 1;
        }
    }
    if (diveAirborne(c, f, false)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 3) {
            c.meter = s16(c.meter + 0x23);
            c.vx = 1.5;
            c.vy = -4.0;
            c.ay = 0.065;
        }
        if (c.frame === 5) c.frame--;
        if (c.frame === 7) c.frame--;
        if (c.frame >= cnt) {
            c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 9) {
        c.y = 0.0;
        c.seRequest = 9;
        c.onStateChange();
        c.stopMotion();
        c.frame = 9;
        return;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.vx = -c.vx * 0.3;
        if (c.vy > -2.0) c.vy = -2.0;
        if (c.vy < -2.5) c.vy = -2.5;
        c.ay = 0.035;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 9) c.frame -= 2;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
        }
    }
}
function rush(c, speed) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.vx = speed;
        if (c.f3138 === 0) {
            f.w04 = 0x1f;
            f.x = Math.trunc(c.x);
            f.y = Math.trunc(c.y);
            f.b20 = 0;
            f.b21 = 0;
            f.d1c = c.facing === -1 ? 1 : 0;
            frameEffect(f);
        }
    }
    if (c.frame === 6 && c.timer === 0 && c.f3138 === 0) {
        c.w16c = 1;
        c.f3138++;
    }
    if (c.d168 > 1 || c.f3138 > 1) {
        c.onStateChange();
        c.state = 0x107;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.frame = c.frame - 8 & 0xffff;
            c.f3138++;
        }
    }
}
function state260(c) {
    rush(c, 1.7);
}
function state261(c) {
    rush(c, 2.3);
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 0 && c.timer === 0) {
        effect21(f, Math.trunc(c.x), Math.trunc(c.y));
        c.startAfterimage(3);
        c.vx = 0.0;
        rfCost(c);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.timer === 0 && (c.frame === 3 || c.frame === 7)) {
        c.vx = 2.3;
        f.w04 = 0x1f;
        f.x = Math.trunc(c.x);
        f.y = Math.trunc(c.y);
        f.b20 = 0;
        f.b21 = 0;
        f.d1c = c.facing === -1 ? 1 : 0;
        frameEffect(f);
    }
    if (c.frame === 6 && c.timer === 0 && c.f3138 === 0) {
        c.w16c = 1;
        c.f3138++;
    }
    if (c.d168 > 1 || c.f3138 > 2) {
        c.onStateChange();
        c.state = 0x107;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 3) c.w13c = 0x1b;
        if (c.frame >= cnt) {
            c.frame = c.frame - 8 & 0xffff;
            c.f3138++;
        }
    }
}
function state263(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 3 && c.timer === 0) {
        landingImpact(c, f);
        c.w16c = 1;
    }
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 7;
            c.inputY = 1;
            c.state = 3;
        }
    }
}
function state267(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vy = c.vy * 0.25;
        c.vx = c.vx * 0.25;
        if (c.y === 0.0) c.stopMotion();
        rfCost(c);
        effect21(f, Math.trunc(c.x), Math.trunc(c.y));
    }
    if (c.y + c.vy > 0.0 && c.frame < 9 && c.frame > 6) {
        c.frame = 9;
        c.y = 0.0;
        c.stopMotion();
        c.seRequest = 9;
    }
    c.timer++;
    if (c.frame > 5) c.vy = c.vy + c.ay;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 4) c.d168 = 3;
        if (c.frame === 6 && c.timer === 0) {
            c.vx = -0.5;
            c.vy = -2.5;
            c.ay = 0.03428571428571429;
            c.voiceRequest = 4;
            c.meter = s16(c.meter + 0x1e);
            f.d00 = 0;
            f.w04 = 0x199;
            f.x = Math.trunc(c.x) + c.facing * 0x14;
            f.y = Math.trunc(c.y) + 0x1e;
            f.b18 = c.facing;
            f.b21 = 1;
            frameChild(c, f);
        }
        if (c.frame === 9) c.frame -= 2;
        if (c.frame >= cnt) {
            c.state = 7;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
registerStates({
    249: state249,
    250: state250,
    251: state251,
    252: state250,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    267: state267
});
