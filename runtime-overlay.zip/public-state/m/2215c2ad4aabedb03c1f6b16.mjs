import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { gameState } from "./11a8544a0f705ad2a3ee4f96.mjs";
export var State = /*#__PURE__*/ function(State) {
    State[State["Title"] = 0] = "Title";
    State[State["CharacterSelect"] = 1] = "CharacterSelect";
    State[State["Loading"] = 2] = "Loading";
    State[State["Battle"] = 3] = "Battle";
    State[State["Unused"] = 4] = "Unused";
    State[State["Result"] = 5] = "Result";
    State[State["Config"] = 6] = "Config";
    State[State["StaffRoll"] = 7] = "StaffRoll";
    State[State["Replay"] = 8] = "Replay";
    return State;
}({});
export const SCENE_COUNT = 9;
export class SceneMachine {
    scenes = new Array(SCENE_COUNT).fill(null);
    current = 0;
    async tick() {
        gameState.frameParity ^= 1;
        const scene = this.scenes[this.current];
        if (!scene) return;
        this.current = await scene.update() & 0xff;
    }
    dispose() {
        for (const scene of this.scenes)scene?.dispose();
        this.scenes.fill(null);
    }
}

export function __logicState(){return {State};}

export function __installInitialRoots(s){
State=s["State"];
}
