import schemas from "./793982866c2f9ea593ed8df1.mjs";
const need=(v,c)=>{if(!v)throw Error('PUBLIC_SCHEMA_'+c);};
const keys=v=>Object.keys(v).sort();
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
export function publicClassKeys(type){if(!/^(Scene:BattleScene|Actor:(?:[0-9]|1[0-9]|2[0-4]):[01]|Stage:(?:1|10|12|16))$/.test(type))return null;const key=type==='Scene:BattleScene'?'BattleScene':type.replace(/^(Actor:\d+):[01]$/,'$1');return schemas.classes[key]?keys(schemas.classes[key].fields):null;}
export function validatePublicBattleDocument(doc,expectedIdentities){
 need(doc&&Array.isArray(doc.nodes)&&doc.nodes.length<=16384,'DOCUMENT');
 const seen=new Map(),resources=new Set(),actors=[null,null];let edges=0;
 const node=t=>{need(t?.[0]==='ref'&&Number.isSafeInteger(t[1])&&t[1]>=0&&t[1]<doc.nodes.length,'REF');return doc.nodes[t[1]];};
 const prop=(t,k)=>{const p=node(t).props?.find(p=>p[0]===k);need(p,'FIELD '+k);return p[1];};
 const scalar=t=>{if(t[0]==='number'){need(/^[0-9a-f]{16}$/.test(t[1]),'NUMBER');const b=Uint8Array.from(t[1].match(/../g),x=>parseInt(x,16));return new DataView(b.buffer).getFloat64(0,false);}if(['string','boolean'].includes(t[0]))return t[1];if(t[0]==='null')return null;throw Error('PUBLIC_SCHEMA_SCALAR');};
 function unique(t,group){const old=seen.get(t[1]);if(old!==undefined){need(group&&old===group,'ALIAS');return false;}seen.set(t[1],group||true);return true;}
 function visit(t,s,depth=0,classType=null){need(++edges<=131072&&depth<=128,'BOUND');
  if(['number','string','boolean','null','undefined','side'].includes(s.kind)){
   const kind=s.kind==='side'?'number':s.kind;need(t[0]===kind,'SCALAR_TYPE');if(kind==='undefined'||kind==='null')return;
   const v=scalar(t);if(kind==='number'){need(Number.isFinite(v),'FINITE');if(s.integer)need(Number.isSafeInteger(v),'INTEGER');if(s.min!==undefined)need(v>=s.min,'MIN');if(s.max!==undefined)need(v<=s.max,'MAX');if(s.kind==='side')need(v===0||v===1,'SIDE');}if(Object.hasOwn(s,'value'))need(Object.is(v,s.value),'VALUE');return;
  }
  if(s.kind==='asset'){need(t[0]==='cap'&&s.ids.includes(t[1]),'ASSET');resources.add(t[1]);need(resources.size<=8,'RESOURCE_LIMIT');return;}
  if(s.kind==='actor-ref'){
   const n=node(t),match=/^Actor:(\d+):([01])$/.exec(n.type??'');need(n.kind==='class'&&match,'ACTOR');const id=Number(match[1]),side=Number(match[2]);need(id<=24&&(s.side===undefined||s.side===side),'ACTOR_SIDE');
   if(actors[side]!==null){need(actors[side]===t[1],'ACTOR_ALIAS');return;}actors[side]=t[1];visit(t,schemas.classes['Actor:'+id],depth+1,n.type);return;
  }
  if(s.kind==='stage-ref'){if(t[0]==='null'){need(s.nullable,'STAGE_NULL');return;}const n=node(t),match=/^Stage:(\d+)$/.exec(n.type??'');need(n.kind==='class'&&match&&s.ids.includes(Number(match[1])),'STAGE');visit(t,schemas.classes[n.type],depth+1,n.type);return;}
  const n=node(t);if(!unique(t,s.aliasGroup))return;
  if(s.kind==='view'){need(n.kind==='view'&&n.type===s.type&&n.length===s.length&&n.offset===s.byteOffset,'VIEW');const b=node(n.buffer);need(unique(n.buffer)&&b.kind==='buffer'&&b.bytes.length===s.bufferBytes,'BUFFER');return;}
  if(s.kind==='array'){need(n.kind==='array'&&n.length===s.length&&n.props.length===s.length,'ARRAY');const p=new Map(n.props);need(p.size===s.length,'ARRAY_DUP');for(let i=0;i<s.length;i++){need(p.has(String(i)),'ARRAY_HOLE');visit(p.get(String(i)),s.element??s.elements[i],depth+1);}return;}
  need(s.kind==='record','SCHEMA_KIND');need(classType?n.kind==='class'&&n.type===classType:n.kind==='object','RECORD');need(same(n.props.map(x=>x[0]),keys(s.fields)),'FIELDS');for(const [k,v]of n.props)visit(v,s.fields[k],depth+1);
 }
 const root=node(doc.root);need(root.kind==='object'&&same(root.props.map(x=>x[0]),['battle','host','identities','modules','selection','sourceStart','world']),'ROOT');unique(doc.root);
 const idToken=prop(doc.root,'identities'),idsNode=node(idToken);need(idsNode.kind==='object'&&same(idsNode.props.map(x=>x[0]),['adapter','core','metadata','numerics','schema']),'IDENTITY_KEYS');unique(idToken);const identities={};for(const [k,t]of idsNode.props){need(t[0]==='string'&&t[1].length<=256,'IDENTITY');identities[k]=t[1];}need(identities.core===schemas.core,'CORE');if(expectedIdentities)need(same(identities,Object.fromEntries(Object.entries(expectedIdentities).sort())),'IDENTITY_PIN');
 for(const k of ['sourceStart','selection','world','host'])visit(prop(doc.root,k),schemas.roots[k]);
 visit(prop(doc.root,'modules'),{kind:'record',fields:schemas.roots.modules});visit(prop(doc.root,'battle'),schemas.classes.BattleScene,0,'Scene:BattleScene');
 need(seen.size===doc.nodes.length,'UNREACHABLE');
 const sourceStart=scalar(prop(doc.root,'sourceStart')),host=prop(doc.root,'host'),rng=prop(host,'rng');need(sourceStart<=524288&&scalar(prop(host,'completed'))===sourceStart,'CLOCK');need(scalar(prop(rng,'calls'))<=scalar(prop(rng,'recurrences')),'RNG_COUNTER');
 const sel=prop(doc.root,'selection'),selection={};for(const k of ['characters','palettes','usePal'])selection[k]=[0,1].map(i=>scalar(prop(prop(sel,k),String(i))));selection.stage=scalar(prop(sel,'stage'));
 for(let side=0;side<2;side++){const t=['ref',actors[side]];need(scalar(prop(t,'id'))===selection.characters[side]&&scalar(prop(t,'side'))===side&&scalar(prop(t,'color'))===selection.palettes[side],'SELECTION');need(same(prop(t,'opponent'),['ref',actors[1-side]]),'OPPONENT');}
 const bounded=(t,k,max)=>{const v=scalar(prop(t,k));need(Number.isSafeInteger(v)&&v>=0&&v<=max,'INDEX '+k);};
 for(const id of actors){const t=['ref',id];bounded(t,'childHead',63);bounded(t,'childTail',63);bounded(t,'historyIndex',node(prop(t,'history')).length-1);const a=prop(t,'afterimage');bounded(a,'index',node(prop(a,'x')).length-1);bounded(a,'count',node(prop(a,'x')).length);}
 const fx=prop(prop(doc.root,'modules'),'src/game/effects.mjs');bounded(fx,'head',639);bounded(fx,'tail',639);
 const stage=prop(prop(doc.root,'world'),'stageObject');if([1,10,12,16].includes(selection.stage))need(node(stage).type==='Stage:'+selection.stage,'STAGE_SELECTION');else need(stage[0]==='null','STAGE_SELECTION');
 const battle=prop(doc.root,'battle');for(const [k,v]of Object.entries({enterState:1,exit:0,paused:0}))need(scalar(prop(battle,k))===v,'BOUNDARY');
 return {sourceStart,identities,selection,actorNodeIds:actors,resourceIds:[...resources]};
}
