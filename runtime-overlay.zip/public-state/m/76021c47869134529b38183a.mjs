import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { HISTORY_LENGTH, NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
function hist(c, i) {
    return c.history[i - (i >= HISTORY_LENGTH ? 1 : 0) * HISTORY_LENGTH];
}
function buttonCommand(base, v) {
    return base + ((v & 0xe0) > 0 ? 1 : 0) + ((v & 0xc0) > 0 ? 1 : 0) + ((v & 0x80) > 0 ? 1 : 0);
}
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function cancelable(c) {
    return ((c.currentHit()?.defenseFlags ?? 0) & 8) > 0;
}
function priorityOk(c, target) {
    return (c.patterns[c.state]?.hdrB ?? 0) <= (c.patterns[target]?.hdrA ?? 0);
}
function cancelOk(c) {
    if (c.state >= 200 && c.d168 >= 2 && c.d168 !== 6) return true;
    return c.state < 200;
}
function rfOk(c) {
    return c.rfGauge >= 500.0 || c.rfBlue > 0;
}
function enter(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function normalOk(c, target) {
    return priorityOk(c, target) && cancelable(c) && cancelOk(c);
}
function superOk(c, target) {
    return cancelable(c) && cancelOk(c) && priorityOk(c, target);
}
function enterSpecial(c, base, lv2, lv1) {
    enter(c, base);
    if (c.f314c > 5 || c.f3150 > 0) {
        c.state = lv2;
        if (c.f3150 === 0) c.f314c = c.f314c - 1 | 0;
        return;
    }
    if (c.f314c > 2) {
        c.state = lv1;
        if (c.f3150 === 0) c.f314c = c.f314c - 1 | 0;
    }
}
export function parseCommandIkumi(c) {
    c.command = NO_COMMAND;
    const idx = c.historyIndex;
    const end = idx + HISTORY_LENGTH;
    const left = c.facing === -1 ? 1 : 0;
    const BACK = 2 - left;
    const FWD = 1 + left;
    const DOWN_BACK = 6 - left;
    const DOWN_FWD = 5 + left;
    let step;
    let v;
    step = 0;
    for(let i = idx + 0x46; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 9) {
            c.command = 94;
            return;
        }
        if ((v & 0xf) === FWD && step === 8) {
            if (v & 0x40) {
                c.command = 94;
                return;
            }
            step = 9;
        }
        if ((v & 0xf) === DOWN_FWD && step === 7) step = 8;
        if ((v & 0xf) === 4 && step === 6) step = 7;
        if ((v & 0xf) === FWD && step === 5) step = 6;
        if ((v & 0xf) === DOWN_FWD && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x2d; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 7) {
            c.command = buttonCommand(0x96, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x96, v);
                return;
            }
            step = 8;
        }
        if ((v & 0xf) === DOWN_FWD && step === 6) step = 7;
        if ((v & 0xf) === DOWN_BACK && step === 5) step = 6;
        if ((v & 0xf) === BACK && step === 4) step = 5;
        if ((v & 0xf) === FWD && step === 3) step = 4;
        if ((v & 0xf) === DOWN_FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 5) {
            c.command = buttonCommand(0xaa, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 4) {
            if (v & 0xf0) {
                c.command = buttonCommand(0xa0, v);
                return;
            }
            step = 5;
        }
        if ((v & 0xf) === DOWN_FWD && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && (c.meter >= 1000 || c.f315c > 0)) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x6e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x6e, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_BACK && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x46, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x46, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x7d; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x14, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x14, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x7d; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x7d; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x1e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x1e, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0xaf; i < end; i++){
        v = hist(c, i);
        if (v & 8 && step === 1) {
            c.command = 6;
            return;
        }
        if (!(v & 8) && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 4) {
            c.command = 53;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 4) {
            c.command = 52;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 4) {
            c.command = 51;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 4) {
            c.command = 50;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 1 && step === 3) {
            c.command = 1;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 1 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 2 && step === 3) {
            c.command = 0;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 2 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
}
export function dispatchMovesIkumi(c) {
    if (c.state < 200) c.bufferedA = 0;
    if (c.bufferTimer > 0) {
        c.bufferTimer = c.bufferTimer - 1 & 0xff;
    } else {
        c.bufferedB = 0;
    }
    if (c.bufferedB === 0) c.bufferTimer = 0;
    if (c.command === 52 && (c.rfGauge >= 500.0 && c.d168 > 1 || c.rfBlue > 0 && c.d168 > 1 && c.d168 !== 6) && cancelable(c) && priorityOk(c, 167)) {
        enter(c, 167);
        if (c.y < 0.0) c.state = 171;
        return;
    }
    if (c.d15c < 2) {
        if (c.command === 94 && c.meter >= 3000 && c.life < 3333 && cancelable(c) && c.y === 0.0 && c.d168 !== 6 && c.f3150 === 0 && priorityOk(c, 321)) {
            enter(c, 321);
            return;
        }
        if (c.f3150 === 0 && c.command === 112 && c.meter >= 1000 && c.y === 0.0 && superOk(c, 311)) {
            enter(c, 311);
            return;
        }
        if (c.f3150 === 0 && c.command === 111 && c.y === 0.0 && c.meter >= 1000 && superOk(c, 310)) {
            enter(c, 310);
            return;
        }
        if (c.f3150 === 0 && c.command === 110 && c.y === 0.0 && c.meter >= 1000 && superOk(c, 309)) {
            enter(c, 309);
            return;
        }
        if (c.f3150 > 0 && c.command === 172 && c.meter >= 3000 && c.y === 0.0 && superOk(c, 320)) {
            enter(c, 320);
            return;
        }
        if (c.f3150 > 0 && (c.command === 171 || c.command === 172) && c.meter >= 2000 && c.y === 0.0 && superOk(c, 319)) {
            enter(c, 319);
            return;
        }
        if (c.f3150 > 0 && (c.command === 170 || c.command === 171 || c.command === 172) && c.meter >= 1000 && c.y === 0.0 && superOk(c, 318)) {
            enter(c, 318);
            return;
        }
        if ((c.command === 170 || c.command === 171 || c.command === 172) && c.f315c > 0 && c.y === 0.0 && superOk(c, 315)) {
            enter(c, 315);
            if (c.f315c === 2) c.state = 316;
            if (c.f315c === 3) c.state = 317;
            return;
        }
        if (c.command === 172 && c.meter >= 3000 && c.y === 0.0 && superOk(c, 314)) {
            enter(c, 314);
            return;
        }
        if ((c.command === 171 || c.command === 172) && c.meter >= 2000 && c.y === 0.0 && superOk(c, 313)) {
            enter(c, 313);
            return;
        }
        if ((c.command === 170 || c.command === 171 || c.command === 172) && c.meter >= 1000 && c.y === 0.0 && superOk(c, 312)) {
            enter(c, 312);
            return;
        }
        if (c.command === 152 && c.meter >= 3000 && c.y === 0.0 && superOk(c, 307)) {
            enter(c, 307);
            return;
        }
        if ((c.command === 152 || c.command === 151) && c.meter >= 2000 && c.y === 0.0 && superOk(c, 305)) {
            enter(c, 305);
            return;
        }
        if ((c.command === 150 || c.command === 151 || c.command === 152) && c.meter >= 1000 && c.y === 0.0 && superOk(c, 303)) {
            enter(c, 303);
            return;
        }
        if (c.command === 72 && c.y === 0.0 && superOk(c, 263)) {
            enter(c, 263);
            return;
        }
        if (c.command === 22 && rfOk(c) && cancelable(c) && c.y === 0.0 && cancelOk(c) && priorityOk(c, 258)) {
            enterSpecial(c, 258, 277, 273);
            return;
        }
        if ((c.command === 21 || c.command === 22) && cancelable(c) && c.y === 0.0 && cancelOk(c) && priorityOk(c, 257)) {
            enterSpecial(c, 257, 276, 272);
            return;
        }
        if (c.command === 20 && cancelable(c) && c.y === 0.0 && cancelOk(c) && priorityOk(c, 256)) {
            enter(c, 256);
            return;
        }
        if (c.command === 32 && c.y === 0.0 && superOk(c, 252)) {
            enterSpecial(c, 252, 284, 281);
            return;
        }
        if (c.command === 31 && c.y === 0.0 && superOk(c, 251)) {
            enterSpecial(c, 251, 283, 280);
            return;
        }
        if (c.command === 30 && c.y === 0.0 && superOk(c, 250)) {
            enterSpecial(c, 250, 282, 279);
            return;
        }
        if (c.command === 12 && c.y === 0.0 && rfOk(c) && superOk(c, 255)) {
            enterSpecial(c, 255, 270, 267);
            return;
        }
        if ((c.command === 11 || c.command === 12) && c.y === 0.0 && superOk(c, 254)) {
            enterSpecial(c, 254, 269, 266);
            return;
        }
        if (c.command === 10 && c.y === 0.0 && superOk(c, 253)) {
            enter(c, 253);
            return;
        }
    }
    if (c.d15c < 1 && (c.command === 0 || c.command === 1)) {
        const dir = 1 - (c.command << 1);
        if (c.y < 0.0 && c.b159 < 2) {
            const dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 165) && c.state !== 170 && c.y < -40.0 && cancelable(c) && cancelOk(c)) {
                airDash(c, 165);
                return;
            }
            const dx2 = c.opponent.x - c.x;
            if ((dx2 * dir > 0.0 || dx2 === 0.0 && c.facing === dir) && priorityOk(c, 166) && c.state !== 170 && cancelable(c) && cancelOk(c)) {
                airDash(c, 166);
                return;
            }
        }
        if (c.y === 0.0 && cancelable(c)) {
            const dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 163) && cancelOk(c)) {
                if (c.state !== 163) c.onStateChange();
                c.state = 163;
                c.faceOpponent();
                c.b158 = c.b158 + 1 & 0xff;
                c.bufferedA = 0;
                return;
            }
            const dx2 = c.opponent.x - c.x;
            if ((dx2 * dir > 0.0 || dx2 === 0.0 && c.facing === dir) && priorityOk(c, 164) && cancelOk(c)) {
                if (c.state !== 164) c.onStateChange();
                c.state = 164;
                c.faceOpponent();
                c.bufferedA = 0;
                return;
            }
        }
    }
    if (c.d15c < 3 && c.command === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && priorityOk(c, 14) && cancelOk(c)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return;
    }
    if (c.pressed[0] === 1 || c.bufferedA & 0x10 || c.bufferedB & 0x10) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 230);
            if (c.inputY === 1) c.state = 233;
            return;
        }
        if (c.y < 0.0) {
            if (normalOk(c, 207)) enter(c, 207);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 204)) {
            enter(c, 204);
            return;
        }
        if ((c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) && normalOk(c, 200)) {
            enter(c, 200);
            return;
        }
    }
    if (c.pressed[1] === 1 || c.bufferedA & 0x20 || c.bufferedB & 0x20) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 231);
            if (c.inputY === 1) c.state = 234;
            return;
        }
        if (c.y < 0.0) {
            if (normalOk(c, 208)) enter(c, 208);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 205)) {
            enter(c, 205);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (priorityOk(c, 201) && cancelable(c) && c.x - c.opponent.x > -70.0 && c.x - c.opponent.x < 70.0 && cancelOk(c)) {
                enter(c, 201);
                return;
            }
            if (normalOk(c, 202)) {
                enter(c, 202);
                return;
            }
        }
    }
    if (c.pressed[2] === 1 || c.bufferedA & 0x40 || c.bufferedB & 0x40) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 232);
            if (c.inputY === 1) c.state = 235;
            return;
        }
        if (c.y < 0.0) {
            if (c.inputX === c.facing && c.inputY === 0 && c.x - c.opponent.x > -100.0 && c.x - c.opponent.x < 100.0 && c.opponent.y < 0.0 && priorityOk(c, 248) && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 248);
                return;
            }
            if (normalOk(c, 209)) enter(c, 209);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 206)) {
            enter(c, 206);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (c.inputX !== 0 && c.x - c.opponent.x > -30.0 && c.x - c.opponent.x < 30.0 && priorityOk(c, 220) && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 220);
                return;
            }
            if (normalOk(c, 203)) enter(c, 203);
        }
    }
}
function airDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    c.b159 = c.b159 + 1 & 0xff;
    c.b15a = c.b15a + 1 & 0xff;
    c.bufferedA = 0;
}
function frame0(c, pattern) {
    return c.patterns[pattern]?.frames[0];
}
function drawPart(c, f, x, y, w) {
    if (!f) return;
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    const src = makeRect(0, 0, w, f.height);
    const dst = makeRect(x, y, w, f.height);
    blit(dst, surf, src, c.colorKey, false);
}
export function renderOverlayIkumi(c) {
    let f;
    let w;
    if (c.f3150 === 0) {
        f = frame0(c, 43);
        if (f) drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - f.width, 0x1f - f.offsetY, f.width);
    }
    if (c.f3150 > 0) {
        f = frame0(c, 44);
        if (f) drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - f.width, 0x1f - f.offsetY, f.width);
    }
    if (c.f3150 > 0) {
        f = frame0(c, 42);
        if (f) {
            w = Math.trunc(Math.imul(f.width, c.f3150) / 0x4ec);
            drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - w, 0x1f - f.offsetY, w);
        }
    }
    if (c.f3150 !== 0) return;
    f = frame0(c, 38);
    if (f) {
        w = Math.trunc(Math.imul(f.width, c.f3148) / 0x64);
        const x = c.side === 0 ? c.f314c * 8 + 0x32 - f.offsetX : 0x10e - c.f314c * 8 + f.offsetX - w;
        drawPart(c, f, x, 0x1f - f.offsetY, w);
    }
    if (c.f314c <= 0) return;
    for(let k = 0; k < 8; k++){
        if (c.f314c <= k) continue;
        if (c.f314c < 9) f = frame0(c, 41);
        if (c.f314c < 6) f = frame0(c, 40);
        if (c.f314c < 3) f = frame0(c, 39);
        if (!f) continue;
        const x = c.side === 0 ? 0x32 + 8 * k - f.offsetX : f.offsetX + (0x10e - 8 * k) - f.width;
        drawPart(c, f, x, 0x1f - f.offsetY, f.width);
    }
}
