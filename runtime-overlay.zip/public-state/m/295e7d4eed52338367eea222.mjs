import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./e4446f6179e9bf5107313c92.mjs";
import { registerChildren, registerStates } from "./dfcb3299a1af62aa24eb2aa0.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
function advance(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return true;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function rfCostEffect(c, f) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = ftol(c.x);
    f.y = ftol(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function putChild(c, f, pattern, x, y, b18, b20, b21) {
    f.w04 = pattern;
    f.x = x;
    f.y = y;
    f.b18 = b18;
    f.b20 = b20;
    f.b21 = b21;
    frameChild(c, f);
}
function throwTry(c, toState, toFrame) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.ay = 0.035;
        c.state = 249;
        o.state = 100;
        f.w04 = 0;
        f.x = ftol(c.x) + c.facing * 0x23;
        f.y = ftol(c.y) - 0x3a;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        o.x = ftol(c.x) + c.facing * 0x23;
        o.y = ftol(c.y) - 0x3a;
        c.biasCamera(50, 3);
        c.biasCameraY(50, 3);
        return;
    }
    if (!advance(c, dur)) return;
    if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) {
        c.w16c = 1;
    } else {
        c.w16c = 0;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = toState;
        c.frame = toFrame;
    }
}
function state247(c) {
    throwTry(c, 219, 2);
}
function state248(c) {
    throwTry(c, 209, 1);
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame < 6) c.biasCamera(50, 3);
    if (c.frame < 6) c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    if (c.frame > 5) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.state = 13;
        return;
    }
    if (c.frame === 0) {
        o.y = c.y - 35.0;
        o.x = c.x;
        o.state = 100;
    }
    if (c.frame === 1) {
        o.y = c.y - 59.0;
        o.x = c.facing * 0x24 + c.x;
        o.state = 100;
    }
    if (c.frame === 2) {
        o.y = c.y - 60.0;
        o.x = c.facing * 0x23 + c.x;
        o.state = 100;
    }
    if (atFrame(c, 3)) {
        f.w04 = 0;
        f.b2c = 2;
        f.x = ftol(c.x) + c.facing * 0x23;
        f.y = ftol(c.y) - 0x38;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        o.x = c.facing * 0x23 + c.x;
        o.y = c.y - 56.0;
        o.state = 63;
        o.knockX = -2.5;
        o.knockY = -0.5;
        o.ay = 0.035;
        o.x = c.facing * 0xf + c.x;
        applyDirectDamage(c, 1000, 500.0);
        o.hitstun = s16(ftol(200.0 * c.proration * 0.0001));
        o.onStateChange();
        putChild(c, f, 450, ftol(c.x) + c.facing * 0x23, ftol(c.y) - 0x38, c.facing, 0, 1);
        f.w04 = 451;
        frameChild(c, f);
        f.w04 = 452;
        frameChild(c, f);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) c.frame = c.frame - 2;
}
function jumpBody(c, dur, cnt, jumpVy, jumpAy, fallAy) {
    if (c.frame > 1 && c.frame < 9) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 9) {
        c.onStateChange();
        c.frame = 9;
    }
    if (atFrame(c, 9)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
    }
    if (!advance(c, dur)) return;
    if (c.frame === 2) {
        c.vy = jumpVy;
        c.ay = jumpAy;
        c.x = c.facing * 0xa + c.x;
    }
    if (c.vy > 0.0 && c.frame === 5) {
        if (fallAy !== null) c.ay = fallAy;
        c.frame = 6;
        return;
    }
    if (c.frame === 6) c.frame = c.frame - 4;
    if (c.frame === 9) c.frame = c.frame - 2;
    if (c.frame >= cnt) {
        c.onStateChange();
        c.stopMotion();
        c.state = 0;
    }
    c.d168 = 0;
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.w16c = 8;
    }
    jumpBody(c, dur, cnt, -1.8, 0.025, null);
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.w16c = 12;
    }
    jumpBody(c, dur, cnt, -2.8, 0.025, null);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        rfCostEffect(c, f);
        c.stopMotion();
        c.w16c = 20;
    }
    if (atFrame(c, 1)) {
        putChild(c, f, 445, ftol(c.x), ftol(c.y) - 0x32, -c.facing, 2, 1);
    }
    jumpBody(c, dur, cnt, -2.8, 0.015, 0.025);
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.y + c.vy > 0.0 && c.frame < 3) {
        c.onStateChange();
        c.frame = 3;
    }
    if (atFrame(c, 3)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
    }
    if (c.y < 0.0) c.vy = c.vy + 0.025;
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 3) c.frame = c.frame - 2;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function standDerive(c, to10) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 0)) c.w16c = 1;
    if (c.d168 > 1 && c.command === 10 && c.frame === 6) {
        c.state = to10;
        c.d168 = 0;
        c.onStateChange();
        return;
    }
    if (c.command === 11 && c.frame === 6) {
        c.state = 273;
        c.d168 = 0;
        c.onStateChange();
        return;
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state254(c) {
    standDerive(c, 256);
}
function state271(c) {
    standDerive(c, 272);
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 0)) {
        c.w16c = 1;
        rfCostEffect(c, f);
    }
    if (atFrame(c, 3)) {
        const ys = [
            0x5f,
            0x50,
            0x41,
            0x32,
            0x23,
            0x14,
            5
        ];
        for(let k = 0; k < ys.length; k++){
            putChild(c, f, k % 2 === 0 ? 448 : 449, ftol(c.x) + c.facing * 0x1e, ftol(c.y) - ys[k], c.facing, 2, 1);
        }
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function spawn407(c, f) {
    const dx = [
        0x8a,
        0x64,
        0x3e,
        0x18
    ];
    for(let k = 0; k < 4; k++){
        if (atFrame(c, k)) putChild(c, f, 407, ftol(c.x) + c.facing * dx[k], ftol(c.y) - 0x32, c.facing, 2, 1);
    }
}
function state256(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.seRequest = 20;
        c.meter = s16(c.meter + 10);
        c.w16c = 3;
    }
    spawn407(c, f);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.seRequest = 20;
        c.meter = s16(c.meter + 35);
        c.w16c = 1;
    }
    if (atFrame(c, 1)) putChild(c, f, 408, ftol(c.x) - c.facing * 9, ftol(c.y) - 0x3a, c.facing, 0, 1);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state272(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.seRequest = 20;
        c.meter = s16(c.meter + 10);
        c.w16c = 5;
    }
    spawn407(c, f);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 7) putChild(c, f, 408, ftol(c.x) - c.facing * 9, ftol(c.y) - 0x3a, c.facing, 0, 1);
    if (c.frame === 8) {
        c.w16c = 1;
        c.seRequest = 21;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state273(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.meter = s16(c.meter + 10);
        f.d00 = 1;
        putChild(c, f, 456, ftol(c.x) + c.facing * 0x1e, ftol(c.y) - 0x30, c.facing, 2, 1);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function dashBody(c, dur, cnt, landVx, upVy, loop) {
    if (c.frame === 2 && c.y + c.vy >= 0.0 && c.vy > 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
        c.vx = landVx;
        c.frame = 3;
        c.timer = 0;
    }
    if (c.frame > 2) {
        c.vx = c.vx - 0.015;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.vy = c.vy + 0.042;
    if (c.vy > 0.0 && c.y >= 0.0) c.vy = 0.0;
    if (!advance(c, dur)) return;
    if (c.w16c > 0) c.d168 = 0;
    if (c.frame === 1) {
        c.vx = 0.3;
        c.vy = upVy;
        c.voiceRequest = 1;
    }
    if (c.frame === 5 && c.vx > 0.8) c.frame = c.frame - 2;
    if (loop && c.frame === 7 && c.f3138 < 5) {
        c.frame = c.frame - 2;
        c.f3138++;
        c.w16c = s16(c.w16c + 2);
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atFrame(c, 0)) {
        c.vx = 0.0;
        c.b158 = 0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 4;
    }
    dashBody(c, dur, cnt, 1.7, -0.9, false);
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 10;
    }
    dashBody(c, dur, cnt, 2.4, -1.2, false);
}
function state260(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        rfCostEffect(c, f);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 10;
    }
    dashBody(c, dur, cnt, 2.4, -1.2, true);
}
function floatBody(c, f, dur, cnt, p) {
    if (c.f3148 > 2.5) c.f3140 = -p.swing;
    if (c.f3148 < 0.0) c.f3140 = p.swing;
    c.f3148 = c.f3148 + c.f3140;
    if (atFrame(c, 3)) {
        c.meter = s16(c.meter + 25);
        c.f3138 = 0;
        c.f3140 = 0.05;
        c.vy = -1.1;
        if (p.halveVx) {
            c.vx = c.vx * 0.5;
        } else {
            c.vx = 0.0;
        }
    }
    if (c.frame > 2 && c.frame < 8) c.vy = c.vy + 0.022;
    if (c.frame === 8 || c.frame === 9) {
        c.vy = c.vy + p.fallAcc;
        if (c.vy > p.fallMax) c.vy = p.fallMax;
    }
    if (atFrame(c, 8) && c.f3138 < p.spawnMax) {
        putChild(c, f, p.child, ftol(c.x) + c.facing * 0x3c, ftol(c.y) - 0x2f, c.facing, 2, 1);
    }
    if ((c.frame === 8 || c.frame === 9) && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.timer = 0;
        c.frame = 10;
        c.stopMotion();
    }
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame === 8) {
        c.voiceRequest = 3;
        if (p.kickVx !== null) c.vx = c.vx - p.kickVx;
        c.vy = c.vy - p.kickVy;
    }
    if (c.frame === 10 && c.f3138 < p.loopMax) {
        c.f3138++;
        c.frame = c.frame - 2;
    }
    if (c.frame === 11 && c.y < 0.0) {
        c.state = 9;
        c.onStateChange();
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.stopMotion();
    }
    floatBody(c, f, dur, cnt, {
        swing: 0.06,
        halveVx: false,
        fallAcc: 0.012,
        fallMax: 0.8,
        child: 404,
        spawnMax: 7,
        kickVx: null,
        kickVy: 0.4,
        loopMax: 16
    });
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.stopMotion();
    }
    floatBody(c, f, dur, cnt, {
        swing: 0.06,
        halveVx: true,
        fallAcc: 0.012,
        fallMax: 0.8,
        child: 404,
        spawnMax: 12,
        kickVx: 0.5,
        kickVy: 0.9,
        loopMax: 24
    });
}
function state263(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        rfCostEffect(c, f);
        c.stopMotion();
    }
    if (atFrame(c, 3) && c.f3138 === 100) {
        rfCostEffect(c, f);
        c.f3138 = 0;
    }
    floatBody(c, f, dur, cnt, {
        swing: 0.08,
        halveVx: true,
        fallAcc: 0.008,
        fallMax: 0.6,
        child: 444,
        spawnMax: 16,
        kickVx: 0.5,
        kickVy: 0.4,
        loopMax: 13
    });
}
function shot405(c, f, pattern, meter) {
    c.voiceRequest = 4;
    c.meter = s16(c.meter + meter);
    putChild(c, f, pattern, ftol(c.x) + c.facing * 0x1d, ftol(c.y) - 0x32, c.facing, 0, 1);
}
function shotAdvance(c, dur, cnt) {
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (atFrame(c, 6)) shot405(c, f, 405, 25);
    shotAdvance(c, dur, cnt);
}
function state265(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (atFrame(c, 6)) shot405(c, f, 405, 15);
    if (atFrame(c, 13)) shot405(c, f, 405, 15);
    shotAdvance(c, dur, cnt);
}
function state266(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        rfCostEffect(c, f);
        c.stopMotion();
        c.facing = -c.facing;
    }
    if (atFrame(c, 6)) shot405(c, f, 406, 25);
    shotAdvance(c, dur, cnt);
}
function pillarState(c, dx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (atFrame(c, 3)) {
        c.voiceRequest = 4;
        c.meter = s16(c.meter + 25);
        f.d00 = 1;
        putChild(c, f, 453, ftol(c.x) + c.facing * dx, -3.0, c.facing, 0, 0);
    }
    shotAdvance(c, dur, cnt);
}
function state267(c) {
    pillarState(c, 0x58);
}
function state268(c) {
    pillarState(c, 0x80);
}
function state269(c) {
    pillarState(c, 0xbc);
}
function state270(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atFrame(c, 0)) c.stopMotion();
    c.b158 = 0;
    if (atFrame(c, 4)) {
        if (c.f3150 === 0) {
            c.f3150 = 1;
            c.timer++;
            return;
        }
        c.f3150 = 0;
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function stanceSuper(c, stance) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.stopMotion();
        c.freeze = 120;
        c.meter = s16(c.meter - 1000);
        c.superDarken(0xb0, 3);
        f.w04 = 9;
        f.b2c = 5;
        f.x = ftol(c.x);
        f.y = ftol(c.y) - 0x28;
        f.b20 = 2;
        f.d00 = 1;
        f.b21 = 1;
        frameEffect(f);
        c.f3150 = stance;
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state300(c) {
    stanceSuper(c, 1);
}
function state301(c) {
    stanceSuper(c, 0);
}
function rainBody(c, f, dur, cnt, p) {
    const o = c.opponent;
    if (c.d168 === 3 && c.f3138 === 0 && c.frame === 3) {
        o.hitstop = s16(o.hitstop + 120);
        c.f3138++;
    }
    if (c.frame === p.rainFrame && c.timer < p.rainTimer) {
        c.d168 = 3;
        let pattern = -1;
        if (c.random(0, 100) < p.t411) {
            pattern = 411;
        } else if (c.random(0, 100) < p.t413) {
            pattern = 413;
        } else if (c.random(0, 100) < p.t412) {
            pattern = 412;
        }
        if (pattern >= 0) {
            f.w04 = pattern;
            f.x = ftol((c.random(0, 150) - 60) * c.facing + c.x);
            f.y = -480.0;
            f.b18 = 1;
            f.b21 = 1;
            f.b20 = 0;
            frameChild(c, f);
            return;
        }
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function rainStart(c, f, cost, effect, sound) {
    c.freeze = 120;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
    f.w04 = effect;
    f.b2c = sound;
    f.x = ftol(c.x);
    f.y = ftol(c.y) - 0x28;
    f.b20 = 2;
    f.d00 = 1;
    f.b21 = 1;
    frameEffect(f);
}
function state303(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 1;
    }
    if (atFrame(c, 4)) rainStart(c, f, 1000, 68, 19);
    rainBody(c, f, dur, cnt, {
        rainFrame: 5,
        rainTimer: 100,
        t411: 1,
        t413: 3,
        t412: 7
    });
}
function state304(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 1;
    }
    if (atFrame(c, 4)) rainStart(c, f, 2000, 69, 5);
    rainBody(c, f, dur, cnt, {
        rainFrame: 5,
        rainTimer: 145,
        t411: 2,
        t413: 3,
        t412: 6
    });
}
function state305(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atFrame(c, 0)) c.stopMotion();
    c.b158 = 0;
    if (atFrame(c, 2)) {
        c.w16c = 1;
        rainStart(c, f, 3000, 70, 64);
        c.seRequest = 37;
    }
    if (c.frame > 1) c.showAltBackground(15);
    rainBody(c, f, dur, cnt, {
        rainFrame: 4,
        rainTimer: 200,
        t411: 3,
        t413: 4,
        t412: 6
    });
}
registerStates({
    247: state247,
    248: state248,
    249: state249,
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    265: state265,
    266: state266,
    267: state267,
    268: state268,
    269: state269,
    270: state270,
    271: state271,
    272: state272,
    273: state273,
    300: state300,
    301: state301,
    303: state303,
    304: state304,
    305: state305
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childAdvanceFree(c, i) {
    if (childAdvance(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function putChildC(c, pattern, x, y, b18, b20, b21) {
    const f = childSpawnFrame;
    f.w04 = pattern;
    f.x = x;
    f.y = y;
    f.b18 = b18;
    f.b20 = b20;
    f.b21 = b21;
    frameChild(c, f);
}
function child404(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vy = c.random(0, 10) * 0.1 + 1.5;
        ch.vx = 2.1 - c.random(0, 5) * 0.1;
    }
    ch.vx = ch.vx - 0.02;
    if (ch.vx < 0.1) ch.vx = 0.1;
    ch.vy = ch.vy - 0.02;
    childAdvanceFree(c, i);
}
function child405(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = 6.0;
        ch.vy = 0.0;
    }
    if (ch.frame === 1) ch.vy = ch.vy + 0.04;
    ch.timer++;
    if (ch.hitState === 3 && ch.frame === 0) {
        ch.vx = 0.0;
        ch.frame = 2;
        ch.timer = 0;
        c.voiceRequest = 5;
        c.opponent.hitstop = s16(c.opponent.hitstop + 60);
        ch.hitState = 0;
        return;
    }
    if (ch.hitState > 1) {
        ch.vx = -1.0;
        ch.vy = -2.0;
        ch.frame = 1;
        ch.timer = 0;
        ch.hitState = 0;
        return;
    }
    childAdvanceFree(c, i);
    if (ch.x < -100.0 || ch.x > 800.0 || ch.y > 30.0) c.freeChild(i);
}
function child406(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = 6.0;
        ch.vy = 0.0;
    }
    if (ch.frame === 0 && (ch.x < -960.0 || ch.x > 1640.0)) {
        ch.frame = 1;
        ch.x = -ch.x;
    }
    if (ch.frame === 2) ch.vy = ch.vy + 0.04;
    ch.timer++;
    if (ch.hitState === 3 && ch.frame <= 1) {
        ch.vx = 0.0;
        ch.frame = 3;
        ch.timer = 0;
        c.voiceRequest = 5;
        c.opponent.hitstop = s16(c.opponent.hitstop + 60);
        ch.hitState = 0;
        return;
    }
    if (ch.hitState > 1) {
        ch.vx = -1.0;
        ch.vy = -2.0;
        ch.frame = 2;
        ch.timer = 0;
        ch.hitState = 0;
        return;
    }
    childAdvanceFree(c, i);
    if (ch.frame > 0 && (ch.x < -2000.0 || ch.x > 2000.0 || ch.y > 30.0)) c.freeChild(i);
}
function child407(c, i) {
    childAdvanceFree(c, i);
}
function child408(c, i) {
    const ch = c.children[i];
    ch.vx = ch.vx - 0.05;
    ch.vy = ch.vy - 0.02;
    if (childAdvance(c, i) && ch.frame >= childCount) ch.frame = ch.frame - 2;
    if (ch.x < -100.0 || ch.x > 800.0 || ch.y > 0.0) c.freeChild(i);
}
function child409(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    childAdvanceFree(c, i);
}
function child410(c, i) {
    const ch = c.children[i];
    if (ch.frame === 2 && ch.timer === 0) {
        ch.hitsLeft = 1;
        childSpawnFrame.d00 = 1;
        if (ch.y < -190.0) {
            putChildC(c, 410, ftol(ch.x), ftol(ch.y) + 0xa0, c.facing, 2, 1);
        } else {
            putChildC(c, 409, ftol(ch.x), 0.0, c.facing, 2, 1);
        }
    }
    childAdvanceFree(c, i);
}
function child411(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    ch.vy = ch.vy + 0.045;
    childAdvanceFree(c, i);
    if (ch.y > 100.0) c.freeChild(i);
}
function child412(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    ch.vy = ch.vy + 0.035;
    if ((ch.hitState > 1 || ch.y > 0.0) && c.a3158[i] === 0) {
        c.voiceRequest = 7;
        ch.hitsLeft = 0;
        c.a3158[i]++;
        ch.vy = -1.5;
    }
    childAdvanceFree(c, i);
    if (ch.y > 100.0) c.freeChild(i);
}
function child413(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    ch.vy = ch.vy + 0.04;
    if ((ch.hitState > 1 || ch.y > 0.0) && ch.frame === 0) {
        c.seRequest = 1;
        ch.hitsLeft = 0;
        ch.frame++;
        ch.vy = -1.5;
        putChildC(c, 414, ftol(ch.x), ftol(ch.y) - 0xf, c.facing, 0, 1);
        putChildC(c, 415, ftol(ch.x), ftol(ch.y) + 0xf, c.facing, 0, 1);
        putChildC(c, 416, ftol(ch.x) + 0xf, ftol(ch.y), c.facing, 0, 1);
        putChildC(c, 417, ftol(ch.x) - 0xf, ftol(ch.y), c.facing, 0, 1);
    }
    childAdvanceFree(c, i);
    if (ch.y > 100.0) c.freeChild(i);
}
function shardChild(c, i, baseVy, baseVx) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vy = c.random(0, 10) * 0.1 + baseVy;
        ch.vx = c.random(0, 10) * 0.1 + baseVx;
    }
    ch.vy = ch.vy + 0.04;
    childAdvanceFree(c, i);
    if (ch.y > 100.0) c.freeChild(i);
}
function child414(c, i) {
    shardChild(c, i, -1.0, 0.5);
}
function child415(c, i) {
    shardChild(c, i, -1.3, 0.9);
}
function child416(c, i) {
    shardChild(c, i, -1.0, -0.5);
}
function child417(c, i) {
    shardChild(c, i, -0.8, -0.9);
}
function child422(c, i) {
    const ch = c.children[i];
    if (ch.frame === 3 && ch.timer === 30 && ch.y === 0.0) {
        childSpawnFrame.d00 = 1;
        c.voiceRequest = 6;
        putChildC(c, 410, ftol(ch.x) - ch.facing * 0xf, -556.0, c.facing, 2, 1);
    }
    if (ch.frame === 3 && ch.timer === 39 && ch.y === 0.0) {
        childSpawnFrame.d00 = 1;
        c.voiceRequest = 6;
        putChildC(c, 410, ftol(ch.x) + ch.facing * 6, -564.0, c.facing, 2, 1);
    }
    if (ch.frame === 3 && ch.timer === 48 && ch.y === 0.0) {
        childSpawnFrame.d00 = 1;
        c.voiceRequest = 6;
        putChildC(c, 410, ftol(ch.x) - ch.facing * 0x24, -560.0, c.facing, 2, 1);
    }
    childAdvanceFree(c, i);
}
function child444(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vy = c.f3148;
        ch.vx = 2.8 - c.f3148 / 2.0;
    }
    ch.vx = ch.vx - 0.02;
    if (ch.vx < 0.1) ch.vx = 0.1;
    ch.vy = ch.vy - 0.02;
    childAdvanceFree(c, i);
}
function child445(c, i) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y - 50.0;
    if (c.state !== 252 || c.frame > 5) {
        c.freeChild(i);
        return;
    }
    if (childAdvance(c, i) && ch.frame >= childCount) ch.frame = 7;
}
function childPlain(c, i) {
    childAdvanceFree(c, i);
}
function debrisChild(c, i, vx, vy) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        c.a3158[i]++;
        ch.vx = vx;
        ch.vy = vy;
    }
    ch.vy = ch.vy + 0.05;
    if (ch.y > 100.0) {
        c.freeChild(i);
        return;
    }
    if (childAdvance(c, i) && ch.frame >= childCount) ch.frame = ch.frame - 1;
}
function child450(c, i) {
    debrisChild(c, i, 0.5, -1.8);
}
function child452(c, i) {
    debrisChild(c, i, 0.4, -1.7);
}
function child453(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        childSpawnFrame.d00 = 1;
        putChildC(c, 422, ftol(ch.x), -3.0, c.facing, 0, 0);
    }
    if (ch.frame === 1 && ch.timer === 0) {
        childSpawnFrame.d00 = 1;
        putChildC(c, 422, ftol(ch.x) + c.facing * 0x1b, 0.0, c.facing, 0, 0);
    }
    if (ch.frame === 2 && ch.timer === 0) {
        childSpawnFrame.d00 = 1;
        putChildC(c, 422, ftol(ch.x) + c.facing * 9, 4.0, c.facing, 0, 0);
    }
    childAdvanceFree(c, i);
}
function child456(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 1.5;
        c.a3158[i] = 0;
        ch.hitsLeft = 1;
    }
    if (ch.frame === 1 && ch.timer === 0) {
        const x = ftol(ch.x) + 0x1e - c.random(0, 0x50);
        const y = ftol(ch.y) + 0x14 - c.random(0, 0x28);
        putChildC(c, 455, x, y, c.facing, 2, 1);
        c.seRequest = 1;
    }
    if (!childAdvance(c, i) || ch.frame < childCount) return;
    if (c.a3158[i] < 6) {
        c.a3158[i]++;
        ch.frame = 1;
        ch.hitsLeft = 1;
        ch.hitState = 0;
        return;
    }
    c.freeChild(i);
}
registerChildren({
    404: child404,
    405: child405,
    406: child406,
    407: child407,
    408: child408,
    409: child409,
    410: child410,
    411: child411,
    412: child412,
    413: child413,
    414: child414,
    415: child415,
    416: child416,
    417: child417,
    422: child422,
    444: child444,
    445: child445,
    448: childPlain,
    449: childPlain,
    450: child450,
    451: childPlain,
    452: child452,
    453: child453,
    455: childPlain,
    456: child456
});
