import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
function chance2(c) {
    const r = rnd(c, 0, 100);
    return c.aiLevel + c.aiLevel > r;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = rnd(c, 0, 2) - 1;
}
function dashCommand(c) {
    return c.facing === 1 ? 1 : 0;
}
export function thinkNayuki(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25.0 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 170 ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 149 && c.state < 157 ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40.0 * c.aiLevel > r && c.state > 199) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 200) c.aiMode = 0;
        return;
    }
    if (o.state === 96) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 50 && c.state <= 150 && c.timer === 0) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 50 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 240) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 320) < dx ? 1 : 0;
        if (o.state > 199 && o.state < 250 && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 10 && c.state <= 12) && c.y === 0.0) return;
    if (o.state >= 50 && o.state < 150 && c.state === 264 && c.w16c > 1) return;
    if (c.state === 168 && c.timer < 6) {
        if (o.state !== 200 && o.state !== 204 && o.state < 250 && o.y === 0.0 && o.w16c === 0 && dx < 60.0 && chance(c, 3.0)) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return;
        }
        if ((o.state === 201 || o.state === 202 || o.state === 205) && o.state < 250 && o.y === 0.0 && o.w16c === 0 && dx > 40.0 && dx < 80.0 && chance2(c)) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return;
        }
    }
    if (c.state === 168 || c.state === 169) {
        if (dx < 100.0) {
            if (chance(c, 3.0) && c.rfGauge > 500.0) {
                c.command = 72;
                return;
            }
            if (chance(c, 3.0) && c.rfGauge > 500.0) {
                c.command = 22;
                return;
            }
            if (chance2(c) && c.rfGauge > 500.0) {
                c.command = 12;
                return;
            }
            if (chance(c, 1.0) && c.meter === 3000) {
                c.command = 97;
                return;
            }
        }
        if (dx < 220.0) {
            if (chance2(c) && c.rfGauge > 500.0) {
                c.command = 72;
                return;
            }
            if (chance2(c) && c.rfGauge > 500.0) {
                c.command = 12;
                return;
            }
        }
    }
    if (c.state === 170 && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5.0)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y > -40.0 && c.y - o.y < 40.0 && dx < 60.0 && chance(c, 5.0)) {
            c.pressed[0] = 1;
            return;
        }
        if (dy < 50.0 && dx < 50.0 && chance(c, 5.0)) {
            c.pressed[1] = 1;
            return;
        }
        if (dy < 50.0 && dx < 130.0 && chance(c, 5.0)) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y === 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 4 && c.rfGauge > 500.0) {
            c.command = 72;
            return;
        }
        if (c.aiRoll < 10 && c.rfGauge > 500.0) {
            c.command = 22;
            return;
        }
        if (c.aiRoll < 13 && c.rfGauge > 500.0) {
            c.command = 12;
            return;
        }
        if (c.aiRoll < 17 && c.aiRoll > 12 && c.meter >= 1000) {
            c.command = rnd(c, 0, 2) * 110;
            return;
        }
        if (c.aiRoll < 16 && c.aiRoll > 18 && c.meter === 3000) {
            c.command = 97;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y < 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 60) {
            c.aiMode = 2;
            return;
        }
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 8.0 * c.aiLevel > rnd(c, 0, 100) && o.state > 149 && o.state < 157 && (c.state === 260 || c.state === 261 || c.state === 262 || c.state === 261 || c.state === 264 || c.state === 265)) {
        c.command = 52;
        return;
    }
    if (c.state === 165 || c.state === 166) c.pressed[0] = 1;
    if (c.aiMode > 0 && c.state > 49 && c.state < 158) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 200) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = rnd(c, 0, 2) - 1;
        if ((c.state === 4 || c.state === 5 || c.state === 6) && (c.y < -60.0 || c.f3148 > 6)) {
            c.command = dashCommand(c);
            if (c.state === 165) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 50) {
        c.aiMode = 6;
        return;
    }
    if (c.aiMode === 6 && c.state === 9) {
        if (c.state === 208) c.aiMode = 0;
        c.pressed[1] = 1;
        return;
    }
    if (c.aiMode === 7 && c.state < 50) {
        c.aiMode = 8;
        return;
    }
    if (c.aiMode === 8 && c.state === 9) {
        if (c.state === 207) c.aiMode = 0;
        c.pressed[0] = 1;
        return;
    }
    if (c.aiMode === 9 && c.state < 50) {
        c.inputY = 1;
        c.pressed[2] = 1;
        if (c.state === 206) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 10 && c.state < 50) {
        c.inputY = 0;
        c.pressed[2] = 1;
        if (c.state === 203) c.aiMode = 0;
        return;
    }
    if ((c.state === 250 || c.state === 252) && o.state > 49 && o.state < 157) {
        if (c.aiRoll < 300 && o.y === 0.0) {
            c.aiMode = 7;
            return;
        }
        if (c.aiRoll > 300 && c.aiRoll < 450 && o.y === 0.0) {
            c.aiMode = 4;
            return;
        }
        if (c.aiRoll > 450 && c.aiRoll < 550 && o.y < 0.0 && dx < 60.0) {
            c.aiMode = 9;
            return;
        }
        if (c.aiRoll > 550 && c.aiRoll < 650 && o.y < 0.0 && dx < 100.0) {
            c.aiMode = 10;
            return;
        }
    }
    if (c.state === 268) {
        if (c.aiRoll < 300 && dx < 120.0 && (o.state > 199 || o.y < 0.0)) {
            c.pressed[0] = 1;
            return;
        }
        if (c.aiRoll < 450 && c.aiRoll > 300 && o.y === 0.0 && dx < 160.0) {
            c.pressed[1] = 1;
            return;
        }
        if (c.aiRoll < 600 && c.aiRoll > 450 && o.y === 0.0 && dx < 100.0) {
            c.pressed[2] = 1;
            return;
        }
        if (c.aiRoll < 650 && c.aiRoll > 600 && o.y === 0.0 && c.f3148 < 9) {
            c.pressed[3] = 1;
            return;
        }
    }
    if (c.d168 > 1 && c.hitstop === 0 && c.aiLevel * 25.0 > rnd(c, 0, 100) && c.aiMode === 0 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (comboNayuki(c, dx, dy)) return;
    }
    if (25.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        const roll = c.aiRoll;
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 99) {
                if (dx < 40.0 && o.y === 0.0 && roll < 5) {
                    c.pressed[2] = 1;
                    c.inputX = -c.facing;
                    c.inputY = 0;
                    return;
                }
                if (dx < 35.0 && roll < 15) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 50.0 && roll < 30) {
                    c.pressed[0] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 90.0 && dx > 60.0 && roll < 75 && roll < 30) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 150.0 && 70 - (c.f3148 > 6 ? 1 : 0) * 20 < dx && roll < 135 && roll < 75) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 150.0 && 70 - (c.f3148 > 6 ? 1 : 0) * 20 < dx && roll < 135 && roll < 160 && c.f3148 > 2) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 150.0 && dx > 90.0 && roll < 240 && roll > 160) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 260.0 && dx > 100.0 && roll < 340 && roll > 300) {
                    c.command = rnd(c, 0, 3) + 10;
                    return;
                }
                if (dx < 200.0 && dx > 70.0 && roll < c.f3148 * 5 + 360 && roll > 350) {
                    c.command = rnd(c, 0, 3) + 70;
                    return;
                }
                if (dx < 200.0 && dx > 70.0 && roll < c.f3148 * 5 + 420 && roll > 410 && c.f3148 > 3 && c.rfGauge > 500.0) {
                    c.command = 21;
                    return;
                }
                if (dx < 200.0 && dx < 100.0 && roll < c.f3148 + c.f3148 + 480 && roll > 470 && c.rfGauge > 500.0 && o.state > 199) {
                    c.command = 72;
                    return;
                }
                if (dx < 200.0 && dx < 70.0 && roll < c.f3148 + c.f3148 + 510 && roll > 500 && c.rfGauge > 500.0 && o.state > 199) {
                    c.command = 22;
                    return;
                }
                if (roll > 530) {
                    const a = o.state > 58 && o.state < 100 && o.state !== 96 ? 1 : 0;
                    const b = o.state > 95 && o.state < 100 && o.state !== 96 ? 1 : 0;
                    const d = dx > 180.0 ? 1 : 0;
                    if (roll < a * 150 + b * 300 + 530 + d * 20 && c.f3148 < 9) {
                        c.pressed[3] = 1;
                        return;
                    }
                }
                if (roll < 42 && roll > 47) {
                    c.command = c.facing & 0xffff;
                    c.aiMode = 5;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 120.0 && roll < 10) {
                        c.inputY = -1;
                        c.inputX = -c.facing;
                        return;
                    }
                    if (dx < 80.0 && dy < 70.0 && roll < 20) {
                        c.pressed[2] = 1;
                        c.inputY = 1;
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 70.0 && dy > 40.0 && dy < 90.0 && roll < 50 && (c.rfGauge > 500.0 || c.rfBlue > 0)) {
                        c.command = 20;
                        return;
                    }
                    if (dx < 80.0 && dy < 150.0 && dy > 80.0 && roll < 90) {
                        c.pressed[2] = 1;
                        c.inputY = 1;
                        return;
                    }
                    if (dx < 150.0 && dx > 100.0 && dy < 120.0 && dy > 90.0 && roll < 110 && roll > 90) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 70.0 && dy < 50.0 && roll < 200) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 70.0 && dy < 100.0 && roll < (o.y === 0.0 ? 1 : 0) * 100 + 250) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 110.0 && dy > 60.0 && dy < 80.0 && c.vy > 0.0 && o.y > c.y && roll > 500 && roll < 620) {
                    c.pressed[2] = 1;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 60.0 && dy > 60.0 && roll < 110) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 150.0 && dx > 100.0 && dy < 80.0 && o.y < c.y && roll < 250 && roll > 110) {
                    c.pressed[2] = 1;
                    return;
                }
            }
        }
    }
    if (c.state < 50 && (o.state > 149 && o.state < 156 || o.state > 49 && o.state < 59) && c.y === 0.0 && 3.0 * c.aiLevel > rnd(c, 0, 100)) {
        if (dx < 150.0) c.command = dashCommand(c);
        return;
    }
    if (c.state < 50 && c.y === 0.0 && 1.0 * c.aiLevel > rnd(c, 0, 100) && dx > 80.0 && dx < 160.0) {
        if (dx < 150.0) c.command = dashCommand(c);
        return;
    }
    if (rnd(c, 0, 1000) < 2) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 4.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 240.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 80.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 140.0 && dx > 100.0 && c.y === 0.0) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 15) c.aiTimer1a0 = 15;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 15) c.aiTimer1a4 = 15;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 40 && dx < 100.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 200) + 90;
        else c.aiTimer1a0 = rnd(c, 0, 200) + 90;
    }
    if (rnd(c, 0, 100) < 80) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 200) + 90;
        else c.aiTimer1a4 = rnd(c, 0, 200) + 90;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 200) + 90;
    else c.aiTimer1a4 = rnd(c, 0, 200) + 90;
}
function comboNayuki(c, dx, dy) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (c.state === 200) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 80.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 50.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 3) === 0) c.aiMode = 7;
            return true;
        }
    }
    if (c.state === 201) {
        if (comboLight(c, roll, true)) return true;
    }
    if (c.state === 202) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.pressed[2] = 1;
            return true;
        }
        if (o.y < 0.0 && roll > 300 && roll < 320 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 110;
            return true;
        }
        if (roll < 150 && dx < 80.0) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 150 && roll < (c.y < 0.0 ? 1 : 0) * 150 + 350) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 350 && roll < 400) {
            c.command = 10;
            return true;
        }
        if (roll > 400 && roll < c.f3148 * 10 + 450) {
            c.command = 30;
            return true;
        }
        if (roll > 600 && roll < 610 && c.y < 0.0) {
            c.command = 52;
            return true;
        }
    }
    if (c.state === 203) {
        if (roll > 0 && roll < 150) {
            c.command = 10;
            return true;
        }
        if (roll > 150 && roll < 300) {
            c.command = 30;
            return true;
        }
        if (roll > 300 && roll < 450) {
            c.command = 70;
            return true;
        }
        if (roll > 450 && roll < 500 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
        if (roll > 500 && roll < 550 && c.d168 === 3 && c.meter >= 1000) {
            c.command = rnd(c, 0, 2) + 110;
            return true;
        }
        if (roll > 550 && roll < 560 && c.meter >= 1000) {
            c.command = rnd(c, 0, 2) + 100;
            return true;
        }
        if (roll > 910) {
            startJump(c);
            return true;
        }
    }
    if (c.state === 204) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 80.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 50.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[1] = 1;
            c.inputY = rnd(c, 0, 2) === 0 ? 1 : 0;
            return true;
        }
        if (roll > 900) {
            startJump(c);
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 3) === 0) c.aiMode = 7;
            return true;
        }
    }
    if (c.state === 205) {
        if (comboLight(c, roll, false)) return true;
    }
    if (c.state === 206) {
        if (roll > 0 && roll < 400 && c.d168 === 3) {
            c.inputX = c.facing;
            c.inputY = -1;
            return true;
        }
        if (roll > 400 && roll < 800 && c.d168 === 3 && c.f3148 < 9) {
            c.pressed[3] = 1;
            return true;
        }
        if (roll > 0 && roll < 150) {
            c.command = 10;
            if (o.y < 0.0) c.command = 11;
            return true;
        }
        if (roll > 150 && roll < 300) {
            c.command = 30;
            return true;
        }
        if (roll > 300 && roll < 450 && o.y === 0.0) {
            c.command = 70;
            return true;
        }
        if (roll > 450 && roll < 600 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
        if (roll > 600 && roll < 1610 && c.meter >= 1000) {
            c.command = rnd(c, 0, 2) + 100;
            return true;
        }
    }
    if (c.state === 207) {
        if (dx < 60.0 && dy < 30.0 && roll < 400) {
            c.pressed[0] = 1;
            return true;
        }
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            return true;
        }
        if (dx < 60.0 && roll < 400) {
            c.pressed[0] = 1;
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 800) {
            c.aiMode = 1;
            if (rnd(c, 0, 4) === 0) c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 208) {
        if (roll > 0 && roll < 400) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 950) {
            c.inputX = rnd(c, 0, 2) - 1;
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 209) {
        if (roll > 950) {
            c.inputX = rnd(c, 0, 2) - 1;
            return true;
        }
        if (roll > 600) {
            c.aiMode = 3;
            return true;
        }
    }
    return false;
}
function comboLight(c, roll, withAir) {
    const o = c.opponent;
    if (withAir) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = 20;
            return true;
        }
        if (o.y < 0.0 && roll > 299 && roll < 600) {
            c.pressed[3] = 1;
            return true;
        }
        if (o.y < 0.0 && roll > 599 && roll < 700) {
            c.inputY = -1;
            c.inputX = c.facing;
            return true;
        }
    }
    if (roll < 350 && c.d168 === 3) {
        c.pressed[2] = 1;
        c.inputY = 1;
        return true;
    }
    if (roll > 350 && roll < 500 && c.d168 === 3) {
        c.pressed[2] = 1;
        c.inputY = 0;
        return true;
    }
    if (roll > 500 && roll < 550 && c.f3148 > 2) {
        c.pressed[1] = 1;
        c.inputY = 0;
        c.inputX = c.facing;
        return true;
    }
    if (roll > 0 && roll < 500) {
        c.pressed[1] = 1;
        c.inputY = 0;
        return true;
    }
    if (roll > 900) {
        startJump(c);
        return true;
    }
    if (roll > 599) {
        c.aiMode = 1;
        if (rnd(c, 0, 2) === 0) c.aiMode = 7;
        return true;
    }
    return false;
}
