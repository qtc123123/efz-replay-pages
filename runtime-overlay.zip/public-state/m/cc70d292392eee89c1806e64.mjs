import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { createImage, loadDat } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { readRec, writeRec } from "./ad76ef61597c869da76b5edb.mjs";
import { blit, fillRect, loadPalette, makeRect, present, readColorKey } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { playBGM, playSE, stopBGM } from "./4bc01372141f4e276b2208f4.mjs";
import { checkEscapeKey, pollInput } from "./06124acd5a2cf7a08d774a8d.mjs";
import { FadeMode, Scene, fadeIn, fadeOut } from "./494d0271e10bf938cecabb23.mjs";
import { GameMode, deleteStageObject, gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { State } from "./2215c2ad4aabedb03c1f6b16.mjs";
const WINNER_DAT = "system\\winner.dat";
const RESULT_DAT = "system\\result.dat";
const QUOTE_TARGETS = 20;
const LOSER_STATE = 0x2f;
var Phase = /*#__PURE__*/ function(Phase) {
    Phase[Phase["Enter"] = 0] = "Enter";
    Phase[Phase["Music"] = 1] = "Music";
    Phase[Phase["Continue"] = 2] = "Continue";
    Phase[Phase["Score"] = 3] = "Score";
    return Phase;
}(Phase || {});
const s8 = (v)=>v << 24 >> 24;
export class ResultScene extends Scene {
    palette = gs.palette;
    surfWinner = loadDat(WINNER_DAT, 0, 0xaf);
    surfResult = loadDat(RESULT_DAT, 0, 0xaf);
    surfQuote = createImage(0, 0);
    surfPortrait = createImage(0, 0);
    portraitKey = 0;
    exit = 0;
    bgX = 0xf0;
    bgV = 0x12;
    stripAX = 0;
    stripAY = 0;
    stripBX = 0;
    stripBY = 0;
    door = -2;
    doorV = 9;
    portraitX = 0x140;
    portraitV = 0xf;
    quoteY = -0xf0;
    quoteV = 0xf;
    t = 0;
    phase = 0;
    cursor = 0;
    held = 0;
    bonusLife = 0;
    bonusCombo = 0;
    bonusDamage = 0;
    bonusPerfect = 0;
    constructor(){
        super();
        this.enterState = 1;
    }
    char(side) {
        return gs.chars[side];
    }
    enter() {
        const w = gs.winner;
        const winner = this.char(w);
        const loser = this.char(1 - w);
        let quote = rand("src/game/scene_result.ts:118:14", {
            consumer: "ResultScene.enter"
        }) % winner.winQuoteCount;
        const portrait = `system\\${winner.name}\\${winner.name}.dat`;
        const base = 0x5f + 0x28 * w;
        this.surfPortrait = loadDat(portrait, 0, base);
        loadPalette(gs.palette, portrait, 0x28 * winner.color, base, 0x28);
        this.portraitKey = readColorKey(this.surfPortrait);
        for(let k = 0; k < QUOTE_TARGETS; k++){
            if (loser.id === s8(winner.winQuoteTarget(k))) quote = k + 10;
        }
        this.surfQuote = loadDat(`system\\${winner.name}\\${quote < 10 ? "0" : ""}${quote}.dat`, 0, 0xaf);
        if (gs.mode === GameMode.VsPlayer) {
            const order = w === 0 ? [
                this.char(0),
                this.char(1)
            ] : [
                this.char(1),
                this.char(0)
            ];
            this.addRec(order[0], 1);
            this.addRec(order[1], 2);
        }
        if (gs.mode === GameMode.Score) {
            const human = this.char(gs.startPlayer);
            const cpu = this.char(1 - gs.startPlayer);
            this.bonusLife = Math.trunc((human.lifeBonus >>> 0) / 100);
            human.hitCount = human.hitCount + this.bonusLife >>> 0;
            this.bonusCombo = human.maxCombo << 1 >>> 0;
            human.hitCount = human.hitCount + this.bonusCombo >>> 0;
            this.bonusDamage = Math.trunc((human.maxComboDamage >>> 0) / 100);
            human.hitCount = human.hitCount + this.bonusDamage >>> 0;
            this.bonusPerfect = gs.round * 0x32 * (cpu.wins === 0 ? 1 : 0);
            human.hitCount = human.hitCount + this.bonusPerfect >>> 0;
            const rec = readRec(human.name);
            const recHigh = rec[4] >>> 0;
            const high = human.scoreHigh >>> 0;
            if (recHigh < high) {
                rec[3] = human.score;
                rec[4] = human.scoreHigh;
            } else if (recHigh === high && rec[3] >>> 0 < human.score >>> 0) {
                rec[3] = human.score;
            }
            writeRec(human.name, rec);
        }
        if (gs.option1 === 2) {
            for(let side = 0; side < 2; side++){
                if (gs.cpuSide[side]) continue;
                const c = this.char(side);
                const rec = readRec(c.name);
                if (rec[6] >>> 0 < c.maxCombo >>> 0) rec[6] = c.maxCombo;
                if (rec[7] >>> 0 < c.maxComboDamage >>> 0) rec[7] = c.maxComboDamage;
                writeRec(c.name, rec);
            }
        }
        this.bgX = 0xf0;
        this.bgV = 0x12;
        this.stripAX = 0;
        this.stripAY = 0;
        this.stripBX = 0;
        this.stripBY = 0;
        this.door = -2;
        this.portraitX = 0x140;
        this.quoteY = -0xf0;
        this.doorV = 9;
        this.portraitV = 0xf;
        this.quoteV = 0xf;
        this.t = 0;
        loser.x = 480.0;
        loser.y = -240.0;
        loser.facing = -1;
        loser.state = LOSER_STATE;
        loser.onStateChange();
        loser.stopMotion();
        loser.flashFrames = 0;
        loser.clearAfterimage();
        loser.blend = 0;
        this.char(0).pushToOpponent = 0.0;
        this.char(1).pushToOpponent = 0.0;
    }
    addRec(c, idx) {
        const rec = readRec(c.name);
        rec[idx] = rec[idx] + 1;
        writeRec(c.name, rec);
    }
    static bgmAtSixty(id) {
        if (id === 19 || id === 20 || id === 21 || id === 23) return 4;
        if (id === 14) return 9;
        if (id === 1 || id === 16 || id === 17 || id === 13 || id === 15 || id === 2 || id === 3 || id === 8 || id === 9 || id === 10) return 2;
        return 3;
    }
    static bgmOnSkip(id) {
        if (id === 19 || id === 20 || id === 21 || id === 23) return 4;
        if (id === 1 || id === 2 || id === 3 || id === 8 || id === 9 || id === 10) return 2;
        return 3;
    }
    static deleteChar(side) {
        gs.chars[side] = null;
        gs.fighters[side] = null;
    }
    finish(next) {
        this.exit = 0;
        this.enterState = 1;
        return next;
    }
    async update() {
        if (this.enterState === 1) {
            this.phase = 0;
            this.cursor = 0;
            this.enter();
            stopBGM();
            await fadeIn(this, FadeMode.White);
            this.enterState = 0;
        } else if (this.exit === 1) {
            await fadeOut(this, gs.mode !== GameMode.Arcade ? FadeMode.White : FadeMode.Black, 0, 100);
            gs.stageMask |= 1 << gs.stage;
            deleteStageObject();
            if (gs.replayMode > 0) gs.replayFile.close();
            return this.leave();
        }
        if (checkEscapeKey()) {
            this.exit = 1;
            gs.continued = 0;
        }
        if (this.t < 60) {
            this.t++;
            const loser = this.char(gs.winner === 1 ? 0 : 1);
            for(let i = 0; i < 3; i++){
                loser.updateState();
                loser.integrate();
            }
            const se = s8(loser.seRequest);
            if (se >= 0 && se < 0x41) {
                playSE(se);
                loser.seRequest = 0xff;
            }
            if (this.t === 60) {
                playBGM(ResultScene.bgmAtSixty(this.char(gs.winner).id));
                this.phase = 1;
            }
        }
        if (this.bgX > 40 && this.t >= 60) {
            this.bgX -= Math.trunc(this.bgV / 3);
            if (this.bgX < 120 && this.bgV > 1) this.bgV--;
        }
        pollInput();
        if (this.phase === 2) {
            this.updateContinueMenu();
        } else if (gs.input.some((i)=>i.a || i.b || i.c || i.d)) {
            const humanLost = gs.winner !== gs.startPlayer;
            if (gs.mode === GameMode.Arcade && humanLost && this.phase < 2) {
                if (this.phase === 0) playBGM(ResultScene.bgmOnSkip(this.char(gs.winner).id));
                this.openPage(2);
            } else if (gs.mode === GameMode.Score && this.phase < 2) {
                if (this.phase === 0) playBGM(ResultScene.bgmOnSkip(this.char(gs.winner).id));
                this.openPage(3);
            } else {
                this.exit = 1;
            }
        }
        this.stripAX += 2;
        if (this.stripAX >= 0x140) this.stripAX = 0;
        this.stripAY += 1;
        if (this.stripAY >= 0xf0) this.stripAY = 0;
        this.stripBX -= 2;
        if (this.stripBX < 0) this.stripBX = 0x140;
        this.stripBY -= 1;
        if (this.stripBY < 0) this.stripBY = 0xf0;
        if (this.door < 0xa0 && this.portraitX <= -0x50) {
            this.door += this.doorV;
            if (this.door > 0x73) this.doorV--;
        }
        if (this.portraitX > -0xa0 && this.bgX < 0xa0) {
            this.portraitX -= this.portraitV;
            if (this.portraitX < -0x28) this.portraitV--;
        }
        if (this.quoteY < 0 && this.door > 0x78) {
            this.quoteY += this.quoteV;
            if (this.quoteY >= 0 && gs.mode === GameMode.Demo) this.exit = 1;
            if (this.quoteY > -0x78) this.quoteV--;
        }
        this.render();
        return State.Result;
    }
    openPage(phase) {
        this.phase = phase;
        this.portraitX = -0xa0;
        this.quoteY = 0;
        this.bgX = 0x28;
        this.door = 0xa0;
        this.t = 0x3c;
    }
    updateContinueMenu() {
        const input = gs.input[gs.startPlayer];
        if (input.moveX !== 0 && this.held === 0) {
            this.cursor++;
            playSE(8);
            if (this.cursor > 1) this.cursor = 0;
            this.held = 1;
        }
        if (input.moveX === 0) this.held = 0;
        if (input.a) {
            playSE(6);
            if (this.cursor === 0) {
                gs.continueRound = gs.round < 8 ? gs.round : 0;
                gs.continued = 1;
            } else {
                gs.continued = 0;
            }
            this.exit = 1;
        }
    }
    leave() {
        const humanWon = gs.winner === gs.startPlayer;
        if (gs.mode === GameMode.Arcade) {
            if (humanWon) {
                if (gs.round === 8) {
                    ResultScene.deleteChar(0);
                    ResultScene.deleteChar(1);
                    return this.finish(State.StaffRoll);
                }
                this.defeatCPU();
                gs.continued = 0;
                return this.finish(State.Loading);
            }
            if (gs.continued > 0) return this.finish(State.Loading);
            ResultScene.deleteChar(0);
            ResultScene.deleteChar(1);
            return this.finish(State.CharacterSelect);
        }
        if (gs.mode === GameMode.Score && humanWon && gs.round < 8) {
            this.defeatCPU();
            return this.finish(State.Loading);
        }
        ResultScene.deleteChar(0);
        ResultScene.deleteChar(1);
        return this.finish(gs.mode === GameMode.Demo ? State.Title : State.CharacterSelect);
    }
    defeatCPU() {
        const cpu = gs.startPlayer === 1 ? 0 : 1;
        gs.defeatedMask |= 1 << this.char(cpu).id;
        ResultScene.deleteChar(cpu);
        gs.round++;
    }
    drawNumber(x, y, value) {
        let v = value >>> 0;
        let right = x;
        do {
            const d = v % 10;
            blit({
                left: right - 16,
                top: y,
                right,
                bottom: y + 0x13
            }, this.surfResult, {
                left: d << 4,
                top: 0x1c7,
                right: d + 1 << 4,
                bottom: 0x1da
            }, gs.objectKey);
            right -= 0xe;
            v = Math.trunc(v / 10);
        }while (v > 0)
    }
    drawStrips(sx, sy, srcY) {
        const c = this.door;
        const key = gs.objectKey;
        const surf = this.surfWinner;
        for(let y = -0xf0; y <= 0xf0; y += 0x50){
            const yy = sy + y;
            if (sx <= 0xa0) {
                blit(makeRect(c - 0xa0, yy, 0xa0, 0x30), surf, makeRect(sx, srcY, 0xa0, 0x30), key);
                blit(makeRect(0xa0 - c + 0xa0, yy, 0xa0 - sx, 0x30), surf, makeRect(sx + 0xa0, srcY, 0xa0 - sx, 0x30), key);
                blit(makeRect(0xa0 - c + 0x140 - sx, yy, sx, 0x30), surf, makeRect(0, srcY, sx, 0x30), key);
            } else {
                blit(makeRect(c - 0xa0, yy, 0x140 - sx, 0x30), surf, makeRect(sx, srcY, 0x140 - sx, 0x30), key);
                blit(makeRect(c + 0xa0 - sx, yy, sx - 0xa0, 0x30), surf, makeRect(0, srcY, sx - 0xa0, 0x30), key);
                blit(makeRect(0xa0 - c + 0xa0, yy, 0xa0, 0x30), surf, makeRect(sx - 0xa0, srcY, 0xa0, 0x30), key);
            }
        }
    }
    render() {
        __session.render();
        const key = gs.objectKey;
        const res = this.surfResult;
        blit(makeRect(0, 0, 0x140, 0xa0), gs.bgSurf, makeRect(this.bgX, 0x140, 0x140, 0xa0), 0);
        fillRect(makeRect(0, 0xa0, 0x140, 0x50), 0xb0);
        this.char(gs.winner === 1 ? 0 : 1).draw(-this.bgX, -0x50);
        fillRect(makeRect(0x140 - this.door, 0, this.door, 0xf0), 0xe7);
        fillRect(makeRect(0, 0, this.door, 0xf0), 0xe7);
        this.drawStrips(this.stripBX, this.stripBY, 0x30);
        this.drawStrips(this.stripAX, this.stripAY, 0);
        blit(makeRect(this.portraitX + 0x50, 0, 0x140, 0xf0), this.surfPortrait, makeRect(0, 0, 0x140, 0xf0), this.portraitKey);
        if (this.phase < 2) {
            blit(makeRect(0, this.quoteY, 0x140, 0xf0), this.surfQuote, makeRect(0, 0, 0x140, 0xf0), key);
        } else if (this.phase === 2) {
            blit(makeRect(0x57, 0x5a, 0x99, 0x19), res, makeRect(0, 0x1da, 0x99, 0x19), key);
            if (this.cursor === 0) {
                blit(makeRect(0x68, 0x7c, 0x33, 0x15), res, makeRect(0, 0x1f3, 0x33, 0x15), key);
                blit(makeRect(0xb4, 0x7e, 0x1e, 0x10), res, makeRect(0x26, 0x208, 0x1e, 0x10), key);
            } else {
                blit(makeRect(0x6e, 0x7e, 0x26, 0xf), res, makeRect(0, 0x208, 0x26, 0xf), key);
                blit(makeRect(0xaf, 0x7c, 0x27, 0x14), res, makeRect(0x33, 0x1f4, 0x27, 0x14), key);
            }
        } else if (this.phase === 3) {
            this.renderScorePage();
        }
        present();
    }
    renderScorePage() {
        const key = gs.objectKey;
        const res = this.surfResult;
        const human = this.char(gs.startPlayer);
        blit(makeRect(0x49, 9, 0xd6, 0x2a), res, makeRect(0, (gs.round - 1) * 0x2a, 0xd6, 0x2a), key);
        blit(makeRect(9, 0x3b, 0x34, 0x12), res, makeRect(0, 0x161, 0x34, 0x12), key);
        this.drawNumber(0x136, 0x3a, this.bonusLife);
        blit(makeRect(9, 0x56, 0x6a, 0x1d), res, makeRect(0, 0x173, 0x6a, 0x1d), key);
        this.drawNumber(0x136, 0x5b, this.bonusCombo);
        blit(makeRect(9, 0x75, 0x75, 0x21), res, makeRect(0, 0x190, 0x75, 0x21), key);
        this.drawNumber(0x136, 0x7c, this.bonusDamage);
        blit(makeRect(9, 0x9c, 0x7e, 0x16), res, makeRect(0, 0x1b1, 0x7e, 0x16), key);
        this.drawNumber(0x136, 0x9d, this.bonusPerfect);
        blit(makeRect(9, 0xbe, 0x4a, 0x12), res, makeRect(0x34, 0x161, 0x4a, 0x12), key);
        blit(makeRect(0x12a, 0xbb, 0xb, 0x11), res, makeRect(0xb2, 0x1c8, 0xb, 0x11), key);
        this.drawNumber(0x128, 0xba, human.hitCount);
        this.drawNumber(0x136, 0xd7, human.score);
        if (human.scoreHigh >>> 0 > 0) {
            this.drawNumber(0xc6, 0xd7, human.scoreHigh);
            for(let i = 1; i < 8; i++){
                if ((human.score >>> 0) / __numerics.pow(10, 8 - i) < 1.0) this.drawNumber(0xc6 + i * 0xe, 0xd7, 0);
            }
        }
    }
    static files = [
        WINNER_DAT,
        RESULT_DAT
    ];
}

export function __logicState(){return {Phase};}

export function __installInitialRoots(s){
Phase=s["Phase"];
}
