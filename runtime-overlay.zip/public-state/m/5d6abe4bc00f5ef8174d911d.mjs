import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerStates } from "./4f243a87eb42ac119eae883d.mjs";
import { openSpawnFrame, frameEffect } from "./8a0ae749d7e9ba4d08c1d570.mjs";
import { frameDuration, frameCount, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, f, pat, blend, layer) {
    f.w04 = pat;
    f.x = ftol(c.x);
    f.y = ftol(c.y);
    f.b20 = blend;
    f.b21 = layer;
    frameEffect(f);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function attackStart(c, meter, se) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = 1;
}
function groundJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2) {
        c.state = 4;
        if (c.inputX === c.facing) c.state = 5;
        if (c.inputX === -c.facing) c.state = 6;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a < 1) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function landTo13(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return true;
    }
    return false;
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function endTo7(c) {
    c.state = 7;
    if (c.inputY === 1) c.state = 3;
    c.onStateChange();
}
function opponentPoint0(o) {
    return [
        o.pointsX[0],
        o.pointsY[0]
    ];
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame < 9) c.vy += c.ay;
    if (!advance(c, dur)) return;
    if (c.frame === 3) {
        c.vy = -1.8;
        c.ay = 0.05;
    }
    if (c.frame === 9) c.frame = w16(c.frame - 4);
    if (c.frame < 9 && c.frame > 4 && c.y + c.vy > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.frame = 9;
    }
    if (c.frame === cnt - 1) c.faceOpponent();
    if (c.frame >= cnt) endTo7(c);
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, f, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0x63);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.timer = w16(c.timer + 1);
    if (c.life > 0 && c.timer > 0x45 && c.frame === 0) c.setState(0x60);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(0x60);
    }
}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 0x99, 0x96, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 0x9a, 0x97, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 0x9b, 0x98, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 0x99, 0x96, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 0x9a, 0x97, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 0x9b, 0x98, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy += c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(0xd);
    }
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, f, 8, 2, 0);
    } else {
        c.vy += c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(0xd);
    }
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        f.w04 = 9;
        f.x = ftol(c.x);
        f.y = ftol(c.y) - 0x3c;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.w16c = 1;
        c.seRequest = 0x3e;
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 6)) {
        c.stopMotion();
        f.w04 = 9;
        f.x = ftol(c.x);
        f.y = ftol(c.y) - 0x3c;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.w16c = 1;
        c.seRequest = 0x3e;
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 0xd;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 0xc) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 4);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    if (atStart(c)) {
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.vy += c.ay;
    if (c.frame === 6) {
        c.vx -= 0.05;
        if (!(c.vx >= 0.5)) c.vx = 0.5;
    }
    if (atFrame(c, 2)) {
        c.vx = 2.5;
        c.vy = -1.6;
        c.ay = 0.05;
    }
    if (atFrame(c, 6)) c.ay = 0.08;
    if (c.y + c.vy > 0.0) {
        c.setState(0xb2);
        return;
    }
    if (advance(c, dur) && c.frame === 6) {
        if (c.inputX === -c.facing) {
            c.ay = 0.08;
            return;
        }
        c.f3138++;
        if (c.f3138 < 7) {
            c.frame = w16(c.frame - 2);
            c.f3138++;
        }
    }
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.frame > 0) c.vx += 0.055;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.y + c.vy > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.setState(0xd);
        return;
    }
    c.vy += c.ay;
    if (advance(c, dur)) {
        if (c.frame === 3) {
            c.vx = -3.5;
            c.vy = -1.5;
            c.ay = 0.05;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 4);
    }
}
function airDash(c, sign, vxEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        if (sign > 0) {
            c.vx = 1.8;
            c.startAfterimage(3);
            c.vy = 0.0;
            c.ay = 0.0;
        } else {
            c.vx = -1.8;
            c.vy = 0.0;
            c.ay = 0.0;
            c.startAfterimage(3);
        }
        if (c.f3138 === 0) c.seRequest = 0x11;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    const dir = sign * c.facing;
    if (c.inputX === dir && c.f313c >= 0x78) {
        c.setState(9);
        c.vx = vxEnd;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
    if (c.inputX !== dir && c.f3138 >= 0x30) {
        c.setState(9);
        c.vx = vxEnd;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
}
const s165 = (c)=>airDash(c, 1, 1.3);
const s166 = (c)=>airDash(c, -1, -0.9);
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 0x5a;
    c.superDarken(0xb0, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 0x12;
        fxAtSelf(c, f, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, f, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, f, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 0x3c;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 0xa9;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 0x12;
        fxAtSelf(c, f, 1, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            if (c.ay === 0.0) c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx -= 0.08;
    if (!(c.vx >= 0.0)) c.vx = 0.0;
    if (advance(c, dur) && c.frame >= cnt) endTo7(c);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 0xc) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 0xc;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 3) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 0xc) c.frame = w16(c.frame - 4);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 0x15);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) attackStart(c, 15, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx -= 0.02;
    if (!(c.vx > 0.0)) c.vx = 0.0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) {
        attackStart(c, 15, 0x14);
        c.vx = 1.2;
    }
    if (advance(c, dur)) {
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.w16c = 2;
    }
    if (atFrame(c, 1)) {
        addMeter(c, 0x23);
        c.seRequest = 0x14;
    }
    if (advance(c, dur)) {
        if (c.frame < 6) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 0x15);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.stopMotion();
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 2)) attackStart(c, 0xd, 0x14);
    if (c.vx > 0.0) {
        c.vx -= 0.025;
        if (!(c.vx >= 0.0)) c.vx = 0.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 3) c.vx = 1.5;
        if (c.frame === 6 && c.f3138 < 1) {
            c.frame = w16(c.frame - 2);
            c.f3138++;
        }
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        addMeter(c, 0x19);
        c.vx = 3.0;
    }
    if (c.frame > 1) {
        c.vx -= 0.07;
        if (!(c.vx >= 0.0)) c.vx = 0.0;
        if (c.vx === 0.0) c.w16c = 0;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 3) {
            c.seRequest = 0x14;
            c.w16c = 1;
        }
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function airNormal(c, startFrame, meter, se, resetBefore) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, startFrame)) attackStart(c, meter, se);
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame < resetBefore) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s207 = (c)=>airNormal(c, 1, 5, 0x15, 3);
const s208 = (c)=>airNormal(c, 3, 0xd, 0x14, 2);
const s209 = (c)=>airNormal(c, 4, 0x1e, 0x14, 4);
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!(c.vx > 0.0)) c.vx = 0.0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.y < 0.0) {
        c.vy += c.ay;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.vy = 0.0;
            c.timer = 0;
            c.frame = 5;
            return;
        }
    }
    if (c.frame > 4) {
        c.vx -= 0.036;
        if (!(c.vx >= 0.0)) c.vx = 0.0;
    }
    if (atFrame(c, 2)) attackStart(c, 15, 0x14);
    if (advance(c, dur)) {
        if (c.frame === 1) {
            c.vx = 1.0;
            c.vy = -2.6;
            c.ay = 0.065;
        }
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.stopMotion();
    if (groundJumpCancel(c)) return;
    if (atFrame(c, 2)) attackStart(c, 0xd, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 1 && c.d168 === 3) {
        c.stopMotion();
        c.onStateChange();
        o.stopMotion();
        o.onStateChange();
        c.state = 0xdd;
        o.state = 0x6b;
        f.w04 = 0;
        f.x = ftol(c.x) + c.facing * 0x25;
        f.y = ftol(c.y) - 0x30;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1 && c.timer === 0 && o.y === 0.0) c.w16c = 1;
        else c.w16c = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        const [px, py] = opponentPoint0(o);
        c.x = o.x - px * c.facing;
        c.y = py + 0x1e;
    }
    if (atFrame(c, 3)) {
        o.state = 0x3b;
        o.onStateChange();
        o.knockX = -2.5;
        o.knockY = -1.0;
        o.ay = 0.035;
        c.vx = -1.8;
        c.vy = -1.9;
        c.ay = 0.04;
        f.w04 = 0;
        f.b2c = 2;
        f.x = ftol(c.x);
        f.y = ftol(c.y) - 0x2d;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        applyDirectDamage(c, 0x3e8, 750.0);
    }
    if (c.frame > 2) c.vy += c.ay;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function airNormalB(c, meter, se, w16c, landFrame, resetBefore) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    c.startAfterimage(3);
    if (airJumpCancel(c)) return;
    if (atStart(c)) c.vx = 0.5;
    if (atFrame(c, 1)) {
        addMeter(c, meter);
        c.seRequest = se;
        c.w16c = w16c;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(0xe9);
        c.frame = landFrame;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame < resetBefore) c.d168 = 0;
        if (c.frame >= cnt) c.setState(10);
    }
}
const s230 = (c)=>airNormalB(c, 5, 0x15, 1, 2, 3);
const s231 = (c)=>airNormalB(c, 0xd, 0x14, 2, 1, 5);
const s232 = (c)=>airNormalB(c, 0xa, 0x14, 1, 1, 4);
function s233(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.faceOpponent();
    if (advance(c, dur)) {
        c.d168 = 3;
        if (c.frame >= cnt) endTo7(c);
    }
}
function s248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.vy += c.ay;
    if (c.frame === 2 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        o.d128 = 1;
        f.w04 = 0;
        f.x = ftol(c.x) + c.facing * 0x16;
        f.y = ftol(c.y) - 0x36;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.frame = 0;
        c.timer = 0;
        c.state = 0xf9;
        o.state = 0x67;
        o.x = c.facing * 0x16 + c.x;
        o.y = c.y - 52.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 2 && o.y < 0.0 && (o.state < 0x32 || o.state > 0x95)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0xd1;
            c.frame = 2;
        }
    }
}
const THROW_249 = [
    [
        0x67,
        15.0,
        -70.0,
        0
    ],
    [
        0x76,
        -25.0,
        -65.0,
        1
    ],
    [
        0x75,
        -28.0,
        -43.0,
        1
    ],
    [
        0x75,
        -12.0,
        -29.0,
        1
    ],
    [
        0x68,
        12.0,
        -23.0,
        -1
    ],
    [
        0x68,
        23.0,
        -36.0,
        -1
    ],
    [
        0x67,
        28.0,
        -58.0,
        -1
    ],
    [
        0x67,
        14.0,
        -73.0,
        -1
    ],
    [
        0x76,
        -12.0,
        -78.0,
        1
    ]
];
function s249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.w13e = 2;
    if (c.frame < 11) {
        if (c.x > 6100.0 && c.facing === 1) {
            c.x = 6100.0;
            c.vx = 0.0;
        }
        if (c.x < 30.0 && c.facing === -1) {
            c.x = 30.0;
            c.vx = 0.0;
        }
        c.biasCamera(0x32, 3);
        c.biasCameraY(0x32, 3);
    }
    if (c.frame < 10 || c.frame > 11 && c.frame < 15) {
        c.vy += c.ay;
        if (c.vy + c.y > 0.0) {
            if (c.frame < 10) {
                c.y = 0.0;
                c.stopMotion();
                o.onStateChange();
                o.state = 0x62;
                o.y = 0.0;
                o.x = c.facing + c.x;
                o.facing = -c.facing;
                o.stopMotion();
                applyDirectDamage(c, 0x3e8, 500.0);
                f.w04 = 0;
                f.x = ftol(c.x);
                f.y = ftol(c.y);
                f.b20 = 2;
                f.b21 = 1;
                frameEffect(f);
                c.timer = 0;
                c.frame = 10;
                c.seRequest = 2;
                return;
            }
            if (c.frame === 14) {
                c.y = 0.0;
                c.stopMotion();
                c.timer = 0;
                c.frame = 15;
                return;
            }
        }
    }
    if (c.frame < 1) {
        o.state = 0x67;
        o.x = c.facing * 0x16 + c.x;
        o.y = c.y - 52.0;
    }
    if (c.frame >= 1 && c.frame <= 9) {
        const [st, dx, dy, face] = THROW_249[c.frame - 1];
        o.state = st;
        o.x = (dx + c.vx) * c.facing + c.x;
        o.y = dy + c.vy + c.y;
        if (face !== 0) o.facing = face * c.facing;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 10) c.frame = w16(c.frame - 8);
        if (c.frame === 12) {
            c.vx = -0.8;
            c.vy = -1.0;
            c.ay = 0.035;
        }
        if (c.frame >= cnt) {
            c.onStateChange();
            c.faceOpponent();
            c.state = 3;
        }
    }
}
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    248: s248,
    249: s249
});

export function __logicState(){return {THROW_249};}

export function __installInitialRoots(s){
if(THROW_249!==s["THROW_249"])throw Error('INITIAL_CONST_IDENTITY:THROW_249');
}
