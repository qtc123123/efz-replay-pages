import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./4fd020f21e3ef9d96dc087c0.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./b1bf50e501f736bc8b07bfdb.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
function startGround(c) {
    c.b158 = 0;
    c.vx = 0.0;
    c.vy = 0.0;
}
function rfCost(c) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
}
function spawnEffect33(c, d, mul) {
    d.w04 = 0x21;
    d.b2c = 0xb;
    d.x = ftol(c.x) - c.facing * mul;
    d.y = ftol(c.y) - 0x38;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
}
function endToFall(c) {
    c.state = 9;
    c.b159 = 1;
    c.b15a = c.b15a + 1 & 0xff;
    c.ay = 0.035;
    c.onStateChange();
}
function stateGround(c, mul) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        startGround(c);
        if (mul !== 0) {
            spawnEffect33(c, d, mul);
            rfCost(c);
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function stateAir(c, mul) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        if (mul !== 0) {
            spawnEffect33(c, d, mul);
            rfCost(c);
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame >= cnt) endToFall(c);
}
function spawnShot(c, d, pat) {
    c.meter = s16(c.meter + 0xf);
    d.w04 = pat;
    d.x = c.facing * 0x41 + c.x;
    d.y = c.y - 54.0;
    d.b18 = c.facing;
    d.b21 = 1;
    d.d00 = 1;
    c.f314c = c.f314c + 1;
    frameChild(c, d);
}
function stateShot(c, pat) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    c.timer++;
    c.d168 = 3;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 5 && c.timer === 0) spawnShot(c, d, pat);
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        startGround(c);
        spawnEffect33(c, d, 0xa);
        rfCost(c);
    }
    c.timer++;
    c.d168 = 3;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 5 && c.timer === 0) {
        c.meter = s16(c.meter + 0xf);
        d.w04 = 0x1af;
        d.x = c.facing * 0x41 + c.x;
        d.y = c.y - 54.0;
        d.b18 = c.facing;
        d.b21 = 1;
        d.d00 = 1;
        frameChild(c, d);
        c.f314c = 1;
        d.d00 = 1;
        d.w04 = 0x1b0;
        d.b20 = 2;
        frameChild(c, d);
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state268(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 || c.frame === 1) {
        c.ay = 0.035;
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.y = 0.0;
            c.vy = 0.0;
            c.vx = 0.0;
            c.timer = 0;
            c.frame = 2;
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame === 2) c.frame = c.frame - 2;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
registerStates({
    250: (c)=>stateGround(c, 0),
    251: (c)=>stateGround(c, 0),
    252: (c)=>stateGround(c, 0),
    253: (c)=>stateGround(c, 0),
    254: (c)=>stateGround(c, 0),
    255: (c)=>stateGround(c, 0x11),
    256: (c)=>stateGround(c, 0),
    257: (c)=>stateGround(c, 0),
    258: (c)=>stateGround(c, 0x11),
    259: (c)=>stateGround(c, 0),
    260: (c)=>stateGround(c, 0),
    261: (c)=>stateGround(c, 0x11),
    262: (c)=>stateShot(c, 0x1ad),
    263: (c)=>stateShot(c, 0x1ae),
    264: state264,
    265: (c)=>stateAir(c, 0),
    266: (c)=>stateAir(c, 0),
    267: (c)=>stateAir(c, 0xa),
    268: state268,
    269: (c)=>stateAir(c, 0),
    270: (c)=>stateAir(c, 0),
    271: (c)=>stateAir(c, 0xa),
    272: (c)=>stateAir(c, 0),
    273: (c)=>stateAir(c, 0),
    274: (c)=>stateAir(c, 0xa),
    275: (c)=>stateGround(c, 0),
    276: (c)=>stateGround(c, 0),
    277: (c)=>stateGround(c, 0x11)
});
const r = (conds, pat, frame, mode = 4)=>({
        conds,
        pat,
        frame,
        mode
    });
function match(c, conds) {
    for (const [st, fr] of conds){
        if (c.state === st && (fr < 0 || c.frame === fr)) return true;
    }
    return false;
}
function route(c, i, table, before, after) {
    const ch = c.children[i];
    for (const e of table){
        if (!match(c, e.conds)) continue;
        before?.(c, i);
        c.f3148 = e.mode;
        ch.pattern = e.pat;
        ch.frame = e.frame;
        ch.timer = 0;
        after?.(c, i);
        return true;
    }
    return false;
}
function faceOpponent(c, i) {
    const ch = c.children[i];
    if (ch.x <= c.opponent.x) {
        ch.facing = 1;
    } else {
        ch.facing = -1;
    }
}
function routeThrown(c, i) {
    if (c.state !== 0x7b) return false;
    const ch = c.children[i];
    c.f3148 = 4;
    ch.y = 0.0;
    ch.vx = 0.0;
    ch.vy = 0.0;
    ch.ay = 0.0;
    ch.pattern = 0x1d5;
    ch.frame = 0xb;
    ch.timer = 0;
    return true;
}
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function routes404to412(f404, f407) {
    return [
        r([
            [
                253,
                2
            ],
            [
                265,
                3
            ]
        ], 404, f404),
        r([
            [
                254,
                2
            ],
            [
                266,
                3
            ]
        ], 405, f404),
        r([
            [
                255,
                2
            ],
            [
                267,
                3
            ]
        ], 406, f404),
        r([
            [
                256,
                2
            ],
            [
                269,
                3
            ]
        ], 407, f407),
        r([
            [
                257,
                2
            ],
            [
                270,
                3
            ]
        ], 408, f407),
        r([
            [
                258,
                2
            ],
            [
                271,
                3
            ]
        ], 409, f407),
        r([
            [
                259,
                2
            ],
            [
                272,
                3
            ]
        ], 410, f407),
        r([
            [
                260,
                2
            ],
            [
                273,
                3
            ]
        ], 411, f407),
        r([
            [
                261,
                2
            ],
            [
                274,
                3
            ]
        ], 412, f407)
    ];
}
function routes466(f) {
    return [
        r([
            [
                275,
                2
            ]
        ], 466, f),
        r([
            [
                276,
                2
            ]
        ], 467, f),
        r([
            [
                277,
                2
            ]
        ], 468, f)
    ];
}
function routesSupers(p416, p418, p420) {
    return [
        r([
            [
                300,
                2
            ],
            [
                306,
                1
            ]
        ], 454, 0),
        r([
            [
                301,
                2
            ],
            [
                307,
                1
            ]
        ], 455, 0),
        r([
            [
                302,
                2
            ],
            [
                308,
                1
            ]
        ], 456, 0),
        r([
            [
                303,
                2
            ],
            [
                309,
                1
            ]
        ], p416, 0),
        r([
            [
                304,
                2
            ],
            [
                310,
                1
            ]
        ], p418, 0),
        r([
            [
                305,
                2
            ],
            [
                311,
                1
            ]
        ], p420, 0),
        r([
            [
                312,
                2
            ],
            [
                313,
                2
            ],
            [
                314,
                2
            ]
        ], 437, 0),
        r([
            [
                315,
                3
            ]
        ], 446, 0)
    ];
}
function routes316(p0, p1, p2) {
    return [
        r([
            [
                316,
                2
            ],
            [
                319,
                1
            ]
        ], p0, 0),
        r([
            [
                317,
                2
            ],
            [
                320,
                1
            ]
        ], p1, 0),
        r([
            [
                318,
                2
            ],
            [
                321,
                1
            ]
        ], p2, 0)
    ];
}
const ROUTES_400 = [
    r([
        [
            250,
            0
        ]
    ], 401, 0, 1),
    r([
        [
            251,
            -1
        ],
        [
            252,
            -1
        ]
    ], 402, 0, 2),
    ...routes404to412(7, 0),
    ...routes466(0),
    ...routesSupers(416, 418, 420),
    ...routes316(454, 455, 456)
];
const ROUTES_401 = [
    r([
        [
            253,
            2
        ],
        [
            265,
            3
        ]
    ], 422, 8),
    r([
        [
            254,
            2
        ],
        [
            266,
            3
        ]
    ], 423, 8),
    r([
        [
            255,
            2
        ],
        [
            267,
            3
        ]
    ], 424, 8),
    r([
        [
            256,
            2
        ],
        [
            269,
            3
        ]
    ], 407, 8),
    r([
        [
            257,
            2
        ],
        [
            270,
            3
        ]
    ], 408, 8),
    r([
        [
            258,
            2
        ],
        [
            271,
            3
        ]
    ], 409, 8),
    r([
        [
            259,
            2
        ],
        [
            272,
            3
        ]
    ], 426, 8),
    r([
        [
            260,
            2
        ],
        [
            273,
            3
        ]
    ], 427, 8),
    r([
        [
            261,
            2
        ],
        [
            274,
            3
        ]
    ], 428, 8),
    ...routes466(9),
    ...routesSupers(417, 419, 421),
    ...routes316(457, 458, 459)
];
const ROUTES_402 = [
    ...routes404to412(7, 0),
    ...routes466(0),
    ...routesSupers(416, 418, 420),
    ...routes316(454, 455, 456)
];
const ROUTES_436 = [
    ...routes404to412(8, 0),
    ...routesSupers(416, 418, 420),
    ...routes316(454, 455, 456)
];
function clampX(c, i) {
    const ch = c.children[i];
    if (ch.x > 620.0) {
        ch.vx = 0.0;
        ch.x = 620.0;
    }
    if (ch.x < 20.0) {
        ch.vx = 0.0;
        ch.x = 20.0;
    }
}
function child400(c, i) {
    const ch = c.children[i];
    c.a3154[i] = 0;
    ch.hitsLeft = 0;
    faceOpponent(c, i);
    ch.vx = 0.0;
    ch.vy = 0.0;
    c.f3148 = 0;
    if (route(c, i, ROUTES_400)) return;
    if (routeThrown(c, i)) return;
    if (c.x - ch.x > 300.0 || c.x - ch.x < -300.0) {
        c.f3148 = 2;
        ch.pattern = 0x1b4;
        ch.frame = 0;
        ch.timer = 0;
        if (c.x > ch.x) ch.facing = 1;
        if (c.x <= ch.x) ch.facing = -1;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) ch.frame = 0;
}
function child401(c, i) {
    const ch = c.children[i];
    c.a3154[i] = 0;
    ch.vy = 0.0;
    ch.vx = 0.0;
    ch.hitsLeft = 0;
    faceOpponent(c, i);
    ch.vx = 0.0;
    ch.vy = 0.0;
    c.f3148 = 1;
    if (ch.frame >= 8 && ch.frame < 0x11) {
        c.f3148 = 3;
        if (c.state === 250 && c.frame === 0) {
            ch.timer = 0;
            ch.frame = 0x11;
            return;
        }
        if (route(c, i, ROUTES_401)) return;
        if (routeThrown(c, i)) return;
    }
    if (c.state === 251 || c.state === 252) {
        c.f3148 = 1;
        ch.pattern = 0x192;
        ch.frame = 0;
        ch.timer = 0;
        return;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame === 0x11) ch.frame = 8;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.pattern = 400;
        c.f3148 = 0;
    }
}
function child402(c, i) {
    const ch = c.children[i];
    c.f3148 = 2;
    ch.hitsLeft = 0;
    if (ch.frame < 0xb) {
        ch.vx = 1.5;
        ch.vy = 0.0;
    }
    if (ch.frame > 0xa) {
        if (ch.vx > 0.0) ch.vx = ch.vx - 0.035;
        if (ch.vx < 0.0) ch.vx = 0.0;
    }
    clampX(c, i);
    if (route(c, i, ROUTES_402, faceOpponent, (cc, k)=>{
        cc.a3154[k] = 0;
    })) return;
    if (routeThrown(c, i)) return;
    if (c.a3154[i] === 0) {
        c.a3154[i] = 1;
        if (c.state === 251) ch.facing = 1;
        if (c.state === 252) ch.facing = -1;
        return;
    }
    if (c.state === 250) {
        c.f3148 = 1;
        ch.pattern = 0x191;
        ch.frame = 0;
        ch.timer = 0;
        return;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame === 0xb && c.a3154[i] < 0) {
        ch.frame = 0;
        c.a3154[i] = c.a3154[i] + 1;
    }
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 400;
        c.a3154[i] = 0;
    }
}
function child403(c, i) {
    const ch = c.children[i];
    c.f3148 = 4;
    ch.moveWhileFrozen = 0;
    c.a3154[i] = 0;
    c.a3254[i] = 0;
    c.a3354[i] = 0;
    if (routeThrown(c, i)) return;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = -1.0;
        ch.vy = -2.5;
        ch.ay = 0.035;
    }
    if (ch.y < 0.0 && ch.frame < 7) {
        ch.vy = ch.vy + ch.ay;
        if (ch.y + ch.vy > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.timer = 0;
            ch.frame = 7;
            c.shakeScreen(3, 0);
            const d = childSpawnFrame;
            d.w04 = 3;
            d.x = ftol(ch.x);
            d.y = ftol(ch.y);
            d.b20 = 2;
            d.b21 = 0;
            frameEffect(d);
            c.seRequest = 7;
        }
    }
    clampX(c, i);
    if (!childAdvance(c, i)) return;
    if (ch.frame === 7) ch.frame = ch.frame - 2;
    if (ch.frame >= childCount) {
        ch.pattern = 400;
        ch.frame = 0;
        c.f3148 = 0;
    }
}
function childStrike(c, i, jump, hits, cap) {
    const ch = c.children[i];
    c.f3148 = 4;
    if (ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 0x193;
        ch.frame = 0;
        ch.timer = 0;
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    if (ch.frame === 9 && ch.timer === 0) {
        c.a3154[i] = 0;
        c.a3254[i] = 0;
    }
    if (ch.frame === 0xb && ch.timer === 0 && c.a3154[i] === 0) {
        ch.vx = 0.0;
        ch.vy = jump;
        ch.ay = 0.055;
        ch.hitsLeft = hits;
        c.a3154[i] = c.a3154[i] + 1;
    }
    if (ch.y < 0.0 && ch.frame < 0xf) {
        ch.vy = ch.vy + ch.ay;
        if (ch.vy > cap) ch.vy = cap;
        if (ch.vy + ch.y > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.timer = 0;
            ch.frame = 0xf;
            return;
        }
    }
    clampX(c, i);
    if (!childAdvance(c, i)) return;
    if (ch.frame === 0xf) ch.frame = ch.frame - 4;
    if (ch.frame >= childCount) {
        ch.pattern = 400;
        ch.frame = 0;
        c.f3148 = 0;
    }
}
function childShot(c, i, v0, limit) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3254[i] === 0) {
        ch.hitsLeft = 1;
        c.a3254[i] = c.a3254[i] + 1;
        ch.vx = v0;
    }
    if (ch.vx > 0.8) {
        ch.vx = ch.vx - 0.035;
        if (ch.vx < 0.8) ch.vx = 0.8;
    }
    if (ch.hitState > 0 && c.a3154[i] === 0 && ch.blend === 0) {
        ch.blend = 1;
        c.a3154[i] = 0x1e;
    }
    if (ch.blend === 1) {
        c.a3154[i] = c.a3154[i] - 1;
        if (c.a3154[i] < 0) {
            c.freeChild(i);
            c.f314c = 0;
            return;
        }
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        if (c.a3354[i] > limit) {
            c.freeChild(i);
            c.f314c = 0;
        } else {
            c.a3354[i] = c.a3354[i] + 1;
        }
    }
}
function child431(c, i) {
    const ch = c.children[i];
    c.f3150 = ftol(ch.x);
    if (ch.frame === 0 && ch.timer === 0 && c.a3254[i] === 0) {
        ch.hitsLeft = 2;
        c.a3254[i] = c.a3254[i] + 1;
        ch.vx = 2.0;
    }
    if (ch.vx > 0.8) {
        ch.vx = ch.vx - 0.035;
        if (ch.vx < 0.6) ch.vx = 0.6;
    }
    if (ch.hitsLeft === 0 && c.a3154[i] === 0 && ch.blend === 0) {
        c.f314c = 2;
        ch.blend = 1;
        c.a3154[i] = 0x1e;
    }
    if (ch.blend === 1) {
        c.a3154[i] = c.a3154[i] - 1;
        if (c.a3154[i] < 0) {
            c.freeChild(i);
            c.f314c = 0;
            return;
        }
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 6 || ch.frame === 0xc) ch.hitState = 0;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        if (c.a3354[i] > 2) {
            c.freeChild(i);
            c.f314c = 0;
        } else {
            c.a3354[i] = c.a3354[i] + 1;
        }
    }
}
function child432(c, i) {
    const ch = c.children[i];
    ch.x = c.f3150;
    if (c.f314c === 2 || c.f314c === 0) {
        if (ch.frame < 0x18) {
            ch.frame = 0x18;
            ch.timer = 0;
            return;
        }
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame === 0x18) ch.frame = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child436(c, i) {
    const ch = c.children[i];
    c.f3148 = 2;
    ch.hitsLeft = 0;
    if (ch.frame < 0xa) ch.vx = 1.5;
    ch.vy = 0.0;
    clampX(c, i);
    if (ch.frame > 9) {
        ch.vx = ch.vx - 0.035;
        if (ch.vx < 0.0) ch.vx = 0.0;
    }
    if (c.state === 250 && c.frame === 0) {
        ch.timer = 0;
        ch.frame = 0;
        ch.pattern = 400;
        return;
    }
    if (route(c, i, ROUTES_436)) return;
    if (c.a3154[i] === 0) {
        c.a3154[i] = 1;
        if (c.state === 251) ch.facing = 1;
        if (c.state === 252) ch.facing = -1;
        return;
    }
    if (c.state === 250) {
        c.f3148 = 1;
        ch.pattern = 0x191;
        ch.frame = 0;
        ch.timer = 0;
        return;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame === 0xa) {
        const far = ch.x < c.x && ch.x - c.x < -200.0 || ch.x > c.x && ch.x - c.x > 200.0;
        if (far) ch.frame = 0;
    }
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 400;
        c.a3154[i] = 0;
    }
}
registerChildren({
    400: child400,
    401: child401,
    402: child402,
    403: child403,
    410: (c, i)=>childStrike(c, i, -1.8, 4, 0.3),
    411: (c, i)=>childStrike(c, i, -2.8, 6, 0.3),
    412: (c, i)=>childStrike(c, i, -1.8, 0xc, 0.15),
    429: (c, i)=>childShot(c, i, 1.7, 0),
    430: (c, i)=>childShot(c, i, 2.1, 1),
    431: child431,
    432: child432,
    436: child436
});

export function __logicState(){return {ROUTES_400,ROUTES_401,ROUTES_402,ROUTES_436};}

export function __installInitialRoots(s){
if(ROUTES_400!==s["ROUTES_400"])throw Error('INITIAL_CONST_IDENTITY:ROUTES_400');
if(ROUTES_401!==s["ROUTES_401"])throw Error('INITIAL_CONST_IDENTITY:ROUTES_401');
if(ROUTES_402!==s["ROUTES_402"])throw Error('INITIAL_CONST_IDENTITY:ROUTES_402');
if(ROUTES_436!==s["ROUTES_436"])throw Error('INITIAL_CONST_IDENTITY:ROUTES_436');
}
