import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { blit, blitBlend, makeRect, BlendTable } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { hasSE, playSE } from "./4bc01372141f4e276b2208f4.mjs";
import { residueSound } from "./88bddfa53ecc3b1f298ce39d.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
export const EFFECT_SLOTS = 640;
export const GROUND_Y = 210;
function newEffect() {
    return {
        pat: 0,
        frame: 0,
        timer: 0,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        b48: 0,
        mirror: 0,
        blend: 0,
        layer: 0,
        fixed: 0,
        sound: 0xff
    };
}
const effects = Array.from({
    length: EFFECT_SLOTS
}, newEffect);
const active = new Int32Array(EFFECT_SLOTS);
const owner = new Int32Array(EFFECT_SLOTS);
let head = 0;
let tail = 0;
let patterns = [];
let fxCounter = 0;
let fxAngleA = 0;
let fxAngleB = 0;
export function setEffectPatterns(p) {
    patterns = p;
}
function advanceHead() {
    let n = 0;
    do {
        head = (head + 1) % EFFECT_SLOTS;
        if (head === tail) {
            tail = (tail + 1) % EFFECT_SLOTS;
            while(tail !== head && !active[tail]){
                owner[tail] = 0;
                tail = (tail + 1) % EFFECT_SLOTS;
            }
        }
        n++;
    }while (owner[head] !== 0 && n < EFFECT_SLOTS)
}
export function spawnEffect(p) {
    const s = head;
    active[s] = 1;
    owner[s] = p.owner ?? 0;
    const e = effects[s];
    e.pat = p.pat;
    e.frame = 0;
    e.timer = 0;
    e.x = p.x;
    e.y = p.y;
    e.b48 = p.b18 ?? 0;
    e.mirror = p.mirror ?? 0;
    e.blend = p.blend ?? 0;
    e.sound = p.sound ?? 0xff;
    e.fixed = p.fixed ?? 0;
    e.layer = p.layer ?? 0;
    advanceHead();
}
function killEffect(i) {
    active[i] = 0;
    owner[i] = 0;
    if (i === tail) {
        while(tail !== head && !active[tail]){
            owner[tail] = 0;
            tail = (tail + 1) % EFFECT_SLOTS;
        }
    }
}
export function snapshotEffects() {
    const out = [];
    for(let i = tail; i !== head; i = (i + 1) % EFFECT_SLOTS){
        if (!active[i]) continue;
        const e = effects[i];
        out.push([
            i,
            e.pat & 0xffff,
            e.frame & 0xffff,
            e.timer & 0xffff,
            e.x,
            e.y,
            e.vx,
            e.vy,
            e.b48 << 24 >> 24,
            e.mirror | 0,
            e.blend << 24 >> 24,
            e.layer & 0xff,
            e.fixed | 0,
            owner[i] | 0
        ]);
    }
    return out;
}
export function pendingEffectSounds() {
    const out = [];
    for(let i = tail; i !== head; i = (i + 1) % EFFECT_SLOTS){
        const s = effects[i].sound;
        if (s >= 0 && s < 0x41) out.push([
            i,
            s
        ]);
    }
    return out;
}
export function clearEffects() {
    active.fill(0);
    owner.fill(0);
    head = 0;
    tail = 0;
}
export function updateEffects() {
    for(let i = tail; i !== head; i = (i + 1) % EFFECT_SLOTS){
        if (active[i]) updateEffect(i);
    }
}
const PI = 3.141592;
function spawnChildren(e, pat, count, onlyL0 = false) {
    for(let k = 0; k < count; k++){
        const base = {
            pat,
            x: Math.trunc(e.x),
            y: Math.trunc(e.y),
            mirror: e.mirror,
            blend: 2
        };
        spawnEffect({
            ...base,
            layer: 0
        });
        if (!onlyL0) spawnEffect({
            ...base,
            layer: 1
        });
    }
}
function spawnCentered(pat, blend, layer, sound = 0xff) {
    spawnEffect({
        pat,
        x: 160.0,
        y: 120.0,
        blend,
        layer,
        fixed: 1,
        sound
    });
}
function advanceGeneric(i, e) {
    const pat = patterns[e.pat];
    if (!pat) {
        killEffect(i);
        return;
    }
    e.timer++;
    if (e.timer >= (pat.frames[e.frame]?.duration ?? 0)) {
        e.timer = 0;
        e.frame++;
        if (e.frame >= pat.count) killEffect(i);
    }
}
function advanceChain(i, e) {
    const pat = patterns[e.pat];
    if (!pat) {
        killEffect(i);
        return -1;
    }
    e.timer++;
    if (e.timer < (pat.frames[e.frame]?.duration ?? 0)) return null;
    e.timer = 0;
    e.frame++;
    if (e.frame >= pat.count) {
        killEffect(i);
        return -1;
    }
    return e.frame;
}
function updateEffect(i) {
    const e = effects[i];
    const first = e.frame === 0 && e.timer === 0;
    const dir = 2 * (e.mirror ? 1 : 0) - 1;
    const fxOn = gs.option2 !== 0;
    const move = ()=>{
        e.x += e.vx;
        e.y += e.vy;
    };
    switch(e.pat){
        case 0:
            if (first && fxOn) {
                spawnChildren(e, 0x0a, 3);
                spawnChildren(e, 0x23, 3);
                spawnChildren(e, 0x24, 8);
                spawnChildren(e, 0x2f, 2);
            }
            break;
        case 2:
            if (first && fxOn) spawnChildren(e, 0x27, 8);
            break;
        case 11:
            if (first && fxOn) spawnChildren(e, 0x22, 5);
            break;
        case 12:
            if (first && fxOn) spawnChildren(e, 0x22, 8);
            break;
        case 13:
            if (first && fxOn) {
                spawnChildren(e, 0x25, 8);
                spawnChildren(e, 0x22, 5);
            }
            break;
        case 14:
            if (first && fxOn) spawnChildren(e, 0x2a, 16);
            break;
        case 15:
            if (first && fxOn) spawnChildren(e, 0x2c, 8);
            break;
        case 16:
            if (first && fxOn) spawnChildren(e, 0x2b, 8);
            break;
        case 33:
            if (first) {
                fxCounter = 0;
                spawnChildren(e, 0x26, 40, true);
            }
            break;
        case 52:
            if (first) {
                spawnChildren(e, 0x2e, 16);
                fxCounter = 0;
                fxAngleA = Math.trunc(rand("src/game/effects.ts:296:27", {
                    consumer: "src/game/effects.ts"
                }) / 91.02) << 16 >> 16;
                fxAngleB = fxAngleA + (Math.trunc(rand("src/game/effects.ts:297:39", {
                    consumer: "src/game/effects.ts"
                }) / 273.07) << 16 >> 16) + 0x1e;
                spawnChildren(e, 0x35, 40, true);
                spawnChildren(e, 0x36, 40, true);
            }
            break;
        case 10:
        case 34:
        case 35:
        case 36:
        case 37:
            if (first) {
                const a = rand("src/game/effects.ts:310:14", {
                    consumer: "src/game/effects.ts"
                }) * PI * 2 / 32768;
                const s = e.pat === 10 ? Math.trunc(rand("src/game/effects.ts:311:40", {
                    consumer: "src/game/effects.ts"
                }) / 2000) : e.pat <= 35 ? rand("src/game/effects.ts:311:71", {
                    consumer: "src/game/effects.ts"
                }) / 20000.0 : rand("src/game/effects.ts:311:90", {
                    consumer: "src/game/effects.ts"
                }) / 13000.0;
                e.vx = __numerics.cos(a) * s;
                e.vy = __numerics.sin(a) * s;
            }
            move();
            break;
        case 38:
            if (first) {
                const ang = fxCounter * 9 * PI / 180;
                const A = __numerics.cos(ang) * 3.0;
                const B = __numerics.sin(ang) * 3.0 / 3.0;
                const phi = -0.43633222222222223;
                e.vx = __numerics.cos(phi) * A - __numerics.sin(phi) * B;
                e.vy = (__numerics.cos(phi) * B + __numerics.sin(phi) * A) * dir;
                fxCounter++;
            }
            move();
            break;
        case 39:
            if (first) {
                const a = rand("src/game/effects.ts:332:14", {
                    consumer: "src/game/effects.ts"
                }) * PI * 2 / 32768;
                const s = rand("src/game/effects.ts:333:14", {
                    consumer: "src/game/effects.ts"
                }) / 13000;
                e.vx = __numerics.cos(a / 2.0 - 1.570796) * dir * s;
                e.vy = __numerics.sin(a) * s;
            }
            move();
            break;
        case 42:
        case 43:
        case 44:
        case 45:
            if (first) {
                const K = e.pat === 42 || e.pat === 44 ? 20 : 40;
                const base = [
                    0x23,
                    0x19,
                    -0x0a,
                    -0x14
                ][e.pat - 42];
                const deg = (rand("src/game/effects.ts:346:18", {
                    consumer: "src/game/effects.ts"
                }) * K >> 15) + (rand("src/game/effects.ts:346:40", {
                    consumer: "src/game/effects.ts"
                }) < 0x4000 ? 180 : 0) + base;
                const ang = deg * (3.141592 / 180);
                const s = rand("src/game/effects.ts:349:14", {
                    consumer: "src/game/effects.ts"
                }) / 13000;
                e.vx = __numerics.cos(ang) * dir * s;
                e.vy = __numerics.sin(ang) * s;
            }
            move();
            break;
        case 46:
        case 47:
            if (first) {
                if (e.pat === 46) {
                    e.vx = __numerics.sin(Math.fround(rand("src/game/effects.ts:364:33", {
                        consumer: "src/game/effects.ts"
                    }))) * 6.0;
                    e.vy = -rand("src/game/effects.ts:365:13", {
                        consumer: "src/game/effects.ts"
                    }) / 4000.0 - 2.0;
                } else {
                    e.vx = -Math.abs(Math.fround(__numerics.sin(Math.fround(rand("src/game/effects.ts:367:55", {
                        consumer: "src/game/effects.ts"
                    }))) * 4.0)) * dir;
                    e.vy = -rand("src/game/effects.ts:368:13", {
                        consumer: "src/game/effects.ts"
                    }) / 7000.0 - 2.0;
                }
            }
            e.vy += 0.2;
            if (rand("src/game/effects.ts:372:7", {
                consumer: "src/game/effects.ts"
            }) < 0x4000) e.timer++;
            if (e.y + e.vy >= 0.0) e.vy = -e.vy * (0.9 - rand("src/game/effects.ts:373:48", {
                consumer: "src/game/effects.ts"
            }) / 32768.0 * 0.3);
            move();
            break;
        case 53:
        case 54:
            if (first) {
                const ang = fxCounter * 9 * PI / 180;
                const A = __numerics.cos(ang) * 3 * 5.0;
                const B = __numerics.sin(ang) * 3 / 3 * 5.0;
                const theta = (e.pat === 53 ? fxAngleA : fxAngleB) * PI / 180;
                e.vx = __numerics.cos(theta) * A - __numerics.sin(theta) * B;
                e.vy = (__numerics.sin(theta) * A + __numerics.cos(theta) * B) * dir;
                fxCounter++;
            }
            e.vx *= 0.94;
            e.vy *= 0.94;
            move();
            break;
        case 26:
            break;
        case 5:
            {
                const f = advanceChain(i, e);
                if (f === 10) {
                    spawnCentered(21, 0, 2);
                    spawnCentered(0x38 + gs.roundNumber, 0, 2);
                } else if (f === 15) {
                    spawnCentered(0x1a, 2, 1);
                }
                return;
            }
        case 27:
            {
                const f = advanceChain(i, e);
                if (f === 0x1a) spawnCentered(5, 2, 2, gs.roundNumber + 0x0b);
                return;
            }
        case 21:
            if (advanceChain(i, e) === -1) {
                spawnCentered(6, 2, 3);
                spawnCentered(22, 0, 2, 0x17);
            }
            return;
        case 22:
            if (advanceChain(i, e) === -1) spawnCentered(23, 0, 2);
            return;
        case 23:
            if (advanceChain(i, e) === -1) {
                spawnCentered(7, 2, 2);
                spawnCentered(24, 0, 2, 0x18);
            }
            return;
        case 24:
            if (advanceChain(i, e) === -1) spawnCentered(25, 0, 2);
            return;
        case 25:
            if (advanceChain(i, e) === -1) {
                spawnCentered(0x12, 2, 2);
                gs.introState = 0;
            }
            return;
    }
    advanceGeneric(i, e);
}
export function drawEffects(camX, camY, layer) {
    for(let i = tail; i !== head; i = (i + 1) % EFFECT_SLOTS){
        const e = effects[i];
        if (!active[i] || e.layer !== layer) continue;
        const f = patterns[e.pat]?.frames[e.frame];
        if (!f) continue;
        const surf = gs.effects[f.sprite];
        if (!surf) continue;
        const k = e.fixed === 0 ? 1 : 0;
        const x = Math.trunc(e.x) + k * camX - (e.mirror ? f.width - f.offsetX : f.offsetX);
        const y = k * GROUND_Y + Math.trunc(e.y) - f.offsetY + k * camY;
        const dst = makeRect(x, y, f.width, f.height);
        const src = makeRect(0, 0, f.width, f.height);
        if (e.blend === 1 || e.blend === 2) blitBlend(dst, surf, src, gs.objectKey, e.mirror !== 0, e.blend === 1 ? BlendTable.Average : BlendTable.Add);
        else if (e.blend === 0) blit(dst, surf, src, gs.objectKey, e.mirror !== 0);
    }
}
export function flushEffectSounds(mute) {
    for(let i = tail; i !== head; i = (i + 1) % EFFECT_SLOTS){
        const e = effects[i];
        if (e.sound >= 0 && e.sound < 0x41 && !mute) {
            playSE(e.sound);
            if (hasSE(e.sound)) residueSound();
        }
        e.sound = 0xff;
    }
}

export function __logicState(){return {effects,active,owner,head,tail,patterns,fxCounter,fxAngleA,fxAngleB};}

export function __installInitialRoots(s){
if(effects!==s["effects"])throw Error('INITIAL_CONST_IDENTITY:effects');
if(active!==s["active"])throw Error('INITIAL_CONST_IDENTITY:active');
if(owner!==s["owner"])throw Error('INITIAL_CONST_IDENTITY:owner');
head=s["head"];
tail=s["tail"];
patterns=s["patterns"];
fxCounter=s["fxCounter"];
fxAngleA=s["fxAngleA"];
fxAngleB=s["fxAngleB"];
}
