import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./2bf4cca999321fd0777adb51.mjs";
import { updateChildrenMizukaB } from "./3a7948481af9e187ce0f99cd.mjs";
import { parseCommandMizukaB, dispatchMovesMizukaB } from "./4fa41a01a5aa31fe91c36ab4.mjs";
import { thinkMizukaB } from "./6b1822e2d1ff5edea6d92b49.mjs";
import { tickHookMizukaB } from "./30c9c7e1b9b733e1da86fa41.mjs";
import "./67f674b983e823561930bd25.mjs";
import "./1468d44c3e8f760e8c6bfc15.mjs";
import "./046310b46b2650a8f959abcc.mjs";
const POINTS_X = [
    -13,
    14,
    0,
    0,
    0
];
const POINTS_Y = [
    -60,
    0,
    0,
    0,
    0
];
export class MizukaB extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    a3148 = new Int32Array(64);
    a3248 = new Int32Array(64);
    a3348 = new Int32Array(64);
    f3448 = 0;
    f344c = 0;
    f3450 = 0;
    f3454 = 0;
    f3458 = 0;
    f345c = 0;
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        6,
        6,
        1,
        7,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.pointsX[0] = POINTS_X[0];
        this.pointsY[0] = POINTS_Y[0];
        this.pointsX[1] = POINTS_X[1];
        this.pointsY[1] = POINTS_Y[1];
        this.f3448 = 0;
        this.f344c = 0;
        this.f3450 = 0;
        this.f3454 = 0;
        this.f3458 = 0;
        this.f345c = 0;
        this.a3148.fill(0);
        this.a3248.fill(0);
        this.a3348.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3148[i] = 0;
        this.a3248[i] = 0;
        this.a3348[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {
        tickHookMizukaB(this);
    }
    parseCommand() {
        parseCommandMizukaB(this);
    }
    dispatchMoves() {
        dispatchMovesMizukaB(this);
    }
    think() {
        thinkMizukaB(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMizukaB(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
