import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { CHARACTER_FOLDERS } from "./ed94471e7e2b500bb335f7ed.mjs";
import { UnportedCharacter } from "./951a63061c72a41469745332.mjs";
import { Akane } from "./d5d0b5c6c6d206be57771f53.mjs";
import { Ayu } from "./7f742a07bafe299630bf0ccc.mjs";
import { Mai } from "./92613c9311ef295d4ad9aef6.mjs";
import { Makoto } from "./02e428a36f4bbcadda898a8a.mjs";
import { Mayu } from "./e7866b034b80ad53e9e397e3.mjs";
import { Mio } from "./b85c24a12b191363e79c14f7.mjs";
import { Misaki } from "./4289fd6ee2b3f7593da2424b.mjs";
import { Nagamori } from "./40a927e055ad669c28a62e16.mjs";
import { Nanase } from "./7d0378b083efc99444780ade.mjs";
import { ExNanase } from "./1a439a84f9ecedb83c1bd285.mjs";
import { Nayuki } from "./ed1d2b18902be84cc006d5fb.mjs";
import { Kaori } from "./20739f84a55ac143db202ecd.mjs";
import { Ikumi } from "./8c6315d573d34b8894957bc6.mjs";
import { Sayuri } from "./fd134f54c4b7ed0bea4684c4.mjs";
import { Shiori } from "./864ad30d714b961909e01ffc.mjs";
import { Mishio } from "./d05404f3d6516f06f161942e.mjs";
import { Akiko } from "./9d12108b99330194106aa335.mjs";
import { NayukiB } from "./ed38def0ff38f29d82f8035c.mjs";
import { MizukaB } from "./19ae084e8b72a0ea4ade37e6.mjs";
import { Kanna } from "./e85e07ff802a12454e3a4109.mjs";
import { Kano } from "./7aa79767eb9fd852f4114c39.mjs";
import { Minagi } from "./157713df8e669ec920ab985b.mjs";
import { Misuzu } from "./b8e0bbb7eef6d958087dea02.mjs";
import { Mizuka } from "./83ea1601ecf828531607c537.mjs";
const PORTED = {
    0: Nanase,
    1: Ayu,
    2: Mai,
    3: Makoto,
    4: Akane,
    5: Mayu,
    6: Nagamori,
    7: Misaki,
    8: Shiori,
    9: Sayuri,
    10: Nayuki,
    11: Mio,
    12: ExNanase,
    13: Kaori,
    14: Ikumi,
    15: Mishio,
    16: Akiko,
    17: NayukiB,
    18: MizukaB,
    19: Kanna,
    20: Kano,
    21: Minagi,
    22: Nayuki,
    23: Misuzu,
    24: Mizuka
};
export function registerCharacter(id, cls) {
    PORTED[id] = cls;
}
export function isPorted(id) {
    return id in PORTED;
}
export function createCharacter(id, side) {
    const cls = PORTED[id] ?? UnportedCharacter;
    return new cls(side, id, CHARACTER_FOLDERS[id] ?? "");
}

export function __logicState(){return {PORTED};}

export function __installInitialRoots(s){
if(PORTED!==s["PORTED"])throw Error('INITIAL_CONST_IDENTITY:PORTED');
}
