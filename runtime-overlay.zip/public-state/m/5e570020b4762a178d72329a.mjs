import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./d80c43470aa1f91788a9cb77.mjs";
import { childCount, childDuration, frameChild, frameEffect, openSpawnFrame } from "./8b7e65180486b4c98515924a.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function groundJumpCancel(c, exact3) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && (exact3 ? c.d168 === 3 : c.d168 >= 2)) {
        jumpTo456(c);
        return true;
    }
    return false;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a === 0) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function attackStart(c, meter, se, hits) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = hits;
}
function stopIfNotDashing(c) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
}
function dashSlide(c) {
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - 0.06;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function airDashEnd(c, vx) {
    c.setState(9);
    c.vx = vx;
    c.ay = 0.03;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function burstFx(c, d) {
    d.w04 = 9;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 60;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    c.w16c = 1;
    c.seRequest = 62;
}
function airLand(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(99);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.timer = w16(c.timer + 1);
    c.b158 = 0;
    if (c.life > 0 && c.timer > 99 && c.frame === 0) c.setState(96);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(96);
    }
}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    c.b158 = 0;
    if (atStart(c)) {
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx = c.vx + 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy = c.vy + c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy = c.vy + c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        burstFx(c, d);
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 6)) {
        c.stopMotion();
        burstFx(c, d);
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 17) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.startAfterimage(3);
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (atStart(c)) {
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.vx = 1.5;
    c.b158 = 1;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = 0;
    }
    if (c.inputX === c.facing && c.f313c >= 120) c.setState(178);
    if (c.inputX !== c.facing && c.f3138 >= 60) c.setState(178);
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.startAfterimage(2);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) {
        c.vx = -1.8;
        c.vy = -0.9;
    }
    if (c.frame > 1) c.vy = c.vy + 0.038;
    if (c.frame > 2 && c.vy + c.y >= 0.0 && c.f3138 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.f3138++;
        c.y = 0.0;
        c.seRequest = 9;
        c.timer = 0;
        c.frame = 11;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.faceOpponent();
        c.setState(0);
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 1.8;
        c.startAfterimage(3);
        c.vy = 0.0;
        c.ay = 0.0;
        if (c.f3138 === 0) c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 120) airDashEnd(c, 1.3);
    if (c.inputX !== c.facing && c.f3138 >= 48) airDashEnd(c, 1.3);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = -1.8;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
        if (c.f3138 === 0) c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9);
    if (c.inputX !== -c.facing && c.f3138 >= 42) airDashEnd(c, -0.9);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.b158 = 0;
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        if (c.ay === 0.0) c.ay = 0.035;
        c.vx = 0.0;
        c.vy = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c) && c.f3140 === 0) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
        fxAtSelf(c, d, 4, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.f3140++;
            if (c.f3140 < 5) {
                c.frame = 0;
                return;
            }
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 11) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 11;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 2) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 11) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function groundNormal(c, jc, atk, meter, se, clearBelow, crouchable) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c);
    if (jc !== 0 && groundJumpCancel(c, jc === 3)) return;
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, crouchable);
    }
}
const s200 = (c)=>groundNormal(c, 2, 1, 5, 21, 3, false);
const s201 = (c)=>groundNormal(c, 2, 1, 15, 20, 4, false);
const s202 = (c)=>groundNormal(c, 0, 2, 15, 20, 4, false);
const s203 = (c)=>groundNormal(c, 3, 2, 35, 20, 5, false);
const s204 = (c)=>groundNormal(c, 2, 1, 5, 21, 3, true);
const s205 = (c)=>groundNormal(c, 3, 3, 13, 20, 4, true);
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c);
    if (atFrame(c, 1)) attackStart(c, 25, 20, 6);
    if (atFrame(c, 1)) {
        const d = openSpawnFrame();
        d.w04 = 404;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 30;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
        c.markChildrenNear(s16(ftol(c.x)), -10, 90, 50);
    }
    if (advance(c, dur)) {
        if (c.w16c > 0) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function airNormal(c, atk, meter, se, clearBelow, loop207) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.state = 13;
        c.onStateChange();
        return;
    }
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (loop207 && c.frame === 4 && c.f3138 < 3) {
            c.frame = 2;
            c.f3138++;
        }
        if (c.frame >= cnt) c.setState(9);
    }
}
const s207 = (c)=>airNormal(c, 1, 5, 21, 3, true);
const s208 = (c)=>airNormal(c, 2, 13, 20, 4, false);
const s209 = (c)=>airNormal(c, 2, 30, 20, 4, false);
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) {
        c.vx = 1.4;
        c.vy = -1.5;
        c.ay = 0.08;
    }
    if (atFrame(c, 2)) attackStart(c, 15, 20, 1);
    if (atFrame(c, 5)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 0) c.vy = c.vy + c.ay;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 5) {
            if (c.y + c.vy < 0.0) c.frame = w16(c.frame - 1);
            else c.y = 0.0;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s216(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.b158 = 0;
    }
    if (atFrame(c, 3)) {
        attackStart(c, 20, 20, 1);
        c.vx = 1.5;
    }
    if (c.vx > 0.0) c.vx = c.vx - 0.035;
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        if (c.frame < 5) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (atStart(c)) {
        attackStart(c, 30, 20, 1);
        c.vx = c.vx / 2.0;
        c.ay = 0.07;
    }
    if (c.d168 > 1) {
        c.setState(213);
        c.stopMotion();
        return;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.shakeScreen(3, 0);
        const d = openSpawnFrame();
        d.w04 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        d.b2c = 7;
        frameEffect(d);
        c.seRequest = 7;
        c.setState(214);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy = c.vy + c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s215(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.frame === 3 || c.frame === 4) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - 0.035;
        if (c.vx < 0.0) c.vx = 0.0;
        if (c.vy + c.y > 0.0) {
            c.frame = 5;
            c.timer = 0;
            c.shakeScreen(3, 0);
            const d = openSpawnFrame();
            fxAtSelf(c, d, 3, 2, 0);
            c.seRequest = 7;
            return;
        }
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 3) {
            c.vx = 2.0;
            c.vy = -0.8;
            c.ay = 0.035;
        }
        if (c.frame === 5) c.frame = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.stopMotion();
        o.onStateChange();
        c.state = 221;
        o.state = 107;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x25;
        d.y = ftol(c.y) - 42;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 1) {
        o.w140 = 10000;
        c.w16c = 1;
        o.state = 104;
        o.x = c.facing * 0x23 + c.x;
        o.y = -35.0;
        c.d168 = 0;
    }
    if (c.frame === 5 && c.timer === 45) {
        c.frame = 6;
        c.timer = 0;
        return;
    }
    if (atFrame(c, 6)) {
        o.hitstop = 30;
        c.f313c = 0;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 24;
        d.b20 = 2;
        d.b2c = 2;
        d.b21 = 1;
        frameEffect(d);
        applyDirectDamage(c, 75, 1000.0);
    }
    if (atFrame(c, 10)) {
        o.hitstop = 30;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 24;
        d.b20 = 2;
        d.b2c = 2;
        d.b21 = 1;
        frameEffect(d);
        o.w140 = 0;
        applyDirectDamage(c, 800, 750.0);
        o.state = 97;
        o.onStateChange();
    }
    if (c.frame > 14) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.setState(13);
            c.stopMotion();
            return;
        }
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) {
            o.state = 113;
            if (c.facing === 1 && c.x + 20.0 < 40.0) c.x = 40.0;
            if (c.facing === -1 && c.x > 620.0) c.x = 620.0;
            o.y = 0.0;
            o.x = c.x;
        }
        if (c.frame === 2) {
            c.x = (-17 - o.pointsX[1]) * c.facing + o.x;
        }
        if (c.frame === 7 && c.f3138 < 3) {
            c.frame = w16(c.frame - 2);
            c.f3138++;
        }
        if (c.frame === 14) {
            c.vx = -0.7;
            c.vy = -1.7;
            c.ay = 0.037;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function dashAttack(c, atk, meter, se, clearBelow) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    c.b158 = 0;
    if (atStart(c)) {
        c.vx = 1.9;
        c.vy = 0.0;
    }
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
const s230 = (c)=>dashAttack(c, 1, 5, 21, 3);
function s231(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atStart(c)) {
        c.vx = 1.9;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) attackStart(c, 10, 20, 1);
    if (advance(c, dur)) {
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function s232(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, true)) return;
    c.b158 = 0;
    c.startAfterimage(3);
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atStart(c)) {
        c.vx = 1.9;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) attackStart(c, 10, 20, 1);
    if (advance(c, dur)) {
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
const s233 = (c)=>dashAttack(c, 1, 5, 21, 3);
function s234(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (atStart(c)) {
        c.ax = 0.0;
        c.w16c = 1;
    }
    if (atFrame(c, 2)) {
        c.vx = 1.1;
        c.vy = -1.2;
        c.ay = 0.034;
    }
    if (atFrame(c, 6)) {
        addMeter(c, 25);
        c.seRequest = 20;
    }
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.y = 0.0;
        c.onStateChange();
        c.stopMotion();
        return;
    }
    if (advance(c, dur)) {
        if (c.frame < 9) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s235(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (atStart(c)) {
        c.ax = 0.0;
        c.w16c = 1;
    }
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.frame === 3 || c.frame === 4) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - 0.025;
        if (c.vx < 0.0) c.vx = 0.0;
        if (c.vy + c.y > 0.0) {
            c.w16c = 1;
            c.frame = 5;
            c.timer = 0;
            c.shakeScreen(3, 0);
            c.vx = c.vx * 0.3;
            const d = openSpawnFrame();
            fxAtSelf(c, d, 3, 2, 0);
            c.seRequest = 7;
            return;
        }
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 3) {
            c.vx = 2.5;
            c.vy = -0.8;
            c.ay = 0.035;
        }
        if (c.frame === 5) c.frame = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 249;
        o.state = 100;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x1d;
        d.y = ftol(c.y) - 49;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.x = c.facing * 0x1d + c.x;
        o.y = c.y - 49.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 209;
            c.frame = 2;
        }
    }
}
function s249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 6) c.biasCamera(50, 3);
    if (c.frame < 6) c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 5) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.state = 13;
        return;
    }
    if (c.frame === 2) {
        o.y = c.y - 69.0;
        o.x = c.facing * 0x21 + c.x;
        o.state = 101;
    }
    if (c.frame === 3) {
        o.y = c.y - 71.0;
        o.x = c.facing * 0xb + c.x;
        o.state = 101;
        o.facing = -c.facing;
    }
    if (c.frame === 4) {
        o.y = c.y - 49.0;
        o.x = c.facing * 0x1a + c.x;
        o.state = 101;
        o.facing = -c.facing;
    }
    if (c.frame === 5) {
        o.y = c.y - 46.0;
        o.x = c.facing * 0x19 + c.x;
        o.state = 118;
        o.facing = c.facing;
    }
    if (c.frame === 6) {
        o.y = c.y - 72.0;
        o.x = c.x + 0.0;
        o.state = 104;
        o.facing = c.facing;
    }
    if (atFrame(c, 7)) {
        o.y = c.y - 40.0;
        o.x = c.x - c.facing * 0x14;
        o.state = 63;
        applyDirectDamage(c, 1200, 500.0);
        o.onStateChange();
        o.knockX = -2.0;
        o.knockY = 0.0;
    }
    if (atFrame(c, 8)) c.ay = 0.035;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 9) c.facing = -c.facing;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function child404(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function childFamily(c, i, p) {
    const ch = c.children[i];
    ch[p.axis] = p.a;
    if (ch.timer > p.t1) ch[p.axis] = p.b;
    if (ch.timer > p.t2) ch[p.axis] = p.c3;
    if (ch.timer > p.t3) c.freeChild(i);
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
}
const POS = {
    a: 10.0,
    b: 0.3,
    c3: 10.0,
    t1: 28,
    t2: 90,
    t3: 130
};
const NEG = {
    a: -10.0,
    b: -0.3,
    c3: -10.0,
    t1: 28,
    t2: 90,
    t3: 130
};
const FAMILY = {
    418: {
        axis: "vx",
        ...POS
    },
    419: {
        axis: "vy",
        ...NEG
    },
    420: {
        axis: "vx",
        ...NEG
    },
    421: {
        axis: "vx",
        ...POS
    },
    422: {
        axis: "vy",
        ...POS
    },
    423: {
        axis: "vx",
        ...NEG
    },
    424: {
        axis: "vy",
        a: -10.0,
        b: 0.3,
        c3: 10.0,
        t1: 28,
        t2: 90,
        t3: 130
    },
    425: {
        axis: "vy",
        ...POS
    },
    426: {
        axis: "vx",
        ...POS
    },
    427: {
        axis: "vy",
        ...POS
    },
    428: {
        axis: "vx",
        ...NEG
    },
    429: {
        axis: "vy",
        ...NEG
    },
    430: {
        axis: "vy",
        ...NEG
    },
    431: {
        axis: "vx",
        ...POS
    },
    432: {
        axis: "vy",
        ...POS
    },
    433: {
        axis: "vx",
        ...NEG
    },
    434: {
        axis: "vy",
        ...NEG
    },
    435: {
        axis: "vx",
        ...POS
    },
    436: {
        axis: "vy",
        ...POS
    },
    437: {
        axis: "vx",
        ...NEG
    },
    438: {
        axis: "vx",
        ...POS
    },
    439: {
        axis: "vx",
        ...NEG
    },
    440: {
        axis: "vy",
        ...NEG
    },
    441: {
        axis: "vy",
        ...POS
    },
    442: {
        axis: "vx",
        ...POS
    },
    443: {
        axis: "vy",
        a: -10.0,
        b: -0.3,
        c3: -10.0,
        t1: 28,
        t2: 150,
        t3: 180
    },
    444: {
        axis: "vy",
        a: 10.0,
        b: 0.3,
        c3: 10.0,
        t1: 28,
        t2: 150,
        t3: 180
    },
    445: {
        axis: "vx",
        a: 10.0,
        b: 0.3,
        c3: 10.0,
        t1: 23,
        t2: 510,
        t3: 540
    },
    446: {
        axis: "vx",
        a: -10.0,
        b: -0.3,
        c3: -10.0,
        t1: 26,
        t2: 270,
        t3: 300
    }
};
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    212: s212,
    213: s213,
    215: s215,
    216: s216,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    234: s234,
    235: s235,
    248: s248,
    249: s249
});
const childMap = {
    404: child404
};
for (const [k, p] of Object.entries(FAMILY))childMap[Number(k)] = (c, i)=>childFamily(c, i, p);
registerChildren(childMap);

export function __logicState(){return {POS,NEG,FAMILY,childMap};}

export function __installInitialRoots(s){
if(POS!==s["POS"])throw Error('INITIAL_CONST_IDENTITY:POS');
if(NEG!==s["NEG"])throw Error('INITIAL_CONST_IDENTITY:NEG');
if(FAMILY!==s["FAMILY"])throw Error('INITIAL_CONST_IDENTITY:FAMILY');
if(childMap!==s["childMap"])throw Error('INITIAL_CONST_IDENTITY:childMap');
}
