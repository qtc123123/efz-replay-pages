import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./9410f25ccc5489d02b4dd080.mjs";
import { childCount, childDuration, childSpawnFrame, frameEffect, openSpawnFrame } from "./1d4a8932dc5ab92063658a65.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function normalHit(c, meter, se) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = 1;
}
function fxAt(c, d, pat, dx, dy, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x) + dx;
    d.y = ftol(c.y) + dy;
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function groundJumpCancel(c, ok) {
    if (c.inputY !== -1 || c.frame <= 0 || c.d15c >= 3 || !ok) return false;
    jumpTo456(c);
    return true;
}
function airJumpCancel(c) {
    if (c.inputY !== -1 || c.frame <= 0 || c.d15c >= 3 || c.d168 < 2 || c.b15a !== 0) return false;
    c.b15a = c.b15a + 1 & 0xff;
    c.state = 14;
    if (c.inputX === c.facing) c.state = 15;
    if (c.inputX === -c.facing) c.state = 16;
    c.d168 = 0;
    c.onStateChange();
    return true;
}
function endGround(c, base, crouchable) {
    c.state = base;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function landTo13(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return true;
    }
    return false;
}
function sEmpty(_c) {}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy += c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAt(c, d, 8, 0, 0, 2, 0);
    } else {
        c.vy += c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        fxAt(c, d, 9, 0, -70, 2, 1);
        c.w16c = 1;
        c.seRequest = 62;
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 7)) {
        c.stopMotion();
        fxAt(c, d, 9, 0, -70, 2, 1);
        c.w16c = 1;
        c.seRequest = 62;
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 15) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.startAfterimage(3);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (atFrame(c, 3) && c.y >= 0.0) {
        d.w04 = 31;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 0;
        d.d1c = c.facing === -1 ? 1 : 0;
        frameEffect(d);
        c.vx = 1.8;
        c.vy = -1.2;
        c.ay = 0.01;
        c.seRequest = 17;
    }
    c.vy += c.ay;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 120) {
        c.setState(9);
        c.vx = 0.5;
        c.ay = 0.03;
    }
    if (c.inputX !== c.facing && c.f3138 >= 39) {
        c.setState(9);
        c.vx = 0.5;
        c.ay = 0.03;
    }
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(2);
    }
    if (atFrame(c, 3) && c.y === 0.0) {
        c.vx = -1.8;
        c.vy = -1.3;
        c.ay = 0.01;
        c.seRequest = 17;
        d.w04 = 31;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 0;
        d.d1c = c.facing === 1 ? 1 : 0;
        frameEffect(d);
    }
    c.vy += c.ay;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX !== -c.facing) c.f3138 = 0;
    if (c.f313c > 39 && c.inputX !== -c.facing || c.f313c >= 120) {
        c.setState(9);
        c.vx = -0.5;
        c.ay = 0.03;
    }
}
function airDash(c, dir, vxEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3140 === 0) {
        c.vx = dir * 1.8;
        c.vy = -0.3;
        c.seRequest = 17;
        c.f3140++;
    }
    c.vy += 0.01;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === dir * c.facing && c.f313c >= 120) {
        c.setState(9);
        c.vx = vxEnd;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
    if (c.inputX !== dir * c.facing && c.f3138 >= 48) {
        c.setState(9);
        c.vx = vxEnd;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
}
const s165 = (c)=>airDash(c, 1, 1.3);
const s166 = (c)=>airDash(c, -1, -0.9);
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(0xb0, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAt(c, d, 1, 0, 0, 2, 1);
    }
    if (atFrame(c, 2)) fxAt(c, d, 4, 0, 0, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAt(c, d, 8, 0, 0, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 18;
        fxAt(c, d, 1, 0, 0, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 5) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 5;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 3) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 5) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) normalHit(c, 5, 21);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) c.vx = 0.5;
    if (atFrame(c, 2)) normalHit(c, 15, 20);
    if (c.frame > 1) {
        c.vx -= 0.02;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (advance(c, dur)) {
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) normalHit(c, 15, 20);
    if (advance(c, dur)) {
        if (c.frame < 4) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 4)) normalHit(c, 35, 20);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) normalHit(c, 5, 21);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, true);
    }
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atFrame(c, 2)) normalHit(c, 13, 20);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, true);
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atFrame(c, 3)) normalHit(c, 25, 20);
    if (advance(c, dur)) {
        if (c.frame === 3) {
            d.w04 = 0;
            d.x = ftol(c.x) + c.facing * 37;
            d.y = ftol(c.y) - 2;
            d.b20 = 2;
            c.voiceRequest = 3;
            d.b21 = 1;
            frameEffect(d);
        }
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, true);
    }
}
function airNormalHead(c, hitFrame, meter, se) {
    c.vy += c.ay;
    if (airJumpCancel(c)) return false;
    if (atFrame(c, hitFrame)) normalHit(c, meter, se);
    if (landTo13(c)) return false;
    return true;
}
function s207(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!airNormalHead(c, 1, 5, 21)) return;
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s208(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!airNormalHead(c, 2, 13, 20)) return;
    if (advance(c, dur)) {
        if (c.frame < 5) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s209(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!airNormalHead(c, 3, 30, 20)) return;
    if (advance(c, dur)) {
        if (c.frame < 8) c.d168 = 0;
        if (c.frame === 7 && c.f3138 < 1) {
            c.frame = w16(c.frame - 3);
            c.f3138++;
        }
        if (c.frame >= cnt) c.setState(9);
    }
}
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) {
        c.vx = 1.4;
        c.vy = -1.5;
        c.ay = 0.08;
    }
    if (atFrame(c, 2)) normalHit(c, 15, 20);
    if (atFrame(c, 5)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 0) c.vy += c.ay;
    if (advance(c, dur)) {
        if (c.frame < 6) c.d168 = 0;
        if (c.frame === 5) {
            if (c.y + c.vy < 0.0) c.frame = w16(c.frame - 1);
            else c.y = 0.0;
        }
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 8)) normalHit(c, 35, 20);
    if (c.y < 0.0) {
        c.vy += 0.055;
        if (c.y + c.vy > 0.0) {
            c.stopMotion();
            c.y = 0.0;
            c.timer = 0;
            c.frame = 8;
            return;
        }
    }
    if (advance(c, dur)) {
        if (c.frame === 7) {
            c.vx = 0.5;
            c.vy = -1.2;
        }
        if (c.frame < 5) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function landImpactFx(c, d) {
    d.w04 = 3;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 0;
    d.b2c = 7;
    frameEffect(d);
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vy += c.ay;
    if (atStart(c)) {
        normalHit(c, 30, 20);
        c.vx = c.vx / 2.0;
        c.ay = 0.07;
    }
    if (c.d168 > 1) {
        c.setState(213);
        c.stopMotion();
        return;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.vy = 0.0;
        c.shakeScreen(3, 0);
        landImpactFx(c, d);
        c.seRequest = 7;
        c.setState(214);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        landImpactFx(c, d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 7, true);
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 221;
        o.state = 110;
        o.d128 = 1;
        fxAt(c, d, 0, c.facing * 36, -44, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 7, true);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.biasCameraY(50, 10);
    if (atStart(c)) {
        o.state = 100;
        o.stopMotion();
        o.y = 0.0;
        o.x = c.facing * 42 + c.x;
        o.onStateChange();
    }
    if (atFrame(c, 5)) {
        o.onStateChange();
        o.state = 59;
        o.knockX = 2.0;
        o.knockY = -1.0;
        o.ay = 0.035;
        o.y = -59.0;
        o.x = c.facing * 15 + c.x;
        o.d128 = 1;
        applyDirectDamage(c, 1200, 750.0);
        c.comboCount = s16(c.comboCount - 1);
        c.comboDisplay = s16(c.comboDisplay - 1);
        o.facing = -c.facing;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) {
            o.state = 108;
            o.y = 0.0;
            o.x = c.facing * 36 + c.x;
        }
        if (c.frame === 2) {
            o.state = 108;
            o.y = 0.0;
            o.x = c.facing * 35 + c.x;
        }
        if (c.frame === 3) {
            o.y = 0.0;
            o.x = c.facing * 34 + c.x;
        }
        if (c.frame === 4) {
            o.state = 104;
            o.y = -32.0;
            o.x = c.x - c.facing * 2;
            o.facing = c.facing;
        }
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function airNormalB(c, hitFrame, meter, se) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = 0.5;
        c.ay = 0.03;
    }
    if (atFrame(c, hitFrame)) normalHit(c, meter, se);
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s230 = (c)=>airNormalB(c, 1, 5, 21);
const s231 = (c)=>airNormalB(c, 2, 10, 21);
const s232 = (c)=>airNormalB(c, 1, 10, 20);
function s248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.vy += c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 249;
        o.state = 100;
        fxAt(c, d, 0, c.facing * 31, -64, 2, 1);
        o.x = c.facing * 31 + c.x;
        o.y = c.y - 64.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 209;
            c.frame = 2;
        }
    }
}
function s249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 4) c.biasCamera(50, 3);
    if (c.frame < 4) c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy += c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 5) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.state = 13;
        return;
    }
    if (c.frame === 1) {
        o.y = c.y - 64.0;
        o.x = c.facing * 30 + c.x;
    }
    if (c.frame === 2) {
        o.y = c.y - 64.0;
        o.x = c.facing * 29 + c.x;
    }
    if (c.frame === 3) {
        o.y = c.y - 96.0;
        o.x = c.facing * 11 + c.x;
        o.state = 104;
        o.facing = c.facing;
    }
    if (atFrame(c, 4)) {
        o.y = c.y - 39.0;
        o.x = c.x - c.facing * 33;
        o.state = 63;
        applyDirectDamage(c, 1200, 500.0);
        o.onStateChange();
        o.knockX = -2.0;
        o.knockY = 0.0;
    }
    if (atFrame(c, 7)) c.ay = 0.035;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 8) c.facing = -c.facing;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
registerStates({
    103: sEmpty,
    107: sEmpty,
    113: sEmpty,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    248: s248,
    249: s249
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    return true;
}
function slotStart(c, i, key) {
    const ch = c.children[i];
    c[key] = 1;
    if (ch.frame === 0 && ch.timer === 0 && c.a3258[i] === 0) {
        ch.hitsLeft = 1;
        c.a3258[i]++;
    }
}
function slotFree(c, i, key) {
    c.freeChild(i);
    c[key] = 0;
}
function grabCheck(c, i, voiceFirst) {
    const ch = c.children[i];
    const o = c.opponent;
    if (ch.x + 50.0 > o.x && ch.x - 50.0 < o.x && ch.y + 50.0 > o.y - 40.0 && ch.y - 50.0 < o.y - 40.0 && o.y < 0.0 && o.state !== 96) {
        ch.frame = 2;
        if (voiceFirst) {
            c.voiceRequest = 2;
            ch.timer = 0;
        } else {
            ch.timer = 0;
            c.voiceRequest = 2;
        }
    }
}
function hitFreeze(c, i, n) {
    const ch = c.children[i];
    if (ch.hitState === 3 && c.a3158[i] === 0) {
        c.opponent.hitstop = n;
        ch.hitstop = n;
        c.a3158[i]++;
    }
}
function c403(c, i) {
    const ch = c.children[i];
    slotStart(c, i, "f346c");
    if (ch.frame === 1) {
        grabCheck(c, i, true);
        if ((c.state === 250 || c.state === 252) && c.frame <= 1 || ch.hitState === 4 || ch.hitState === 5) {
            slotFree(c, i, "f346c");
            return;
        }
    }
    hitFreeze(c, i, 60);
    if (childAdvance(c, i)) {
        if (ch.frame === 2) {
            slotFree(c, i, "f346c");
            return;
        }
        if (ch.frame >= childCount) slotFree(c, i, "f346c");
    }
}
function c404(c, i) {
    const ch = c.children[i];
    slotStart(c, i, "f3470");
    if (ch.frame === 1) {
        grabCheck(c, i, false);
        if ((c.state === 251 || c.state === 252) && c.frame <= 1 || ch.hitState === 4 || ch.hitState === 5) {
            slotFree(c, i, "f3470");
            return;
        }
    }
    hitFreeze(c, i, 60);
    if (childAdvance(c, i)) {
        if (ch.frame === 2) slotFree(c, i, "f3470");
        if (ch.frame >= childCount) slotFree(c, i, "f3470");
    }
}
function c405(c, i) {
    const ch = c.children[i];
    slotStart(c, i, "f3474");
    if (ch.frame === 1) {
        grabCheck(c, i, false);
        if (c.state === 252 && c.frame <= 1 || ch.hitState === 4 || ch.hitState === 5) {
            slotFree(c, i, "f3474");
        }
    }
    hitFreeze(c, i, 90);
    if (childAdvance(c, i)) {
        if (ch.frame === 2) {
            slotFree(c, i, "f3474");
            return;
        }
        if (ch.frame >= childCount) slotFree(c, i, "f3474");
    }
}
function cWait(c, i, key, s1) {
    const ch = c.children[i];
    const o = c.opponent;
    slotStart(c, i, key);
    if (ch.frame === 0 && ch.timer > 20) {
        if (ch.x + 50.0 > o.x && ch.x - 50.0 < o.x) {
            ch.frame = 1;
            ch.timer = 0;
        }
        if ((c.state === s1 || c.state === 255) && c.frame === 0 || ch.hitState === 4 || ch.hitState === 5 || c.state > 49 && c.state < 150) {
            const d = childSpawnFrame;
            d.w04 = 0;
            d.x = ftol(ch.x);
            d.y = ftol(ch.y);
            d.b20 = 2;
            d.b21 = 1;
            frameEffect(d);
            slotFree(c, i, key);
            return;
        }
    }
    if (ch.frame === 4 && ch.timer === 0) c.voiceRequest = 0;
    if (childAdvance(c, i)) {
        if (ch.frame === 1) slotFree(c, i, key);
        if (ch.frame === 12 && c.a3258[i] < 3) {
            ch.frame = w16(ch.frame - 2);
            c.a3258[i]++;
        }
        if (ch.frame >= childCount) slotFree(c, i, key);
    }
}
const c406 = (c, i)=>cWait(c, i, "f3478", 253);
const c407 = (c, i)=>cWait(c, i, "f347c", 254);
function c408(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    slotStart(c, i, "f3480");
    if (ch.frame === 0 && ch.timer > 20) {
        if (ch.x + 70.0 > o.x && ch.x - 70.0 < o.x) {
            ch.frame = 1;
            ch.timer = 0;
        }
        if (c.state === 255 && c.frame === 0 || ch.hitState === 4 || ch.hitState === 5) {
            slotFree(c, i, "f3480");
            return;
        }
    }
    if (ch.frame === 4 && ch.timer === 0) c.voiceRequest = 0;
    if (childAdvance(c, i)) {
        if (ch.frame === 1) slotFree(c, i, "f3480");
        if (ch.frame >= childCount) slotFree(c, i, "f3480");
    }
}
registerChildren({
    403: c403,
    404: c404,
    405: c405,
    406: c406,
    407: c407,
    408: c408
});
