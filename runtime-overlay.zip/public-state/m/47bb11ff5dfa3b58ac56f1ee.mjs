// Runtime-neutral diagnostic encoding. No Node, DOM, hashing, renderer or I/O imports.
// All JS NaNs are semantically equal; signed zero, infinities and finite binary64
// encodings are distinct. Typed integer width is retained in container records.
const fp=new DataView(new ArrayBuffer(8));
export const CANONICAL_FORMAT='efz-canonical-state/2';
const byteHex=Array.from({length:256},(_,n)=>n.toString(16).padStart(2,'0'));
const finiteTokens=new Map();
export function numberToken(n){
 if(Number.isNaN(n))return 'nan';if(n===Infinity)return '+inf';if(n===-Infinity)return '-inf';
 if(n===0)return Object.is(n,-0)?'8000000000000000':'0000000000000000';
 const cached=finiteTokens.get(n);if(cached!==undefined)return cached;
 fp.setFloat64(0,n,false);let s='';for(let i=0;i<8;i++)s+=fp.getUint8(i).toString(16).padStart(2,'0');
 if(finiteTokens.size<4096)finiteTokens.set(n,s);return s;
}
const tag=v=>Object.prototype.toString.call(v).slice(8,-1);
export const propertyPath=(p,k)=>/^(0|[1-9][0-9]*)$/.test(k)?`${p}[${k}]`:/^[A-Za-z_$][\w$]*$/.test(k)?`${p}.${k}`:`${p}[${JSON.stringify(k)}]`;
export function canonicalSnapshot(root,{exclude=()=>false,identity=()=>null,functionIdentity=()=>null,maxRows=2000000,onRow=null}={}){
 const rows=[],seen=new Map();let count=0;
 const emit=(path,type,value)=>{if(count++>=maxRows)throw Error('CANONICAL_ROW_LIMIT');const row={path,type,value};if(onRow)onRow(row);else rows.push(row);};
 function walk(v,path){
  if(exclude(path,v))return;
  if(v===null){emit(path,'null',null);return;}
  const t=typeof v;
  if(t==='number'){emit(path,'f64',numberToken(v));return;}
  if(t==='string'||t==='boolean'){emit(path,t,v);return;}
  if(t==='undefined'){emit(path,t,null);return;}
  if(t==='bigint'){emit(path,t,v.toString());return;}
  if(t==='symbol')throw Error('CANONICAL_SYMBOL '+path);
  if(t==='function'){
   const id=functionIdentity(v,path);if(!id)throw Error('CANONICAL_FUNCTION_ID '+path);
   emit(path,'function',id);return;
  }
  const id=identity(v,path);if(id!==null){emit(path,'immutable',id);return;}
  if(seen.has(v)){emit(path,'alias',seen.get(v));return;}seen.set(v,path);
  const kind=tag(v);
  if(kind==='Promise'||kind==='WeakMap'||kind==='WeakSet'||kind==='WeakRef')throw Error('CANONICAL_UNSUPPORTED '+kind+' '+path);
  if(ArrayBuffer.isView(v)){
   emit(path,kind,{length:v.length??v.byteLength,byteOffset:v.byteOffset,byteLength:v.byteLength});
   if(kind==='DataView'){
    for(let i=0;i<v.byteLength;i++)emit(`${path}[${i}]`,'u8',v.getUint8(i));
   }else{for(let i=0;i<v.length;i++)walk(v[i],`${path}[${i}]`);}
   walk(v.buffer,path+'.$buffer');
   return;
  }
  if(kind==='ArrayBuffer'||kind==='SharedArrayBuffer'){
   const bytes=new Uint8Array(v);let hex='';for(let i=0;i<bytes.length;i++)hex+=byteHex[bytes[i]];emit(path,kind,{byteLength:bytes.length,hex});return;
  }
  if(kind==='Map'){
   emit(path,'Map',v.size);let i=0;for(const [k,x] of v){walk(k,`${path}[${i}].key`);walk(x,`${path}[${i}].value`);i++;}return;
  }
  if(kind==='Set'){emit(path,'Set',v.size);let i=0;for(const x of v)walk(x,`${path}[${i++}]`);return;}
  if(kind==='Date'){emit(path,'Date',numberToken(v.getTime()));return;}
  if(kind==='RegExp'){emit(path,'RegExp',[v.source,v.flags]);walk(v.lastIndex,path+'.lastIndex');return;}
  const keys=Reflect.ownKeys(v);if(keys.some(k=>typeof k==='symbol'))throw Error('CANONICAL_SYMBOL_KEY '+path);
  const selected=keys.filter(k=>!(Array.isArray(v)&&k==='length')&&!exclude(propertyPath(path,k),Object.getOwnPropertyDescriptor(v,k)?.value,v,k)).sort((a,b)=>{
   const ai=/^(0|[1-9][0-9]*)$/.test(a),bi=/^(0|[1-9][0-9]*)$/.test(b);return ai&&bi?Number(a)-Number(b):ai?-1:bi?1:a<b?-1:a>b?1:0;
  });
  emit(path,Array.isArray(v)?'Array':v.constructor?.name??'Object',Array.isArray(v)?{length:v.length,keys:selected}:selected);
  for(const k of selected){const d=Object.getOwnPropertyDescriptor(v,k);if(!('value'in d))throw Error('CANONICAL_ACCESSOR '+propertyPath(path,k));walk(d.value,propertyPath(path,k));}
 }
 walk(root,'$');return rows;
}
export function firstDifference(expected,actual){
 const n=Math.max(expected.length,actual.length);
 for(let i=0;i<n;i++){
  const a=expected[i],b=actual[i];
  if(a&&b&&a.path===b.path&&a.type===b.type&&(Object.is(a.value,b.value)||(a.value&&b.value&&typeof a.value==='object'&&typeof b.value==='object'&&JSON.stringify(a.value)===JSON.stringify(b.value))))continue;
  return {ordinal:i,path:a?.path??b?.path,expected:a??null,actual:b??null};
 }return null;
}
export function serializeSnapshot(root,options){return JSON.stringify(canonicalSnapshot(root,options));}
