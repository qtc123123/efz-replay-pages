import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { loadDat } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { preloadReplays, replayPath } from "./8d7f594b1298130b3a745321.mjs";
import { blit, loadPalette, makeRect, present, readColorKey, setPalette } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { playBGM, playSE, stopBGM } from "./4bc01372141f4e276b2208f4.mjs";
import { checkEscapeKey, pollInput } from "./06124acd5a2cf7a08d774a8d.mjs";
import { FadeMode, Scene, fadeIn, fadeOut } from "./494d0271e10bf938cecabb23.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { State } from "./2215c2ad4aabedb03c1f6b16.mjs";
const BG_DAT = "system\\replay_bg.dat";
const OB_DAT = "system\\replay.dat";
const SLOTS = 9;
const EXIT_COL = 9;
var Phase = /*#__PURE__*/ function(Phase) {
    Phase[Phase["Grid"] = 0] = "Grid";
    Phase[Phase["SlideIn"] = 1] = "SlideIn";
    Phase[Phase["Menu"] = 2] = "Menu";
    Phase[Phase["SlideOut"] = 3] = "SlideOut";
    Phase[Phase["Confirm"] = 4] = "Confirm";
    return Phase;
}(Phase || {});
const s8 = (v)=>v << 24 >> 24;
const cosd = (deg)=>__numerics.cos(deg / 57.29579143313326);
export class ReplayScene extends Scene {
    surfBG = loadDat(BG_DAT, 0, 1);
    surfOB = loadDat(OB_DAT, 0, 0xc1);
    obKey;
    exit = 0;
    latch = [
        0,
        0
    ];
    phase = 0;
    row = 0;
    menu = 0;
    confirm = 0;
    col = 0;
    exists = new Uint8Array(SLOTS * SLOTS);
    ids = new Int8Array(SLOTS * SLOTS * 2);
    slide = 0.0;
    scroll = 0.0;
    constructor(){
        super();
        loadPalette(this.palette, BG_DAT, 0, 1, 0xc0);
        loadPalette(this.palette, OB_DAT, 0, 0xc1, 0x3e);
        this.obKey = readColorKey(this.surfOB);
        this.enterState = 1;
    }
    async enter() {
        this.latch[0] = this.latch[1] = 0;
        this.phase = 0;
        this.menu = 0;
        this.confirm = 0;
        this.slide = 0.0;
        this.scroll = 0.0;
        gs.round = 0;
        gs.continued = 0;
        gs.continueRound = 0;
        gs.usePal[0] = 0;
        gs.usePal[1] = 0;
        loadPalette(this.palette, OB_DAT, 0, 0xc1, 0x3e);
        const paths = [];
        for(let i = 0; i < SLOTS; i++){
            for(let j = 0; j < SLOTS; j++)paths.push(replayPath(i + 1, j + 1));
        }
        await preloadReplays(paths);
        const file = gs.replayFile;
        for(let i = 0; i < SLOTS; i++){
            for(let j = 0; j < SLOTS; j++){
                if (file.openRead(replayPath(i + 1, j + 1)) === 0) {
                    this.exists[i * SLOTS + j] = 0;
                } else {
                    this.ids[(i * SLOTS + j) * 2] = s8(file.readWord());
                    this.ids[(i * SLOTS + j) * 2 + 1] = s8(file.readWord());
                    this.exists[i * SLOTS + j] = 1;
                }
                file.close();
            }
        }
        if (this.enterState === 2) {
            this.render();
            await fadeIn(this, FadeMode.White);
        } else {
            loadPalette(this.palette, OB_DAT, 0, 0xc1, 0x3e);
            setPalette(this.palette);
            await fadeIn(this, FadeMode.White);
        }
        this.enterState = 0;
    }
    selectFile() {
        gs.replayRow = this.row;
        gs.replayCol = this.col;
    }
    async update() {
        if (this.enterState > 0) {
            playBGM(6);
            await this.enter();
        }
        if (this.exit > 0) {
            await fadeOut(this, FadeMode.White, 0, 0);
            const next = this.exit === 2 ? State.CharacterSelect : State.Title;
            this.enterState = this.exit === 2 ? 2 : 1;
            gs.stage = 0;
            this.exit = 0;
            stopBGM();
            return next;
        }
        if (checkEscapeKey()) this.exit = 1;
        pollInput();
        for(let p = 0; p < 2; p++){
            const inp = gs.input[p];
            switch(this.phase){
                case 0:
                    if (!this.latch[p] && inp.moveY !== 0) {
                        playSE(8);
                        this.row += inp.moveY;
                        if (this.row > 8) this.row = 0;
                        else if (this.row < 0) this.row = 8;
                    }
                    if (!this.latch[p] && inp.moveX !== 0) {
                        playSE(8);
                        this.col += inp.moveX;
                        if (this.col > 9) this.col = 0;
                        else if (this.col < 0) this.col = 9;
                    }
                    if (inp.a) {
                        if (this.col === EXIT_COL) {
                            this.exit = 1;
                        } else {
                            playSE(6);
                            this.phase = 1;
                        }
                    }
                    if (this.phase === 0 && (gs.input[0].b || gs.input[1].b)) this.exit = 1;
                    break;
                case 1:
                    this.slide += 2.0;
                    this.scroll += this.row * 16.0 / 90.0;
                    if (this.slide > 180.0) {
                        this.slide = 180.0;
                        this.phase = 2;
                    }
                    break;
                case 2:
                    {
                        if (!this.latch[p] && inp.moveY !== 0) {
                            playSE(8);
                            this.menu += inp.moveY;
                            if (this.menu >= 3) this.menu = 0;
                            else if (this.menu < 0) this.menu = 2;
                        }
                        if (inp.a) {
                            playSE(6);
                            const exists = this.exists[this.col * SLOTS + this.row] !== 0;
                            if (exists && this.menu === 0) {
                                this.selectFile();
                                gs.replayMode = 1;
                                await fadeOut(this, FadeMode.Black, 0, 0x32);
                                this.enterState = 2;
                                return State.Loading;
                            }
                            if (this.menu === 1) {
                                if (exists) {
                                    this.phase = 4;
                                } else {
                                    this.selectFile();
                                    gs.replayMode = 2;
                                    this.exit = 2;
                                }
                            } else {
                                this.phase = 3;
                            }
                        }
                        if (inp.b && !this.latch[p]) {
                            this.phase = 3;
                            this.latch[p] = 1;
                        }
                        break;
                    }
                case 3:
                    this.slide -= 2.0;
                    this.scroll -= this.row * 16.0 / 90.0;
                    if (this.slide < 0.0) {
                        this.slide = 0.0;
                        this.phase = 0;
                    }
                    break;
                case 4:
                    if (!this.latch[p] && inp.moveX !== 0) {
                        playSE(8);
                        this.confirm += inp.moveX;
                        if (this.confirm > 1) this.confirm = 0;
                        else if (this.confirm < 0) this.confirm = 1;
                    }
                    if (inp.a) {
                        playSE(6);
                        this.phase = 2;
                        if (this.confirm === 0) {
                            this.selectFile();
                            gs.replayMode = 2;
                            this.exit = 2;
                        }
                    }
                    if (inp.b) {
                        this.phase = 2;
                        this.latch[p] = 1;
                    }
                    break;
            }
            this.latch[p] = inp.moveX || inp.moveY || inp.b ? 1 : 0;
        }
        this.render();
        return State.Replay;
    }
    ob(dst, src) {
        blit(dst, this.surfOB, src, this.obKey, false);
    }
    drawNames(i, y, srcTop) {
        if (this.col >= EXIT_COL || this.exists[this.col * SLOTS + i] <= 0) return;
        for(let k = 0; k < 2; k++){
            const id = this.ids[(this.col * SLOTS + i) * 2 + k];
            const src = makeRect(Math.trunc(id / 10) * 0x50 + 0x40, id % 10 * 16 + srcTop, 0x50, 0x10);
            this.ob(makeRect(k === 0 ? 0x5a : 0xcd, y, 0x50, 0x10), src);
        }
    }
    render() {
        __session.render();
        blit(makeRect(0, 0, 320, 240), this.surfBG, makeRect(0, 0, 320, 240), 0, false);
        this.ob(makeRect(0, 4, 320, 16), makeRect(0, 0x19, 320, 16));
        const cx = this.col * 16 + 0x50;
        const cw = this.col === EXIT_COL ? 0x28 : 0x10;
        this.ob(makeRect(cx, 4, cw, 0xf), makeRect(cx, 6, cw, 0xf));
        if (this.phase !== 4) {
            const y = 0x13f - Math.trunc(160.0 - cosd(this.slide) * 160.0);
            this.ob(makeRect(0, y + 0x70, 320, 16), makeRect(0, this.menu === 0 ? 0x354 : 0x2cc, 320, 16));
            this.ob(makeRect(0, y + 0x80, 320, 16), makeRect(0, this.menu === 1 ? 0x364 : 0x2dc, 320, 16));
            this.ob(makeRect(0, y + 0x90, 320, 16), makeRect(0, this.menu === 2 ? 0x374 : 0x2ec, 320, 16));
        } else {
            this.ob(makeRect(0, 0x70, 320, 0x2c), makeRect(0, 0x300, 320, 0x2c));
            this.ob(makeRect(0, 0xa0, 320, 16), makeRect(0, this.confirm * 16 + 0x334, 320, 16));
        }
        for(let i = 0; i < SLOTS; i++){
            if (this.row === i) {
                const y = i * 16 + 0x60 - Math.trunc(this.scroll);
                this.ob(makeRect(0, y, 320, 16), makeRect(0, i * 16 + 0x5c, 320, 16));
                this.drawNames(i, y, 0x18c);
            } else {
                const y = i * 16 + Math.trunc(160.0 - cosd(this.slide) * 160.0) + 0x60;
                this.ob(makeRect(0, y, 320, 16), makeRect(0, i * 16 + 0xfc, 320, 16));
                this.drawNames(i, y, 0x22c);
            }
        }
        present();
    }
    static files = [
        BG_DAT,
        OB_DAT
    ];
}

export function __logicState(){return {Phase};}

export function __installInitialRoots(s){
Phase=s["Phase"];
}
