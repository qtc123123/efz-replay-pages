import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { spawnEffect } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { childHandlers, childHandlers2, registerChildren, registerChildren2, registerStates, registerStates2 } from "./81433295782a220b1d5e4d42.mjs";
import { childFrameCount, childFrameDuration, frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
export function newSpawnFrame() {
    return {
        d00: 0,
        w04: 0,
        x: 0,
        y: 0,
        b18: 0,
        d1c: 0,
        b20: 0,
        b21: 0,
        d24: 0,
        d28: 0,
        b2c: 0,
        d30: 0,
        clip: [
            0,
            0,
            0,
            0
        ]
    };
}
export function resetSpawnFrame(f) {
    f.d00 = 0;
    f.b20 = 0;
    f.b2c = 0xff;
    f.d24 = 0;
    f.d28 = 0;
    f.d30 = 0;
    f.clip = [
        0,
        0,
        0,
        0
    ];
}
export function openSpawnFrame() {
    const f = newSpawnFrame();
    resetSpawnFrame(f);
    return f;
}
export function frameEffect(f) {
    spawnEffect({
        owner: f.d00,
        pat: f.w04,
        x: f.x,
        y: f.y,
        b18: f.b18,
        mirror: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        sound: f.b2c
    });
}
export function frameChild(c, f) {
    return c.spawnChild({
        type: f.d00,
        pattern: f.w04,
        x: f.x,
        y: f.y,
        facing: f.b18,
        d4c: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        shadow: f.d28,
        b6c: f.b2c,
        moveWhileFrozen: f.d30,
        clip: [
            ...f.clip
        ]
    });
}
export const childSpawnFrame = newSpawnFrame();
export let childDuration = 0;
export let childCount = 0;
let walkAborted = false;
export function abortChildWalk() {
    walkAborted = true;
}
function walk(c, handlers) {
    if (c.opponent.freeze > 0) return;
    let i = c.childTail;
    Object.assign(childSpawnFrame, newSpawnFrame());
    walkAborted = false;
    while(i !== c.childHead){
        const ch = c.children[i];
        if (c.childActive[i] !== 0 && ch.hitstop === 0) {
            let run = true;
            if (c.freeze !== 0) {
                if (c.freeze <= 0 || ch.moveWhileFrozen === 0) run = false;
            }
            if (run) {
                childDuration = childFrameDuration(c, i);
                childCount = childFrameCount(c, i);
                resetSpawnFrame(childSpawnFrame);
                const k = ch.pattern - 400;
                if (k >= 0 && k <= 0x63) {
                    const handler = handlers.get(ch.pattern);
                    handler?.(c, i);
                    if (walkAborted) return;
                }
            }
        }
        i++;
        if (i >= 64) i = 0;
    }
}
export function updateChildrenIkumi(c) {
    if (c.form === 1) {
        walk(c, childHandlers2);
        return;
    }
    walk(c, childHandlers);
}
const w16 = (v)=>v & 0xffff;
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function rfCost(c) {
    if (c.rfBlue === 0) c.rfGauge = c.rfGauge - 500.0;
    else c.rfGauge = c.rfGauge - 250.0;
}
function effect21(c, f) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = ftol(c.x);
    f.y = ftol(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function effect0(c, f, dx, dy) {
    f.w04 = 0;
    f.x = ftol(c.x) + c.facing * dx;
    f.y = ftol(c.y) - dy;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function state248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 0xf9;
        o.state = 0x67;
        effect0(c, f, 0x27, 0x4b);
        o.x = c.facing * 0x27 + c.x;
        o.y = c.y - 75.0;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) {
            c.w16c = 1;
        } else {
            c.w16c = 0;
        }
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0xd1;
            c.frame = 1;
        }
    }
}
function throw249(c, damage) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame < 5) c.biasCamera(0x32, 3);
    if (c.frame < 5) c.biasCameraY(0x32, 3);
    c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 4) {
        c.stopMotion();
        c.onStateChange();
        c.y = 0.0;
        c.state = 0xd;
        return;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        c.d168 = 0;
        if (c.frame === 2) {
            o.y = c.y - 70.0;
            o.x = c.facing * 0x2a + c.x;
            o.state = 0x64;
            o.hitstop = 0x3c;
            f.w04 = 0xe;
            f.b2c = 4;
            f.x = ftol(c.x) + c.facing * 0x2a;
            f.y = ftol(c.y) - 0x48;
            f.b20 = 2;
            f.b21 = 1;
            frameEffect(f);
        }
        if (c.frame === 5 && c.f3138 < 5) {
            c.f3138 = c.f3138 + 1;
            c.frame = w16(c.frame - 2);
            return;
        }
        if (c.frame === 5) {
            c.shakeScreen(4, 0);
            o.y = c.y - 40.0;
            o.x = c.facing * 0x2a + c.x;
            o.state = 0x3f;
            applyDirectDamage(c, damage, 500.0);
            o.onStateChange();
            o.knockX = -2.0;
            o.knockY = 0.0;
            c.ay = 0.035;
            c.vy = -0.5;
            c.vx = -2.0;
            f.w04 = 0x199;
            f.x = ftol(c.x) + c.facing * 0x2a;
            f.y = ftol(c.y) - 0x46;
            f.b20 = 2;
            f.b18 = c.facing;
            f.b21 = 1;
            frameChild(c, f);
            c.voiceRequest = 5;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function state249(c) {
    throw249(c, 0x4b0);
}
function state249b(c) {
    throw249(c, 0x578);
}
function ground2(c, dist, childB) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        c.d168 = 0;
        if (c.frame === 5) {
            f.w04 = 0x192;
            f.x = ftol(c.x) + c.facing * dist;
            f.y = 0.0;
            f.b20 = 2;
            f.b21 = 1;
            f.d00 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
            f.w04 = childB;
            frameChild(c, f);
            c.shakeScreen(2, 0);
        }
        if (c.frame === 7 && c.f3138 > 0) {
            c.frame = w16(c.frame - 2);
            c.f3138 = c.f3138 - 1;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state250(c) {
    ground2(c, 0x3c, 0x193);
}
function state251(c) {
    ground2(c, 0x78, 0x193);
}
function state252(c) {
    ground2(c, 0xb4, 0x193);
}
function state279(c) {
    ground2(c, 0x3c, 0x19a);
}
function state280(c) {
    ground2(c, 0x78, 0x19a);
}
function state281(c) {
    ground2(c, 0xb4, 0x19a);
}
function state282(c) {
    ground2(c, 0x3c, 0x19c);
}
function state283(c) {
    ground2(c, 0x78, 0x19c);
}
function state284(c) {
    ground2(c, 0xb4, 0x19c);
}
function rush(c, hits, clearBelow, powered) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.vy = 0.0;
        c.vx = 2.5;
        c.w16c = hits;
        if (powered) {
            rfCost(c);
            effect21(c, f);
        }
    }
    if (c.frame === 4 && c.timer === 0) c.f3138 = 1;
    if (c.frame === 10 && c.timer === 0) {
        c.seRequest = 0x14;
        addMeter(c, 0x23);
        f.w04 = 0x191;
        f.x = ftol(c.x);
        f.y = c.y;
        f.b20 = 2;
        f.b21 = 1;
        f.d00 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        c.voiceRequest = 2;
    }
    if (c.frame > 11) {
        c.vx = c.vx - 0.045;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.x - o.x < 150.0 && c.facing === -1 || o.x - c.x < 150.0 && c.facing === 1) {
        if (c.f3138 !== 0 && c.frame < 8) {
            c.timer = 0;
            c.frame = 8;
            return;
        }
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame === 8 && c.f313c < 1) {
            c.frame = 0;
            c.f313c = c.f313c + 1;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state253(c) {
    rush(c, 1, 3, false);
}
function state254(c) {
    rush(c, 1, 3, false);
}
function state255(c) {
    rush(c, 1, 3, true);
}
function state266(c) {
    rush(c, 2, 14, false);
}
function state267(c) {
    rush(c, 1, 3, true);
}
function state269(c) {
    rush(c, 3, 14, false);
}
function state270(c) {
    rush(c, 1, 3, true);
}
function hop(c, vx, vy, land, powered, flash7) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 1;
        if (powered) {
            rfCost(c);
            effect21(c, f);
        }
    }
    if (c.frame === 3 && c.timer === 0) {
        c.vx = vx;
        c.vy = vy;
        c.ay = 0.025;
    }
    if (c.y < 0.0) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy >= 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.onStateChange();
            c.state = land;
            return;
        }
    }
    if (c.frame === 9 && c.timer === 0) {
        c.seRequest = 0x14;
        addMeter(c, 0x23);
        f.w04 = 0x190;
        f.x = ftol(c.x);
        f.y = c.y;
        f.b20 = 2;
        f.b21 = 1;
        f.d00 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        c.voiceRequest = 3;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (flash7) {
            if (c.frame === 7) c.d168 = 2;
            if (c.frame === 8) c.d168 = 0;
        } else if (c.frame < 3) {
            c.d168 = 0;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function state256(c) {
    hop(c, 1.1, -1.5, 0x103, false, true);
}
function state256b(c) {
    hop(c, 1.1, -1.5, 0x103, false, false);
}
function state257(c) {
    hop(c, 1.4, -1.5, 0x103, false, false);
}
function state258(c) {
    hop(c, 1.7, -1.2, 0x103, true, false);
}
function state272(c) {
    hop(c, 1.6, -1.3, 0x112, false, false);
}
function state273(c) {
    hop(c, 1.7, -1.1, 0x112, true, false);
}
function state276(c) {
    hop(c, 1.7, -1.1, 0x116, false, false);
}
function state277(c) {
    hop(c, 1.7, -1.0, 0x116, true, false);
}
function landing(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state263(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (c.frame === 2 && c.timer === 0 && o.y === 0.0) {
        c.w16c = 1;
    } else {
        c.w16c = 0;
    }
    if (c.frame === 2 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 0x108;
        o.state = 0x6b;
        effect0(c, f, 0x25, 0x2a);
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function hit264(c, damage2, proration2) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 3 && c.timer === 0) {
        o.hitstop = 0x5dc;
        effect0(c, f, 0x2b, 0x2e);
        applyDirectDamage(c, 0xfa, 1000.0);
        o.onStateChange();
        o.state = 0x6c;
        o.x = c.facing * 0x28 + c.x;
        c.voiceRequest = 4;
    }
    if (c.frame === 7 && c.timer === 0) {
        f.w04 = 0x1d6;
        f.x = ftol(c.x) + c.facing * 0x2b;
        f.y = ftol(c.y) - 0x2e;
        f.b20 = 0;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
    }
    if (c.frame === 12 && c.timer === 0x5a) {
        o.hitstop = 0;
        f.w04 = 0x199;
        f.x = ftol(c.x) + c.facing * 0x2b;
        f.y = ftol(c.y) - 0x2e;
        f.b20 = 2;
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
        applyDirectDamage(c, damage2, proration2);
        o.onStateChange();
        o.state = 0x3f;
        o.knockX = -0.8;
        o.knockY = -2.8;
        f.w04 = 0x1dd;
        f.x = ftol(c.x) + c.facing * 0x2b;
        f.y = ftol(c.y) - 0x2e;
        f.b20 = 0;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        f.w04 = 0x1dd;
        f.x = ftol(c.x) + c.facing * 0x2b;
        f.y = ftol(c.y) - 0x2e;
        f.b20 = 0;
        f.b21 = 1;
        f.b18 = -c.facing;
        frameChild(c, f);
        c.voiceRequest = 5;
        c.shakeScreen(4, 0);
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state264(c) {
    hit264(c, 0xfa, 600.0);
}
function state264b(c) {
    hit264(c, 0x1f4, 700.0);
}
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child400(c, i) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y;
    childAdvance(c, i);
}
function child401(c, i) {
    childAdvance(c, i);
}
function child402(c, i) {
    childAdvance(c, i);
}
function spawnerChild(c, i, next) {
    const ch = c.children[i];
    if (ch.frame === 0) ch.hitsLeft = 1;
    if (ch.frame === 0 && ch.timer === 0) {
        const f = childSpawnFrame;
        f.w04 = next;
        f.x = ftol(ch.x);
        f.y = ftol(ch.y);
        f.b18 = ch.facing;
        f.b21 = 1;
        f.b20 = 2;
        f.d00 = 1;
        frameChild(c, f);
        c.voiceRequest = 1;
    }
    childAdvance(c, i);
}
function child403(c, i) {
    spawnerChild(c, i, 0x196);
}
function spawn478(c) {
    const f = childSpawnFrame;
    const o = c.opponent;
    f.w04 = 0x1de;
    f.x = ftol(o.x);
    f.y = o.y - 40.0;
    f.b20 = 0;
    f.b21 = 1;
    f.b18 = c.facing;
    frameChild(c, f);
}
function hit1Child(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0) {
        ch.hitsLeft = 1;
        c.a3160[i] = 0;
    }
    if (ch.hitState === 3 && c.a3160[i] === 0) {
        c.a3160[i] = 1;
        spawn478(c);
    }
    if (s16(ch.hitsLeft) === 0 && ch.frame < 0x2f) {
        ch.timer = 0;
        ch.frame = 0x2f;
        return true;
    }
    return false;
}
function child406(c, i) {
    if (hit1Child(c, i)) return;
    childAdvance(c, i);
}
function child409(c, i) {
    childAdvance(c, i);
}
function child410(c, i) {
    spawnerChild(c, i, 0x19b);
}
function child411(c, i) {
    if (hit1Child(c, i)) return;
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame === 0x2f && c.a3160[i] === 0) {
            c.a3160[i] = c.a3160[i] + 1;
            ch.frame = 0x20;
        }
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child412(c, i) {
    spawnerChild(c, i, 0x19d);
}
function child413(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0) {
        ch.hitsLeft = 2;
        c.a3160[i] = 0;
        c.a3260[i] = 0;
    }
    if (s16(ch.hitsLeft) === 0 && ch.frame < 0x2f) {
        ch.timer = 0;
        ch.frame = 0x2f;
        return;
    }
    if (ch.hitState === 3 && c.a3260[i] === 0) {
        c.a3260[i] = 1;
        spawn478(c);
    }
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        if (ch.frame === 0x2f && c.a3160[i] < 3) {
            c.a3160[i] = c.a3160[i] + 1;
            ch.frame = 0x20;
            ch.hitState = 0;
            c.a3260[i] = 0;
        }
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function formCases(form) {
    return {
        248: state248,
        249: form === 0 ? state249 : state249b,
        250: state250,
        251: state251,
        252: state252,
        253: state253,
        254: state254,
        255: state255,
        256: form === 0 ? state256 : state256b,
        257: state257,
        258: state258,
        259: landing,
        263: state263,
        264: form === 0 ? state264 : state264b,
        266: state266,
        267: state267,
        269: state269,
        270: state270,
        272: state272,
        273: state273,
        274: landing,
        276: state276,
        277: state277,
        278: landing,
        279: state279,
        280: state280,
        281: state281,
        282: state282,
        283: state283,
        284: state284
    };
}
registerStates(formCases(0));
registerStates2(formCases(1));
const childCases = {
    400: child400,
    401: child401,
    402: child402,
    403: child403,
    406: child406,
    409: child409,
    410: child410,
    411: child411,
    412: child412,
    413: child413
};
registerChildren(childCases);
registerChildren2(childCases);

export function __logicState(){return {childSpawnFrame,childDuration,childCount,walkAborted,childCases};}

export function __installInitialRoots(s){
if(childSpawnFrame!==s["childSpawnFrame"])throw Error('INITIAL_CONST_IDENTITY:childSpawnFrame');
childDuration=s["childDuration"];
childCount=s["childCount"];
walkAborted=s["walkAborted"];
if(childCases!==s["childCases"])throw Error('INITIAL_CONST_IDENTITY:childCases');
}
