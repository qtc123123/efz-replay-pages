import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = rnd(c, 0, 2) - 1;
}
function dashCommand(c) {
    return c.facing === 1 ? 1 : 0;
}
function rfOver(c) {
    return c.rfGauge > 500.0;
}
function pickRushMode(c, dx, table, last) {
    for (const [n, mode] of table){
        if (rnd(c, 0, n) === 0) c.aiMode = mode;
    }
    if (dx < 45.0 && rnd(c, 0, last) === 0) c.aiMode = 10;
}
function oppReeling(c) {
    const s = c.opponent.state;
    return s > 49 && s < 156 ? 1 : 0;
}
function oppLow(c) {
    return c.opponent.state < 49 ? 1 : 0;
}
export function thinkMayu(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25.0 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 170 ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 149 && c.state < 157 ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40.0 * c.aiLevel > r && c.state > 199) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 200) c.aiMode = 0;
        return;
    }
    if (o.state === 96) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 50 && c.state <= 150 && c.timer === 0) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 50 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 240) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 320) < dx ? 1 : 0;
        if (o.state > 199 && o.state < 250 && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 10 && c.state <= 12) && c.y === 0.0) return;
    if (o.state >= 50 && o.state < 150 && c.state === 264 && c.w16c > 1) return;
    if (c.state === 168 && c.timer < 6) {
        if (o.state !== 200 && o.state !== 204 && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx < 40.0 && chance(c, 3.0)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && chance(c, 3.0)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
        }
        if ((o.state === 201 || o.state === 202 || o.state === 205) && o.state < 250 && o.y === 0.0 && o.w16c === 0 && dx > 60.0 && dx < 70.0 && chance(c, 3.0)) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return;
        }
    }
    if (c.state === 168 || c.state === 169) {
        if (dx < 80.0) {
            if (chance(c, 3.0) && rfOver(c)) {
                c.command = 22;
                return;
            }
            {
                const g = rfOver(c) ? 1 : 0;
                const r = rnd(c, 0, 100);
                if (c.aiLevel * 3.0 + g * 2 > r) {
                    c.command = 12;
                    return;
                }
            }
            if (chance(c, 4.0) && c.meter >= 1000 && o.y === 0.0) {
                c.command = rnd(c, 0, 3) + 100;
                return;
            }
            if (chance(c, 3.0) && c.meter === 3000 && o.y < -30.0) {
                c.command = 122;
                return;
            }
        }
        if (dx < 120.0 && chance(c, 3.0) && rfOver(c)) {
            c.command = 12;
            return;
        }
        if (dx > 120.0) {
            if (chance(c, 1.0) && rfOver(c)) {
                c.command = 12;
                return;
            }
            if (chance(c, 1.0)) {
                const r = rnd(c, 0, 0);
                c.command = r + r + 30;
                return;
            }
        }
    }
    if (c.state === 170 && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5.0)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -40.0 && dx < 60.0 && chance(c, 5.0)) {
            c.pressed[0] = 1;
            return;
        }
        if (c.y - o.y > -40.0 && c.y - o.y < 0.0 && dx < 70.0 && chance(c, 5.0)) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y > -60.0 && c.y - o.y < 30.0 && dy > 80.0 && dx < 80.0 && chance(c, 5.0)) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return;
        }
        if (dy < 50.0 && dx < 100.0 && chance(c, 1.0)) {
            c.command = 30;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y === 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 4 && rfOver(c)) {
            c.command = 22;
            return;
        }
        if (c.aiRoll < 10 && rfOver(c)) {
            c.command = 12;
            return;
        }
        if (c.aiRoll < 13 && dx > 100.0) {
            c.command = 30;
            return;
        }
        if (c.aiRoll < 13 && dx < 90.0) {
            c.command = 32;
            return;
        }
        if (c.aiRoll < 17 && c.aiRoll > 12 && c.meter >= 1000 && dx < 80.0) {
            c.command = rnd(c, 0, 2) * 100;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y < 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 20) {
            c.aiMode = 2;
            return;
        }
        if (dx < 100.0 && c.aiRoll < 22) {
            c.command = 30;
            return;
        }
    }
    if ((rfOver(c) || c.rfBlue > 0) && 8.0 * c.aiLevel > rnd(c, 0, 100) && o.state > 149 && o.state < 157 && (c.state === 259 || c.state === 260 || c.state === 266 || c.state === 267 || c.state === 301 || c.state === 302)) {
        c.command = 52;
        return;
    }
    if (c.aiMode > 0 && c.state > 49 && c.state < 158) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 200) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = rnd(c, 0, 2) - 1;
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = dashCommand(c);
            if (c.state === 165) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 50) {
        c.aiMode = 0;
        c.command = dashCommand(c);
        return;
    }
    if (c.aiMode === 6 && c.state < 50) {
        c.aiMode = 7;
        c.command = dashCommand(c);
        return;
    }
    if (c.aiMode === 7 && c.state === 163) {
        c.inputX = -c.facing;
        c.pressed[1] = 1;
        if (c.state === 231) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 8 && c.state < 50) {
        c.command = dashCommand(c);
        c.aiMode = 9;
        return;
    }
    if (c.aiMode === 9 && c.state === 163) {
        c.inputX = -c.facing;
        c.pressed[0] = 1;
        if (c.state === 230) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 10 && c.state < 50) {
        c.inputY = 0;
        c.pressed[0] = 1;
        if (c.state === 200) c.aiMode = 0;
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && c.aiLevel * 25.0 > rnd(c, 0, 100) && c.aiMode !== 0 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (comboMayu(c, dx, dy)) return;
    }
    if (25.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        const roll = c.aiRoll;
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 99) {
                if (dx < 40.0 && o.y === 0.0 && roll < 5) {
                    c.pressed[2] = 1;
                    c.inputX = -c.facing;
                    c.inputY = 0;
                    return;
                }
                if (dx < 35.0 && roll < oppReeling(c) * 30 + oppLow(c) * 20 + 25) {
                    c.pressed[0] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 50.0 && roll > 60 && roll < oppReeling(c) * 30 + oppLow(c) * 20 + 80) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 70.0 && roll > 130 && roll < oppReeling(c) * 30 + oppLow(c) * 20 + 145) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 100.0 && roll > 200 && roll < oppReeling(c) * 30 + oppLow(c) * 20 + 235) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 120.0 && dx > 100.0 && roll > 300 && roll < 310) {
                    c.pressed[2] = 1;
                    return;
                }
                if (dx > 80.0 && roll < 340 && roll > 320) {
                    c.command = 30;
                    return;
                }
                if (dx > 150.0 && roll < 370 && roll > 350) {
                    c.command = 32;
                    return;
                }
                if (roll < 400 && roll > 420 && dx > 150.0) {
                    c.command = c.facing & 0xffff;
                    c.aiMode = 5;
                    return;
                }
                if (roll < oppReeling(c) * 100 + oppLow(c) * 20 + 480 && roll > 450 && dx < 100.0) {
                    c.aiMode = 6;
                    return;
                }
                if (roll < oppReeling(c) * 100 + oppLow(c) * 20 + 630 && roll > 600 && dx < 100.0) {
                    c.aiMode = 6;
                    return;
                }
                if (dx < 220.0 && roll < 700 && roll > 710 && rfOver(c)) {
                    c.command = 12;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 120.0 && roll < 10) {
                        c.inputY = -1;
                        c.inputX = -c.facing;
                        return;
                    }
                    if (dy * 0.5 > dx && dy > 50.0 && dy < 180.0 && roll > 40 && roll < 70 && c.meter >= 1000) {
                        c.command = rnd(c, 0, 3) + 120;
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 140.0 && dy < 110.0 && dy > 80.0 && roll < 40) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dy * 0.5 > dx && dy > 50.0 && dy < 180.0 && roll > 40 && roll < 70 && c.meter >= 1000) {
                        c.command = rnd(c, 0, 3) + 120;
                        return;
                    }
                    if (dx < 80.0 && dy > 130.0 && dy < 160.0 && roll > 70 && roll < 80) {
                        c.command = rnd(c, 0, 3) + 20;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 70.0 && dy < 60.0 && c.y < o.y && roll < 200) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 50.0 && dy < 100.0 && roll < 400) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 80.0 && dy > 40.0 && dy < 60.0 && o.y > c.y && roll > 400 && roll < 620) {
                    c.pressed[2] = 1;
                    return;
                }
                if (roll > 650 && roll < 660) {
                    c.command = rnd(c, 0, 3) + 30;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 70.0 && dy < 60.0 && c.y < o.y && roll < 200) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 50.0 && dy < 100.0 && roll < 400) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 80.0 && dy > 40.0 && dy < 60.0 && o.y > c.y && roll > 400 && roll < 620) {
                    c.pressed[2] = 1;
                    return;
                }
                if (roll > 650 && roll < 700) {
                    c.command = rnd(c, 0, 3) + 30;
                    return;
                }
            }
        }
    }
    if (c.state < 50 && (o.state > 149 && o.state < 156 || o.state > 49 && o.state < 59) && c.y === 0.0 && 1.0 * c.aiLevel > rnd(c, 0, 100)) {
        if (dx < 100.0) c.command = dashCommand(c);
        return;
    }
    if (rnd(c, 0, 1000) < 2) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 240.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 80.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 140.0 && c.y === 0.0) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 15) c.aiTimer1a0 = 15;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 15) c.aiTimer1a4 = 15;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 40 && dx < 60.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 200) + 30;
        else c.aiTimer1a0 = rnd(c, 0, 200) + 30;
    }
    if (rnd(c, 0, 100) < 80) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 200) + 30;
        else c.aiTimer1a4 = rnd(c, 0, 200) + 30;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 200) + 30;
    else c.aiTimer1a4 = rnd(c, 0, 200) + 30;
}
function comboMayu(c, dx, dy) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (c.state === 200) {
        if (o.y < 0.0 && roll < 150) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 40.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 50.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 0;
            if (c.d168 === 2 && rnd(c, 0, 100) < 20) {
                c.pressed[2] = 1;
                c.inputY = 1;
            }
            return true;
        }
        if (dx < 100.0 && roll > 150 && roll < 600) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 600) {
            c.aiMode = 1;
            if (rnd(c, 0, 4) === 0) c.aiMode = 5;
            if (rnd(c, 0, 3) === 0) c.aiMode = 6;
            return true;
        }
    }
    if (c.state === 201) {
        if (o.y < 0.0 && roll < 400 && c.d168 === 3) {
            c.command = 20;
            return true;
        }
        if (o.y < 0.0 && roll > 400 && roll < 500 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 120;
            return true;
        }
        if (o.y < 0.0 && roll > 400 && roll < 700 && dx < 90.0) {
            c.inputY = -1;
            c.inputX = c.facing;
            return true;
        }
        if (roll < 150) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 150 && roll < 400) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 400 && roll < 550) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 550 && roll < 600) {
            c.command = rnd(c, 0, 3) + 30;
            return true;
        }
        if (roll > 600 && roll < 620 && dx > 80.0) {
            c.command = rnd(c, 0, 3) + 70;
            return true;
        }
        if (roll > 920) {
            startJump(c);
            return true;
        }
        if (roll > 499) {
            c.aiMode = 1;
            pickRushMode(c, dx, [
                [
                    2,
                    5
                ],
                [
                    2,
                    6
                ],
                [
                    3,
                    8
                ]
            ], 2);
            return true;
        }
    }
    if (c.state === 202) {
        if (o.y < 0.0 && o.y < -50.0 && dx < 70.0 && roll < 200 && c.d168 === 3 && c.meter === 3000) {
            c.command = 122;
            return true;
        }
        if (o.y < 0.0 && roll > 199 && roll < 400) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 400 && roll < 500) {
            c.command = 11;
            return true;
        }
        if (o.y < 0.0 && roll > 399 && roll < 500 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 100;
            return true;
        }
        if (roll > 0 && roll < 400 && dx < 90.0) {
            c.pressed[2] = 1;
            c.inputY = 0;
            if (rnd(c, 0, 10) < 7) c.inputY = 1;
            return true;
        }
        if (roll > 480 && roll < 550 && c.d168 === 3 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 170;
            return true;
        }
        if (roll > 550 && roll < 600) {
            c.command = rnd(c, 0, 3) + 30;
            return true;
        }
        if (roll > 600 && roll < 620 && dx > 80.0) {
            c.command = rnd(c, 0, 3) + 70;
            return true;
        }
        if (roll > 620) {
            c.aiMode = 1;
            pickRushMode(c, dx, [
                [
                    2,
                    5
                ],
                [
                    2,
                    6
                ],
                [
                    3,
                    8
                ]
            ], 2);
            return true;
        }
    }
    if (c.state === 203) {
        if (o.y < 0.0 && roll < 200 && c.d168 === 3 && dy < 70.0 && rfOver(c)) {
            c.command = 12;
            return true;
        }
        if (roll > 0 && roll < 100 && c.d168 !== 3 && rfOver(c)) {
            c.command = 10;
            if (rnd(c, 0, 2) === 0) c.command = 11;
            return true;
        }
        if (roll > 250 && roll < 550) {
            c.command = rnd(c, 0, 3) + 30;
            return true;
        }
        if (roll > 550 && roll < 600 && c.d168 === 3 && c.meter >= 1000 && dx < 90.0) {
            c.command = rnd(c, 0, 3) + 170;
            return true;
        }
        if (roll > 600 && roll < 680 && dx > 80.0) {
            c.command = rnd(c, 0, 3) + 70;
            return true;
        }
        if (roll > 799) {
            c.aiMode = 1;
            return true;
        }
    }
    if (c.state === 204) {
        if (o.y < 0.0 && roll < 150) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 40.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 50.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 0;
            if (c.d168 === 2 && rnd(c, 0, 100) < 20) {
                c.pressed[2] = 1;
                c.inputY = 1;
            }
            return true;
        }
        if (dx < 100.0 && roll > 150 && roll < 600) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 500) {
            c.aiMode = 1;
            pickRushMode(c, dx, [
                [
                    4,
                    5
                ],
                [
                    3,
                    6
                ],
                [
                    2,
                    8
                ]
            ], 3);
            return true;
        }
    }
    if (c.state === 205) {
        if (o.y < 0.0 && roll < 400 && c.d168 === 3) {
            c.command = 20;
            return true;
        }
        if (o.y < 0.0 && roll > 400 && roll < 700 && dx < 90.0) {
            c.inputY = -1;
            c.inputX = c.facing;
            return true;
        }
        if (roll < 200) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 200 && roll < 350) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 350 && roll < 550) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 550 && roll < 600) {
            c.command = rnd(c, 0, 3) + 30;
            return true;
        }
        if (roll > 600 && roll < 620 && dx > 80.0) {
            c.command = rnd(c, 0, 3) + 70;
            return true;
        }
        if (roll > 920) {
            startJump(c);
            return true;
        }
        if (roll > 650) {
            c.aiMode = 1;
            pickRushMode(c, dx, [
                [
                    4,
                    5
                ],
                [
                    2,
                    6
                ],
                [
                    2,
                    8
                ]
            ], 4);
            return true;
        }
    }
    if (c.state === 206) {
        if (roll < 200 && c.d168 === 3 && rfOver(c)) {
            c.command = 12;
            return true;
        }
        if (roll > 0 && roll < 100 && c.d168 !== 3 && rfOver(c)) {
            c.command = 10;
            if (rnd(c, 0, 2) === 0) c.command = 11;
            return true;
        }
        if (roll > 250 && roll < 550) {
            c.command = rnd(c, 0, 3) + 30;
            return true;
        }
        if (roll > 550 && roll < 600 && c.d168 === 3 && c.meter >= 1000 && dx < 70.0) {
            c.command = rnd(c, 0, 3) + 120;
            return true;
        }
        if (roll > 600 && roll < 680 && dx > 80.0) {
            c.command = rnd(c, 0, 3) + 70;
            return true;
        }
        if (roll > 799) {
            c.aiMode = 1;
            return true;
        }
    }
    if (c.state === 207) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            return true;
        }
        if (dx < 60.0 && roll < 400) {
            c.pressed[0] = 1;
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 4) === 0) c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 208) {
        if (roll > 20 && roll < (c.d168 !== 3 ? 1 : 0) * 50 + 50 && o.y < 0.0) {
            c.command = 30;
            if (rnd(c, 0, 2) === 0) c.command = 32;
            return true;
        }
        if (roll > 60 && roll < 300) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 950) {
            c.inputX = rnd(c, 0, 2) - 1;
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 209) {
        if (roll > 20 && roll < (c.d168 !== 3 ? 1 : 0) * 50 + 50 && o.y < 0.0) {
            c.command = 30;
            if (rnd(c, 0, 2) === 0) c.command = 32;
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    return false;
}
