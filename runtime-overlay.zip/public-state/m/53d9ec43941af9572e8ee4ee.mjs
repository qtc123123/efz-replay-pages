import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./1ced9d0c06b49387c5b9e1d5.mjs";
import { registerChildren, registerStates } from "./5ebc1d602888d5d1fbd12f34.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function enterState(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function rfCostEffect(c, f) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = ftol(c.x);
    f.y = ftol(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function zeroVelocity(c) {
    c.vx = 0.0;
    c.vy = 0.0;
    c.ax = 0.0;
}
function shotChild(c, f, pattern) {
    f.w04 = pattern;
    f.x = ftol(c.x) + c.facing * 0xe;
    f.y = ftol(c.y) - 0x29;
    f.b20 = 0;
    f.d28 = 1;
    f.b21 = 0;
    f.b18 = c.facing;
    frameChild(c, f);
    c.voiceRequest = 0;
    c.meter = s16(c.meter + 0x2d);
}
function shotAdvance(c, dur, cnt) {
    c.timer++;
    if (c.timer < dur - (c.frame === 4 ? 1 : 0) * c.f3148 * 3) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function shotState(c, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 3 && c.timer === 0) shotChild(c, f, pattern);
    shotAdvance(c, dur, cnt);
}
function state250(c) {
    shotState(c, 0x191);
}
function state251(c) {
    shotState(c, 0x192);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) rfCostEffect(c, f);
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 3 && c.timer === 0) shotChild(c, f, 0x193);
    shotAdvance(c, dur, cnt);
}
function state279(c) {
    shotState(c, 0x191);
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        zeroVelocity(c);
        c.w16c = 2;
    }
    if (c.y < 0.0) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - 0.035;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 4) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 0x2d);
        c.vx = 1.2;
        c.vy = -2.5;
        c.ay = 0.03;
    }
    if (c.frame >= cnt) {
        c.state = 0x100;
        if (c.inputY === 1) c.state = 0x102;
        c.onStateChange();
    }
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        zeroVelocity(c);
        c.w16c = 1;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 4) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 0x2d);
        c.vx = 1.7;
        c.vy = -1.7;
        f.w04 = 0x194;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 0;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
    }
    if (c.frame >= cnt) {
        c.state = 0x102;
        c.onStateChange();
    }
}
function state256(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 2.4;
        c.w16c = 1;
        c.vy = 0.0;
    }
    if (c.wallBlock() !== 0 && c.f313c === 0) {
        c.vx = -0.7;
        c.vy = -2.0;
        c.ay = 0.035;
        c.state = 0x101;
        c.seRequest = 0x1f;
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.f313c = c.f313c + 1;
        return;
    }
    if (c.w16c === 0) {
        c.vx = -0.7;
        c.vy = -2.0;
        c.ay = 0.035;
        c.state = 0x101;
        return;
    }
    c.timer++;
    if (c.y === 0.0 && !(c.vy < 0.0)) c.vy = 0.0;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) c.frame = c.frame - 4;
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    clearBufferedInput(c);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame >= cnt) {
        c.onStateChange();
        c.state = 9;
    }
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.04;
    c.vy = c.vy + c.ay;
    if (c.frame === 0 && c.timer === 0) c.vx = c.vx * 0.5;
    if (c.frame === 3 && c.timer === 0) c.w16c = 1;
    if (!(c.y + c.vy < 0.0)) {
        c.y = 0.0;
        c.state = 0x61;
        c.stopMotion();
        c.onStateChange();
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) c.frame = c.frame - 2;
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.stopMotion();
    if (c.frame === 0 && c.timer === 0) c.voiceRequest = 4;
    if (c.frame === 0xa && c.timer === 0) c.f3148 = c.f3148 + 1;
    if (c.frame === 0xa && c.timer === 0) c.voiceRequest = 5;
    if (c.f3148 > 9) c.f3148 = 9;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame >= cnt) {
        c.onStateChange();
        c.state = 7;
    }
}
function state271(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.stopMotion();
    if (c.frame === 5 && c.timer === 0) c.voiceRequest = 5;
    if (c.frame === 5 && c.timer === 0) c.f3148 = c.f3148 + 1;
    if (c.f3148 > 9) c.f3148 = 9;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame >= cnt) {
        c.onStateChange();
        c.state = 7;
    }
}
function endState7(c) {
    c.state = 7;
    c.stopMotion();
    c.onStateChange();
}
function state260(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        zeroVelocity(c);
        c.ay = 0.035;
        c.w16c = 1;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.frame > 8 && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 0xc;
    }
    if (c.frame > 4 && c.frame < 9) c.vx = c.vx - 0.025;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.f313c = c.f313c + 1;
    c.d168 = 0;
    if (c.frame === 4) {
        c.meter = s16(c.meter + 0x2d);
        c.vx = 1.8;
        c.vy = -1.9;
        if (c.f3148 > 2) {
            c.vx = 2.1;
            c.vy = -2.0;
        }
        if (c.f3148 > 5) {
            c.vx = 2.4;
            c.vy = -2.1;
        }
        if (c.f3148 > 8) {
            c.vx = 3.0;
            c.vy = -2.2;
        }
    }
    if (c.frame === 5) {
        if (c.f3148 > 2) c.frame = 6;
        if (c.f3148 > 5) c.frame = 7;
        if (c.f3148 > 8) c.frame = 8;
        return;
    }
    if (c.frame > 5 && c.frame < 9) c.frame = 9;
    if (c.frame === 9) {
        c.ay = 0.035;
        c.vx = c.vx * 0.3;
    }
    if (c.frame >= cnt) endState7(c);
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        zeroVelocity(c);
        c.w16c = 3;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.frame > 5 && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 0x10;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.f313c = c.f313c + 1;
    if (c.frame === 5 || c.frame === 9 || c.frame === 0xd) c.d168 = 0;
    if (c.frame === 4) {
        c.meter = s16(c.meter + 0x2d);
        c.vx = 1.2;
        c.vy = -1.2;
        c.ay = 0.03;
        if (c.f3148 > 6) c.vy = -2.2;
    }
    if (c.frame === 8 && c.f3148 < 5 || c.frame === 0xb && c.f3148 < 7) c.frame = 0xf;
    if (c.frame === 0xf) {
        if (c.vy < 0.0) c.vy = c.vy * 0.5;
        c.vx = c.vx * 0.5;
    }
    if (c.frame >= cnt) endState7(c);
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        rfCostEffect(c, f);
        zeroVelocity(c);
        c.w16c = s16(c.f3148 + 1);
    }
    if (c.frame === 0 && c.timer === 0) {
        zeroVelocity(c);
        c.w16c = 0x63;
    }
    c.vy = c.vy + c.ay;
    if (c.frame > 0xb && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 0x10;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.f313c = c.f313c + 1;
    if (c.frame === 5 || c.frame === 9 || c.frame === 0xd) c.d168 = 0;
    if (c.frame === 4) {
        c.meter = s16(c.meter + 0x2d);
        c.vx = 0.8;
        c.vy = -1.5;
        c.ay = 0.035;
        c.w13c = s16(c.f3148 * 0xc + 0x1e);
    }
    if (c.frame === 7 || c.frame === 0xb) c.vy = -1.4;
    if (c.frame === 0xc) c.frame = 4;
    if ((c.frame === 0xb || c.frame === 8) && c.f3138 > c.f3148) c.frame = 0xc;
    if (c.frame === 0xb || c.frame === 8) c.f3138 = c.f3138 + 1;
    if (c.frame === 0xf && c.vy < 0.0) c.vy = c.vy * 0.5;
    if (c.frame >= cnt) endState7(c);
}
function state263(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        zeroVelocity(c);
        c.w16c = s16(c.f3148 + 6);
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.frame > 0xf) {
        c.vx = c.vx - 0.028;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if ((c.frame === 6 || c.frame === 0xb) && c.timer === 0) c.seRequest = 0x14;
    if (c.y + c.vx > 0.0 && c.frame > 5 && c.frame < 0x10) {
        c.timer = 0;
        c.y = 0.0;
        c.vy = 0.0;
        c.frame = 0x10;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.f313c = c.f313c + 1;
    if (c.f313c > 2) {
        c.d168 = 0;
        c.f313c = 0;
    }
    if (c.frame === 5) {
        c.meter = s16(c.meter + 0x2d);
        c.vx = 1.8;
        c.vy = -1.7;
        c.ay = 0.035;
        if (c.f3138 === 1) {
            c.vx = 0.6;
            c.vy = -3.2;
            c.ay = 0.024;
        }
    }
    if (c.frame === 0x10) c.frame = 5;
    if (c.frame >= cnt) endState7(c);
}
function rushEarlyExit(c) {
    c.timer++;
    if (c.timer >= 0x18 && c.f3148 > 3 && c.frame === 0xb) {
        c.frame++;
        c.timer = 0;
        c.d168 = 0;
    }
}
function rushShouldAdvance(c, dur) {
    if (c.timer >= dur) return true;
    if (c.timer >= dur - c.f3148 * 3 && c.frame === 0xb) return true;
    if (c.timer >= dur - 3 && c.frame === 1 && c.f3148 > 2) return true;
    if (c.timer >= dur - 3 && c.frame === 2 && c.f3148 > 4) return true;
    return false;
}
function rushAdvance(c, cnt, dashVx, strongVx) {
    c.timer = 0;
    c.frame++;
    if (c.frame < 0xb) c.d168 = 0;
    if (c.frame === 4) {
        c.meter = s16(c.meter + 0x2d);
        c.vx = dashVx;
        if (strongVx !== null && c.f3138 === 1) c.vx = strongVx;
    }
    if (c.frame === 7 && c.f313c < 2) {
        c.frame = 4;
        c.f313c = c.f313c + 1;
    }
    if (c.frame === 7 && c.f3138 === 1 && c.f313c < 4) {
        c.frame = 4;
        c.f313c = c.f313c + 1;
    }
    if (c.frame >= cnt) endState7(c);
}
function rushSe(c) {
    if ((c.frame === 4 || c.frame === 6) && c.timer === 0) c.seRequest = 0x15;
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        zeroVelocity(c);
        c.w16c = 2;
    }
    if (c.frame > 9) {
        c.vx = c.vx - 0.08;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    rushSe(c);
    rushEarlyExit(c);
    if (rushShouldAdvance(c, dur)) rushAdvance(c, cnt, 2.2, 3.4);
}
function state265(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        zeroVelocity(c);
        c.w16c = 2;
    }
    if (c.frame > 9) {
        c.vx = c.vx + 0.08;
        if (c.vx > 0.0) c.vx = 0.0;
    }
    rushSe(c);
    rushEarlyExit(c);
    if (rushShouldAdvance(c, dur)) rushAdvance(c, cnt, -2.2, null);
}
function state266(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        rfCostEffect(c, f);
        zeroVelocity(c);
        c.w16c = s16(c.f3148 + 1);
    }
    if (c.frame > 9) {
        c.vx = c.vx - 0.3;
        c.w16c = 1;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    rushSe(c);
    c.timer++;
    if (rushShouldAdvance(c, dur)) rushAdvance(c, cnt, 2.5, null);
}
function state267(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        rfCostEffect(c, f);
        zeroVelocity(c);
        c.w16c = 0x63;
    }
    if (c.frame > 9) {
        c.vx = c.vx - 0.3;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    rushSe(c);
    c.timer++;
    if (c.timer >= dur) rushAdvance(c, cnt, 2.8, null);
}
function stanceButtons(c, dPress) {
    if (c.pressed[0] === 1) {
        enterState(c, 0x113);
        if (c.f3148 > 4) c.state = 0x10d;
        return true;
    }
    if (c.pressed[1] === 1) {
        enterState(c, 0x112);
        return true;
    }
    if (c.pressed[2] === 1) {
        enterState(c, 0x114);
        if (c.inputY === 1) c.state = 0x119;
        return true;
    }
    if (dPress && c.pressed[3] === 1) {
        stanceD(c);
        return true;
    }
    return false;
}
function stanceD(c) {
    enterState(c, 0x10f);
    if (c.inputY === 1) c.state = 0x118;
    if (c.f3148 === 9) {
        c.state = 0x10c;
        c.frame = 8;
    }
}
function state268(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 7) {
        if (c.command === 1) {
            enterState(c, 0xa3);
            if (c.facing === -1) c.state = 0xa4;
            return;
        }
        if (c.command === 0) {
            enterState(c, 0xa4);
            if (c.facing === -1) c.state = 0xa3;
            return;
        }
        if (c.command === 0xa && c.f3148 > 0) {
            enterState(c, 0xfa);
            return;
        }
        if (c.command === 0xb && c.f3148 > 0) {
            enterState(c, 0xfb);
            return;
        }
        if (c.command === 0x14 && c.f3148 > 0) {
            enterState(c, 0x104);
            return;
        }
        if (stanceButtons(c, false)) return;
        if (c.pressed[3] === 1) {
            if (c.inputX === c.facing) {
                enterState(c, 0x115);
                if (c.f3148 > 4) c.state = 0x115;
                return;
            }
            if (c.inputX === -c.facing) {
                enterState(c, 0x116);
                if (c.f3148 > 4) c.state = 0x116;
                return;
            }
            stanceD(c);
            return;
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.f313c = c.f313c + 1;
    if (c.frame >= cnt) {
        c.state = 0;
        c.stopMotion();
        c.onStateChange();
    }
}
function stanceStep(c, startVx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = startVx;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.frame > 3) {
        c.vx = c.vx - 0.08;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if ((c.frame === 1 || c.frame === 3) && c.timer === 0) c.seRequest = 0x15;
    if (c.frame < 4) {
        if (stanceButtons(c, true)) return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame === 4 && c.f313c < 3) {
        c.frame = c.frame - 4;
        c.f313c = c.f313c + 1;
    }
    if (c.frame >= cnt) {
        c.state = 0x10c;
        c.stopMotion();
        c.onStateChange();
        c.frame = 8;
    }
}
function state272(c) {
    stanceStep(c, 1.4);
}
function state273(c) {
    stanceStep(c, -1.4);
}
function state277(c) {
    stanceStep(c, 1.4);
}
function state278(c) {
    stanceStep(c, -1.4);
}
function stompState(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.y + c.vx > 0.0 && c.frame > 2 && c.frame < 8) {
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
        c.frame = 8;
        c.shakeScreen(3, 0);
        f.w04 = 3;
        f.x = ftol(c.x) + c.facing * 0x1e;
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b21 = 0;
        frameEffect(f);
        c.seRequest = 7;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 3) {
        c.meter = s16(c.meter + 0x2d);
        c.vx = 1.4;
        c.vy = -2.1;
        c.ay = 0.045;
    }
    if (c.frame === 8) c.frame = c.frame - 1;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.stopMotion();
        c.onStateChange();
    }
}
function state269(c) {
    stompState(c);
}
function state275(c) {
    stompState(c);
}
function warpHead(c) {
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 0;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.meter = s16(c.meter + 0x23);
        c.seRequest = 0x14;
    }
    if (c.frame > 8) c.vy = c.vy + c.ay;
    if (c.frame > 8 && c.vy + c.y > 0.0) {
        c.onStateChange();
        c.state = 0xd;
        return true;
    }
    return false;
}
function warpAdvance(c, cnt, jumpVy) {
    c.timer = 0;
    c.frame++;
    if (c.frame === 5) {
        c.voiceRequest = 3;
        c.w16c = 1;
    }
    if (c.frame < 3) c.d168 = 0;
    if (c.frame === 3 || c.frame === 4 || c.frame === 5) c.x = c.facing * 0x28 + c.x;
    if (c.frame === 9) {
        c.vy = jumpVy;
        c.vx = 0.7;
        c.ay = 0.033;
    }
    if (c.frame >= cnt) c.frame = c.frame - 1;
}
function state270(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (warpHead(c)) return;
    c.timer++;
    if (c.timer >= dur) warpAdvance(c, cnt, -1.0);
}
function state276(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (warpHead(c)) return;
    c.timer++;
    if (c.timer >= dur || c.frame === 1 && c.timer === 0x27 - c.f3148 * 3) warpAdvance(c, cnt, -0.7);
}
function state274(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    c.timer++;
    if (c.timer < dur - (c.frame === 9 ? 1 : 0) * c.f3148 * 3) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 7 && c.timer === 0) {
        f.w04 = 0x1ac;
        if (c.inputX === c.facing) f.w04 = 0x1ad;
        if (c.inputX === -c.facing) f.w04 = 0x1ab;
        f.x = ftol(c.x) + c.facing * 0x1e;
        f.y = ftol(c.y) - 0x32;
        f.b20 = 0;
        f.d28 = 1;
        f.b21 = 0;
        f.b18 = c.facing;
        frameChild(c, f);
        c.voiceRequest = 0;
        c.meter = s16(c.meter + 0x2d);
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state280(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.stopMotion();
    if (c.frame === 0 && c.timer === 0) c.voiceRequest = 4;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame >= cnt) {
        c.onStateChange();
        c.state = 0;
    }
}
function state281(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - 0.03;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.meter = s16(c.meter + 0x19);
        c.seRequest = 0x14;
        c.w16c = 1;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame < 2) c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        if (c.inputY === 1) c.state = 3;
        c.faceOpponent();
        c.onStateChange();
    }
}
registerStates({
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    265: state265,
    266: state266,
    267: state267,
    268: state268,
    269: state269,
    270: state270,
    271: state271,
    272: state272,
    273: state273,
    274: state274,
    275: state275,
    276: state276,
    277: state277,
    278: state278,
    279: state279,
    280: state280,
    281: state281
});
function orbChild(c, i, p) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = p.hits;
        ch.vx = 0.3;
        ch.vy = -1.2;
        c.voiceRequest = 0;
    }
    if (ch.frame === 0) {
        ch.vy = ch.vy + 0.045;
        if (ch.vy + ch.y > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.frame = 1;
            ch.layer = 1;
        }
    }
    if (p.shadowOff && ch.frame > 4 && ch.vy + ch.y > 0.0) ch.shadow = 0;
    if ((!p.needBlend0 || ch.blend === 0) && c.frame === 6 && c.state === p.state && ch.frame < 5) {
        const d = c.x - ch.x;
        if (d < 60.0 && d > 0.0 && c.facing === -1 || d > -60.0 && d < 0.0 && c.facing === 1) {
            ch.timer = 0;
            ch.frame = 5;
            const f = childSpawnFrame;
            f.w04 = 0;
            f.x = ftol(c.x) + c.facing * 0x1e;
            f.y = ftol(c.y) - 0x14;
            f.b20 = 2;
            f.b21 = 1;
            f.b2c = 2;
            frameEffect(f);
            ch.vx = p.kickVx;
            ch.vy = p.kickVy;
            ch.ay = 0.025;
        }
    }
    if (ch.frame > 4) ch.vy = ch.vy + ch.ay;
    if ((!p.needNoHits || ch.hitsLeft === 0) && ch.hitState > 1) {
        ch.timer = 0;
        ch.hitState = 0;
        ch.frame = 6;
        ch.vy = -1.5;
        ch.vx = -ch.vx * 0.5;
        ch.ay = 0.035;
    }
    if (ch.frame === 7) ch.blend = 1;
    if (ch.y > 60.0) c.freeChild(i);
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame === 2) ch.blend = 1;
    if (ch.frame === 3) c.freeChild(i);
    if (p.hold6 && ch.frame === 6) ch.frame = ch.frame - 1;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child401(c, i) {
    orbChild(c, i, {
        hits: 1,
        shadowOff: true,
        needBlend0: true,
        state: 0xfa,
        kickVx: 1.8,
        kickVy: -0.9,
        needNoHits: false,
        hold6: false
    });
}
function child402(c, i) {
    orbChild(c, i, {
        hits: 1,
        shadowOff: false,
        needBlend0: false,
        state: 0xfb,
        kickVx: 2.0,
        kickVy: -3.5,
        needNoHits: false,
        hold6: false
    });
}
function child403(c, i) {
    orbChild(c, i, {
        hits: 5,
        shadowOff: true,
        needBlend0: false,
        state: 0xfc,
        kickVx: 2.2,
        kickVy: -1.6,
        needNoHits: true,
        hold6: true
    });
}
function child404(c, i) {
    const ch = c.children[i];
    if (c.state === 0xfe) {
        ch.x = c.x;
        ch.y = c.y;
    } else {
        ch.vx = 1.7;
        ch.vy = -1.7;
    }
    if (gs.viewTop - 0x28 > ch.y) c.freeChild(i);
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = ch.frame - 1;
}
registerChildren({
    401: child401,
    402: child402,
    403: child403,
    404: child404
});
