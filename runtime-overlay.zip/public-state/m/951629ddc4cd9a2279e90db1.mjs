import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./2997ced5c6273385064924f8.mjs";
import { childCount, childDuration, frameChild, frameEffect, openSpawnFrame } from "./d2cd6c2c9053eff29ff0ef4e.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
var Jc = /*#__PURE__*/ function(Jc) {
    Jc[Jc["None"] = 0] = "None";
    Jc[Jc["Ge2"] = 1] = "Ge2";
    Jc[Jc["Eq3"] = 2] = "Eq3";
    return Jc;
}(Jc || {});
function groundJumpCancel(c, kind) {
    if (kind === 0) return false;
    if (c.inputY !== -1 || c.frame <= 0) return false;
    if (c.d15c >= 3) return false;
    if (kind === 2 ? c.d168 !== 3 : c.d168 < 2) return false;
    jumpTo456(c);
    return true;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a === 0) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function attackStart(c, meter, se, hits) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = hits;
}
function stopIfNotDashing(c) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
}
function dashSlide(c, k) {
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - k;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function airDashEnd(c, vx) {
    c.setState(9);
    c.vx = vx;
    c.ay = 0.03;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function burstFx(c, d) {
    d.w04 = 9;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 70;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    c.w16c = 1;
    c.seRequest = 62;
}
function airLand(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function guardChild(c, d, dy) {
    if (c.f3148 !== 0) return;
    d.w04 = 400;
    d.x = ftol(c.x) + c.facing * 0x1c;
    d.y = ftol(c.y) - dy;
    d.b20 = 0;
    d.b21 = 1;
    d.d00 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
    c.f3148 = 1;
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(99);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.life > 0 && c.timer > 99) c.setState(96);
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(96);
    }
}
function guardGround(c, crouch, stand, meter, vx0, dy, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
        guardChild(c, d, dy);
    }
    if (c.f3138 === 1 && (c.pressed[0] === 1 || c.pressed[1] === 1 || c.pressed[2] === 1) && c.d15c < 2) {
        c.onStateChange();
        c.stopMotion();
        c.state = 258;
        return;
    }
    c.vy = 0.0;
    c.vx = c.vx + 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, 56, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, 56, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, 56, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, 37, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, 37, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, 37, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
        guardChild(c, d, 67);
    }
    c.vx = -1.2;
    c.vy = c.vy + c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy = c.vy + c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        burstFx(c, d);
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 8)) {
        c.stopMotion();
        burstFx(c, d);
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 19) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 3) {
            d.w04 = 31;
            d.x = ftol(c.x);
            d.y = ftol(c.y);
            d.b20 = 0;
            d.b21 = 0;
            d.d1c = c.facing === -1 ? 1 : 0;
            frameEffect(d);
            c.vx = 1.5;
            c.vy = -1.5;
            c.seRequest = 17;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 120) {
        c.setState(9);
        c.vx = 0.5;
        c.vy = -0.7;
        c.ay = 0.03;
    }
    if (c.inputX !== c.facing && c.f3138 >= 39) {
        c.setState(9);
        c.vx = 0.5;
        c.vy = -0.7;
        c.ay = 0.03;
    }
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(2);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.frame > 2) c.vy = c.vy + c.ay;
    if (c.frame > 2 && c.vy + c.y >= 0.0 && c.f3138 === 0) {
        c.stopMotion();
        c.y = 0.0;
        c.f3138++;
        c.seRequest = 9;
        c.frame = 5;
        c.timer = 0;
        c.f3138++;
    }
    if (advance(c, dur)) {
        if (c.frame === 3) {
            c.vx = -1.8;
            c.vy = -0.8;
            c.ay = 0.035;
        }
        if (c.frame === 5) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.faceOpponent();
            c.setState(3);
        }
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = 2.0;
        c.startAfterimage(3);
        c.vy = 0.0;
        c.ay = 0.0;
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f3138 >= 120) airDashEnd(c, 1.3);
    if (c.inputX !== c.facing && c.f3138 >= 48) airDashEnd(c, 1.3);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -2.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9);
    if (c.inputX !== -c.facing && c.f3138 >= 48) airDashEnd(c, -0.9);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, dy, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
        guardChild(c, d, dy);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 56, 0);
const s169 = (c)=>recoilGuard(c, 37, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    guardChild(c, d, 67);
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.faceOpponent();
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 5) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 5;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 3) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 5) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function groundNormal(c, jc, slide, atk, meter, se, crouchable) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c, slide);
    if (groundJumpCancel(c, jc)) return;
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, crouchable);
    }
}
const s200 = (c)=>groundNormal(c, 1, 0.06, 1, 5, 21, false);
const s201 = (c)=>groundNormal(c, 1, 0.06, 1, 15, 20, false);
const s202 = (c)=>groundNormal(c, 0, 0.06, 2, 15, 20, false);
const s204 = (c)=>groundNormal(c, 1, 0.06, 1, 5, 21, true);
const s205 = (c)=>groundNormal(c, 1, 0.03, 2, 13, 20, true);
const s206 = (c)=>groundNormal(c, 2, 0.06, 2, 25, 20, true);
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c, 0.06);
    if (atFrame(c, 2)) {
        attackStart(c, 35, 20, 2);
        c.f3138 = 2;
    }
    if (advance(c, dur)) {
        if (c.frame < 8) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function airNormal(c, atk, meter, se, clearBelow) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return;
    }
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s207 = (c)=>airNormal(c, 1, 5, 21, 2);
const s208 = (c)=>airNormal(c, 2, 13, 20, 2);
const s209 = (c)=>airNormal(c, 2, 30, 20, 3);
function s210(c) {
    const dur = frameDuration(c);
    if (c.frame > 6) c.vy = c.vy + c.ay;
    if (atFrame(c, 2)) c.stopMotion();
    if (atFrame(c, 6)) {
        attackStart(c, 30, 20, 3);
        c.vx = 1.0;
        c.vy = 1.0;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.setState(13);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 10) c.frame = 7;
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy = c.vy + c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        d.w04 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        d.b2c = 7;
        frameEffect(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 2 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 221;
        o.state = 107;
        o.hitstop = 60;
        o.x = c.facing * 0x28 + c.x;
        o.facing = -c.facing;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x26;
        d.y = ftol(c.y) - 58;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 2 && o.y === 0.0) c.w16c = 1;
        else c.w16c = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.biasCameraY(50, 3);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) {
            o.x = c.facing * 0x23 + c.x;
            o.y = -57.0;
            o.state = 101;
        }
        if (c.frame === 2) {
            o.x = c.facing * 0x15 + c.x;
            o.y = -68.0;
            o.state = 103;
        }
        if (c.frame === 3) {
            o.x = c.x - c.facing * 0x1b;
            o.y = -88.0;
            o.state = 59;
            applyDirectDamage(c, 1150, 750.0);
            o.onStateChange();
            o.stopMotion();
            o.facing = c.facing;
            o.knockX = -1.5;
            o.knockY = -1.0;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s230(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.vx = c.vx - 0.06;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atStart(c)) c.vy = 0.0;
    if (atFrame(c, 1)) attackStart(c, 5, 21, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function s231(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    if (c.vx > 0.0) c.vx = c.vx - 0.03;
    else c.b158 = 0;
    if (atFrame(c, 1)) {
        c.w16c = 1;
        c.seRequest = 20;
        addMeter(c, 20);
    }
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function s232(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    if (atStart(c)) {
        c.vx = 1.1;
        c.vy = -2.5;
    }
    c.vy = c.vy + 0.055;
    if (c.y === 0.0 && c.frame > 0) c.vy = 0.0;
    if (atFrame(c, 11)) {
        c.seRequest = 21;
        addMeter(c, 35);
        c.w16c = 1;
    }
    if (c.vy + c.y >= 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
        c.setState(269);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(13);
    }
}
function s248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 249;
        o.state = 100;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x29;
        d.y = ftol(c.y) - 84;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.x = c.facing * 0x29 + c.x;
        o.y = c.y - 84.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 209;
            c.frame = 2;
        }
    }
}
function s249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 3) c.biasCamera(50, 3);
    if (c.frame < 3) c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    if (atStart(c)) {
        if (c.f3138 === 2) {
            const d = openSpawnFrame();
            d.w04 = 422;
            d.x = ftol(c.x) + c.facing * 0x29;
            d.y = ftol(c.y) - 84;
            d.b20 = 2;
            d.b21 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
        }
        if (c.f3138 > 2) c.voiceRequest = 10;
    }
    c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 5) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.state = 13;
        return;
    }
    if (c.frame === 2) {
        o.y = c.y - 68.0;
        o.x = c.facing * 0x19 + c.x;
    }
    if (atFrame(c, 3)) {
        o.hitstop = 0;
        o.y = c.y - 31.0;
        o.x = c.facing * 0x1f + c.x;
        o.state = 69;
        applyDirectDamage(c, 1200, 500.0);
        o.onStateChange();
        o.knockX = -3.0;
        o.knockY = 3.0;
    }
    if (atFrame(c, 5)) c.ay = 0.035;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 2 && c.f3138 < 10) {
            c.f3138++;
            c.frame = w16(c.frame - 2);
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    248: s248,
    249: s249
});
function child400(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const s = c.state;
    if (!(s > 149 && s < 157 || s > 167 && s < 171)) {
        c.freeChild(i);
        c.f3148 = 0;
        return;
    }
    if (s > 149 && s < 153 || s === 168) {
        ch.y = c.y - 56.0;
        ch.x = c.facing * 0x1c + c.x;
    }
    if (s > 152 && s < 156 || s === 169) {
        ch.y = c.y - 37.0;
        ch.x = c.facing * 0x1c + c.x;
    }
    if (s === 156 || s === 170) {
        ch.y = c.y - 64.0;
        ch.x = c.facing * 0x1c + c.x;
    }
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= dur) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= cnt) ch.frame = 0;
    }
}
function child422(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (c.frame > 1) c.freeChild(i);
    ch.timer = w16(ch.timer + 1);
    if (c.hitstop > 0) ch.timer = w16(ch.timer - 1);
    if (ch.timer >= dur) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= cnt) ch.frame = w16(ch.frame - 2);
    }
}
registerChildren({
    400: child400,
    422: child422
});

export function __logicState(){return {Jc};}

export function __installInitialRoots(s){
Jc=s["Jc"];
}
