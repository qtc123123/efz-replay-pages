import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { HISTORY_LENGTH, NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { registerChildren } from "./4fd020f21e3ef9d96dc087c0.mjs";
import { childCount, childDuration } from "./b1bf50e501f736bc8b07bfdb.mjs";
function hist(c, i) {
    return c.history[i - (i >= HISTORY_LENGTH ? 1 : 0) * HISTORY_LENGTH];
}
function buttonCommand(base, v) {
    return base + ((v & 0xe0) > 0 ? 1 : 0) + ((v & 0xc0) > 0 ? 1 : 0) + ((v & 0x80) > 0 ? 1 : 0);
}
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function cancelable(c) {
    return ((c.currentHit()?.defenseFlags ?? 0) & 8) > 0;
}
function priorityOk(c, hdrState) {
    return (c.patterns[c.state]?.hdrB ?? 0) <= (c.patterns[hdrState]?.hdrA ?? 0);
}
function cancelOk(c) {
    if (c.state >= 200 && c.d168 >= 2 && c.d168 !== 6) return true;
    return c.state < 200;
}
function rfOk(c) {
    return c.rfGauge >= 500.0 || c.rfBlue > 0;
}
function enter(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function moveOk(c, hdrState) {
    return cancelable(c) && cancelOk(c) && priorityOk(c, hdrState);
}
function crouchHeld(c) {
    return c.inputY === 1 || (c.bufferedA & 4) !== 0 || (c.bufferedB & 4) !== 0;
}
function standHeld(c) {
    return c.inputY === 0 || (c.bufferedA & 4) === 0 || (c.bufferedB & 4) === 0;
}
function oppThrowable(c) {
    return c.opponent.state < 50 || c.opponent.state > 156;
}
function partnerBusy(c) {
    return c.f3148 === 4;
}
export function parseCommandMinagi(c) {
    c.command = NO_COMMAND;
    const idx = c.historyIndex;
    const end = idx + HISTORY_LENGTH;
    const left = c.facing === -1 ? 1 : 0;
    const BACK = 2 - left;
    const FWD = 1 + left;
    const DOWN_BACK = 6 - left;
    const DOWN_FWD = 5 + left;
    let step;
    let v;
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 6) {
            c.command = 0x5c;
            return;
        }
        if ((v & 0xf) === 4 && step === 5) step = 6;
        if ((v & 0xf) === 0 && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0 && c.meter === 3000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x64; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 5) {
            c.command = buttonCommand(0xaa, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 4) {
            if (v & 0xf0) {
                c.command = buttonCommand(0xa0, v);
                return;
            }
            step = 5;
        }
        if ((v & 0xf) === DOWN_FWD && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x6e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x6e, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_BACK && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x64, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x64, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_FWD && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x6e; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 4 && c.y === 0.0) {
            c.command = buttonCommand(0x50, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 3) {
            if (v & 0xf0 && c.y === 0.0) {
                c.command = buttonCommand(0x50, v);
                return;
            }
            step = 4;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x46, v);
            return;
        }
        if ((v & 0xf) === DOWN_BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x46, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x14, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x14, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x1e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x1e, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0xaf; i < end; i++){
        v = hist(c, i);
        if (v & 8 && step === 1) {
            c.command = 6;
            return;
        }
        if (!(v & 8) && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 4) {
            c.command = 53;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0 && c.state === 96) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 4) {
            c.command = 52;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 4) {
            c.command = 51;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 4) {
            c.command = 50;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 1 && step === 3) {
            c.command = 1;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 1 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 2 && step === 3) {
            c.command = 0;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 2 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
}
function special(c, ok, ground, air) {
    if (!ok || !moveOk(c, ground)) return false;
    enter(c, ground);
    if (air !== 0 && c.y < 0.0) c.state = air;
    return true;
}
export function dispatchMovesMinagi(c) {
    const cmd = c.command;
    if (c.state < 200) c.bufferedA = 0;
    if (c.bufferTimer > 0) {
        c.bufferTimer = c.bufferTimer - 1 & 0xff;
    } else {
        c.bufferedB = 0;
    }
    if (c.bufferedB === 0) c.bufferTimer = 0;
    if (cmd === 52 && rfOk(c) && c.d168 > 1 && c.d168 !== 6 && cancelable(c) && priorityOk(c, 167)) {
        enter(c, 167);
        if (c.y < 0.0) c.state = 171;
        return;
    }
    if (c.d15c < 2) {
        const ground = c.y === 0.0;
        if (c.life < 3333 && !partnerBusy(c) && cmd === 92 && c.meter >= 3000 && ground && moveOk(c, 313)) {
            enter(c, 315);
            return;
        }
        if (special(c, cmd === 172 && ground && c.meter >= 3000, 314, 0)) return;
        if (special(c, ground && (cmd === 171 || cmd === 172) && c.meter >= 2000, 313, 0)) return;
        if (special(c, ground && (cmd === 170 || cmd === 171 || cmd === 172) && c.meter >= 1000, 312, 0)) return;
        if (special(c, !partnerBusy(c) && cmd === 112 && c.meter >= 3000, 305, 311)) return;
        if (special(c, !partnerBusy(c) && (cmd === 111 || cmd === 112) && c.meter >= 2000, 304, 310)) return;
        if (special(c, !partnerBusy(c) && (cmd === 110 || cmd === 111 || cmd === 112) && c.meter >= 1000, 303, 309)) return;
        if (special(c, !partnerBusy(c) && cmd === 102 && c.meter >= 3000, 302, 308)) return;
        if (special(c, !partnerBusy(c) && (cmd === 101 || cmd === 102) && c.meter >= 2000, 301, 307)) return;
        if (special(c, !partnerBusy(c) && (cmd === 100 || cmd === 101 || cmd === 102) && c.meter >= 1000, 300, 306)) return;
        if (special(c, cmd === 82 && rfOk(c) && ground && c.f314c === 0, 264, 0)) return;
        if (special(c, (cmd === 81 || cmd === 82) && ground && c.f314c === 0, 263, 0)) return;
        if (special(c, cmd === 80 && ground && c.f314c === 0, 262, 0)) return;
        if (special(c, !partnerBusy(c) && cmd === 32 && rfOk(c), 261, 274)) return;
        if (special(c, !partnerBusy(c) && (cmd === 31 || cmd === 32), 260, 273)) return;
        if (special(c, !partnerBusy(c) && cmd === 30, 259, 272)) return;
        if (special(c, !partnerBusy(c) && ground && cmd === 22 && rfOk(c), 277, 0)) return;
        if (special(c, !partnerBusy(c) && ground && (cmd === 21 || cmd === 22), 276, 0)) return;
        if (special(c, !partnerBusy(c) && ground && cmd === 20, 275, 0)) return;
        if (special(c, !partnerBusy(c) && cmd === 72 && rfOk(c), 258, 271)) return;
        if (special(c, !partnerBusy(c) && (cmd === 71 || cmd === 72), 257, 270)) return;
        if (special(c, !partnerBusy(c) && cmd === 70, 256, 269)) return;
        if (special(c, !partnerBusy(c) && cmd === 12 && rfOk(c), 255, 267)) return;
        if (special(c, !partnerBusy(c) && (cmd === 11 || cmd === 12), 254, 266)) return;
        if (special(c, !partnerBusy(c) && cmd === 10, 253, 265)) return;
    }
    if (c.d15c < 1 && (cmd === 0 || cmd === 1)) {
        if (c.y < 0.0 && c.b159 < 1) {
            let dir = 1 - (cmd << 1);
            let dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 165) && c.state !== 170 && c.y < -30.0 && cancelable(c) && cancelOk(c) && c.state !== 253) {
                dash(c, 165, true);
                return;
            }
            dir = 1 - (cmd << 1);
            dx = c.opponent.x - c.x;
            if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && c.state !== 170 && priorityOk(c, 166) && cancelable(c) && cancelOk(c)) {
                dash(c, 166, true);
                return;
            }
        }
        if (c.y === 0.0 && cancelable(c)) {
            let dir = 1 - (cmd << 1);
            let dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 163) && cancelOk(c)) {
                dash(c, 163, false);
                return;
            }
            dir = 1 - (cmd << 1);
            dx = c.opponent.x - c.x;
            if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && priorityOk(c, 164) && cancelOk(c)) {
                dash(c, 164, false);
                return;
            }
        }
    }
    if (c.d15c < 3 && cmd === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && priorityOk(c, 14) && cancelOk(c)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return;
    }
    if (c.pressed[0] === 1 || c.bufferedA & 0x10 || c.bufferedB & 0x10) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 230);
            if (c.inputY === 1) c.state = 233;
            return;
        }
        if (c.y < 0.0) {
            if (moveOk(c, 207)) enter(c, 207);
            return;
        }
        if (crouchHeld(c) && moveOk(c, 204)) {
            enter(c, 204);
            return;
        }
        if (standHeld(c) && moveOk(c, 200)) {
            enter(c, 200);
            return;
        }
    }
    if (c.pressed[1] === 1 || c.bufferedA & 0x20 || c.bufferedB & 0x20) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 231);
            if (c.inputY === 1) c.state = 234;
            return;
        }
        if (c.y < 0.0) {
            if (moveOk(c, 208)) enter(c, 208);
            return;
        }
        if (crouchHeld(c) && moveOk(c, 205)) {
            enter(c, 205);
            return;
        }
        if (standHeld(c)) {
            if (priorityOk(c, 201) && cancelable(c) && c.x - c.opponent.x > -50.0 && c.x - c.opponent.x < 50.0 && cancelOk(c)) {
                enter(c, 201);
                return;
            }
            if (moveOk(c, 202)) {
                enter(c, 202);
                return;
            }
        }
    }
    if (c.pressed[2] === 1 || c.bufferedA & 0x40 || c.bufferedB & 0x40) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 232);
            if (c.inputY === 1) c.state = 235;
            return;
        }
        if (c.y < 0.0) {
            if (c.inputX === c.facing && c.inputY === 0 && c.x - c.opponent.x > -100.0 && c.x - c.opponent.x < 100.0 && c.opponent.y < 0.0 && priorityOk(c, 248) && oppThrowable(c) && cancelable(c) && cancelOk(c)) {
                enter(c, 248);
                return;
            }
            if (moveOk(c, 209)) enter(c, 209);
            return;
        }
        if (crouchHeld(c) && moveOk(c, 206)) {
            enter(c, 206);
            return;
        }
        if (standHeld(c)) {
            if (c.opponent.y === 0.0 && c.inputX !== 0 && c.x - c.opponent.x > -30.0 && c.x - c.opponent.x < 30.0 && priorityOk(c, 220) && oppThrowable(c) && cancelable(c) && cancelOk(c)) {
                enter(c, 220);
                return;
            }
            if (moveOk(c, 203)) {
                enter(c, 203);
                return;
            }
        }
    }
    if (c.d15c >= 2) return;
    if (c.pressed[3] === 1 || c.bufferedA & 0x80 || c.bufferedB & 0x80) {
        if (priorityOk(c, 250) && cancelable(c) && c.y === 0.0 && cancelOk(c)) {
            if ((c.f3148 === 0 || c.f3148 === 2 || c.f3148 === 3) && c.inputX === 0) {
                enter(c, 250);
                return;
            }
            if (c.f3148 === 0 && c.inputX === 1) {
                enter(c, 251);
                return;
            }
            if (c.f3148 === 0 && c.inputX === -1) {
                enter(c, 252);
            }
        }
    }
}
function dash(c, s, air) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    if (air) {
        c.b159 = c.b159 + 1 & 0xff;
        c.b15a = c.b15a + 1 & 0xff;
    } else {
        c.b158 = c.b158 + 1 & 0xff;
    }
    c.bufferedA = 0;
}
function child413(c, i, p) {
    const ch = c.children[i];
    c.f3148 = 4;
    if (ch.frame < p.camFrames) {
        c.opponent.biasCameraY(0x32, 0x1e);
        if (p.altBg) c.showAltBackground(0xf);
    }
    if (ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 0x193;
        ch.frame = 0;
        ch.timer = 0;
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.moveWhileFrozen = 1;
    }
    if (c.state !== p.states[0] && c.state !== p.states[1]) ch.moveWhileFrozen = 0;
    if (ch.y < 0.0 && ch.frame > 0x10) {
        ch.vy += 0.035;
        if (ch.vy + ch.y > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.timer = 0;
            ch.frame = p.land;
            return;
        }
    }
    if (ch.x > 620.0) {
        ch.vx = 0.0;
        ch.x = 620.0;
    }
    if (ch.x < 20.0) {
        ch.vx = 0.0;
        ch.x = 20.0;
    }
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame === 0xa) {
        ch.hitsLeft = 0x63;
        c.a3254[i] = 0;
        c.a3154[i] = 0;
        ch.frame = ch.frame + 4 & 0xffff;
        return;
    }
    if (ch.frame === 0xe && c.a3254[i] < p.loop14) {
        ch.frame = ch.frame - 4 & 0xffff;
        c.a3254[i]++;
    }
    if (ch.frame === 0xf) {
        ch.vx = 0.5;
        ch.vy = p.vy15;
    }
    if (ch.frame === 0x10 && c.a3154[i] < p.loop16) {
        c.a3154[i]++;
        ch.frame = ch.frame - 1 & 0xffff;
    }
    if (ch.frame === p.land) ch.frame = ch.frame - 2 & 0xffff;
    if (ch.frame >= childCount) {
        ch.pattern = 0x190;
        ch.frame = 0;
        c.f3148 = 0;
    }
}
const SPEC_413 = {
    states: [
        0x12c,
        0x132
    ],
    camFrames: 0x10,
    altBg: false,
    land: 0x14,
    loop14: 2,
    vy15: -2.2,
    loop16: 2
};
const SPEC_414 = {
    states: [
        0x12d,
        0x133
    ],
    camFrames: 0x14,
    altBg: false,
    land: 0x17,
    loop14: 3,
    vy15: -2.6,
    loop16: 3
};
const SPEC_415 = {
    states: [
        0x12e,
        0x134
    ],
    camFrames: 0x17,
    altBg: true,
    land: 0x1a,
    loop14: 3,
    vy15: -2.6,
    loop16: 4
};
function child466(c, i, p) {
    const ch = c.children[i];
    c.f3148 = 4;
    if (ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 0x193;
        ch.frame = 0;
        ch.timer = 0;
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    if (ch.y < 0.0 && ch.frame > 0xb) {
        ch.vy += p.gravity;
        if (ch.vy + ch.y > 0.0 && ch.frame < p.land) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.timer = 0;
            ch.frame = p.land;
            return;
        }
    }
    if (ch.x > 620.0) {
        ch.vx = 0.0;
        ch.x = 620.0;
    }
    if (ch.x < 20.0) {
        ch.vx = 0.0;
        ch.x = 20.0;
    }
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame === 0xb) {
        ch.hitsLeft = 0x63;
        ch.vx = 0.5;
        ch.vy = -2.0;
    }
    if (p.loop12 > 0 && ch.frame === 0xc && c.a3154[i] < p.loop12) {
        ch.frame = ch.frame - 1 & 0xffff;
        c.a3154[i]++;
    }
    if (ch.frame === p.land) ch.frame = ch.frame - 2 & 0xffff;
    if (ch.frame >= childCount) {
        ch.pattern = 0x190;
        ch.frame = 0;
        c.f3148 = 0;
    }
}
const SPEC_466 = {
    gravity: 0.035,
    land: 0x10,
    loop12: 0
};
const SPEC_468 = {
    gravity: 0.025,
    land: 0x16,
    loop12: 3
};
function child469(c, i) {
    const ch = c.children[i];
    c.f3148 = 4;
    ch.moveWhileFrozen = 0;
    c.a3154[i] = 0;
    c.a3254[i] = 0;
    c.a3354[i] = 0;
    if (ch.frame === 0xb && ch.timer === 0) {
        ch.x = c.facing * 0x3c + c.x;
    }
    if (ch.x > 620.0) {
        ch.vx = 0.0;
        ch.x = 620.0;
    }
    if (ch.x < 20.0) {
        ch.vx = 0.0;
        ch.x = 20.0;
    }
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame >= childCount) {
        ch.pattern = 0x190;
        ch.frame = 0;
        c.f3148 = 0;
    }
}
registerChildren({
    413: (c, i)=>child413(c, i, SPEC_413),
    414: (c, i)=>child413(c, i, SPEC_414),
    415: (c, i)=>child413(c, i, SPEC_415),
    466: (c, i)=>child466(c, i, SPEC_466),
    467: (c, i)=>child466(c, i, SPEC_466),
    468: (c, i)=>child466(c, i, SPEC_468),
    469: child469
});

export function __logicState(){return {SPEC_413,SPEC_414,SPEC_415,SPEC_466,SPEC_468};}

export function __installInitialRoots(s){
if(SPEC_413!==s["SPEC_413"])throw Error('INITIAL_CONST_IDENTITY:SPEC_413');
if(SPEC_414!==s["SPEC_414"])throw Error('INITIAL_CONST_IDENTITY:SPEC_414');
if(SPEC_415!==s["SPEC_415"])throw Error('INITIAL_CONST_IDENTITY:SPEC_415');
if(SPEC_466!==s["SPEC_466"])throw Error('INITIAL_CONST_IDENTITY:SPEC_466');
if(SPEC_468!==s["SPEC_468"])throw Error('INITIAL_CONST_IDENTITY:SPEC_468');
}
