import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
function chance2(c) {
    const r = rnd(c, 0, 100);
    return c.aiLevel + c.aiLevel > r;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = rnd(c, 0, 2) - 1;
}
function dashCommand(c) {
    return c.facing === 1 ? 1 : 0;
}
function pickSpecial(c) {
    c.command = rnd(c, 0, 3) + 40;
    if (rnd(c, 0, 100) < 20) c.command = rnd(c, 0, 3) + 30;
}
function pickRushMode(c, dx, table, withA) {
    for (const [n, mode] of table){
        if (rnd(c, 0, n) === 0) c.aiMode = mode;
    }
    if (withA && dx < 50.0 && rnd(c, 0, 2) === 0) c.aiMode = 20;
}
function oppReeling(c) {
    const s = c.opponent.state;
    return s > 49 && s < 156 ? 1 : 0;
}
function rfOk(c) {
    return c.rfGauge > 500.0 || c.rfBlue > 0;
}
export function thinkKaori(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25.0 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 170 ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 149 && c.state < 157 ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40.0 * c.aiLevel > r && c.state > 199) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 200) c.aiMode = 0;
        return;
    }
    if (o.state === 96) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 50 && c.state <= 150 && c.timer === 0) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 50 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 240) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 320) < dx ? 1 : 0;
        if (o.state > 199 && o.state < 250 && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 10 && c.state <= 12) && c.y === 0.0) return;
    if (o.state >= 50 && o.state < 150 && c.state === 264 && c.w16c > 1) return;
    if (c.state === 168 && c.timer < 6) {
        if (o.state !== 200 && o.state !== 204 && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx < 35.0 && chance(c, 3.0)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 50.0 && chance2(c)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
        }
        if ((o.state === 201 || o.state === 202 || o.state === 205) && o.state < 250 && o.y === 0.0 && o.w16c === 0 && dx > 60.0 && dx < 80.0 && chance(c, 1.0)) {
            c.pressed[1] = 1;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.state === 168 || c.state === 169) {
        if (dx < 90.0) {
            if (chance(c, 3.0) && c.rfGauge > 500.0) {
                c.command = 20;
                return;
            }
            if (chance2(c) && c.rfGauge > 500.0) {
                c.command = 22;
                return;
            }
            if (chance2(c)) {
                c.command = 11;
                return;
            }
            if (dx < 40.0 && chance2(c)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 60.0 && chance(c, 1.0)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (chance(c, 1.0) && c.meter === 2000) {
                c.command = 121;
                return;
            }
            if (chance(c, 1.0) && dx < 30.0 && c.meter === 3000) {
                c.command = 90;
                return;
            }
        }
        if (dx < 130.0 && dx > 90.0) {
            if (chance2(c) && c.rfGauge > 500.0) {
                c.command = 12;
                return;
            }
            if (chance(c, 1.0) && c.rfGauge > 500.0) {
                c.command = 22;
                return;
            }
            if (dx < 110.0 && chance(c, 1.0)) {
                c.pressed[0] = 2;
                c.inputY = 0;
                return;
            }
            if (chance2(c)) {
                c.command = 42;
                return;
            }
            if (chance(c, 3.0)) {
                c.command = 11;
                return;
            }
        }
        if (dx > 130.0) {
            if (chance(c, 1.0)) {
                c.command = 42;
                return;
            }
            if (chance(c, 3.0)) {
                c.command = 11;
                return;
            }
        }
    }
    if (c.state === 170 && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5.0)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -40.0 && dx < 80.0 && chance(c, 5.0)) {
            c.pressed[0] = 1;
            return;
        }
        if (c.y - o.y > -50.0 && c.y - o.y < 50.0 && dx < 80.0 && chance(c, 5.0)) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y > -30.0 && c.y - o.y < 90.0 && dx < 120.0 && chance(c, 5.0)) {
            c.pressed[2] = 1;
            c.inputY = 0;
            c.inputX = c.facing;
            return;
        }
        if (chance2(c)) {
            c.command = 42;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y === 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 2 && c.rfGauge > 500.0) {
            c.command = 22;
            return;
        }
        if (c.aiRoll < 5 && c.aiRoll > 2 && c.rfGauge > 500.0) {
            c.command = 20;
            return;
        }
        if (c.aiRoll < 8 && c.aiRoll > 5) {
            c.command = 10;
            return;
        }
        if (c.aiRoll < 12 && c.aiRoll > 8 && dx < 50.0) {
            c.command = 42;
            return;
        }
        if (c.aiRoll < 18 && c.aiRoll > 20 && dx < 30.0 && c.meter === 3000) {
            c.command = 90;
            return;
        }
        if (c.aiRoll > 65) {
            c.aiMode = 2;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y < 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 2) {
            c.command = 42;
            return;
        }
        if (c.aiRoll > 65) {
            c.aiMode = 2;
            return;
        }
    }
    if (rfOk(c) && 8.0 * c.aiLevel > rnd(c, 0, 100) && o.state > 149 && o.state < 157 && (c.state === 253 || c.state === 254 || c.state === 255 || c.state === 265 && c.y < -110.0 || c.state === 271 || c.state === 272 || c.state === 273)) {
        c.command = 52;
        return;
    }
    if (c.state > 255 && c.state < 262 && 10.0 * c.aiLevel < rnd(c, 0, 100)) {
        if (dy * 0.5 > dx) {
            c.pressed[2] = 1;
            return;
        }
        if (dx < 30.0 && dy < 50.0) {
            c.pressed[2] = 1;
            c.inputX = -c.facing;
            return;
        }
        if (dx < 20.0 && dy > 80.0) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return;
        }
        if (dx > 120.0 && dy < dx) {
            c.command = rnd(c, 0, 2) + 11;
            return;
        }
    }
    if (c.aiMode > 0 && c.state > 49 && c.state < 158) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 200) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = rnd(c, 0, 2) - 1;
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = dashCommand(c);
            if (c.state === 165) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 7;
        return;
    }
    if (c.aiMode === 7 && c.state === 163) {
        c.pressed[0] = 1;
        if (c.state === 230) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 8 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 9;
        return;
    }
    if (c.aiMode === 9 && c.state === 163) {
        c.pressed[1] = 1;
        if (c.state === 231) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 10 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 11;
        return;
    }
    if (c.aiMode === 11 && c.state === 163) {
        c.pressed[2] = 1;
        if (c.state === 232) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 12 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 13;
        return;
    }
    if (c.aiMode === 13 && c.state === 163) {
        c.pressed[0] = 1;
        c.inputY = 1;
        if (c.state === 230) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 14 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 15;
        return;
    }
    if (c.aiMode === 15 && c.state === 163) {
        c.pressed[1] = 1;
        c.inputY = 1;
        if (c.state === 231) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 16 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 17;
        return;
    }
    if (c.aiMode === 17 && c.state === 163) {
        c.pressed[2] = 1;
        c.inputY = 1;
        if (c.state === 232) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 20 && c.state < 50) {
        c.pressed[0] = 1;
        c.inputY = 1;
        if (c.state === 204) c.aiMode = 0;
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && c.aiLevel * 25.0 > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (comboKaori(c, dx)) return;
    }
    if (25.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        const roll = c.aiRoll;
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 99) {
                if (dx < 40.0 && o.y === 0.0 && roll < 5) {
                    c.pressed[2] = 1;
                    c.inputX = -c.facing;
                    c.inputY = 0;
                    return;
                }
                if (dx < 40.0 && roll < oppReeling(c) * 25 + 65) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 55.0 && roll > 90 && roll < oppReeling(c) * 25 + 140) {
                    c.pressed[0] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx > 80.0 && dx < 100.0 && roll < 160 && roll > 140) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (70 - oppReeling(c) * 70 < dx && dx < 100.0 && roll < oppReeling(c) * 40 + 200 && roll > 160) {
                    c.aiMode = 8;
                    return;
                }
                if (70 - oppReeling(c) * 70 < dx && dx < 100.0 && roll < oppReeling(c) * 40 + 280 && roll > 240) {
                    c.aiMode = 12;
                    return;
                }
                if (dx < 120.0 && dx > 60.0 && roll < 360 && roll > 320) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 120.0 && dx > 80.0 && roll < 380 && roll > 360) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx > 100.0 && dx < 150.0 && roll < 430 && roll > 380) {
                    c.aiMode = 14;
                    return;
                }
                if (90 - oppReeling(c) * 90 < dx && dx < 130.0 && roll < 470 && roll > 430) {
                    c.aiMode = 10;
                    return;
                }
                if (dx > 90.0 && dx < 150.0 && roll < 530 && roll > 470) {
                    c.aiMode = 10;
                    return;
                }
                if (dx > 180.0 && roll < 560 && roll > 550) {
                    c.command = 10;
                    return;
                }
                if (dx < 100.0 && roll < 570 && roll > 560) {
                    c.command = rnd(c, 0, 3) + 101;
                    return;
                }
                if (dx > 100.0 && roll < 590 && roll > 570) {
                    c.command = 10;
                    return;
                }
                if (dx > 100.0 && roll < 610 && roll > 590) {
                    c.command = 11;
                    return;
                }
                if (roll < 750 && roll > 700 && o.state > 49 && o.state < 156 && dx > 100.0) {
                    c.aiMode = 5;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 120.0 && roll < 10) {
                        c.inputY = -1;
                        c.inputX = -c.facing;
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 80.0 && dy < 90.0 && roll < 6 && rfOk(c)) {
                        c.command = 22;
                        return;
                    }
                    if (dx < 80.0 && dy < 90.0 && roll < (rfOk(c) ? 1 : 0) * 8 + 10) {
                        c.command = 20;
                        return;
                    }
                    if (dx < 60.0 && roll < 310 && roll > 300 && dy > 100.0 && c.meter === 3000) {
                        c.command = 102;
                        return;
                    }
                    if (dx < 60.0 && roll < 320 && roll > 310 && dy > 200.0 && c.meter >= 1000) {
                        c.command = rnd(c, 0, 2) + 100;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 80.0 && dy < 100.0 && roll < 100) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 80.0 && dy > 90.0 && dy < 80.0 && o.y < c.y && roll > 100 && roll < 180) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx > 80.0 && dx < 110.0 && dy > 100.0 && dy < 130.0 && roll > 180 && roll < 240) {
                    c.pressed[2] = 1;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 80.0 && dy < 100.0 && c.y < o.y && roll < 20) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx > 20.0 && dx < 90.0 && dy > 90.0 && roll > 20 && roll < 40) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx > 80.0 && dx < 100.0 && dy > 70.0 && dy < 100.0 && c.y < o.y && roll > 40 && roll < 50) {
                    c.pressed[2] = 1;
                    return;
                }
                if (dx > 90.0 && dx < 130.0 && dy > 40.0 && dy < 120.0 && c.y > o.y && roll > 50 && roll < 65) {
                    c.pressed[2] = 1;
                    c.inputX = c.facing;
                    return;
                }
            }
        }
    }
    if (c.state < 50 && (o.state > 149 && o.state < 156 || o.state > 49 && o.state < 59) && c.y === 0.0 && 5.0 * c.aiLevel > rnd(c, 0, 100) && dx > 120.0) {
        c.command = dashCommand(c);
        return;
    }
    if (rnd(c, 0, 1000) < 2 && dx > 90.0) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 4) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 180.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 170.0 && dx > 140.0 && c.y === 0.0 && o.state < 50) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 15) c.aiTimer1a0 = 15;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 15) c.aiTimer1a4 = 15;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 40 && dx < 120.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 200) + 30;
        else c.aiTimer1a0 = rnd(c, 0, 200) + 30;
    }
    if (rnd(c, 0, 100) < 70) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 200) + 60;
        else c.aiTimer1a4 = rnd(c, 0, 200) + 60;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 200) + 60;
    else c.aiTimer1a4 = rnd(c, 0, 200) + 60;
}
function comboKaori(c, dx) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (c.state === 200) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 60.0 && roll > 0 && roll < 300) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 80.0 && roll > 0 && roll < 400) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 70.0 && roll > 400 && roll < 700) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 970) {
            startJump(c);
            return true;
        }
        if (roll > 600) {
            c.aiMode = 1;
            pickRushMode(c, dx, [
                [
                    3,
                    6
                ],
                [
                    3,
                    8
                ],
                [
                    3,
                    8
                ],
                [
                    3,
                    12
                ]
            ], true);
            return true;
        }
    }
    if (c.state === 201) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (o.y < 0.0 && roll > 300 && roll < 550) {
            pickSpecial(c);
            return true;
        }
        if (o.y < 0.0 && roll > 600 && roll < 750) {
            c.inputX = c.facing;
            c.inputY = -1;
            return true;
        }
        if (roll < 100) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 100 && roll < 350 && dx < 110.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 350 && roll < 600) {
            pickSpecial(c);
            return true;
        }
        if (o.y < 0.0 && roll > 600 && roll < 750 && dx < 100.0) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 750) {
            c.aiMode = 1;
            pickRushMode(c, dx, [
                [
                    3,
                    6
                ],
                [
                    4,
                    8
                ],
                [
                    4,
                    10
                ],
                [
                    3,
                    12
                ]
            ], true);
            return true;
        }
    }
    if (c.state === 202) {
        if (o.y < 0.0 && roll > 0 && roll < 300) {
            c.command = 11;
            return true;
        }
        if (o.y < 0.0 && roll > 300 && roll < 500) {
            pickSpecial(c);
        }
        if (roll > 500 && roll < 600) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 600) {
            c.aiMode = 1;
            pickRushMode(c, dx, [
                [
                    2,
                    12
                ],
                [
                    2,
                    14
                ],
                [
                    3,
                    16
                ]
            ], false);
            return true;
        }
    }
    if (c.state === 203) {
        if (roll > 0 && roll < 300) {
            c.command = 11;
            return true;
        }
        if (roll > 350 && roll < 600) {
            pickSpecial(c);
            return true;
        }
        if (roll > 900) {
            c.aiMode = 1;
            return true;
        }
    }
    if (c.state === 204) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 600 && roll < 650) {
            pickSpecial(c);
            return true;
        }
        if (dx < 70.0 && roll > 0 && roll < 200) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 80.0 && roll > 200 && roll < 600) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 970) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            pickRushMode(c, dx, [
                [
                    2,
                    6
                ],
                [
                    4,
                    8
                ],
                [
                    3,
                    12
                ]
            ], true);
            return true;
        }
    }
    if (c.state === 205) {
        if (roll < 100) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 100 && roll < 250 && dx < 110.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 250 && roll < 450 && dx < 100.0) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 450 && roll < 550) {
            c.command = 11;
            return true;
        }
        if (roll > 550 && roll < 650) {
            pickSpecial(c);
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 800) {
            c.aiMode = 1;
            return true;
        }
    }
    if (c.state === 206) {
        if (roll > 0 && roll < 400) {
            pickSpecial(c);
            return true;
        }
        if (roll > 400 && roll < 600) {
            c.command = 11;
            return true;
        }
        if (roll > 800 && roll < 850 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 110;
            return true;
        }
        if (roll > 900) {
            c.aiMode = 1;
            return true;
        }
    }
    if (c.state === 207) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            return true;
        }
        if (dx < 60.0 && roll < 400) {
            c.pressed[0] = 1;
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 4) === 0) c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 208) {
        if (roll > 80 && roll < 300) {
            c.pressed[2] = 1;
            const f = c.facing;
            c.inputX = f * (rnd(c, 0, 2) === 0 ? 1 : 0);
            return true;
        }
        if (roll > 950) {
            c.inputX = rnd(c, 0, 2) - 1;
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 209) {
        if (roll < 200) {
            c.command = 42;
            return true;
        }
        if (roll > 950) {
            c.inputX = rnd(c, 0, 2) - 1;
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 231 || c.state === 230 || c.state === 232 || c.state === 233 || c.state === 234) {
        if (roll < 450) {
            pickSpecial(c);
            return true;
        }
        if (roll > 450 && roll < 650) {
            c.command = 11;
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            pickRushMode(c, dx, [
                [
                    2,
                    6
                ],
                [
                    4,
                    8
                ],
                [
                    3,
                    10
                ],
                [
                    4,
                    12
                ],
                [
                    4,
                    14
                ]
            ], true);
            return true;
        }
    }
    if (c.state === 265 && roll > 600 && c.y === 0.0) {
        c.aiMode = 1;
        if (dx < 50.0) c.aiMode = 20;
        return true;
    }
    if (c.state === 235 && roll > 600 && c.y === 0.0) {
        c.aiMode = 1;
        if (dx < 50.0) c.aiMode = 20;
        return true;
    }
    if (c.state === 251 && roll > 699) {
        pickRushMode(c, dx, [
            [
                2,
                6
            ],
            [
                4,
                8
            ],
            [
                3,
                10
            ],
            [
                4,
                12
            ],
            [
                4,
                14
            ],
            [
                3,
                16
            ]
        ], false);
        return true;
    }
    return false;
}
