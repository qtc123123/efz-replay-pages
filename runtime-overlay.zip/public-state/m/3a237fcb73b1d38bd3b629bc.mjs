import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { spawnEffect } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { childHandlers, registerChildren, registerStates } from "./63e7d3d2e4c75abee840f38e.mjs";
import { childFrameCount, childFrameDuration, frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
export function newSpawnFrame() {
    return {
        d00: 0,
        w04: 0,
        x: 0,
        y: 0,
        b18: 0,
        d1c: 0,
        b20: 0,
        b21: 0,
        d24: 0,
        d28: 0,
        b2c: 0,
        d30: 0,
        clip: [
            0,
            0,
            0,
            0
        ]
    };
}
export function resetSpawnFrame(f) {
    f.d00 = 0;
    f.b20 = 0;
    f.b2c = 0xff;
    f.d24 = 0;
    f.d28 = 0;
    f.d30 = 0;
    f.clip = [
        0,
        0,
        0,
        0
    ];
}
export function openSpawnFrame() {
    const f = newSpawnFrame();
    resetSpawnFrame(f);
    return f;
}
export function frameEffect(f) {
    spawnEffect({
        owner: f.d00,
        pat: f.w04,
        x: f.x,
        y: f.y,
        b18: f.b18,
        mirror: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        sound: f.b2c
    });
}
export function frameChild(c, f) {
    return c.spawnChild({
        type: f.d00,
        pattern: f.w04,
        x: f.x,
        y: f.y,
        facing: f.b18,
        d4c: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        shadow: f.d28,
        b6c: f.b2c,
        moveWhileFrozen: f.d30,
        clip: [
            ...f.clip
        ]
    });
}
export const childSpawnFrame = newSpawnFrame();
export let childDuration = 0;
export let childCount = 0;
let walkAborted = false;
export function abortChildWalk() {
    walkAborted = true;
}
export function updateChildrenKaori(c) {
    if (c.opponent.freeze > 0) return;
    let i = c.childTail;
    Object.assign(childSpawnFrame, newSpawnFrame());
    walkAborted = false;
    while(i !== c.childHead){
        const ch = c.children[i];
        if (c.childActive[i] !== 0 && ch.hitstop === 0) {
            let run = true;
            if (c.freeze !== 0) {
                if (c.freeze <= 0 || ch.moveWhileFrozen === 0) run = false;
            }
            if (run) {
                childDuration = childFrameDuration(c, i);
                childCount = childFrameCount(c, i);
                resetSpawnFrame(childSpawnFrame);
                const k = ch.pattern - 400;
                if (k >= 0 && k <= 0x63) {
                    const handler = childHandlers.get(ch.pattern);
                    handler?.(c, i);
                    if (walkAborted) return;
                }
            }
        }
        i++;
        if (i >= 64) i = 0;
    }
}
const w16 = (v)=>v & 0xffff;
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function startStill(c) {
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
}
function rfCost(c) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
}
function effect21(f, c) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = ftol(c.x);
    f.y = ftol(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function decelPositive(c, dec) {
    if (c.vx > 0.0) c.vx = c.vx - dec;
    if (c.vx < 0.0) c.vx = 0.0;
}
function endResetFace(c, end) {
    c.onStateChange();
    c.faceOpponent();
    c.state = end;
}
function state248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 249;
        o.state = 100;
        const f = openSpawnFrame();
        f.w04 = 0;
        f.x = ftol(c.x) + c.facing * 0x2e;
        f.y = ftol(c.y) - 0x46;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        o.x = c.facing * 0x2e + c.x;
        o.y = c.y - 70.0;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) {
            c.w16c = 1;
        } else {
            c.w16c = 0;
        }
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 209;
            c.frame = 2;
        }
    }
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 5) c.biasCamera(0x32, 3);
    if (c.frame < 5) c.biasCameraY(0x32, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 7) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.state = 13;
        return;
    }
    if (c.frame === 3 && c.timer === 0) {
        o.y = c.y - 27.0;
        o.x = c.facing * 0x36 + c.x;
        o.state = 69;
        applyDirectDamage(c, 0x578, 500.0);
        o.onStateChange();
        const f = openSpawnFrame();
        f.w04 = 0;
        f.x = ftol(c.x) + c.facing * 0x36;
        f.y = ftol(c.y) - 0x1b;
        f.b2c = 2;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        o.knockX = -3.0;
        o.knockY = 3.0;
    }
    if (c.frame === 5 && c.timer === 0) c.ay = 0.035;
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function rush(c, vx0) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    startStill(c);
    if (c.frame === 2 && c.timer === 0) c.vx = vx0;
    decelPositive(c, 0.05);
    if (c.frame > 4 && c.frame < 7) {
        if (c.pressed[0] === 1) {
            c.onStateChange();
            c.state = 259;
            return;
        }
        if (c.pressed[1] === 1) {
            c.onStateChange();
            c.state = 263;
            return;
        }
        if (c.pressed[2] === 1) {
            c.onStateChange();
            c.state = 260;
            if (c.inputY > 0) c.state = 261;
            return;
        }
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state250(c) {
    rush(c, 2.5);
}
function state251(c) {
    rush(c, 4.0);
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    startStill(c);
    if (c.frame === 6 && c.timer === 0) {
        addMeter(c, 0x2d);
        c.w16c = 1;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame < 6) c.d168 = 0;
        if (c.frame === 11) {
            if (c.d168 === 3) {
                c.w16c = 1;
                c.d168 = 0;
            } else {
                c.frame = 15;
            }
        }
        if (c.frame >= cnt) endResetFace(c, 0);
    }
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    startStill(c);
    if (c.frame === 4 && c.timer === 0) c.vx = 2.1;
    decelPositive(c, 0.03);
    if (c.frame === 6 && c.timer === 0) {
        addMeter(c, 0x2d);
        c.w16c = 1;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame < 6) c.d168 = 0;
        if (c.frame === 11) {
            c.w16c = 1;
            c.d168 = 0;
        }
        if (c.frame >= cnt) endResetFace(c, 0);
    }
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        rfCost(c);
        effect21(f, c);
    }
    if (c.frame === 4 && c.timer === 0) c.vx = 2.0;
    decelPositive(c, 0.04);
    if (c.frame === 6 && c.timer === 0) {
        addMeter(c, 0x2d);
        c.w16c = 1;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame < 6) c.d168 = 0;
        if (c.frame === 11) {
            if (c.d168 === 3) {
                c.w16c = 1;
                c.d168 = 0;
            } else {
                c.frame = 15;
            }
        }
        if (c.frame >= cnt) endResetFace(c, 0);
    }
}
function beam(c, f, pattern, hits, loops) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 3 && c.timer === 0) {
        f.w04 = pattern;
        f.x = ftol(c.x) + c.facing * 0x28;
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.w16c = hits;
        addMeter(c, 0x23);
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        c.d168 = 0;
        if (c.frame === 8 && c.f3138 < loops) {
            c.frame = w16(c.frame - 1);
            c.f3138 = c.f3138 + 1;
        }
        if (c.frame >= cnt) endResetFace(c, 0);
    }
}
function state256(c) {
    const f = openSpawnFrame();
    startStill(c);
    beam(c, f, 0x19a, 0, 6);
}
function state257(c) {
    const f = openSpawnFrame();
    startStill(c);
    beam(c, f, 0x190, 10, 10);
}
function state258(c) {
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        rfCost(c);
        effect21(f, c);
    }
    beam(c, f, 0x19b, 1, 7);
}
function followAdvance(c, dur, cnt, end) {
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endResetFace(c, end);
    }
}
function hitAt(c, n, se) {
    if (c.frame === n && c.timer === 0) {
        c.seRequest = se;
        c.w16c = 1;
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.1;
    if (c.vx < 0.0) c.vx = 0.0;
    hitAt(c, 2, 0x15);
    followAdvance(c, dur, cnt, 0);
}
function state260(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame < 5) c.vx = c.vx - 0.1;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame === 5 && c.timer === 0) {
        c.seRequest = 0x15;
        c.w16c = 1;
        c.vx = 3.5;
    }
    if (c.frame > 4) c.vx = c.vx - 0.07;
    followAdvance(c, dur, cnt, 0);
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.05;
    if (c.vx < 0.0) c.vx = 0.0;
    hitAt(c, 5, 0x15);
    followAdvance(c, dur, cnt, 3);
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.05;
    if (c.vx < 0.0) c.vx = 0.0;
    hitAt(c, 5, 0x15);
    followAdvance(c, dur, cnt, 0);
}
function state263(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.1;
    if (c.vx < 0.0) c.vx = 0.0;
    hitAt(c, 2, 0x15);
    hitAt(c, 7, 0x14);
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 2 || c.frame === 7) c.d168 = 0;
        if (c.frame >= cnt) endResetFace(c, 0);
    }
}
function child400(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (c.state !== 0x100 && c.state !== 0x101 && c.state !== 0x102 && ch.frame < 0x3e) ch.frame = 0x3e;
    if (ch.frame < 0x3e) ch.x = c.facing * 0x28 + c.x;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child410(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0) ch.hitsLeft = 0xf;
    ch.timer = w16(ch.timer + 1);
    if (c.state !== 0x100 && ch.frame < 0x3e) ch.frame = 0x3e;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        if (ch.frame === 0x1e) ch.frame = 0x3e;
        const fr = ch.frame;
        if (fr === 1 || fr === 8 || fr === 0xb || fr === 0xe || fr === 0x11 || fr === 0x14 || fr === 0x17 || fr === 0x1a || fr === 0x1d) {
            ch.hitState = 0;
        }
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child411(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.frame < 0x3e) ch.x = c.facing * 0x28 + c.x;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame === 0x1e) ch.frame = 0x3e;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
registerStates({
    248: state248,
    249: state249,
    250: state250,
    251: state251,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263
});
registerChildren({
    400: child400,
    410: child410,
    411: child411
});

export function __logicState(){return {childSpawnFrame,childDuration,childCount,walkAborted};}

export function __installInitialRoots(s){
if(childSpawnFrame!==s["childSpawnFrame"])throw Error('INITIAL_CONST_IDENTITY:childSpawnFrame');
childDuration=s["childDuration"];
childCount=s["childCount"];
walkAborted=s["walkAborted"];
}
