import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k, n = 100) {
    const r = rnd(c, 0, n);
    return k * c.aiLevel > r;
}
function s8(v) {
    return v << 24 >> 24;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = s8(rnd(c, 0, 2) - 1);
}
export function thinkAkiko(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 0xaa ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 0x95 && c.state < 0x9d ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking * 2000 + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40 * c.aiLevel > r && c.state > 0xc7) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 0xc8) c.aiMode = 0;
        return;
    }
    if (o.state === 0x60) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 0x32 && c.state <= 0x96 && c.timer === 0) {
        c.aiMode = 8 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 0x32 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 0xf0) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 0x140) < dx ? 1 : 0;
        if (o.state > 0xc7 && o.state < 0xfa && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 0xa && c.state <= 0xc) && c.y === 0.0) return;
    if (o.state >= 0x32 && o.state < 0x96 && c.state === 0x108 && c.w16c > 1) return;
    if (c.state === 0xa8 && c.timer < 6) {
        if (o.state !== 0xc8 && o.state !== 0xcc && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx < 40.0 && chance(c, 3)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && chance(c, 3)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
        }
        if ((o.state === 0xc9 || o.state === 0xca || o.state === 0xcd) && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx > 40.0 && dx < 80.0 && chance(c, 3)) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (dx > 80.0 && dx < 140.0 && chance(c, 3, 300)) {
                c.command = 0x15;
                return;
            }
        }
    }
    if (c.state === 0xa8 || c.state === 0xa9) {
        if (dx < 100.0) {
            if (chance(c, 3, 300) && c.rfGauge > 500.0) {
                c.command = 0x14;
                return;
            }
            const g = c.rfGauge > 500.0 ? 1 : 0;
            if (3 * c.aiLevel + g * 2 > rnd(c, 0, 300)) {
                c.command = 0x15;
                return;
            }
            if (chance(c, 4, 500) && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 3) + 0x6e;
                return;
            }
        }
        if (dx < 160.0 && chance(c, 3)) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return;
        }
        if (dx > 220.0 && chance(c, 2)) {
            c.command = rnd(c, 0, 3) + 0xa;
            return;
        }
        if (dx > 180.0 && chance(c, 5)) {
            c.command = rnd(c, 0, 3) + 0x46;
            return;
        }
    }
    if (c.state === 0xaa && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y > 0.0 && c.y - o.y < 40.0 && dx < 80.0 && chance(c, 5)) {
            c.pressed[0] = 1;
            return;
        }
        if (c.y - o.y > -70.0 && c.y - o.y < 70.0 && dx < 130.0 && chance(c, 5)) {
            c.pressed[1] = 1;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y === 0.0 && 15 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3) {
            c.command = 0x15;
            return;
        }
        if (c.aiRoll < 4) {
            c.command = 0x14;
            return;
        }
        if (c.aiRoll < 0x11 && c.aiRoll > 0xc && c.meter >= 0x3e8) {
            c.command = rnd(c, 0, 3) * 0x6e & 0xffff;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y < 0.0 && 15 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 0x14) {
            c.aiMode = 2;
            return;
        }
        if (dx < 100.0 && c.aiRoll < 0x16) {
            c.command = 0x16;
            return;
        }
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 8 * c.aiLevel > rnd(c, 0, 100) && o.state > 0x95 && o.state < 0x9d && (c.state === 0xfa || c.state === 0xfb || c.state === 0x104 || c.state === 0x105 || c.state === 0x106 || c.state === 0x132 || c.state === 0x133 || c.state === 0x134 || c.state === 0x13b || c.state === 0x13c || c.state === 0x13d)) {
        c.command = 0x34;
        return;
    }
    if (c.aiMode > 0 && c.state > 0x31 && c.state < 0x9e) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 0xc8) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = s8(rnd(c, 0, 2) - 1);
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = c.facing === 1 ? 1 : 0;
            if (c.state === 0xa5) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 0x32) {
        c.aiMode = 6;
        return;
    }
    if (c.aiMode === 6 && c.state === 9) {
        c.aiMode = 0;
        c.pressed[1] = 1;
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && 25 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.state > 0xfc && c.state < 0x103 && c.aiRoll < 0xfa) {
            c.command = rnd(c, 0, 3) + 0x14;
            return;
        }
        if (c.state === 0xc8) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 80.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                c.inputY = 0;
                if (c.d168 === 2 && rnd(c, 0, 100) < 0x14) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                }
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x18f && c.aiRoll < 0x2bc) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 4) === 0) c.aiMode = 5;
                return;
            }
        }
        if (c.state === 0xc9) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x15;
                return;
            }
            if (c.aiRoll < 0x12c) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll < 0x15e) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x258) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x398) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x1f3) {
                c.aiMode = 1;
                if (rnd(c, 0, 3) === 0) c.aiMode = 5;
                return;
            }
        }
        if (c.state === 0xca) {
            if (o.y < 0.0 && c.aiRoll < 0x64 && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x15;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0xc7 && c.aiRoll < 0x190) {
                c.command = 0x1f;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x18f && c.aiRoll < 0x1f4 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 2) + 0x64;
                return;
            }
            if (c.aiRoll < (c.d168 === 3 ? 1 : 0) * 0xc8 + 0xc8) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll < 0x1f4 && c.d168 === 3 && dx < 100.0) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x1f3 && c.aiRoll < 0x226) {
                c.command = rnd(c, 0, 2) + 0xa;
                return;
            }
            if (c.aiRoll > 0x225 && c.aiRoll < 0x23a && c.rfGauge > 500.0) {
                c.command = 0xc;
                return;
            }
            if (c.aiRoll > 0x257 && c.aiRoll < 0x28a) {
                c.command = 0x46;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcb) {
            if (o.y < 0.0 && c.aiRoll < 0x96 && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x15;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < (c.d168 === 3 ? 1 : 0) * 0xc8 + 0x64 && (c.rfGauge > 500.0 || c.d168 === 3)) {
                c.command = rnd(c, 0, 2) + 0xa;
                return;
            }
            if (c.aiRoll > 0x64 && c.aiRoll < 0x78) {
                c.command = 0x1e;
                return;
            }
            if (c.aiRoll > 0x78 && c.aiRoll < 0x96) {
                c.command = 0x46;
                return;
            }
            if (c.aiRoll > 0xfa && c.aiRoll < 0x190 && c.d168 === 3 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 3) + 0x64;
                return;
            }
            if (c.aiRoll > 0x190 && c.aiRoll < 0x1cc && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 2) + 0x64;
                return;
            }
            if (c.aiRoll > 0x1cc && c.aiRoll < 0x1e0 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 2) + 0x78;
                return;
            }
            if (c.aiRoll > 0x38e) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x225) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcc) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 80.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                c.inputY = 0;
                if (c.d168 === 2 && rnd(c, 0, 100) < 0x14) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                }
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x18f && c.aiRoll < 0x2bc) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 4) === 0) c.aiMode = 5;
                return;
            }
        }
        if (c.state === 0xcd) {
            if (c.aiRoll < 0x96 && c.d168 === 3 && dx < 100.0) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll < (c.d168 === 3 ? 1 : 0) * 0xc8 + 0x12c) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xce) {
            if (o.y < 0.0 && c.aiRoll < 0xc8 && c.d168 === 3) {
                c.command = 0x15;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < (c.d168 === 3 ? 1 : 0) * 0xc8 + 0x64 && (c.rfGauge > 500.0 || c.d168 === 3)) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x64 && c.aiRoll < 0x96) {
                c.command = 0x1e;
                return;
            }
            if (c.aiRoll > 0x96 && c.aiRoll < 0xc8) {
                c.command = rnd(c, 0, 2) + 0x1f;
                return;
            }
            if (c.aiRoll > 0x96 && c.aiRoll < 0xc8) {
                c.command = rnd(c, 0, 3) + 0x46;
                return;
            }
            if (c.aiRoll > 0xc8 && c.aiRoll < 0xfa && c.rfGauge > 500.0) {
                c.command = 0x34;
                return;
            }
            if (dx < 100.0 && c.aiRoll > 0xfa && c.aiRoll < 0x104 && c.d168 === 3 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 3) + 0x6e;
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcf) {
            if (c.aiRoll < 0x15e) {
                c.pressed[1] = 1;
                return;
            }
            if (dx < 60.0 && c.aiRoll < 0x1c2) {
                c.pressed[0] = 1;
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x18f && c.aiRoll < 0x1f4) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 4) === 0) c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd0) {
            if (c.aiRoll > 0x3c && c.aiRoll < 0x64) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd1 && c.aiRoll > 0x289) {
            c.aiMode = 3;
            return;
        }
    }
    if (25 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 0x63) {
                if (dx < 40.0 && o.y === 0.0 && c.aiRoll < 5) {
                    c.pressed[2] = 1;
                    c.inputX = s8(-c.facing);
                    c.inputY = 0;
                    return;
                }
                if (dx < 45.0 && c.aiRoll < 0x14) {
                    c.pressed[0] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 60.0 && c.aiRoll < 0x1e) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 140.0 && dx > 100.0 && c.aiRoll < 0xf) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 120.0 && c.aiRoll < 0x14) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 120.0 && dx > 80.0 && c.aiRoll < 0x28 && c.aiRoll > 0x25) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 100.0 && dx > 80.0 && c.aiRoll < 0x25) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 150.0 && dx > 80.0 && c.aiRoll < 0x2a && c.aiRoll > 0x28) {
                    c.command = 0x1e;
                    return;
                }
                if (c.aiRoll < 0x37 && c.aiRoll > 0x2a) {
                    c.command = c.facing & 0xffff;
                    c.aiMode = 5;
                    return;
                }
                if (dx > 140.0 && c.aiRoll < 0x3c && c.aiRoll > 0x37) {
                    c.command = rnd(c, 0, 3) + 0x46;
                    return;
                }
                if (dx > 120.0 && c.aiRoll < 0x42 && c.aiRoll > 0x3c) {
                    c.command = rnd(c, 0, 3) + 0xa;
                    return;
                }
                if (dx > 180.0 && c.meter >= 0xbb8 && c.aiRoll < 0x44 && c.aiRoll > 0x42) {
                    c.command = 0xc1;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < 0xa) {
                        c.inputY = -1;
                        c.inputX = s8(-c.facing);
                        return;
                    }
                    if (dx > 100.0 && dx < 150.0 && c.aiRoll < 0xf) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < 0x11 && c.meter >= 0x7d0) {
                        c.command = rnd(c, 0, 1) + 0x79;
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 40.0 && dy < 120.0 && c.aiRoll < (c.rfGauge > 500.0 || c.rfBlue > 0 ? 1 : 0) * 5 + 6) {
                        c.command = 0x15;
                        return;
                    }
                    if (dx > 100.0 && dx < 150.0 && o.y < -60.0 && c.aiRoll < 0x14) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx < 50.0 && dy < 60.0 && c.aiRoll < 0x11 && c.meter >= 0x3e8) {
                        c.command = rnd(c, 0, 3) + 0x6e;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 70.0 && dy < 100.0 && c.aiRoll < (o.y === 0.0 ? 1 : 0) * 0x64 + 0x64) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 80.0 && dy > 60.0 && dy < 80.0 && c.vy > 0.0 && o.y > c.y && c.aiRoll > 0xc8 && c.aiRoll < 0xdc) {
                    c.pressed[2] = 1;
                    return;
                }
                if (dx < 80.0 && dy > 140.0 && o.y > c.y && c.aiRoll < 0xa) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                    c.inputX = 0;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 140.0 && dy > 60.0 && c.aiRoll < 0xfa) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 120.0 && dy < 90.0 && o.y > c.y && c.aiRoll < 0x10e) {
                    c.pressed[2] = 1;
                    return;
                }
                if (dx < 140.0 && dy > 60.0 && c.aiRoll < 0x15e) {
                    c.pressed[0] = 1;
                    return;
                }
            }
        }
    }
    if (c.state < 0x32 && (o.state > 0x95 && o.state < 0x9c || o.state > 0x31 && o.state < 0x3b) && c.y === 0.0 && 1 * c.aiLevel > rnd(c, 0, 100)) {
        if (dx < 100.0) c.command = c.facing === 1 ? 1 : 0;
        return;
    }
    if (rnd(c, 0, 1000) < 2) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 240.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 80.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 140.0 && dx > 100.0 && c.y === 0.0) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 0xf) c.aiTimer1a0 = 0xf;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 0xf) c.aiTimer1a4 = 0xf;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 0x28 && dx < 60.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x1e;
        else c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x1e;
    }
    if (rnd(c, 0, 100) < 0x50) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x1e;
        else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x1e;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x1e;
    else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x1e;
}
