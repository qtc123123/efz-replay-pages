import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./4f243a87eb42ac119eae883d.mjs";
import { abortChildWalk, childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./8a0ae749d7e9ba4d08c1d570.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function superEffect(d, c, pat, sound, dx, dy) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function holdOpponent(c, state, ox, oy, face) {
    const o = c.opponent;
    o.state = state;
    o.x = (ox + c.vx) * c.facing + c.x;
    o.y = oy + c.vy + c.y;
    if (face === 1) o.facing = c.facing;
    if (face === -1) o.facing = -c.facing;
}
function holdOpponentFront(c) {
    const o = c.opponent;
    o.state = 0x67;
    o.x = c.facing * 0x16 + c.x;
    o.y = c.y - 52.0;
}
function clampX(c) {
    if (c.x > 580.0) {
        c.x = 580.0;
        c.vx = 0.0;
    }
    if (c.x < 60.0) {
        c.x = 60.0;
        c.vx = 0.0;
    }
}
function hitSpark(d, c, sound) {
    d.w04 = 0;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b2c = sound;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
}
function leap305(c) {
    const k = c.x > 320.0 ? 1 : 0;
    c.vx = (1 - (k << 1)) * 0.6 * c.facing;
    c.vy = -5.0;
    c.ay = 0.06;
}
function state303(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.stopMotion();
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40, 0, 0x28);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (c.frame > 1) c.showAltBackground(0xf);
    if (c.frame < 3) c.biasCameraY(0x32, 3);
    if (c.frame === 6 && c.d168 === 3) {
        o.onStateChange();
        o.stopMotion();
        o.state = 0x6b;
        c.onStateChange();
        c.stopMotion();
        c.state = 0x131;
        c.y = c.pointsY[0] + 0x32;
        c.x = (-c.pointsX[0] - 0x14) * c.facing + o.x;
        d.w04 = 0;
        d.x = ftol(o.x) + c.pointsX[0];
        d.y = ftol(o.y) + c.pointsY[0];
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (c.frame > 2 && c.frame < 7) c.vy += c.ay;
    if (c.frame === 6 && c.y + c.vy > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 7;
        return;
    }
    if (c.frame === 6 && !(o.y < 0.0)) c.w16c = 1;
    else c.w16c = 0;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 3) {
        c.vx = 1.5;
        c.vy = -2.0;
        c.ay = 0.045;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state304(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.stopMotion();
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40, 0, 0x28);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    c.showAltBackground(0xf);
    if (c.frame < 3) c.biasCameraY(0x32, 3);
    if (c.frame === 4 && c.d168 === 3) {
        o.onStateChange();
        o.stopMotion();
        o.state = 0x6b;
        c.onStateChange();
        c.stopMotion();
        c.state = 0x132;
        o.hitstop = 0x78;
        o.x = c.facing * 0x1e + c.x;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x2c;
        d.y = ftol(c.y) - 7;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 4 && !(o.y < 0.0)) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state305(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.biasCamera(0x32, 3);
    c.biasCameraY(0x32, 3);
    c.showAltBackground(0xf);
    if (c.frame > 3) c.vy += c.ay;
    if (c.frame === 4) {
        o.w140 = 0x7530;
        holdOpponent(c, 0x67, 23.0, -52.0, 0);
    }
    if (c.frame === 5) holdOpponent(c, 0x67, 15.0, -70.0, 0);
    if (c.frame === 6) holdOpponent(c, 0x76, -31.0, -65.0, 1);
    if (c.frame === 7) holdOpponent(c, 0x75, -36.0, -32.0, 1);
    if (c.frame === 8) holdOpponent(c, 0x68, -7.0, -8.0, -1);
    if (c.frame === 9 || c.frame === 10) holdOpponent(c, 0x68, -4.0, -6.0, -1);
    if (c.frame > 8 && c.vy + c.y > 0.0) {
        c.stopMotion();
        c.onStateChange();
        o.stopMotion();
        o.onStateChange();
        o.state = 0x62;
        o.y = 0.0;
        o.x = c.x;
        c.y = 0.0;
        c.state = 0x133;
        applyDirectDamage(c, 0x3e8, 960.0);
        hitSpark(d, c, 2);
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 4) leap305(c);
    if (c.frame >= cnt) c.frame -= 2;
}
function state306(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.biasCamera(0x32, 3);
    c.biasCameraY(0x32, 3);
    c.showAltBackground(0xf);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.onStateChange();
        c.state = 0x131;
        c.frame = 4;
        c.opponent.hitstop = 0;
        leap305(c);
    }
}
function state307(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    o.biasCameraY(0x32, 3);
    c.showAltBackground(0xf);
    c.w13e = 2;
    if (o.state === 0x63) o.timer = 0;
    if (c.f3138 > 0x78 && c.f3138 < 0x2d0 && c.frame > 5 && c.frame < 0xc && (c.random(0, 0x64) & 0xffff) < 5) {
        d.w04 = 0x195;
        const bx = c.x + 80.0;
        d.x = bx - (c.random(0, 0xa0) & 0xffff);
        d.y = 0 - (c.random(0, 0x32) & 0xffff);
        d.b20 = 0;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.frame > 3) c.vy += c.ay;
    if (c.frame > 5) c.f3138++;
    if (c.f3138 === 0x50) {
        d.w04 = 0x191;
        d.x = ftol(c.x) + c.facing * 0x1e;
        d.y = -320.0;
        d.b20 = 0;
        d.b21 = 1;
        d.d00 = 1;
        d.d28 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.f3138 === 0x78) {
        d.w04 = 0x192;
        d.x = ftol(c.x) - c.facing * 0x14;
        d.y = -320.0;
        d.b20 = 0;
        d.b21 = 1;
        d.d28 = 1;
        d.b18 = c.facing;
        d.d00 = 1;
        frameChild(c, d);
    }
    if (c.frame === 9 && c.vy + c.y > 0.0) {
        c.stopMotion();
        c.timer = 0;
        c.frame = 0xa;
        o.stopMotion();
        o.onStateChange();
        o.state = 0x62;
        c.y = 0.0;
        o.w140 = 0x7530;
        applyDirectDamage(c, 0x12c, 960.0);
        hitSpark(d, c, 2);
        return;
    }
    if (c.frame === 0xf && c.vy + c.y > 0.0) {
        c.stopMotion();
        c.timer = 0;
        c.frame = 0x10;
        o.stopMotion();
        o.onStateChange();
        o.state = 0x62;
        c.y = 0.0;
        applyDirectDamage(c, 0x578, 960.0);
        o.w140 = 0;
        c.shakeScreen(0xa, 0xa);
        o.hitstop = 0x78;
        hitSpark(d, c, 0x16);
        return;
    }
    if (c.frame === 0x14 && c.vy + c.y > 0.0) {
        c.stopMotion();
        c.timer = 0;
        c.frame = 0x15;
        o.stopMotion();
        o.onStateChange();
        c.y = 0.0;
        return;
    }
    if (c.frame === 0xb && c.f3138 > 0x334) {
        c.frame = 0xc;
        c.timer = 0;
        c.vy = -5.0;
        c.ay = 0.06;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 6) {
        c.vx = 0.0;
        c.vy = -3.9;
        c.ay = 0.08;
    }
    if (c.frame === 0xc) {
        if (c.f3138 > 0x2da) {
            c.frame = 0xb;
        } else {
            c.frame = 6;
            c.vx = 0.0;
            c.vy = -3.9;
            c.ay = 0.08;
        }
    }
    if (c.frame === 0x12) {
        c.vx = -0.6;
        c.vy = -1.5;
        c.ay = 0.038;
    }
    if (c.frame === 0x1f && c.f313c < 4) {
        c.frame -= 2;
        c.f313c++;
    }
    if (c.frame >= cnt) {
        c.onStateChange();
        c.state = 0;
        c.faceOpponent();
    }
}
function dashGrab(c, cost, pat, sound, w13c, loopMax, next, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.stopMotion();
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, 0, 0x28);
        if (big) c.seRequest = 0x25;
    }
    if (big) c.showAltBackground(0xf);
    if (c.frame < 3) c.biasCameraY(0x32, 3);
    if ((c.frame === 3 || c.frame === 4) && c.d168 === 3) {
        clampX(c);
        o.onStateChange();
        o.stopMotion();
        holdOpponentFront(c);
        c.onStateChange();
        c.ay = 0.025;
        c.state = next;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x2c;
        d.y = ftol(c.y) - 0x2c;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (big) {
        if (c.frame > 6) c.vx -= 0.025;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame > 4 && c.frame < 0x70) c.vy += c.ay;
    if (c.frame < 0xc && c.y + c.vy > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 0xc;
        return;
    }
    if (!big) {
        if (c.frame > 6) c.vx -= 0.025;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if ((c.frame === 3 || c.frame === 4) && o.y < 0.0) c.w16c = 1;
    else c.w16c = 0;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 3) {
        c.vx = 2.0;
        c.vy = -3.2;
        c.ay = 0.035;
        c.w13c = w13c;
    }
    if (c.frame === 5 && c.f3138 < loopMax) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame === 6) c.vy *= 0.5;
    if (c.frame === 0xc) c.frame -= 4;
    if (c.frame >= cnt) {
        c.state = 3;
        c.faceOpponent();
        c.onStateChange();
    }
}
function holdThrowFrame(c, f) {
    if (f === 4) holdOpponent(c, 0x67, 15.0, -70.0, 0);
    if (f === 5) holdOpponent(c, 0x76, -25.0, -65.0, 1);
    if (f === 6) holdOpponent(c, 0x75, -28.0, -43.0, 1);
    if (f === 7) holdOpponent(c, 0x75, -12.0, -29.0, 1);
    if (f === 8) holdOpponent(c, 0x68, 12.0, -23.0, -1);
    if (f === 9) holdOpponent(c, 0x68, 23.0, -36.0, -1);
    if (f === 10) holdOpponent(c, 0x67, 28.0, -58.0, -1);
    if (f === 11) holdOpponent(c, 0x67, 14.0, -73.0, -1);
    if (f === 12) holdOpponent(c, 0x76, -12.0, -78.0, 1);
}
function slamOpponent(c) {
    const o = c.opponent;
    o.onStateChange();
    o.state = 0x62;
    o.y = 0.0;
}
function state311(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.w13e = 2;
    if (c.frame < 0xe) {
        clampX(c);
        c.biasCamera(0x32, 3);
        c.biasCameraY(0x32, 3);
    }
    if (c.frame < 0xd || c.frame > 0xe && c.frame < 0x12) {
        c.vy += c.ay;
        if (c.vy + c.y > 0.0) {
            if (c.frame < 0xd) {
                c.y = 0.0;
                c.stopMotion();
                slamOpponent(c);
                o.x = c.facing + c.x;
                o.facing = -c.facing;
                o.stopMotion();
                o.hitstop = 0x7e;
                applyDirectDamage(c, 0x92e, 750.0);
                c.shakeScreen(0xa, 0);
                c.timer = 0;
                c.frame = 0xd;
                c.seRequest = 0x16;
                return;
            }
            if (c.frame === 0x11) {
                c.y = 0.0;
                c.stopMotion();
                c.timer = 0;
                c.frame = 0x12;
                return;
            }
        }
    }
    if (c.frame < 0xd) {
        c.vx -= 0.025;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame < 4) holdOpponentFront(c);
    holdThrowFrame(c, c.frame);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 0xd) c.frame -= 8;
    if (c.frame === 0xf) {
        o.hitstop = 3;
        c.vx = -1.2;
        c.vy = -2.0;
        c.ay = 0.035;
        o.y = -1.0;
        o.onStateChange();
        o.stopMotion();
        o.knockX = -1.2;
        o.knockY = -2.0;
        o.state = 0x3b;
    }
    if (c.frame >= cnt) {
        c.onStateChange();
        c.faceOpponent();
        c.state = 3;
    }
}
function doubleThrow(c, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.w13e = 2;
    if (big) c.showAltBackground(0xf);
    if (c.frame < 0x19) {
        clampX(c);
        c.biasCamera(0x32, 3);
        c.biasCameraY(0x32, 3);
    }
    if (c.frame < 0xd || c.frame > 0xe && c.frame < 0x19 || c.frame > 0x1a && c.frame < 0x1e) {
        c.vy += c.ay;
        if (c.vy + c.y > 0.0) {
            if (c.frame < 0xd) {
                c.y = 0.0;
                c.stopMotion();
                slamOpponent(c);
                o.stopMotion();
                o.hitstop = 0x96;
                o.x = c.facing + c.x;
                o.facing = -c.facing;
                applyDirectDamage(c, 0x3e8, 980.0);
                c.shakeScreen(0xa, 0);
                o.w140 = 0x7530;
                c.timer = 0;
                c.frame = 0xd;
                c.seRequest = 0x16;
                return;
            }
            if (c.frame > 0xe && c.frame < 0x19) {
                c.y = 0.0;
                c.stopMotion();
                slamOpponent(c);
                o.x = c.facing + c.x;
                o.facing = -c.facing;
                o.stopMotion();
                if (big) {
                    o.hitstop = 0xba;
                    applyDirectDamage(c, 0xed8, 980.0);
                    o.w140 = 0;
                    c.shakeScreen(0x14, 0x1e);
                } else {
                    o.hitstop = 0x7e;
                    c.shakeScreen(0xf, 0);
                    applyDirectDamage(c, 0x834, 980.0);
                    o.w140 = 0;
                }
                c.timer = 0;
                c.frame = 0x19;
                c.seRequest = 0x16;
                return;
            }
            if (c.frame === 0x1d) {
                c.y = 0.0;
                c.stopMotion();
                c.timer = 0;
                c.frame = 0x1e;
                return;
            }
        }
    }
    if (c.frame < 0xd) {
        c.vx -= 0.025;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame > 0xe && c.frame < 0x19) {
        c.vx += 0.025;
        if (c.vx > 0.0) c.vx = 0.0;
    }
    if (c.frame < 4) holdOpponentFront(c);
    if (c.frame === 4 || c.frame === 0xf || c.frame === 0x10) holdThrowFrame(c, 4);
    if (c.frame >= 0x11 && c.frame <= 0x18) holdThrowFrame(c, c.frame - 12);
    else if (c.frame >= 5 && c.frame <= 0xc) holdThrowFrame(c, c.frame);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 0xd || c.frame === 0x19) c.frame -= 8;
    if (c.frame === 0xf) {
        c.vx = -4.0;
        c.vy = big ? -7.0 : -4.0;
        c.ay = 0.025;
        o.hitstop = 3;
    }
    if (c.frame === 0x1b) {
        c.vx = -1.8;
        c.vy = -2.3;
        c.ay = 0.035;
        o.onStateChange();
        o.stopMotion();
        o.knockX = -1.8;
        o.knockY = -2.3;
        o.state = 0x3b;
    }
    if (c.frame >= cnt) {
        c.onStateChange();
        c.faceOpponent();
        c.state = 3;
    }
}
function steerSuper(c, cost, pat, sound, w16c, maxV, loopMax, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (big && c.frame > 0) c.showAltBackground(0xf);
    if (c.frame === 1 && c.timer === 0) {
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, 0xf, 0x22);
        c.biasCameraY(0x32, 0x78);
        c.w16c = w16c;
        if (big) c.seRequest = 0x25;
    }
    if (c.timer === 0 && (c.frame === 9 || c.frame === 0xb || c.frame === 0xd || c.frame === 0xf)) c.seRequest = 0x15;
    if (c.frame > 7 && c.frame < 0x10) {
        if (c.inputX === c.facing) c.vx += 0.012;
        if (c.inputX === -c.facing) c.vx -= 0.012;
        if (c.vx < -maxV) c.vx = -maxV;
        else if (c.vx > maxV) c.vx = maxV;
    }
    if (c.frame > 0xf) {
        if (c.vx > 0.0) {
            c.vx -= 0.01;
            if (c.vx < 0.0) c.vx = 0.0;
        }
        if (c.vx < 0.0) {
            c.vx += 0.01;
            if (c.vx > 0.0) c.vx = 0.0;
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 0x10 && c.f3138 < loopMax) {
        c.frame -= 4;
        c.f3138++;
    }
    if (c.frame === 1 || c.frame === 9 || c.frame === 0xb || c.frame === 0xd || c.frame === 0xf || c.frame === 0x10) c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function rushSuper(c, cost, pat, sound, dashVx, loopMax, next, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (big) c.showAltBackground(0xf);
    if (atStart(c)) {
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, 0, 0x28);
        c.w16c = 1;
        c.biasCameraY(0x32, 0x78);
        if (big) c.seRequest = 0x25;
    }
    if (c.frame > 0xd && c.frame < 0x12 && c.d168 === 3) {
        c.onStateChange();
        c.stopMotion();
        o.stopMotion();
        o.hitstop = 0xb4;
        o.y = 0.0;
        o.state = 0x49;
        o.x = c.facing * 0x1e + c.x;
        c.state = next;
        o.facing = -c.facing;
        return;
    }
    if (c.vx > 0.0) c.vx -= 0.035;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.d168 > 0 && c.frame < 0x12 && c.frame > 0xd) {
        c.timer = 0;
        c.frame = 0x12;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 0xe) c.vx = dashVx;
    if (c.frame === 0x12 && c.f3138 < loopMax) {
        c.f3138++;
        c.frame -= 4;
    }
    if (c.frame >= cnt) {
        c.state = 3;
        c.onStateChange();
    }
}
function comboSuper(c, landFrom, landTo, loop15Max, jumpFrame, jumpVy, jumpVx, jumpW16c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.w16c = 0x63;
    if ((c.frame === 5 || c.frame === 0xa) && c.timer === 0) c.seRequest = 0x15;
    if (c.vx > 0.0) c.vx -= 0.035;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.y < 0.0) {
        c.ay = 0.055;
        c.vy += c.ay;
    }
    if (c.frame > landFrom && c.frame < landTo && c.y + c.vy > 0.0) {
        c.timer = 0;
        c.frame = landTo;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 9) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0xa) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0xc) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0xd) {
        if (c.f3138 > 1) {
            c.frame = 0xf;
            return;
        }
        c.x = c.facing * 0xf + c.x;
    }
    if (c.frame === 0xf && c.f3138 < loop15Max) {
        c.frame = 5;
        c.f3138++;
    }
    if (c.frame === jumpFrame) {
        c.vy = jumpVy;
        c.vx = jumpVx;
        c.w16c = jumpW16c;
    }
    if (c.frame === landTo) c.frame -= 4;
    if (c.frame >= cnt) {
        c.state = 3;
        c.onStateChange();
    }
}
function state322(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.w16c = 0x63;
    if ((c.frame === 5 || c.frame === 0xa) && c.timer === 0) c.seRequest = 0x15;
    if (c.vx > 0.0) c.vx -= 0.025;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.y < 0.0) {
        c.ay = 0.045;
        c.vy += c.ay;
    }
    if (c.frame > 0x1b && c.frame < 0x21 && c.y + c.vy > 0.0) {
        c.timer = 0;
        c.frame = 0x21;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    if (c.frame > 0x25 && c.frame < 0x2a && c.y + c.vy > 0.0) {
        c.timer = 0;
        c.frame = 0x2a;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    if (c.frame > 0x2c && c.frame < 0x43 && c.y + c.vy > 0.0) {
        c.timer = 0;
        c.frame = 0x43;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 9) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0xa) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0xc) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0xd) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0xf && c.f3138 < 0xa) {
        c.f3138++;
        c.frame = 5;
    }
    if (c.frame === 0x13) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0x14) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0x16) c.x = c.facing * 0xf + c.x;
    if (c.frame === 0xf && c.f3138 < 8) {
        c.frame = 5;
        c.f3138++;
    }
    if (c.frame === 0x1c) {
        c.vy = -1.8;
        c.vx = 1.5;
        c.w16c = 1;
    }
    if (c.frame === 0x25) {
        c.vy = -2.6;
        c.vx = 1.5;
        c.w16c = 1;
    }
    if (c.frame === 0x2d) {
        c.vy = -4.5;
        c.vx = 2.2;
        c.w16c = 8;
    }
    if (c.frame === 0x43) c.frame -= 4;
    if (c.frame >= cnt) {
        c.state = 3;
        c.onStateChange();
    }
}
registerStates({
    303: state303,
    304: state304,
    305: state305,
    306: state306,
    307: state307,
    308: (c)=>dashGrab(c, 0x3e8, 0x44, 0x13, 6, 1, 0x137, false),
    309: (c)=>dashGrab(c, 0x7d0, 0x45, 5, 0xc, 3, 0x138, false),
    310: (c)=>dashGrab(c, 0xbb8, 0x46, 0x40, 0x12, 5, 0x139, true),
    311: state311,
    312: (c)=>doubleThrow(c, false),
    313: (c)=>doubleThrow(c, true),
    314: (c)=>steerSuper(c, 0x3e8, 0x44, 0x13, 0xc, 1.2, 3, false),
    315: (c)=>steerSuper(c, 0x7d0, 0x45, 5, 0x63, 1.3, 5, false),
    316: (c)=>steerSuper(c, 0xbb8, 0x46, 0x40, 0x63, 1.4, 0xa, true),
    317: (c)=>rushSuper(c, 0x3e8, 0x44, 0x13, 3.2, 2, 0x13e, false),
    318: (c)=>comboSuper(c, 0x12, 0x1f, 1, 0x13, -3.3, 1.5, 3),
    319: (c)=>rushSuper(c, 0x7d0, 0x45, 5, 4.0, 3, 0x140, false),
    320: (c)=>comboSuper(c, 0x19, 0x26, 2, 0x19, -4.0, 1.6, 4),
    321: (c)=>rushSuper(c, 0xbb8, 0x46, 0x40, 4.5, 3, 0x142, true),
    322: state322
});
function childStep(c, i, dur) {
    const ch = c.children[i];
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function child400(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0 && c.a3148[i] === 0) {
        ch.hitsLeft = 1;
        ch.vx = 2.0;
        c.a3148[i]++;
    }
    ch.vx -= 0.03;
    ch.timer++;
    if (childStep(c, i, dur)) {
        ch.hitState = 0;
        if (ch.frame >= cnt) ch.frame = 0;
    }
    if (ch.x < -100.0 || ch.x > 800.0) c.freeChild(i);
}
function droppingChild(c, i, vy0, ay0, nextPat, is402) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const o = c.opponent;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.frame = 0;
        ch.vx = 0.0;
        ch.vy = vy0;
        ch.ay = ay0;
    }
    if (ch.frame < 0xb) ch.vy += ch.ay;
    if (ch.frame === 3 && ch.vy + ch.y > 0.0) {
        ch.vy = 0.0;
        if (is402) {
            ch.ay = 0.0;
            ch.timer = 0;
            ch.frame = 4;
        } else {
            ch.timer = 0;
            ch.frame = 4;
            ch.ay = 0.0;
        }
        o.stopMotion();
        o.onStateChange();
        o.state = 0x62;
        ch.y = 0.0;
        applyDirectDamage(c, 0x12c, 960.0);
        if (!(o.life > 0)) o.life = 1;
        const d = childSpawnFrame;
        d.w04 = 0;
        d.x = ftol(ch.x);
        d.y = 0.0;
        d.b2c = 2;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (ch.frame === 5 && c.f3138 > 0x334) {
        ch.frame = 6;
        ch.timer = 0;
        ch.vy = -5.0;
        ch.ay = 0.06;
        return;
    }
    if (ch.frame === 9 && ch.vy + ch.y > 0.0) {
        ch.vy = 0.0;
        if (is402) {
            ch.ay = 0.0;
            ch.y = 0.0;
        } else {
            ch.y = 0.0;
            ch.ay = 0.0;
        }
        ch.timer = 0;
        ch.frame = 0xa;
        return;
    }
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame === 6) {
        if (c.f3138 > 0x2da) {
            ch.frame = 5;
        } else {
            ch.frame = 0;
            ch.vx = 0.0;
            ch.vy = vy0;
            ch.ay = ay0;
        }
    }
    if (ch.frame >= cnt) {
        ch.timer = 0;
        ch.frame = 0;
        ch.pattern = nextPat;
    }
}
function child403(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (c.f3140 === 1 && ch.frame === 0) {
        ch.frame = 1;
        ch.timer = 0;
        c.seRequest = 0x1a;
        ch.vx = 1.0;
    }
    ch.timer++;
    if (childStep(c, i, dur)) {
        ch.hitState = 0;
        if (ch.frame >= cnt) ch.frame = 1;
    }
    if (ch.x < -100.0 || ch.x > 740.0) c.freeChild(i);
}
function child404(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.8;
        ch.vy = -2.0;
    }
    ch.vy += 0.043;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame >= cnt) {
        c.freeChild(i);
        c.f3140 = 1;
    }
}
function child405(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame >= cnt) c.freeChild(i);
}
function followChild(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.x = c.x;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame === 7 && c.frame <= 0xb) {
        ch.frame -= 2;
        return;
    }
    if (ch.frame >= cnt || c.state !== 0x132) c.freeChild(i);
}
function child408(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const o = c.opponent;
    ch.vx = 2.0;
    ch.vy = -4.0;
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 4;
    ch.timer++;
    if (childStep(c, i, dur)) {
        if (ch.y > -480.0) ch.hitState = 0;
        if (ch.frame >= cnt) ch.frame -= 4;
    }
    if (ch.y < -680.0) {
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 0x199;
        ch.x = ch.facing * ((ch.y - o.y) / 2.0) + o.x;
        abortChildWalk();
        return;
    }
}
function child409(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.vx = 3.0;
    ch.vy = 6.0;
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 4;
    ch.timer++;
    if (childStep(c, i, dur)) {
        ch.hitState = 0;
        if (ch.frame >= cnt) ch.frame -= 4;
    }
    if (ch.y > 0.0) {
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.y = 0.0;
        ch.pattern = 0x19a;
        ch.blend = 2;
        ch.frame = 0;
        ch.timer = 0;
        abortChildWalk();
        return;
    }
}
function child410(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.hitsLeft = 1;
    if (ch.frame === 0 && ch.timer === 0) c.voiceRequest = 3;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame >= cnt) c.freeChild(i);
}
registerChildren({
    400: child400,
    401: (c, i)=>droppingChild(c, i, -3.1, 0.08, 0x193, false),
    402: (c, i)=>droppingChild(c, i, -2.1, 0.07, 0x194, true),
    403: child403,
    404: child404,
    405: child405,
    406: followChild,
    407: followChild,
    408: child408,
    409: child409,
    410: child410
});
