import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { loadDat, createImage } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { blit, loadPalette, makeRect, present, readColorKey, setPalette, setPaletteRange } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { playBGM, playSE, stopBGM } from "./4bc01372141f4e276b2208f4.mjs";
import { checkEscapeKey, checkFunctionKeys, pollInput } from "./06124acd5a2cf7a08d774a8d.mjs";
import { FadeMode, Scene, fadeIn, fadeOut } from "./494d0271e10bf938cecabb23.mjs";
import { GameMode, gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { State } from "./2215c2ad4aabedb03c1f6b16.mjs";
import { trackStartGame } from "./bde0cf00ad13465da28af274.mjs";
import { CHARACTER_FOLDERS, STAGE_COUNT, isCharacterLocked, isStageLocked, pad2 } from "./ed94471e7e2b500bb335f7ed.mjs";
const BG_DAT = "system\\chr_sel_bg.dat";
const OB_DAT = "system\\chr_sel_ob.dat";
const ALL_DAT = "system\\stage\\all.dat";
const GRID = [
    6,
    0,
    4,
    7,
    5,
    11,
    1,
    10,
    3,
    8,
    2,
    9,
    23,
    20,
    21,
    14,
    12,
    18,
    17,
    15,
    13,
    16,
    -1,
    19
];
const NAME_ROW = [
    5,
    7,
    11,
    9,
    0,
    4,
    2,
    1,
    10,
    12,
    8,
    3,
    21,
    13,
    20,
    14,
    15,
    8,
    6,
    19,
    17,
    18,
    -1,
    16
];
const PORTRAIT_X = [
    -40,
    -10,
    -5,
    0,
    -5,
    -5,
    -30,
    -30,
    -20,
    -10,
    -40,
    -5,
    -50,
    0,
    -15,
    -15,
    -20,
    -20,
    -45,
    10,
    -20,
    0,
    0,
    -20
];
const COLS = 3;
const ROWS = 8;
const COLOR_COUNT = 6;
var St = /*#__PURE__*/ function(St) {
    St[St["Choose"] = 0] = "Choose";
    St[St["SlideIn"] = 1] = "SlideIn";
    St[St["SlideOut"] = 2] = "SlideOut";
    St[St["Color"] = 3] = "Color";
    St[St["Stage"] = 4] = "Stage";
    St[St["Intro"] = 5] = "Intro";
    St[St["Decided"] = 6] = "Decided";
    St[St["StageIn"] = 7] = "StageIn";
    St[St["StageOut"] = 8] = "StageOut";
    St[St["StagePrev"] = 9] = "StagePrev";
    St[St["StageNext"] = 10] = "StageNext";
    return St;
}(St || {});
const cosd = (deg)=>__numerics.cos(deg * Math.PI / 180);
const sind = (deg)=>__numerics.sin(deg * Math.PI / 180);
export class CharacterSelectScene extends Scene {
    surfBG = loadDat(BG_DAT, 0, 1);
    surfOB = loadDat(OB_DAT, 0, 1);
    surfAll = loadDat(ALL_DAT, 0, 175);
    surfStage = createImage(0, 0);
    portraits = [
        createImage(0, 0),
        createImage(0, 0)
    ];
    portraitKeys = [
        0,
        0
    ];
    obKey;
    allKey;
    stageKey = 0;
    st = [
        5,
        5
    ];
    col = [
        0,
        2
    ];
    row = [
        0,
        0
    ];
    chr = [
        2,
        9
    ];
    color = [
        0,
        0
    ];
    ang = [
        180,
        180
    ];
    off = [
        300,
        300
    ];
    held = [
        0,
        0
    ];
    rnd = [
        0,
        0
    ];
    bgY = 0;
    bar = [
        50,
        50
    ];
    barVel = [
        0,
        0
    ];
    scroll = 0;
    panelY = -480;
    pt = 60;
    introT = 60;
    rollT = 0;
    scrT = 0;
    exit = 0;
    constructor(){
        super();
        loadPalette(this.palette, OB_DAT, 0, 1, 174);
        this.obKey = readColorKey(this.surfOB);
        this.allKey = readColorKey(this.surfAll);
        this.enterState = 1;
    }
    async enter() {
        this.st = [
            5,
            5
        ];
        // Recent-J retains both color slots across selection reentry.
        this.ang = [
            180,
            180
        ];
        this.off = [
            300,
            300
        ];
        this.held = [
            0,
            0
        ];
        this.rnd = [
            0,
            0
        ];
        this.bgY = 0;
        this.bar = [
            50,
            50
        ];
        this.barVel = [
            0,
            0
        ];
        this.scroll = 0;
        this.panelY = -480;
        this.pt = 60;
        this.introT = 60;
        this.rollT = 0;
        this.scrT = 0;
        this.exit = 0;
        gs.usePal[0] = 0;
        gs.usePal[1] = 0;
        if (gs.mode <= GameMode.VsPlayer) loadPalette(this.palette, BG_DAT, 0, 1, 48);
        if (gs.mode === GameMode.Arcade || gs.mode === GameMode.Score) {
            for(let p = 0; p < 2; p++){
                if (gs.cpuSide[p]) {
                    this.st[p] = 4;
                    this.color[p] = -1;
                }
            }
        }
        if (gs.mode < GameMode.Replay) gs.replayMode = 0;
        const sub = gs.mode === GameMode.Practice || gs.mode === GameMode.Replay;
        playBGM(sub && gs.fileCheck !== 0 ? 1 : 0);
        await fadeIn(this, FadeMode.White);
        this.enterState = 0;
    }
    cell(p) {
        return this.col[p] + COLS * this.row[p];
    }
    static portraitBase(p) {
        return 175 + 40 * p;
    }
    createFighter(p) {
        gs.fighters[p] = {
            id: this.chr[p],
            color: this.color[p],
            isCPU: gs.cpuSide[p]
        };
        const name = CHARACTER_FOLDERS[this.chr[p]];
        const file = `system\\${name}\\${name}.dat`;
        const base = CharacterSelectScene.portraitBase(p);
        this.portraits[p] = loadDat(file, 0, base);
        loadPalette(this.palette, file, 40 * this.color[p], base, 40);
        setPalette(this.palette);
        this.portraitKeys[p] = readColorKey(this.portraits[p]);
    }
    loadPortraitPalette(p) {
        const name = CHARACTER_FOLDERS[this.chr[p]];
        const base = CharacterSelectScene.portraitBase(p);
        loadPalette(this.palette, `system\\${name}\\${name}.dat`, 40 * this.color[p], base, 40);
        setPaletteRange(this.palette, base, 40);
    }
    loadStagePreview(withList) {
        const file = `system\\stage\\${pad2(gs.stage)}.dat`;
        this.surfStage = loadDat(file, 0, 191);
        this.stageKey = readColorKey(this.surfStage);
        if (withList) loadPalette(this.palette, ALL_DAT, 0, 175, 16);
        loadPalette(this.palette, file, 0, 191, 64);
        setPaletteRange(this.palette, 175, 80);
    }
    async startGame() {
        for(let p = 0; p < 2; p++){
            if (!gs.cpuSide[p]) trackStartGame(this.chr[p], gs.mode);
        }
        await fadeOut(this, FadeMode.Black, 0, 50);
        gs.round = 1;
        gs.defeatedMask = 0;
        gs.stageMask = 0;
        this.enterState = 1;
        return State.Loading;
    }
    async update() {
        if (this.enterState >= 1) await this.enter();
        if (this.exit) {
            await fadeOut(this, FadeMode.Black, 0, 100);
            this.enterState = 1;
            gs.stage = 0;
            this.exit = 0;
            stopBGM();
            return gs.mode === GameMode.Replay ? State.Replay : State.Title;
        }
        if (checkEscapeKey()) this.exit = 1;
        checkFunctionKeys();
        pollInput();
        const inp = gs.input.map((i)=>({
                ...i
            }));
        for(let p = 0; p < 2; p++){
            const o = 1 - p;
            if (!gs.cpuSide[p]) continue;
            if (gs.mode === GameMode.Arcade) {
                inp[p] = {
                    moveX: 0,
                    moveY: 0,
                    a: 0,
                    b: 0,
                    c: 0,
                    d: 0
                };
            } else if (gs.mode === GameMode.Practice || gs.mode === GameMode.VsCom || gs.mode === GameMode.Replay) {
                if (this.st[p] <= 3 && this.st[o] === 6) inp[p] = {
                    ...gs.input[o]
                };
                inp[p].b = gs.input[o].b;
            }
        }
        for(let p = 0; p < 2; p++){
            const r = this.stepPlayer(p, inp[p]);
            if (r !== null) return r;
            if (!gs.cpuSide[p] && this.st[p] === 0 && inp[p].b) this.exit = 0;
            this.held[p] = Number(inp[p].moveX !== 0 || inp[p].moveY !== 0);
        }
        const [s0, s1] = this.st;
        if (s0 === 6 && s1 === 6) {
            if (this.ang[0] >= 90) {
                for(let p = 0; p < 2; p++){
                    this.off[p] = Math.trunc((cosd(this.ang[p]) + 1) * 300);
                    this.ang[p] -= 5;
                }
            } else if (this.pt < 60) {
                this.panelY = this.panelFormula();
                this.pt += 3;
            } else {
                this.st = [
                    7,
                    7
                ];
                this.loadStagePreview(true);
            }
        } else {
            for(let p = 0; p < 2; p++){
                if (this.st[p] === 6 && inp[p].b) this.st[p] = 2;
            }
        }
        if (s0 === 7) {
            if (this.rollT > 84) {
                this.rollT = 90;
                this.st = [
                    4,
                    4
                ];
            } else this.rollT += 5;
        } else if (s0 === 8 || s1 === 8) {
            if (this.rollT > 0) {
                this.rollT -= 4;
            } else if (this.pt > 0) {
                this.panelY = this.panelFormula();
                this.pt -= 3;
            } else {
                this.st = [
                    0,
                    0
                ];
            }
        }
        if (this.st[0] === 5 || this.st[1] === 5) {
            if (this.introT > 0) {
                this.bgY = Math.trunc(cosd(1.5 * this.introT) * 240);
                this.introT--;
            }
            if (this.pt > 0) {
                this.panelY = this.panelFormula();
                this.pt--;
                if (this.pt === 0) this.st = [
                    0,
                    0
                ];
            }
        }
        for(let i = 0; i < 2; i++)this.bar[i] = Math.min(50, Math.max(0, this.bar[i] - this.barVel[i]));
        this.scroll += 1;
        if (this.scroll >= 240) this.scroll -= 240;
        this.render();
        const s0now = this.st[0];
        if (s0now === 9 || s0now === 10) {
            if (this.scrT < 90) {
                this.scrT += 10;
            } else {
                this.scrT = 0;
                this.st = [
                    4,
                    4
                ];
                if (s0now === 9) {
                    gs.stage++;
                    if (gs.fileCheck === 0 && gs.stage === 13) gs.stage = 17;
                    if (gs.fileCheck === -1 && gs.stage === 18) gs.stage = 0;
                    if (gs.stage >= STAGE_COUNT) gs.stage = 0;
                } else {
                    gs.stage--;
                    if (gs.stage < 0) gs.stage = STAGE_COUNT - 1;
                    if (gs.fileCheck === 0 && gs.stage === 16) gs.stage = 12;
                    if (gs.fileCheck === -1 && gs.stage === 22) gs.stage = 17;
                }
                this.loadStagePreview(false);
            }
        }
        return State.CharacterSelect;
    }
    panelFormula() {
        return Math.trunc(((cosd(this.pt) - 0.5) * 2 - 1) * 240);
    }
    stepStage(stage, dir) {
        let s = stage;
        do {
            s = (s + dir + STAGE_COUNT) % STAGE_COUNT;
        }while (isStageLocked(s, gs.fileCheck) && s !== stage)
        return s;
    }
    stepPlayer(p, input) {
        const o = 1 - p;
        switch(this.st[p]){
            case 0:
                {
                    gs.usePal[p] = 0;
                    this.barVel[p] = 2;
                    if (input.c && this.rnd[p] === 0 || input.a && GRID[this.cell(p)] === -1) this.rnd[p] = 60;
                    if (this.rnd[p] > 0) {
                        this.rnd[p]--;
                        input.moveX = rand("src/game/scene_select.ts:384:19", {
                            consumer: "CharacterSelectScene.stepPlayer",
                            player: p
                        }) % 3 - 1;
                        input.moveY = rand("src/game/scene_select.ts:385:19", {
                            consumer: "CharacterSelectScene.stepPlayer",
                            player: p
                        }) % 2;
                        input.a = 0;
                        this.held[p] = 0;
                        if (this.rnd[p] === 0) {
                            const id = GRID[this.cell(p)];
                            if (id === -1 || isCharacterLocked(id, gs.fileCheck)) {
                                this.rnd[p]++;
                            } else {
                                input.a = 1;
                                input.moveX = 0;
                                input.moveY = 0;
                            }
                        }
                    }
                    if (this.held[p]) {
                        if (input.moveX === 0 && input.moveY === 0) this.held[p] = 0;
                    } else {
                        let moved = true;
                        if (input.moveY < 0) {
                            this.row[p] = (this.row[p] + ROWS - 1) % ROWS;
                        } else if (input.moveY > 0) {
                            this.row[p] = (this.row[p] + 1) % ROWS;
                            this.ang[p] = 40;
                        } else if (input.moveX < 0) {
                            this.col[p] = (this.col[p] + COLS - 1) % COLS;
                            this.ang[p] = 40;
                        } else if (input.moveX > 0) {
                            this.col[p] = (this.col[p] + 1) % COLS;
                            this.ang[p] = 40;
                        } else {
                            moved = false;
                        }
                        if (moved) {
                            playSE(8);
                            this.held[p] = 1;
                        }
                        this.chr[p] = GRID[this.cell(p)];
                    }
                    if (this.chr[p] < 0 || isCharacterLocked(this.chr[p], gs.fileCheck)) input.a = 0;
                    if (input.a && input.moveX === 0 && input.moveY === 0) {
                        if (this.st[o] >= 1 && this.st[o] <= 6 && this.chr[o] === this.chr[p] && this.color[o] === this.color[p]) {
                            this.color[p] = (this.color[p] + 1) % COLOR_COUNT;
                        }
                        playSE(6);
                        this.createFighter(p);
                        this.st[p] = 1;
                        this.ang[p] = 90;
                    }
                    break;
                }
            case 1:
                this.barVel[p] = -2;
                this.off[p] = Math.trunc((cosd(this.ang[p]) + 1) * 300);
                this.ang[p] += 5;
                if (this.ang[p] > 180) {
                    this.st[p] = 3;
                    playSE(40 + this.chr[p]);
                }
                if (input.b) {
                    this.st[p] = 2;
                    this.rnd[p] = 0;
                }
                break;
            case 2:
                if (this.ang[p] < 90) {
                    this.st[p] = 0;
                } else {
                    this.off[p] = Math.trunc((cosd(this.ang[p]) + 1) * 300);
                    this.ang[p] -= 5;
                }
                break;
            case 3:
                {
                    gs.usePal[p] = input.moveY > 0 ? 1 : 0;
                    if (this.held[p]) {
                        if (input.moveX === 0 && input.moveY === 0) this.held[p] = 0;
                    } else if (input.moveX !== 0) {
                        playSE(8);
                        this.held[p] = 1;
                        const step = input.moveX > 0 ? 1 : COLOR_COUNT - 1;
                        this.color[p] = (this.color[p] + step) % COLOR_COUNT;
                        if (this.chr[o] === this.chr[p] && this.color[o] === this.color[p] && this.st[o] >= 1 && this.st[o] <= 6) {
                            this.color[p] = (this.color[p] + step) % COLOR_COUNT;
                        }
                        this.loadPortraitPalette(p);
                    }
                    if (input.a || input.d) {
                        if (input.d) gs.usePal[p] = 1;
                        const fighter = gs.fighters[p];
                        if (fighter) fighter.color = this.color[p];
                        playSE(6);
                        this.st[p] = 6;
                        if (gs.mode === GameMode.Arcade || gs.mode === GameMode.Score) return this.startGame();
                    }
                    if (input.b) {
                        this.st[p] = 2;
                    }
                    break;
                }
            case 4:
                if (this.st[o] === 4) return this.stepStageSelect(p, input);
                break;
        }
        return null;
    }
    stepStageSelect(p, input) {
        if (this.rnd[0] > 0) {
            this.rnd[0]--;
            if (this.rnd[0] === 0 && isStageLocked(gs.stage, gs.fileCheck)) this.rnd[0] = rand("src/game/scene_select.ts:498:81", {
                consumer: "CharacterSelectScene.stepStageSelect",
                player: p
            }) % STAGE_COUNT + 1;
            if (this.rnd[0] === 0) {
                playSE(6);
                this.loadStagePreview(false);
                return this.startGame();
            }
            gs.stage++;
            if (gs.stage >= STAGE_COUNT) gs.stage = 0;
        } else {
            if (input.moveY > 0 || input.moveX > 0) {
                playSE(8);
                this.st = [
                    10,
                    10
                ];
            } else if (input.moveX < 0 || input.moveY < 0) {
                playSE(8);
                this.st = [
                    9,
                    9
                ];
            }
            if (isStageLocked(gs.stage, gs.fileCheck)) input.a = 0;
            if (input.a) {
                playSE(6);
                return this.startGame();
            }
        }
        if (input.c && this.rnd[0] === 0) this.rnd[0] = rand("src/game/scene_select.ts:522:50", {
            consumer: "CharacterSelectScene.stepStageSelect",
            player: p
        }) % STAGE_COUNT + 60;
        if (input.b) {
            this.st[p] = 8;
            this.st[1 - p] = 8;
            this.rnd[0] = 0;
            this.rnd[1] = 0;
        }
        return null;
    }
    render() {
        __session.render();
        const ob = this.surfOB;
        const key = this.obKey;
        blit(makeRect(0, 0, 320, 240), this.surfBG, makeRect(0, this.bgY, 320, 240), 0);
        const hideCPU = (p)=>gs.mode === GameMode.Arcade && gs.cpuSide[p] === 1;
        if (!hideCPU(0)) {
            const x = 5 - this.bar[0];
            blit(makeRect(x, this.scroll, 22, 240), ob, makeRect(133, 128, 22, 240), key);
            blit(makeRect(x, this.scroll - 240, 22, 240), ob, makeRect(133, 128, 22, 240), key);
        }
        if (!hideCPU(1)) {
            const x = 292 + this.bar[1];
            blit(makeRect(x, -this.scroll, 22, 240), ob, makeRect(165, 128, 22, 240), key);
            blit(makeRect(x, 240 - this.scroll, 22, 240), ob, makeRect(165, 128, 22, 240), key);
        }
        for(let p = 0; p < 2; p++){
            if (this.st[p] < 1 || this.st[p] === 5 || this.chr[p] < 0 || hideCPU(p)) continue;
            const half = Math.trunc(this.off[p] / 2);
            const xoff = PORTRAIT_X[this.cell(p)];
            const nameRow = NAME_ROW[this.chr[p]];
            if (p === 0) {
                blit(makeRect(-80 - this.off[0] + xoff, 0, 320, 240), this.portraits[0], makeRect(0, 0, 320, 240), this.portraitKeys[0], true);
                blit(makeRect(-half, 137, 122, 95), ob, makeRect(192, 9, 122, 95), key);
                blit(makeRect(-half, 192, 122, 32), ob, makeRect(0, 256 + 32 * nameRow, 122, 32), key);
                if (gs.usePal[0]) blit(makeRect(-16 - half, 5, 128, 32), ob, makeRect(0, 224, 128, 32), key);
            } else {
                blit(makeRect(80 + this.off[1] - xoff, 0, 320, 240), this.portraits[1], makeRect(0, 0, 320, 240), this.portraitKeys[1]);
                blit(makeRect(198 + half, 137, 122, 95), ob, makeRect(192, 9, 122, 95), key);
                blit(makeRect(198 + half, 192, 122, 32), ob, makeRect(0, 256 + 32 * nameRow, 122, 32), key);
                if (gs.usePal[1]) blit(makeRect(207 + half, 5, 128, 32), ob, makeRect(0, 224, 128, 32), key);
            }
        }
        const y = this.panelY;
        blit(makeRect(96, y, 128, 217), ob, makeRect(0, 0, 128, 217), key);
        const lockRect = makeRect(138, 96, 41, 25);
        const covers = gs.fileCheck === 0 ? [
            [
                103,
                114
            ],
            [
                143,
                114
            ],
            [
                183,
                114
            ],
            [
                177,
                192
            ]
        ] : gs.fileCheck === -1 ? [
            [
                97,
                140
            ],
            [
                137,
                140
            ],
            [
                143,
                166
            ],
            [
                183,
                166
            ]
        ] : [];
        for (const [cx, cy] of covers)blit(makeRect(cx, y + cy, 41, 25), ob, lockRect, key);
        if (this.panelY === 0) {
            const pos = (p)=>[
                    88 + 40 * this.col[p] + (this.row[p] % 2 === 0 ? 6 : 0),
                    10 + 26 * this.row[p]
                ];
            const active = [
                0,
                1
            ].filter((p)=>!hideCPU(p) && this.st[p] !== 4 && this.st[p] !== 5);
            if (active.length === 2 && this.cell(0) === this.cell(1)) {
                const [cx, cy] = pos(0);
                blit(makeRect(cx, cy, 63, 24), ob, makeRect(129, 64, 63, 24), key);
            } else {
                for (const p of [
                    1,
                    0
                ]){
                    if (!active.includes(p)) continue;
                    const [cx, cy] = pos(p);
                    blit(makeRect(cx, cy, 63, 24), ob, makeRect(129, 32 * p, 63, 24), key);
                }
            }
        }
        const s0 = this.st[0];
        if ((s0 === 4 || s0 === 7 || s0 === 8 || s0 === 9 || s0 === 10) && gs.mode !== GameMode.Arcade && gs.mode !== GameMode.Score) {
            this.renderStageMenu(s0);
        }
        present();
    }
    renderStageMenu(st) {
        const t = this.rollT;
        const rolling = this.rnd[0] > 0;
        let dx = 0;
        let dy = 0;
        if (st === 9) {
            dy = Math.trunc(sind(this.scrT) * 32.0);
            dx = -Math.trunc(sind(this.scrT) * 11.0);
        } else if (st === 10) {
            dy = -Math.trunc(sind(this.scrT) * 32.0);
            dx = Math.trunc(sind(this.scrT) * 11.0);
        }
        const px = -Math.round(230 * cosd(t));
        if (rolling) blit(makeRect(px, 0, 195, 222), this.surfOB, makeRect(0, 985, 195, 222), this.obKey);
        else blit(makeRect(px, 0, 195, 222), this.surfStage, makeRect(1, 0, 195, 222), this.stageKey);
        const next = [];
        let s = gs.stage;
        for(let i = 1; i <= 7; i++){
            s = this.stepStage(s, 1);
            next.push(s);
        }
        for(let i = 7; i >= 1; i--){
            const ix = 170 + 11 * i + dx;
            const iy = 205 - 33 * i + Math.round((190 + 33 * i) * cosd(t)) + dy;
            blit(makeRect(ix, iy, 160, 32), this.surfAll, makeRect(0, 32 * next[i - 1], 160, 32), this.allKey);
        }
        blit(makeRect(170 + dx, 205 + Math.round(190 * cosd(t)) + dy, 160, 32), this.surfAll, makeRect(160, 32 * gs.stage, 160, 32), this.allKey);
    }
    static files = [
        BG_DAT,
        OB_DAT,
        ALL_DAT
    ];
}

export function __logicState(){return {GRID,NAME_ROW,PORTRAIT_X,St};}

export function __installInitialRoots(s){
if(GRID!==s["GRID"])throw Error('INITIAL_CONST_IDENTITY:GRID');
if(NAME_ROW!==s["NAME_ROW"])throw Error('INITIAL_CONST_IDENTITY:NAME_ROW');
if(PORTRAIT_X!==s["PORTRAIT_X"])throw Error('INITIAL_CONST_IDENTITY:PORTRAIT_X');
St=s["St"];
}
