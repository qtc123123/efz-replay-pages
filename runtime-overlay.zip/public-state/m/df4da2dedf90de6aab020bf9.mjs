// Deployment-owned setting. No URL, storage or UI override is accepted.
// Set only to the verified HTTPS relay origin; null keeps the viewer offline.
export const RELAY_ORIGIN = 'https://liberal-salon-automatic-fastest.trycloudflare.com';
