import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { loadDat } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { blit, loadPalette, makeRect, present } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { playBGM, stopBGM } from "./4bc01372141f4e276b2208f4.mjs";
import { pollInput } from "./06124acd5a2cf7a08d774a8d.mjs";
import { FadeMode, Scene, fadeIn, fadeOut } from "./494d0271e10bf938cecabb23.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { State } from "./2215c2ad4aabedb03c1f6b16.mjs";
const STFR_DAT = "system\\stfr.dat";
const SCROLL_MAX = 2280.0;
const SCROLL_END = 2800.0;
export class StaffRollScene extends Scene {
    surf = loadDat(STFR_DAT, 0, 1);
    scrollY = 0.0;
    skip = 0;
    constructor(){
        super();
        loadPalette(this.palette, STFR_DAT, 0, 1, 254);
    }
    async update() {
        if (this.scrollY === 0.0) {
            playBGM(5);
            this.render();
            await fadeIn(this, FadeMode.Black);
            this.scrollY += 0.5;
            return State.StaffRoll;
        }
        if (this.scrollY > SCROLL_END || this.skip) {
            await fadeOut(this, FadeMode.Black, -500, 200);
            stopBGM();
            this.scrollY = 0;
            this.skip = 0;
            return State.Title;
        }
        pollInput();
        for (const input of gs.input){
            if (input.a === 1 || input.b === 1 || input.c === 1 || input.d === 1) this.skip = 1;
        }
        this.scrollY += 0.3;
        this.render();
        return State.StaffRoll;
    }
    render() {
        __session.render();
        const sy = this.scrollY <= SCROLL_MAX ? Math.trunc(this.scrollY) : SCROLL_MAX;
        blit(makeRect(0, 0, 320, 240), this.surf, makeRect(0, sy, 320, 240), 0);
        present();
    }
    static files = [
        STFR_DAT
    ];
}
