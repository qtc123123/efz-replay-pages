import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./63e7d3d2e4c75abee840f38e.mjs";
import { childCount, childDuration, frameChild, frameEffect, openSpawnFrame } from "./3a237fcb73b1d38bd3b629bc.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function groundJumpCancel(c, exact3) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && (exact3 ? c.d168 === 3 : c.d168 >= 2)) {
        jumpTo456(c);
        return true;
    }
    return false;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a === 0) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function attackStart(c, meter, se, hits) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = hits;
}
function landTo13(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return true;
    }
    return false;
}
function stopIfNotDashing(c) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
}
function dashSlide(c) {
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - 0.06;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGroundNormal(c, end, crouchable) {
    c.state = end;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function groundNormalAdvance(c, dur, cnt, clearBelow, crouchable) {
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, 0, crouchable);
    }
}
function airNormalAdvance(c, dur, cnt, clearBelow) {
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function burstFx(c, d) {
    d.w04 = 9;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 70;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    c.w16c = 1;
    c.seRequest = 62;
}
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        burstFx(c, d);
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 8)) {
        c.stopMotion();
        burstFx(c, d);
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 0x13) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (atStart(c)) c.stopMotion();
    c.vx = 1.65;
    c.b158 = 1;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) {
            c.frame = 0;
            return;
        }
    }
    if (c.inputX === c.facing && c.f3138 >= 120) c.setState(178);
    if (c.inputX !== c.facing && c.f3138 >= 60) c.setState(178);
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(2);
    c.b158 = 0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2) && c.f313c === 0) {
        c.vx = -2.5;
        c.vy = -1.0;
        c.ay = 0.05;
        c.f313c++;
    }
    if (c.frame > 1) c.vy = c.vy + c.ay;
    if (c.frame > 1 && c.vy + c.y >= 0.0 && c.f3138 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.y = 0.0;
        c.f3138++;
        c.seRequest = 9;
        c.frame = 4;
        c.timer = 0;
    }
    if (c.frame === 4 || c.frame === 5) {
        if (c.facing === 1 && c.command === 1 || c.facing === -1 && c.command === 0) {
            c.onStateChange();
            c.stopMotion();
            c.state = 251;
            return;
        }
    }
    if (advance(c, dur)) {
        if (c.frame === 4) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.faceOpponent();
            c.setState(0);
        }
    }
}
function airDashEnd(c, vx) {
    c.setState(9);
    c.vx = vx;
    c.ay = 0.03;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = 2.0;
        c.startAfterimage(3);
        c.vy = 0.0;
        c.ay = 0.0;
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f3138 >= 120) airDashEnd(c, 1.3);
    if (c.inputX !== c.facing && c.f3138 >= 48) airDashEnd(c, 1.3);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -2.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9);
    if (c.inputX !== -c.facing && c.f3138 >= 48) airDashEnd(c, -0.9);
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.b158 = 0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1) && c.f3140 === 0) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2) && c.f3140 === 0) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt && c.f3140 < 3) {
            c.f3140++;
            c.frame = w16(c.frame - 2);
        }
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 4) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 4;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 2) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 4) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c);
    if (groundJumpCancel(c, false)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 21, 1);
    groundNormalAdvance(c, dur, cnt, 2, false);
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c);
    if (groundJumpCancel(c, false)) return;
    if (atFrame(c, 1)) attackStart(c, 15, 20, 1);
    groundNormalAdvance(c, dur, cnt, 2, false);
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    if (groundJumpCancel(c, true)) return;
    dashSlide(c);
    if (atFrame(c, 2)) attackStart(c, 15, 20, 1);
    groundNormalAdvance(c, dur, cnt, 2, false);
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c);
    if (atFrame(c, 4)) attackStart(c, 35, 20, 1);
    groundNormalAdvance(c, dur, cnt, 2, false);
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c);
    if (groundJumpCancel(c, false)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 21, 1);
    groundNormalAdvance(c, dur, cnt, 3, true);
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.vx > 0.0 && c.b158 === 1 && c.frame < 3) c.vx = c.vx - 0.06;
    if (c.inputY === -1 && c.frame > 0 && c.d168 >= 2) {
        jumpTo456(c);
        return;
    }
    if (groundJumpCancel(c, true)) return;
    if (atFrame(c, 3)) {
        attackStart(c, 13, 20, 1);
        c.vx = c.vx + 0.5;
    }
    if (c.frame > 2) c.vx = c.vx - 0.02;
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, 0, true);
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c);
    if (groundJumpCancel(c, true)) return;
    if (atFrame(c, 3)) attackStart(c, 25, 20, 1);
    groundNormalAdvance(c, dur, cnt, 4, true);
}
function airNormal(c, atk, meter, se, clearBelow) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    if (landTo13(c)) return;
    airNormalAdvance(c, dur, cnt, clearBelow);
}
const s207 = (c)=>airNormal(c, 1, 5, 21, 3);
const s208 = (c)=>airNormal(c, 2, 13, 20, 3);
const s209 = (c)=>airNormal(c, 2, 30, 20, 5);
const s211 = (c)=>airNormal(c, 3, 30, 20, 5);
function s210(c) {
    const dur = frameDuration(c);
    if (c.frame > 6) c.vy = c.vy + c.ay;
    if (atFrame(c, 2)) c.stopMotion();
    if (atFrame(c, 6)) {
        attackStart(c, 30, 20, 3);
        c.vx = 1.0;
        c.vy = 1.0;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.setState(13);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 10) c.frame = 7;
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy = c.vy + c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        d.w04 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        d.b2c = 7;
        frameEffect(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, 7, true);
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 2) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 2 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 221;
        o.state = 107;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x28;
        d.y = ftol(c.y) - 60;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, 0, true);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 1) c.d168 = 0;
    if (atFrame(c, 1)) o.x = c.facing * 0x24 + c.x;
    if (atFrame(c, 2)) o.x = c.facing * 0x22 + c.x;
    if (atFrame(c, 3)) o.x = c.facing * 0x19 + c.x;
    if (atFrame(c, 4)) o.x = c.facing + c.x;
    if (atFrame(c, 4)) o.x = c.x + 0.0;
    if (atFrame(c, 6)) {
        o.onStateChange();
        o.state = 0x51;
        applyDirectDamage(c, 1200, 750.0);
        o.knockX = -2.5;
        o.knockY = -1.5;
        c.seRequest = 2;
        const d = openSpawnFrame();
        d.w04 = 401;
        d.x = ftol(c.x) + c.facing * 0x14;
        d.y = ftol(c.y) - 60;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
        for(let k = 0; k < 7; k++){
            const bx = ftol(c.x);
            d.x = bx + (c.random(0, 100) & 0xffff) - 50;
            const by = ftol(c.y);
            d.y = by + (c.random(0, 80) & 0xffff) - 60;
            frameChild(c, d);
        }
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, 0, true);
    }
}
function s230(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.vx = c.vx - 0.06;
    c.b158 = 0;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atStart(c)) c.vy = 0.0;
    if (atFrame(c, 1)) attackStart(c, 5, 21, 1);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function dashAttackJc(c, hits, clearBelow) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (c.vx > 0.0) c.vx = c.vx - 0.03;
    else c.b158 = 0;
    if (atFrame(c, 1)) {
        c.w16c = hits;
        c.seRequest = 20;
        addMeter(c, 20);
    }
    if (c.vx < 0.0) c.vx = 0.0;
    if (groundJumpCancel(c, false)) return;
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
const s231 = (c)=>dashAttackJc(c, 3, 5);
const s232 = (c)=>dashAttackJc(c, 1, 3);
function s233(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.vx = c.vx - 0.06;
    if (c.vx < 0.0) c.vx = 0.0;
    c.b158 = 0;
    if (atStart(c)) c.vy = 0.0;
    if (atFrame(c, 1)) attackStart(c, 5, 21, 1);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(3);
    }
}
function s234(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (c.vx > 0.0) c.vx = c.vx - 0.03;
    else c.b158 = 0;
    if (atFrame(c, 2)) {
        c.w16c = 1;
        c.seRequest = 20;
        addMeter(c, 20);
        c.vx = c.vx + 1.2;
    }
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function s235(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (c.vx > 0.0 && c.frame < 3) c.vx = c.vx - 0.03;
    else c.b158 = 0;
    if (atFrame(c, 13)) {
        c.w16c = 1;
        c.seRequest = 20;
        addMeter(c, 20);
    }
    if (c.frame > 2 && c.frame < 17) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.timer = 0;
            c.frame = 18;
            c.y = 0.0;
            c.stopMotion();
            return;
        }
    }
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 3) {
            c.vx = 1.2;
            c.vy = -1.5;
            c.ay = 0.035;
        }
        if (c.frame >= cnt) c.setState(0);
    }
}
function s240(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.vx = 1.0;
        c.vy = -2.5;
        c.ay = 0.035;
        c.state = 241;
        o.state = 107;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x1d;
        d.y = ftol(c.y) - 39;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.x = c.x;
        o.y = 0.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 211;
            c.frame = 1;
        }
    }
}
function s241(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy = c.vy + c.ay;
    if (c.facing === 1 && c.x > 630.0) {
        c.x = 630.0;
        c.vx = 0.0;
    }
    if (c.facing === -1 && c.x < 30.0) {
        c.x = 30.0;
        c.vx = 0.0;
    }
    if (c.vy + c.y > 0.0 && c.frame === 4) {
        c.stopMotion();
        c.y = 0.0;
        c.frame = 5;
        c.timer = 0;
    }
    if (c.frame === 0) {
        o.y = c.y - 35.0;
        o.x = c.x;
        o.state = 100;
    }
    if (c.frame === 1) {
        o.y = c.y - 55.0;
        o.x = c.x - c.facing * 0x15;
        o.state = 115;
    }
    if (c.frame === 2) {
        o.y = c.y - 71.0;
        o.x = c.x - c.facing * 0x14;
        o.state = 104;
    }
    if (c.frame === 3) {
        o.y = c.y - 76.0;
        o.x = c.x - c.facing * 0xf;
        o.state = 104;
    }
    if (c.frame === 4) {
        o.y = c.y - 77.0;
        o.x = c.x - c.facing * 0xc;
        o.state = 104;
    }
    if (c.frame === 5) {
        o.y = c.y - 55.0;
        o.x = c.x - c.facing * 0x13;
        o.state = 117;
    }
    if (atFrame(c, 6)) {
        c.shakeScreen(4, 0);
        const d = openSpawnFrame();
        d.w04 = 3;
        d.b2c = 7;
        d.x = ftol(c.x) + c.facing * 0xf;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.x = c.facing * 0xf + c.x;
        o.state = 63;
        o.knockX = -2.0;
        o.knockY = -0.5;
        o.ay = 0.035;
        o.x = c.facing * 0xf + c.x;
        applyDirectDamage(c, 1000, 790.0);
        o.hitstun = s16(ftol(200.0 * c.proration * 0.0001));
        o.onStateChange();
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function child401(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
registerStates({
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    234: s234,
    235: s235,
    240: s240,
    241: s241
});
registerChildren({
    401: child401
});
