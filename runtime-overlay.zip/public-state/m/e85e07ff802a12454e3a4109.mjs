import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./4bfdef0d515a63cf0e27cdb5.mjs";
import { updateChildrenKanna } from "./7d17e301343a90178a9cad8e.mjs";
import { parseCommandKanna, dispatchMovesKanna } from "./7dd9e28153b43bdbd85fad2b.mjs";
import { thinkKanna } from "./08cb8c91c14243c29f21fd05.mjs";
import "./260c1c2b3795487117b917d8.mjs";
import "./ce8d4c5ddca06310d4f17eb8.mjs";
import "./2c9227c5f0f3e69ed1c93e3d.mjs";
import "./761413913f1960f6dabf0a09.mjs";
const CTOR_POINTS_X = [
    -4,
    27,
    11,
    11,
    33
];
const CTOR_POINTS_Y = [
    -59,
    0,
    -18,
    -13,
    -35
];
const RESET_POINTS_X = [
    -13,
    14,
    17,
    7,
    27
];
const RESET_POINTS_Y = [
    -60,
    0,
    -6,
    -25,
    -25
];
export class Kanna extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0x3c;
    a3154 = new Int32Array(64);
    a3254 = new Int32Array(64);
    a3354 = new Int32Array(64);
    pointsX = [
        ...CTOR_POINTS_X
    ];
    pointsY = [
        ...CTOR_POINTS_Y
    ];
    params = [
        4,
        1,
        6,
        0x17,
        0x10,
        0xff,
        0xff,
        0xff
    ];
    w0dc = 0;
    b0de = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    f314c = 0;
    f3150 = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = 0x3c;
        for(let k = 0; k < 5; k++){
            this.pointsX[k] = RESET_POINTS_X[k];
            this.pointsY[k] = RESET_POINTS_Y[k];
        }
        this.a3154.fill(0);
        this.a3254.fill(0);
        this.a3354.fill(0);
        super.resetRound();
    }
    groundMovement() {
        if (this.y === 0) {
            this.b159 = 0;
            this.b15a = 0;
        }
        if (this.y < 0) return;
        const s0 = this.state;
        if (s0 === 4 || s0 === 5 || s0 === 6 || s0 === 0xa || s0 === 0xb || s0 === 0xc) return;
        if (this.d15c < 3 && this.inputY === -1) {
            this.faceOpponent();
            if (this.command >= 3 && this.command <= 5) {
                if (this.command === 3) {
                    if (this.state !== 0xa) this.onStateChange();
                    this.state = 0xa;
                    return;
                }
                if (this.command === 4) {
                    if (this.state !== 0xb) this.onStateChange();
                    this.state = 0xb;
                    return;
                }
                if (this.command === 5) {
                    if (this.state !== 0xc) this.onStateChange();
                    this.state = 0xc;
                    return;
                }
            } else {
                if (this.inputX === 0) {
                    if (this.state !== 4) this.onStateChange();
                    this.state = 4;
                    return;
                }
                if (this.inputX === this.facing) {
                    if (this.state !== 5) this.onStateChange();
                    this.state = 5;
                    return;
                }
                if (this.inputX === -this.facing) {
                    if (this.state !== 6) this.onStateChange();
                    this.state = 6;
                    return;
                }
            }
        }
        if (this.inputY === 1) {
            if (this.state !== 8 && this.state !== 3) {
                this.state = 8;
                this.onStateChange();
                this.faceOpponent();
                return;
            }
            if (this.state !== 8) {
                this.state = 3;
                this.faceOpponent();
            }
            return;
        }
        if (this.inputX !== 0) {
            this.faceOpponent();
            const t = this.inputX === this.facing ? 1 : 2;
            if (this.state !== 0 && this.state !== 1 && this.state !== 2) this.onStateChange();
            this.state = t;
            return;
        }
        if (this.state === 3 || this.state === 8) {
            this.state = 7;
            this.faceOpponent();
            this.onStateChange();
            return;
        }
        if (this.state === 7 || this.state === 0xd) {
            this.faceOpponent();
            return;
        }
        if (this.state !== 0 && this.state !== 1 && this.state !== 2) this.onStateChange();
        this.state = 0;
        this.faceOpponent();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3154[i] = 0;
        this.a3254[i] = 0;
        this.a3354[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {}
    parseCommand() {
        parseCommandKanna(this);
    }
    dispatchMoves() {
        dispatchMovesKanna(this);
    }
    think() {
        thinkKanna(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenKanna(this);
    }
}

export function __logicState(){return {CTOR_POINTS_X,CTOR_POINTS_Y,RESET_POINTS_X,RESET_POINTS_Y};}

export function __installInitialRoots(s){
if(CTOR_POINTS_X!==s["CTOR_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_X');
if(CTOR_POINTS_Y!==s["CTOR_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_Y');
if(RESET_POINTS_X!==s["RESET_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_X');
if(RESET_POINTS_Y!==s["RESET_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_Y');
}
