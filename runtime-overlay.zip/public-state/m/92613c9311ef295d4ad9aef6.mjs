import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./6eb1fb66adb5d5a47cd5c7ec.mjs";
import { updateChildrenMai } from "./746d3a93e9a50814987814cf.mjs";
import { parseCommandMai, dispatchMovesMai } from "./d828065c4b24c0cdbf5f5eff.mjs";
import { thinkMai } from "./20a64323b32fb4de6289c2cd.mjs";
import { renderOverlayMai, tickHookMai } from "./0f251a902b506317b8b23902.mjs";
import "./86cd5d319c2452749c3d0678.mjs";
import "./1d086b3aa249a36ef14013d9.mjs";
import "./338d4470c8a4488c1c8ee922.mjs";
const CTOR_POINTS_X = [
    -20,
    -24,
    4,
    7,
    30
];
const RESET_POINTS_X = [
    -23,
    -24,
    4,
    7,
    30
];
const POINTS_Y = [
    -58,
    0,
    -8,
    -12,
    -22
];
export class Mai extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    f3154 = 0;
    a3158 = new Int32Array(64);
    a3258 = new Int32Array(64);
    a3358 = new Int32Array(64);
    pointsX = [
        ...CTOR_POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        3,
        0,
        1,
        9,
        2,
        0xff,
        0xff,
        0xff
    ];
    w0dc = 0;
    b0de = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = this.f313c = this.f3140 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = RESET_POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.f3144 = this.f3148 = this.f314c = this.f3150 = this.f3154 = 0;
        this.a3158.fill(0);
        this.a3258.fill(0);
        this.a3358.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3158[i] = 0;
        this.a3258[i] = 0;
        this.a3358[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayMai(this);
    }
    tickHook() {
        tickHookMai(this);
    }
    parseCommand() {
        parseCommandMai(this);
    }
    dispatchMoves() {
        dispatchMovesMai(this);
    }
    think() {
        thinkMai(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMai(this);
    }
}

export function __logicState(){return {CTOR_POINTS_X,RESET_POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(CTOR_POINTS_X!==s["CTOR_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_X');
if(RESET_POINTS_X!==s["RESET_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
