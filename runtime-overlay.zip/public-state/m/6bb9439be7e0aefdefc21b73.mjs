import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { spawnEffect } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { childHandlers, registerChildren, registerStates } from "./1f5919024557a92ec3a28767.mjs";
import { childFrameCount, childFrameDuration, frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
export function newSpawnFrame() {
    return {
        d00: 0,
        w04: 0,
        x: 0,
        y: 0,
        b18: 0,
        d1c: 0,
        b20: 0,
        b21: 0,
        d24: 0,
        d28: 0,
        b2c: 0,
        d30: 0,
        clip: [
            0,
            0,
            0,
            0
        ]
    };
}
export function resetSpawnFrame(f) {
    f.d00 = 0;
    f.b20 = 0;
    f.b2c = 0xff;
    f.d24 = 0;
    f.d28 = 0;
    f.d30 = 0;
    f.clip = [
        0,
        0,
        0,
        0
    ];
}
export function openSpawnFrame() {
    const f = newSpawnFrame();
    resetSpawnFrame(f);
    return f;
}
export function frameEffect(f) {
    spawnEffect({
        owner: f.d00,
        pat: f.w04,
        x: f.x,
        y: f.y,
        b18: f.b18,
        mirror: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        sound: f.b2c
    });
}
export function frameChild(c, f) {
    return c.spawnChild({
        type: f.d00,
        pattern: f.w04,
        x: f.x,
        y: f.y,
        facing: f.b18,
        d4c: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        shadow: f.d28,
        b6c: f.b2c,
        moveWhileFrozen: f.d30,
        clip: [
            ...f.clip
        ]
    });
}
export const childSpawnFrame = newSpawnFrame();
export let childDuration = 0;
export let childCount = 0;
let walkAborted = false;
export function abortChildWalk() {
    walkAborted = true;
}
export function updateChildrenExNanase(c) {
    if (c.opponent.freeze > 0) return;
    let i = c.childTail;
    Object.assign(childSpawnFrame, newSpawnFrame());
    walkAborted = false;
    while(i !== c.childHead){
        const ch = c.children[i];
        if (c.childActive[i] !== 0 && ch.hitstop === 0) {
            let run = true;
            if (c.freeze !== 0) {
                if (c.freeze <= 0 || ch.moveWhileFrozen === 0) run = false;
            }
            if (run) {
                childDuration = childFrameDuration(c, i);
                childCount = childFrameCount(c, i);
                resetSpawnFrame(childSpawnFrame);
                const k = ch.pattern - 400;
                if (k >= 0 && k <= 0x63) {
                    const handler = childHandlers.get(ch.pattern);
                    handler?.(c, i);
                    if (walkAborted) return;
                }
            }
        }
        i++;
        if (i >= 64) i = 0;
    }
}
function rfCost(c) {
    if (c.rfBlue === 0) c.rfGauge = c.rfGauge - 500.0;
    else c.rfGauge = c.rfGauge - 250.0;
}
function effect21(c, f) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = ftol(c.x) - c.facing * 0xa;
    f.y = ftol(c.y) - 0x38;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function effect0(f, x, y) {
    f.w04 = 0;
    f.x = x;
    f.y = y;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function oppStateOutside(c, max) {
    const st = c.opponent.state;
    return st < 50 || st > max;
}
function readOppButtons(c) {
    const o = c.opponent;
    if (o.pressed[0] === 1) c.f3138 = 1;
    if (o.pressed[1] === 1) c.f3138 = 2;
    if (o.pressed[2] === 1) c.f3138 = 3;
}
function throwBroken(c) {
    const o = c.opponent;
    c.onStateChange();
    c.state = 0x102;
    c.seRequest = 0x1a;
    o.state = 0x9e;
    o.onStateChange();
    o.stopMotion();
}
function state248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.stopMotion();
        o.d128 = 1;
        effect0(f, ftol(c.x) + c.facing * 0x25, ftol(c.y) - 0x2a);
        c.frame = 0;
        c.timer = 0;
        c.state = 0xf9;
        o.x = c.facing * 0x19 + c.x;
        o.y = c.y - 80.0;
        o.state = 0x65;
        o.onStateChange();
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 1 && o.y < 0.0 && oppStateOutside(c, 0x95)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0xd1;
            c.frame = 2;
        }
    }
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.w13e = 0x1e;
    o.w13e = 0x1e;
    c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 1.0;
        c.vy = -2.0;
        c.ay = 0.04;
    }
    c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.frame === 1) {
        c.y = 0.0;
        c.stopMotion();
        c.frame = 2;
        c.timer = 0;
        return;
    }
    if (c.x > 600.0 || c.x < 40.0) c.vx = 0.0;
    if (c.frame === 0) {
        o.x = c.facing * 0x19 + c.x;
        o.y = c.y - 80.0;
        o.state = 0x65;
        o.onStateChange();
    }
    if (c.frame === 1) {
        o.x = c.facing * 0xa + c.x;
        o.y = c.y - 90.0;
        o.state = 0x76;
        o.onStateChange();
    }
    if (c.frame === 2) {
        o.x = c.facing * 0x1e + c.x;
        o.y = c.y - 60.0;
        o.state = 0x69;
        o.onStateChange();
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 3) {
            o.x = c.facing * 0x28 + c.x;
            o.y = 0.0;
            o.state = 0x62;
            o.onStateChange();
            applyDirectDamage(c, 0x578, 500.0);
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (c.frame === 2 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.state = 0x6b;
        o.hitstop = 0x5a;
        o.x = c.facing * 0x28 + c.x;
        o.d128 = 1;
        o.stopMotion();
        c.timer = 0;
        c.frame = 3;
        effect0(f, ftol(c.x) + c.facing * 0x37, ftol(c.y) - 0x29);
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 2 && o.y === 0.0 && oppStateOutside(c, 150)) c.w16c = 1;
        else c.w16c = 0;
        if (c.frame === 4) {
            c.frame = 0;
            c.state = 0xfe;
            c.frame = 1;
            o.x = c.facing * 0x28 + c.x;
            o.y = -81.0;
            o.state = 0x67;
            return;
        }
        if (c.frame === 3) c.frame = 4;
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 8;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.stopMotion();
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 1) {
            o.x = c.facing * 0xb + c.x;
            o.y = -62.0;
            o.state = 100;
            o.onStateChange();
        }
        if (c.frame === 2) {
            o.x = c.x - c.facing * 0xb;
            o.y = -57.0;
            o.state = 100;
            o.onStateChange();
        }
        if (c.frame === 3) {
            o.x = c.x - c.facing * 0xb;
            o.y = -52.0;
            o.state = 0x68;
            o.onStateChange();
        }
        if (c.frame === 4) {
            o.x = c.x - c.facing * 0x19;
            o.y = -55.0;
            o.state = 0x68;
            o.onStateChange();
        }
        if (c.frame === 5) {
            o.x = c.x - c.facing * 0x25;
            o.y = -54.0;
            o.state = 0x3f;
            o.onStateChange();
            o.knockX = 0.5;
            o.knockY = -2.6;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.d168 === 3) {
        c.biasCameraY(50, 3);
        c.d168 = 0;
        o.x = c.facing * 0x32 + c.x;
        o.y = 0.0;
        o.state = 0x6b;
        o.onStateChange();
        o.stopMotion();
        o.d128 = 1;
        c.onStateChange();
        c.state = 0xfe;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.d168 = 0;
        c.frame++;
        if (c.frame === 5 && c.timer === 0) c.x = c.facing * 0xf + c.x;
        if (c.frame === 6 && o.y === 0.0) c.w16c = 1;
        else c.w16c = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.d168 === 3) {
        c.biasCameraY(50, 3);
        c.d168 = 0;
        o.x = c.facing * 0x28 + c.x;
        o.y = -80.0;
        o.state = 0x67;
        o.onStateChange();
        o.stopMotion();
        c.onStateChange();
        c.state = 0xfe;
        c.frame = 2;
        o.d128 = 1;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.d168 = 0;
        c.frame++;
        if (c.frame === 6 && o.y < 0.0) c.w16c = 1;
        else c.w16c = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.biasCameraY(50, 3);
    if (c.f3138 === 0 && c.frame === 2) readOppButtons(c);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 1) {
            o.x = c.facing * 0x28 + c.x;
            o.y = -81.0;
            o.state = 0x67;
            o.onStateChange();
            o.stopMotion();
            o.d128 = 1;
        }
        if (c.frame === 2) {
            o.x = c.facing * 0x28 + c.x;
            o.y = -80.0;
            o.state = 0x67;
            o.onStateChange();
            o.stopMotion();
            o.d128 = 1;
        }
        if (c.frame >= cnt) {
            c.state = 0x101;
            o.state = 0x3f;
            o.onStateChange();
            o.stopMotion();
            o.d128 = 1;
            if (c.command === 10 || c.command === 30) {
                c.state = 0xff;
                c.frame = 0;
                c.timer = 0;
                o.state = 0x67;
                if (c.f3138 === 3) throwBroken(c);
                return;
            }
            if (c.command === 11 || c.command === 31) {
                if (c.f3138 === 2) {
                    throwBroken(c);
                    return;
                }
                c.state = 0xfb;
                o.state = 0x67;
                c.frame = 1;
                c.timer = 0;
                o.x = c.facing * 0xb + c.x;
                o.y = -62.0;
                o.state = 100;
                return;
            }
            o.y = -40.0;
            c.frame = 0;
            c.timer = 0;
        }
    }
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.biasCameraY(50, 3);
    if (c.frame === 1 && c.timer === 0) c.f3138 = 0;
    c.stopMotion();
    if (c.frame === 6 && c.timer === 0) {
        applyDirectDamage(c, 0x5dc, 1000.0);
        c.seRequest = 2;
        effect0(f, ftol(c.x) - c.facing * 7, ftol(c.y) + 7);
    }
    if (c.frame < 10 && c.f3138 === 0) readOppButtons(c);
    if (c.frame === 10 && c.timer === 0) {
        if ((c.command === 10 || c.command === 30) && c.meter >= 1000) {
            if (c.f3138 === 3) {
                throwBroken(c);
                return;
            }
            c.frame = 0;
            c.timer = 0;
            c.state = 0x12c;
            return;
        }
        if ((c.command === 11 || c.command === 31) && c.meter >= 1000) {
            if (c.f3138 === 2) {
                throwBroken(c);
                return;
            }
            c.frame = 0;
            c.timer = 0;
            c.state = 0x132;
            c.facing = -c.facing;
            return;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 1) {
            o.x = c.facing * 0x24 + c.x;
            o.y = -78.0;
            o.state = 0x67;
            o.onStateChange();
        }
        if (c.frame === 2) {
            o.x = c.facing * 0x2b + c.x;
            o.y = -75.0;
            o.state = 0x67;
            o.onStateChange();
        }
        if (c.frame === 3) {
            o.x = c.facing * 0x2d + c.x;
            o.y = -69.0;
            o.state = 0x67;
            o.onStateChange();
        }
        if (c.frame === 4) {
            o.x = c.facing * 0x17 + c.x;
            o.y = -66.0;
            o.state = 0x68;
            o.onStateChange();
            o.facing = c.facing;
        }
        if (c.frame === 5) {
            o.x = c.x - c.facing * 0xa;
            o.y = -62.0;
            o.state = 0x69;
            o.onStateChange();
        }
        if (c.frame === 6) {
            o.x = c.x - 0.0;
            o.y = 0.0;
            o.state = 0x62;
            o.onStateChange();
            o.stopMotion();
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state256(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0 && c.f3138 === 1) {
        throwBroken(c);
        return;
    }
    if (c.frame === 1 && c.timer === 0) {
        o.state = 0x3f;
        o.frame = 0;
        o.timer = 0;
        o.stopMotion();
        o.knockX = -3.0;
        o.knockY = -2.0;
        o.x = c.facing * 0x1e + c.x;
        o.y = -40.0;
        c.shakeScreen(10, 10);
        applyDirectDamage(c, 0x708, 700.0);
        c.d168 = 3;
        c.voiceRequest = 2;
        f.w04 = 0x190;
        f.x = ftol(c.x) + c.facing * 0x28;
        f.y = ftol(c.y) - 0x50;
        f.b20 = 2;
        f.b18 = c.facing;
        f.d00 = 1;
        f.b21 = 1;
        frameChild(c, f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.biasCameraY(50, 3);
    if (c.frame === 2 && c.timer === 0) {
        c.meter = s16(c.meter + 0x1e);
        c.seRequest = 0x14;
        c.w16c = 1;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        effect21(c, f);
        rfCost(c);
    }
    if (c.frame > 5) c.vx = c.vx - 0.015;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.d168 === 3 && c.frame === 6) {
        c.stopMotion();
        c.biasCameraY(50, 3);
        c.d168 = 0;
        o.x = c.facing * 0x32 + c.x;
        o.y = 0.0;
        o.state = 0x6b;
        o.onStateChange();
        o.stopMotion();
        o.d128 = 1;
        c.onStateChange();
        c.state = 0xfe;
        effect0(f, ftol(c.x) + c.facing * 0x45, ftol(c.y) - 0x23);
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.d168 = 0;
        c.frame++;
        if (c.frame === 3) c.vx = 1.3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function spawnHand(c, f, pattern) {
    c.voiceRequest = 1;
    f.w04 = pattern;
    f.x = ftol(c.x);
    f.y = ftol(c.y) - 0x3a;
    f.b18 = c.facing;
    f.b20 = 2;
    f.b21 = 1;
    frameChild(c, f);
}
function state271(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.b158 = 0;
        c.d168 = 0;
    }
    c.timer++;
    if (c.timer >= dur - (c.exOn() << 1)) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 8) {
            spawnHand(c, f, 0x191);
            c.meter = s16(c.meter + 0x1e);
        }
        if (c.frame === 10 && c.f3138 < 3) {
            c.f3138++;
            c.frame = c.frame - 2 & 0xffff;
            if (c.f3138 === 2) c.d168 = 3;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 8;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state272(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (c.frame === 8 && c.timer === 0) spawnHand(c, f, 0x192);
    c.timer++;
    if (c.timer >= dur - (c.exOn() << 1)) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 8) c.meter = s16(c.meter + 0x1e);
        if (c.frame === 10 && c.f3138 < 2) {
            c.f3138++;
            c.frame = c.frame - 2 & 0xffff;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 8;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state273(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        effect21(c, f);
        rfCost(c);
    }
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (c.frame === 8 && c.timer === 0) spawnHand(c, f, 0x193);
    c.timer++;
    if (c.timer >= dur - (c.exOn() << 1)) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 8) c.meter = s16(c.meter + 0x1e);
        if (c.frame === 10 && c.f3138 < 3) {
            c.f3138++;
            c.frame = c.frame - 2 & 0xffff;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 8;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function spawnRush(c, f, pattern) {
    f.w04 = pattern;
    f.x = ftol(c.x);
    f.y = ftol(c.y);
    f.b18 = c.facing;
    f.b20 = 2;
    f.b21 = 0;
    frameChild(c, f);
}
function rushHitInterval(c) {
    if (c.d168 > 0 && c.f313c === 0) {
        c.f3140 = 0x2d;
        c.f313c = 1;
    }
    if (c.d168 > 0 && c.f3140 > 0) c.f3140 = c.f3140 - 1;
    if (c.d168 > 0 && c.f3140 <= 0 && c.f313c > 0) {
        c.d168 = 0;
        c.f313c = 0;
    }
}
function rush(c, decel, pattern, speed, limit) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame > 3) {
        c.vx = c.vx - decel;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame > 3) rushHitInterval(c);
    c.timer++;
    if (c.timer >= dur - (c.exOn() << 1)) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 4) {
            spawnRush(c, f, pattern);
            c.meter = s16(c.meter + 0x1e);
        }
        if (c.frame === 4) {
            c.vx = speed;
            c.w16c = 3;
            c.d168 = 0;
        }
        if (c.frame === 8 && c.f3138 < limit) {
            c.f3138++;
            c.frame = c.frame - 4 & 0xffff;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 8;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state274(c) {
    rush(c, 0.03, 0x194, 2.5, 4);
}
function state275(c) {
    rush(c, 0.018, 0x195, 2.8, 7);
}
function state276(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        effect21(c, f);
        rfCost(c);
    }
    if (c.frame > 7) {
        c.vx = c.vx - 0.025;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur - (c.exOn() << 1)) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 4) {
            c.w13c = 0x3c;
            spawnRush(c, f, 0x196);
            c.meter = s16(c.meter + 0x1e);
        }
        if (c.frame === 4) c.w16c = 0xf;
        if (c.frame === 8 && c.f3138 < 5) {
            c.f3138++;
            c.frame = c.frame - 4 & 0xffff;
            c.d168 = 0;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 8;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function playOnce(c, i) {
    const ch = c.children[i];
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = ch.frame + 1 & 0xffff;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child400(c, i) {
    playOnce(c, i);
}
function child401(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    playOnce(c, i);
}
function childRush(c, i, owner) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y;
    if ((c.state !== owner || c.state === owner && c.frame > 7) && ch.frame < 0x1d) {
        ch.timer = 0;
        ch.frame = 0x1d;
    }
    if (c.hitstop === 0) ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = ch.frame + 1 & 0xffff;
        ch.hitState = 0;
        if (ch.frame === 0x1d) ch.frame = 0xf;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child407(c, i) {
    const ch = c.children[i];
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = ch.frame + 1 & 0xffff;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function loopChild(c, i) {
    const ch = c.children[i];
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = ch.frame + 1 & 0xffff;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
}
function child495(c, i) {
    const ch = c.children[i];
    ch.vx = -0.02;
    ch.drawWhileFrozen = 30000;
    ch.timer = ch.timer + 1 & 0xffff;
    if (c.state !== 0x57) c.freeChild(i);
    loopChild(c, i);
}
function child496(c, i) {
    const ch = c.children[i];
    const s = c.state;
    const inStates = s === 0x53 || s === 0x54 || s === 0x55 || s === 0x56;
    const burst = !inStates || s === 0x53 && c.frame > 1 || s === 0x54 && c.frame > 1;
    if (burst) {
        const f = childSpawnFrame;
        const pieces = [
            [
                0x1f1,
                0x17,
                -4
            ],
            [
                0x1f1,
                -4,
                -6
            ],
            [
                0x1f1,
                -0xe,
                -0x1a
            ],
            [
                0x1f1,
                0,
                0
            ],
            [
                0x1f1,
                0x1e,
                -0x28
            ],
            [
                0x1f1,
                -0x19,
                -0x50
            ],
            [
                0x1f2,
                -0x23,
                -0x2a
            ],
            [
                0x1f2,
                -0x12,
                -0x14
            ],
            [
                0x1f2,
                2,
                -0x41
            ],
            [
                0x1f2,
                0x10,
                -0x50
            ]
        ];
        for (const [pattern, dx, dy] of pieces){
            f.w04 = pattern;
            f.x = ftol(c.x) + c.facing * dx;
            f.y = ftol(c.y) + dy;
            f.b20 = 0;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        c.seRequest = 0x22;
        c.freeChild(i);
        c.f3144 = 0;
        return;
    }
    ch.timer = ch.timer + 1 & 0xffff;
    loopChild(c, i);
}
function coin() {
    return rand("src/game/chars/exnanase/states_specials.ts:1211:8", {
        consumer: "src/game/chars/exnanase/states_specials.ts"
    }) > 0x3e80 ? 1 : 0;
}
function debris(c, i, init, gravity) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3154[i] === 0) init();
    ch.vy = ch.vy + gravity;
    if (ch.y > 0.0 && ch.vy > 0.0) ch.vy = -ch.vy;
    if (c.a3254[i] < 10) ch.blend = 1;
    if (c.a3254[i] < 0) {
        c.freeChild(i);
        return;
    }
    ch.timer = ch.timer + 1 & 0xffff;
    c.a3254[i]--;
    loopChild(c, i);
}
function child497(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 0x28;
        c.a3254[i] = r1 + coin() * 0x14 + 0x50;
        c.a3154[i]++;
        const t1 = coin() * 1.2;
        const t2 = coin() * 0.7 + t1;
        ch.vx = coin() * 1.7 + t2 + -1.8;
        const u1 = coin() * 0.6;
        const u2 = coin() * 0.9 + u1;
        ch.vy = -1.2 - (coin() * 1.4 + u2);
    }, 0.05);
}
function child498(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 0x3c;
        c.a3254[i] = r1 + coin() * 0x28 + 0x78;
        c.a3154[i]++;
        const t1 = coin();
        const t2 = coin() * 0.5 + t1;
        ch.vx = coin() * 1.5 + t2 + -1.5;
        const u1 = coin() * 0.5;
        const u2 = coin() * 0.8 + u1;
        ch.vy = -1.0 - (coin() * 1.2 + u2);
    }, 0.03);
}
function child499(c, i) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y;
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = ch.frame + 1 & 0xffff;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
registerStates({
    248: state248,
    249: state249,
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    271: state271,
    272: state272,
    273: state273,
    274: state274,
    275: state275,
    276: state276
});
registerChildren({
    400: child400,
    401: child401,
    402: child401,
    403: child401,
    404: (c, i)=>childRush(c, i, 0x112),
    405: (c, i)=>childRush(c, i, 0x113),
    406: (c, i)=>childRush(c, i, 0x114),
    407: child407,
    495: child495,
    496: child496,
    497: child497,
    498: child498,
    499: child499
});

export function __logicState(){return {childSpawnFrame,childDuration,childCount,walkAborted};}

export function __installInitialRoots(s){
if(childSpawnFrame!==s["childSpawnFrame"])throw Error('INITIAL_CONST_IDENTITY:childSpawnFrame');
childDuration=s["childDuration"];
childCount=s["childCount"];
walkAborted=s["walkAborted"];
}
