import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { createPalette, present, setPalette, setPaletteDarken, setPaletteWhiten } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { setBGMVolume } from "./4bc01372141f4e276b2208f4.mjs";
import { winSleep as sleep } from "./79570e25e06545d452dd916b.mjs";
export var FadeMode = /*#__PURE__*/ function(FadeMode) {
    FadeMode[FadeMode["Black"] = 0] = "Black";
    FadeMode[FadeMode["White"] = 1] = "White";
    return FadeMode;
}({});
export class Scene {
    enterState = -1;
    palette = createPalette();
    dispose() {}
}
function applyFade(scene, mode, level) {
    scene.render();
    if (mode === 0) setPaletteDarken(scene.palette, 0, 255, level);
    else setPaletteWhiten(scene.palette, 0, 255, level);
    present();
}
export async function fadeIn(scene, mode) {
    for(let i = 0; i <= 20; i++){
        applyFade(scene, mode, i * 5);
        await sleep(i % 2 === 0 ? 16 : 15);
    }
    setPalette(scene.palette);
}
export async function fadeOut(scene, mode, vol0, volStep) {
    for(let i = 20; i >= 0; i--){
        setBGMVolume(vol0 - Math.trunc((20 - i) * volStep / 2));
        applyFade(scene, mode, i * 5);
        await sleep(i % 2 === 0 ? 16 : 15);
    }
}

export function __logicState(){return {FadeMode};}

export function __installInitialRoots(s){
FadeMode=s["FadeMode"];
}
