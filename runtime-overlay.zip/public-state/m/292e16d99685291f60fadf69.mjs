import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./7b1ab9c36f2b6b5ca7dcee6a.mjs";
import { registerChildren, registerStates } from "./c2c7a57dacaa46758b7f3f58.mjs";
import { frameCount, frameDuration, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
function rfCost(c) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
}
function effect21(c, f) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.w0dc = 4;
        c.b0de = 0xec;
        c.vx = 0.0;
        c.w16c = 1;
        c.backWindow = 0;
        c.freeze = 0x3c;
        f.w04 = 0x28;
        f.x = Math.trunc(c.x) + c.facing * 10;
        f.y = Math.trunc(c.y) - 0x28;
        f.b20 = 2;
        f.b21 = 1;
        f.b2c = 0x13;
        frameEffect(f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function spawn400(c, f) {
    f.w04 = 0x190;
    f.x = c.facing * 0x1e + c.x;
    f.y = c.y + -65.0;
    f.b18 = c.facing;
    f.b20 = 2;
    f.b21 = 1;
    f.d28 = 0;
    frameChild(c, f);
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 4 && c.timer === 0) {
            c.voiceRequest = 0;
            c.meter = s16(c.meter + 0x14);
            f.d00 = 1;
            f.b20 = 0;
            c.f3138 = c.random(0, 9) & 0xffff;
            if (c.f3150 === 0) {
                f.w04 = 0x193;
                c.f3150 = 1;
                c.f313c = 5;
            } else if (c.f3150 === 1) {
                f.w04 = 0x194;
                c.f3150 = 2;
                c.f313c = 3;
            } else if (c.f3150 === 2) {
                f.w04 = 0x192;
                c.f3150 = 0;
                c.f313c = 3;
            }
            for(c.f3140 = 0; c.f3140 < c.f313c; c.f3140++){
                f.x = c.facing * 0x28 + c.x;
                const y = c.y + -57.0;
                f.y = y - (c.random(0, 0x14) & 0xffff);
                f.b18 = c.facing;
                f.b21 = 1;
                f.d28 = 1;
                frameChild(c, f);
            }
            spawn400(c, f);
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 4 && c.timer === 0) {
            c.voiceRequest = 0;
            c.meter = s16(c.meter + 0x14);
            f.d00 = 1;
            f.b20 = 0;
            c.f3138 = c.random(0, 9) & 0xffff;
            if (c.f3150 === 0) {
                f.x = c.facing * 0x46 + c.x;
                f.w04 = 0x196;
                c.f3150 = 1;
                c.f313c = 1;
            } else if (c.f3150 === 1) {
                f.w04 = 0x197;
                f.x = c.facing * 0x28 + c.x;
                c.f3150 = 2;
                c.f313c = 3;
            } else if (c.f3150 === 2) {
                f.w04 = 0x198;
                f.x = c.facing * 0x28 + c.x;
                c.f3150 = 0;
                c.f313c = 1;
            }
            for(c.f3140 = 0; c.f3140 < c.f313c; c.f3140++){
                f.y = c.y + -67.0;
                if (c.f3150 === 0) {
                    const y = c.y + -57.0;
                    f.y = y - (c.random(0, 0x14) & 0xffff);
                }
                f.d28 = 1;
                f.b18 = c.facing;
                f.b21 = 1;
                frameChild(c, f);
            }
            spawn400(c, f);
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function burst252(c, f, setB20) {
    c.voiceRequest = 0;
    c.meter = s16(c.meter + 0xa);
    f.d00 = 1;
    if (setB20) f.b20 = 0;
    c.f3138 = c.random(0, 9) & 0xffff;
    if (c.f3138 < 4) {
        f.x = c.facing * 0x46 + c.x;
        f.w04 = 0x196;
        c.f313c = 1;
    }
    if (c.f3138 < 8 && c.f3138 > 3) {
        f.x = c.facing * 0x28 + c.x;
        f.w04 = 0x197;
        c.f313c = 3;
    }
    if (c.f3138 > 7) {
        f.x = c.facing * 0x28 + c.x;
        f.w04 = 0x198;
        c.f313c = 1;
    }
    for(c.f3140 = 0; c.f3140 < c.f313c; c.f3140++){
        f.y = c.y + -67.0;
        if (c.f3138 < 8 && c.f3138 > 3) {
            const y = c.y + -57.0;
            f.y = y - (c.random(0, 0x14) & 0xffff);
        }
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
    }
    spawn400(c, f);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        if (c.y === 0.0) c.stopMotion();
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.f3140 = 0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 4 && c.timer === 0) burst252(c, f, true);
        if (c.frame === 8 && c.timer === 0) burst252(c, f, false);
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function rushTail(c, dur, cnt, jumpVx, jumpVy) {
    if (c.frame < 0x13 && c.y < 0.0) {
        if (c.frame > 0xa) c.vy = c.vy + c.ay;
        if (c.y + c.vy >= 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.frame = 0x13;
            c.timer = 0;
            return;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 1) c.d168 = 0;
        if (c.frame === 6) {
            c.meter = s16(c.meter + 0x19);
            c.vx = jumpVx;
            c.vy = jumpVy;
            c.ay = 0.035;
            c.voiceRequest = 3;
        }
        if (c.frame === 7) {
            c.vx = 0.5;
            c.vy = -0.2;
        }
        if (c.frame === 0xb && c.f3138 < 3) {
            c.frame = 9;
            c.f3138 = c.f3138 + 1;
        }
        if (c.frame === 0x13) c.frame = 0x11;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function rushCancelWindow(c) {
    return (c.frame === 9 || c.frame === 0xa) && c.d168 === 3;
}
function rush(c, clearAy, next, jumpVx, jumpVy) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.f3138 = 0;
        c.w16c = 1;
        c.vx = 0.0;
        c.vy = 0.0;
        if (clearAy) c.ay = 0.0;
        else c.ax = 0.0;
    }
    if (rushCancelWindow(c) && (c.command === 0x14 || c.command === 0x15)) {
        c.onStateChange();
        c.state = next;
        c.facing = -c.facing;
        return;
    }
    rushTail(c, dur, cnt, jumpVx, jumpVy);
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.f3138 = 0;
        c.f313c = 0;
        c.w16c = 1;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        effect21(c, f);
        c.startAfterimage(3);
        rfCost(c);
    }
    if (rushCancelWindow(c) && c.command === 0x16) {
        c.onStateChange();
        c.state = 0x102;
        c.facing = -c.facing;
        return;
    }
    rushTail(c, dur, cnt, 9.0, -3.6);
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.w16c = 1;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (rushCancelWindow(c) && c.command === 0x16) {
        if (c.f313c < 3) {
            c.facing = -c.facing;
            c.f313c = c.f313c + 1;
            c.f3138 = 0;
            c.frame = 0;
            c.timer = 0;
            return;
        }
        c.onStateChange();
        c.state = 0xfe;
        c.facing = -c.facing;
        return;
    }
    rushTail(c, dur, cnt, 9.0, -3.6);
}
function airTurn(c, is259) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.f3138 = 0;
        c.w16c = 1;
        c.vx = -c.vx;
        c.ay = 0.035;
    }
    if (c.frame > 3 && c.y < 0.0) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy >= 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.onStateChange();
            c.state = 0xd;
            return;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 1) c.d168 = 0;
        if (c.frame === 3 && c.timer === 0) {
            c.vy = -1.0;
            c.voiceRequest = 4;
            const o = c.opponent;
            if (!is259) {
                if (!(c.y - o.y - 50.0 >= 3.0) && !(c.y - o.y - 50.0 <= -3.0)) return;
                if (!(c.y - o.y - 50.0 >= 10.0) && !(c.y - o.y - 50.0 <= -10.0)) {
                    c.frame = 4;
                } else {
                    c.frame = 5;
                }
            } else {
                if (!(c.y - o.y - 40.0 >= 8.0) && !(c.y - o.y - 40.0 <= -8.0)) {
                    c.frame = 4;
                } else {
                    c.frame = 5;
                }
            }
            return;
        }
        if (c.frame === 4 && c.timer === 0) c.frame = 6;
        if (c.frame === 5 && c.timer === 0) c.frame = 6;
        if (c.frame >= cnt) c.frame = c.frame - 2;
    }
}
function grab(c, step, cap, capSet, next, is267) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        if (is267) {
            c.w16c = 4;
            c.f3138 = 0;
            c.f313c = 0;
            effect21(c, f);
            c.startAfterimage(3);
            rfCost(c);
        } else {
            c.w16c = 1;
        }
    }
    if (c.frame === 3 && c.timer === 0) c.voiceRequest = 5;
    if (c.frame > 4 && c.frame < 7) {
        c.f3138 = c.f3138 + step;
        if (c.f3138 > cap) c.f3138 = capSet;
        c.d0d0 = 1;
        if (c.facing * 0x39 + c.x < o.x && c.facing === 1) {
            c.pushToOpponent = c.f3138 * 0.01 * -o.facing;
        }
        if (c.facing * 0x39 + c.x > o.x && c.facing === -1) {
            c.pushToOpponent = c.f3138 * 0.01 * o.facing;
        }
    }
    if (c.frame > 4 && c.d168 === 3) {
        if (c.facing === 1 && c.x < 100.0) c.x = 100.0;
        if (c.facing === -1 && c.x > 540.0) c.x = 540.0;
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        o.d128 = 1;
        f.w04 = 0;
        f.x = Math.trunc(c.x) + c.facing * 0x39;
        f.y = Math.trunc(c.y) - 0x2f;
        f.b20 = 2;
        f.d00 = 1;
        f.b21 = 1;
        frameEffect(f);
        c.state = next;
        o.state = 0x79;
        o.y = 0.0;
        o.x = c.facing * 0x39 + c.x;
        o.facing = c.facing;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (is267 && c.frame === 7 && c.f313c < 3) {
            c.f313c = c.f313c + 1;
            c.frame = c.frame - 1;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function spawnDebris(c, f, pattern) {
    f.w04 = pattern;
    f.d00 = 1;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y);
    f.b20 = 0;
    f.b21 = 1;
    f.b18 = c.facing;
    frameChild(c, f);
}
function toss(c, knockY, damage) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.frame === 0xb || c.frame === 0xc) {
        c.vy = c.vy + 0.03;
        if (c.y + c.vy >= 0.0) {
            c.stopMotion();
            c.y = 0.0;
            c.onStateChange();
            c.state = 0xd;
            return;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 7 && c.timer === 0) c.voiceRequest = 6;
        if (c.frame === 0xb && c.timer === 0) {
            c.shakeScreen(4, 0xa);
            c.vx = 1.2;
            c.vy = -1.25;
            o.y = -50.0;
            o.x = c.x - c.facing * 0x46;
            o.onStateChange();
            o.stopMotion();
            o.state = 0x3f;
            o.knockX = 0.0;
            o.knockY = knockY;
            applyDirectDamage(c, damage, 500.0);
            c.voiceRequest = 7;
            o.d128 = 1;
            f.w04 = 0x48;
            f.x = Math.trunc(c.x) - c.facing * 0x46;
            f.y = Math.trunc(c.y) - 0x3c;
            f.b20 = 2;
            f.d00 = 1;
            f.b21 = 1;
            frameEffect(f);
            spawnDebris(c, f, 0x19d);
            spawnDebris(c, f, 0x19e);
        }
        if (c.frame >= cnt) c.frame = c.frame - 2;
    }
}
registerStates({
    249: state249,
    250: state250,
    251: state251,
    252: state252,
    253: (c)=>rush(c, false, 0xff, 2.0, -0.85),
    254: (c)=>airTurn(c, false),
    255: (c)=>rush(c, true, 0x103, 3.5, -1.4),
    256: (c)=>rush(c, false, 0xff, 3.0, -1.25),
    257: state257,
    258: state258,
    259: (c)=>airTurn(c, true),
    263: (c)=>grab(c, 3, 0x5b, 0x5a, 0x108, false),
    264: (c)=>toss(c, -2.5, 0x5dc),
    265: (c)=>grab(c, 4, 0x79, 0x78, 0x10a, false),
    266: (c)=>toss(c, -2.5, 0x5dc),
    267: (c)=>grab(c, 6, 0x96, 0x96, 0x10c, true),
    268: (c)=>toss(c, -3.5, 0x6d6)
});
function child400(c, i) {
    const ch = c.children[i];
    ch.vx = 0.0;
    ch.vy = 0.0;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function convert(c, ch, voice, pattern) {
    c.voiceRequest = voice;
    ch.pattern = pattern;
    ch.shadow = 0;
    ch.blend = 2;
    ch.frame = 0;
    ch.timer = 0;
    ch.vx = 0.0;
    ch.vy = 0.0;
}
function spawnTrail(c, ch, dx) {
    const f = childSpawnFrame;
    f.w04 = 0x19b;
    f.x = Math.trunc(ch.x - ch.facing * dx);
    f.y = Math.trunc(ch.y);
    f.b20 = 0;
    f.b21 = 1;
    f.b18 = ch.facing;
    frameChild(c, f);
}
function freeIfOut(c, i) {
    const ch = c.children[i];
    if (ch.x < -100.0 || ch.x > 800.0 || ch.y < -480.0) c.freeChild(i);
}
function shot(c, i, p) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        c.a3164[i] = 0;
        ch.vx = (c.random(0, p.vxRnd) & 0xffff) * 0.05 + p.vxBase;
        ch.vy = p.vyBase - (c.random(0, p.vyRnd) & 0xffff) * p.vyMul;
        ch.hitsLeft = 1;
        ch.hitState = 0;
    }
    if (ch.frame === 0 && ch.hitState !== 0 || p.groundHit && ch.y >= 0.0) {
        convert(c, ch, p.voice, p.next);
        return;
    }
    if (ch.frame === 0) {
        c.a3164[i] = c.a3164[i] - 1;
        if (c.a3164[i] <= 0) {
            spawnTrail(c, ch, p.trailDx);
            c.a3164[i] = 5;
        }
    }
    if (p.accel !== null) ch.vx = ch.vx + p.accel;
    if (p.dampVy) {
        if (ch.vy < -0.1) ch.vy = ch.vy + 0.01;
        if (ch.vy > 0.1) ch.vy = ch.vy - 0.01;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 1) {
            convert(c, ch, p.voice, p.next);
            return;
        }
        if (ch.frame >= childCount) c.freeChild(i);
    }
    freeIfOut(c, i);
}
function child406(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    if (ch.frame === 0 && ch.timer === 0) {
        c.a3164[i] = 0;
        ch.vx = (c.random(0, 10) & 0xffff) * 0.05 + 1.5;
        ch.hitsLeft = 1;
        ch.hitState = 0;
    }
    if (ch.frame === 1 && ch.hitState !== 0) {
        convert(c, ch, 2, 0x195);
        c.shakeScreen(3, 3);
        f.w04 = 0x1ae;
        f.x = Math.trunc(ch.x);
        f.y = Math.trunc(ch.y);
        f.b18 = ch.facing;
        f.b20 = 2;
        f.w04 = 0x1af;
        frameChild(c, f);
        frameChild(c, f);
        f.w04 = 0x1b2;
        frameChild(c, f);
        frameChild(c, f);
        frameChild(c, f);
        frameChild(c, f);
        f.d00 = 1;
        f.b21 = 1;
        frameChild(c, f);
        frameChild(c, f);
        frameChild(c, f);
        frameChild(c, f);
        return;
    }
    if (ch.frame === 1) {
        c.a3164[i] = c.a3164[i] - 1;
        if (c.a3164[i] <= 0) {
            spawnTrail(c, ch, 0x4b);
            c.a3164[i] = 5;
        }
    }
    ch.vx = ch.vx + 0.005;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 2) {
            convert(c, ch, 2, 0x195);
            f.w04 = 0x1ae;
            f.x = Math.trunc(ch.x);
            f.y = Math.trunc(ch.y);
            f.d00 = 1;
            f.b20 = 0;
            f.b21 = 1;
            f.b18 = ch.facing;
            frameChild(c, f);
            frameChild(c, f);
            frameChild(c, f);
            frameChild(c, f);
            return;
        }
        if (ch.frame >= childCount) c.freeChild(i);
    }
    freeIfOut(c, i);
}
function burst408(c, ch, b20, with431) {
    const f = childSpawnFrame;
    convert(c, ch, 2, 0x199);
    f.w04 = 0x1ae;
    f.x = Math.trunc(ch.x);
    f.y = Math.trunc(ch.y);
    f.d00 = 1;
    f.b20 = b20;
    f.b21 = 1;
    f.b18 = ch.facing;
    frameChild(c, f);
    frameChild(c, f);
    frameChild(c, f);
    frameChild(c, f);
    if (with431) {
        f.w04 = 0x1af;
        frameChild(c, f);
        frameChild(c, f);
        frameChild(c, f);
        frameChild(c, f);
    }
}
function child408(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 1.5;
        ch.vy = 0.0;
        ch.hitsLeft = 1;
        ch.hitState = 0;
    }
    ch.vy = ch.vy + 0.015;
    if (ch.frame === 0 && (ch.hitState !== 0 || ch.y + ch.vy >= 0.0)) {
        burst408(c, ch, 2, true);
        c.shakeScreen(5, 5);
        return;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 1) {
            burst408(c, ch, 0, false);
            c.shakeScreen(3, 3);
            return;
        }
        if (ch.frame >= childCount) c.freeChild(i);
    }
    freeIfOut(c, i);
}
function child411(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function debris(c, i, falling) {
    const ch = c.children[i];
    if (falling) {
        if (ch.frame === 0 && ch.timer === 0) {
            ch.vx = 1.5;
            ch.vy = -2.5;
        }
        ch.vy = ch.vy + 0.035;
    }
    ch.timer++;
    if (ch.hitState === 1) c.freeChild(i);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
registerChildren({
    400: child400,
    402: (c, i)=>shot(c, i, {
            vxRnd: 10,
            vxBase: 1.25,
            vyRnd: 8,
            vyMul: 0.05,
            vyBase: 0.2,
            accel: 0.005,
            dampVy: false,
            groundHit: false,
            voice: 1,
            next: 0x191,
            trailDx: 10
        }),
    403: (c, i)=>shot(c, i, {
            vxRnd: 5,
            vxBase: 1.4,
            vyRnd: 0x14,
            vyMul: 0.1,
            vyBase: 1.0,
            accel: null,
            dampVy: false,
            groundHit: true,
            voice: 1,
            next: 0x191,
            trailDx: 10
        }),
    404: (c, i)=>shot(c, i, {
            vxRnd: 10,
            vxBase: 0.0,
            vyRnd: 10,
            vyMul: 0.1,
            vyBase: 0.5,
            accel: 0.015,
            dampVy: true,
            groundHit: false,
            voice: 1,
            next: 0x191,
            trailDx: 10
        }),
    406: child406,
    407: (c, i)=>shot(c, i, {
            vxRnd: 10,
            vxBase: 0.0,
            vyRnd: 0xf,
            vyMul: 0.1,
            vyBase: 0.75,
            accel: 0.01,
            dampVy: true,
            groundHit: false,
            voice: 2,
            next: 0x195,
            trailDx: 0x14
        }),
    408: child408,
    411: child411,
    413: (c, i)=>debris(c, i, false),
    414: (c, i)=>debris(c, i, true)
});
