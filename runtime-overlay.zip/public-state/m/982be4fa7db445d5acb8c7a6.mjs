import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { childCount, childDuration, frameChild, frameEffect, openSpawnFrame } from "./d2cd6c2c9053eff29ff0ef4e.mjs";
import { registerChildren, registerStates } from "./2997ced5c6273385064924f8.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
function mirrorIfLeft(c) {
    return c.facing === -1 ? 1 : 0;
}
function mirrorIfRight(c) {
    return c.facing === 1 ? 1 : 0;
}
function rfCostEffect(c, f) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = ftol(c.x);
    f.y = ftol(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function endFacing(c, s) {
    c.state = s;
    c.faceOpponent();
    c.onStateChange();
}
function shot401(c, f, high) {
    c.voiceRequest = 1;
    f.w04 = 0x191;
    f.x = c.facing * 0x23 + c.x;
    f.y = high ? -80.0 : -20.0;
    f.b18 = c.facing;
    f.b20 = 2;
    f.d00 = 1;
    f.b21 = 1;
    frameChild(c, f);
    c.f314c = c.f314c + 1;
    f.w04 = 0x1f;
    f.x = ftol(c.x);
    if (high) {
        f.y = ftol(c.y);
        f.b20 = 0;
        f.b21 = 0;
        f.d1c = mirrorIfRight(c);
    } else {
        f.y = ftol(c.y) + 8;
        f.b20 = 0;
        f.b21 = 1;
        f.d1c = mirrorIfLeft(c);
    }
    frameEffect(f);
}
function shotSingle(c, high) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 4 && c.timer === 0) shot401(c, f, high);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame >= cnt) endFacing(c, 0);
    }
}
function state250(c) {
    shotSingle(c, false);
}
function state251(c) {
    shotSingle(c, true);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        rfCostEffect(c, f);
    }
    if (c.frame === 4 && c.timer === 0) shot401(c, f, false);
    if (c.frame === 8 && c.timer === 0) shot401(c, f, true);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function grabConfirm(c) {
    if (c.frame === 5 || c.frame === 6) {
        if (c.d168 === 3) {
            c.frame = 7;
            c.timer = 0;
            c.d168 = 0;
        }
    }
}
function grabCarry(c, f, facingFirst, throwState, damage, proration) {
    if (c.frame !== 7 && c.frame !== 8) return;
    const o = c.opponent;
    if (!(c.f3140 > 0)) {
        f.w04 = 0x22;
        let v = ftol(c.x);
        v = v + c.facing * 0xa;
        v = v - (c.random(0, 8) & 0xffff);
        f.x = v;
        v = ftol(c.y);
        v = v + 3;
        v = v - (c.random(0, 6) & 0xffff);
        f.y = v;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.f3140 = 2;
    }
    c.f3140 = c.f3140 - 1;
    c.biasCameraY(0x32, 0x1e);
    o.state = 0x68;
    o.onStateChange();
    o.stopMotion();
    o.y = 0.0;
    if (facingFirst) {
        o.facing = -c.facing;
        o.x = (27.0 + c.vx) * c.facing + c.x;
        o.y = c.y - 50.0;
    } else {
        o.x = (27.0 + c.vx) * c.facing + c.x;
        o.y = c.y - 50.0;
        o.facing = -c.facing;
    }
    if (!(c.x > 580.0 && c.facing === 1 || c.x < 60.0 && c.facing === -1)) return;
    if (c.x > 580.0 && c.facing === 1) c.x = 600.0;
    if (c.x < 60.0 && c.facing === -1) c.x = 40.0;
    c.timer = 0;
    c.frame = 9;
    c.stopMotion();
    o.onStateChange();
    o.state = throwState;
    o.x = (c.facing === 1 ? 1 : 0) * 0x280;
    o.y = -1.0;
    o.knockX = -2.0;
    o.knockY = -0.9;
    applyDirectDamage(c, damage, proration);
    o.hitstop = 0x5a;
    c.shakeScreen(6, 9);
    f.w04 = 0;
    f.x = c.facing * 0x19 + c.x;
    f.y = -41.0;
    f.b20 = 2;
    f.b21 = 1;
    f.b2c = 0x24;
    frameEffect(f);
    c.voiceRequest = 0;
    c.d168 = 3;
}
function grabRecover(c) {
    if (c.frame > 0xb && c.frame < 0x13) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.y = 0.0;
            c.vx = c.vx * 0.5;
            c.vy = 0.0;
            c.frame = 0x13;
            c.timer = 0;
            return true;
        }
    }
    if (c.frame > 0x12) {
        c.vx = c.vx - 0.025;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    return false;
}
function grabAdvanceTail(c, cnt, loops) {
    if (c.frame === 7 && c.f3138 < loops) {
        c.frame = c.frame - 2;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame === 7) c.frame = 0x13;
    if (c.frame === 9) c.frame = c.frame - 2;
    if (c.frame === 0xc) {
        c.vx = -2.0;
        c.vy = -1.5;
        c.ay = 0.035;
    }
    if (c.frame >= cnt) {
        c.state = 3;
        c.onStateChange();
    }
}
function dashEffect(c, f) {
    c.vx = 1.8;
    f.w04 = 0x1f;
    f.x = ftol(c.x) + c.facing * 0xa;
    f.y = ftol(c.y) + 4;
    f.b20 = 0;
    f.b21 = 1;
    f.d1c = mirrorIfLeft(c);
    frameEffect(f);
}
function grabBasic(c, loops) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
    }
    grabConfirm(c);
    grabCarry(c, f, false, 0x3b, 0x3b6, 900.0);
    if (grabRecover(c)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 4) dashEffect(c, f);
        grabAdvanceTail(c, cnt, loops);
    }
}
function state253(c) {
    grabBasic(c, 1);
}
function state254(c) {
    grabBasic(c, 2);
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
        rfCostEffect(c, f);
    }
    grabConfirm(c);
    if (c.frame === 5 || c.frame === 7) {
        if (!(c.f313c > 0)) {
            f.w04 = 0x1f;
            f.x = ftol(c.x);
            f.y = ftol(c.y) + 4;
            f.b20 = 0;
            f.b21 = 1;
            f.d1c = mirrorIfLeft(c);
            frameEffect(f);
            c.f313c = 0xf;
        }
    }
    c.f313c = c.f313c - 1;
    grabCarry(c, f, true, 0x40, 0x546, 750.0);
    if (grabRecover(c)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 4) c.vx = 2.9;
        grabAdvanceTail(c, cnt, 4);
    }
}
function state256(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.meter = s16(c.meter + 0x23);
    }
    if (c.d168 === 6 && c.frame < 6) {
        c.f3150 = c.opponent.state;
        c.onStateChange();
        c.state = 0x12b;
        c.d168 = 0;
        c.freeze = 0xa0;
        c.seRequest = 3;
        c.voiceRequest = 2;
        f.w04 = 0;
        f.x = ftol(c.x) + c.facing * 0xa;
        f.y = ftol(c.y) - 0x28;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        f.w04 = 9;
        f.x = ftol(c.x) + c.facing * 0xa;
        f.y = ftol(c.y) - 0x28;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.opponent.d128 = 1;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function state299(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.biasCameraY(0x32, 3);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 1) {
        o.onStateChange();
        o.x = c.facing * 0x23 + c.x;
        o.y = -57.0;
        o.state = 0x65;
    }
    if (c.frame === 2) {
        o.x = c.facing * 0x15 + c.x;
        o.y = -68.0;
        o.state = 0x67;
        o.onStateChange();
    }
    if (c.frame === 3) {
        o.x = c.x - c.facing * 0x1b;
        o.y = -88.0;
        o.state = 0x3b;
        applyDirectDamage(c, 0x258, 750.0);
        o.onStateChange();
        o.stopMotion();
        o.facing = c.facing;
        o.knockX = -0.8;
        o.knockY = -2.0;
    }
    if (c.frame === 0xa) c.facing = -c.facing;
    if (c.frame === 0xb || c.frame === 0xd || c.frame === 0xf || c.frame === 0x11) c.seRequest = 0x14;
    if (c.frame === 0x13) c.seRequest = 0x1a;
    if (c.frame >= cnt) endFacing(c, 0);
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 1 && c.timer === 0) {
        c.w16c = 3;
        c.meter = s16(c.meter + 0x28);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.vy = -3.0;
        c.ay = 0.045;
        c.vx = 2.0;
    }
    if (c.y < 0.0) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - 0.05;
        if (c.vx < 0.0) c.vx = 0.0;
        if (c.y + c.vy > 0.0) {
            c.stopMotion();
            c.y = 0.0;
            c.timer = 0;
            c.frame = 9;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) endFacing(c, 3);
    }
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.w16c = 3;
        c.meter = s16(c.meter + 0x28);
    }
    if (c.frame === 3 && c.timer === 0) {
        c.vy = -3.0;
        c.ay = 0.045;
        c.vx = 2.0;
    }
    if (c.y < 0.0) {
        c.vx = c.vx - 0.05;
        if (c.vx < 0.0) c.vx = 0.0;
        c.vy = c.vy + c.ay;
        if (c.y + c.vy > 0.0) {
            c.stopMotion();
            c.y = 0.0;
            c.timer = 0;
            c.frame = 0xb;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2) {
            f.w04 = 0x1a5;
            f.x = c.x;
            f.y = c.y + 25.0;
            f.b18 = c.facing;
            f.b20 = 2;
            f.d00 = 1;
            f.b21 = 1;
            frameChild(c, f);
        }
        c.d168 = 0;
        if (c.frame === 0xb) c.frame = c.frame - 2;
        if (c.frame >= cnt) endFacing(c, 3);
    }
}
function spawnDiveChild(c, f, pattern) {
    f.w04 = pattern;
    f.x = ftol(c.x);
    f.y = ftol(c.y);
    f.b20 = 2;
    f.b21 = 1;
    f.b18 = c.facing;
    frameChild(c, f);
}
function diveLanding(c) {
    if (c.y + c.vy > 0.0 && c.frame > 3 && c.frame < 7) {
        c.stopMotion();
        c.timer = 0;
        c.y = 0.0;
        c.frame = 7;
        c.seRequest = 9;
        return true;
    }
    return false;
}
function diveAdvance(c, dur, cnt, loops) {
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 3 && c.f3138 < loops) {
            c.frame = c.frame - 2;
            c.f3138 = c.f3138 + 1;
        }
        if (c.frame === 7) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.voiceRequest = 8;
        c.stopMotion();
        c.w16c = 1;
        spawnDiveChild(c, f, 0x193);
    }
    if (c.frame === 3 && c.timer === 0) {
        c.vx = 1.3;
        c.vy = 1.3;
        spawnDiveChild(c, f, 0x194);
    }
    if (diveLanding(c)) return;
    diveAdvance(c, dur, cnt, 1);
}
function state260(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.voiceRequest = 8;
        c.stopMotion();
        c.w16c = 2;
        spawnDiveChild(c, f, 0x193);
    }
    if (c.frame > 2 && c.d168 === 2) {
        c.onStateChange();
        c.stopMotion();
        c.state = 0x10c;
        return;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.vx = 1.5;
        c.vy = 1.5;
        spawnDiveChild(c, f, 0x194);
    }
    if (diveLanding(c)) return;
    diveAdvance(c, dur, cnt, 3);
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0 && c.f313c === 0) {
        c.voiceRequest = 9;
        c.stopMotion();
        c.w16c = 1;
        spawnDiveChild(c, f, 0x193);
        rfCostEffect(c, f);
        c.f313c = c.f313c + 1;
    }
    if (c.frame === 3 && c.timer === 0) {
        spawnDiveChild(c, f, 0x194);
        c.vx = 1.7;
        c.vy = 1.7;
        c.w16c = 2;
    }
    if (diveLanding(c)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 3 && c.f3138 < 5) {
            c.frame = 1;
            c.f3138 = c.f3138 + 1;
        }
        if (c.frame === 7) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 3;
        }
    }
}
function dustEffect(c, f) {
    f.w04 = 0x1f;
    f.x = ftol(c.x);
    f.y = ftol(c.y) + 4;
    f.b20 = 0;
    f.b21 = 1;
    f.d1c = mirrorIfLeft(c);
    frameEffect(f);
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.meter = s16(c.meter + 0x28);
        c.voiceRequest = 6;
        c.vx = 4.0;
        dustEffect(c, f);
    }
    if (c.vx > 0.0) {
        c.vx = c.vx - 0.14;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function hopAttack(c, f) {
    if (c.frame === 2 && c.timer === 0) c.voiceRequest = 6;
    if (c.timer === 0 && (c.frame === 4 || c.frame === 8)) {
        c.meter = s16(c.meter + 0x14);
        if (c.frame === 4) {
            c.vx = 1.0;
            c.vy = -1.5;
            c.ay = 0.05;
        }
        dustEffect(c, f);
        c.w16c = 1;
    }
    if (c.frame > 2 && c.frame < 8) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.timer = 0;
            c.frame = 8;
            return true;
        }
    }
    return false;
}
function state263(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (hopAttack(c, f)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 7) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
        }
    }
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 3;
        rfCostEffect(c, f);
    }
    if (hopAttack(c, f)) return;
    if (c.frame === 0xd && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.frame === 0xf && c.timer === 0) {
        c.meter = s16(c.meter + 0x14);
        c.seRequest = 0x15;
        c.vx = 4.0;
        dustEffect(c, f);
    }
    if (c.vx > 0.0 && c.y === 0.0) {
        c.vx = c.vx - 0.14;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 7) c.d168 = 0;
        if (c.frame === 0xe) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function airShot(c, pattern, dy) {
    const dur = frameDuration(c);
    const f = openSpawnFrame();
    c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.vy > 0.0 && c.frame > 6) {
        c.onStateChange();
        c.stopMotion();
        c.frame = 9;
        c.y = 0.0;
        return;
    }
    if (c.frame === 5 && c.timer === 0) {
        c.voiceRequest = 1;
        f.w04 = pattern;
        f.x = c.facing * 0x28 + c.x;
        f.y = c.y - dy;
        f.b18 = c.facing;
        f.b20 = 2;
        f.d00 = 1;
        f.b21 = 1;
        frameChild(c, f);
        c.f314c = c.f314c + 1;
        c.vy = -1.4;
        c.ay = 0.025;
        c.vx = -0.5;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 9 && c.f313c < 3) {
            c.frame = c.frame - 2;
            c.f313c = c.f313c + 1;
        }
        if (c.frame >= 9) {
            c.onStateChange();
            c.state = 9;
        }
    }
}
function state265(c) {
    airShot(c, 0x192, 60.0);
}
function state266(c) {
    airShot(c, 0x1a3, 40.0);
}
function state267(c) {
    airShot(c, 0x1a4, 40.0);
}
function state268(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.035;
    if (c.frame === 0 && c.timer === 0) {
        c.b15a = 1;
        c.b159 = 1;
        c.vy = -1.4;
        c.vx = -0.6;
        if (c.b158 === 1) c.b158 = 0;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.state = 9;
            c.onStateChange();
        }
    }
    if (!(c.y + c.vy < 0.0) && c.frame > 3) {
        c.y = 0.0;
        c.seRequest = 9;
        endFacing(c, 0xd);
    }
}
function state315(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 1 && c.timer === 0) {
        c.freeze = 0x78;
        c.meter = s16(c.meter - 0xbb8);
        c.superDarken(0xb0, 3);
        f.w04 = 0x46;
        f.b2c = 0x40;
        f.x = ftol(c.x) - c.facing * 0x18;
        f.y = ftol(c.y) - 0x2b;
        f.b20 = 2;
        f.d00 = 1;
        f.b21 = 1;
        frameEffect(f);
        c.seRequest = 0x25;
        f.w04 = 0x47;
        frameEffect(f);
    }
    if (c.frame > 3) c.showAltBackground(0xf);
    if ((c.frame === 0xb || c.frame === 0xc) && c.d168 === 3) {
        c.stopMotion();
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 0x13c;
        o.hitstop = 0x1e;
        o.state = 0x6b;
        c.x = (s16(o.pointsX[0]) + 0xf) * c.facing + o.x;
        c.y = o.y + 46.0 + s16(o.pointsY[0]);
        o.facing = -c.facing;
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y) - 0x35;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        return;
    }
    if (c.frame === 0xb || c.frame === 0xc) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.timer = 0;
            c.frame = 0xd;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 0xa) {
            c.x = o.x;
            c.y = o.y - 100.0;
            f.w04 = 0x19e;
            f.x = ftol(c.x);
            f.y = c.y - 60.0;
            f.b20 = 0;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        if (c.frame === 0xb) {
            c.ay = 0.035;
            c.vy = 1.0;
        }
        if (c.frame === 0xc || c.frame === 0xd) {
            c.w16c = 1;
        } else {
            c.w16c = 0;
        }
        if (c.frame === 0xd) c.frame = c.frame - 2;
        if (c.frame >= cnt) endFacing(c, 3);
    }
}
function state316(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame > 0) c.showAltBackground(0xf);
    if (o.state === 0x63) o.timer = 0;
    o.biasCameraY(0x32, 3);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 2) {
        c.x = o.x;
        c.y = 0.0;
        c.shakeScreen(6, 0);
        o.state = 0x62;
        o.y = 0.0;
        o.stopMotion();
        o.onStateChange();
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b2c = 2;
        f.b21 = 1;
        frameEffect(f);
    }
    if (c.frame === 0xa || c.frame === 0x10 || c.frame === 0x16 || c.frame === 0x19 || c.frame === 0x1c) {
        f.w04 = 0x19f;
        f.x = ftol(c.x);
        f.y = 0.0;
        f.b20 = 2;
        f.b21 = 0;
        f.b18 = c.facing;
        frameChild(c, f);
    }
    if (c.frame === 0xa || c.frame === 0xd || c.frame === 0x10 || c.frame === 0x13 || c.frame === 0x16 || c.frame === 0x19) {
        applyDirectDamage(c, 0x64, 998.0);
        c.shakeScreen(2, 0);
        o.w140 = 18000;
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b2c = 2;
        f.b21 = 1;
        frameEffect(f);
        o.hitstop = 0x1e;
    }
    if (c.frame === 0xf && c.f3138 < 0x16) {
        c.frame = c.frame - 6;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame === 0x1c) {
        applyDirectDamage(c, 0x32, 999.0);
        o.w140 = 0;
        c.shakeScreen(6, 0);
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b2c = 0x24;
        f.b21 = 1;
        frameEffect(f);
        o.hitstop = 0x1e;
    }
    if (c.frame >= cnt) endFacing(c, 0);
}
registerStates({
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    265: state265,
    266: state266,
    267: state267,
    268: state268,
    299: state299,
    315: state315,
    316: state316
});
function childAdvance(c, i, free) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame < childCount) return false;
    if (free) c.freeChild(i);
    else ch.frame = 0;
    return true;
}
function floatShot(c, i, ax, ay) {
    const ch = c.children[i];
    if (ch.frame === 0 && c.a3154[i] === 0) {
        ch.hitsLeft = 1;
        c.a3154[i] = 1;
        ch.vx = 0.1;
    }
    if (c.a3154[i] < 6) ch.vx = ch.vx + ax;
    if (ay !== 0 && c.a3154[i] < 6) ch.vy = ch.vy + ay;
    if (c.a3154[i] === 6) ch.vy = ch.vy + 0.035;
    if (ch.vx > 2.0) ch.vx = 2.0;
    if (ch.hitState > 1 && ch.hitsLeft === 0) {
        ch.vx = -1.0;
        ch.vy = -1.5;
        ch.hitState = 0;
        c.a3154[i] = 6;
    }
    if (gs.viewLeft - 0x14 > ch.x || gs.viewRight + 0x14 < ch.x || ch.y > 60.0) {
        c.freeChild(i);
        c.f314c = c.f314c - 1;
    }
    if (childAdvance(c, i, false) && c.a3154[i] < 5) c.a3154[i] = c.a3154[i] + 1;
}
function child401(c, i) {
    floatShot(c, i, 0.013, 0);
}
function child402(c, i) {
    floatShot(c, i, 0.013, 0);
}
function child419(c, i) {
    floatShot(c, i, 0.01, 0.006);
}
function child420(c, i) {
    floatShot(c, i, 0.007, 0.012);
}
function child403(c, i) {
    const ch = c.children[i];
    ch.y = c.y;
    ch.x = c.x;
    if (!((c.state === 0x103 || c.state === 0x104 || c.state === 0x105) && c.frame <= 2)) c.freeChild(i);
    childAdvance(c, i, false);
}
function child404(c, i) {
    const ch = c.children[i];
    ch.y = c.y;
    ch.x = c.x;
    if (!((c.state === 0x103 || c.state === 0x104 || c.state === 0x105) && c.y < 0.0)) c.freeChild(i);
    childAdvance(c, i, false);
}
function child414(c, i) {
    childAdvance(c, i, true);
}
function child415(c, i) {
    childAdvance(c, i, true);
}
function child421(c, i) {
    const ch = c.children[i];
    if (c.a3154[i] === 0) {
        c.a3154[i] = c.a3154[i] + 1;
        c.voiceRequest = 7;
    }
    ch.x = c.x;
    ch.y = c.y + 25.0;
    if (c.state !== 0x102) c.freeChild(i);
    ch.timer++;
    if (c.hitstop > 0) ch.timer--;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    401: child401,
    402: child402,
    403: child403,
    404: child404,
    414: child414,
    415: child415,
    419: child419,
    420: child420,
    421: child421
});
