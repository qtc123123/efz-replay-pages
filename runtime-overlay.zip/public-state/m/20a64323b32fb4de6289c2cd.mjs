import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { registerChildren } from "./6eb1fb66adb5d5a47cd5c7ec.mjs";
import { abortChildWalk, childCount, childDuration, childSpawnFrame, frameChild } from "./746d3a93e9a50814987814cf.mjs";
import { ftol, s8 } from "./7596266716c972d06fe8897a.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
function cloneDash(c) {
    if (c.f3144 === 0 && c.f314c === 1) {
        c.pressed[3] = 1;
        c.inputX = s8((rnd(c, 0, 2) === 0 ? 1 : 0) * c.facing);
    }
}
function idle0(c) {
    return c.f3144 === 0 && c.f314c === 0 ? 1 : 0;
}
function idle1(c) {
    return c.f3144 === 0 && c.f314c === 1 ? 1 : 0;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = s8(rnd(c, 0, 2) - 1);
}
function cmd40(c, hi) {
    c.command = rnd(c, 0, hi) + 40;
    if (c.d168 === 3 && c.rfGauge > 500.0) c.command = 42;
}
export function thinkMai(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 0xaa ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 0x95 && c.state < 0x9d ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking * 2 + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40 * c.aiLevel > r && c.state > 0xc7) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 0xc8) c.aiMode = 0;
        return;
    }
    if (o.state === 0x60) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 0x32 && c.state <= 0x96 && c.timer === 0) {
        c.aiMode = 8 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 0x32 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 0xf0) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 0x140) < dx ? 1 : 0;
        if (o.state > 0xc7 && o.state < 0xfa && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 0xa && c.state <= 0xc) && c.y === 0.0) return;
    if (o.state >= 0x32 && o.state < 0x96 && c.state === 0x108 && c.w16c > 1) return;
    if (c.state === 0xa8 && c.timer < 6) {
        if (o.state !== 0xc8 && o.state !== 0xcc && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx < 60.0 && chance(c, 3)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && chance(c, 3)) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 100.0 && chance(c, 3)) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
        }
        if ((o.state === 0xc9 || o.state === 0xca || o.state === 0xcd) && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx < 80.0 && chance(c, 3) && c.rfGauge > 500.0) {
                c.command = 0x2a;
                return;
            }
            if (dx < 120.0 && chance(c, 3) && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 2) + 0x64;
                return;
            }
        }
    }
    if (c.state === 0xa8 || c.state === 0xa9) {
        if (dx < 120.0) {
            if (dx < 60.0 && chance(c, 3)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && chance(c, 3)) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (chance(c, 3) && c.meter >= 0x3e8) {
                c.command = 0x6e;
                return;
            }
            if (dx < 100.0 && chance(c, 3)) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 80.0 && chance(c, 3) && c.rfGauge > 500.0) {
                c.command = 0x2a;
                return;
            }
            if (dx < 120.0 && chance(c, 3) && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 2) + 0x64;
                return;
            }
        }
        if (dx < 160.0) {
            if (chance(c, 3) && c.meter >= 0x3e8) {
                c.command = 0x6e;
                return;
            }
            if (chance(c, 3) && c.rfGauge > 500.0) {
                c.command = 0x2a;
                return;
            }
            if (chance(c, 3) && c.rfGauge > 500.0) {
                c.command = 0x20;
                return;
            }
        }
        if (dx < 220.0 && dx > 160.0) {
            if (c.aiLevel + c.aiLevel > rnd(c, 0, 100) && c.meter === 0xbb8) {
                c.command = 0x66;
                return;
            }
            if (c.aiLevel + c.aiLevel > rnd(c, 0, 100)) {
                c.command = 0x28;
                return;
            }
            if (chance(c, 3) && c.y === 0.0) {
                c.pressed[1] = 1;
                c.inputX = c.facing;
                return;
            }
            if (chance(c, 3) && c.y === 0.0) {
                c.pressed[2] = 1;
                c.inputX = c.facing;
                return;
            }
        }
        if (dx > 220.0 && c.aiLevel + c.aiLevel > rnd(c, 0, 100)) {
            c.command = 0x28;
            return;
        }
    }
    if (c.state === 0xaa && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5)) {
            c.aiMode = 3;
            return;
        }
        if (dy < 70.0 && dx < 80.0 && chance(c, 5) && c.rfGauge > 500.0) {
            c.command = 0x16;
            return;
        }
        if (dy < 60.0 && dx < 70.0 && chance(c, 5)) {
            c.command = 0x14;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -60.0 && dx < 80.0 && chance(c, 5)) {
            c.pressed[0] = 1;
            return;
        }
        if (dy < 40.0 && dx < 120.0 && chance(c, 5)) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -60.0 && dx < 80.0 && chance(c, 5)) {
            c.pressed[2] = 1;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y === 0.0 && 15 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0 && dx < 90.0 && o.y === 0.0) {
            c.command = 0x48;
            return;
        }
        if (c.aiRoll < 7 && c.rfGauge > 500.0 && dx < 70.0) {
            c.command = 0x20;
            return;
        }
        if (c.aiRoll < 0x11 && c.aiRoll > 0xc && c.meter >= 0x3e8 && dx < 140.0) {
            c.command = rnd(c, 0, 2) + 0x6e;
            return;
        }
        if (c.aiRoll < 0x12 && c.aiRoll > 0x16 && c.meter >= 0x3e8 && dx < 100.0) {
            c.command = rnd(c, 0, 2) + 0x64;
            return;
        }
        if (c.aiRoll < 0x1e) {
            c.aiMode = 2;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y < 0.0 && 15 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 0x1e) {
            c.aiMode = 2;
            return;
        }
        if (dx < 100.0 && c.aiRoll < 0x16 && c.rfGauge > 500.0) {
            c.command = 0x16;
            return;
        }
        if (dx < 100.0 && c.aiRoll < 0x2a) {
            c.command = 0x14;
            return;
        }
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 8 * c.aiLevel > rnd(c, 0, 100) && o.state > 0x95 && o.state < 0x9d && (c.state === 0xfa || c.state === 0xfb || c.state === 0xfc || c.state === 0x100 || c.state === 0x12f || c.state === 0x130 || c.state === 0x131)) {
        c.command = 0x34;
        return;
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 1.0 * c.aiLevel > rnd(c, 0, 100) && c.d168 === 3 && (c.state === 0x100 || c.state === 0xd4 && dx < 60.0)) {
        c.command = 0x34;
        return;
    }
    if ((c.state === 0xfe || c.state === 0xff) && c.f3144 === 0 && c.f314c === 1 && chance(c, 5)) {
        c.pressed[3] = 1;
        c.inputX = c.facing;
        return;
    }
    if (c.state === 0x60 && dx < 120.0 && c.f3144 === 0 && c.f314c === 1 && chance(c, 5)) {
        c.pressed[3] = 1;
        c.inputX = c.facing;
        return;
    }
    if (o.state > 0x3a && o.state < 0x9d && c.f314c === 0 && chance(c, 5)) {
        c.pressed[3] = 1;
        c.inputX = 0;
        c.inputY = 0;
        return;
    }
    if (c.aiMode > 0 && c.state > 0x31 && c.state < 0x9e) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 0xc8) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = s8(rnd(c, 0, 2) - 1);
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = c.facing === 1 ? 1 : 0;
            if (c.state === 0xa5) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 0x32) {
        c.command = c.facing === 1 ? 1 : 0;
        if (c.state === 0xa3) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6) {
        if (c.y === 0.0) {
            c.inputY = -1;
            c.inputX = c.facing;
        }
        if (c.y < 0.0) c.command = 0x14;
        if (c.state === 0xfa) {
            c.aiMode = 0;
            cloneDash(c);
        }
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && 25 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.state === 0xc8) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 160.0 && c.aiRoll < 0xa) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x64 && c.aiRoll < 0x190) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x190 && c.aiRoll < 0x1b8) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x384 - idle0(c) * 0xc8) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x2bb - idle1(c) * 0x12c) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xc9) {
            if (o.y < 0.0 && c.aiRoll < 0xc8 && c.d168 === 3) {
                c.inputX = c.facing;
                c.inputY = -1;
                return;
            }
            if (dx < 50.0 && c.d168 === 2 && c.aiRoll < 0x96 && rnd(c, 0, 3) === 0) {
                c.aiMode = 6;
                c.inputY = 0;
                c.pressed[0] = 0;
            }
            if (o.y < 0.0 && c.aiRoll > 0xc8 && c.aiRoll < 0x1f4) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0x82 && c.f314c === 0) {
                c.pressed[3] = 1;
                c.inputX = 0;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x82 && c.aiRoll < 0x190 && dx < 140.0) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x190 && c.aiRoll < 0x1cc && dx < 140.0) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x23a - (c.f314c === 1 ? 1 : 0) * 0x96 && c.aiRoll < 0x2a8) {
                cmd40(c, 2);
                return;
            }
            if (c.aiRoll > 0x1cc && c.aiRoll < 0x230 && o.y === 0.0 && dx < 100.0 && c.f314c === 0) {
                c.command = 0x1e;
                return;
            }
            if (c.aiRoll > 0x384 - idle0(c) * 0xc8) {
                startJump(c);
                cloneDash(c);
                return;
            }
            if (c.aiRoll > 0x2bc - idle0(c) * 0xc8) {
                c.aiMode = 1;
                cloneDash(c);
            }
        }
        if (c.state === 0xca) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && dx < 90.0) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x12c && c.aiRoll < 0x1f4 && dx > 150.0) {
                c.pressed[1] = 1;
                c.inputY = 0;
                c.inputX = c.facing;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x1f4 && c.aiRoll < 0x258 && c.f314c === 0) {
                c.pressed[3] = 1;
                c.inputX = 0;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll < 0x64 && dx < 110.0) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x64 && c.aiRoll < 0x12c) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x12c && c.aiRoll < 0x1c2 && o.y === 0.0) {
                c.command = 0x1e;
                if (dx > 120.0) c.command = 0x1f;
                return;
            }
            if (c.aiRoll > 0x23a && c.aiRoll < 0x26c) {
                cmd40(c, 1);
                return;
            }
            if (c.aiRoll > 0x384 - idle0(c) * 0xc8) {
                startJump(c);
                cloneDash(c);
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                cloneDash(c);
            }
        }
        if (c.state === 0xcb) {
            if (c.aiRoll > 0xc8 && c.aiRoll < 0x1f4 && c.f314c === 0) {
                c.pressed[3] = 1;
                c.inputX = 0;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0x12c && o.y === 0.0) {
                c.pressed[2] = 1;
                c.inputX = c.facing;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x1f4 && c.aiRoll < 0x226 && o.y === 0.0) {
                c.command = 0x1e;
                if (dx > 120.0) c.command = 0x1f;
                return;
            }
            if (c.aiRoll > 0x28a && c.aiRoll < 0x2bc) {
                cmd40(c, 1);
                return;
            }
            if (c.aiRoll > 0x28a && c.aiRoll < 0x2bc) {
                cmd40(c, 2);
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                cloneDash(c);
            }
        }
        if (c.state === 0xcc) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && dx < 50.0) {
                c.pressed[0] = 1;
                c.inputY = 1;
                if (rnd(c, 0, 3) === 0) {
                    c.aiMode = 6;
                    c.inputY = 0;
                    c.pressed[0] = 0;
                }
                return;
            }
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 50.0 && c.aiRoll < 0x190) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x384 - idle0(c) * 0x64) {
                startJump(c);
                cloneDash(c);
                return;
            }
            if (c.aiRoll > 0x320) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcd) {
            if (c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll < 0x190 && dx > 140.0 && o.y === 0.0) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll < 0x190 && c.aiRoll < 0x1f4 && dx < 100.0) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x226 - (c.f314c === 1 ? 1 : 0) * 0x96 && c.aiRoll < 0x2bc) {
                cmd40(c, 2);
                return;
            }
            if (c.aiRoll > 0x384 - idle0(c) * 0xc8 && c.d168 === 3) {
                startJump(c);
                return;
            }
            if (c.aiRoll > 0x384 - idle0(c) * 0xc8) {
                c.aiMode = 1;
                cloneDash(c);
                return;
            }
        }
        if (c.state === 0xce) {
            if (c.aiRoll > 0xc8 && c.aiRoll < 0x1f4 && c.f314c === 0) {
                c.pressed[3] = 1;
                c.inputX = 0;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0x12c) {
                c.command = 0x1f;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x190 && c.rfGauge > 500.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x226 - (c.f314c === 1 ? 1 : 0) * 0x96 && c.aiRoll < 0x2bc) {
                cmd40(c, 2);
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcf) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                return;
            }
            if (dx < 60.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x18f && c.aiRoll < 0x2bc) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x2bb - idle1(c) * 0x12c) {
                c.aiMode = 1;
                if (rnd(c, 0, 4) === 0) c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd0) {
            if (c.aiRoll > 0x50 && c.aiRoll < 0x12c) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd1) {
            if (c.aiRoll > 0x3b6) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
    }
    if (25 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 0x63) {
                if (dx < 40.0 && o.y === 0.0 && c.aiRoll < 3) {
                    c.pressed[2] = 1;
                    c.inputX = s8(-c.facing);
                    c.inputY = 0;
                    return;
                }
                if (dx < 60.0 && o.state < 0x32 && o.state < 0xa8 && c.aiRoll < 5) {
                    c.aiMode = 6;
                    return;
                }
                if (dx < 50.0) {
                    const blocking = o.state > 0x95 && o.state < 0x9d ? 1 : 0;
                    if (c.aiRoll < blocking * 0x32 + 0x19 && o.state < 0xc8) {
                        c.pressed[0] = 1;
                        c.inputY = 1;
                        return;
                    }
                }
                if (dx < 80.0 && c.aiRoll < 0xa && c.meter >= 0x3e8 && o.state > 0xc7) {
                    c.command = rnd(c, 0, 2) + 0x64;
                    return;
                }
                if (dx > 80.0 && dx < 120.0 && c.aiRoll < 0x14) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 130.0 && dx > 80.0 && c.aiRoll < 0x1e && c.aiRoll > 0xf) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 150.0 && dx > 90.0 && c.aiRoll < 0x1e && c.aiRoll > 0x14) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 200.0 && dx > 160.0 && c.aiRoll < 0x2d && c.aiRoll > 0x1e) {
                    c.pressed[1] = 1;
                    if (rnd(c, 0, 2) === 0) {
                        c.pressed[1] = 0;
                        c.pressed[2] = 1;
                    }
                    c.inputY = 0;
                    c.inputX = c.facing;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 180.0 && dy > 90.0 && c.aiRoll < 0x1e) {
                        c.inputY = -1;
                        c.inputX = s8(-c.facing);
                        return;
                    }
                    if (dx > 130.0 && dy < 180.0 && dy > 90.0 && c.aiRoll > 0x1e && c.aiRoll < 0x46) {
                        c.inputY = -1;
                        c.inputX = s8(-c.facing);
                        return;
                    }
                    if (dx < 150.0 && dx > 60.0 && c.aiRoll > 0x46 && c.aiRoll < 0x6e) {
                        c.pressed[0] = 1;
                        c.inputX = c.facing;
                        c.inputY = 0;
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 80.0 && dy < 180.0 && dy > 90.0 && c.aiRoll < 0x1e) {
                        c.inputY = -1;
                        c.inputX = s8(-c.facing);
                        return;
                    }
                    if (dx > 130.0 && dy < 180.0 && dy > 90.0 && c.aiRoll > 0x1e && c.aiRoll < 0x46) {
                        c.inputY = -1;
                        c.inputX = s8(-c.facing);
                        return;
                    }
                    if (dx < 150.0 && dx > 60.0 && dy > 130.0 && c.aiRoll > 0x46 && c.aiRoll < 0x6e) {
                        c.pressed[1] = 1;
                        c.inputY = 1;
                        return;
                    }
                    if (dx < 100.0 && dy > 160.0 && dy < 240.0 && c.aiRoll > 0 && c.aiRoll < 0x8c) {
                        c.pressed[2] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx < 140.0 && dx > 90.0 && dy > 90.0 && c.aiRoll > 0xa0 && c.aiRoll < 0xdc) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx < 130.0 && dy < 80.0 && c.aiRoll > 0xdc && c.aiRoll < 0x12c && c.rfGauge > 500.0) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 100.0 && dy < 100.0 && c.aiRoll < (o.y === 0.0 ? 1 : 0) * 0x64 + 0x64) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 140.0 && dy < 80.0 && c.aiRoll > 0xc8 && c.aiRoll < 0x104) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 140.0 && dx > 80.0 && dy > 40.0 && dy < 80.0 && c.aiRoll > 0x104 && c.aiRoll < 0x109) {
                    c.pressed[2] = 1;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 120.0 && dy < 90.0 && o.y > c.y && c.aiRoll < 0x6e) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 140.0 && dy < 90.0 && c.aiRoll < 0xd2) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 150.0 && dx > 100.0 && dy < 90.0 && o.y > c.y && c.aiRoll < 0x9c4) {
                    c.pressed[2] = 1;
                    return;
                }
            }
        }
    }
    if (c.state < 0x32 && (o.state > 0x95 && o.state < 0x9c || o.state > 0x31 && o.state < 0x3b) && c.y === 0.0) {
        const k = c.f3144 === 1 && c.f314c === 1 && (o.state > 0x95 && o.state < 0x9d || o.state > 0x31 && o.state < 0x3b) ? 1 : 0;
        const r = rnd(c, 0, 100);
        const m = (o.state === 0x63 ? 1 : 0) * 4 + k * 2 + 1;
        if (m * c.aiLevel > r && dx > 80.0) {
            c.command = c.facing === 1 ? 1 : 0;
            return;
        }
    }
    if (c.state < 0x32 && o.state < 0x32 && dx > 60.0 && dx < 140.0 && 2 * c.aiLevel > rnd(c, 0, 100) && c.x > 120.0 && c.x < 520.0 && c.f314c === 0) {
        c.command = c.facing !== 1 ? 1 : 0;
        return;
    }
    if (rnd(c, 0, 1000) < (c.f314c === 1 ? 1 : 0) + 2) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 160.0 && c.y === 0.0 && rnd(c, 0, 100) < 3) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 100.0 && c.y === 0.0 && rnd(c, 0, 100) < 2 && o.state < 0xa8) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 170.0 && dx > 120.0 && c.y === 0.0) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 0xf) c.aiTimer1a0 = 0xf;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 0xf) c.aiTimer1a4 = 0xf;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 0x3c && dx < 150.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x3c;
        else c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x3c;
    }
    if (rnd(c, 0, 100) < 0x28) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x1e;
        else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x1e;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x1e;
    else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x1e;
}
function tick(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function advanceFree(c, i) {
    const ch = c.children[i];
    if (!tick(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child418(c, i) {
    advanceFree(c, i);
}
function child421(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 1.1;
        ch.vy = -1.0;
        ch.ay = 0.04;
        ch.hitsLeft = 1;
    }
    ch.vy = ch.vy + ch.ay;
    if (ch.hitState === 1 || !(ch.y < 0.0)) {
        ch.pattern = 402;
        ch.blend = 1;
        ch.frame = 0;
        ch.timer = 0;
        abortChildWalk();
        return;
    }
    if (tick(c, i)) {
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            ch.frame = 0;
            ch.timer = 1;
        }
    }
    if (ch.x < -100.0 || ch.x > 800.0 || ch.y < -480.0) c.freeChild(i);
}
function child422(c, i) {
    const ch = c.children[i];
    ch.vy = ch.vy + ch.ay;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.8;
        ch.vy = -0.5;
        ch.ay = 0.03;
    }
    if (tick(c, i)) {
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            ch.frame = 0;
            ch.timer = 1;
        }
    }
    if (ch.x < -100.0 || ch.x > 800.0 || ch.y > 50.0) c.freeChild(i);
}
function child423(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.vx = c.f3140;
        c.a3158[i]++;
        ch.hitsLeft = 1;
    }
    ch.vy = ch.vy + 0.045;
    if (tick(c, i)) {
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
    if (!(ch.y + ch.vy < 0.0)) {
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 424;
        c.seRequest = 0x12;
    }
}
function child424(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 7;
    }
    advanceFree(c, i);
}
function child425(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.vx = c.f3140 - (c.f3140 > 5 ? 1 : 0) * 5;
        c.a3158[i]++;
        ch.hitsLeft = 1;
    }
    ch.vy = ch.vy + 0.045;
    if (tick(c, i)) {
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
    if (!(ch.y + ch.vy < 0.0)) {
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 426;
    }
}
function child433(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    advanceFree(c, i);
}
function child434(c, i) {
    advanceFree(c, i);
}
function cloneRush(c, i, dashVx, decel, mode3150) {
    const ch = c.children[i];
    c.f3144 = 2;
    if (c.state > 0x31 && c.state < 0x96 || ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 402;
        ch.frame = 0;
        ch.timer = 0;
        abortChildWalk();
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = 0.0;
    }
    if (ch.frame === 2 && ch.timer === 0) ch.vx = dashVx;
    if (ch.frame > 3) {
        ch.vx = ch.vx - decel;
        if (ch.vx < 0.2) ch.vx = 0.2;
    }
    if (c.opponent.x - ch.x < 120.0 && ch.facing === 1 && ch.frame === 3) {
        ch.timer = 0;
        ch.frame = 4;
        return;
    }
    if (ch.x - c.opponent.x < 120.0 && ch.facing === -1 && ch.frame === 3) {
        ch.timer = 0;
        ch.frame = 4;
        return;
    }
    if (ch.x > 600.0) {
        ch.x = 600.0;
        ch.vx = 0.0;
    }
    if (ch.x < 40.0) {
        ch.x = 40.0;
        ch.vx = 0.0;
    }
    if (!tick(c, i)) return;
    if (ch.frame === 10 && c.a3158[i] < 2) {
        ch.frame -= 2;
        c.a3158[i]++;
    }
    ch.hitState = 0;
    if (ch.frame >= childCount) {
        c.f3150 = mode3150;
        c.f3144 = 3;
        c.f3148 = 1200;
        c.a3158[i] = 0;
        c.a3258[i] = 0;
        ch.frame = 0;
        ch.vx = 0.0;
        c.freeChild(i);
    }
}
function child435(c, i) {
    cloneRush(c, i, 5.25, 0.4, 1);
}
function child436(c, i) {
    const ch = c.children[i];
    c.f3144 = 2;
    if (c.state > 0x31 && c.state < 0x96 || ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 402;
        ch.frame = 0;
        ch.timer = 0;
        abortChildWalk();
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) ch.vx = 0.0;
    if (ch.frame === 4 && ch.timer === 0) {
        const f = childSpawnFrame;
        f.w04 = 0x1c6;
        f.x = ftol(ch.facing * 0x24 + ch.x);
        f.y = ftol(ch.y - 60.0);
        f.d00 = 1;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = ch.facing;
        frameChild(c, f);
    }
    if (ch.x > 600.0) {
        ch.x = 600.0;
        ch.vx = 0.0;
    }
    if (ch.x < 40.0) {
        ch.x = 40.0;
        ch.vx = 0.0;
    }
    if (!tick(c, i)) return;
    if (ch.frame === 7 && c.a3158[i] < 3) {
        ch.frame -= 2;
        c.a3158[i]++;
    }
    ch.hitState = 0;
    if (ch.frame >= childCount) {
        c.f3144 = 3;
        c.f3150 = 1;
        c.f3148 = 1200;
        c.a3158[i] = 0;
        c.a3258[i] = 0;
        ch.frame = 0;
        ch.vx = 0.0;
        c.freeChild(i);
    }
}
function child437(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 3;
    if (ch.frame === 7 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.vx = 0.7;
        c.a3158[i]++;
    }
    if (ch.hitState > 0 && ch.hitsLeft === 0 && ch.frame < 40) {
        ch.timer = 0;
        ch.frame = 40;
        return;
    }
    if (ch.x > 740.0 || ch.x < -100.0) {
        c.freeChild(i);
        return;
    }
    if (!tick(c, i)) return;
    ch.hitState = 0;
    if (ch.frame === 40 && ch.hitsLeft > 1) {
        ch.frame = 18;
        ch.hitsLeft--;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child451(c, i) {
    cloneRush(c, i, 4.0, 0.15, 4);
}
function child453(c, i) {
    const ch = c.children[i];
    if (c.state > 0x31 && c.state < 0x96 || c.f3144 === 3) {
        if (ch.frame < 30) {
            ch.frame = 30;
            return;
        }
    }
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 2;
    if (!tick(c, i)) return;
    if (ch.frame === 1 || ch.frame === 18) ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child454(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
    }
    if (!tick(c, i)) return;
    if (ch.frame === 2) ch.hitState = 0;
    if (ch.frame === 4) ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    418: child418,
    421: child421,
    422: child422,
    423: child423,
    424: child424,
    425: child425,
    426: child424,
    433: child433,
    434: child434,
    435: child435,
    436: child436,
    437: child437,
    451: child451,
    453: child453,
    454: child454
});
