// Bounded inspector for the recovered extension writer layout, not producer authentication.
import {PROFILE,validateInitialization,integer} from "./ebf033feb11a338744b4587b.mjs";
export class RevivalRng {
 #state; #draws=0;
 constructor(state){this.#state=integer(state,1,2147483646,'saved RNG state');}
 get state(){return this.#state;} get draws(){return this.#draws;}
 restore(state,draws){
  integer(state,1,2147483646,'saved RNG state');
  if(!Number.isSafeInteger(draws)||draws<0||Object.is(draws,-0))throw Error('saved RNG draw progress');
  this.#state=state;this.#draws=draws;
 }
 next(){
  // Product < 2^47: integer binary64 arithmetic is exact here.
  do{this.#state=(this.#state*48271)%2147483647;this.#draws++;}while(this.#state-1>0x3fffffff);
  return (this.#state-1)&32767;
 }
}
export function inspectExtendedReplay(input){
 if(!(input instanceof Uint8Array)||input.length<508||input.length>64*1024*1024)throw Error('file extent');
 const bytes=new Uint8Array(input),v=new DataView(bytes.buffer),s=v.getUint32(bytes.length-8,true);
 if(v.getInt32(bytes.length-4,true)!==-1)throw Error('extension marker');
 if(s<492||s>bytes.length-16||s%2)throw Error('extension extent');
 const seed=v.getUint32(s,true),words=v.getUint32(s+4,true);
 integer(seed,1,2147483646,'saved RNG state');
 if(words===0||words%2||s+16+words*2!==bytes.length)throw Error('paired extension extent equation');
 const nativeEnd=s-480;if(nativeEnd<12||nativeEnd%2)throw Error('native body extent');
 const padding=[0,0,15,39,0,0,0,0,0,0,0,0,0,0,0,0];
 for(let i=0;i<480;i++)if(bytes[nativeEnd+i]!==padding[i%16])throw Error('extension padding mismatch');
 // Selected profile intentionally refuses other signed-low-byte header variants.
 if(v.getUint16(4,true)!==104)throw Error('unsupported marker104 header');
 const initialization=validateInitialization({profile:PROFILE,characters:[v.getUint16(0,true),v.getUint16(2,true)],stage:v.getUint16(6,true),palettes:[v.getUint16(8,true),v.getUint16(10,true)],seed,winRounds:2});
 const frames=words/2,pairsOffset=s+8;
 return Object.freeze({seed,words,frames,extensionOffset:s,nativeEnd,pairsOffset,headerBytes:12,initialization,
  pair(frame){integer(frame,0,frames-1,'frame outside recording');return [v.getUint16(pairsOffset+4*frame,true),v.getUint16(pairsOffset+4*frame+2,true)];},
  nativeTape(){return bytes.slice(0,nativeEnd);}
 });
}
