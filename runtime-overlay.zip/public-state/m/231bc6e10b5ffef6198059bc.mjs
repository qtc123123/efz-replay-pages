import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren } from "./2d89f5a5c2e93d6456ad7e4a.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame, setPolarVelocity } from "./59adbef650633f2bfaadb9d3.mjs";
import { ftol, s16, s8 } from "./7596266716c972d06fe8897a.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function dashForward(c) {
    return c.facing === 1 ? 1 : 0;
}
function jumpRandom(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = s8(rnd(c, 0, 2) - 1);
}
export function thinkKano(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25.0 * c.aiLevel + air * 0x1e * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 0x190 + (c.state === 0xaa ? 1 : 0) * 0x12c;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 0x95 && c.state < 0x9d ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40.0 * c.aiLevel > r && c.state > 0xc7) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 0xc8) c.aiMode = 0;
        return;
    }
    if (o.state === 0x60) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 0x32 && c.state <= 0x96 && c.timer === 0) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 0x32 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 0xf0) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 0x140) < dx ? 1 : 0;
        if (o.state > 0xc7 && o.state < 0xfa && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 0xa && c.state <= 0xc) && c.y === 0.0) return;
    if (o.state >= 0x32 && o.state < 0x96 && c.state === 0x108 && c.w16c > 1) return;
    if (c.state === 0xa8 && c.timer < 6) {
        if (o.state !== 0xc8 && o.state !== 0xcc && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx < 40.0 && c.aiLevel * 3.0 > rnd(c, 0, 100)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && c.aiLevel + c.aiLevel > rnd(c, 0, 100)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
        }
        if ((o.state === 0xc9 || o.state === 0xca || o.state === 0xcd) && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx > 20.0 && dx < 60.0 && c.aiLevel + c.aiLevel > rnd(c, 0, 100)) {
                c.pressed[1] = 1;
                c.inputY = 1;
                c.inputX = 0;
                return;
            }
            if (dx > 60.0 && dx < 80.0 && c.aiLevel + c.aiLevel > rnd(c, 0, 100)) {
                c.pressed[0] = 3;
                c.inputY = 1;
                return;
            }
        }
    }
    if (c.state === 0xa8 || c.state === 0xa9) {
        if (dx < 100.0) {
            if (c.aiLevel * 3.0 > rnd(c, 0, 100) && c.rfGauge > 500.0) {
                c.command = 0x16;
                return;
            }
            if (c.aiLevel * 1.0 > rnd(c, 0, 100) && c.rfGauge > 500.0) {
                c.command = 0xc;
                return;
            }
            if (c.aiLevel + c.aiLevel > rnd(c, 0, 100) && dx < 80.0 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 3) + 0x78;
                return;
            }
            if (c.aiLevel * 1.0 > rnd(c, 0, 100) && dx < 150.0 && c.meter === 0xbb8) {
                c.command = 0x5f;
                return;
            }
        }
        if (dx < 220.0) {
            if (c.aiLevel * 3.0 > rnd(c, 0, 100) && c.rfGauge > 500.0) {
                c.command = 0xc;
                return;
            }
            if (c.aiLevel * 1.0 > rnd(c, 0, 100) && c.meter === 0xbb8) {
                c.command = 0x5f;
                return;
            }
        }
        if (dx > 220.0) {
            if (c.aiLevel * 1.0 > rnd(c, 0, 100) && c.rfGauge > 500.0) {
                c.command = rnd(c, 0, 3) + 0xa;
                return;
            }
            if (c.aiLevel * 1.0 > rnd(c, 0, 100) && c.meter === 0xbb8) {
                c.command = 0x5f;
                return;
            }
        }
    }
    if (c.state === 0xaa && c.frame === 1 && c.timer === 0) {
        if (c.aiLevel * 5.0 > rnd(c, 0, 100)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -40.0 && dx < 80.0 && c.aiLevel * 5.0 > rnd(c, 0, 100)) {
            c.pressed[0] = 1;
            return;
        }
        if (c.y - o.y > -100.0 && c.y - o.y < -50.0 && dx < 100.0 && c.aiLevel * 5.0 > rnd(c, 0, 100)) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y > -100.0 && c.y - o.y < -50.0 && dx < 120.0 && c.aiLevel * 5.0 > rnd(c, 0, 100)) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return;
        }
        if (dy < 50.0 && dx < 100.0 && c.aiLevel + c.aiLevel > rnd(c, 0, 100)) {
            c.command = 0x16;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y === 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0) {
            c.command = 0x16;
            return;
        }
        if (c.aiRoll < 4 && c.rfGauge > 500.0) {
            c.command = 0xc;
            return;
        }
        if (c.aiRoll < 0x11 && c.aiRoll > 0xc && c.meter >= 0x3e8) {
            c.command = rnd(c, 0, 3) + 0x78;
            return;
        }
        if (c.aiRoll > 0x55) {
            c.aiMode = 2;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y < 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0) {
            c.command = 0x16;
            return;
        }
        if (c.aiRoll < 0x11 && c.aiRoll > 0xc && c.meter >= 0x3e8) {
            c.command = rnd(c, 0, 3) + 0x78;
            return;
        }
        if (c.aiRoll > 0x55) {
            c.aiMode = 2;
            return;
        }
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 8.0 * c.aiLevel > rnd(c, 0, 100) && o.state > 0x95 && o.state < 0x9d) {
        if (c.state === 0xfa || c.state === 0xfb || c.state === 0xfc || c.state === 0x10e || c.state === 0x10f || c.state === 0x110) {
            c.command = 0x34;
            return;
        }
    }
    if (c.aiMode > 0 && c.state > 0x31 && c.state < 0x9e) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 0xc8) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = s8(rnd(c, 0, 2) - 1);
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = dashForward(c);
            if (c.state === 0xa5) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6 && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 7;
        return;
    }
    if (c.aiMode === 7 && c.state === 0xa3) {
        c.pressed[0] = 1;
        if (c.state === 0xe6) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 8 && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 9;
        return;
    }
    if (c.aiMode === 9 && c.state === 0xa3) {
        c.pressed[1] = 1;
        if (c.state === 0xe7) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0xa && c.state < 0x32) {
        c.command = dashForward(c);
        if (c.state === 0xa3) c.aiMode = 0xb;
        return;
    }
    if (c.aiMode === 0xb && c.state === 0xa3) {
        c.pressed[2] = 1;
        if (c.state === 0xe8) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0xc && c.state < 0x32) {
        c.pressed[0] = 1;
        c.inputY = 1;
        if (c.state === 0xcc) c.aiMode = 0;
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && c.aiLevel * 25.0 > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.state === 0xc8) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 50.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                c.inputY = 0;
                if (c.d168 === 2 && rnd(c, 0, 100) < 0x1e) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                }
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x18f && c.aiRoll < 0x2bc) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x3ca) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 2) === 0) c.aiMode = 6;
                if (rnd(c, 0, 2) === 0) c.aiMode = 8;
                return;
            }
        }
        if (c.state === 0xc9) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x14;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x12b && c.aiRoll < 0x140 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 3) + 0x78;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x140 && c.aiRoll < 0x258 && c.d168 === 3) {
                c.inputX = c.facing;
                c.inputY = -1;
                return;
            }
            if (c.aiRoll < 0xc8) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0xc8 && c.aiRoll < 0x1c2 && dx < 90.0) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x1c2 && c.aiRoll < 0x2bc) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x384) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                if (rnd(c, 0, 1) === 0) {
                    c.aiMode = 6;
                    if (dx > 80.0) c.aiMode = 8;
                    return;
                }
            }
        }
        if (c.state === 0xca) {
            if (o.y < 0.0 && c.aiRoll > 0x12b && c.aiRoll < 0x140) {
                c.command = 0xa;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x140 && c.aiRoll < 0x258 && dx < 100.0) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll < 0x1f4 && c.d168 === 3 && dx < 80.0) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                if (rnd(c, 0, 1) === 0) {
                    c.aiMode = 6;
                    if (dx > 110.0) c.aiMode = 8;
                    return;
                }
            }
        }
        if (c.state === 0xcb) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = 0xa;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x12b && c.aiRoll < 0x140 && c.meter >= 0x3e8 && dx < 90.0) {
                c.command = rnd(c, 0, 3) + 0x78;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0xc8 && c.d168 === 3) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0xc8 && c.aiRoll < 0xfa) {
                c.command = rnd(c, 0, 3) + 0x1e;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x190 && c.rfGauge > 500.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x190 && c.aiRoll < 0x1ae && c.d168 === 3 && c.meter === 0xbb8) {
                c.command = 0x5f;
                return;
            }
            if (c.aiRoll > 0x1ae && c.aiRoll < 0x21c && c.d168 !== 3) {
                c.command = 0x28;
                if (dx > 120.0) c.command = 0x29;
                return;
            }
            if (c.aiRoll > 0x38e && c.d168 === 3) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcc) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 50.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                c.inputY = 0;
                if (c.d168 === 2 && rnd(c, 0, 100) < 0x14) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                }
                return;
            }
            if (dx < 135.0 && c.aiRoll < 0x258) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 1) !== 0) return;
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
                return;
            }
        }
        if (c.state === 0xcd) {
            if (o.y < 0.0 && c.aiRoll > 0x140 && c.aiRoll < 0x258 && dx < 100.0) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll < 0x64) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (c.aiRoll > 0x64 && c.aiRoll < 0x12c && dx < 100.0) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x12c && c.aiRoll < 0x258) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x384) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x2bc) {
                c.aiMode = 1;
                if (rnd(c, 0, 1) === 0) {
                    c.aiMode = 6;
                    if (dx > 110.0) c.aiMode = 8;
                }
                return;
            }
        }
        if (c.state === 0xce) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = 0xa;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x12b && c.aiRoll < 0x140 && c.meter >= 0x3e8 && dx < 90.0) {
                c.command = rnd(c, 0, 3) + 0x78;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0xc8 && c.d168 === 3) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0xc8 && c.aiRoll < 0xfa) {
                c.command = rnd(c, 0, 3) + 0x1e;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x190 && c.rfGauge > 500.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x1ae && c.aiRoll < 0x21c && c.d168 !== 3) {
                c.command = 0x28;
                if (dx > 120.0) c.command = 0x29;
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcf) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                return;
            }
            if (dx < 60.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x18f && c.aiRoll < 0x2bc) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 4) === 0) c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd0) {
            if (c.aiRoll > 0x14 && c.aiRoll < 0x3c && c.d168 === 3 && o.y < 0.0) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x50 && c.aiRoll < 0x12c) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x3b6) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd1) {
            if (c.aiRoll > 0x3b6) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xe7) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x14;
                return;
            }
            if (c.aiRoll > 0xc8 && c.aiRoll < 0xdc && dx < 90.0 && c.d168 === 3 && c.meter >= 0x3e8) {
                c.command = rnd(c, 0, 3) + 0x78;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x190 && c.rfGauge > 500.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x289 && rnd(c, 0, 2) === 0) {
                c.aiMode = 0xc;
                if (dx > 110.0) c.aiMode = 8;
            }
        }
        if (c.state === 0xe8) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = 0xa;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x12b && c.aiRoll < 0x140 && c.meter >= 0x3e8 && dx < 90.0) {
                c.command = rnd(c, 0, 3) + 0x78;
                return;
            }
            if (c.aiRoll > 0 && c.aiRoll < 0xc8 && c.d168 === 3) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0xc8 && c.aiRoll < 0xfa) {
                c.command = rnd(c, 0, 3) + 0x1e;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x190 && c.rfGauge > 500.0) {
                c.command = 0x34;
                return;
            }
            if (c.aiRoll > 0x190 && c.aiRoll < 0x1ae && c.d168 === 3 && c.meter === 0xbb8) {
                c.command = 0x5f;
                return;
            }
            if (c.aiRoll > 0x1ae && c.aiRoll < 0x21c && c.d168 !== 3) {
                c.command = 0x28;
                if (dx > 120.0) c.command = 0x29;
                return;
            }
            if (c.aiRoll > 0x38e && c.d168 === 3) {
                jumpRandom(c);
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 1;
                return;
            }
        }
    }
    if (25.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 0x63) {
                if (dx < 40.0 && o.y === 0.0 && c.aiRoll < 5) {
                    c.pressed[2] = 1;
                    c.inputX = s8(-c.facing);
                    c.inputY = 0;
                    return;
                }
                if (dx < 50.0 && c.aiRoll < 0x17) {
                    c.pressed[0] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 75.0 && c.aiRoll < 0x1e) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 0x28 && c.aiRoll > 0x1e) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 0x34 && c.aiRoll > 0x28 || dx > 80.0 && dx < 130.0 && c.aiRoll < 0x50 && c.aiRoll > 0x34) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx > 80.0 && dx < 140.0 && c.aiRoll < 0x64 && c.aiRoll > 0x50) {
                    c.aiMode = 8;
                    return;
                }
                if (dx > 70.0 && dx < 120.0 && c.aiRoll < 0x78 && c.aiRoll > 0x64) {
                    c.aiMode = 8;
                    return;
                }
                if (dx < 90.0 && dx > 70.0 && c.aiRoll < 0x82 && c.aiRoll > 0x78) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 120.0 && dx > 70.0 && c.aiRoll < 0x91 && c.aiRoll > 0x82) {
                    c.pressed[2] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx > 100.0 && dx < 140.0 && c.aiRoll < 0x98 && c.aiRoll > 0x91) {
                    c.aiMode = 0xa;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 0xa5 && c.aiRoll > 0x91 && c.rfGauge > 500.0 && o.state > 0xc7) {
                    c.command = 0x16;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 0xaa && c.aiRoll > 0xa5 && c.meter >= 0x3e8 && o.state > 0xc7) {
                    c.command = rnd(c, 0, 3) + 0x78;
                    return;
                }
                if (dx > 200.0 && c.aiRoll < 0xaa && c.aiRoll > 0xa5 && c.meter >= 0x3e8 && o.state > 0xc7) {
                    c.command = rnd(c, 0, 3) + 0x82;
                    return;
                }
                if (dx > 200.0 && c.aiRoll < 0xbe && c.aiRoll > 0xaa) {
                    c.command = rnd(c, 0, 3) + 0xa;
                    return;
                }
                if (dx > 80.0 && dx < 120.0 && c.aiRoll < 0xd2 && c.aiRoll > 0xbe) {
                    c.command = 0x28;
                    return;
                }
                if (dx > 140.0 && dx < 180.0 && c.aiRoll < 0xd2 && c.aiRoll > 0xbe) {
                    c.command = 0x29;
                    return;
                }
                if (dx > 200.0 && dx < 240.0 && c.aiRoll < 0xd2 && c.aiRoll > 0xbe) {
                    c.command = 0x2a;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < 0xa) {
                        c.inputY = -1;
                        c.inputX = s8(-c.facing);
                        return;
                    }
                    if (dx < 80.0 && c.aiRoll < 0xf && c.meter >= 0x3e8) {
                        c.command = rnd(c, 0, 3) + 0x78;
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 90.0 && dy < 140.0 && c.aiRoll < 6 && (c.rfGauge > 500.0 || c.rfBlue > 0)) {
                        c.command = 0x16;
                        return;
                    }
                    if (dx < 90.0 && dy < 140.0 && dy > 100.0 && c.aiRoll < 0x23 && c.aiRoll > 0xa) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx > 100.0 && dx < 140.0 && dy < 180.0 && dy > 140.0 && c.aiRoll < 0x3c && c.aiRoll > 0x23) {
                        c.pressed[2] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx > 100.0 && dx < 140.0 && dy < 140.0 && dy > 100.0 && c.aiRoll < 0x50 && c.aiRoll > 0x3c) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx < 80.0 && c.aiRoll < 0x6e && c.aiRoll > 0x50 && o.y < -50.0 && c.meter >= 0x3e8) {
                        c.command = rnd(c, 0, 3) + 0x78;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 80.0 && dy < 100.0 && c.aiRoll < 0x32) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx > 60.0 && dx < 120.0 && dy > 90.0 && dy < 120.0 && o.y < c.y && c.aiRoll > 0x32 && c.aiRoll < 0x78) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx > 80.0 && dx < 140.0 && dy > 100.0 && dy < 180.0 && c.aiRoll > 0x78 && c.aiRoll < 0xaa) {
                    c.pressed[2] = 1;
                    return;
                }
                {
                    const r = rnd(c, 0, 0x140);
                    if (dx - 100.0 > r && dy < 90.0 && c.aiRoll > 0xaa && c.aiRoll < 0xdc) {
                        c.command = rnd(c, 0, 3) + 0xa;
                        return;
                    }
                }
                if (dx > 100.0 && c.aiRoll > 0xf0 && c.aiRoll < 0x14a && dy + 40.0 > dx && dy - 40.0 < dx) {
                    c.command = rnd(c, 0, 3) + 0x28;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 80.0 && dy < 100.0 && c.aiRoll < 0x14) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx > 60.0 && dx < 120.0 && dy > 90.0 && dy < 120.0 && o.y < c.y && c.aiRoll > 0x14 && c.aiRoll < 0x28) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx > 80.0 && dx < 140.0 && dy > 100.0 && dy < 180.0 && c.aiRoll > 0x28 && c.aiRoll < 0x32) {
                    c.pressed[2] = 1;
                    return;
                }
                {
                    const r = rnd(c, 0, 0x140);
                    if (dx - 100.0 > r && dy < 180.0 && c.aiRoll > 0xaa && c.aiRoll < 0xf0) {
                        c.command = rnd(c, 0, 3) + 0xa;
                        return;
                    }
                }
            }
        }
    }
    if (c.state < 0x32 && (o.state > 0x95 && o.state < 0x9c || o.state > 0x31 && o.state < 0x3b) && c.y === 0.0 && 3.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.command = dashForward(c);
        return;
    }
    if (c.state < 0x32 && o.state < 0x32 && dx > 60.0 && dx < 140.0 && 2.0 * c.aiLevel > rnd(c, 0, 100) && c.x > 120.0 && c.x < 520.0) {
        c.command = c.facing !== 1 ? 1 : 0;
        return;
    }
    if (rnd(c, 0, 1000) < 2) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 180.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 170.0 && dx > 140.0 && c.y === 0.0 && o.state < 0x32) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 0xf) c.aiTimer1a0 = 0xf;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 0xf) c.aiTimer1a4 = 0xf;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 0x32 && dx < 120.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x2d;
        else c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x2d;
    }
    if (rnd(c, 0, 100) < 0x1e) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x1e;
        else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x1e;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x1e;
    else c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x1e;
}
function patFrame0(c, pattern) {
    return c.patterns[pattern]?.frames[0];
}
function drawPart(c, f, x, y, w) {
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    blit(makeRect(x, y, w, f.height), surf, makeRect(0, 0, w, f.height), c.colorKey, false);
}
export function renderOverlayKano(c) {
    if (c.f3150 === 0x2710) {
        const f = patFrame0(c, 42);
        if (f) drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - f.width, 0x1f - f.offsetY, f.width);
    }
    if (c.f3150 !== 0 && c.f3150 < 0x2710) {
        const f = patFrame0(c, 43);
        if (f) drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - f.width, 0x1f - f.offsetY, f.width);
    }
    if (c.f3150 !== 0 && c.f3150 < 0x2710) {
        const f = patFrame0(c, 44);
        if (f) {
            const w = Math.trunc(Math.imul(f.width, c.f3150) / 0x2710);
            drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - w, 0x1f - f.offsetY, w);
        }
    }
}
function meterThreshold(c) {
    return 0x1e - (0x1c - (ftol(c.meter * 0.001) << 2));
}
export function tickHookKano(c) {
    const o = c.opponent;
    const f = openSpawnFrame();
    if (o.freeze === 0 && c.state < 0x12c) c.f3154++;
    if (c.f3154 > meterThreshold(c)) {
        c.meter = s16(c.meter + 1);
        c.f3154 = 0;
    }
    if ((c.f3154 > meterThreshold(c) ? 1 : 0) * 0.5 !== 0.0 && c.state === 3) {
        c.meter = s16(c.meter + 1);
        c.f3154 = 0;
    }
    if (c.vx === 0.0 && o.freeze === 0 && c.state < 0x12c && (c.state < 0x32 || c.state > 0xc8)) c.f3158++;
    else c.f3158 = 0;
    if (c.f3158 > 0x276) {
        c.meter = s16(c.meter + 0x12c);
        c.f3158 = 0;
        f.w04 = 0x19b;
        f.x = ftol(c.x);
        f.y = c.y - 50.0;
        f.b18 = 1;
        f.b20 = 0;
        f.b21 = 1;
        frameChild(c, f);
    }
    c.f3160--;
    if (c.f315c > 0 && c.f3160 <= 0) {
        f.w04 = 0x1c3;
        let x = ftol(c.x) + 0x78;
        x -= rnd(c, 0, 0xf0);
        x -= ftol(c.f3164 * 192.0);
        f.x = x;
        f.y = -480.0;
        f.b18 = s8(c.f3164);
        f.b20 = 2;
        f.b21 = 1;
        f.d00 = 1;
        frameChild(c, f);
        c.f315c--;
        c.f3160 = 0xb4;
    }
}
function childStep(c, i) {
    const ch = c.children[i];
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childPlayOnce(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (childStep(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function childLoop(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (childStep(c, i) && ch.frame >= childCount) ch.frame = 0;
}
function child446(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    if (ch.timer === 0 && ch.frame === 0) {
        c.shakeScreen(0xa, 0xa);
        c.voiceRequest = 0x14;
        ch.hitsLeft = 1;
    }
    if (ch.frame > 8 && ch.frame < 0xb && c.a3174[i] < 6 && c.a3274[i] <= 0) {
        f.w04 = 0x1c0;
        let x = ftol(ch.x);
        x = x + rnd(c, 0, 0xa0) - 0x50;
        f.x = x;
        let y = ftol(ch.y) + 0xf;
        y -= rnd(c, 0, 0x1e);
        f.y = y;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        f.w04 = 0x1bf;
        frameChild(c, f);
        c.a3274[i] = 0x2d;
        c.a3174[i]++;
        c.shakeScreen(5, 5);
        c.voiceRequest = 0x15;
    }
    c.a3274[i]--;
    ch.x = c.x;
    ch.timer++;
    if (!childStep(c, i)) return;
    if (ch.frame === 0xb && c.frame === 0xd) ch.frame -= 2;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child447(c, i) {
    const ch = c.children[i];
    ch.x = c.x;
    childPlayOnce(c, i);
}
function child448(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    ch.timer++;
    if (!childStep(c, i)) return;
    if (ch.frame === 2) {
        f.w04 = 0x1c6;
        f.x = ftol(c.x);
        f.y = 0.0;
        f.b20 = 2;
        f.b21 = 0;
        f.b18 = c.facing;
        frameChild(c, f);
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child449(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    if (ch.timer === 0 && ch.frame === 0) c.voiceRequest = 0x16;
    if (ch.frame === 0xe && ch.timer === 0) {
        f.w04 = 0x1be;
        f.x = ftol(ch.x);
        f.y = ftol(ch.y);
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        f.w04 = 0x1bf;
        frameChild(c, f);
        c.a3274[i] = 0x2d;
        c.a3174[i]++;
        c.shakeScreen(5, 5);
    }
    ch.x = c.x;
    childPlayOnce(c, i);
}
function child450(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        c.voiceRequest = 0x17;
        ch.hitsLeft = 1;
        c.a3174[i]++;
        ch.vx = 6.0;
        ch.vy = -6.0;
    }
    if (ch.y < -1600.0) {
        c.freeChild(i);
        return;
    }
    childLoop(c, i);
}
function child451(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    if (c.a3174[i] === 0) {
        c.voiceRequest = 0x18;
        ch.hitsLeft = 1;
        c.a3174[i]++;
        setPolarVelocity(c, i, 60.0, 4.0);
    }
    if (ch.y > 0.0) {
        f.w04 = 0x1bf;
        f.x = ftol(ch.x);
        f.y = 0.0;
        f.b20 = 2;
        f.b21 = 0;
        f.b18 = s8(c.f3164);
        frameChild(c, f);
        f.w04 = 0x1c4;
        f.b21 = 1;
        f.b18 = s8(c.f3164);
        frameChild(c, f);
        f.w04 = 0x1c5;
        f.b21 = 1;
        f.b18 = s8(c.f3164);
        frameChild(c, f);
        c.freeChild(i);
        return;
    }
    childLoop(c, i);
}
function child452(c, i) {
    childPlayOnce(c, i);
}
function child453(c, i) {
    const ch = c.children[i];
    if (ch.timer === 0 && ch.frame === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 0x19;
        c.shakeScreen(0xa, 0);
    }
    childPlayOnce(c, i);
}
function child454(c, i) {
    const ch = c.children[i];
    if (ch.timer === 0 && ch.frame === 0) ch.hitsLeft = 1;
    childPlayOnce(c, i);
}
function child455(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    if (c.isHeld(0) === 0 && ch.frame < 0xf) {
        ch.frame = 0xf;
        ch.timer = 0;
        c.voiceRequest = 0x1c;
        c.voiceRequest = 6;
    }
    if (c.state > 0x31 && c.state < 0x96) {
        c.freeChild(i);
        return;
    }
    if (ch.frame < 0xf) ch.vx = ch.vx + 0.0025;
    else ch.vx = 0.0;
    if (ch.frame === 0xf && ch.timer === 0) {
        f.w04 = 0x19a;
        f.x = ftol(ch.x);
        f.y = 0.0;
        if (c.a3174[i] === 1) f.x = ch.x - c.facing * 0x2d;
        if (c.a3174[i] === 2) f.x = c.facing * 0x2d + ch.x;
        if (c.a3174[i] === 3) f.x = ch.x - c.facing * 0x5a;
        if (c.a3174[i] === 4) f.x = c.facing * 0x5a + ch.x;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
    }
    ch.timer++;
    if (!childStep(c, i)) return;
    if (ch.frame === 0xf) ch.frame = 0;
    if (ch.frame < childCount) return;
    if (c.a3174[i] < 2) {
        ch.frame--;
        c.a3174[i]++;
    } else {
        c.freeChild(i);
    }
}
function child456(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    ch.timer++;
    if (!childStep(c, i)) return;
    if (ch.frame < childCount) return;
    c.freeChild(i);
    f.w04 = 0x34;
    f.y = -87.0;
    f.x = ftol(c.facing * 0x1f + c.x);
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
    const o = c.opponent;
    o.state = 0x65;
    o.hitstop = 0x270f;
    c.voiceRequest = 0x1c;
    applyDirectDamage(c, 0x1388, 850.0);
    c.f3138 = 1;
}
registerChildren({
    446: child446,
    447: child447,
    448: child448,
    449: child449,
    450: child450,
    451: child451,
    452: child452,
    453: child453,
    454: child454,
    455: child455,
    456: child456
});
