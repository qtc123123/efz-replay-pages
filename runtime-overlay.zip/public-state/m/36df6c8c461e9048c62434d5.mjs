import {PROFILE,validateInitialization,integer} from "./ebf033feb11a338744b4587b.mjs";

// Local direct-battle playback is independent of service/checkpoint admission.
export const LOCAL_REPLAY_PROFILE='efz402-revival-local/1';
export const LOCAL_TAPE_PROFILE='efz402-native-local/1';
export function validateLocalReplayInitialization(value){
 if(!value||value.profile!==LOCAL_REPLAY_PROFILE)throw Error('unsupported local replay initialization profile');
 const winRounds=integer(value.winRounds,1,3,'local replay rounds to win');
 const base=validateInitialization({...value,profile:PROFILE,winRounds:2});
 return Object.freeze({...base,profile:LOCAL_REPLAY_PROFILE,winRounds});
}
export function validateResourceInitialization(value){
 return value?.profile===LOCAL_TAPE_PROFILE?validateLocalTapeInitialization(value):value?.profile===LOCAL_REPLAY_PROFILE?validateLocalReplayInitialization(value):validateInitialization(value);
}

export function validateLocalTapeInitialization(value){
 if(!value||value.profile!==LOCAL_TAPE_PROFILE||value.seed!==1)throw Error('unsupported native replay initialization');
 // Native replays store gameplay RNG words in the tape. The original core's
 // CRT startup state is 1; it is retained only for uncaptured presentation RNG.
 const base=validateLocalReplayInitialization({...value,profile:LOCAL_REPLAY_PROFILE});
 return Object.freeze({...base,profile:LOCAL_TAPE_PROFILE});
}

// F4 (held gauge), F5 (latched reset/cycle), and Escape are qualified
// against original contextual tape witnesses. Other command bits remain closed.
export function validateLocalReplayPair(pair){
 if(!Array.isArray(pair)||pair.length!==2)throw Error('input pair');
 for(const word of pair){
  if(!Number.isInteger(word)||word<0||word>65535)throw Error('input word');
  if(word&~0x23ff)throw Error('auxiliary command is not qualified for local playback');
 }
 return pair.slice();
}
