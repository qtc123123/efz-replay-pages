import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./c2c7a57dacaa46758b7f3f58.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./7b1ab9c36f2b6b5ca7dcee6a.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function groundJumpCancel(c, ok, checkD15c = true) {
    if (c.inputY === -1 && c.frame > 0 && (!checkD15c || c.d15c < 3) && ok) {
        c.state = 4;
        if (c.inputX === c.facing) c.state = 5;
        if (c.inputX === -c.facing) c.state = 6;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a === 0) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function attackStart(c, meter, se) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = 1;
}
function landTo13(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return true;
    }
    return false;
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function dashDust(c, d, mirror) {
    d.w04 = 0x1f;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 0;
    d.b21 = 0;
    d.d1c = mirror;
    frameEffect(d);
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0x63);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.timer = w16(c.timer + 1);
    if (c.life > 0 && c.timer > 0x63 && c.frame === 0) c.setState(0x60);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(0x60);
    }
}
function sEmpty(_c) {}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 0x99, 0x96, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 0x9a, 0x97, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 0x9b, 0x98, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 0x99, 0x96, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 0x9a, 0x97, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 0x9b, 0x98, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy += c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(0xd);
    }
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy += c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(0xd);
    }
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        d.w04 = 9;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x3c;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.w16c = 1;
        c.seRequest = 0x3e;
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 3)) {
        c.stopMotion();
        d.w04 = 9;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x3c;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.w16c = 1;
        c.seRequest = 0x3e;
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 0xd;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 0xc) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.f3138 = 0;
    }
    if (c.frame > 7) {
        c.vy += c.ay;
        if (c.y + c.vy >= 0.0) {
            c.state = 0xd;
            c.onStateChange();
            return;
        }
    }
    if (advance(c, dur)) {
        if (c.frame === 1) {
            dashDust(c, d, c.facing === -1 ? 1 : 0);
            c.seRequest = 0x11;
        }
        if (c.frame === 4) {
            c.vx = 2.0;
            c.vy = -1.0;
            c.ay = 0.01;
        }
        if (c.frame === 5 && c.inputX === c.facing && c.f3138 < 2) {
            c.f3138++;
            c.frame = 4;
        }
        if (c.frame === 8) {
            c.vy = -0.2;
            c.vx = 1.0;
            c.ay = 0.03;
        }
        if (c.frame >= cnt) c.setState(9);
    }
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 3) {
            c.seRequest = 0x11;
            dashDust(c, d, c.facing === 1 ? 1 : 0);
            c.vx = -3.0;
        }
        if (c.frame === 6) c.stopMotion();
        if (c.frame >= cnt) {
            c.onStateChange();
            c.stopMotion();
            c.state = 0;
        }
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3140 === 0) {
        c.vx = 1.8;
        c.vy = 0.0;
        c.seRequest = 0x11;
        c.f3140++;
        c.startAfterimage(3);
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 0x78) {
        c.setState(9);
        c.vx = 1.3;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
    if (c.inputX !== c.facing && c.f3138 >= 0x30) {
        c.setState(9);
        c.vx = 1.3;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3140 === 0) {
        c.vx = -1.8;
        c.vy = 0.0;
        c.seRequest = 0x11;
        c.f3140++;
        c.startAfterimage(3);
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 0x78) {
        c.setState(9);
        c.vx = -0.9;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
    if (c.inputX !== -c.facing && c.f3138 >= 0x2a) {
        c.setState(9);
        c.vx = -0.9;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 0x5a;
    c.superDarken(0xb0, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 0x12;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 0x3c;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 0xa9;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 0x12;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 7) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 7;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 1) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 0x15);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) attackStart(c, 15, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) attackStart(c, 15, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 4)) attackStart(c, 0x23, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 5) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 0x15);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atFrame(c, 2)) {
        addMeter(c, 0xd);
        c.w16c = 3;
    }
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame === 3) {
            c.d168 = 0;
            c.seRequest = 0x14;
        }
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) attackStart(c, 0x19, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 5) c.stopMotion();
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s207(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 0x15);
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s208(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 1)) {
        addMeter(c, 0xd);
        c.w16c = 5;
    }
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 2) {
            c.seRequest = 0x15;
            c.d168 = 0;
        }
        if (c.frame === 3) {
            c.seRequest = 0x15;
            c.d168 = 0;
        }
        if (c.frame === 4) {
            c.seRequest = 0x15;
            c.d168 = 0;
        }
        if (c.frame === 5) {
            c.seRequest = 0x15;
            c.d168 = 0;
        }
        if (c.frame === 7) {
            c.seRequest = 0x14;
            c.d168 = 0;
        }
        if (c.frame >= cnt) c.setState(9);
    }
}
function s209(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 3)) {
        c.f3138 = 0;
        addMeter(c, 0x1e);
        c.seRequest = 0x14;
        c.w16c = 3;
    }
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame < 5) c.d168 = 0;
        if (c.frame === 8 && c.f3138 < 2) {
            c.frame = 5;
            c.d168 = 0;
            c.f3138++;
        }
        if (c.frame >= cnt) c.setState(9);
    }
}
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) {
        c.vx = 1.4;
        c.vy = -1.5;
        c.ay = 0.08;
    }
    if (atFrame(c, 2)) attackStart(c, 15, 0x14);
    if (atFrame(c, 5)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 0) c.vy += c.ay;
    if (advance(c, dur)) {
        if (c.frame < 6) c.d168 = 0;
        if (c.frame === 5) {
            if (c.y + c.vy < 0.0) c.frame = w16(c.frame - 1);
            else c.y = 0.0;
        }
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (groundJumpCancel(c, c.d168 === 3, false)) return;
    if (atFrame(c, 3)) attackStart(c, 0x1e, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 9) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function impactFx(c, d) {
    c.shakeScreen(3, 0);
    d.w04 = 3;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 0;
    d.b2c = 7;
    frameEffect(d);
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vy += c.ay;
    if (atStart(c)) {
        attackStart(c, 0x1e, 0x14);
        c.vx = c.vx / 2.0;
        c.ay = 0.07;
    }
    if (c.d168 > 1) {
        c.setState(0xd5);
        c.stopMotion();
        return;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.vy = 0.0;
        impactFx(c, d);
        c.seRequest = 7;
        c.setState(0xd6);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) impactFx(c, d);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 0xdd;
        o.state = 0x6e;
        o.d128 = 1;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x28;
        d.y = ftol(c.y) - 0x41;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        o.state = 0x64;
        o.stopMotion();
        o.y = 0.0;
        o.x = c.facing * 0x2a + c.x;
        o.onStateChange();
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) {
            o.state = 0x79;
            o.y = 0.0;
            o.x = c.x;
        }
        if (c.frame === 2) {
            o.state = 0x7a;
            o.frame = 2;
            o.timer = 0;
            o.y = 0.0;
            o.x = c.x - c.facing * 0x28;
            d.d28 = 1;
            d.w04 = 0x1a7;
            d.x = c.x - c.facing * 0x28;
            d.y = 0.0;
            d.b18 = c.facing;
            d.b20 = 0;
            d.d00 = 1;
            d.b21 = 0;
            frameChild(c, d);
        }
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function airNormalB(c, startFrame, meter, se) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = 0.5;
        c.ay = 0.03;
    }
    if (atFrame(c, startFrame)) attackStart(c, meter, se);
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s230 = (c)=>airNormalB(c, 1, 5, 0x15);
const s231 = (c)=>airNormalB(c, 2, 0xa, 0x15);
const s232 = (c)=>airNormalB(c, 1, 0xa, 0x14);
function s240(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.vy += c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 0xf1;
        o.state = 0x64;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x16;
        d.y = ftol(c.y) - 0x44;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.x = c.facing * 0x16 + c.x;
        o.y = c.y - 68.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 0x32 || o.state > 0x95)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0xd1;
            c.frame = 1;
        }
    }
}
function s241(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame < 2) c.biasCamera(0x32, 3);
    if (c.frame < 2) c.biasCameraY(0x32, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.stopMotion();
        c.state = 0xd;
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 2) {
            d.d28 = 1;
            d.w04 = 0x1a8;
            d.x = c.facing * 0x25 + c.x;
            d.y = -56.0;
            d.b18 = c.facing;
            d.b20 = 0;
            d.d00 = 1;
            d.b21 = 1;
            frameChild(c, d);
        }
        if (c.frame === 3) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function childAdvanceEnd(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    return ch.frame >= childCount;
}
function c423(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    const d = childSpawnFrame;
    ch.vx = -3.0;
    o.facing = -ch.facing;
    o.vx = 3.0;
    if (o.wallBlock() !== 0) {
        o.onStateChange();
        o.state = 0x3b;
        o.facing = ch.facing;
        o.knockX = 0.0;
        o.knockY = -2.0;
        o.ay = 0.035;
        o.y = -59.0;
        o.d128 = 1;
        applyDirectDamage(c, 0x4b0, 500.0);
        c.shakeScreen(3, 3);
        c.seRequest = 2;
        d.w04 = 0x1a1;
        d.x = ftol(ch.x + 60.0 - c.random(0, 0x78));
        d.y = ftol(ch.y + 0.0 - c.random(0, 0x78));
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
        for(let k = 0; k < 6; k++){
            d.x = ftol(ch.x + 60.0 - c.random(0, 0x78));
            d.y = ftol(ch.y + 0.0 - c.random(0, 0x78));
            frameChild(c, d);
        }
        c.freeChild(i);
        return;
    }
    if (childAdvanceEnd(c, i)) c.freeChild(i);
}
function c424(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    const d = childSpawnFrame;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 3.0;
        o.facing = -ch.facing;
    }
    if (ch.frame === 0) {
        o.state = 0x68;
        o.facing = -ch.facing;
        o.x = ch.x + 0.0;
        o.y = ch.y;
        o.d128 = 1;
        if (ch.y + ch.vy >= 0.0) {
            ch.vy = 0.0;
            ch.y = 0.0;
            ch.timer = 0;
            ch.frame = 1;
            o.x = ch.x;
            o.y = ch.y;
            o.onStateChange();
            o.state = 0x62;
            o.facing = ch.facing;
            o.d128 = 1;
            applyDirectDamage(c, 0x4b0, 750.0);
            c.shakeScreen(3, 3);
            c.seRequest = 2;
            d.w04 = 0;
            d.x = ftol(ch.x);
            d.y = ftol(ch.y);
            d.b20 = 2;
            d.b21 = 1;
            frameEffect(d);
        }
    }
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        if (ch.frame === 2) ch.blend = 1;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    103: sEmpty,
    107: sEmpty,
    113: sEmpty,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    240: s240,
    241: s241
});
registerChildren({
    423: c423,
    424: c424
});
