import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerStates } from "./4bfdef0d515a63cf0e27cdb5.mjs";
import { frameChild, frameEffect, openSpawnFrame } from "./7d17e301343a90178a9cad8e.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function attackStart(c, meter, se) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = 1;
}
function rfDrain(c, v) {
    if (c.rfBlue !== 0) c.rfGauge -= v;
}
function landFromHit(c) {
    c.y = 0.0;
    if (c.d12c !== 0) c.setState(0x61);
    else c.setState(0x62);
}
function fxAt(c, d, pat, dx, dy, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x) + dx;
    d.y = ftol(c.y) + dy;
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function fxAtSelf(c, d, pat, blend, layer) {
    fxAt(c, d, pat, 0, 0, blend, layer);
}
function spawnNormalChild(c, pat) {
    const d = openSpawnFrame();
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 1;
    d.d00 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function impactFx(c) {
    c.shakeScreen(3, 0);
    const d = openSpawnFrame();
    d.w04 = 3;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 0;
    d.b2c = 7;
    frameEffect(d);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function jumpCancel(c, exact3) {
    if (c.inputY !== -1 || c.frame <= 0 || c.d15c >= 3) return false;
    if (exact3 ? c.d168 !== 3 : c.d168 < 2) return false;
    jumpTo456(c);
    return true;
}
function airCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a < 2) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    if (c.inputY === 0 && c.inputX !== 0 && c.frame > 0 && c.d168 >= 2 && c.b15a < 2 && c.d15c < 3) {
        c.b15a = c.b15a + 1 & 0xff;
        if (c.inputX === c.facing) c.state = 0xa5;
        if (c.inputX === -c.facing) c.state = 0xa6;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function slide(c, decel) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx -= decel;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function s81(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (atStart(c)) {
        const d = openSpawnFrame();
        d.w04 = 0x1f3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
        addMeter(c, 30);
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    c.vx += 0.02;
    c.vy += c.ay;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 1);
    if (c.y + c.vy >= 0.0 && c.frame === 1) landFromHit(c);
}
function s82(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (atStart(c) && c.f3138 === 0) {
        c.seRequest = 0x1e;
        c.vy = -0.45;
        c.vx = -0.1;
        c.f3138++;
        addMeter(c, 30);
    }
    if (atFrame(c, 4)) {
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    if (c.vy > 0.0 && c.frame === 4) {
        c.frame = 5;
        c.timer = 0;
    }
    if (c.frame > 3) c.vy += c.ay;
    if (advance(c, dur)) {
        if (c.frame === 4 && c.f3138 < 8) {
            c.frame = 0;
            c.f3138++;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.y + c.vy >= 0.0 && c.frame > 4) landFromHit(c);
}
function spawn496(c) {
    if (c.f3144 === 0) {
        const d = openSpawnFrame();
        d.w04 = 0x1f0;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 0;
        d.d00 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.f3144 = 1;
    }
}
function s83(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vy = -1.5;
        c.vx = -0.8;
        addMeter(c, 30);
    }
    c.vy += 0.04;
    if (c.frame === 0 && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.timer = 0;
        c.frame = 1;
        return;
    }
    if (c.frame === 1) c.vx += 0.01;
    if (atFrame(c, 2)) c.vx = -2.0;
    if (c.frame > 1) c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(0);
        c.faceOpponent();
    }
}
function s85(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vx = c.knockX;
        c.vy = c.knockY;
        addMeter(c, 30);
    }
    c.vy += 0.04;
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(0);
        c.faceOpponent();
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function s86(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        spawn496(c);
        if (c.f3138 === 0) {
            rfDrain(c, 30.0);
            c.seRequest = 0x21;
            c.vx = c.knockX;
            c.vy = c.knockY;
            addMeter(c, 30);
            c.f3138++;
        }
    }
    c.vy += 0.06;
    if (advance(c, dur) && c.frame >= cnt) c.frame = 0;
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function s87(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        const d = openSpawnFrame();
        d.w04 = 0x1ef;
        d.x = 60.0;
        d.y = 40.0;
        d.d24 = 1;
        d.b18 = 1;
        d.b20 = 0;
        d.b21 = 0;
        frameChild(c, d);
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        const d = openSpawnFrame();
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0x63);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.life > 0 && c.timer > 0x3c && c.frame === 0) {
        c.setState(0x60);
        c.b158 = 0;
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(0x60);
    }
}
function guardGround(c, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.b158 = 0;
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || !(c.x + 20.0 < 639.0)) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 20, -2.3, false);
function airLand(c) {
    c.y = 0.0;
    c.seRequest = 9;
    c.faceOpponent();
    c.setState(0xd);
}
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy += c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) airLand(c);
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = vx;
    c.ay = 0.045;
    c.b158 = 0;
    if (atStart(c)) {
        c.vy = -2.3;
        const d = openSpawnFrame();
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy += c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) airLand(c);
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(3);
        c.stopMotion();
    }
    if (atFrame(c, 3)) {
        c.vx = 2.0;
        c.vy = -1.0;
        c.ay = 0.02;
        c.voiceRequest = 0;
    }
    if (c.y < 0.0) {
        c.vy += c.ay;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.vy = 0.0;
            c.timer = 0;
            c.frame = 7;
            return;
        }
    }
    if (c.frame > 6) {
        c.vx -= 0.04;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 7) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) c.setState(0);
    }
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(3);
        c.stopMotion();
    }
    if (atFrame(c, 2)) {
        c.vx = -2.0;
        c.vy = -1.0;
        c.ay = 0.035;
        c.voiceRequest = 0;
    }
    if (c.y < 0.0) {
        c.vy += c.ay;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.onStateChange();
            c.stopMotion();
            c.state = 0xd;
            return;
        }
    }
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 1);
}
function airDash(c, dashFrame, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    c.f3140++;
    if (c.f3140 > c.f3148) {
        if (c.inputY === -1 && c.d15c < 3 && c.b15a < 2) {
            c.b15a = c.b15a + 1 & 0xff;
            c.state = 14;
            if (c.inputX === c.facing) c.state = 15;
            if (c.inputX === -c.facing) c.state = 16;
            c.d168 = 0;
            c.onStateChange();
            return;
        }
        if (c.inputY === 1) {
            c.setState(9);
            if (c.b15a < 2 && c.inputX !== 0 && c.d15c < 3) {
                c.b15a = c.b15a + 1 & 0xff;
                if (c.inputX === c.facing) c.state = 0x12;
                if (c.inputX === -c.facing) c.state = 0x14;
                c.d168 = 0;
                c.onStateChange();
            }
            return;
        }
        if (c.b15a < 2 && c.d15c < 3) {
            if (c.inputX === c.facing) {
                c.state = 0x11;
                c.b15a = c.b15a + 1 & 0xff;
                c.onStateChange();
                c.d168 = 0;
                return;
            }
            if (c.inputX === -c.facing) {
                c.state = 0x13;
                c.b15a = c.b15a + 1 & 0xff;
                c.onStateChange();
                c.d168 = 0;
                return;
            }
        }
    }
    if (atFrame(c, dashFrame)) {
        c.ay = 0.045;
        c.vy = -0.5;
        c.vx = vx;
        c.voiceRequest = 0;
    }
    if (c.frame >= dashFrame) c.vy += 0.01;
    if (advance(c, dur) && c.frame >= cnt) c.setState(0xa);
    if (c.y + c.vy >= 0.0 && c.frame > 3) airLand(c);
}
const s165 = (c)=>airDash(c, 3, 2.0);
const s166 = (c)=>airDash(c, 2, -2.0);
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 0x5a;
    c.superDarken(0xb0, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 0x12;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        const d = openSpawnFrame();
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 0x3c;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 0xa9;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 0x12;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx -= 0.03;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c, 0.06);
    if (jumpCancel(c, false)) return;
    if (atFrame(c, 2)) attackStart(c, 5, 0x15);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c, 0.03);
    if (atFrame(c, 1)) spawnNormalChild(c, 0x1a4);
    if (jumpCancel(c, false)) return;
    if (atFrame(c, 3)) attackStart(c, 15, 0x14);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c, 0.06);
    if (atFrame(c, 4)) attackStart(c, 15, 0x14);
    if (atFrame(c, 3)) spawnNormalChild(c, 0x1a5);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c, 0.06);
    if (jumpCancel(c, true)) return;
    if (atFrame(c, 4)) attackStart(c, 0x23, 0x23);
    if (atFrame(c, 6)) spawnNormalChild(c, 0x1a8);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c, 0.03);
    if (jumpCancel(c, false)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 0x15);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c, 0.03);
    if (jumpCancel(c, false)) return;
    if (atFrame(c, 2)) attackStart(c, 0xd, 0x14);
    if (atFrame(c, 1)) spawnNormalChild(c, 0x1a6);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.b158 === 0 && atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1 && c.frame < 3) c.vx -= 0.03;
    else c.b158 = 0;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atFrame(c, 1)) c.w16c = 1;
    if (atFrame(c, 3) && c.f3138 === 0) {
        addMeter(c, 0x19);
        c.seRequest = 0x14;
        c.f3138++;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function airNormal(c, startFrame, meter, se, resetBefore, child) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airCancel(c)) return;
    if (atFrame(c, startFrame)) attackStart(c, meter, se);
    if (child !== null && atFrame(c, child[1])) spawnNormalChild(c, child[0]);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(0xd);
        return;
    }
    if (advance(c, dur)) {
        if (c.frame < resetBefore) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s207 = (c)=>airNormal(c, 2, 5, 0x15, 3, null);
const s208 = (c)=>airNormal(c, 2, 0xd, 0x14, 4, [
        0x1a7,
        3
    ]);
const s209 = (c)=>airNormal(c, 1, 0x1e, 0x14, 3, [
        0x1a9,
        1
    ]);
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) {
        c.vx = 1.4;
        c.vy = -1.5;
        c.ay = 0.08;
    }
    if (atFrame(c, 2)) attackStart(c, 15, 0x14);
    if (atFrame(c, 5)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 0) c.vy += c.ay;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 5) {
            if (c.y + c.vy < 0.0) c.frame = w16(c.frame - 1);
            else c.y = 0.0;
        }
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (jumpCancel(c, false)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 3)) attackStart(c, 0x1e, 0x14);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (atStart(c)) {
        attackStart(c, 0x1e, 0x14);
        c.vx = c.vx / 2.0;
        c.ay = 0.07;
    }
    if (c.d168 > 1) {
        c.setState(0xd5);
        c.stopMotion();
        return;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        impactFx(c);
        c.setState(0xd6);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) impactFx(c);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.onStateChange();
        c.stopMotion();
        o.stopMotion();
        o.onStateChange();
        c.state = 0xdd;
        o.d128 = 1;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x25;
        d.y = ftol(c.y) - 0x2a;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (atFrame(c, 4)) applyDirectDamage(c, 0x4e2, 750.0);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) {
            o.state = 0x67;
            o.stopMotion();
            o.onStateChange();
            o.y = -86.0;
            o.x = c.facing * 0x29 + c.x;
        }
        if (c.frame === 2) {
            o.y = -97.0;
            o.x = c.facing * 0x24 + c.x;
        }
        if (c.frame === 3) {
            o.y = -97.0;
            o.x = c.facing * 0x22 + c.x;
            o.facing = -c.facing;
        }
        if (c.frame === 4) {
            o.y = 0.0;
            o.x = c.facing * 0x24 + c.x;
            o.facing = -c.facing;
            c.shakeScreen(3, 0);
            o.state = 0x61;
            o.stopMotion();
            o.onStateChange();
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function dashNormal(c, startFrame, meter, se, resetBefore, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    c.vx -= 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atStart(c)) {
        c.vx = 2.0;
        c.vy = 0.0;
    }
    if (atFrame(c, startFrame)) attackStart(c, meter, se);
    if (advance(c, dur)) {
        if (c.frame < resetBefore) c.d168 = 0;
        if (c.frame >= cnt) c.setState(end);
    }
}
const s230 = (c)=>dashNormal(c, 2, 5, 0x15, 3, 0);
const s231 = (c)=>dashNormal(c, 2, 0xa, 0x14, 3, 0);
const s233 = (c)=>dashNormal(c, 1, 5, 0x15, 5, 3);
const s234 = (c)=>dashNormal(c, 2, 0xa, 0x14, 3, 3);
function dashHeavyHead(c) {
    c.startAfterimage(3);
    c.b158 = 0;
    if (c.frame < 3) {
        if (c.b158 === 0) c.vx = 0.0;
        if (c.vx > 0.0 && c.b158 === 1) {
            c.vx -= 0.06;
        } else {
            c.vx = 0.0;
            c.b158 = 0;
        }
    }
}
function s232(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    dashHeavyHead(c);
    if (atFrame(c, 3)) {
        c.seRequest = 0x14;
        c.vx = 3.0;
        c.w16c = 1;
        addMeter(c, 0x23);
    }
    c.vx = c.vx - (c.vx > 0.0 ? 1 : 0) * 0.07;
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function s235(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    dashHeavyHead(c);
    if (c.frame > 2 && c.frame < 0xf) {
        c.vy += c.ay;
        if (c.vy + c.y > 0.0) {
            c.timer = 0;
            c.stopMotion();
            c.y = 0.0;
            c.frame = 0xf;
        }
    }
    if (atFrame(c, 7)) {
        c.seRequest = 0x14;
        c.w16c = 1;
        addMeter(c, 0x23);
    }
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame === 3) {
            c.vx = 1.5;
            c.vy = -1.5;
            c.ay = 0.032;
        }
        if (c.frame >= cnt) c.setState(0);
    }
}
registerStates({
    81: s81,
    82: s82,
    83: s83,
    84: s83,
    85: s85,
    86: s86,
    87: s87,
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    234: s234,
    235: s235
});
