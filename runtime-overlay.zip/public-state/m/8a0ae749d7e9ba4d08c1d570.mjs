import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { spawnEffect } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { childHandlers } from "./4f243a87eb42ac119eae883d.mjs";
import { childFrameCount, childFrameDuration } from "./7596266716c972d06fe8897a.mjs";
export function newSpawnFrame() {
    return {
        d00: 0,
        w04: 0,
        x: 0,
        y: 0,
        b18: 0,
        d1c: 0,
        b20: 0,
        b21: 0,
        d24: 0,
        d28: 0,
        b2c: 0,
        d30: 0,
        clip: [
            0,
            0,
            0,
            0
        ]
    };
}
export function resetSpawnFrame(f) {
    f.d00 = 0;
    f.b20 = 0;
    f.b2c = 0xff;
    f.d24 = 0;
    f.d28 = 0;
    f.d30 = 0;
    f.clip = [
        0,
        0,
        0,
        0
    ];
}
export function openSpawnFrame() {
    const f = newSpawnFrame();
    resetSpawnFrame(f);
    return f;
}
export function frameEffect(f) {
    spawnEffect({
        owner: f.d00,
        pat: f.w04,
        x: f.x,
        y: f.y,
        b18: f.b18,
        mirror: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        sound: f.b2c
    });
}
export function frameChild(c, f) {
    return c.spawnChild({
        type: f.d00,
        pattern: f.w04,
        x: f.x,
        y: f.y,
        facing: f.b18,
        d4c: f.d1c,
        blend: f.b20,
        layer: f.b21,
        fixed: f.d24,
        shadow: f.d28,
        b6c: f.b2c,
        moveWhileFrozen: f.d30,
        clip: [
            ...f.clip
        ]
    });
}
export const childSpawnFrame = newSpawnFrame();
export let childDuration = 0;
export let childCount = 0;
let walkAborted = false;
export function abortChildWalk() {
    walkAborted = true;
}
export function updateChildrenMayu(c) {
    if (c.opponent.freeze > 0) return;
    let i = c.childTail;
    Object.assign(childSpawnFrame, newSpawnFrame());
    walkAborted = false;
    while(i !== c.childHead){
        const ch = c.children[i];
        if (c.childActive[i] !== 0 && ch.hitstop === 0) {
            let run = true;
            if (c.freeze !== 0) {
                if (c.freeze <= 0 || ch.moveWhileFrozen === 0) run = false;
            }
            if (run) {
                childDuration = childFrameDuration(c, i);
                childCount = childFrameCount(c, i);
                resetSpawnFrame(childSpawnFrame);
                const k = ch.pattern - 400;
                if (k >= 0 && k <= 0x63) {
                    const handler = childHandlers.get(ch.pattern);
                    handler?.(c, i);
                    if (walkAborted) return;
                }
            }
        }
        i++;
        if (i >= 64) i = 0;
    }
}

export function __logicState(){return {childSpawnFrame,childDuration,childCount,walkAborted};}

export function __installInitialRoots(s){
if(childSpawnFrame!==s["childSpawnFrame"])throw Error('INITIAL_CONST_IDENTITY:childSpawnFrame');
childDuration=s["childDuration"];
childCount=s["childCount"];
walkAborted=s["walkAborted"];
}
