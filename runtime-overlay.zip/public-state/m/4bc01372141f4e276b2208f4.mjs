import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { exists, read } from "./197efe2647ca25903d217eb5.mjs";
let ac = null;
let master = null;
const buffers = new Map();
let bgmSource = null;
let bgmGain = null;
let bgmToken = 0;
export function initAudio() {}
async function loadBuffer(path) {
    let p = buffers.get(path);
    if (!p) {
        p = (async ()=>{
            if (!ac) return null;
            const data = await read(path);
            if (!data) {
                console.warn(`[audio] 找不到檔案：${path}`);
                return null;
            }
            try {
                return await ac.decodeAudioData(data.slice().buffer);
            } catch (err) {
                console.warn(`[audio] 無法解碼：${path}`, err);
                return null;
            }
        })();
        buffers.set(path, p);
    }
    return p;
}
export function dsVolumeToGain(volume) {
    if (volume <= -10000) return 0;
    return __numerics.pow(10, volume / 2000);
}
export const SE_COUNT = 65;
const SE_VOLUME = -500;
function sePath(n) {
    return `wave\\se\\${String(n).padStart(2, "0")}.wav`;
}
const sePlaying = new Map();
export async function loadSystemSE() {
    await Promise.all(Array.from({
        length: SE_COUNT
    }, (_, n)=>loadBuffer(sePath(n))));
}
export function hasSE(n) {
    return exists(sePath(n));
}
export function playSE(n) {
    __session.effect({
        kind: "playSE",
        args: [
            n
        ]
    });
    void loadBuffer(sePath(n)).then((buf)=>{
        if (!buf || !ac || !master) return;
        const prev = sePlaying.get(n);
        if (prev) {
            try {
                prev.stop();
            } catch  {}
        }
        const gain = ac.createGain();
        gain.gain.value = dsVolumeToGain(SE_VOLUME);
        gain.connect(master);
        const src = ac.createBufferSource();
        src.buffer = buf;
        src.connect(gain);
        src.onended = ()=>{
            gain.disconnect();
            if (sePlaying.get(n) === src) sePlaying.delete(n);
        };
        sePlaying.set(n, src);
        src.start();
    });
}
const wavePlaying = new Map();
export async function preloadWaves(paths) {
    await Promise.all(paths.map((p)=>loadBuffer(p)));
}
export function playWave(path, volume) {
    __session.effect({
        kind: "playWave",
        args: [
            path,
            volume
        ]
    });
    void loadBuffer(path).then((buf)=>{
        if (!buf || !ac || !master) return;
        const prev = wavePlaying.get(path);
        if (prev) {
            try {
                prev.stop();
            } catch  {}
        }
        const gain = ac.createGain();
        gain.gain.value = dsVolumeToGain(volume);
        gain.connect(master);
        const src = ac.createBufferSource();
        src.buffer = buf;
        src.connect(gain);
        src.onended = ()=>{
            gain.disconnect();
            if (wavePlaying.get(path) === src) wavePlaying.delete(path);
        };
        wavePlaying.set(path, src);
        src.start();
    });
}
function findLoopPoints(data) {
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    const base = Math.max(0, data.length - 0x140);
    let position = 0;
    let length = 0;
    for(let i = base; i < data.length; i++){
        if (data[i] === 0x63 && data[i + 1] === 0x75 && data[i + 2] === 0x65) {
            if (i + 0x14 <= data.length) position = view.getUint32(i + 0x10, true);
        } else if (data[i] === 0x61 && data[i + 1] === 0x64 && data[i + 2] === 0x74 && data[i + 3] === 0x6c) {
            if (i + 0x14 <= data.length) length = view.getUint32(i + 0x10, true);
        }
    }
    if (position === 0 || length === 0) return null;
    const rate = wavSampleRate(data);
    if (!rate) return null;
    return {
        start: position / rate,
        end: (position + length) / rate
    };
}
function wavSampleRate(data) {
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    let pos = 12;
    while(pos + 8 <= data.length){
        const id = String.fromCharCode(data[pos], data[pos + 1], data[pos + 2], data[pos + 3]);
        const size = view.getUint32(pos + 4, true);
        if (id === "fmt ") return pos + 12 <= data.length ? view.getUint32(pos + 12, true) : 0;
        pos += 8 + size + (size & 1);
    }
    return 0;
}
export function playBGM(n) {
    __session.effect({
        kind: "playBGM",
        args: [
            n
        ]
    });
    stopBGM();
    const token = ++bgmToken;
    const path = `wave\\bgm\\bgm${String(n).padStart(2, "0")}.wav`;
    const loop = !(n === 2 || n === 3 || n === 4 || n === 9);
    void Promise.all([
        loadBuffer(path),
        read(path)
    ]).then(([buf, raw])=>{
        if (!buf || !ac || !master || token !== bgmToken) return;
        bgmGain = ac.createGain();
        bgmGain.connect(master);
        bgmSource = ac.createBufferSource();
        bgmSource.buffer = buf;
        bgmSource.loop = loop;
        const points = loop && raw ? findLoopPoints(raw) : null;
        if (points) {
            bgmSource.loopStart = points.start;
            bgmSource.loopEnd = points.end;
        }
        bgmSource.connect(bgmGain);
        bgmSource.start();
    });
}
export function stopBGM() {
    __session.effect({
        kind: "stopBGM",
        args: []
    });
    bgmToken++;
    if (bgmSource) {
        try {
            bgmSource.stop();
        } catch  {}
        bgmSource.disconnect();
        bgmSource = null;
    }
    bgmGain?.disconnect();
    bgmGain = null;
}
const DSBVOLUME_MIN = -10000;
const DSBVOLUME_MAX = 0;
export function setBGMVolume(volume) {
    __session.effect({
        kind: "setBGMVolume",
        args: [
            volume
        ]
    });
    if (!bgmGain || !ac) return;
    if (volume < DSBVOLUME_MIN || volume > DSBVOLUME_MAX) return;
    bgmGain.gain.setValueAtTime(dsVolumeToGain(volume), ac.currentTime);
}
export function __audioState() {
    return {
        bgmToken
    };
}

export function __logicState(){return {ac,master,buffers,bgmSource,bgmGain,bgmToken,SE_VOLUME,sePlaying,wavePlaying,DSBVOLUME_MIN};}

export function __installInitialRoots(s){
bgmToken=s["bgmToken"];
}
