/**
 * Bounded UTF-8 using only ECMAScript intrinsics (including QuickJS).
 *
 * Encoding matches TextEncoder for primitive strings: unpaired UTF-16
 * surrogates become U+FFFD. This is intentionally not a lossless encoding of
 * arbitrary UTF-16; callers requiring exact string/key identity should reject
 * unpaired surrogates before encoding rather than silently replacing them.
 *
 * Decoding matches TextDecoder('utf-8', {fatal:true, ignoreBOM:true}). The
 * ignoreBOM:true choice PRESERVES U+FEFF, including at the start of a string.
 * The TextDecoder default strips an initial BOM and breaks such round trips.
 *
 * maxBytes is a nonnegative safe integer, default 4096. Exceeding it throws
 * RangeError. Invalid input types or malformed UTF-8 throw TypeError. Bounds
 * are checked before allocating encoded bytes or building decoded output.
 * These are input/output size limits, not a native heap/RSS guarantee.
 */

function checkLimit(maxBytes) {
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 0) {
    throw new RangeError('UTF8_BOUND: maxBytes must be a nonnegative safe integer');
  }
}

function boundExceeded() {
  throw new RangeError('UTF8_BOUND: encoded byte length exceeds maxBytes');
}

/** Measure the replacement-normalized UTF-8 bytes without allocating them. */
export function utf8ByteLength(str, maxBytes = 4096) {
  checkLimit(maxBytes);
  if (typeof str !== 'string') throw new TypeError('UTF8_STRING: expected a primitive string');
  // Every UTF-16 code unit contributes at least one UTF-8 byte, even in pairs.
  // This also refuses enormous inputs before scanning them under a small cap.
  if (str.length > maxBytes) boundExceeded();
  let length = 0;
  for (let index = 0; index < str.length; index++) {
    const code = str.charCodeAt(index);
    if (code < 0x80) length++;
    else if (code < 0x800) length += 2;
    else if (code >= 0xd800 && code <= 0xdbff && index + 1 < str.length &&
             str.charCodeAt(index + 1) >= 0xdc00 && str.charCodeAt(index + 1) <= 0xdfff) {
      length += 4;
      index++;
    } else length += 3; // BMP scalar or replacement for an unpaired surrogate.
    if (length > maxBytes) boundExceeded();
  }
  return length;
}

/** Encode into one exactly sized Uint8Array, only after the bounded size pass. */
export function encodeUTF8(str, maxBytes = 4096) {
  const length = utf8ByteLength(str, maxBytes);
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (let index = 0; index < str.length; index++) {
    let code = str.charCodeAt(index);
    if (code >= 0xd800 && code <= 0xdbff) {
      const low = str.charCodeAt(index + 1);
      if (low >= 0xdc00 && low <= 0xdfff) {
        code = 0x10000 + ((code - 0xd800) << 10) + low - 0xdc00;
        index++;
      } else code = 0xfffd;
    } else if (code >= 0xdc00 && code <= 0xdfff) code = 0xfffd;

    if (code < 0x80) bytes[offset++] = code;
    else if (code < 0x800) {
      bytes[offset++] = 0xc0 | (code >>> 6);
      bytes[offset++] = 0x80 | (code & 0x3f);
    } else if (code < 0x10000) {
      bytes[offset++] = 0xe0 | (code >>> 12);
      bytes[offset++] = 0x80 | ((code >>> 6) & 0x3f);
      bytes[offset++] = 0x80 | (code & 0x3f);
    } else {
      bytes[offset++] = 0xf0 | (code >>> 18);
      bytes[offset++] = 0x80 | ((code >>> 12) & 0x3f);
      bytes[offset++] = 0x80 | ((code >>> 6) & 0x3f);
      bytes[offset++] = 0x80 | (code & 0x3f);
    }
  }
  return bytes;
}

function invalidUTF8(offset) {
  throw new TypeError('UTF8_INVALID: malformed UTF-8 at byte ' + offset);
}

/** Decode only the supplied Uint8Array view; malformed input is always fatal. */
export function decodeUTF8(bytes, maxBytes = 4096) {
  checkLimit(maxBytes);
  if (!(bytes instanceof Uint8Array)) throw new TypeError('UTF8_BYTES: expected Uint8Array');
  const length = bytes.length;
  if (length > maxBytes) boundExceeded();
  const parts = [];
  let chunk = '';
  let offset = 0;
  while (offset < length) {
    const start = offset;
    const lead = bytes[offset++];
    let code;
    let remaining;
    let minimum;
    if (lead < 0x80) {
      code = lead;
      remaining = 0;
      minimum = 0;
    } else if (lead >= 0xc2 && lead <= 0xdf) {
      code = lead & 0x1f;
      remaining = 1;
      minimum = 0x80;
    } else if (lead >= 0xe0 && lead <= 0xef) {
      code = lead & 0x0f;
      remaining = 2;
      minimum = 0x800;
    } else if (lead >= 0xf0 && lead <= 0xf4) {
      code = lead & 0x07;
      remaining = 3;
      minimum = 0x10000;
    } else invalidUTF8(start);

    if (remaining > length - offset) invalidUTF8(start);
    for (let index = 0; index < remaining; index++) {
      const next = bytes[offset++];
      if ((next & 0xc0) !== 0x80) invalidUTF8(offset - 1);
      code = (code << 6) | (next & 0x3f);
    }
    if (code < minimum || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) {
      invalidUTF8(start);
    }
    if (code <= 0xffff) chunk += String.fromCharCode(code);
    else {
      code -= 0x10000;
      chunk += String.fromCharCode(0xd800 | (code >>> 10), 0xdc00 | (code & 0x3ff));
    }
    // Bound each concatenation chain without giant argument lists or recursion.
    if (chunk.length >= 1024) {
      parts.push(chunk);
      chunk = '';
    }
  }
  parts.push(chunk);
  return parts.join('');
}
