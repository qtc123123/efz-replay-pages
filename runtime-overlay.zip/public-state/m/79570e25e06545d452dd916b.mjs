import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
const WAIT_OVERSHOOT = 0.5;
const RESYNC_MS = 250;
const MAX_PENDING = 2;
let frameResolvers = [];
let rafScheduled = false;
export function nextAnimationFrame() {
    return new Promise((resolve)=>{
        frameResolvers.push(resolve);
        if (rafScheduled) return;
        rafScheduled = true;
        requestAnimationFrame(()=>{
            rafScheduled = false;
            const now = __session.now();
            const list = frameResolvers;
            frameResolvers = [];
            for (const r of list)r(now);
        });
    });
}
let sleepDeadline = 0;
let instantSleep = false;
export function setInstantSleepForTrace(on) {
    instantSleep = on;
}
export async function winSleep(ms) {
    __session.wait(ms);
    if (instantSleep) return;
    const now = __session.now();
    if (sleepDeadline < now - 20) sleepDeadline = now;
    sleepDeadline += ms + WAIT_OVERSHOOT;
    while(__session.now() < sleepDeadline){
        const t = await nextAnimationFrame();
        if (t - sleepDeadline > RESYNC_MS) sleepDeadline = t;
    }
}
export class FrameTimer {
    interval = 10;
    next;
    windowStart;
    count = 0;
    pending = 0;
    constructor(){
        const now = __session.now();
        this.next = now;
        this.windowStart = Math.floor(now);
    }
    advance(until) {
        if (until - this.next > RESYNC_MS) this.next = until;
        let n = 0;
        while(this.next <= until){
            n++;
            this.count++;
            const t = Math.floor(this.next);
            if (t - this.windowStart >= 1000) {
                if (this.count > 64) this.interval = this.interval + 1 & 0xff;
                this.count = 0;
                this.windowStart = t;
            }
            this.next += this.interval + WAIT_OVERSHOOT;
        }
        return n;
    }
    async wait() {
        await __session.originalUpdateComplete();
    }
}

export function __logicState(){return {frameResolvers,rafScheduled,sleepDeadline,instantSleep};}

export function __installInitialRoots(s){
frameResolvers=s["frameResolvers"];
rafScheduled=s["rafScheduled"];
sleepDeadline=s["sleepDeadline"];
instantSleep=s["instantSleep"];
}
