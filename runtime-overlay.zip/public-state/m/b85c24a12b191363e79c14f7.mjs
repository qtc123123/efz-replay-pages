import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./dfcb3299a1af62aa24eb2aa0.mjs";
import { updateChildrenMio } from "./e4446f6179e9bf5107313c92.mjs";
import { parseCommandMio, dispatchMovesMio } from "./7f15aa95e5748289de04b3c5.mjs";
import { thinkMio } from "./052579dabc2084114f0e5194.mjs";
import { renderOverlayMio } from "./cde871fb0b72848667e14994.mjs";
import "./a98d7eeaad122476e16d7386.mjs";
import "./7c6dfeb303456a5c829e3ca1.mjs";
import "./295e7d4eed52338367eea222.mjs";
const POINTS_X = [
    -22,
    17,
    15,
    22,
    33
];
const POINTS_Y = [
    -56,
    0,
    -23,
    -26,
    -52
];
export class Mio extends Character {
    f3138 = 0;
    f3140 = 0;
    f3148 = 0;
    f3150 = 0;
    f3154 = 0;
    a3158 = new Int32Array(64);
    a3258 = new Int32Array(64);
    a3358 = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        4,
        7,
        1,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f3140 = 0;
        this.f3148 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f3140 = 0;
        this.f3148 = 0;
        this.f3150 = 0;
        this.f3154 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a3158.fill(0);
        this.a3258.fill(0);
        this.a3358.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3158[i] = 0;
        this.a3258[i] = 0;
        this.a3358[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayMio(this);
    }
    tickHook() {}
    parseCommand() {
        parseCommandMio(this);
    }
    dispatchMoves() {
        dispatchMovesMio(this);
    }
    think() {
        thinkMio(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMio(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
