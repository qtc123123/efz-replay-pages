import {CUSTOM_PALETTE_PROFILE,RESOLVED_PALETTE_PROFILE,validatePaletteBinding}from"./palette-binding-v1.mjs?v=fce4160233e46f8e7c768b6dab17c1d5f658c64b40d8111ad0c0878b21ca38b8";
import {PUBLIC_IDENTITIES}from"./11a102e855d1170b0ca63b17.mjs";
const need=(v,c='INVALID')=>{if(!v)throw Error('PUBLIC_FEED_'+c);};
const SHA=/^[a-f0-9]{64}$/,UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const uint=(v,max)=>Number.isSafeInteger(v)&&v>=0&&v<=max;
export const EXPERIMENTAL_SCHEMA='efz-live-public-experimental/1';
function owned(value){let nodes=0;function copy(v,depth){need(++nodes<=24000&&depth<=10,'BOUND');if(v===null||typeof v==='boolean')return v;if(typeof v==='number'){need(Number.isFinite(v));return v;}if(typeof v==='string'){need(v.length<=4096);return v;}need(v&&typeof v==='object');const array=Array.isArray(v);need(array?Object.getPrototypeOf(v)===Array.prototype:[Object.prototype,null].includes(Object.getPrototypeOf(v)));const ds=Object.getOwnPropertyDescriptors(v),ks=Reflect.ownKeys(ds);need(ks.every(k=>typeof k==='string'));if(array){need(v.length<=1024&&ks.length===v.length+1);return Array.from({length:v.length},(_,i)=>{const d=ds[i];need(d&&Object.hasOwn(d,'value')&&d.enumerable);return copy(d.value,depth+1);});}need(ks.length<=32);const out={};for(const k of ks){need(!['__proto__','constructor','prototype'].includes(k));const d=ds[k];need(Object.hasOwn(d,'value')&&d.enumerable);out[k]=copy(d.value,depth+1);}return out;}return copy(value,0);}
const pair=(a,max)=>Array.isArray(a)&&a.length===2&&a.every(v=>uint(v,max));
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
function summary(v){need(v?.scope==='summary','VERIFICATION_SCOPE');}
export function validateExperimentalGame(value){
 const v=owned(value);need(v.experimental===true&&v.browserAdmission==='experimental-public-state','ADMISSION');need(UUID.test(v.id)&&uint(v.sourceStart,524288)&&v.clockOrigin===v.sourceStart,'BOUNDARY');
 const i=v.initialization;need(i?.profile==='efz402-revival-local/1'&&pair(i.characters,24)&&pair(i.palettes,5)&&uint(i.stage,22)&&uint(i.seed,2147483646)&&i.seed>0&&uint(i.winRounds,3)&&i.winRounds>0,'INITIALIZATION');
 need(v.names===null||Array.isArray(v.names)&&v.names.length===2&&v.names.every(x=>typeof x==='string'&&x.length<=80&&!/[\x00-\x1f\x7f]/.test(x)),'NAMES');
 const a=v.initialArtifact;need(a?.profile==='efz-public-battle/1'&&SHA.test(a.sha256)&&uint(a.byteLength,1048576)&&a.byteLength>0&&a.sourceStart===v.sourceStart&&uint(a.epoch,2147483647)&&a.epoch>0,'ARTIFACT');
 need(a.identities&&same(Object.entries(a.identities).sort(),Object.entries(PUBLIC_IDENTITIES).sort()),'IDENTITIES');
 summary(v.verification);need(v.verification.profile==='efz-battle-summary-checks/1'&&v.verification.schemaHash==='0d421237a4f143f911cf252276053bfbf59a71547ea3dffed1b0839596a193a0'&&v.verification.stride===64&&v.verification.terminalRequired===true,'VERIFICATION');
 need(['raw-source/1','historical-stock-fallback/1',CUSTOM_PALETTE_PROFILE,RESOLVED_PALETTE_PROFILE].includes(v.visualPolicy)&&v.nativeVisualExactness===false,'VISUAL_POLICY');
 need(Array.isArray(v.paletteFallbackSides)&&v.paletteFallbackSides.length<=2&&v.paletteFallbackSides.every(n=>n===0||n===1)&&new Set(v.paletteFallbackSides).size===v.paletteFallbackSides.length,'PALETTE');
 if([CUSTOM_PALETTE_PROFILE,RESOLVED_PALETTE_PROFILE].includes(v.visualPolicy)){v.paletteBinding=validatePaletteBinding(v.paletteBinding,{gameId:v.id,epoch:a.epoch,sourceStart:v.sourceStart,artifactSha256:a.sha256});need(v.paletteBinding.profile===v.visualPolicy,'PALETTE_PROFILE');const stock=v.paletteBinding.resolutions?.filter(r=>r.kind!=='custom').map(r=>r.side).sort()??[];need(same(v.paletteFallbackSides,stock),'PALETTE_FALLBACK');}else need(v.paletteBinding===undefined,'UNEXPECTED_PALETTE_BINDING');
 need(uint(v.availableFrames,524288-v.sourceStart)&&[null,'complete','interrupted','error'].includes(v.terminal),'EXTENT');return v;
}
export function validateExperimentalManifest(value){const v=owned(value);need(v.schema===EXPERIMENTAL_SCHEMA&&v.experimental===true&&v.browserAdmission==='experimental-public-state','ADMISSION');summary(v.verification);need(Array.isArray(v.games)&&v.games.length<=32,'GAMES');const games=v.games.map(validateExperimentalGame);need(new Set(games.map(x=>x.id)).size===games.length,'GAME_DUPLICATE');need(v.session&&['waiting','selection','playing','ended','error'].includes(v.session.state),'SESSION');return {...v,games};}
export function validateExperimentalChunk(value,{id,from}){
 const v=owned(value);need(v.schema===EXPERIMENTAL_SCHEMA&&v.id===id&&UUID.test(id)&&uint(v.from,524288)&&v.from===from,'CHUNK');if(v.experimental!==undefined)need(v.experimental===true);if(v.verification!==undefined)summary(v.verification);
 need(uint(v.availableFrames,524288)&&Array.isArray(v.pairs)&&v.pairs.length<=1024&&v.from+v.pairs.length<=v.availableFrames&&[null,'complete','interrupted','error'].includes(v.terminal),'EXTENT');for(const p of v.pairs)need(pair(p,65535)&&p.every(x=>(x&~0x23ff)===0),'INPUT');
 need(Array.isArray(v.checks)&&v.checks.length<=18,'CHECK_BOUND');const end=v.from+v.pairs.length;let previous=v.from-1;const checks=new Set();for(const c of v.checks){need(uint(c.frame,end-1)&&c.frame>=v.from&&c.frame>previous&&SHA.test(c.sha256),'CHECK');previous=c.frame;checks.add(c.frame);}
 for(let frame=(Math.floor(v.from/64)+1)*64-1;frame<end;frame+=64)need(checks.has(frame),'CHECK_REQUIRED');if(v.terminal!==null&&end===v.availableFrames&&end>v.from)need(checks.has(end-1),'CHECK_TERMINAL');return v;
}
