import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
const en = {
    intro: "This port does not include any game data. Select the EFZ game folder on your computer (the one containing <code>efz.exe</code> and the <code>system</code> folder).",
    storedNotice: "Game data is stored in this browser.",
    start: "Start game",
    clear: "Clear stored game data",
    pick: "Select game folder",
    repick: "Select game folder again",
    hint: "You can also drag the folder onto this page. Files are only read in your browser and never uploaded. After the first time, they are kept in this browser so you don't need to select the folder again.",
    legalLink: "Unofficial port, not affiliated with the original rights holders",
    legalOpen: "Legal Notice",
    legalTitle: "Legal Notice",
    legal1: "This is an unofficial, independent port. It is not affiliated with, endorsed by, or sponsored by the developer or publisher of the original game, or by the rights holders of the original characters.",
    legal2: "ETERNAL FIGHTER ZERO was created by Tasogare Frontier. Its characters originate from works including ONE ~Kagayaku Kisetsu e~, Kanon and AIR. All game titles, characters, artwork, music, sound effects and other original materials remain the property of their respective owners.",
    legal3: "This project does not include or distribute the original executable or any game data. Users must provide their own game files and are responsible for ensuring that their use of those files is lawful. This project does not grant any license or other rights to the original game, its assets, or any third-party intellectual property.",
    legal4: "This program supports only the game data of ETERNAL FIGHTER ZERO version 4.02. Using files from any other version may cause unexpected behavior.",
    legal5: "Game files selected by the user are read and processed locally in the browser and are never uploaded or transmitted to any server. So that the folder does not have to be selected again, the files are kept in this browser's local storage and can be deleted at any time with the \"Clear stored game data\" button. Game settings and records are likewise stored only in this browser.",
    legal6: "This website uses Google Analytics to measure visits. Game files are never sent to Google Analytics.",
    legal7: "This software is provided \"as is\", without warranties of any kind, to the extent permitted by applicable law.",
    close: "Close",
    notGameFolder: "Could not find system\\title.dat ({count} files read). Make sure you selected the EFZ game folder.",
    storing: "Storing game data in the browser… ({done} / {total})",
    readingStored: "Reading stored game data…",
    readFailed: "Failed to read stored data: {error}. Please select the game folder again.",
    cleared: "Stored game data has been cleared from this browser.",
    loading: "Loading…",
    launchFailed: "Failed to start: {error}",
    storeFailed: "Could not store the game data in this browser ({error}). You can still play now, but you will need to select the folder again next time.",
    storeUnsupported: "This browser cannot store the game data. You can still play now, but you will need to select the folder again next time.",
    touchPad: "Show on-screen controller",
    btnA: "L",
    btnB: "M",
    btnC: "H",
    btnD: "Sp"
};
const zhTW = {
    intro: "本移植版不附帶任何遊戲資源，請選擇你電腦上的 EFZ 遊戲資料夾（含 <code>efz.exe</code> 與 <code>system</code> 目錄）。",
    storedNotice: "已在這個瀏覽器中儲存遊戲資料。",
    start: "開始遊戲",
    clear: "清除已儲存的遊戲資料",
    pick: "選擇遊戲資料夾",
    repick: "重新選擇遊戲資料夾",
    hint: "也可以把資料夾直接拖曳到這個頁面。檔案只在瀏覽器內讀取，不會上傳；第一次選擇後會存在這個瀏覽器中，之後不必再選。",
    legalLink: "非官方移植，與原作權利人無關",
    legalOpen: "法律聲明",
    legalTitle: "法律聲明",
    legal1: "本專案為非官方的獨立移植，與原作的開發商、發行商及角色原作的權利人皆無關聯，亦未獲得其授權、背書或贊助。",
    legal2: "「ETERNAL FIGHTER ZERO」由黄昏フロンティア製作，遊戲中的角色出自《ONE ～輝く季節へ～》、《Kanon》、《AIR》等作品。遊戲名稱、角色、美術、音樂、音效及其他原作素材的權利，均屬各自的權利人所有。",
    legal3: "本專案不包含、也不散布原作的執行檔或任何遊戲資料。使用者必須自行提供遊戲檔案，並自行確保其使用合法；本專案不授予原作、其素材或任何第三方智慧財產的任何權利。",
    legal4: "本程式僅對應 ETERNAL FIGHTER ZERO 4.02 版的遊戲資料；使用其他版本的檔案可能導致不可預期的行為。",
    legal5: "使用者選擇的遊戲檔案只在瀏覽器中讀取與處理，不會上傳或傳送到任何伺服器。為了不必每次重新選擇資料夾，檔案會存放在此瀏覽器的本機儲存空間，可隨時以「清除已儲存的遊戲資料」刪除；遊戲設定與紀錄同樣只存放在此瀏覽器中。",
    legal6: "本網站使用 Google Analytics 統計造訪情形；遊戲檔案不會傳送給 Google Analytics。",
    legal7: "本軟體依「現狀」提供，在法律允許的範圍內不提供任何形式的保證。",
    close: "關閉",
    notGameFolder: "找不到 system\\title.dat（共讀到 {count} 個檔案），請確認選的是 EFZ 遊戲資料夾。",
    storing: "正在把遊戲資料存進瀏覽器…（{done} / {total}）",
    readingStored: "正在讀取已儲存的遊戲資料…",
    readFailed: "讀取失敗：{error}，請重新選擇遊戲資料夾。",
    cleared: "已清除瀏覽器中儲存的遊戲資料。",
    loading: "載入中…",
    launchFailed: "啟動失敗：{error}",
    storeFailed: "無法把遊戲資料存進這個瀏覽器（{error}）。這次仍可遊玩，但下次需要重新選擇資料夾。",
    storeUnsupported: "這個瀏覽器無法儲存遊戲資料。這次仍可遊玩，但下次需要重新選擇資料夾。",
    touchPad: "顯示虛擬搖桿",
    btnA: "弱",
    btnB: "中",
    btnC: "強",
    btnD: "Sp"
};
const ja = {
    intro: "この移植版にはゲームデータは含まれていません。お使いのコンピューターにある EFZ のゲームフォルダ（<code>efz.exe</code> と <code>system</code> フォルダを含むもの）を選択してください。",
    storedNotice: "ゲームデータはこのブラウザに保存されています。",
    start: "ゲームを開始",
    clear: "保存したゲームデータを削除",
    pick: "ゲームフォルダを選択",
    repick: "ゲームフォルダを選び直す",
    hint: "フォルダをこのページに直接ドラッグすることもできます。ファイルはブラウザ内で読み込むだけで、アップロードはされません。一度選択するとこのブラウザに保存されるため、次回からは選択し直す必要はありません。",
    legalLink: "非公式の移植版です。原作の権利者とは関係ありません",
    legalOpen: "法的事項",
    legalTitle: "法的事項",
    legal1: "本プロジェクトは非公式かつ独立した移植版であり、原作の開発元・販売元およびキャラクター原作の権利者とは一切関係がなく、その許諾・承認・支援を受けたものではありません。",
    legal2: "『ETERNAL FIGHTER ZERO』は黄昏フロンティアが制作した作品であり、登場キャラクターは『ONE ～輝く季節へ～』『Kanon』『AIR』などの作品に由来します。ゲームタイトル、キャラクター、グラフィック、音楽、効果音その他の原作素材に関する権利は、それぞれの権利者に帰属します。",
    legal3: "本プロジェクトは原作の実行ファイルおよびゲームデータを一切含まず、配布もしていません。ゲームデータは利用者自身が用意し、その利用が適法であることを自ら確認する必要があります。本プロジェクトは、原作、その素材、または第三者の知的財産について、いかなる権利も許諾しません。",
    legal4: "本プログラムは ETERNAL FIGHTER ZERO バージョン 4.02 のゲームデータにのみ対応しています。他のバージョンのファイルを使用した場合、予期しない動作が発生する可能性があります。",
    legal5: "利用者が選択したゲームファイルはブラウザ内でのみ読み込み・処理され、サーバーにアップロードまたは送信されることはありません。毎回フォルダを選択し直さなくて済むよう、ファイルはこのブラウザのローカルストレージに保存され、「保存したゲームデータを削除」ボタンでいつでも削除できます。ゲームの設定や記録も同様に、このブラウザ内にのみ保存されます。",
    legal6: "本サイトはアクセス状況の把握のために Google Analytics を使用しています。ゲームファイルが Google Analytics に送信されることはありません。",
    legal7: "本ソフトウェアは「現状のまま」提供され、法律で認められる範囲において、いかなる保証も行いません。",
    close: "閉じる",
    notGameFolder: "system\\title.dat が見つかりません（読み込んだファイル数：{count}）。EFZ のゲームフォルダを選択したか確認してください。",
    storing: "ゲームデータをブラウザに保存しています…（{done} / {total}）",
    readingStored: "保存したゲームデータを読み込んでいます…",
    readFailed: "読み込みに失敗しました：{error}。ゲームフォルダを選択し直してください。",
    cleared: "ブラウザに保存したゲームデータを削除しました。",
    loading: "読み込み中…",
    launchFailed: "起動に失敗しました：{error}",
    storeFailed: "ゲームデータをこのブラウザに保存できませんでした（{error}）。今回は遊べますが、次回はフォルダを選択し直す必要があります。",
    storeUnsupported: "このブラウザではゲームデータを保存できません。今回は遊べますが、次回はフォルダを選択し直す必要があります。",
    touchPad: "仮想パッドを表示",
    btnA: "弱",
    btnB: "中",
    btnC: "強",
    btnD: "Sp"
};
const MESSAGES = {
    "zh-TW": zhTW,
    ja,
    en
};
function detectLang() {
    return "en";
}
export const lang = detectLang();
export function t(key, params = {}) {
    return MESSAGES[lang][key].replace(/\{(\w+)\}/g, (m, name)=>name in params ? String(params[name]) : m);
}
export function applyTranslations(root = document) {
    document.documentElement.lang = lang;
    for (const el of root.querySelectorAll("[data-i18n]")){
        el.innerHTML = t(el.dataset.i18n);
    }
}

export function __logicState(){return {en,zhTW,ja,MESSAGES,lang};}
