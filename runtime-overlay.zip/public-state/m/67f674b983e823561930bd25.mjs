import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { registerChildren, registerStates, setDefaultStateHandler } from "./2bf4cca999321fd0777adb51.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./3a7948481af9e187ce0f99cd.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const JUMP_GRAVITY = 0.043;
const JUMP_VY = -3.0;
function advance(c, dur, cnt) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return c.frame >= cnt;
}
function advanceChild(c, i, dur, cnt) {
    const ch = c.children[i];
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return ch.frame >= cnt;
}
function landFromHit(c) {
    c.y = 0.0;
    if (c.d12c !== 0) c.setState(0x61);
    else c.setState(0x62);
}
function wallPush(c, y, k) {
    if (c.x - 20.0 <= 0.0 || !(c.x + 20.0 < 639.0)) {
        c.pushToOpponent = (1.0 - (y < 0.0 ? 1 : 0) * k) * c.vx;
    } else {
        c.pushToOpponent = 0.0;
    }
}
function rfDrain(c, v) {
    if (c.rfBlue !== 0) c.rfGauge -= v;
}
function stateDefault(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.blend = 0;
    c.b158 = 0;
    if (advance(c, dur, cnt)) c.frame = 0;
}
function walk(c, vx, loop) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.blend = 0;
    c.vx = vx;
    c.vy = 0.0;
    if (advance(c, dur, cnt)) c.frame = loop;
}
function state3(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.blend = 0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.frame = 0;
}
function jumpLanding(c) {
    if (c.y + c.vy >= 0.0 && c.frame > 3) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function jump(c, vx, dashVx, toFall) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    if (c.frame === 0 && c.timer === 0) {
        if (c.b158 === 0) c.faceOpponent();
        c.vx = 0.0;
    }
    if (c.frame === 2 && c.timer === 0) {
        c.ay = JUMP_GRAVITY;
        c.vy = JUMP_VY;
        if (vx !== null) c.vx = vx;
        if (dashVx !== null && c.b158 === 1) {
            c.vx = dashVx;
            c.b158 = 0;
        }
    }
    if (c.frame > 2) c.vy += c.ay;
    if (advance(c, dur, cnt)) {
        if (toFall) c.setState(9);
        else c.frame = c.frame - 2 & 0xffff;
    }
    jumpLanding(c);
}
function quickJump(c, vx, toFall) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = JUMP_GRAVITY;
    c.blend = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.vy = JUMP_VY;
        c.vx = vx;
        c.b158 = 0;
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) {
        if (toFall) c.setState(9);
        else c.frame = c.frame - 2 & 0xffff;
    }
    jumpLanding(c);
}
function transition(c, next) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(next);
}
function fall(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    c.vy += c.ay;
    c.b158 = 0;
    if (c.ay === 0.0) c.ay = 0.035;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.setState(13);
    }
}
function state13(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(c.inputY === 1 ? 3 : 7);
}
function state47(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.6;
        c.ay = 0.035;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 2) {
        c.timer = 0;
        c.frame = 2;
        c.seRequest = 7;
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2) c.frame = c.frame - 2 & 0xffff;
        if (c.frame >= cnt) c.frame = c.frame - 1 & 0xffff;
    }
}
function hitStand(c, meter, k, guard, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    rfDrain(c, 0.6);
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + meter);
        c.vx = (2.0 - c.opponent.proration / 10000.0) * k;
        rfDrain(c, guard);
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    wallPush(c, c.y, 0.2);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 0);
        else c.setState(3);
    }
}
function hitAir(c, wall, mix, clamp, ay) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    rfDrain(c, 0.8);
    if (wall && c.frame > 0 && c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = mix ? c.vy * 0.75 + c.knockY : c.knockY;
        if (clamp !== null) {
            if (c.vy < clamp) c.vy = clamp;
            else if (c.vy > -0.5) c.vy = -0.5;
        }
        c.ay = ay;
    }
    if (!(c.vy > 0.0)) {
        c.frame = 1;
        c.timer = 0;
    }
    if (c.vy >= 0.0 && c.frame <= 1) {
        c.frame = 2;
        c.timer = 0;
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = c.frame - 2 & 0xffff;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function blowStart(c) {
    c.blend = 0;
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    if (c.vy * c.vy > c.vx * c.vx && c.frame === 0) c.frame = 1;
}
function blowFrame(c, cnt) {
    c.timer = 0;
    c.frame++;
    if (c.frame === 1) c.frame = 0;
    if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
}
function state68(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    blowStart(c);
    c.timer++;
    if (c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (c.timer >= dur) blowFrame(c, cnt);
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state69(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    blowStart(c);
    c.timer++;
    if (c.timer >= dur) blowFrame(c, cnt);
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state70(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0 && c.f3138 === 0) {
        c.meter = s16(c.meter + 30);
        c.f3138++;
        c.hitstun = s16(c.hitstun + 120);
        c.vx = 0.5;
        c.vy = -2.5;
        c.ay = 0.025;
        c.seRequest = 0x1f;
        const f = openSpawnFrame();
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function grounded(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    rfDrain(c, 0.8);
    c.b158 = 0;
    c.vx = 0.0;
    c.vy = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function slide(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    rfDrain(c, 0.6);
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + 30);
        rfDrain(c, 30.0);
        c.vx = 2.2;
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.ay = 0.0;
    c.ax = 0.06;
    c.vx -= c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function state81(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0) {
        const f = openSpawnFrame();
        f.w04 = 0x1f3;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    c.vx += 0.02;
    c.vy += c.ay;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) c.frame = c.frame - 1 & 0xffff;
    if (c.y + c.vy >= 0.0 && c.frame === 1) landFromHit(c);
}
function state82(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0 && c.f3138 === 0) {
        c.seRequest = 0x1e;
        c.vy = -0.45;
        c.vx = -0.1;
        c.f3138++;
        c.meter = s16(c.meter + 30);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    if (c.vy > 0.0 && c.frame === 4) {
        c.frame = 5;
        c.timer = 0;
    }
    if (c.frame > 3) c.vy += c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 4 && c.f3138 < 8) {
            c.frame = 0;
            c.f3138++;
        }
        if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
    }
    if (c.y + c.vy >= 0.0 && c.frame > 4) landFromHit(c);
}
function spawn496(c) {
    if (c.f3144 === 0) {
        const f = openSpawnFrame();
        f.w04 = 0x1f0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 0;
        f.b21 = 0;
        f.d00 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        c.f3144 = 1;
    }
}
function state83(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    if (c.frame === 0 && c.timer === 0) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vy = -1.5;
        c.vx = -0.8;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (c.frame === 0 && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.timer = 0;
        c.frame = 1;
        return;
    }
    if (c.frame === 1) c.vx += 0.01;
    if (c.frame === 2 && c.timer === 0) c.vx = -2.0;
    if (c.frame > 1) c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
}
function state85(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    if (c.frame === 0 && c.timer === 0) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state86(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    if (c.frame === 0 && c.timer === 0) {
        spawn496(c);
        if (c.f3138 === 0) {
            rfDrain(c, 30.0);
            c.seRequest = 0x21;
            c.vx = c.knockX;
            c.vy = c.knockY;
            c.meter = s16(c.meter + 30);
            c.f3138++;
        }
    }
    c.vy += 0.06;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state87(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        const f = openSpawnFrame();
        f.w04 = 0x1ef;
        f.x = 60.0;
        f.y = 40.0;
        f.d24 = 1;
        f.b18 = 1;
        f.b20 = 0;
        f.b21 = 0;
        frameChild(c, f);
    }
    if (advance(c, dur, cnt)) c.setState(0);
}
function superMove(c, cost, effect, se, child, se2) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (c.frame > 19) {
        c.vy += 0.035;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.onStateChange();
            c.stopMotion();
            c.state = 13;
            return;
        }
    }
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 5 && c.timer === 0) {
        c.stopMotion();
        c.freeze = 120;
        c.meter = s16(c.meter - cost);
        c.superDarken(0xb0, 3);
        f.w04 = effect;
        f.b2c = se;
        f.x = ftol(c.x) - c.facing * 14;
        f.y = ftol(c.y) - 50;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        if (se2 !== null) c.seRequest = se2;
    }
    if (c.frame > 4 && c.frame < 6) c.biasCameraY(50, 3);
    if (c.frame === 6 && c.timer === 0) {
        f.d00 = 1;
        f.w04 = child;
        f.d30 = 1;
        f.x = c.facing * 2 + c.x;
        f.y = c.y - 29.0;
        f.d00 = 1;
        f.b18 = c.facing;
        f.b20 = 2;
        f.b21 = 1;
        frameChild(c, f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 24) {
            c.onStateChange();
            c.state = 9;
            c.ay = 0.035;
        }
        if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
    }
}
function state319(c) {
    if (c.frame > 4) c.showAltBackground(15);
    superMove(c, 3000, 70, 64, 469, 37);
}
setDefaultStateHandler(stateDefault);
registerStates({
    1: (c)=>walk(c, 0.8, 2),
    2: (c)=>walk(c, -0.8, 0),
    3: state3,
    4: (c)=>jump(c, null, 0.4, true),
    5: (c)=>jump(c, 1.0, 1.1, false),
    6: (c)=>jump(c, -1.0, null, false),
    7: (c)=>transition(c, 0),
    8: (c)=>transition(c, 3),
    9: fall,
    13: state13,
    14: (c)=>quickJump(c, 0.0, true),
    15: (c)=>quickJump(c, 1.0, false),
    16: (c)=>quickJump(c, -1.0, true),
    20: fall,
    47: state47,
    50: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    51: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    52: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    53: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    54: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    55: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    56: (c)=>hitStand(c, 10, -1.1, 10.0, false),
    57: (c)=>hitStand(c, 15, -1.5, 20.0, false),
    58: (c)=>hitStand(c, 20, -1.8, 30.0, false),
    59: (c)=>hitAir(c, false, true, -2.0, 0.032),
    60: (c)=>hitAir(c, false, true, -4.0, 0.032),
    61: (c)=>hitAir(c, false, true, -6.0, 0.032),
    62: (c)=>hitAir(c, false, true, null, 0.032),
    63: (c)=>hitAir(c, false, false, null, 0.032),
    64: (c)=>hitAir(c, true, true, -2.0, 0.032),
    65: (c)=>hitAir(c, true, true, -4.0, 0.032),
    66: (c)=>hitAir(c, true, true, null, 0.032),
    67: (c)=>hitAir(c, true, false, null, 0.032),
    68: state68,
    69: state69,
    70: state70,
    71: (c)=>hitAir(c, false, false, null, 0.072),
    72: (c)=>grounded(c, true),
    73: (c)=>grounded(c, true),
    74: (c)=>grounded(c, false),
    75: (c)=>slide(c, true),
    76: (c)=>slide(c, true),
    77: (c)=>slide(c, false),
    81: state81,
    82: state82,
    83: state83,
    84: state83,
    85: state85,
    86: state86,
    87: state87,
    317: (c)=>superMove(c, 1000, 68, 19, 464, null),
    318: (c)=>superMove(c, 2000, 69, 5, 466, null),
    319: state319
});
const SUPER_TRACK = [
    [
        7,
        32,
        -21.0,
        null
    ],
    [
        8,
        23,
        -60.0,
        0
    ],
    [
        9,
        19,
        -78.0,
        0
    ],
    [
        10,
        16,
        -80.0,
        0
    ],
    [
        11,
        15,
        -81.0,
        0
    ],
    [
        12,
        -3,
        -96.0,
        0
    ],
    [
        13,
        -33,
        -84.0,
        0
    ],
    [
        14,
        -35,
        -81.0,
        0
    ],
    [
        15,
        -36,
        -76.0,
        0
    ],
    [
        16,
        52,
        -38.0,
        1
    ]
];
function superBody(c, i, ownerState, next) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.hitsLeft = 0x63;
    if (c.frame > 49 && c.frame < 150) {
        c.freeChild(i);
        return;
    }
    if (c.state === ownerState) {
        for (const [fr, k, dy, layer] of SUPER_TRACK){
            if (c.frame !== fr) continue;
            if (fr === 12) ch.frame = 5;
            ch.x = k >= 0 ? c.facing * k + c.x : c.x - c.facing * -k;
            ch.y = c.y + dy;
            if (layer !== null) ch.layer = layer;
        }
        if (c.frame === 17 && ch.frame < 39) {
            ch.x = c.facing * 20 + c.x;
            ch.y = c.y + 2.0;
            ch.layer = 1;
            ch.frame = 39;
            ch.timer = 0;
        }
    }
    if (ch.frame >= 39) {
        if (c.a3148[i] === 0) {
            const f = childSpawnFrame;
            f.d00 = 1;
            f.w04 = 0x1d4;
            f.d30 = 1;
            f.x = ch.x;
            f.y = ch.y;
            f.d00 = 1;
            f.b18 = c.facing;
            f.b20 = 2;
            f.b21 = 1;
            frameChild(c, f);
            ch.vx = 2.0;
            ch.vy = 2.0;
            ch.hitsLeft = 5;
            c.a3148[i]++;
        }
        if (ch.y + c.vy > 0.0) {
            ch.y = 0.0;
            ch.frame = 0;
            ch.timer = 0;
            ch.pattern = next;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.hitsLeft = 0;
            return;
        }
    }
    ch.timer++;
    if (ch.timer >= dur) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 1 || ch.frame === 49 || ch.frame === 44 || ch.frame === 54) ch.hitState = 0;
        if (ch.frame === 39) ch.frame = ch.frame - 20 & 0xffff;
        if (ch.frame >= cnt) {
            ch.frame = ch.frame - 20 & 0xffff;
            ch.hitState = 0;
        }
    }
}
function superImpact(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
        c.voiceRequest = 4;
    }
    ch.timer++;
    if (ch.timer >= dur) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame >= cnt) c.freeChild(i);
    }
}
function child468(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.timer++;
    if (advanceChild(c, i, dur, cnt)) c.freeChild(i);
}
function child470(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.hitState = 0;
        c.voiceRequest = 4;
    }
    if (ch.frame === 15 && ch.timer === 0) {
        if (ch.facing * 120 + ch.x < 720.0 && ch.facing * 120 + ch.x > -80.0) {
            const f = childSpawnFrame;
            f.d00 = 1;
            f.w04 = 0x1d6;
            f.x = c.facing * 120 + ch.x;
            f.y = 0.0;
            f.d00 = 1;
            f.b18 = ch.facing;
            f.b20 = 2;
            f.b21 = 1;
            frameChild(c, f);
        }
    }
    ch.timer++;
    if (ch.timer >= dur) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame >= cnt) c.freeChild(i);
    }
}
function coin() {
    return rand("src/game/chars/mizukab/states_template_a.ts:1050:8", {
        consumer: "src/game/chars/mizukab/states_template_a.ts"
    }) > 0x3e80 ? 1 : 0;
}
function debris(c, i, init, gravity) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0 && c.a3148[i] === 0) init();
    ch.vy += gravity;
    if (ch.y > 0.0 && ch.vy > 0.0) ch.vy = -ch.vy;
    if (c.a3248[i] < 10) ch.blend = 1;
    if (c.a3248[i] < 0) {
        c.freeChild(i);
        return;
    }
    ch.timer++;
    c.a3248[i]--;
    if (advanceChild(c, i, dur, cnt)) ch.frame = 0;
}
function child495(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.vx = -0.02;
    ch.drawWhileFrozen = 30000;
    ch.timer++;
    if (c.state !== 0x57) c.freeChild(i);
    if (advanceChild(c, i, dur, cnt)) ch.frame = 0;
}
function child496(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const s = c.state;
    const inStates = s === 0x53 || s === 0x54 || s === 0x55 || s === 0x56;
    const burst = !inStates || (s === 0x53 || s === 0x54) && c.frame > 1;
    if (burst) {
        const f = childSpawnFrame;
        const pieces = [
            [
                0x1f1,
                23,
                -4
            ],
            [
                0x1f1,
                -4,
                -6
            ],
            [
                0x1f1,
                -14,
                -26
            ],
            [
                0x1f1,
                0,
                0
            ],
            [
                0x1f1,
                30,
                -40
            ],
            [
                0x1f1,
                -25,
                -80
            ],
            [
                0x1f2,
                -35,
                -42
            ],
            [
                0x1f2,
                -18,
                -20
            ],
            [
                0x1f2,
                2,
                -65
            ],
            [
                0x1f2,
                16,
                -80
            ]
        ];
        for (const [pattern, dx, dy] of pieces){
            f.w04 = pattern;
            f.x = ftol(c.x) + c.facing * dx;
            f.y = ftol(c.y) + dy;
            f.b20 = 0;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        c.seRequest = 0x22;
        c.freeChild(i);
        c.f3144 = 0;
        return;
    }
    ch.timer++;
    if (advanceChild(c, i, dur, cnt)) ch.frame = 0;
}
function child497(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 40;
        c.a3248[i] = r1 + coin() * 20 + 80;
        c.a3148[i]++;
        const t1 = coin() * 1.2;
        const t2 = coin() * 0.7 + t1;
        ch.vx = coin() * 1.7 + t2 + -1.8;
        const u1 = coin() * 0.6;
        const u2 = coin() * 0.9 + u1;
        ch.vy = -1.2 - (coin() * 1.4 + u2);
    }, 0.05);
}
function child498(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 60;
        c.a3248[i] = r1 + coin() * 40 + 120;
        c.a3148[i]++;
        const t1 = coin();
        const t2 = coin() * 0.5 + t1;
        ch.vx = coin() * 1.5 + t2 + -1.5;
        const u1 = coin() * 0.5;
        const u2 = coin() * 0.8 + u1;
        ch.vy = -1.0 - (coin() * 1.2 + u2);
    }, 0.03);
}
function child499(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.x = c.x;
    ch.y = c.y;
    ch.timer++;
    if (advanceChild(c, i, dur, cnt)) c.freeChild(i);
}
registerChildren({
    464: (c, i)=>superBody(c, i, 317, 465),
    465: superImpact,
    466: (c, i)=>superBody(c, i, 318, 467),
    467: superImpact,
    468: child468,
    469: (c, i)=>superBody(c, i, 319, 470),
    470: child470,
    495: child495,
    496: child496,
    497: child497,
    498: child498,
    499: child499
});

export function __logicState(){return {JUMP_VY,SUPER_TRACK};}

export function __installInitialRoots(s){
if(JUMP_VY!==s["JUMP_VY"])throw Error('INITIAL_CONST_IDENTITY:JUMP_VY');
if(SUPER_TRACK!==s["SUPER_TRACK"])throw Error('INITIAL_CONST_IDENTITY:SUPER_TRACK');
}
