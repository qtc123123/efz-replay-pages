import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
export const stateHandlers = new Map();
export const stateHandlers2 = new Map();
export const childHandlers = new Map();
export const childHandlers2 = new Map();
export let defaultStateHandler = null;
export let defaultStateHandler2 = null;
export function registerStates(map) {
    for (const [k, v] of Object.entries(map))stateHandlers.set(Number(k), v);
}
export function registerStates2(map) {
    for (const [k, v] of Object.entries(map))stateHandlers2.set(Number(k), v);
}
export function registerChildren(map) {
    for (const [k, v] of Object.entries(map))childHandlers.set(Number(k), v);
}
export function registerChildren2(map) {
    for (const [k, v] of Object.entries(map))childHandlers2.set(Number(k), v);
}
export function setDefaultStateHandler(fn) {
    defaultStateHandler = fn;
}
export function setDefaultStateHandler2(fn) {
    defaultStateHandler2 = fn;
}

export function __logicState(){return {stateHandlers,stateHandlers2,childHandlers,childHandlers2,defaultStateHandler,defaultStateHandler2};}

export function __installInitialRoots(s){
if(stateHandlers!==s["stateHandlers"])throw Error('INITIAL_CONST_IDENTITY:stateHandlers');
if(stateHandlers2!==s["stateHandlers2"])throw Error('INITIAL_CONST_IDENTITY:stateHandlers2');
if(childHandlers!==s["childHandlers"])throw Error('INITIAL_CONST_IDENTITY:childHandlers');
if(childHandlers2!==s["childHandlers2"])throw Error('INITIAL_CONST_IDENTITY:childHandlers2');
defaultStateHandler=s["defaultStateHandler"];
defaultStateHandler2=s["defaultStateHandler2"];
}
