const need=(ok,code)=>{if(!ok)throw Error('PUBLIC_WORKER: '+code);};
function ownFields(v,wanted,optional=[]){need(v&&[Object.prototype,null].includes(Object.getPrototypeOf(v)),'MESSAGE');const ks=Reflect.ownKeys(v);need(wanted.every(k=>ks.includes(k))&&ks.every(k=>wanted.includes(k)||optional.includes(k)),'FIELDS');const out={};for(const k of ks){const d=Object.getOwnPropertyDescriptor(v,k);need(d&&Object.hasOwn(d,'value')&&d.enumerable,'ACCESSOR');out[k]=d.value;}return out;}
function admit(v){const h=ownFields(v,['id','type'],['descriptor','initialBytes','manifest','assetRoot','key','chunk','count']);need(Number.isSafeInteger(h.id)&&h.id>0,'ID');
 if(h.type==='init'){const m=ownFields(v,['id','type','descriptor','initialBytes','manifest','assetRoot','key']);need(m.initialBytes instanceof Uint8Array&&m.initialBytes.length>0&&m.initialBytes.length<=1048576&&Object.getPrototypeOf(m.initialBytes.buffer)===ArrayBuffer.prototype&&!m.initialBytes.buffer.resizable,'ARTIFACT');need(m.key instanceof Uint8Array&&m.key.length===32&&Object.getPrototypeOf(m.key.buffer)===ArrayBuffer.prototype&&!m.key.buffer.resizable,'KEY');return {...m,initialBytes:m.initialBytes.slice(),key:m.key.slice()};}
 if(h.type==='append')return ownFields(v,['id','type','chunk']);
 if(h.type==='step'){const m=ownFields(v,['id','type'],['count']);need(m.count===undefined||Number.isInteger(m.count)&&m.count>=1&&m.count<=16,'COUNT');return {...m,count:m.count??1};}
 need(h.type==='dispose','TYPE');return ownFields(v,['id','type']);
}
// Inspect only a bounded internal message; emit solely finite constants below.
function failureReason(error,operation){
 let raw='';try{const d=Object.getOwnPropertyDescriptor(error,'message');if(d&&typeof d.value==='string')raw=d.value.slice(0,256);}catch{}
 if(/^(?:PALETTE_BINDING_|PALETTE_PROVENANCE_|PUBLIC_RENDER_(?:STOCK_PALETTE|PALETTE_|UNEXPECTED_PALETTE)|PUBLIC_SESSION_PALETTE_|PUBLIC_FEED_(?:PALETTE|UNEXPECTED_PALETTE))/.test(raw))return 'palette';
 if(/^(?:Replay:|encrypted assets:|VFS_|PUBLIC_SESSION_CATALOG|PUBLIC_RENDER_(?:RESOURCE_|SPRITE_|PAT_))/.test(raw))return 'resources';
 if(/^(?:INITIAL_GRAPH_|PUBLIC_SCHEMA_|PUBLIC_BATTLE_|PUBLIC_CAP_|PUBLIC_RENDER_(?:BYTES|HASH_OWNER)|PUBLIC_SESSION_SELECTION|PUBLIC_FEED_(?:ARTIFACT|IDENTITIES))/.test(raw))return 'artifact';
 if(/^BATTLE_RENDER_/.test(raw))return operation==='step'?'render':'engine';
 if(/^(?:BATTLE_STORAGE_|BATTLE_PLAYBACK_|RECEIVER_|PUBLIC_SESSION_(?:SUMMARY_DESYNC|TRACK_SWITCH|SOUND_BOUND))/.test(raw))return 'engine';
 return 'unknown';
}
/** One fresh dedicated Worker per game; inputs never enter page/main-thread engine globals. */
export function installPublicBattleWorker(scope,{createSession}){
 const queue=[],abort=new AbortController();let last=0,initialized=false,session=null,current=null,closing=false,retirement=null,disposeId=null,failure=null,initActiveId=null,initPhase=null;
 const phases=['catalog','common-resources','battle-resources','ready'];
 const post=(id,operation,value)=>{const image=value?.frame?.image;scope.postMessage({id,type:'result',operation,value},image?[image.pixels.buffer,image.palette.buffer]:[]);};
 function fail(id,error,operation){if(closing)return;failure={id,error,operation,phase:initPhase??'catalog'};void close();}
 function close(){if(retirement)return retirement;closing=true;abort.abort();for(const m of queue){m.key?.fill(0);m.initialBytes?.fill(0);}queue.length=0;
  retirement=(async()=>{await current?.catch(()=>{});try{await session?.close();}catch(error){failure??={id:disposeId??last,error};}session=null;scope.removeEventListener('message',receive);
   if(failure){if(failure.operation==='init')scope.postMessage({id:failure.id,type:'error',fatal:true,operation:'init',code:'WORKER_INIT_FAILED',phase:failure.phase,reason:failureReason(failure.error,'init'),message:'PUBLIC_WORKER: INIT_FAILED'});else if(failure.operation==='step')scope.postMessage({id:failure.id,type:'error',fatal:true,operation:'step',code:'WORKER_STEP_FAILED',reason:failureReason(failure.error,'step'),message:'PUBLIC_WORKER: STEP_FAILED'});else{const raw=String(failure.error?.message??'');scope.postMessage({id:failure.id,type:'error',fatal:true,message:/^PUBLIC_WORKER: [A-Z_]+$/.test(raw)?raw:'PUBLIC_WORKER: FAILED'});}}
   else if(disposeId!==null)post(disposeId,'dispose',{status:{state:'closed'}});
  })();retirement.catch(()=>{});return retirement;
 }
 async function execute(m){
  if(m.type==='init'){need(!initialized,'INIT_ONCE');initialized=true;initActiveId=m.id;initPhase=null;
   const onProgress=phase=>{if(closing||initActiveId!==m.id||typeof phase!=='string'||phases.indexOf(phase)!==(initPhase===null?0:phases.indexOf(initPhase)+1))return;initPhase=phase;try{scope.postMessage({id:m.id,type:'progress',operation:'init',phase});}catch{}};
   try{session=await createSession(m,abort.signal,{onProgress});}finally{initActiveId=null;}if(!closing)post(m.id,'init',{status:session.status()});return;}
  need(initialized&&session,'UNINITIALIZED');
  if(m.type==='append'){await session.append(m.chunk);if(!closing)post(m.id,'append',{status:session.status()});return;}
  let result,lastFrame=null;
  for(let i=0;i<m.count&&!closing;i++){result=await session.step();if(result.frame)lastFrame=result.frame;if(result.kind!=='advanced')break;}
  if(!closing)post(m.id,'step',{status:session.status(),kind:result.kind,...(lastFrame?{frame:lastFrame}:{})});
 }
 function pump(){if(current||closing||!queue.length)return;const m=queue.shift();const running=Promise.resolve().then(()=>execute(m));current=running;
  running.catch(error=>fail(m.id,error,m.type)).finally(()=>{m.key?.fill(0);m.initialBytes?.fill(0);if(current===running)current=null;pump();});
 }
 function receive(e){if(closing)return;let m;try{m=admit(e.data);need(m.id>last,'ID_ORDER');last=m.id;if(m.type==='dispose'){disposeId=m.id;void close();return;}need(queue.length+(current?1:0)<8,'QUEUE');queue.push(m);pump();}catch(error){m?.key?.fill(0);m?.initialBytes?.fill(0);fail(m?.id??null,error);}}
 scope.addEventListener('message',receive);return Object.freeze({close});
}
