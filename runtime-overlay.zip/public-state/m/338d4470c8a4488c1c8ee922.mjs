import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { abortChildWalk, childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./746d3a93e9a50814987814cf.mjs";
import { registerChildren, registerStates } from "./6eb1fb66adb5d5a47cd5c7ec.mjs";
import { frameCount, frameDuration, s16 } from "./7596266716c972d06fe8897a.mjs";
const DEG = 57.29579143313326;
function setPolarVelocity(c, i, angle, speed) {
    const ch = c.children[i];
    ch.vx = __numerics.cos(angle / DEG) * speed;
    ch.vy = __numerics.sin(angle / DEG) * speed;
}
function angleOf(dx, dy) {
    return __numerics.atan2(dy, dx) * DEG;
}
function heldButton(c, k) {
    return c.isHeld(k);
}
function rfOrTimerCost(c) {
    if (c.f3144 === 4) {
        c.f3148 = c.f3148 - 1000;
        if (c.f3148 < 0) c.f3148 = 0;
    } else if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
}
function effect21Afterimage(c, f, dy) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y) - dy;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
    c.startAfterimage(3);
}
function effect20(c, f) {
    c.voiceRequest = 0;
    f.w04 = 0x20;
    f.x = Math.trunc(c.x) + c.facing * 0x3c;
    f.y = Math.trunc(c.y);
    f.b20 = 0;
    f.b18 = -c.facing;
    f.b21 = 1;
    frameEffect(f);
}
function effect1f(c, f) {
    f.w04 = 0x1f;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y);
    f.b20 = 0;
    f.b21 = 1;
    f.d1c = c.facing === -1 ? 1 : 0;
    frameEffect(f);
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.w0dc = 4;
        c.b0de = 0xec;
        c.vx = 0.0;
        c.w16c = 1;
        c.backWindow = 0;
        c.freeze = 0x3c;
        f.w04 = 0x28;
        f.x = Math.trunc(c.x) + c.facing * 10;
        f.y = Math.trunc(c.y) - 0x28;
        f.b20 = 2;
        f.b21 = 1;
        f.b2c = 0x13;
        frameEffect(f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        if (c.y === 0.0) {
            c.vx = 0.0;
            c.ay = 0.0;
        }
        if (c.y < 0.0) c.f3138 = 1;
        c.ay = 0.0;
    }
    if (c.frame === 1 && c.timer === 0) {
        c.meter = s16(c.meter + 0x19);
        c.w16c = 1;
        c.vx = c.vx * 0.5;
        c.vy = c.vy * 0.5;
        c.ay = 0.025;
    }
    if (c.frame > 1 && c.vy + c.y >= 0.0) {
        c.timer = 0;
        c.frame = 0;
        c.state = 0xfd;
        return;
    }
    c.timer++;
    c.vy = c.vy + c.ay;
    if (c.timer >= dur || c.timer >= dur - 3 && c.f3138 === 1) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = 11;
    }
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        if (c.y === 0.0) {
            c.vx = 0.0;
            c.ay = 0.0;
        }
        if (c.y < 0.0) c.f3138 = 1;
        c.ay = 0.0;
    }
    if (c.frame === 1 && c.timer === 0) {
        c.meter = s16(c.meter + 0x19);
        c.w16c = 1;
        c.vx = c.vx * 0.5;
        c.vy = c.vy * 0.5;
        c.ay = 0.035;
    }
    if (c.frame > 1 && c.vy + c.y >= 0.0) {
        c.timer = 0;
        c.frame = 0;
        c.state = 0xfd;
        c.f313c = 1;
        return;
    }
    c.timer++;
    c.vy = c.vy + c.ay;
    if (c.timer >= dur || c.timer >= dur - 3 && c.f3138 === 1) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 1) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        if (c.y < 0.0) c.f3138 = 1;
        if (c.y === 0.0) {
            c.vx = 0.0;
            c.ay = 0.0;
        }
        effect21Afterimage(c, f, 0x14);
        rfOrTimerCost(c);
    }
    if (c.frame === 1 && c.timer === 0) {
        c.meter = s16(c.meter + 0x19);
        c.w16c = 2;
        c.vx = c.vx * 0.5;
        c.vy = c.vy * 0.5;
        c.ay = 0.025;
    }
    if (c.frame === 7 && c.timer === 0) {
        f.w04 = 0x1a2;
        f.x = Math.trunc(c.x) + c.facing * 0x25;
        f.y = Math.trunc(c.y) - 0x28;
        f.b20 = 2;
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
    }
    if (c.frame > 1 && c.vy + c.y >= 0.0) {
        c.frame = 0;
        c.timer = 0;
        c.state = 0xfd;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur || c.timer >= dur - 3 && c.f3138 === 1) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.faceOpponent();
    c.timer++;
    if (c.timer >= dur || c.frame === 2 && c.f313c === 1 && c.timer === 21) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.d168 = 2;
    if (heldButton(c, 0) > 0) c.f313c++;
    if (c.frame === 2 && c.timer === 0) effect20(c, f);
    if (c.frame === 5 && c.timer === 0) {
        c.stopMotion();
        if (c.f313c > 0x1e) c.f3138 = 1;
    }
    c.vx = c.vx + c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame === 5 && c.timer === 0x14 && c.f3138 === 0) c.vx = -3.0;
    if (c.frame === 6 && c.timer === 0) {
        c.vx = 1.5;
        c.ax = -0.05;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 6 && c.f3138 === 1) {
            c.frame = 0;
            c.timer = 0;
            c.state = 0x105;
            return;
        }
        if (c.frame === 6) c.x = c.opponent.x - c.facing * 0x3c;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.d168 = 2;
    if (heldButton(c, 1) > 0) c.f313c++;
    if (c.frame === 2 && c.timer === 0) effect20(c, f);
    if (c.frame === 5 && c.timer === 0) {
        c.stopMotion();
        if (c.f313c > 0x1e) c.f3138 = 1;
    }
    c.vx = c.vx + c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame === 5 && c.timer === 0x14 && c.f3138 === 0) c.x = c.opponent.x - c.facing * 0xb4;
    if (c.frame === 6 && c.timer === 0) {
        c.vx = 1.5;
        c.ax = -0.05;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 6 && c.f3138 === 1) {
            c.frame = 0;
            c.timer = 0;
            c.state = 0x106;
            c.x = c.opponent.x - c.facing * 100;
            if (c.x > 540.0 && c.facing === 1) c.x = 540.0;
            if (c.x < 100.0 && c.facing === -1) c.x = 100.0;
            c.y = -100.0;
            return;
        }
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state256(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        effect21Afterimage(c, f, 0x14);
        rfOrTimerCost(c);
        c.w16c = 1;
    }
    if (c.frame === 2 && c.timer === 0) effect20(c, f);
    if (c.frame === 4 && c.d168 === 2) {
        c.timer = 0;
        c.frame = 6;
        return;
    }
    if (c.frame === 5 && c.timer === 0) c.stopMotion();
    c.vx = c.vx + c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame === 5 && c.timer === 0x14) c.vx = 8.0;
    if (c.frame === 6 && c.timer === 0) {
        c.vx = 3.5;
        c.ax = -0.05;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) {
            c.faceOpponent();
            c.state = 0;
            c.onStateChange();
        }
    }
}
function spawnSlash(c, dx1, dx2) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.d168 = 2;
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 2 && c.timer === 0) {
        if (c.f3144 !== 4) {
            c.f3144 = 2;
            f.w04 = 0x19c;
            f.x = Math.trunc(c.x) + c.facing * dx1;
        } else {
            f.w04 = 0x1a8;
            c.f3148 = c.f3148 - 1000;
            if (c.f3148 < 0) c.f3148 = 0;
            f.x = Math.trunc(c.x) + c.facing * dx2;
        }
        f.y = Math.trunc(c.y);
        f.d00 = 1;
        f.b20 = 2;
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state257(c) {
    spawnSlash(c, 0x28, 0x50);
}
function state258(c) {
    spawnSlash(c, 0x78, 0xa0);
}
function state259(c) {
    spawnSlash(c, 0xc8, 0xf0);
}
function state260(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.voiceRequest = 5;
        c.f3148 = 10000;
        c.f314c = 1;
        c.f3150 = 1;
        effect1f(c, f);
        f.w04 = 0x191;
        f.x = Math.trunc(c.x);
        if (c.f3140 === 1) {
            f.x = Math.trunc(c.x) + c.facing * 0x3c;
            if (Math.trunc(c.x) + c.facing * 0x3c > 600) f.x = 600.0;
            if (Math.trunc(c.x) + c.facing * 0x3c < 40) f.x = 40.0;
        }
        if (c.f3140 === 2) {
            f.x = Math.trunc(c.x) - c.facing * 0x3c;
            if (Math.trunc(c.x) - c.facing * 0x3c > 600) f.x = 600.0;
            if (Math.trunc(c.x) - c.facing * 0x3c < 40) f.x = 40.0;
        }
        f.y = Math.trunc(c.y) - 0x11;
        f.b18 = c.facing;
        f.b20 = 2;
        f.b21 = 1;
        f.d00 = 1;
        frameChild(c, f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 2.0;
        c.w16c = 1;
    }
    if (c.frame > 6) c.vx = c.vx - 0.055;
    if (c.vx < 0.0) c.vx = 0.0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 1) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 1.0;
        c.vy = 0.0;
        c.w16c = 1;
    }
    if (c.frame > 2) c.vy = c.vy + 0.035;
    if (c.y + c.vy > 0.0 && c.frame < 12) {
        c.frame = 12;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function summon(c, f, pattern) {
    c.f3144 = 2;
    c.voiceRequest = 5;
    effect1f(c, f);
    f.w04 = pattern;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y) - 0x14;
    f.b18 = c.facing;
    f.b20 = 2;
    f.b21 = 1;
    f.d00 = 1;
    frameChild(c, f);
}
function summonAdvance(c, dur, cnt) {
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state263(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 3 && c.timer === 0) summon(c, f, 0x1ac);
    summonAdvance(c, dur, cnt);
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 3 && c.timer === 0) summon(c, f, 0x1ad);
    summonAdvance(c, dur, cnt);
}
function state265(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 0 && c.timer === 0) {
        effect21Afterimage(c, f, 0x28);
        rfOrTimerCost(c);
    }
    if (c.frame === 3 && c.timer === 0) summon(c, f, 0x1ae);
    summonAdvance(c, dur, cnt);
}
function spawn432(c, dx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.d168 = 2;
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 3 && c.timer === 0) {
        c.f3144 = 2;
        f.w04 = 0x1b0;
        f.x = Math.trunc(c.x) + c.facing * dx;
        f.y = Math.trunc(c.y) - 0x14;
        f.d00 = 1;
        f.b20 = 2;
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
    }
    summonAdvance(c, dur, cnt);
}
function state266(c) {
    spawn432(c, 0x50);
}
function state267(c) {
    spawn432(c, 0xa0);
}
function state268(c) {
    spawn432(c, 0xf0);
}
function state269(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.voiceRequest = 5;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
registerStates({
    249: state249,
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    265: state265,
    266: state266,
    267: state267,
    268: state268,
    269: state269
});
function cloneInterrupted(c, i) {
    const ch = c.children[i];
    if (c.state > 0x31 && c.state < 0x96) return true;
    return ch.hitState === 4 || ch.hitState === 5;
}
function morph(c, i, pattern) {
    const ch = c.children[i];
    ch.pattern = pattern;
    ch.frame = 0;
    ch.timer = 0;
}
function interruptTo402(c, i) {
    morph(c, i, 0x192);
    abortChildWalk();
}
function child401(c, i) {
    const ch = c.children[i];
    c.f3144 = 1;
    if (ch.frame > 2) {
        if (ch.vx >= 0.1) ch.vx = ch.vx - 0.02;
        if (ch.vx <= -0.1) ch.vx = ch.vx + 0.02;
        if (ch.vy >= 0.1) ch.vy = ch.vy - 0.02;
        if (ch.vy <= -0.1) ch.vy = ch.vy + 0.02;
        if (ch.vx < 0.1 && ch.vx > -0.1) ch.vx = 0.0;
        if (ch.vy < 0.1 && ch.vy > -0.1) ch.vy = 0.0;
        if (c.f3150 === 1) {
            c.f3150 = 0;
            ch.vx = 0.0;
            ch.vy = 0.0;
            if (ch.y > -30.0) {
                const f = childSpawnFrame;
                f.w04 = 0x1f;
                f.x = Math.trunc(ch.x);
                f.y = Math.trunc(ch.y);
                f.b20 = 0;
                f.b21 = 0;
                f.d1c = ch.facing === -1 ? 1 : 0;
                frameEffect(f);
            }
        }
        if (c.f3148 <= 0) {
            ch.pattern = 0x193;
            ch.timer = 0;
            ch.frame = 0;
            c.f3148 = 0;
            c.f3144 = 2;
            return;
        }
        if (ch.x > c.opponent.x) ch.facing = -1;
        if (ch.x <= c.opponent.x) ch.facing = 1;
        if (cloneInterrupted(c, i)) {
            ch.pattern = 0x192;
            c.f3144 = 2;
            ch.frame = 0;
            ch.timer = 0;
            return;
        }
        if (c.state === 0x10d) {
            ch.pattern = 0x194;
            ch.timer = 0;
            ch.frame = 0;
            c.f3148 = 0;
            return;
        }
        if (c.state === 0x143 && c.frame === 3 && c.timer === 0) {
            morph(c, i, 0x1bf);
            c.f3144 = 2;
            return;
        }
        if (c.state === 0x141 && c.frame === 3 && c.timer === 0) {
            morph(c, i, 0x1bb);
            c.f3144 = 2;
            return;
        }
        if (c.state === 0x13f && c.frame === 3 && c.timer === 0) {
            morph(c, i, 0x1b7);
            c.f3144 = 2;
            return;
        }
        const busy = c.state >= 0x96 && c.state <= 0x9c || c.state === 0xa8 || c.state === 0xa9 || c.state === 0xaa || c.state === 0x104 || c.state === 0x10d;
        if (!busy) {
            if (c.command === 0x21) {
                morph(c, i, 0x1c3);
                c.f3144 = 2;
                return;
            }
            if (c.command === 0x2b) {
                morph(c, i, 0x1b4);
                c.f3144 = 2;
                return;
            }
            if (c.command === 0xd) {
                morph(c, i, 0x1af);
                c.f3144 = 2;
                return;
            }
            if (c.command === 0x35) {
                morph(c, i, 0x19e);
                c.f3144 = 2;
                return;
            }
        }
    }
    if (ch.x > 600.0) {
        ch.x = 600.0;
        ch.vx = 0.0;
    }
    if (ch.x < 40.0) {
        ch.x = 40.0;
        ch.vx = 0.0;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 3;
    }
}
function child402(c, i) {
    const ch = c.children[i];
    c.f3144 = 2;
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.vx = -2.0;
        ch.vy = -2.0;
        ch.ax = 0.05;
        c.a3158[i] = 1;
    }
    ch.vx = ch.vx + ch.ax;
    ch.vy = ch.vy + ch.ax;
    if (ch.vx > 0.0) ch.vx = 0.0;
    if (ch.vy > 0.0) ch.vy = 0.0;
    ch.timer++;
    if (ch.hitState === 1) c.freeChild(i);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 2 && c.a3258[i] < 5) {
            c.a3258[i]++;
            ch.frame -= 2;
        }
        if (ch.frame >= childCount) {
            c.f314c = 0;
            c.f3148 = 1200;
            c.f3144 = 3;
            c.a3258[i] = 0;
            c.a3158[i] = 0;
            c.freeChild(i);
        }
    }
}
function cloneVanish(c, i) {
    const ch = c.children[i];
    c.f3144 = 2;
    ch.vx = 0.0;
    ch.vy = 0.0;
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return ch.frame >= childCount;
}
function child403(c, i) {
    if (!cloneVanish(c, i)) return;
    c.f3148 = 1200;
    c.f3144 = 3;
    c.f3150 = 0;
    c.f314c = 0;
    c.freeChild(i);
}
function child404(c, i) {
    if (!cloneVanish(c, i)) return;
    c.f3148 = 1200;
    c.f3144 = 3;
    c.f3150 = 1;
    c.freeChild(i);
}
function child406(c, i) {
    const ch = c.children[i];
    c.f3148 = c.f3148 - 1;
    if (cloneInterrupted(c, i)) {
        interruptTo402(c, i);
        return;
    }
    ch.vx = ch.vx + ch.ax;
    ch.vy = ch.vy + ch.ay;
    if (ch.x > 590.0 && ch.facing === 1) ch.vx = 0.0;
    if (ch.x < 50.0 && ch.facing === -1) ch.vx = 0.0;
    if (ch.vx < 0.0) ch.vx = 0.0;
    if (ch.vy < 0.0) ch.vy = 0.0;
    if (ch.frame === 5 && ch.timer === 0) {
        if (c.f3148 > 1) c.f3148 = c.f3148 - 5000;
        else c.f3148 = 0;
    }
    if (ch.frame === 0) {
        ch.vx = 0.0;
        ch.ax = 0.0;
    }
    if (ch.frame === 7 && ch.timer === 0) ch.hitsLeft = 1;
    if (ch.frame === 5 && ch.timer === 0) {
        ch.vx = 2.5;
        ch.ax = -0.015;
        c.a3158[i] = 6;
        ch.vy = 0.9;
        ch.ay = -0.035;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 11 && c.a3158[i] > 0) {
            ch.frame = 7;
            c.a3158[i]--;
        }
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            ch.pattern = 0x191;
            c.f3144 = 0;
            ch.frame = 0;
        }
    }
}
function child407(c, i) {
    const ch = c.children[i];
    if (cloneInterrupted(c, i)) {
        interruptTo402(c, i);
        return;
    }
    if (ch.frame === 5 && ch.timer === 0 && c.a3258[i] === 0) c.f3148 = 0;
    ch.vx = 0.0;
    ch.vy = 0.0;
    if (ch.frame === 5 && ch.timer === 0 && c.a3258[i] !== 1) {
        const f = childSpawnFrame;
        f.w04 = 0x198;
        f.x = Math.trunc(ch.x + ch.facing * 0x1d);
        f.y = Math.trunc(ch.y - 49.0);
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = ch.facing;
        frameChild(c, f);
        c.a3258[i] = 1;
        c.a3158[i] = 0;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 8 && c.a3158[i] < 5) {
            ch.frame -= 4;
            c.a3158[i]++;
        }
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            ch.pattern = 0x193;
            c.f3144 = 0;
            ch.frame = 0;
            c.a3258[i] = 0;
            c.a3158[i] = 0;
        }
    }
}
function child408(c, i) {
    const ch = c.children[i];
    if (ch.timer === 0 && ch.frame === 0 && c.a3158[i] <= 0) {
        if (c.a3258[i] === 0) ch.hitsLeft = 1;
        if (c.a3258[i] < 3 && ch.hitsLeft > 0) {
            const opp = c.opponent;
            c.a3358[i] = Math.trunc(angleOf(opp.x - ch.x, opp.y - 50.0 - ch.y));
            setPolarVelocity(c, i, c.a3358[i], -0.00875);
            ch.ax = ch.vx;
            ch.ay = ch.vy;
            setPolarVelocity(c, i, c.a3358[i], 1.4);
            if (ch.facing === -1) {
                ch.ax = -ch.ax;
                ch.vx = -ch.vx;
            }
            c.a3358[i] = 0xa0;
            c.a3258[i]++;
            c.a3158[i] = 0xf0;
        }
    }
    if (c.a3358[i] > 0) {
        ch.vx = ch.vx + ch.ax;
        ch.vy = ch.vy + ch.ay;
        c.a3358[i]--;
    }
    c.a3158[i]--;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            ch.frame = 0;
            if ((c.a3258[i] > 2 || ch.hitsLeft === 0) && c.a3158[i] <= 0) c.freeChild(i);
        }
    }
}
function child409(c, i) {
    const ch = c.children[i];
    c.f3144 = 1;
    if (c.state === 0x13d) c.showAltBackground(0xf);
    const f = childSpawnFrame;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.moveWhileFrozen = 1;
        if (c.state === 0x13b) c.meter = s16(c.meter - 1000);
        if (c.state === 0x13c) c.meter = s16(c.meter - 2000);
        if (c.state === 0x13d) c.meter = s16(c.meter - 3000);
        c.f3140 = 0;
        c.a3158[i] = 0;
        c.freeze = 0x78;
        c.superDarken(0xb0, 3);
        f.w04 = 9;
        f.b2c = 5;
        f.x = Math.trunc(ch.x + ch.facing * 0x1c);
        f.y = Math.trunc(ch.y - 52.0);
        f.b20 = 2;
        f.d00 = 1;
        f.b21 = 1;
        frameEffect(f);
        c.seRequest = 0x25;
    }
    if (ch.frame > 4 && ch.frame < 12 && c.freeze === 0) {
        if (c.a3358[i] === 0) {
            c.voiceRequest = 6;
            c.a3358[i]++;
        }
        if (c.a3258[i] >= 0xf) {
            c.a3258[i] = 0;
            if (c.state === 0x13b && c.f3140 < 3) {
                spawnFrom409(c, i, 0x19a);
                c.f3140++;
            }
            if (c.state === 0x13c && c.f3140 < 5) {
                spawnFrom409(c, i, 0x1a7);
                c.f3140++;
            }
            if (c.state === 0x13d && c.f3140 < 10) {
                spawnFrom409(c, i, 0x1a9);
                c.f3140++;
            }
        }
    }
    ch.vx = 0.0;
    ch.vy = 0.0;
    c.a3258[i]++;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 12 && c.a3158[i] < 5) {
            ch.frame -= 4;
            c.a3158[i]++;
        }
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            ch.pattern = 0x193;
            c.f3144 = 0;
            ch.moveWhileFrozen = 0;
            ch.frame = 0;
        }
    }
}
function spawnFrom409(c, i, pattern) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    f.w04 = pattern;
    f.x = Math.trunc(ch.x + ch.facing * 0x1d);
    f.y = Math.trunc(ch.y - 49.0);
    f.b20 = 2;
    f.b21 = 1;
    f.b18 = ch.facing;
    frameChild(c, f);
}
function child410(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.vx = c.f3140;
        c.a3158[i]++;
        ch.hitsLeft = 1;
    }
    ch.vy = ch.vy + 0.045;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
    if (ch.y + ch.vy >= 0.0) {
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 0x19b;
        c.seRequest = 0x12;
    }
}
function child411(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 7;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child412(c, i) {
    const ch = c.children[i];
    c.f3144 = 2;
    if (cloneInterrupted(c, i)) {
        interruptTo402(c, i);
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 6;
        c.a3258[i] = 0xb4;
    }
    if (ch.frame > 5) c.a3258[i] = c.a3258[i] - 4;
    if (c.a3258[i] < 0xf) c.a3258[i] = 0xf;
    if (ch.frame > 4) setPolarVelocity(c, i, -60.0, c.a3258[i] * 0.01);
    if (ch.frame > 8) {
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 6 || ch.frame === 8) ch.hitState = 0;
        if (ch.frame === 8 && c.a3158[i] < 8) {
            c.a3158[i]++;
            ch.frame -= 2;
            return;
        }
        if (ch.frame >= childCount) {
            c.f3144 = 3;
            c.f314c = 0;
            c.f3148 = 1200;
            c.f3150 = 1;
            c.a3158[i] = 0;
            c.a3258[i] = 0;
            c.freeChild(i);
        }
    }
}
function child413(c, i) {
    const ch = c.children[i];
    if (cloneInterrupted(c, i)) {
        interruptTo402(c, i);
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 4;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 2) ch.vx = 0.6;
        if (ch.frame === 4 && c.a3158[i] < 0x14) {
            c.a3158[i]++;
            ch.frame -= 2;
        }
        if (ch.frame === 7) {
            ch.vy = -0.1;
            ch.vx = 0.0;
        }
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            if (c.a3158[i] < 0xe) {
                c.a3158[i]++;
                ch.frame -= 2;
                return;
            }
            ch.frame = 0;
            ch.timer = 0;
            ch.pattern = 0x19e;
        }
    }
}
function child414(c, i) {
    const ch = c.children[i];
    c.f3144 = 2;
    if (cloneInterrupted(c, i)) {
        interruptTo402(c, i);
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 6;
        c.a3258[i] = 0xb4;
    }
    if (ch.frame > 1) c.a3258[i] = c.a3258[i] - 2;
    if (c.a3258[i] < 0x1e) c.a3258[i] = 0x1e;
    if (ch.frame > 0) setPolarVelocity(c, i, -30.0, c.a3258[i] * 0.01);
    if (ch.frame > 4) {
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 2 || ch.frame === 4) ch.hitState = 0;
        if (ch.frame === 4 && c.a3158[i] < 0xc) {
            c.a3158[i]++;
            ch.frame -= 2;
            return;
        }
        if (ch.frame >= childCount) {
            c.f3144 = 3;
            c.f314c = 0;
            c.f3148 = 1200;
            c.a3158[i] = 0;
            c.a3258[i] = 0;
            c.freeChild(i);
        }
    }
}
registerChildren({
    401: child401,
    402: child402,
    403: child403,
    404: child404,
    406: child406,
    407: child407,
    408: child408,
    409: child409,
    410: child410,
    411: child411,
    412: child412,
    413: child413,
    414: child414
});
