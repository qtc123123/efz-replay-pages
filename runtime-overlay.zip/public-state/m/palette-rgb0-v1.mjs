// Offline successor primitive. Does not confer live admission or an effective frame.
const need=(v,m)=>{if(!v)throw Error('PALETTE: '+m);};
const typed=Object.getPrototypeOf(Uint8Array.prototype);
const lengthOf=Object.getOwnPropertyDescriptor(typed,'byteLength').get;
const bufferOf=Object.getOwnPropertyDescriptor(typed,'buffer').get;
const byteLengthOf=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'byteLength').get;
const resizable=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get;
function exact(v,n){need(v instanceof Uint8Array,'bytes');const b=bufferOf.call(v);byteLengthOf.call(b);need(!resizable?.call(b)&&lengthOf.call(v)===n,'extent');return v;}
const integer=(v,max)=>Number.isInteger(v)&&v>=0&&v<=max;
function key(side,ch,slot,custom){need(integer(side,1)&&integer(ch,24)&&integer(slot,5)&&typeof custom==='boolean','key');return (((side*25+ch)*6+slot)*2)+Number(custom);}
export function parsePalette(value){const b=exact(value,164);const paletteIndex=b[0],reserved=b[1],custom=b[2],characterId=b[3];need(paletteIndex<=5&&reserved===0&&custom<=1&&characterId<=24,'header');for(let i=7;i<164;i+=4)need(b[i]===0,'RGB0');const rgb0=new Uint8Array(160);for(let i=0;i<160;i++)rgb0[i]=b[i+4];return Object.freeze({characterId,paletteIndex,custom:!!custom,rgb0});}
export class PaletteCache{
 #entries=new Array(600).fill(null);#closed=false;#size=0;
 get size(){return this.#size;}
 observe(side,bytes){need(!this.#closed,'closed');const r=parsePalette(bytes),i=key(side,r.characterId,r.paletteIndex,r.custom);if(!this.#entries[i])this.#size++;this.#entries[i]=r;}
 get(side,ch,slot,custom){need(!this.#closed,'closed');const r=this.#entries[key(side,ch,slot,custom)];return r?Object.freeze({...r,rgb0:r.rgb0.slice()}):null;}
 clear(){this.#entries.fill(null);this.#size=0;}
 close(){this.clear();this.#closed=true;}
}
export function bindPaletteRanges(cache,selection){need(Array.isArray(selection)&&selection.length===2,'selection');const ranges=[];for(let side=0;side<2;side++){const s=selection[side];key(side,s.characterId,s.paletteIndex,s.usePal);if(s.usePal){const r=cache.get(side,s.characterId,s.paletteIndex,true);need(r,'missing custom key');ranges.push(Object.freeze({side,...r}));}}return Object.freeze(ranges);}
export function applyPaletteRanges(world,ranges){exact(world,1024);need(Array.isArray(ranges)&&ranges.length<=2,'ranges');let seen=0;const owned=[];for(const r of ranges){need(r&&integer(r.side,1)&&!(seen&(1<<r.side)),'side');seen|=1<<r.side;key(r.side,r.characterId,r.paletteIndex,r.custom);const b=exact(r.rgb0,160);for(let i=3;i<160;i+=4)need(b[i]===0,'RGB0');owned.push({side:r.side,bytes:new Uint8Array(b)});}for(const r of owned)world.set(r.bytes,(95+40*r.side)*4);}
