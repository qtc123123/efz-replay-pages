import policy from "./d3bf6d242edb41cf3b92234f.mjs";
import {mutableConst}from"./7c8c4610099013016950ba12.mjs";
import {publicClassKeys}from"./53f1cc2f52c41342a5e4fc99.mjs";
const need=(v,c)=>{if(!v)throw Error('PUBLIC_CAP_'+c);};
export function createPublicCapabilities(port,resource,{mode='receiver'}={}){
 need(mode==='producer'||mode==='receiver','MODE');const classes=new Map(),raw=port.snapshot(),actors=raw.modules['src/game/chars/index.mjs'].PORTED;
 const battlePrototype=Object.getPrototypeOf(raw.machine.scenes[3]);
 function registerClass(id,obj){need(obj&&typeof obj==='object','OBJECT');const keys=Object.keys(obj).sort();need(JSON.stringify(keys)===JSON.stringify(publicClassKeys(id)),'CLASS_KEYS '+id);classes.set(id,{obj,keys});}
 registerClass('Scene:BattleScene',raw.machine.scenes[3]);
 const caps={
  identify:v=>v&&(typeof v==='object'||typeof v==='function')?resource.identify(v):null,
  has:id=>resource.has(id)||resource.knows(id),resolve:id=>resource.resolve(id),
  type(v){if(Object.getPrototypeOf(v)===battlePrototype)return 'Scene:BattleScene';if(Number.isInteger(v.id)&&Number.isInteger(v.side)&&v.id>=0&&v.id<=24&&v.side>=0&&v.side<=1&&Object.getPrototypeOf(v)===actors[v.id].prototype)return 'Actor:'+v.id+':'+v.side;if([1,10,12,16].includes(v.stage)&&/^Stage(?:1|10|12|16)Object$/.test(v.constructor?.name))return 'Stage:'+v.stage;return null;},
  checkType:(id,keys)=>classes.has(id)&&JSON.stringify(classes.get(id).keys)===JSON.stringify(keys),
  construct(id,keys){need(caps.checkType(id,keys),'FACTORY');return classes.get(id).obj;},registerClass,
  assertStable(){const current=port.snapshot();need(current.modules['src/game/chars/index.mjs'].PORTED===actors&&Object.getPrototypeOf(current.machine.scenes[3])===battlePrototype,'PINNED_FACTORY');},
  rootAnchors(){const out=[],mods=port.snapshot().modules;for(const [file,fields]of Object.entries(policy.moduleFields)){const source=file==='src/game/sound_events.mjs'?'src/platform/audio.mjs':file;for(const key of fields)if(mutableConst(source,key))out.push({file:source,key,value:mods[source][key]});}return out;},
  classObjects:classes,finishCapture(){if(mode==='producer')for(const id of classes.keys())if(id!=='Scene:BattleScene')classes.delete(id);},
  stats(){return {mode,transientClasses:[...classes.keys()].filter(id=>id!=='Scene:BattleScene').length,resources:resource.stats()};}
 };return caps;
}
