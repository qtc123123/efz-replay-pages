import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { setPalette, setPaletteDarken, setPaletteWhiten } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { hasSE, playSE, setBGMVolume, stopBGM } from "./4bc01372141f4e276b2208f4.mjs";
import { replayPath } from "./8d7f594b1298130b3a745321.mjs";
import { checkEscapeKey, isKeyDown, pollInput } from "./06124acd5a2cf7a08d774a8d.mjs";
import { FadeMode, Scene, fadeIn, fadeOut } from "./494d0271e10bf938cecabb23.mjs";
import { GameMode, deleteStageObject, gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { State } from "./2215c2ad4aabedb03c1f6b16.mjs";
import { clearEffects, drawEffects, flushEffectSounds, spawnEffect, updateEffects } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { resolveHits, resolvePush } from "./ceb424a77025444eff76fcfc.mjs";
import { residueBgmVolume, residueChildCode, residueFinishFade, residuePoint, residueRender, residueSound, residueStateCode, residueUnknownAll } from "./88bddfa53ecc3b1f298ce39d.mjs";
import { drawBackground, drawBottomHud, drawComboPanel, drawFinalMask, drawTopHud } from "./117f1785fea24b4d60a86f40.mjs";
export function resetBattleState() {
    clearEffects();
    gs.roundNumber = 1;
    gs.roundOver = 0;
    gs.introState = 1;
    gs.shakeAmp = 0;
    gs.shakeX = gs.shakeY = 0;
    gs.shakeHold = 0;
    gs.shakePhaseX = 0;
    gs.shakePhaseY = 0;
    gs.cameraBiasFrames = 0;
    gs.cameraYBiasFrames = 0;
    gs.bgbFrames = 0;
    gs.flashMode = 0;
    gs.specialTimerC = gs.specialTimerE = 0;
    gs.speedRequest = 0;
    gs.bgmStep = 0;
    gs.bgmVolume = 0;
}
export class BattleScene extends Scene {
    fpsCount = 0;
    fpsTime = 0;
    fps = 0;
    camBias = 0;
    camYHigh = -50;
    camBiasNow = 0;
    camYFactor = -50;
    camXs = -160;
    camYs = 0;
    camX = -160;
    camY = 0;
    exit = 0;
    ticksPerFrame = 3;
    endTimer = 0;
    paused = 0;
    fnLatch = 0;
    debugGauge = 0;
    debugLife = 9999;
    constructor(){
        super();
        this.enterState = 1;
    }
    get p1() {
        return gs.chars[0];
    }
    get p2() {
        return gs.chars[1];
    }
    async update() {
        residuePoint("start");
        const now = __session.now();
        if (now - this.fpsTime >= 1000) {
            this.fpsTime = now;
            this.fps = this.fpsCount;
            this.fpsCount = 0;
        }
        this.fpsCount++;
        if (this.enterState === 1) {
            gs.introState = 1;
            this.camBias = 0;
            this.camYHigh = -50;
            this.camBiasNow = this.camBias;
            this.camYFactor = this.camYHigh;
            this.camXs = -160;
            this.camYs = 0;
            this.ticksPerFrame = 3;
            this.debugGauge = 0;
            this.debugLife = 9999;
            this.updateCamera();
            this.render();
            this.palette.set(gs.palette);
            await fadeIn(this, FadeMode.Black);
            this.enterState = 0;
            residueUnknownAll();
        } else if (this.exit === 1) {
            await fadeOut(this, FadeMode.White, 0, 100);
            gs.chars = [
                null,
                null
            ];
            deleteStageObject();
            this.exit = 0;
            this.enterState = 1;
            if (gs.replayMode > 0) {
                gs.replayFile.close();
                gs.replayMode = 0;
                stopBGM();
                return State.Replay;
            }
            return gs.mode === GameMode.Demo ? State.Title : State.CharacterSelect;
        }
        await this.systemKeys();
        if (this.paused) return State.Battle;
        if (this.exit === 2) {
            this.ticksPerFrame = 1;
            if (this.finishFade()) {
                this.exit = 0;
                this.enterState = 1;
                if (gs.replayMode > 0) {
                    gs.replayFile.close();
                    gs.replayMode = 0;
                    stopBGM();
                    gs.chars = [
                        null,
                        null
                    ];
                    deleteStageObject();
                    return State.Replay;
                }
                return State.Result;
            }
        } else if (gs.speedRequest !== 0) {
            this.ticksPerFrame = gs.speedTicks;
            gs.speedRequest = 0;
        }
        const p1 = this.p1;
        const p2 = this.p2;
        for(let i = 0; i < this.ticksPerFrame; i++){
            residuePoint("loop");
            p1.readInput();
            p2.readInput();
            this.roundIntro();
            p1.preTick();
            p2.preTick();
            residuePoint("pre_vt20");
            p1.tickHook();
            p2.tickHook();
            residuePoint("pre_vt18");
            for (const c of [
                p1,
                p2
            ]){
                const state = c.state;
                const skipped = c.hitstop > 0 || c.opponent.freeze > 0;
                c.updateState();
                residueStateCode(c, state, skipped);
            }
            residuePoint("pre_vt1c");
            for (const c of [
                p1,
                p2
            ]){
                const before = c.childActive.some((v)=>v !== 0);
                c.updateChildren();
                residueChildCode(c, before || c.childActive.some((v)=>v !== 0));
            }
            residuePoint("post_vt1c");
            if (gs.roundOver === 0 && gs.introState === 0) resolveHits(p1, p2);
            residuePoint("post766");
            resolvePush(p1, p2);
            residuePoint("post_push");
            p1.integrate();
            p2.integrate();
            residuePoint("post_integ");
            for (const c of [
                p1,
                p2
            ])c.freeze = c.freeze > 0 ? c.freeze - 1 : 0;
            p1.tickTimers();
            p2.tickTimers();
            residuePoint("post_timers");
            this.flushCharacterSounds();
            residuePoint("post_snd");
            flushEffectSounds(this.exit === 2);
            residuePoint("post_fxsnd");
            this.judgeRound();
            residuePoint("post_judge");
        }
        residuePoint("loopexit");
        this.screenFlash();
        residuePoint("post_flash");
        this.tickGlobalTimers();
        residuePoint("post_gtimer");
        this.updateCamera();
        residuePoint("post_cam");
        if (gs.option0 || gs.frameParity) {
            this.render();
            residueRender();
        }
        residuePoint("post_render");
        updateEffects();
        residuePoint("post_fx");
        gs.stageObject?.update();
        residuePoint("post_stage");
        return State.Battle;
    }
    async systemKeys() {
        if (gs.replayMode === 1 && gs.replayFile.eof) {
            gs.replayFile.eof = 0;
            this.exit = 1;
        }
        if (checkEscapeKey()) {
            this.exit = 1;
            this.paused = 0;
        }
        if (this.exit === 0 && gs.mode === GameMode.Demo) {
            pollInput();
            const [i1, i2] = gs.input;
            if (i1.a || i2.a || i1.b || i2.b || checkEscapeKey()) {
                this.exit = 1;
                stopBGM();
                this.paused = 0;
            }
        }
        const debugMode = gs.mode !== GameMode.Arcade && gs.mode !== GameMode.Score && gs.mode !== GameMode.Demo;
        if (isKeyDown("F4") && gs.introState === 0 && gs.roundOver === 0 && debugMode) {
            this.debugGauge = this.debugGauge + 5 << 16 >> 16;
            if (this.debugGauge > 2000) this.debugGauge = 0;
            this.debugLife = 9999;
            this.copyDebugValues();
        } else if (isKeyDown("F5") && !this.fnLatch && debugMode) {
            if (this.debugGauge === 1000) {
                if (this.debugLife === 3332) this.debugGauge = 2000;
                else this.debugLife = 3332;
            } else {
                this.debugGauge = 1000;
            }
            this.copyDebugValues();
            this.fnLatch = 1;
        }
        if (gs.mode === GameMode.Practice) {
            if (isKeyDown("F6") && !this.fnLatch) {
                gs.practiceDummyStance = gs.practiceDummyStance + 1 > 2 ? 0 : gs.practiceDummyStance + 1;
                this.fnLatch = 1;
            } else if (isKeyDown("F7") && !this.fnLatch) {
                gs.practiceAutoGuard = gs.practiceAutoGuard ? 0 : 1;
                this.fnLatch = 1;
            }
        } else if (gs.mode === GameMode.Replay && gs.replayMode === 2 && isKeyDown("F6")) {
            await this.restartRecording();
        }
        if (isKeyDown("F8") && !this.fnLatch) {
            this.paused = this.paused ? 0 : 1;
            this.fnLatch = 1;
        }
        if (this.debugGauge === 2000) {
            this.debugGauge = 0;
            this.debugLife = 9999;
            this.copyDebugValues();
            this.p1.life = 9999;
            this.p2.life = 9999;
        }
        this.fnLatch = isKeyDown("F5") || isKeyDown("F6") || isKeyDown("F7") || isKeyDown("F8") ? 1 : 0;
        if (gs.replayMode === 1 && this.paused === 0) {
            if (gs.replayVersion > 0) {
                this.debugGauge = gs.replayFile.readWord() << 16 >> 16;
                this.debugLife = gs.replayFile.readWord() << 16 >> 16;
            } else {
                this.debugGauge = 1000;
                this.debugLife = 9999;
            }
            this.copyDebugValues();
        } else if (gs.replayMode === 2 && this.paused === 0) {
            gs.replayFile.writeWord(this.debugGauge);
            gs.replayFile.writeWord(this.debugLife);
        }
    }
    async restartRecording() {
        if (gs.mode !== GameMode.Replay || gs.replayMode !== 2) return;
        const p1 = this.p1;
        const p2 = this.p2;
        this.palette.set(gs.palette);
        await fadeOut(this, FadeMode.Black, 0, 0);
        const file = gs.replayFile;
        file.close();
        file.create(replayPath(gs.replayCol + 1, gs.replayRow + 1));
        file.writeWord(p1.id);
        file.writeWord(p2.id);
        file.writeWord(0x68);
        file.writeWord(gs.stage);
        file.writeWord(p1.color);
        file.writeWord(p2.color);
        resetBattleState();
        p1.load();
        p2.load();
        p1.debugGauge = this.debugGauge;
        p2.debugGauge = this.debugGauge;
        gs.introState = 1;
        this.camBias = 0;
        this.camYHigh = -50;
        this.camBiasNow = this.camBias;
        this.camYFactor = this.camYHigh;
        this.camXs = -160;
        this.camYs = 0;
        this.ticksPerFrame = 3;
        this.updateCamera();
        this.render();
        this.palette.set(gs.palette);
        await fadeIn(this, FadeMode.Black);
    }
    copyDebugValues() {
        for (const c of [
            this.p1,
            this.p2
        ]){
            c.debugGauge = this.debugGauge;
            c.debugLife = this.debugLife;
        }
    }
    roundIntro() {
        if (gs.introState === 1) {
            spawnEffect({
                pat: 0x1b,
                x: 160.0,
                y: 120.0,
                blend: 2,
                layer: 2,
                fixed: 1,
                sound: 0xff
            });
            gs.introState = 0x63;
        } else if (gs.introState === 2) {
            spawnEffect({
                pat: 5,
                x: 160.0,
                y: 120.0,
                blend: 2,
                layer: 2,
                fixed: 1,
                sound: gs.roundNumber + 11
            });
            gs.introState = 0x63;
        }
    }
    flushCharacterSounds() {
        for (const c of [
            this.p1,
            this.p2
        ]){
            if (this.exit !== 2) {
                if (c.seRequest >= 0 && c.seRequest < 65) {
                    playSE(c.seRequest);
                    if (hasSE(c.seRequest)) residueSound();
                }
                if (c.voiceRequest >= 0 && c.voiceRequest < 50) {
                    c.playVoice(c.voiceRequest);
                    if (c.hasVoice(c.voiceRequest)) residueSound();
                }
            }
            c.seRequest = 0xff;
            c.voiceRequest = 0xff;
        }
    }
    judgeRound() {
        if (this.debugGauge !== 0 || gs.mode === GameMode.Practice) return;
        const p1 = this.p1;
        const p2 = this.p2;
        if (gs.roundOver) {
            for (const c of [
                p1,
                p2
            ])c.pressed.fill(0);
            for (const c of [
                p1,
                p2
            ]){
                if (c.state >= 50 && !c.isReadyPose()) return;
            }
            if (this.exit === 2) return;
            gs.roundOver = 0;
            p1.life = p2.life = 9999;
            gs.introState = 2;
            return;
        }
        if (p1.life <= 0 && p2.life <= 0) {
            for (const c of [
                p1,
                p2
            ]){
                c.wins++;
                if (c.wins >= gs.winRounds) c.wins--;
                c.state = 0x3b;
                c.onStateChange();
            }
            gs.roundOver = 1;
            if (gs.roundNumber < 9) gs.roundNumber++;
            return;
        }
        const ko = (loser, winner, effectX, winnerIndex)=>{
            winner.lifeBonus += winner.life;
            if (winner.wins < gs.winRounds - 1) {
                winner.wins++;
                loser.freeze += 180;
                winner.freeze += 180;
                loser.onStateChange();
                spawnEffect({
                    pat: 0x13,
                    x: effectX,
                    y: 100.0,
                    blend: 0,
                    layer: 2,
                    fixed: 1,
                    sound: 0x1d
                });
                gs.roundOver = 1;
                if (gs.roundNumber < 9) gs.roundNumber++;
            } else {
                winner.wins++;
                loser.onStateChange();
                gs.roundOver = 1;
                this.exit = 2;
                this.endTimer = 0;
                gs.winner = winnerIndex;
            }
        };
        if (p1.life <= 0 && p1.w140 === 0) ko(p1, p2, 80.0, 1);
        else if (p2.life <= 0 && p2.w140 === 0) ko(p2, p1, 240.0, 0);
    }
    finishFade() {
        const t = this.endTimer;
        if (t < 100) {
            setPaletteWhiten(gs.palette, 0, 255, Math.trunc(100 - t));
            setBGMVolume(Math.trunc(-t * 100.0 / 2.0) + gs.bgmVolume);
            residueFinishFade(t === 0);
        }
        this.endTimer = t + 1.0;
        return this.endTimer >= 200.0;
    }
    screenFlash() {
        const whiten = (level)=>{
            setPaletteWhiten(gs.palette, 1, 0xff, level);
            residueUnknownAll();
        };
        const darken = (level)=>{
            setPaletteDarken(gs.palette, 1, 0xff, level);
            residueUnknownAll();
        };
        if (gs.flashMode === 1) {
            if (gs.flashIn > 0) {
                gs.flashValue += (100 - gs.flashValue) / gs.flashIn;
                if (gs.flashValue > 100) gs.flashValue = 100;
                if (gs.flashValue > 0) whiten(100 - Math.trunc(gs.flashValue));
                gs.flashIn--;
            } else if (gs.flashHold > 0) {
                gs.flashHold--;
            } else if (gs.flashValue > 0) {
                gs.flashValue -= 100.0 / gs.flashOut;
                if (gs.flashValue <= 0) gs.flashValue = 0;
                whiten(100 - Math.trunc(gs.flashValue));
            } else {
                gs.flashMode = 0;
            }
        } else if (gs.flashMode === -1) {
            if (gs.flashIn > 0) {
                gs.flashValue -= (gs.flashValue + 100) / gs.flashIn;
                if (gs.flashValue < -100) gs.flashValue = -100;
                if (gs.flashValue < 0) darken(Math.trunc(gs.flashValue) + 100);
                gs.flashIn--;
            } else if (gs.flashHold > 0) {
                gs.flashHold--;
            } else if (gs.flashValue < 0) {
                gs.flashValue += 100.0 / gs.flashOut;
                if (gs.flashValue >= 0) gs.flashValue = 0;
                darken(Math.trunc(gs.flashValue) + 100);
            } else {
                gs.flashMode = 0;
            }
        }
    }
    tickGlobalTimers() {
        if (gs.specialTimerE > 0) gs.specialTimerE--;
        if (gs.specialTimerC > 0) gs.specialTimerC--;
        if (gs.bgmStep > 0) {
            if (gs.bgmTarget > gs.bgmVolume) {
                gs.bgmVolume = gs.bgmVolume + gs.bgmStep | 0;
                if (gs.bgmTarget <= gs.bgmVolume) {
                    gs.bgmVolume = gs.bgmTarget;
                    gs.bgmStep = 0;
                }
            } else {
                gs.bgmVolume = gs.bgmVolume - gs.bgmStep | 0;
                if (gs.bgmTarget >= gs.bgmVolume) {
                    gs.bgmVolume = gs.bgmTarget;
                    gs.bgmStep = 0;
                }
            }
            setBGMVolume(gs.bgmVolume);
            residueBgmVolume();
        }
    }
    updateCamera() {
        const p1 = this.p1;
        const p2 = this.p2;
        const noFreeze = ()=>p1.hitstop === 0 && p2.hitstop === 0 && p1.freeze === 0 && p2.freeze === 0;
        this.camBiasNow = this.camBias;
        if (gs.cameraBiasFrames > 0) {
            this.camBiasNow = gs.cameraBias;
            if (noFreeze()) gs.cameraBiasFrames--;
        }
        let tx = 160 - Math.trunc(((this.camBiasNow + 50) * p1.x + (50 - this.camBiasNow) * p2.x) / 100.0);
        tx = Math.min(Math.max(tx, -319), 0);
        if (this.camXs < tx) {
            this.camXs -= Math.trunc((this.camXs - tx) / 15) - 1;
            if (this.camXs > tx) this.camXs = tx;
        } else {
            this.camXs -= Math.trunc((this.camXs - tx) / 15) + 1;
            if (this.camXs < tx) this.camXs = tx;
        }
        this.camYFactor = p1.y < -240.0 || p2.y < -240.0 ? this.camYHigh : 20;
        if (gs.cameraYBiasFrames > 0) {
            this.camYFactor = (p1.y < p2.y ? -1 : 1) * gs.cameraYBias;
            if (noFreeze()) gs.cameraYBiasFrames--;
        }
        const a = p1.y < 0 ? 1 : 0;
        const b = p2.y < 0 ? 1 : 0;
        const s = p1.y - p2.y < 0 ? 1 : 0;
        const y1 = Math.trunc(p1.y);
        const y2 = Math.trunc(p2.y);
        let ty = -Math.trunc((y1 - a + (y2 - b)) / 2) + Math.trunc((y1 - a - y2 + b) * this.camYFactor / 100) * (2 * s - 1);
        ty = Math.min(Math.max(ty, 0), 240);
        if (this.camYs < ty) {
            this.camYs -= Math.trunc((this.camYs - ty) / 10) - 1;
            if (this.camYs > ty) this.camYs = ty;
        } else {
            this.camYs -= Math.trunc((this.camYs - ty) / 10) + 1;
            if (this.camYs < ty) this.camYs = ty;
        }
        this.updateShake();
        gs.viewLeft = -this.camXs;
        gs.viewTop = -this.camYs - 210;
        gs.viewRight = gs.viewLeft + 320;
        gs.viewBottom = gs.viewTop + 240;
        this.camX = this.camXs + gs.shakeX;
        this.camY = this.camYs + gs.shakeY;
    }
    updateShake() {
        if (gs.shakeAmp < 1.0) return;
        gs.shakeX = Math.trunc(__numerics.cos(gs.shakePhaseX * 3.141592 / 180) * gs.shakeAmp);
        gs.shakeY = Math.trunc(__numerics.sin(gs.shakePhaseY * 3.141592 / 180) * gs.shakeAmp);
        gs.shakePhaseX += 83;
        if (gs.shakePhaseX >= 360) gs.shakePhaseX -= 360;
        gs.shakePhaseY += 107;
        if (gs.shakePhaseY >= 360) gs.shakePhaseY -= 360;
        if (gs.shakeHold > 0) gs.shakeHold--;
        else gs.shakeAmp *= 0.95;
        if (gs.shakeAmp < 1.0) {
            gs.shakeAmp = 0;
            gs.shakeX = gs.shakeY = 0;
        }
    }
    render() {
        __session.render();
        const p1 = this.p1;
        const p2 = this.p2;
        if (!p1 || !p2) return;
        const cx = this.camX;
        const cy = this.camY;
        p1.sampleAfterimage();
        p2.sampleAfterimage();
        drawBackground(this);
        drawTopHud(this);
        p1.drawShadow(cx, cy);
        p2.drawShadow(cx, cy);
        drawEffects(cx, cy, 0);
        p1.drawChildren(cx, cy, 0);
        p2.drawChildren(cx, cy, 0);
        const shake = (c)=>cx + 2 * (c.isBeingHit() ? 1 : 0) * (c.hitstop % 2);
        const order = p2.state >= 200 ? [
            p1,
            p2
        ] : [
            p2,
            p1
        ];
        for (const c of order)c.draw(shake(c), cy);
        p1.drawChildren(cx, cy, 1);
        p2.drawChildren(cx, cy, 1);
        drawEffects(cx, cy, 1);
        drawEffects(cx, cy, 2);
        drawEffects(cx, cy, 3);
        if (gs.stageObject && p1.darkenFrames === 0 && p2.darkenFrames === 0 && gs.bgbFrames === 0) {
            gs.stageObject.draw(cx, cy, 1);
        }
        if (gs.specialTimerC === 0) {
            p1.renderOverlay();
            p2.renderOverlay();
        }
        drawBottomHud(this);
        for (const c of [
            p1,
            p2
        ]){
            if (c.comboDisplay > 1 && c.comboTimer > 0) drawComboPanel(this, c);
        }
        drawFinalMask(this);
    }
    applyPalette() {
        if (gs.flashMode === 0 && this.exit !== 2) setPalette(gs.palette);
    }
}
