import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./2997ced5c6273385064924f8.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./d2cd6c2c9053eff29ff0ef4e.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
const LEVEL_PAT = [
    0x44,
    0x45,
    0x46
];
const LEVEL_SOUND = [
    0x13,
    5,
    0x40
];
function superEffect(d, level, x, y) {
    d.w04 = LEVEL_PAT[level];
    d.b2c = LEVEL_SOUND[level];
    d.x = x;
    d.y = y;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function rushSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atFrame(c, 2)) {
        c.stopMotion();
        superFreeze(c, (p.level + 1) * 1000);
        superEffect(d, p.level, ftol(c.x) + c.facing * 0xd, ftol(c.y) - 0x34);
        if (p.level === 2) c.seRequest = 0x25;
    }
    if (p.level === 2 && c.frame > 1) c.showAltBackground(0xf);
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
    }
    if ((c.frame === 5 || c.frame === 6) && c.d168 === 3) {
        c.frame = 7;
        c.timer = 0;
        c.d168 = 0;
    }
    if (c.frame === 7 || c.frame === 8) {
        if (!(c.f3140 > 0)) {
            d.w04 = 0x22;
            d.x = ftol(c.x) + c.facing * 0xa - c.random(0, 8);
            d.y = ftol(c.y) + 3 - c.random(0, 6);
            d.b20 = 2;
            d.b21 = 1;
            frameEffect(d);
            c.f3140 = 2;
        }
        c.f3140--;
        c.biasCameraY(0x32, 0x1e);
        o.state = 0x68;
        o.onStateChange();
        o.stopMotion();
        o.y = 0.0;
        o.x = (27.0 + c.vx) * c.facing + c.x;
        o.y = c.y - 50.0;
        o.facing = -c.facing;
        if (c.x > 580.0 && c.facing === 1 || c.x < 60.0 && c.facing === -1) {
            if (c.x > 580.0 && c.facing === 1) c.x = 600.0;
            if (c.x < 60.0 && c.facing === -1) c.x = 40.0;
            c.timer = 0;
            c.frame = 9;
            c.stopMotion();
            o.onStateChange();
            o.state = 0x3b;
            o.x = (c.facing === 1 ? 1 : 0) * 0x280;
            o.y = -1.0;
            o.knockX = -2.0;
            o.knockY = p.knockY;
            applyDirectDamage(c, p.damage, 900.0);
            if (p.level === 1) {
                if (c.f313c === 0) o.w140 = 0x4650;
                if (c.f313c > 0) o.w140 = 0;
            }
            if (p.level === 2) o.w140 = c.f313c < 2 ? 0x4650 : 0;
            o.hitstop = 0x5a;
            if (p.level === 1 && c.f313c === 0) o.hitstop = 0x12c;
            if (p.level === 2 && c.f313c < 2) o.hitstop = 0x12c;
            c.shakeScreen(10, 10);
            d.w04 = 0x195;
            d.x = c.x;
            d.y = 0.0;
            d.b20 = 2;
            d.b21 = 1;
            c.seRequest = 0x16;
            frameChild(c, d);
            c.voiceRequest = 0;
            c.d168 = 3;
        }
    }
    if (p.level === 1 && c.frame === 0xb && c.timer === 0x5a && c.f313c === 0) {
        c.frame = 7;
        c.timer = 0;
        c.facing = -c.facing;
        c.vx = 2.7;
        c.f313c = 1;
    }
    if (p.level === 2 && c.frame === 0xb && c.timer === 0x5a && c.f313c < 2) {
        c.frame = 7;
        c.timer = 0;
        c.facing = -c.facing;
        c.vx = 2.7;
        c.f313c++;
    }
    if (c.frame > 0xb && c.frame < 0x13) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.y = 0.0;
            c.vx = c.vx * 0.5;
            c.vy = 0.0;
            c.frame = 0x13;
            c.timer = 0;
            return;
        }
    }
    if (c.frame > 0x12) {
        c.vx = c.vx - 0.025;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 4) {
        c.vx = p.vx4;
        d.w04 = 0x1f;
        d.x = ftol(c.x) + c.facing * 0xa;
        d.y = ftol(c.y) + 4;
        d.b20 = 0;
        d.b21 = 1;
        d.d1c = c.facing === -1 ? 1 : 0;
        frameEffect(d);
    }
    if (p.w13c !== null && c.frame === 5) c.w13c = p.w13c;
    if (c.frame === 7 && c.f3138 < p.loops) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame === 7) c.frame = 0x13;
    if (c.frame === 9) c.frame -= 2;
    if (c.frame === 0xc) {
        c.vx = -2.0;
        c.vy = -1.5;
        c.ay = 0.035;
    }
    if (c.frame >= cnt) {
        c.state = 3;
        c.onStateChange();
    }
}
function summonSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        c.f313c = 0;
        c.stopMotion();
        superFreeze(c, (p.level + 1) * 1000);
        superEffect(d, p.level, ftol(c.x) + c.facing * 0x17, ftol(c.y) - 0x1e);
        if (p.level === 2) c.seRequest = 0x25;
    }
    if (p.level === 2 && c.frame > 0) c.showAltBackground(0xf);
    if (c.frame > 0x10 && c.frame < 0x16) {
        c.f313c++;
        for (const s of p.spawns){
            if (c.f313c !== s.at) continue;
            d.w04 = s.pat;
            d.x = ftol(c.x) + c.facing * s.dx;
            d.y = ftol(c.y) + s.dy;
            d.b20 = 0;
            d.b21 = s.layer;
            d.d28 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
        }
    }
    if (atFrame(c, 0x11)) {
        d.w04 = 0x196;
        c.voiceRequest = 3;
        d.x = ftol(c.x) + c.facing * 0x72;
        d.y = ftol(c.y) - 0x2a;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.f3138++;
    }
    if (c.frame > 1) c.biasCameraY(0x32, 3);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 0x16 && c.f3138 < p.loops) c.frame = 0x11;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
const SUMMON_306 = [
    {
        at: 0x30,
        pat: 0x198,
        dx: 0x28,
        dy: -3,
        layer: 0
    },
    {
        at: 0x4e,
        pat: 0x19b,
        dx: 0x28,
        dy: 6,
        layer: 1
    }
];
const SUMMON_307 = [
    {
        at: 0x1e,
        pat: 0x198,
        dx: 0x3c,
        dy: -1,
        layer: 0
    },
    {
        at: 0x37,
        pat: 0x19b,
        dx: 0x28,
        dy: 6,
        layer: 1
    },
    {
        at: 0x46,
        pat: 0x199,
        dx: -0xa,
        dy: 0,
        layer: 0
    },
    {
        at: 0x55,
        pat: 0x19c,
        dx: -0x28,
        dy: 8,
        layer: 1
    }
];
const SUMMON_308 = [
    {
        at: 0x1e,
        pat: 0x198,
        dx: 0x50,
        dy: -1,
        layer: 0
    },
    {
        at: 0x37,
        pat: 0x19b,
        dx: 0x64,
        dy: 6,
        layer: 1
    },
    {
        at: 0x46,
        pat: 0x199,
        dx: -0xa,
        dy: 0,
        layer: 0
    },
    {
        at: 0x55,
        pat: 0x19c,
        dx: -0x28,
        dy: 0xa,
        layer: 1
    },
    {
        at: 0x64,
        pat: 0x19a,
        dx: 0x37,
        dy: 5,
        layer: 1
    },
    {
        at: 0x73,
        pat: 0x19d,
        dx: -0x46,
        dy: 2,
        layer: 0
    }
];
function spawn416(c, d, dx, y, layer) {
    d.w04 = 0x1a0;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = y;
    d.b20 = 2;
    d.b21 = layer;
    d.b18 = c.facing;
    frameChild(c, d);
}
function grabSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, p.triggerFrame)) {
        superFreeze(c, (p.level + 1) * 1000);
        superEffect(d, p.level, ftol(c.x) - c.facing * 0x18, ftol(c.y) - 0x35);
        if (p.level === 2) c.seRequest = 0x25;
    }
    if (p.level === 2 && c.frame > 0) c.showAltBackground(0xf);
    if (c.frame === 5 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = p.next;
        o.state = 0x65;
        o.x = c.facing * 0x12 + c.x;
        o.y = -87.0;
        o.facing = -c.facing;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x12;
        d.y = ftol(c.y) - 0x57;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (c.frame > 9 && c.frame < 0xc) {
        c.f313c++;
        if (c.f313c === 0xc) {
            spawn416(c, d, 0x32, -240.0, 0);
            spawn416(c, d, -0x32, -240.0, 0);
        }
        if (c.f313c === 0x15) {
            spawn416(c, d, 0x46, -210.0, 1);
            spawn416(c, d, -0x46, -210.0, 1);
        }
    }
    if (c.frame > 1) c.biasCameraY(0x32, 3);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 5 && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 0xc && c.f3138 < 8) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function barrageSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (p.level === 2 && c.frame > 0) c.showAltBackground(0xf);
    c.biasCameraY(0x32, 3);
    if (c.frame === 4 || c.frame === 5) {
        c.f313c++;
        if (c.f313c === p.interval && c.f3138 < p.maxShots) {
            c.f313c = 0;
            d.w04 = 0x1a0;
            d.x = ftol(c.x) + c.random(0, p.range) - p.range / 2;
            d.y = -230 - c.random(0, 0x14);
            d.b20 = 2;
            d.b21 = d.y > -240.0 ? 1 : 0;
            d.b18 = c.facing;
            frameChild(c, d);
            d.w04 = 0;
            d.x = ftol(c.x) + c.facing * 0x12;
            d.y = ftol(c.y) - 0x57;
            d.b20 = 2;
            d.b2c = 2;
            d.b21 = 1;
            frameEffect(d);
            o.hitstop = 0x1e;
            c.shakeScreen(3, 0);
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 1) {
        o.x = (c.facing << 4) + c.x;
        o.y = -95.0;
        o.state = 0x65;
        o.onStateChange();
    }
    if (c.frame === 2) {
        o.x = c.facing * 0xd + c.x;
        o.y = -98.0;
        o.state = 0x65;
    }
    if (c.frame === 3) {
        o.x = c.facing * 0xd + c.x;
        o.y = -97.0;
        o.state = 0x65;
    }
    if (c.frame === 6 && c.f3138 < p.loops) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame === 6) {
        o.x = c.x;
        o.y = -88.0;
        o.state = 0x3b;
        applyDirectDamage(c, p.damage, 750.0);
        o.onStateChange();
        o.stopMotion();
        o.facing = -c.facing;
        o.knockX = -1.5;
        o.knockY = -1.0;
        spawn416(c, d, 0x32, -240.0, 0);
        spawn416(c, d, -0x32, -240.0, 0);
        spawn416(c, d, 0, -225.0, 1);
        spawn416(c, d, 0x46, -210.0, 1);
        spawn416(c, d, -0x46, -210.0, 1);
        if (p.level >= 1) {
            spawn416(c, d, 0x5a, -240.0, 1);
            spawn416(c, d, -0x5a, -240.0, 1);
        }
        if (p.level === 2) {
            spawn416(c, d, 0x64, -230.0, 0);
            spawn416(c, d, -0x64, -230.0, 0);
        }
    }
    if (c.frame === 9 && c.f3140 < 0xf) {
        c.frame -= 2;
        c.f3140++;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
registerStates({
    300: (c)=>rushSuper(c, {
            level: 0,
            vx4: 2.5,
            w13c: null,
            loops: 1,
            damage: 0x8ca,
            knockY: -2.9
        }),
    301: (c)=>rushSuper(c, {
            level: 1,
            vx4: 3.0,
            w13c: 9,
            loops: 2,
            damage: 0x6d6,
            knockY: -2.9
        }),
    302: (c)=>rushSuper(c, {
            level: 2,
            vx4: 3.5,
            w13c: 0x2d,
            loops: 4,
            damage: 0x708,
            knockY: -3.9
        }),
    306: (c)=>summonSuper(c, {
            level: 0,
            spawns: SUMMON_306,
            loops: 8
        }),
    307: (c)=>summonSuper(c, {
            level: 1,
            spawns: SUMMON_307,
            loops: 0xc
        }),
    308: (c)=>summonSuper(c, {
            level: 2,
            spawns: SUMMON_308,
            loops: 0x19
        }),
    309: (c)=>grabSuper(c, {
            level: 0,
            triggerFrame: 1,
            next: 0x136
        }),
    310: (c)=>barrageSuper(c, {
            level: 0,
            interval: 0x1e,
            maxShots: 7,
            range: 0x78,
            loops: 0xc,
            damage: 0x546
        }),
    311: (c)=>grabSuper(c, {
            level: 1,
            triggerFrame: 1,
            next: 0x138
        }),
    312: (c)=>barrageSuper(c, {
            level: 1,
            interval: 0x1a,
            maxShots: 0xf,
            range: 0xa0,
            loops: 0x12,
            damage: 0x992
        }),
    313: (c)=>grabSuper(c, {
            level: 2,
            triggerFrame: 0,
            next: 0x13a
        }),
    314: (c)=>barrageSuper(c, {
            level: 2,
            interval: 0xf,
            maxShots: 0x18,
            range: 0xc8,
            loops: 0x1b,
            damage: 0xd7a
        })
});
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    if (childStep(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function child406(c, i) {
    if (c.a3154[i] === 0) {
        c.children[i].hitsLeft = 1;
        c.a3154[i]++;
    }
    childOnce(c, i);
}
function childSummon(c, i, dx, dy) {
    const ch = c.children[i];
    if (!(c.state >= 0x132 && c.state <= 0x134 && c.frame <= 0x15)) {
        if (ch.frame < 0xa) {
            ch.timer = 0;
            ch.frame = 0xa;
        }
    }
    if (ch.frame === 5 && ch.timer === 0) {
        ch.hitsLeft = 1;
        const d = childSpawnFrame;
        d.w04 = 0x197;
        d.x = ftol(ch.x) + ch.facing * dx;
        d.y = ftol(ch.y) - dy;
        d.b20 = 2;
        d.b2c = 4;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
    }
    if (!childStep(c, i)) return;
    if (ch.frame === 9 && c.frame < 0x16) ch.frame = 4;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child416(c, i) {
    const ch = c.children[i];
    if (c.a3154[i] === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 5;
        c.a3154[i]++;
    }
    if (ch.frame === 3 && ch.timer === 0) {
        ch.hitsLeft = 1;
        const d = childSpawnFrame;
        d.w04 = 0x1a1;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y) + 0xa0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
    }
    childOnce(c, i);
}
registerChildren({
    405: childOnce,
    406: child406,
    407: childOnce,
    408: (c, i)=>childSummon(c, i, 0x3f, 0x5d),
    409: (c, i)=>childSummon(c, i, 0x3f, 0x5d),
    410: (c, i)=>childSummon(c, i, 0x3f, 0x5d),
    411: (c, i)=>childSummon(c, i, 0x30, 0x35),
    412: (c, i)=>childSummon(c, i, 0x30, 0x35),
    413: (c, i)=>childSummon(c, i, 0x2b, 0x35),
    416: child416,
    417: childOnce
});

export function __logicState(){return {LEVEL_PAT,LEVEL_SOUND,SUMMON_306,SUMMON_307,SUMMON_308};}

export function __installInitialRoots(s){
if(LEVEL_PAT!==s["LEVEL_PAT"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_PAT');
if(LEVEL_SOUND!==s["LEVEL_SOUND"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_SOUND');
if(SUMMON_306!==s["SUMMON_306"])throw Error('INITIAL_CONST_IDENTITY:SUMMON_306');
if(SUMMON_307!==s["SUMMON_307"])throw Error('INITIAL_CONST_IDENTITY:SUMMON_307');
if(SUMMON_308!==s["SUMMON_308"])throw Error('INITIAL_CONST_IDENTITY:SUMMON_308');
}
