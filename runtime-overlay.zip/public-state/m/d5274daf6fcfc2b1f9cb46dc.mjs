import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { registerChildren, registerChildren2 } from "./81433295782a220b1d5e4d42.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, openSpawnFrame } from "./2ed079700202e720d67705c7.mjs";
import { ftol } from "./7596266716c972d06fe8897a.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
function chance2(c) {
    const r = rnd(c, 0, 100);
    return c.aiLevel + c.aiLevel > r;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = rnd(c, 0, 2) - 1;
}
function dashCommand(c) {
    return c.facing === 1 ? 1 : 0;
}
function rfOk(c) {
    return c.rfGauge > 500.0 || c.rfBlue > 0;
}
export function thinkIkumi(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25.0 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 170 ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 149 && c.state < 157 ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40.0 * c.aiLevel > r && c.state > 199) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 200) c.aiMode = 0;
        return;
    }
    if (o.state === 96) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 50 && c.state <= 150 && c.timer === 0) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 50 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 240) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 320) < dx ? 1 : 0;
        if (o.state > 199 && o.state < 250 && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 10 && c.state <= 12) && c.y === 0.0) return;
    if (o.state >= 50 && o.state < 150 && c.state === 264 && c.w16c > 1) return;
    if (c.state === 168 && c.timer < 6) {
        if (o.state !== 200 && o.state !== 204 && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx < 40.0 && chance(c, 3.0)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && chance2(c)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
        }
        if ((o.state === 201 || o.state === 202 || o.state === 205) && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx > 20.0 && dx < 60.0 && chance2(c)) {
                c.pressed[1] = 1;
                c.inputY = 1;
                c.inputX = 0;
                return;
            }
            if (dx > 60.0 && dx < 80.0 && chance2(c)) {
                c.pressed[0] = 3;
                c.inputY = 1;
                return;
            }
        }
    }
    if (c.state === 168 || c.state === 169) {
        if (dx < 100.0) {
            if (chance(c, 3.0) && c.rfGauge > 500.0) {
                c.command = 22;
                return;
            }
            if (chance(c, 1.0) && c.rfGauge > 500.0) {
                c.command = 12;
                return;
            }
            if (chance2(c) && dx < 80.0 && c.meter >= 1000) {
                c.command = rnd(c, 0, 3) + 120;
                return;
            }
            if (chance(c, 1.0) && dx < 150.0 && c.meter === 3000) {
                c.command = 95;
                return;
            }
        }
        if (dx < 220.0) {
            if (chance(c, 3.0) && c.rfGauge > 500.0) {
                c.command = 12;
                return;
            }
            if (chance(c, 1.0) && c.meter === 3000) {
                c.command = 95;
                return;
            }
        }
        if (dx > 220.0) {
            if (chance(c, 1.0) && c.rfGauge > 500.0) {
                c.command = rnd(c, 0, 3) + 10;
                return;
            }
            if (chance(c, 1.0) && c.meter === 3000) {
                c.command = 95;
                return;
            }
        }
    }
    if (c.state === 170 && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5.0)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -40.0 && dx < 80.0 && chance(c, 5.0)) {
            c.pressed[0] = 1;
            return;
        }
        if (c.y - o.y > -100.0 && c.y - o.y < -50.0 && dx < 100.0 && chance(c, 5.0)) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y > -100.0 && c.y - o.y < -50.0 && dx < 120.0 && chance(c, 5.0)) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return;
        }
        if (dy < 50.0 && dx < 100.0 && chance2(c)) {
            c.command = 22;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y === 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0) {
            c.command = 22;
            return;
        }
        if (c.aiRoll < 4 && c.rfGauge > 500.0) {
            c.command = 12;
            return;
        }
        if (c.aiRoll < 17 && c.aiRoll > 12 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 120;
            return;
        }
        if (c.aiRoll > 85) {
            c.aiMode = 2;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y < 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0) {
            c.command = 22;
            return;
        }
        if (c.aiRoll < 17 && c.aiRoll > 12 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 120;
            return;
        }
        if (c.aiRoll > 85) {
            c.aiMode = 2;
            return;
        }
    }
    if (rfOk(c) && 8.0 * c.aiLevel > rnd(c, 0, 100) && o.state > 149 && o.state < 157 && (c.state === 250 || c.state === 251 || c.state === 252 || c.state === 270 || c.state === 271 || c.state === 272)) {
        c.command = 52;
        return;
    }
    if (c.aiMode > 0 && c.state > 49 && c.state < 158) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 200) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = rnd(c, 0, 2) - 1;
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = dashCommand(c);
            if (c.state === 165) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 7;
        return;
    }
    if (c.aiMode === 7 && c.state === 163) {
        c.pressed[0] = 1;
        if (c.state === 230) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 8 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 9;
        return;
    }
    if (c.aiMode === 9 && c.state === 163) {
        c.pressed[1] = 1;
        if (c.state === 231) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 10 && c.state < 50) {
        c.command = dashCommand(c);
        if (c.state === 163) c.aiMode = 11;
        return;
    }
    if (c.aiMode === 11 && c.state === 163) {
        c.pressed[2] = 1;
        if (c.state === 232) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 12 && c.state < 50) {
        c.pressed[0] = 1;
        c.inputY = 1;
        if (c.state === 204) c.aiMode = 0;
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && c.aiLevel * 25.0 > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (comboIkumi(c, dx)) return;
    }
    if (25.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        const roll = c.aiRoll;
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 99) {
                if (dx < 40.0 && o.y === 0.0 && roll < 5) {
                    c.pressed[2] = 1;
                    c.inputX = -c.facing;
                    c.inputY = 0;
                    return;
                }
                if (dx < 50.0 && roll < 23) {
                    c.pressed[0] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 75.0 && roll < 30) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 80.0 && roll < 40 && roll > 30) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 80.0 && roll < 52 && roll > 40 || dx > 80.0 && dx < 130.0 && roll < 80 && roll > 52) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx > 80.0 && dx < 140.0 && roll < 100 && roll > 80) {
                    c.aiMode = 8;
                    return;
                }
                if (dx > 70.0 && dx < 120.0 && roll < 120 && roll > 100) {
                    c.aiMode = 8;
                    return;
                }
                if (dx < 90.0 && dx > 70.0 && roll < 130 && roll > 120) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 120.0 && dx > 70.0 && roll < 145 && roll > 130) {
                    c.pressed[2] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx > 100.0 && dx < 140.0 && roll < 152 && roll > 145) {
                    c.aiMode = 10;
                    return;
                }
                if (dx < 80.0 && roll < 165 && roll > 145 && c.rfGauge > 500.0 && o.state > 199) {
                    c.command = 22;
                    return;
                }
                if (dx < 80.0 && roll < 170 && roll > 165 && c.meter >= 1000 && o.state > 199) {
                    c.command = rnd(c, 0, 3) + 120;
                    return;
                }
                if (dx > 200.0 && roll < 170 && roll > 165 && c.meter >= 1000 && o.state > 199) {
                    c.command = rnd(c, 0, 3) + 130;
                    return;
                }
                if (dx > 200.0 && roll < 190 && roll > 170) {
                    c.command = rnd(c, 0, 3) + 10;
                    return;
                }
                if (dx > 80.0 && dx < 120.0 && roll < 210 && roll > 190) {
                    c.command = 40;
                    return;
                }
                if (dx > 140.0 && dx < 180.0 && roll < 210 && roll > 190) {
                    c.command = 41;
                    return;
                }
                if (dx > 200.0 && dx < 240.0 && roll < 210 && roll > 190) {
                    c.command = 42;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 120.0 && roll < 10) {
                        c.inputY = -1;
                        c.inputX = -c.facing;
                        return;
                    }
                    if (dx < 80.0 && roll < 15 && c.meter >= 1000) {
                        c.command = rnd(c, 0, 3) + 120;
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 90.0 && dy < 140.0 && roll < 6 && rfOk(c)) {
                        c.command = 22;
                        return;
                    }
                    if (dx < 90.0 && dy < 140.0 && dy > 100.0 && roll < 35 && roll > 10) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx > 100.0 && dx < 140.0 && dy < 180.0 && dy > 140.0 && roll < 60 && roll > 35) {
                        c.pressed[2] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx > 100.0 && dx < 140.0 && dy < 140.0 && dy > 100.0 && roll < 80 && roll > 60) {
                        c.pressed[1] = 1;
                        c.inputY = 0;
                        return;
                    }
                    if (dx < 80.0 && roll < 110 && roll > 80 && o.y < -50.0 && c.meter >= 1000) {
                        c.command = rnd(c, 0, 3) + 120;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 80.0 && dy < 100.0 && roll < 50) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx > 60.0 && dx < 120.0 && dy > 90.0 && dy < 120.0 && o.y < c.y && roll > 50 && roll < 120) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx > 80.0 && dx < 140.0 && dy > 100.0 && dy < 180.0 && roll > 120 && roll < 170) {
                    c.pressed[2] = 1;
                    return;
                }
                {
                    const r = rnd(c, 0, 320);
                    if (dx - 100.0 > r && dy < 90.0 && roll > 170 && roll < 220) {
                        c.command = rnd(c, 0, 3) + 10;
                        return;
                    }
                }
                if (dx > 100.0 && roll > 240 && roll < 330 && dy + 40.0 > dx && dy - 40.0 < dx) {
                    c.command = rnd(c, 0, 3) + 40;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 80.0 && dy < 100.0 && roll < 20) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx > 60.0 && dx < 120.0 && dy > 90.0 && dy < 120.0 && o.y < c.y && roll > 20 && roll < 40) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx > 80.0 && dx < 140.0 && dy > 100.0 && dy < 180.0 && roll > 40 && roll < 50) {
                    c.pressed[2] = 1;
                    return;
                }
                {
                    const r = rnd(c, 0, 320);
                    if (dx - 100.0 > r && dy < 180.0 && roll > 170 && roll < 240) {
                        c.command = rnd(c, 0, 3) + 10;
                        return;
                    }
                }
            }
        }
    }
    if (c.state < 50 && (o.state > 149 && o.state < 156 || o.state > 49 && o.state < 59) && c.y === 0.0 && 3.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.command = dashCommand(c);
        return;
    }
    if (c.state < 50 && o.state < 50 && dx > 60.0 && dx < 140.0 && 2.0 * c.aiLevel > rnd(c, 0, 100) && c.x > 120.0 && c.x < 520.0) {
        c.command = c.facing === 1 ? 0 : 1;
        return;
    }
    if (rnd(c, 0, 1000) < 2) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 180.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 170.0 && dx > 140.0 && c.y === 0.0 && o.state < 50) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 15) c.aiTimer1a0 = 15;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 15) c.aiTimer1a4 = 15;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 50 && dx < 120.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 200) + 45;
        else c.aiTimer1a0 = rnd(c, 0, 200) + 45;
    }
    if (rnd(c, 0, 100) < 30) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 200) + 30;
        else c.aiTimer1a4 = rnd(c, 0, 200) + 30;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 200) + 30;
    else c.aiTimer1a4 = rnd(c, 0, 200) + 30;
}
function comboIkumi(c, dx) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (c.state === 200) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 50.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 0;
            if (c.d168 === 2 && rnd(c, 0, 100) < 30) {
                c.pressed[2] = 1;
                c.inputY = 1;
            }
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 970) {
            startJump(c);
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 2) === 0) c.aiMode = 6;
            if (rnd(c, 0, 2) === 0) c.aiMode = 8;
            return true;
        }
    }
    if (c.state === 201) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (o.y < 0.0 && roll > 299 && roll < 320 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 120;
            return true;
        }
        if (o.y < 0.0 && roll > 320 && roll < 600 && c.d168 === 3) {
            c.inputX = c.facing;
            c.inputY = -1;
            return true;
        }
        if (roll < 200) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 200 && roll < 450 && dx < 90.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 450 && roll < 700) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 900) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 80.0) c.aiMode = 8;
                return true;
            }
        }
    }
    if (c.state === 202) {
        if (o.y < 0.0 && roll > 299 && roll < 320) {
            c.command = 10;
            return true;
        }
        if (o.y < 0.0 && roll > 320 && roll < 600 && dx < 100.0) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll < 500 && c.d168 === 3 && dx < 80.0) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
                return true;
            }
        }
    }
    if (c.state === 203) {
        if (comboCancel(c, dx, roll, true, true)) return true;
    }
    if (c.state === 204) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 50.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 0;
            if (c.d168 === 2 && rnd(c, 0, 100) < 20) {
                c.pressed[2] = 1;
                c.inputY = 1;
            }
            return true;
        }
        if (dx < 135.0 && roll < 600) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
            }
            return true;
        }
    }
    if (c.state === 205) {
        if (o.y < 0.0 && roll > 320 && roll < 600 && dx < 100.0) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll < 100) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 100 && roll < 300 && dx < 100.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 300 && roll < 600) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 900) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
            }
            return true;
        }
    }
    if (c.state === 206) {
        if (comboCancel(c, dx, roll, false, false)) return true;
    }
    if (c.state === 207) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            return true;
        }
        if (dx < 60.0 && roll < 400) {
            c.pressed[0] = 1;
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 4) === 0) c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 208) {
        if (roll > 20 && roll < 60 && c.d168 === 3 && o.y < 0.0) {
            c.command = 10;
            return true;
        }
        if (roll > 80 && roll < 300) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 950) {
            c.inputX = rnd(c, 0, 2) - 1;
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 209) {
        if (roll > 950) {
            c.inputX = rnd(c, 0, 2) - 1;
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 231) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (roll > 200 && roll < 220 && dx < 90.0 && c.d168 === 3 && c.meter >= 1000) {
            c.command = rnd(c, 0, 3) + 120;
            return true;
        }
        if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
        if (roll > 649 && rnd(c, 0, 2) === 0) {
            c.aiMode = 12;
            if (dx > 110.0) c.aiMode = 8;
        }
    }
    if (c.state === 232) {
        if (comboCancel(c, dx, roll, true, true)) return true;
    }
    return false;
}
function comboCancel(c, dx, roll, with95, withJump) {
    const o = c.opponent;
    if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
        c.command = 10;
        return true;
    }
    if (o.y < 0.0 && roll > 299 && roll < 320 && c.meter >= 1000 && dx < 90.0) {
        c.command = rnd(c, 0, 3) + 120;
        return true;
    }
    if (roll > 0 && roll < 200 && c.d168 === 3) {
        c.command = 10;
        return true;
    }
    if (roll > 200 && roll < 250) {
        c.command = rnd(c, 0, 3) + 30;
        return true;
    }
    if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
        c.command = 52;
        return true;
    }
    if (with95 && roll > 400 && roll < 430 && c.d168 === 3 && c.meter === 3000) {
        c.command = 95;
        return true;
    }
    if (roll > 430 && roll < 540 && c.d168 !== 3) {
        c.command = 40;
        if (dx > 120.0) c.command = 41;
        return true;
    }
    if (withJump && roll > 910 && c.d168 === 3) {
        startJump(c);
        return true;
    }
    if (roll > 649) {
        c.aiMode = 1;
        return true;
    }
    return false;
}
const FLASH_COLORS = new Map([
    [
        6,
        0xd5
    ],
    [
        12,
        0xd6
    ],
    [
        18,
        0xea
    ],
    [
        24,
        0xe9
    ],
    [
        30,
        0xe8
    ],
    [
        36,
        0xe7
    ],
    [
        42,
        0xe6
    ],
    [
        48,
        0xe5
    ],
    [
        54,
        0xe4
    ],
    [
        60,
        0xe5
    ],
    [
        66,
        0xe6
    ],
    [
        72,
        0xe7
    ],
    [
        78,
        0xe8
    ],
    [
        84,
        0xe9
    ],
    [
        90,
        0xea
    ],
    [
        96,
        0xd6
    ],
    [
        102,
        0xd5
    ]
]);
function spawnOnOpponent(c, f, pattern) {
    const o = c.opponent;
    f.w04 = pattern;
    f.x = ftol(o.x);
    f.y = o.y - 40.0;
    f.b20 = 0;
    f.b21 = 1;
    f.b18 = c.facing;
    frameChild(c, f);
    c.f3154++;
}
export function tickHookIkumi(c) {
    const f = openSpawnFrame();
    if (c.f314c === 8 && c.y === 0.0 && c.state < 8 && c.state !== 300) {
        c.onStateChange();
        c.stopMotion();
        c.state = 300;
    }
    if (c.f314c === 10) {
        c.f3158++;
        if (c.f3158 > 185) c.f3158 = 0;
        c.f3150--;
        c.w138 = 2;
        c.w13a = 2;
        c.startAfterimage(2);
        const color = FLASH_COLORS.get(c.f3158);
        if (color !== undefined) c.requestFlash(color, 9);
        if (c.f3150 <= 0) {
            c.f314c = 0;
            c.f3148 = 0;
            c.setForm(0);
        }
    }
    if (c.d168 !== 3 || c.f3154 !== 0) return;
    const s = c.state;
    if (s === 201 || s === 202 || s === 205 || s === 208) spawnOnOpponent(c, f, 470);
    if (s === 231 || s === 234) spawnOnOpponent(c, f, 478);
    if (s === 253 || s === 254 || s === 256 || s === 257) spawnOnOpponent(c, f, 471);
    if (s === 266 || s === 255 || s === 267 || s === 258 || s === 272 || s === 273) spawnOnOpponent(c, f, 479);
    if (s === 269 || s === 270 || s === 276 || s === 277) spawnOnOpponent(c, f, 480);
}
const DEG = 57.29579143313326;
function setPolarVelocity(c, i, angle, speed) {
    const ch = c.children[i];
    ch.vx = __numerics.cos(angle / DEG) * speed;
    ch.vy = __numerics.sin(angle / DEG) * speed;
}
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    if (childStep(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function spawnShards(c, i, pattern, n) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    f.w04 = pattern;
    f.x = ftol(ch.x);
    f.y = ftol(ch.y);
    f.b18 = ch.facing;
    f.b21 = 1;
    f.b20 = 0;
    for(let k = 0; k < n; k++)frameChild(c, f);
}
function shardSource(n472, n473, n474) {
    return (c, i)=>{
        const ch = c.children[i];
        if (ch.frame === 2 && ch.timer === 0) {
            if (n472 > 0) spawnShards(c, i, 472, n472);
            if (n473 > 0) spawnShards(c, i, 473, n473);
            if (n474 > 0) spawnShards(c, i, 474, n474);
        }
        childOnce(c, i);
    };
}
function addGauge(c, form, gain) {
    if (form === 0) {
        if (c.f314c < 8) c.f3148 += gain;
        if (c.f3148 >= 100) {
            c.f3148 = 0;
            c.f314c++;
            if (c.f314c > 8) c.f314c = 8;
        }
    } else {
        c.f3150 += gain;
        if (c.f3150 > 1260) c.f3150 = 1260;
    }
}
function shard(c, i, p) {
    const ch = c.children[i];
    ch.vy = ch.vy + 0.035;
    if (c.a3160[i] === 0) {
        c.a3160[i]++;
        c.a3260[i] = c.random(90, p.hi) & 0xffff;
        const r = c.random(0, 5) & 0xffff;
        const speed = r * 0.1 + p.base;
        setPolarVelocity(c, i, -c.a3260[i], speed);
    }
    if (ch.vy > 0.0 && ch.frame === 0) {
        ch.timer = 0;
        ch.frame = 1;
        return;
    }
    const first = p.needFrame ? ch.frame > 0 : ch.vy > 0.0;
    if (first && ch.x - c.x < 15.0 && ch.x - c.x > -15.0 && ch.y - c.y < 0.0 && ch.y - c.y > -50.0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 475;
        addGauge(c, p.form, p.gain);
        return;
    }
    if (ch.frame > 0 && ch.y >= 0.0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 476;
        ch.layer = 0;
        return;
    }
    if (childStep(c, i)) {
        if (p.holdFirst && ch.frame === 1) ch.frame--;
        if (ch.frame >= childCount) ch.frame--;
    }
}
function grounded(c, i, form, gain) {
    const ch = c.children[i];
    if (ch.frame === 4 && ch.x - c.x > -15.0 && ch.x - c.x < 15.0 && c.y === 0.0) {
        addGauge(c, form, gain);
        ch.timer = 0;
        ch.frame = 7;
        return;
    }
    childOnce(c, i);
}
registerChildren({
    470: shardSource(3, 0, 0),
    471: shardSource(4, 2, 0),
    472: (c, i)=>shard(c, i, {
            hi: 97,
            base: 3.2,
            gain: 10,
            needFrame: true,
            holdFirst: true,
            form: 0
        }),
    473: (c, i)=>shard(c, i, {
            hi: 100,
            base: 2.2,
            gain: 30,
            needFrame: false,
            holdFirst: false,
            form: 0
        }),
    474: (c, i)=>shard(c, i, {
            hi: 100,
            base: 2.8,
            gain: 50,
            needFrame: false,
            holdFirst: false,
            form: 0
        }),
    475: childOnce,
    476: (c, i)=>grounded(c, i, 0, 8),
    477: shardSource(8, 4, 2),
    478: shardSource(4, 1, 0),
    479: shardSource(5, 3, 1),
    480: shardSource(5, 3, 2)
});
registerChildren2({
    470: shardSource(3, 0, 0),
    471: shardSource(4, 2, 0),
    472: (c, i)=>shard(c, i, {
            hi: 97,
            base: 3.2,
            gain: 10,
            needFrame: true,
            holdFirst: true,
            form: 1
        }),
    473: (c, i)=>shard(c, i, {
            hi: 100,
            base: 2.2,
            gain: 30,
            needFrame: false,
            holdFirst: false,
            form: 1
        }),
    474: (c, i)=>shard(c, i, {
            hi: 100,
            base: 2.8,
            gain: 50,
            needFrame: false,
            holdFirst: false,
            form: 1
        }),
    475: childOnce,
    476: (c, i)=>grounded(c, i, 1, 5),
    477: shardSource(8, 4, 2),
    478: shardSource(4, 1, 0),
    479: shardSource(5, 3, 1),
    480: shardSource(5, 3, 2)
});

export function __logicState(){return {FLASH_COLORS};}

export function __installInitialRoots(s){
if(FLASH_COLORS!==s["FLASH_COLORS"])throw Error('INITIAL_CONST_IDENTITY:FLASH_COLORS');
}
