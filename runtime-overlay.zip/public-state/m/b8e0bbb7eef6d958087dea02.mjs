import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./9410f25ccc5489d02b4dd080.mjs";
import { frameChild, openSpawnFrame, updateChildrenMisuzu } from "./1d4a8932dc5ab92063658a65.mjs";
import { parseCommandMisuzu, dispatchMovesMisuzu } from "./55603117b22db7b99551868c.mjs";
import { thinkMisuzu } from "./4f5ba633f895045b361f4933.mjs";
import { renderOverlayMisuzu, tickHookMisuzu } from "./b6561ecc60f70e920b1261d8.mjs";
import "./b7efcd533a6aa403554e6efa.mjs";
import "./cd9215f2161e6aeb5be0520d.mjs";
import "./646c12bb681bd951ee731cc1.mjs";
const CTOR_POINTS_X = [
    -2,
    1,
    24,
    -11,
    21
];
const CTOR_POINTS_Y = [
    -62,
    -10,
    -18,
    -23,
    -22
];
const RESET_POINTS_X = [
    -13,
    14,
    17,
    7,
    27
];
const RESET_POINTS_Y = [
    -60,
    0,
    -6,
    -25,
    -25
];
export class Misuzu extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    f3154 = 0;
    a3158 = new Int32Array(64);
    a3258 = new Int32Array(64);
    a3358 = new Int32Array(64);
    f3458 = 0;
    f345c = 0;
    f3460 = 0;
    f3464 = 0;
    f3468 = 0;
    f346c = 0;
    f3470 = 0;
    f3474 = 0;
    f3478 = 0;
    f347c = 0;
    f3480 = 0;
    pointsX = [
        ...CTOR_POINTS_X
    ];
    pointsY = [
        ...CTOR_POINTS_Y
    ];
    params = [
        5,
        1,
        0x13,
        2,
        0,
        1,
        6,
        0xff,
        0xff,
        0xff,
        0xff,
        0x17
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = 0;
        this.f314c = 0;
        this.f3460 = 0;
        this.f3458 = 0;
        this.f345c = 0;
        this.f3154 = 0;
        this.f3150 = 0;
        this.f3464 = 0;
        this.f3468 = 0;
        this.f346c = 0;
        this.f3470 = 0;
        this.f3474 = 0;
        this.f3478 = 0;
        this.f347c = 0;
        this.f3480 = 0;
        for(let k = 0; k < 5; k++){
            this.pointsX[k] = RESET_POINTS_X[k];
            this.pointsY[k] = RESET_POINTS_Y[k];
        }
        this.a3158.fill(0);
        this.a3258.fill(0);
        this.a3358.fill(0);
        super.resetRound();
        const f = openSpawnFrame();
        f.w04 = 0x190;
        f.x = 320.0;
        f.y = -320.0;
        f.b20 = 0;
        f.b21 = 1;
        f.d28 = 1;
        f.d00 = 1;
        f.b18 = this.facing;
        frameChild(this, f);
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3158[i] = 0;
        this.a3258[i] = 0;
        this.a3358[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayMisuzu(this);
    }
    tickHook() {
        tickHookMisuzu(this);
    }
    parseCommand() {
        parseCommandMisuzu(this);
    }
    dispatchMoves() {
        dispatchMovesMisuzu(this);
    }
    think() {
        thinkMisuzu(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMisuzu(this);
    }
}

export function __logicState(){return {CTOR_POINTS_X,CTOR_POINTS_Y,RESET_POINTS_X,RESET_POINTS_Y};}

export function __installInitialRoots(s){
if(CTOR_POINTS_X!==s["CTOR_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_X');
if(CTOR_POINTS_Y!==s["CTOR_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_Y');
if(RESET_POINTS_X!==s["RESET_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_X');
if(RESET_POINTS_Y!==s["RESET_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_Y');
}
