import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./6eb1fb66adb5d5a47cd5c7ec.mjs";
import { childCount, childDuration, frameChild, frameEffect, openSpawnFrame } from "./746d3a93e9a50814987814cf.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function groundJumpCancel(c, ok) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && ok) {
        c.state = 4;
        if (c.inputX === c.facing) c.state = 5;
        if (c.inputX === -c.facing) c.state = 6;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a === 0) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function attackStart(c, meter, se) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = 1;
}
function landTo13(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return true;
    }
    return false;
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(99);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.life > 0 && c.timer > 99 && c.frame === 0) {
        c.setState(96);
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(96);
    }
}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy += c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy += c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function burstFx(c, d) {
    d.w04 = 9;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 70;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    c.w16c = 1;
    c.seRequest = 62;
}
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        burstFx(c, d);
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 7)) {
        c.stopMotion();
        burstFx(c, d);
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 12) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.startAfterimage(3);
    }
    if (atFrame(c, 2)) {
        c.vx = 2.5;
        c.vy = -0.3;
        c.ay = 0.02;
        if (c.f3144 === 4) {
            c.vx = 3.2;
            c.vy = -0.25;
            c.ay = 0.025;
        }
    }
    c.vy = (c.frame > 2 ? 1 : 0) * c.ay + c.vy;
    if (c.y + c.vy >= 0.0 && c.frame > 2 && c.frame < 5) {
        c.y = 0.0;
        c.frame = 5;
        c.timer = 0;
        c.stopMotion();
    }
    if (advance(c, dur)) {
        if (c.frame === 5) c.frame = 3;
        if (c.frame >= cnt) {
            c.faceOpponent();
            c.state = 3;
            c.onStateChange();
        }
    }
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) {
        c.vx = -2.0;
        c.vy = -1.0;
    }
    if (c.frame > 1) c.vy = c.vy + 0.04;
    if (c.frame > 3 && c.frame < 7 && c.vy + c.y >= 0.0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.y = 0.0;
        c.frame = 7;
        c.timer = 0;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.faceOpponent();
        c.state = 3;
        c.onStateChange();
    }
}
function airDashEnd(c, vx) {
    c.setState(9);
    c.vx = vx;
    c.ay = 0.03;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = 1.3;
        c.startAfterimage(3);
        c.vy = 0.0;
        c.ay = 0.0;
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 120) airDashEnd(c, 1.1);
    if (c.inputX !== c.facing && c.f3138 >= 48) airDashEnd(c, 1.1);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -1.3;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9);
    if (c.inputX !== -c.facing && c.f3138 >= 48) airDashEnd(c, -0.9);
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.startAfterimage(10);
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        c.startAfterimage(10);
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 7) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 7;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 2) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function groundNormalAdvance(c, dur, cnt, resetBefore, crouchable) {
    if (advance(c, dur)) {
        if (c.frame < resetBefore) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, crouchable);
    }
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 21);
    groundNormalAdvance(c, dur, cnt, 3, false);
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) attackStart(c, 15, 20);
    groundNormalAdvance(c, dur, cnt, 3, false);
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) attackStart(c, 15, 20);
    if (atFrame(c, 9)) c.voiceRequest = 2;
    groundNormalAdvance(c, dur, cnt, 3, false);
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) attackStart(c, 35, 20);
    if (atFrame(c, 10)) c.voiceRequest = 2;
    groundNormalAdvance(c, dur, cnt, 3, false);
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 21);
    groundNormalAdvance(c, dur, cnt, 3, true);
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atFrame(c, 1)) attackStart(c, 13, 20);
    groundNormalAdvance(c, dur, cnt, 3, true);
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (groundJumpCancel(c, c.d168 === 3)) return;
    if (atFrame(c, 3)) attackStart(c, 25, 20);
    if (atFrame(c, 10)) c.voiceRequest = 2;
    groundNormalAdvance(c, dur, cnt, 3, true);
}
function airNormalAdvance(c, dur, cnt) {
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s207(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 5, 21);
    if (landTo13(c)) return;
    airNormalAdvance(c, dur, cnt);
}
function s208(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (landTo13(c)) return;
    if (atFrame(c, 4)) c.voiceRequest = 2;
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame === 1) attackStart(c, 13, 20);
        if (c.frame >= cnt) c.setState(9);
    }
}
function s209(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 30, 20);
    if (atFrame(c, 4)) c.voiceRequest = 2;
    if (landTo13(c)) return;
    airNormalAdvance(c, dur, cnt);
}
function spawnPuppetAttack(c, pattern, dx, dy) {
    const d = openSpawnFrame();
    c.voiceRequest = 1;
    addMeter(c, 25);
    d.w04 = pattern;
    d.x = ftol(c.x) - c.facing * dx;
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function puppetNormal(c, jumpCancel, pattern, dx, dy, resetBefore) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (jumpCancel && groundJumpCancel(c, c.d168 === 3)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.w16c = 1;
    }
    if (atFrame(c, 2)) spawnPuppetAttack(c, pattern, dx, dy);
    if (atFrame(c, 6)) c.voiceRequest = 2;
    groundNormalAdvance(c, dur, cnt, resetBefore, false);
}
const s210 = (c)=>puppetNormal(c, true, 415, 0x1c, 44, 3);
const s211 = (c)=>puppetNormal(c, false, 416, 0x15, 63, 3);
const s212 = (c)=>puppetNormal(c, false, 417, 5, 61, 2);
function puppetNormalEx(c, pattern, dx, dy) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, c.d168 >= 2)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.w16c = 1;
        c.f3148 -= 1000;
    }
    if (atFrame(c, 2)) spawnPuppetAttack(c, pattern, dx, dy);
    if (atFrame(c, 6)) c.voiceRequest = 2;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
const s213 = (c)=>puppetNormalEx(c, 415, 0x1c, 44);
const s214 = (c)=>puppetNormalEx(c, 416, 0x15, 63);
const s215 = (c)=>puppetNormalEx(c, 417, 5, 61);
function s216(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.vx > 0.0) c.vx = c.vx - 0.08;
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        if (c.frame === 1) c.d168 = 0;
        if (c.frame === 3) {
            c.seRequest = 21;
            addMeter(c, 25);
            c.vx = 3.0;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.stopMotion();
        o.onStateChange();
        o.state = 108;
        c.state = 221;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x31;
        d.y = ftol(c.y) - 43;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1 && o.y === 0.0) c.w16c = 1;
        else c.w16c = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.biasCameraY(50, 3);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) {
            if (c.facing === 1 && c.x + 20.0 < 40.0) c.x = 40.0;
            if (c.facing === -1 && c.x > 620.0) c.x = 620.0;
            o.state = 103;
            o.y = -150.0;
            o.x = c.facing * 0x29 + c.x;
        }
        if (c.frame === 2) {
            o.y = -100.0;
            o.x = c.facing * 0x2f + c.x;
        }
        if (c.frame === 3) {
            o.y = -81.0;
            o.x = c.x - c.facing * 0x5c;
            o.facing = -c.facing;
            o.state = 117;
        }
        if (c.frame === 4) {
            o.y = 0.0;
            o.x = c.x - c.facing * 0x61;
            applyDirectDamage(c, 1200, 750.0);
            o.state = 97;
            o.d12c = 1;
            c.d168 = 3;
            o.onStateChange();
            o.stopMotion();
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function airNormalB(c, startFrame, meter, se) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = 0.5;
        c.ay = 0.03;
    }
    if (atFrame(c, startFrame)) attackStart(c, meter, se);
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s230 = (c)=>airNormalB(c, 1, 5, 21);
const s231 = (c)=>airNormalB(c, 2, 10, 21);
const s232 = (c)=>airNormalB(c, 1, 10, 20);
function s240(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vy += c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 241;
        o.state = 100;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x1f;
        d.y = ftol(c.y) - 82;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.x = c.facing * 0x1f + c.x;
        o.y = c.y - 82.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 209;
            c.frame = 1;
        }
    }
}
function s241(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 4) c.biasCamera(50, 3);
    if (c.frame < 4) c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy += c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 5) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.state = 13;
        return;
    }
    if (c.frame === 1) {
        o.y = c.y - 80.0;
        o.x = c.facing * 0x1d + c.x;
        o.state = 103;
    }
    if (c.frame === 2) {
        o.y = c.y - 71.0;
        o.x = c.facing * 0xb + c.x;
        o.state = 104;
        o.facing = c.facing;
    }
    if (atFrame(c, 3)) {
        o.y = c.y - 60.0;
        o.x = c.x - c.facing * 0x25;
        o.state = 69;
        applyDirectDamage(c, 1300, 500.0);
        o.onStateChange();
        o.knockX = -3.0;
        o.knockY = 3.0;
    }
    if (atFrame(c, 5)) c.ay = 0.035;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function childPuppetHit(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    215: s215,
    216: s216,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    240: s240,
    241: s241
});
registerChildren({
    415: childPuppetHit,
    416: childPuppetHit,
    417: childPuppetHit
});
