import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./2bf4cca999321fd0777adb51.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame, setPolarVelocity } from "./3a7948481af9e187ce0f99cd.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
function advance(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return true;
}
function finish(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function addMeter(c, v) {
    c.meter = s16(c.meter + v);
}
function dustEffect(c, d) {
    d.w04 = 0x1f;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 0;
    d.b21 = 0;
    d.d1c = c.facing === -1 ? 1 : 0;
    frameEffect(d);
}
function rfCostEffect(c, d) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    d.w04 = 0x21;
    d.b2c = 0xb;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 0x32;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
}
function spawnFront(c, d, pat, dx, dy) {
    d.w04 = pat;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.b21 = 1;
    d.d00 = 1;
    c.voiceRequest = 0xb;
    d.b18 = c.facing;
    frameChild(c, d);
}
function state248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.stopMotion();
        o.d128 = 1;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x1e;
        d.y = ftol(c.y) - 0x3c;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.frame = 0;
        c.timer = 0;
        c.state = 0xf9;
        o.state = 0x6e;
        o.y = c.y;
        o.x = c.facing * 0x14 + c.x;
        return;
    }
    if (!advance(c, dur)) return;
    if (c.frame === 1 && o.y < 0.0 && (o.state < 0x32 || o.state > 0x95)) {
        c.w16c = 1;
    } else {
        c.w16c = 0;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0xd2;
        c.frame = 2;
    }
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.b158 = 0;
    if (c.frame >= 7) {
        c.vy = c.vy + 0.035;
        if (c.y + c.vy > 0.0) {
            c.onStateChange();
            c.stopMotion();
            c.y = 0.0;
            c.state = 0xd;
            return;
        }
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 3) {
        o.y = c.y - 1.0;
        o.x = c.facing * 0x1d + c.x;
    }
    if (c.frame === 4) {
        o.onStateChange();
        o.state = 0x3c;
        o.knockX = 3.0;
        o.knockY = -1.0;
        o.ay = 0.035;
        applyDirectDamage(c, 0x3e8, 500.0);
        c.comboCount = s16(c.comboCount - 1);
        c.comboDisplay = s16(c.comboDisplay - 1);
        o.d128 = 1;
    }
    if (c.frame >= cnt) c.frame = c.frame - 2;
}
function shotState(c, pat, dx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (c.frame === 9 && c.timer === 0) dustEffect(c, d);
    if (c.frame === 9 && c.timer === 0) {
        spawnFront(c, d, pat, dx, 0x26);
        addMeter(c, 0x1e);
    }
    if (c.frame === 0xa && c.command > 9 && c.command < 0xd) {
        c.timer = 0;
        c.frame = 0xb;
        return;
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 0x12) {
        c.onStateChange();
        c.state = 0;
    }
    if (c.frame === 0xb) c.frame = 0x12;
    finish(c, cnt);
}
function state250(c) {
    shotState(c, 0x1a1, 0x37);
}
function state251(c) {
    shotState(c, 0x1a2, 0x5f);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) {
        c.startAfterimage(3);
        c.stopMotion();
        rfCostEffect(c, d);
        c.f3454 = 0;
    }
    if (c.frame === 9 && c.timer === 0) dustEffect(c, d);
    if (c.frame === 9 && c.timer === 0) {
        spawnFront(c, d, 0x1a3, 0x19, 0x26);
        addMeter(c, 0x1e);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    finish(c, cnt);
}
function groundShot(c, pat, dx, guard) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        if (guard) rfCostEffect(c, d);
    }
    if (c.frame === 6 && c.timer === 0) {
        d.w04 = pat;
        d.x = ftol(c.x) + c.facing * dx;
        d.y = 0.0;
        d.b20 = 0;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
        addMeter(c, 0x2d);
    }
    if (!advance(c, dur)) return;
    c.d168 = 3;
    finish(c, cnt);
}
function spawnTriple(c, d, list) {
    list.forEach(([pat, dx, dy], k)=>{
        d.w04 = pat;
        d.x = ftol(c.x) + c.facing * dx;
        d.y = ftol(c.y) - dy;
        if (k === 0) {
            d.b20 = 0;
            d.b21 = 1;
            d.b18 = c.facing;
        }
        frameChild(c, d);
    });
    c.voiceRequest = 3;
    addMeter(c, 0xf);
}
function scatterState(c, first, second) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (c.frame === 4 && c.timer === 0) c.voiceRequest = 2;
    if (c.frame === 0xe && c.timer === 0) spawnTriple(c, d, first);
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame === 9 && c.timer === 0) spawnTriple(c, d, second);
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
        c.faceOpponent();
    }
}
function state256(c) {
    scatterState(c, [
        [
            0x1bd,
            0xd,
            0x3a
        ],
        [
            0x1bf,
            0x12,
            0x26
        ],
        [
            0x1be,
            0x15,
            0x12
        ]
    ], [
        [
            0x1bc,
            0x1f,
            0x33
        ],
        [
            0x1bf,
            0x1a,
            0x1f
        ],
        [
            0x1be,
            0x15,
            0xb
        ]
    ]);
}
function state257(c) {
    scatterState(c, [
        [
            0x1c3,
            6,
            0x47
        ],
        [
            0x1c1,
            0x10,
            0x3d
        ],
        [
            0x1c0,
            0x1a,
            0x33
        ]
    ], [
        [
            0x1bc,
            0x1f,
            0x33
        ],
        [
            0x1bf,
            0x1a,
            0x1f
        ],
        [
            0x1be,
            0x15,
            0xb
        ]
    ]);
}
function state258(c) {
    scatterState(c, [
        [
            0x1c3,
            6,
            0x47
        ],
        [
            0x1c1,
            0x10,
            0x3d
        ],
        [
            0x1c0,
            0x1a,
            0x33
        ]
    ], [
        [
            0x1c3,
            6,
            0x47
        ],
        [
            0x1c2,
            0x10,
            0x3d
        ],
        [
            0x1c0,
            0x1a,
            0x33
        ]
    ]);
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (!advance(c, dur)) return;
    if (c.frame === 1) c.d168 = 0;
    if (c.frame === 4 && c.timer === 0) {
        d.w04 = 0x1b5;
        d.x = ftol(c.x);
        d.y = 0.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        addMeter(c, 0x2d);
    }
    if (c.frame === 7 && c.f3138 < 6) {
        c.frame = c.frame - 3;
        c.f3138 = c.f3138 + 1;
        if (c.f3138 > 1) c.w16c = 0;
    }
    finish(c, cnt);
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
        rfCostEffect(c, d);
    }
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 3;
    }
    if (c.frame === 5 && c.timer === 0 && c.f3138 < 2) {
        d.w04 = 0x1b5;
        const x = ftol(c.x);
        d.x = x + (c.random(0, 0x46) & 0xffff) - 0x23;
        d.y = 0.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        addMeter(c, 0x14);
    }
    if (!advance(c, dur)) return;
    if (c.frame === 7 && c.f3138 < 6) {
        c.frame = c.frame - 3;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame === 4 && c.f3138 < 2) c.d168 = 0;
    finish(c, cnt);
}
function toSpecial179(c) {
    if (c.f3458 > 0) {
        c.frame = 7;
        c.state = 0xb3;
    }
}
function airShotState(c, pat, dx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.frame === 7 && c.timer === 0) {
        spawnFront(c, d, pat, dx, 0x26);
        addMeter(c, 0x1e);
    }
    if (c.frame === 8 && c.command > 9 && c.command < 0xd) {
        c.timer = 0;
        c.frame = 0xb;
        return;
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 0xb) {
        c.onStateChange();
        c.state = 0x14;
        return;
    }
    if (c.frame >= cnt) {
        c.state = 0x14;
        c.onStateChange();
        toSpecial179(c);
    }
}
function state262(c) {
    airShotState(c, 0x1a1, 0x37);
}
function state263(c) {
    airShotState(c, 0x1a2, 0x5f);
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    if (atStart(c)) {
        c.startAfterimage(3);
        c.vx = 0.0;
        c.vy = 0.0;
        rfCostEffect(c, d);
    }
    if (c.frame === 7 && c.timer === 0) {
        d.w04 = 0x1a3;
        d.x = ftol(c.x) + c.facing * 0x37;
        d.y = ftol(c.y) - 0x26;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
        c.voiceRequest = 0xb;
        addMeter(c, 0x1e);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0x14;
        c.ay = 0.035;
        c.onStateChange();
        toSpecial179(c);
    }
}
function state265(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.frame === 7 && c.timer === 0) {
        spawnFront(c, d, 0x1cb, 0x26, 0x37);
        addMeter(c, 0x2d);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 9;
        c.onStateChange();
        toSpecial179(c);
    }
}
function dashGround(c, dashVx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (c.frame === 8 && c.timer === 0) c.blend = 2;
    if (c.frame === 9 && c.timer === 0) c.voiceRequest = 0xe;
    if (c.frame === 0xf && c.timer === 0) c.vx = dashVx;
    if (c.frame === 0x10 && c.timer === 0) c.vx = 0.0;
    if (c.frame === 0x17 && c.timer === 0) c.blend = 0;
    if (!advance(c, dur)) return;
    c.d168 = 3;
    finish(c, cnt);
}
function state268(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (c.frame === 8 && c.timer === 0) c.blend = 2;
    if (c.frame === 9 && c.timer === 0) c.voiceRequest = 0xe;
    if (c.frame === 0x10 && c.timer === 0) c.vx = 0.0;
    if (c.frame === 0x17 && c.timer === 0) c.blend = 0;
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame === 0x10) {
        c.x = c.opponent.x - c.facing * 0xa;
        c.y = -130.0;
    }
    if (c.frame >= cnt) {
        c.state = 9;
        c.ay = 0.035;
        c.onStateChange();
    }
}
function dashAir(c, dashVx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    c.b159 = 1;
    c.b15a = 1;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.frame === 8 && c.timer === 0) c.blend = 2;
    if (c.frame === 9 && c.timer === 0) c.voiceRequest = 0xe;
    if (c.frame === 0xf && c.timer === 0) c.vx = dashVx;
    if (c.frame === 0x10 && c.timer === 0) c.vx = 0.0;
    if (c.frame === 0x17 && c.timer === 0) c.blend = 0;
    if (!advance(c, dur)) return;
    if (c.frame >= cnt) {
        c.state = 9;
        c.onStateChange();
        toSpecial179(c);
    }
}
function state271(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    c.b159 = 1;
    c.b15a = 1;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.frame === 8 && c.timer === 0) c.blend = 2;
    if (c.frame === 9 && c.timer === 0) c.voiceRequest = 0xe;
    if (c.frame === 0x10 && c.timer === 0) {
        c.vx = 0.0;
        c.f3458 = 0;
    }
    if (c.frame === 0x17 && c.timer === 0) c.blend = 0;
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame === 0x10) {
        c.x = c.opponent.x - c.facing * 0x3c;
        c.y = 0.0;
    }
    finish(c, cnt);
}
registerStates({
    248: state248,
    249: state249,
    250: state250,
    251: state251,
    252: state252,
    253: (c)=>groundShot(c, 0x196, 0x3c, false),
    254: (c)=>groundShot(c, 0x196, 0xa0, false),
    255: (c)=>groundShot(c, 0x198, 0x3c, true),
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state259,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    265: state265,
    266: (c)=>dashGround(c, 13.0),
    267: (c)=>dashGround(c, -13.0),
    268: state268,
    269: (c)=>dashAir(c, 13.0),
    270: (c)=>dashAir(c, -13.0),
    271: state271
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function childRelay(c, i, next) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 0;
    }
    if (ch.frame === 9 && ch.timer === 0 && ch.x > 0.0 && ch.x < 640.0) {
        const d = childSpawnFrame;
        d.w04 = next;
        d.x = ftol(ch.x) + ch.facing * 0x3c;
        d.y = 0.0;
        d.b20 = 0;
        d.b21 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childRunner(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3148[i] === 0) {
        ch.vx = (c.random(0, 0x14) & 0xffff) * 0.01 + 0.7;
        ch.hitsLeft = 1;
        c.a3148[i] = c.a3148[i] + 1;
    }
    if (childAdvance(c, i)) {
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
    if (ch.x < -30.0 && ch.facing === -1 || ch.x > 670.0 && ch.facing === 1) c.freeChild(i);
}
function childBeam(c, i, vx, ax, hits) {
    const ch = c.children[i];
    if (ch.frame === 3 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.hitsLeft = 5;
    }
    if (ch.frame > 4 && ch.frame < 0x26 && (c.state === 0xfa || c.state === 0xfb) && c.frame === 0xd || (c.state === 0x106 || c.state === 0x107) && c.frame === 0xe) {
        ch.vx = vx;
        ch.ax = ax;
        ch.vy = 0.0;
        ch.hitsLeft = hits;
        ch.timer = 0;
        ch.frame = 0;
        ch.pattern = 0x1a4;
        return;
    }
    if (ch.frame > 3 && ch.frame < 0x26 && ch.hitsLeft === 0 || c.state > 0x31 && c.state < 0x96 && ch.frame < 0x26 || c.state > 0xf9 && c.state < 0xfc && ch.frame < 0x26 && c.frame === 0 || c.state > 0x105 && c.state < 0x108 && ch.frame < 0x26 && c.frame === 0) {
        ch.timer = 0;
        ch.frame = 0x26;
        return;
    }
    if (!childAdvance(c, i)) return;
    c.a3348[i] = c.a3348[i] + 1;
    if (c.a3348[i] > 5) {
        ch.hitState = 0;
        c.a3348[i] = 0;
    }
    if (ch.frame === 0x25) {
        if (c.a3148[i] < 0 || c.a3148[i] < 1 && ch.y < -38.0) {
            ch.frame = 4;
            c.a3148[i] = c.a3148[i] + 1;
        } else {
            ch.vx = 0.0;
            ch.frame = 0x29;
        }
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child419(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    if (ch.frame === 3 && ch.timer === 0) {
        ch.vx = 0.35;
        ch.hitsLeft = 1;
    }
    ch.vx = ch.vx + 0.005;
    if (ch.hitState === 3 && ch.frame < 0x25) {
        ch.timer = 0;
        ch.frame = 0x25;
        ch.vx = 0.0;
        c.voiceRequest = 0xc;
        return;
    }
    if (ch.hitState > 1 && ch.frame < 0x25) {
        ch.timer = 0;
        ch.frame = 0x28;
        ch.vx = 0.0;
        return;
    }
    if (ch.frame === 0x25 && ch.hitState === 3) {
        o.stopMotion();
        o.onStateChange();
        o.state = 0x79;
        ch.hitState = 0;
    }
    if (ch.frame > 3 && ch.frame < 0x26 && ch.hitsLeft === 0 || c.state > 0x31 && c.state < 0x96 && ch.frame < 0x26) {
        ch.timer = 0;
        ch.frame = 0x26;
        return;
    }
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame === 0x25) {
        if (c.a3148[i] < 6) {
            ch.frame = 4;
            c.a3148[i] = c.a3148[i] + 1;
        } else {
            ch.vx = 0.0;
            ch.frame = 0x28;
        }
    }
    if (ch.frame >= childCount) {
        c.freeChild(i);
        if (o.state === 0x79) {
            o.onStateChange();
            o.stopMotion();
            o.y = -480.0;
            o.x = c.x;
            o.state = 0x3b;
        }
    }
}
function child420(c, i) {
    const ch = c.children[i];
    ch.vx = ch.vx + ch.ax;
    if (ch.vx < 0.0) ch.vx = 0.0;
    if (!childAdvance(c, i)) return;
    c.a3348[i] = c.a3348[i] + 1;
    if (c.a3348[i] > 5) {
        ch.hitState = 0;
        c.a3348[i] = 0;
    }
    if (ch.frame === 0x25 && ch.vx > 0.0) {
        ch.frame = 4;
        c.a3148[i] = c.a3148[i] + 1;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child437(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 1;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childShard(c, i, angle) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        setPolarVelocity(c, i, angle, 3.6);
    }
    if (ch.hitState > 0 && ch.frame === 0) {
        ch.frame = 1;
        ch.timer = 0;
        ch.vx = -0.9;
        ch.vy = -2.7;
        return;
    }
    if (ch.frame > 0) ch.vy = ch.vy + 0.045;
    if (ch.y + ch.vy > 0.0) {
        ch.y = 0.0;
        ch.vy = -0.5 * ch.vy;
        if (ch.blend === 0) {
            ch.blend = 1;
        } else {
            c.freeChild(i);
            return;
        }
    }
    if (childAdvance(c, i)) {
        if (ch.frame === 1) ch.frame = ch.frame - 1;
        if (ch.frame >= childCount) ch.frame = 1;
    }
    if (ch.x < -30.0 || ch.x > 670.0 || ch.y < -510.0) c.freeChild(i);
}
function child459(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 0x63;
        c.voiceRequest = 0xd;
    }
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.hitState = 0;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    408: (c, i)=>childRelay(c, i, 0x199),
    409: (c, i)=>childRelay(c, i, 0x19a),
    410: (c, i)=>childRelay(c, i, 0x198),
    411: childRunner,
    412: childRunner,
    413: childRunner,
    414: childRunner,
    415: childRunner,
    416: childRunner,
    417: (c, i)=>childBeam(c, i, 3.0, -0.05, 3),
    418: (c, i)=>childBeam(c, i, 3.5, -0.04, 5),
    419: child419,
    420: child420,
    437: child437,
    444: (c, i)=>childShard(c, i, 0.0),
    445: (c, i)=>childShard(c, i, 0.0),
    446: (c, i)=>childShard(c, i, 0.0),
    447: (c, i)=>childShard(c, i, 0.0),
    448: (c, i)=>childShard(c, i, -35.0),
    449: (c, i)=>childShard(c, i, -60.0),
    450: (c, i)=>childShard(c, i, -60.0),
    451: (c, i)=>childShard(c, i, -85.0),
    459: child459
});
