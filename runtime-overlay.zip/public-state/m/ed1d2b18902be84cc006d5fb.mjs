import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./5ebc1d602888d5d1fbd12f34.mjs";
import { updateChildrenNayuki } from "./1ced9d0c06b49387c5b9e1d5.mjs";
import { parseCommandNayuki, dispatchMovesNayuki } from "./16f6563882e9a043174d8c4b.mjs";
import { thinkNayuki } from "./ec6a862e22018797c10a96bb.mjs";
import { renderOverlayNayuki } from "./65a0fb463dc9a48f0fe8a3a3.mjs";
import "./f3180801b4015a59fdddea06.mjs";
import "./00fcd1f481026401ce6edcdc.mjs";
import "./53d9ec43941af9572e8ee4ee.mjs";
const POINTS_X = [
    -5,
    18,
    14,
    20,
    36
];
const POINTS_Y = [
    -58,
    0,
    -17,
    -25,
    -44
];
const F3148_INIT = 3;
export class Nayuki extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = F3148_INIT;
    f314c = 0;
    f3154 = 0;
    f3150 = 0;
    f3158 = 0;
    a315c = new Int32Array(64);
    a325c = new Int32Array(64);
    a335c = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        7,
        1,
        6,
        0x10,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    wF2 = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = F3148_INIT;
        this.f314c = 0;
        this.f3150 = 0;
        this.f3154 = 0;
        this.f3158 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a315c.fill(0);
        this.a325c.fill(0);
        this.a335c.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a315c[i] = 0;
        this.a325c[i] = 0;
        this.a335c[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayNayuki(this);
    }
    tickHook() {}
    parseCommand() {
        parseCommandNayuki(this);
    }
    dispatchMoves() {
        dispatchMovesNayuki(this);
    }
    think() {
        thinkNayuki(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenNayuki(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
