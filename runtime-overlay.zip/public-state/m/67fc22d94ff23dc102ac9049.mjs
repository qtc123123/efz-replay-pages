import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./72fceafa5789cf9e4e3cf0ff.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./f2e83919002a3a51b71740fe.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { requestGameSpeed } from "./11a8544a0f705ad2a3ee4f96.mjs";
const w16 = (v)=>v & 0xffff;
function fxAtSelf(c, d, pat, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
var Jc = /*#__PURE__*/ function(Jc) {
    Jc[Jc["None"] = 0] = "None";
    Jc[Jc["Ge2"] = 1] = "Ge2";
    Jc[Jc["Eq3"] = 2] = "Eq3";
    Jc[Jc["Ge2NoD15c"] = 3] = "Ge2NoD15c";
    return Jc;
}(Jc || {});
function groundJumpCancel(c, kind) {
    if (kind === 0) return false;
    if (c.inputY !== -1 || c.frame <= 0) return false;
    if (kind !== 3 && c.d15c >= 3) return false;
    if (kind === 2 ? c.d168 !== 3 : c.d168 < 2) return false;
    jumpTo456(c);
    return true;
}
function airJumpCancel(c) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && c.d168 >= 2 && c.b15a === 0) {
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function attackStart(c, meter, se, hits) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = hits;
}
function stopIfNotDashing(c) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
}
function dashSlide(c, k) {
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - k;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function airDashEnd(c, vx) {
    c.setState(9);
    c.vx = vx;
    c.ay = 0.03;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function burstFx(c, d) {
    d.w04 = 9;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 60;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    c.w16c = 1;
    c.seRequest = 62;
}
function airLand(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function s96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (advance(c, dur)) {
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function s97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, d, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(99);
}
function s99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.timer = w16(c.timer + 1);
    c.b158 = 0;
    if (c.life > 0 && c.timer > 99 && c.frame === 0) c.setState(96);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(96);
    }
}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        c.b158 = 0;
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx = c.vx + 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy = c.vy + c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAtSelf(c, d, 8, 2, 0);
    } else {
        c.vy = c.vy + c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    airLand(c);
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        burstFx(c, d);
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 6)) {
        c.stopMotion();
        burstFx(c, d);
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 15) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.startAfterimage(3);
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (atStart(c)) {
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.vx = 1.5;
    c.b158 = 1;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 4) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.setState(0);
            return;
        }
    }
    if (c.inputX === c.facing && c.f313c >= 80 && c.frame < 4) c.setState(178);
    if (c.inputX !== c.facing && c.f3138 >= 60 && c.frame < 4) c.setState(178);
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(2);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 2)) {
        c.vx = -1.6;
        c.vy = -1.0;
        c.ay = 0.04;
    }
    if (c.frame > 1 && c.frame < 5) c.vy = c.vy + c.ay;
    if (c.frame > 2 && c.vy + c.y >= 0.0 && c.f3138 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.y = 0.0;
        c.f3138++;
        c.seRequest = 9;
        c.frame = 5;
        c.timer = 0;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.faceOpponent();
        c.setState(0);
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = 1.3;
        c.startAfterimage(3);
        c.vy = 0.0;
        c.ay = 0.0;
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 120) airDashEnd(c, 1.3);
    if (c.inputX !== c.facing && c.f3138 >= 39) airDashEnd(c, 1.3);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -1.3;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9);
    if (c.inputX !== -c.facing && c.f3138 >= 48) airDashEnd(c, -0.9);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        if (c.ay === 0.0) c.ay = 0.035;
        c.vx = 0.0;
        c.vy = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 10) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 10;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 2) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 10) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function groundNormal(c, jc, slide, atk, meter, se, clearBelow, crouchable) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stopIfNotDashing(c);
    dashSlide(c, slide);
    if (groundJumpCancel(c, jc)) return;
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, crouchable);
    }
}
const s200 = (c)=>groundNormal(c, 1, 0.03, 2, 5, 21, 3, false);
const s201 = (c)=>groundNormal(c, 2, 0.03, 1, 15, 20, 4, false);
const s202 = (c)=>groundNormal(c, 0, 0.03, 4, 15, 20, 6, false);
const s204 = (c)=>groundNormal(c, 1, 0.03, 1, 5, 21, 3, true);
const s205 = (c)=>groundNormal(c, 1, 0.03, 2, 13, 20, 4, true);
const s206 = (c)=>groundNormal(c, 0, 0.03, 3, 25, 20, 4, true);
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    stopIfNotDashing(c);
    if (groundJumpCancel(c, 2)) return;
    dashSlide(c, 0.06);
    if (groundJumpCancel(c, 3)) return;
    if (atFrame(c, 5)) {
        attackStart(c, 35, 20, 1);
        d.w04 = 400;
        d.x = ftol(c.x) + c.facing * 0x1e;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b2c = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (advance(c, dur)) {
        if (c.frame < 6) c.d168 = 0;
        if (c.frame === 8 && c.f313c < 5) {
            c.f313c++;
            c.frame = w16(c.frame - 2);
            if (c.f313c === 3) c.w16c = 0;
        }
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function airNormalHead(c, atk, start) {
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c)) return false;
    if (atFrame(c, atk)) start();
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.state = 13;
        c.onStateChange();
        return false;
    }
    return true;
}
function s207(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!airNormalHead(c, 2, ()=>attackStart(c, 5, 21, 1))) return;
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s208(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!airNormalHead(c, 1, ()=>attackStart(c, 13, 20, 1))) return;
    if (advance(c, dur)) {
        if (c.frame === 4 && c.f3138 === 0) {
            c.frame = w16(c.frame - 2);
            c.f3138++;
        }
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s209(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (!airNormalHead(c, 2, ()=>{
        c.voiceRequest = 2;
        attackStart(c, 30, 20, 3);
    })) return;
    if (advance(c, dur)) {
        if (c.frame === 6 && c.f3138 < 4) {
            c.frame = w16(c.frame - 2);
            c.f3138++;
        }
        if (s16(c.w16c) > 0) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 221;
        o.state = 107;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x25;
        d.y = ftol(c.y) - 42;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (atFrame(c, 1) && c.f3140 === 8) {
        applyDirectDamage(c, 1000, 750.0);
        o.onStateChange();
        o.state = 86;
        o.knockX = -1.0;
        o.knockY = -4.0;
    }
    if (c.frame > 14) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.state = 13;
            c.onStateChange();
            c.stopMotion();
            return;
        }
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 2 && c.f3140 < 14) {
            c.f3140++;
            c.frame = 0;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function dashAttack(c, jc, slide, atk, meter, se, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (groundJumpCancel(c, jc)) return;
    if (slide) c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atStart(c)) c.vy = 0.0;
    if (atFrame(c, atk)) attackStart(c, meter, se, 1);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(end);
    }
}
const s230 = (c)=>dashAttack(c, 0, false, 1, 5, 21, 0);
const s231 = (c)=>dashAttack(c, 2, true, 2, 10, 20, 0);
const s233 = (c)=>dashAttack(c, 0, false, 1, 5, 21, 3);
const s234 = (c)=>dashAttack(c, 0, false, 2, 5, 21, 3);
const s235 = (c)=>dashAttack(c, 0, true, 2, 5, 21, 3);
function s232(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (c.frame > 0 && c.frame < 2) c.vx = c.vx - 0.03;
    if (atFrame(c, 6)) {
        addMeter(c, 25);
        c.seRequest = 20;
    }
    if (c.y < 0.0) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.timer = 0;
            c.frame = 11;
        }
    }
    if (advance(c, dur)) {
        if (c.frame === 2) {
            c.vx = 1.0;
            c.vy = -0.9;
            c.ay = 0.02;
            c.w16c = 1;
        }
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function s248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        o.d128 = 1;
        c.stopMotion();
        c.onStateChange();
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 32;
        d.y = ftol(c.y) - 57;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.frame = 0;
        c.timer = 0;
        c.state = 249;
        o.state = 103;
        o.x = c.facing * 32 + c.x;
        o.y = c.y - 57.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 209;
            c.frame = 2;
        }
    }
}
function s249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.w13e = 2;
    if (atFrame(c, 2) && c.f3138 === 8) {
        applyDirectDamage(c, 1100, 500.0);
        o.onStateChange();
        o.state = 86;
        o.knockX = -1.0;
        o.knockY = -4.0;
    }
    if (c.frame > 3) {
        c.vy = c.vy + 0.035;
        if (c.y + c.vy > 0.0) {
            c.stopMotion();
            c.y = 0.0;
            c.onStateChange();
            c.state = 13;
            return;
        }
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 3 && c.f3138 < 15) {
            c.frame = w16(c.frame - 2);
            c.f3138++;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
registerStates({
    96: s96,
    97: s97,
    98: s97,
    99: s99,
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    234: s234,
    235: s235,
    248: s248,
    249: s249
});
function childAdvance(c, i, dur) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    return true;
}
function child400(c, i) {
    const dur = childDuration;
    const cnt = childCount;
    if (childAdvance(c, i, dur) && c.children[i].frame >= cnt) c.freeChild(i);
}
function child445(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const o = c.opponent;
    ch.y = o.y;
    ch.x = o.x;
    if (c.state === 319 && c.frame === 3) {
        o.facing = -c.facing;
        applyDirectDamage(c, 5000, 700.0);
        c.shakeScreen(8, 5);
        requestGameSpeed(1);
        o.hitstop = 0;
        o.state = 63;
        o.frame = 0;
        o.timer = 0;
        o.knockX = -0.2;
        o.knockY = -1.0;
        o.d128 = 1;
        const f = childSpawnFrame;
        f.w04 = 52;
        f.x = ftol(ch.x);
        f.y = ftol(ch.y) - 40;
        f.b20 = 2;
        f.b21 = 1;
        f.b2c = 22;
        frameEffect(f);
        for (const pattern of [
            446,
            447,
            448,
            449
        ]){
            f.w04 = pattern;
            f.x = ftol(ch.x);
            f.y = ftol(ch.y);
            f.b20 = 0;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        c.freeChild(i);
    }
    ch.timer = w16(ch.timer + 1);
    c.a3258[i]--;
    if (ch.timer >= dur) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= cnt) ch.frame = w16(ch.frame - 1);
    }
}
function debris(c, i, vx, vy) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        c.a3158[i]++;
        ch.vx = vx;
        ch.vy = vy;
    }
    ch.vy = ch.vy + 0.035;
    ch.timer = w16(ch.timer + 1);
    c.a3258[i]--;
    if (ch.timer >= dur) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= cnt) {
            ch.frame = 0;
            if (ch.blend === 1) {
                c.freeChild(i);
                return;
            }
            if (ch.blend === 0) ch.blend = 1;
        }
    }
}
registerChildren({
    400: child400,
    445: child445,
    446: (c, i)=>debris(c, i, -1.0, -1.0),
    447: (c, i)=>debris(c, i, -0.7, -0.5),
    448: (c, i)=>debris(c, i, 0.85, -0.7),
    449: (c, i)=>debris(c, i, 0.1, -0.9)
});

export function __logicState(){return {Jc};}

export function __installInitialRoots(s){
Jc=s["Jc"];
}
