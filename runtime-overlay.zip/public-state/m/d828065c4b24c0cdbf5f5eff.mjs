import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { HISTORY_LENGTH, NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { registerChildren } from "./6eb1fb66adb5d5a47cd5c7ec.mjs";
import { abortChildWalk, childCount, childDuration, childSpawnFrame, frameChild } from "./746d3a93e9a50814987814cf.mjs";
import { ftol } from "./7596266716c972d06fe8897a.mjs";
function hist(c, i) {
    return c.history[i - (i >= HISTORY_LENGTH ? 1 : 0) * HISTORY_LENGTH];
}
function buttonCommand(base, v) {
    return base + ((v & 0xe0) > 0 ? 1 : 0) + ((v & 0xc0) > 0 ? 1 : 0) + ((v & 0x80) > 0 ? 1 : 0);
}
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function cancelable(c) {
    return ((c.currentHit()?.defenseFlags ?? 0) & 8) > 0;
}
function priorityOk(c, target) {
    return (c.patterns[c.state]?.hdrB ?? 0) <= (c.patterns[target]?.hdrA ?? 0);
}
function priorityOr212(c, target) {
    return priorityOk(c, target) || c.state === 212;
}
function cancelOk(c) {
    if (c.state >= 200 && c.d168 >= 2 && c.d168 !== 6) return true;
    return c.state < 200;
}
function rfOk(c) {
    return c.rfGauge >= 500.0 || c.rfBlue > 0;
}
function enter(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function normalOk(c, target) {
    return priorityOk(c, target) && cancelable(c) && cancelOk(c);
}
function groundSpecialOk(c, target) {
    return cancelable(c) && c.y === 0.0 && priorityOr212(c, target) && cancelOk(c);
}
function cloneIdleOr1(c) {
    return c.f3144 === 0 || c.f3144 === 1;
}
export function parseCommandMai(c) {
    c.command = NO_COMMAND;
    const idx = c.historyIndex;
    const end = idx + HISTORY_LENGTH;
    const left = c.facing === -1 ? 1 : 0;
    const BACK = 2 - left;
    const FWD = 1 + left;
    const DOWN_BACK = 6 - left;
    const DOWN_FWD = 5 + left;
    let step;
    let v;
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x6e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x6e, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_BACK && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x64, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x64, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_FWD && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x14, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x14, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x28, v);
            return;
        }
        if ((v & 0xf) === 4 && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x28, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x1e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x1e, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0xaf; i < end; i++){
        v = hist(c, i);
        if (v & 8 && step === 1) {
            c.command = 6;
            return;
        }
        if (!(v & 8) && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 4) {
            c.command = 53;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 4) {
            c.command = 52;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 4) {
            c.command = 51;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 4) {
            c.command = 50;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 1 && step === 3) {
            c.command = 1;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 1 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 2 && step === 3) {
            c.command = 0;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 2 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
}
export function dispatchMovesMai(c) {
    if (c.state < 200) c.bufferedA = 0;
    if (c.bufferTimer > 0) {
        c.bufferTimer = c.bufferTimer - 1 & 0xff;
    } else {
        c.bufferedB = 0;
    }
    if (c.bufferedB === 0) c.bufferTimer = 0;
    if (c.command === 52) {
        let ok = false;
        if (c.rfGauge >= 500.0 && c.d168 > 1 && c.d168 !== 6) ok = true;
        else if (c.rfBlue > 0 && c.d168 > 1) ok = true;
        if (ok && cancelable(c) && priorityOk(c, 167)) {
            enter(c, 167);
            if (c.y < 0.0) c.state = 171;
            return;
        }
    }
    if (c.d15c < 2) {
        if (c.f3148 > 0 && c.life < 3333 && c.command === 103 && c.y === 0.0 && cancelable(c) && c.f3144 === 4 && cancelOk(c) && priorityOk(c, 324)) {
            enter(c, 324);
            return;
        }
        if (c.life < 3333 && c.command === 103 && c.meter >= 3000 && c.y === 0.0 && cancelable(c) && c.f3144 === 0 && cancelOk(c) && priorityOk(c, 309)) {
            enter(c, 309);
            return;
        }
        if (c.command === 112 && c.meter >= 3000 && c.y === 0.0 && cancelable(c) && cloneIdleOr1(c) && cancelOk(c) && priorityOk(c, 322)) {
            enter(c, 322);
            if (c.f3144 === 1) c.state = 323;
            return;
        }
        if ((c.command === 111 || c.command === 112) && c.meter >= 2000 && c.y === 0.0 && cancelable(c) && cloneIdleOr1(c) && priorityOk(c, 320) && cancelOk(c)) {
            enter(c, 320);
            if (c.f3144 === 1) c.state = 321;
            return;
        }
        if ((c.command === 110 || c.command === 111 || c.command === 112) && c.meter >= 1000 && c.y === 0.0 && cancelable(c) && cloneIdleOr1(c) && priorityOk(c, 318) && cancelOk(c)) {
            enter(c, 318);
            if (c.f3144 === 1) c.state = 319;
            return;
        }
        if (c.command === 102 && c.meter >= 3000 && c.y === 0.0 && cancelable(c) && priorityOk(c, 305) && cancelOk(c)) {
            enter(c, 305);
            return;
        }
        if ((c.command === 101 || c.command === 102) && c.meter >= 2000 && c.y === 0.0 && cancelable(c) && priorityOk(c, 304) && cancelOk(c)) {
            enter(c, 304);
            return;
        }
        if ((c.command === 100 || c.command === 101 || c.command === 102) && c.meter >= 1000 && c.y === 0.0 && cancelable(c) && priorityOk(c, 303) && cancelOk(c)) {
            enter(c, 303);
            return;
        }
        if (c.command === 22 && c.f3144 === 0 && groundSpecialOk(c, 268)) {
            enter(c, 268);
            return;
        }
        if ((c.command === 21 || c.command === 22) && c.f3144 === 0 && groundSpecialOk(c, 267)) {
            enter(c, 267);
            return;
        }
        if (c.command === 20 && c.f3144 === 0 && groundSpecialOk(c, 266)) {
            enter(c, 266);
            return;
        }
        if (c.command === 22 && (rfOk(c) || c.f3144 === 4) && cancelable(c) && c.y < 0.0 && priorityOk(c, 252) && cancelOk(c)) {
            enter(c, 252);
            return;
        }
        if ((c.command === 21 || c.command === 22) && cancelable(c) && c.y < 0.0 && priorityOk(c, 251) && cancelOk(c)) {
            enter(c, 251);
            return;
        }
        if (c.command === 20 && cancelable(c) && c.y < 0.0 && priorityOk(c, 250) && cancelOk(c)) {
            enter(c, 250);
            return;
        }
        if (c.command === 32 && (c.f3144 === 0 || c.f3144 === 4) && groundSpecialOk(c, 259)) {
            enter(c, 259);
            return;
        }
        if ((c.command === 31 || c.command === 32) && (c.f3144 === 0 || c.f3144 === 4) && groundSpecialOk(c, 258)) {
            enter(c, 258);
            return;
        }
        if (c.command === 30 && (c.f3144 === 0 || c.f3144 === 4) && groundSpecialOk(c, 257)) {
            enter(c, 257);
            return;
        }
        if (c.command === 12 && rfOk(c) && c.f3144 === 0 && groundSpecialOk(c, 265)) {
            enter(c, 265);
            return;
        }
        if ((c.command === 12 || c.command === 11) && c.f3144 === 0 && groundSpecialOk(c, 264)) {
            enter(c, 264);
            return;
        }
        if (c.command === 10 && c.f3144 === 0 && groundSpecialOk(c, 263)) {
            enter(c, 263);
            return;
        }
        if (c.command === 42 && (c.f3144 === 4 || rfOk(c)) && groundSpecialOk(c, 256)) {
            enter(c, 256);
            return;
        }
        if ((c.command === 41 || c.command === 42) && groundSpecialOk(c, 255)) {
            enter(c, 255);
            return;
        }
        if (c.command === 40 && groundSpecialOk(c, 254)) {
            enter(c, 254);
            return;
        }
    }
    if (c.d15c < 3 && c.command === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && priorityOk(c, 14) && cancelOk(c)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return;
    }
    if (c.d15c < 1 && (c.command === 0 || c.command === 1)) {
        const dir = 1 - (c.command << 1);
        if (c.y < 0.0 && c.b159 < 1) {
            const dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 165) && c.state !== 170 && c.y < -30.0 && cancelable(c) && cancelOk(c)) {
                airDash(c, 165);
                return;
            }
            const dx2 = c.opponent.x - c.x;
            if ((dx2 * dir > 0.0 || dx2 === 0.0 && c.facing === dir) && priorityOk(c, 166) && c.state !== 170 && cancelable(c) && cancelOk(c)) {
                airDash(c, 166);
                return;
            }
        }
        if (c.y === 0.0 && cancelable(c)) {
            const dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 163) && cancelOk(c)) {
                groundDash(c, 163);
                return;
            }
            const dx2 = c.opponent.x - c.x;
            if ((dx2 * dir > 0.0 || dx2 === 0.0 && c.facing === dir) && priorityOk(c, 164) && cancelOk(c)) {
                groundDash(c, 164);
                return;
            }
        }
    }
    if (c.pressed[0] === 1 || c.bufferedA & 0x10 || c.bufferedB & 0x10) {
        if (c.y < 0.0) {
            if (normalOk(c, 207)) enter(c, 207);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 204)) {
            enter(c, 204);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (c.f3144 === 4 && priorityOk(c, 213) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 213);
                return;
            }
            if (c.state !== 212 && priorityOk(c, 210) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 210);
                if (c.f3144 === 4) c.state = 213;
                return;
            }
            if (normalOk(c, 200)) {
                enter(c, 200);
                return;
            }
        }
    }
    if (c.pressed[1] === 1 || c.bufferedA & 0x20 || c.bufferedB & 0x20) {
        if (c.y < 0.0) {
            if (normalOk(c, 208)) enter(c, 208);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 205)) {
            enter(c, 205);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (c.f3144 === 4 && priorityOk(c, 214) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 214);
                return;
            }
            if (c.state !== 212 && priorityOk(c, 211) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 211);
                if (c.f3144 === 4) c.state = 214;
                return;
            }
            if (priorityOk(c, 201) && cancelable(c) && c.x - c.opponent.x > -70.0 && c.x - c.opponent.x < 70.0 && cancelOk(c)) {
                enter(c, 201);
                return;
            }
            if (normalOk(c, 202)) {
                enter(c, 202);
                return;
            }
        }
    }
    if (c.pressed[2] === 1 || c.bufferedA & 0x40 || c.bufferedB & 0x40) {
        if (c.y < -10.0 && c.state === 163) {
            enter(c, 232);
            return;
        }
        if (c.y < 0.0) {
            if (c.inputX === c.facing && c.inputY === 0 && c.x - c.opponent.x > -100.0 && c.x - c.opponent.x < 100.0 && c.opponent.y < 0.0 && priorityOk(c, 240) && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 240);
                return;
            }
            if (normalOk(c, 209)) enter(c, 209);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 206)) {
            enter(c, 206);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 216) && c.inputX === c.facing) {
            enter(c, 216);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (c.inputX !== 0 && c.opponent.y === 0.0 && c.x - c.opponent.x > -30.0 && c.x - c.opponent.x < 30.0 && priorityOk(c, 220) && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 220);
                return;
            }
            if (c.f3144 === 4 && priorityOk(c, 215) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 215);
                return;
            }
            if (priorityOk(c, 212) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 212);
                if (c.f3144 === 4) c.state = 215;
                return;
            }
            if (priorityOk(c, 216) && cancelable(c) && c.inputX === -c.facing && cancelOk(c)) {
                enter(c, 216);
                return;
            }
            if (normalOk(c, 203)) {
                enter(c, 203);
                return;
            }
        }
    }
    if (c.d15c >= 2) return;
    if (c.inputY !== 0) return;
    if (c.pressed[3] !== 1) return;
    if (priorityOk(c, 260) && cancelable(c) && c.f3144 === 0 && c.y === 0.0 && cancelOk(c)) {
        enter(c, 260);
        if (c.inputX === c.facing) c.f3140 = 1;
        if (c.inputX === -c.facing) c.f3140 = 2;
        return;
    }
    if (c.command === NO_COMMAND && priorityOk(c, 269) && cancelable(c) && c.f3144 === 1 && c.y === 0.0 && cancelOk(c)) {
        enter(c, 269);
    }
}
function airDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    c.b159 = c.b159 + 1 & 0xff;
    c.b15a = c.b15a + 1 & 0xff;
    c.bufferedA = 0;
}
function groundDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    c.b158 = c.b158 + 1 & 0xff;
    c.bufferedA = 0;
}
function cloneAttackInterrupted(c, i) {
    const ch = c.children[i];
    c.f3144 = 2;
    if (c.state > 49 && c.state < 150 || ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 402;
        ch.frame = 0;
        ch.timer = 0;
        abortChildWalk();
        return true;
    }
    return false;
}
function tickFrame(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function resetHitOnFrames(c, i) {
    const ch = c.children[i];
    if (ch.frame === 4 || ch.frame === 6 || ch.frame < 3) ch.hitState = 0;
}
function backTo401(c, i) {
    const ch = c.children[i];
    ch.pattern = 401;
    c.f3144 = 1;
    c.f3148 = 10000;
    c.a3158[i] = 0;
    c.a3258[i] = 0;
    ch.frame = 3;
}
function child428(c, i) {
    if (cloneAttackInterrupted(c, i)) return;
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 4;
        ch.vx = 1.7;
    }
    ch.vx = ch.vx - 0.035;
    if (ch.vx < 0.0) ch.vx = 0.0;
    if (ch.x > 600.0 && ch.facing === 1) {
        ch.x = 600.0;
        ch.vx = 0.0;
    }
    if (ch.x < 40.0 && ch.facing === -1) {
        ch.x = 40.0;
        ch.vx = 0.0;
    }
    if (!tickFrame(c, i)) return;
    if (ch.frame === 7 && c.a3158[i] < 3) {
        ch.frame -= 4;
        c.a3158[i]++;
    }
    resetHitOnFrames(c, i);
    if (ch.frame === 9 && c.a3258[i] < 1) {
        ch.frame -= 2;
        c.a3258[i]++;
        return;
    }
    if (ch.frame >= childCount) {
        c.f3144 = 3;
        c.f314c = 0;
        c.f3148 = 1200;
        c.f3150 = 1;
        c.a3158[i] = 0;
        c.a3258[i] = 0;
        c.freeChild(i);
    }
}
function child429(c, i) {
    if (cloneAttackInterrupted(c, i)) return;
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 4;
        ch.vx = 1.7;
    }
    ch.vx = ch.vx - 0.025;
    if (ch.vx < 0.1) ch.vx = 0.1;
    if (ch.x > 600.0 && ch.facing === 1) {
        ch.x = 600.0;
        ch.vx = 0.0;
    }
    if (ch.x < 40.0 && ch.facing === -1) {
        ch.x = 40.0;
        ch.vx = 0.0;
    }
    if (!tickFrame(c, i)) return;
    if (ch.frame === 7 && c.a3158[i] < 1) {
        ch.frame -= 4;
        c.a3158[i]++;
    }
    resetHitOnFrames(c, i);
    if (ch.frame < childCount) return;
    if (c.a3258[i] < 2) {
        ch.frame -= 2;
        c.a3258[i]++;
        return;
    }
    backTo401(c, i);
}
function child430(c, i) {
    if (cloneAttackInterrupted(c, i)) return;
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 16;
        ch.vx = 2.0;
    }
    ch.vx = ch.vx - 0.025;
    if (ch.vx < 0.4) ch.vx = 0.4;
    if (ch.x > 600.0) {
        ch.x = 600.0;
        ch.vx = 0.0;
    }
    if (ch.x < 40.0) {
        ch.x = 40.0;
        ch.vx = 0.0;
    }
    if (!tickFrame(c, i)) return;
    if (ch.frame === 7 && c.a3158[i] < 7) {
        ch.frame -= 4;
        c.a3158[i]++;
    }
    resetHitOnFrames(c, i);
    if (ch.frame < childCount) return;
    if (c.a3258[i] < 5) {
        ch.frame -= 2;
        c.a3258[i]++;
        return;
    }
    backTo401(c, i);
}
function child431(c, i) {
    if (cloneAttackInterrupted(c, i)) return;
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 8;
        ch.vx = 1.3;
    }
    ch.vx = ch.vx - 0.025;
    if (ch.vx < 0.1) ch.vx = 0.1;
    if (ch.x > 600.0) {
        ch.x = 600.0;
        ch.vx = 0.0;
    }
    if (ch.x < 40.0) {
        ch.x = 40.0;
        ch.vx = 0.0;
    }
    if (!tickFrame(c, i)) return;
    if (ch.frame === 7 && c.a3158[i] < 3) {
        ch.frame -= 4;
        c.a3158[i]++;
    }
    if (ch.frame === 9 && c.a3258[i] < 2) {
        ch.frame -= 2;
        c.a3258[i]++;
        return;
    }
    resetHitOnFrames(c, i);
    if (ch.frame >= childCount) {
        c.f3144 = 3;
        c.f3148 = 1200;
        c.a3158[i] = 0;
        c.a3258[i] = 0;
        ch.frame = 0;
        ch.vx = 0.0;
        c.freeChild(i);
    }
}
function child432(c, i) {
    if (cloneAttackInterrupted(c, i)) return;
    const ch = c.children[i];
    if (ch.frame === 2 && ch.timer === 0) {
        const f = childSpawnFrame;
        f.w04 = 0x1c5;
        f.x = ftol(ch.facing * 0x3c + ch.x);
        f.y = ftol(ch.y - 50.0);
        f.d00 = 1;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = ch.facing;
        frameChild(c, f);
    }
    if (ch.x > 600.0) {
        ch.x = 600.0;
        ch.vx = 0.0;
    }
    if (ch.x < 40.0) {
        ch.x = 40.0;
        ch.vx = 0.0;
    }
    if (!tickFrame(c, i)) return;
    ch.hitState = 0;
    if (ch.frame === 5 && c.a3158[i] < 4) {
        ch.frame -= 2;
        c.a3158[i]++;
    }
    if (ch.frame >= childCount) {
        ch.frame = 3;
        ch.timer = 0;
        ch.pattern = 401;
        c.a3158[i] = 0;
        c.f3148 = 10000;
        c.f3144 = 1;
    }
}
registerChildren({
    428: child428,
    429: child429,
    430: child430,
    431: child431,
    432: child432
});
