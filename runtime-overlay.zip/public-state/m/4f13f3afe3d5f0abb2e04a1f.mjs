import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./1d012cc8875ecbb32aaeb678.mjs";
import { registerChildren, registerStates } from "./62d688cb05fea0c19aa52424.mjs";
import { frameCount, frameDuration, s16 } from "./7596266716c972d06fe8897a.mjs";
const DEG = 57.29579143313326;
function setPolarVelocity(c, angle, speed) {
    c.vx = __numerics.cos(angle / DEG) * speed;
    c.vy = __numerics.sin(angle / DEG) * speed;
}
function rfCostEffect(c, f) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function dustEffect(c, f, dx) {
    f.w04 = 0x1f;
    f.x = Math.trunc(c.x) + c.facing * dx;
    f.y = Math.trunc(c.y);
    f.b20 = 0;
    f.b21 = 0;
    f.d1c = c.facing === -1 ? 1 : 0;
    frameEffect(f);
}
function spawnFromBody(c, f, pattern, dx, dy) {
    f.w04 = pattern;
    f.x = Math.trunc(c.x) + c.facing * dx;
    f.y = Math.trunc(c.y) - dy;
    f.b20 = 2;
    f.b21 = 1;
    f.b18 = c.facing;
    frameChild(c, f);
}
function anyPressed(c) {
    return c.pressed[0] === 1 || c.pressed[1] === 1 || c.pressed[2] === 1 || c.pressed[3] === 1;
}
function rapidCancel(c, bump) {
    if (!anyPressed(c)) return false;
    const go = (state, flip)=>{
        c.onStateChange();
        c.state = state;
        if (bump) c.f313c = c.f313c + 1;
        if (flip) c.facing = -c.facing;
        return true;
    };
    if (c.inputY === -1) {
        if (c.inputX === 0) return go(0x106, false);
        if (c.inputX === c.facing) return go(0x107, false);
        if (c.inputX === -c.facing) return go(0x107, true);
    }
    if (c.inputY === 0) {
        if (c.inputX === c.facing) return go(0x108, false);
        if (c.inputX === -c.facing) return go(0x108, true);
    }
    if (c.inputY === 1) {
        if (c.inputX === 0) return go(0x10a, false);
        if (c.inputX === c.facing) return go(0x109, false);
        if (c.inputX === -c.facing) return go(0x109, true);
    }
    return false;
}
function rollLevel(c) {
    if (c.random(0, 1000) < 500) {
        c.f3158 = 1;
    } else {
        c.f3158 = 2;
    }
}
function charge(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.meter = s16(c.meter + 0x2d);
        c.f3138 = 5;
        c.w16c = 1;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 3) c.voiceRequest = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.d168 > 0 && c.f3158 === 0) rollLevel(c);
            c.onStateChange();
        }
    }
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.meter = s16(c.meter + 0x2d);
        c.w16c = 2;
        rfCostEffect(c, f);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.d168 > 0) c.f3138 = 1;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2 || c.frame === 11) c.d168 = 0;
        if (c.frame === 3) c.voiceRequest = 0;
        if (c.frame === 12) c.voiceRequest = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.f3138 > 0 && c.f3158 === 0) rollLevel(c);
            c.onStateChange();
        }
    }
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 6;
    }
    if (c.vx > 0.0) {
        c.vx = c.vx - 0.035;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 10 || c.frame === 13 || c.frame === 16 || c.frame === 19) c.d168 = 0;
        if (c.frame === 5) {
            dustEffect(c, f, 0x28);
            c.vx = 3.0;
        }
        if (c.frame === 7 && c.f3138 < 2) {
            c.f3138 = c.f3138 + 1;
            c.frame = c.frame - 2;
            return;
        }
        if (c.frame === 7 && c.d168 === 0) c.frame = 0x16;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 4;
    }
    if ((c.frame === 6 || c.frame === 9 || c.frame === 12 || c.frame === 15) && c.timer === 0) {
        c.seRequest = 0x15;
        c.meter = s16(c.meter + 5);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 6 || c.frame === 9 || c.frame === 12 || c.frame === 15) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        rfCostEffect(c, f);
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 0x63;
    }
    if (c.vx > 0.0) {
        c.vx = c.vx - 0.035;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 10 || c.frame === 13 || c.frame === 16 || c.frame === 19 || c.frame === 22 || c.frame === 25 || c.frame === 28 || c.frame === 31) c.d168 = 0;
        if (c.frame === 5) {
            dustEffect(c, f, 0x28);
            c.vx = 3.2;
        }
        if (c.frame === 7 && c.f3138 < 2) {
            c.f3138 = c.f3138 + 1;
            c.frame = c.frame - 2;
            c.d168 = 0;
            return;
        }
        if (c.frame === 7 && c.d168 === 0) c.frame = 0x1f;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function groundShot(c, flip, angle, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame > 4 && c.frame < 7) {
        if (rapidCancel(c, false)) return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (flip && c.frame === 4 && c.timer === 0) c.facing = -c.facing;
        if (c.frame === 5 && c.timer === 0) {
            c.voiceRequest = 5;
            c.w16c = 1;
            setPolarVelocity(c, angle, 2.2);
            c.meter = s16(c.meter + 0x14);
            dustEffect(c, f, 0);
            spawnFromBody(c, f, pattern, 0, 0);
        }
        if (c.frame === 7 && c.f3138 < 4) {
            c.frame = c.frame - 2;
            c.f3138 = c.f3138 + 1;
        }
        if (c.frame >= cnt) {
            c.frame = 0;
            c.state = 0x11a;
            c.onStateChange();
        }
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame > 2 && c.frame < 5) {
        if (rapidCancel(c, false)) return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 3 && c.timer === 0) {
            c.voiceRequest = 5;
            c.w16c = 1;
            setPolarVelocity(c, 0.0, 2.2);
            c.meter = s16(c.meter + 0x14);
            spawnFromBody(c, f, 0x195, 0, 0);
        }
        if (c.frame === 5 && c.f3138 < 4) {
            c.f3138 = c.f3138 + 1;
            c.frame = c.frame - 2;
            return;
        }
        if (c.frame >= cnt) {
            c.state = 0x11b;
            c.frame = 0;
        }
    }
}
function diveShot(c, angle, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame > 3 && c.frame < 6) {
        if (rapidCancel(c, false)) return;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.y + c.vy > 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
        c.frame = 7;
        c.timer = 0;
        c.state = 0x11b;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 4 && c.timer === 0) {
            c.voiceRequest = 5;
            c.w16c = 1;
            setPolarVelocity(c, angle, 2.2);
            c.meter = s16(c.meter + 0x14);
            spawnFromBody(c, f, pattern, 0, 0);
        }
        if (c.frame === 6 && c.f3138 < 4) {
            c.f3138 = c.f3138 + 1;
            c.frame = c.frame - 2;
            return;
        }
        if (c.frame >= cnt) {
            c.state = 0x11a;
            c.frame = 0;
        }
    }
}
function airShot(c, landing, shotFrame, loopFrame, angle, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (landing && c.y + c.vy > 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
        c.frame = 7;
        c.timer = 0;
        c.state = 0x10b;
        return;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === shotFrame && c.timer === 0) {
            c.voiceRequest = 5;
            c.w16c = 1;
            setPolarVelocity(c, angle, 2.2);
            c.meter = s16(c.meter + 5);
            spawnFromBody(c, f, pattern, 0, 0);
        }
        if (c.frame === 4 && c.f3138 < 0) {
            c.f3138 = c.f3138 + 1;
            c.frame = c.frame - 2;
            return;
        }
        if (c.frame === loopFrame && c.f3138 < 4) {
            c.f3138 = c.f3138 + 1;
            c.frame = c.frame - 2;
            return;
        }
        if (c.frame >= cnt) {
            c.state = 0x10b;
            c.frame = 0;
            c.f313c = c.f313c + 1;
        }
    }
}
function airFall(c, consumeLevel1) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    openSpawnFrame();
    if (c.f3140 === 0) {
        c.vx = c.vx * 0.5;
        if (c.vy < 0.0) c.vy = c.vy * 0.75;
        c.f3140 = c.f3140 + 1;
    }
    if (c.f313c === 0 && c.frame < 5) {
        if (rapidCancel(c, true)) return;
    }
    if (c.frame < 7) {
        c.vy = c.vy + 0.035;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.vy = 0.0;
            c.timer = 0;
            c.frame = 7;
        }
    }
    if (c.frame > 6) {
        c.vx = c.vx - 0.05;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 7) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
            c.faceOpponent();
            if (consumeLevel1 && c.f3158 === 1) c.f3158 = 0;
        }
    }
}
function wave(c, pattern, d168, consumeLevel2) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    c.vy = c.vy + c.ay;
    if (c.frame === 7 && c.timer === 0) {
        c.voiceRequest = 1;
        f.d00 = 1;
        spawnFromBody(c, f, pattern, 0x40, 0);
        c.f3148 = 1;
        c.meter = s16(c.meter + 0x19);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = d168;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
            if (consumeLevel2 && c.f3158 === 2) c.f3158 = 0;
        }
    }
}
function state270(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        rfCostEffect(c, f);
        c.stopMotion();
    }
    c.vy = c.vy + c.ay;
    if (c.frame === 7 && c.timer === 0) {
        c.voiceRequest = 2;
        f.d00 = 1;
        spawnFromBody(c, f, 0x192, 0x14, 0x3c);
        c.f3148 = 1;
        c.meter = s16(c.meter + 0x19);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
            if (c.f3158 === 2) c.f3158 = 0;
        }
    }
}
function nearOpponent(c, variant272) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    c.vy = c.vy + c.ay;
    if (c.frame === 5 && c.timer === 0) {
        f.w04 = 0x198;
        const o = c.opponent;
        const far = variant272 ? !(c.x - o.x > 150.0 || c.x - o.x < -150.0) : c.x - o.x >= 150.0 || c.x - o.x <= -150.0;
        if (far) {
            if (o.x > c.x) f.x = c.x + 150.0;
            if (o.x < c.x) f.x = c.x - 150.0;
        } else {
            f.x = o.x;
        }
        f.y = Math.trunc(c.y);
        f.b18 = c.facing;
        f.b21 = 1;
        f.b20 = 2;
        f.d00 = 1;
        frameChild(c, f);
        c.f314c = 1;
        c.meter = s16(c.meter + 0x19);
        c.voiceRequest = 3;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 10 && c.f3138 < 2) {
            c.f3138 = c.f3138 + 1;
            c.frame = c.frame - 2;
        }
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
            if (c.f3158 === 2) c.f3158 = 0;
        }
    }
}
function attackStart(c) {
    c.b158 = 0;
    c.stopMotion();
    c.meter = s16(c.meter + 0x2d);
    c.f3138 = 5;
    c.w16c = 1;
}
function brake(c, step) {
    if (c.vx > 0.0) {
        c.vx = c.vx - step;
        if (c.vx < 0.0) c.vx = 0.0;
    }
}
const BRAKE_045 = 0.04500000178813934;
const BRAKE_025 = 0.02500000037252903;
function finishConsume(c, level) {
    c.state = 0;
    if (c.f3158 === level) c.f3158 = 0;
    c.onStateChange();
}
function state273(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) attackStart(c);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 2) spawnFromBody(c, f, 0x1b5, 0x26, 0x28);
        if (c.frame === 3) c.voiceRequest = 5;
        if (c.frame >= cnt) finishConsume(c, 1);
    }
}
function state274(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) attackStart(c);
    brake(c, BRAKE_045);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 3) {
            c.voiceRequest = 5;
            c.vx = 2.5;
            spawnFromBody(c, f, 0x1b5, 0x26, 0x28);
        }
        if (c.frame >= cnt) finishConsume(c, 1);
    }
}
function guardAttackStart(c, f) {
    c.b158 = 0;
    c.stopMotion();
    c.meter = s16(c.meter + 0x2d);
    c.w16c = 1;
    rfCostEffect(c, f);
}
function state275(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        guardAttackStart(c, f);
        c.vx = 1.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.d168 > 0) c.f3138 = 1;
    brake(c, BRAKE_025);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2 || c.frame === 11) c.d168 = 0;
        if (c.frame === 3) {
            c.voiceRequest = 5;
            spawnFromBody(c, f, 0x1bc, 0x26, 0x28);
        }
        if (c.frame === 9) {
            c.w16c = 1;
            c.d168 = 0;
            c.voiceRequest = 5;
            spawnFromBody(c, f, 0x1b5, 0x26, 0x28);
        }
        if (c.frame >= cnt) finishConsume(c, 1);
    }
}
function burst438(c, variant277) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) attackStart(c);
    if (variant277) brake(c, BRAKE_045);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 3) {
            c.voiceRequest = 4;
            spawnFromBody(c, f, 0x1b6, 0x26, 0x28);
            spawnFromBody(c, f, 0x1b8, 0, 0);
            if (variant277) {
                f.d00 = 1;
                spawnFromBody(c, f, 0x1ba, 0x5a, 0x3c);
            }
        }
        if (c.frame >= cnt) finishConsume(c, 2);
    }
}
function state278(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        guardAttackStart(c, f);
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.d168 > 0) c.f3138 = 1;
    brake(c, BRAKE_025);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2 || c.frame === 11) c.d168 = 0;
        if (c.frame === 3) {
            c.voiceRequest = 4;
            spawnFromBody(c, f, 0x1bd, 0x26, 0x28);
            spawnFromBody(c, f, 0x1b8, 0, 0);
        }
        if (c.frame === 9) {
            c.w16c = 1;
            c.d168 = 0;
            c.voiceRequest = 4;
            spawnFromBody(c, f, 0x1b6, 0x26, 0x28);
            spawnFromBody(c, f, 0x1b8, 0, 0);
        }
        if (c.frame >= cnt) finishConsume(c, 2);
    }
}
function state279(c, variant280) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) attackStart(c);
    if (variant280) brake(c, BRAKE_045);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 3) {
            c.voiceRequest = 0;
            if (variant280) c.vx = 2.5;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state281(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.meter = s16(c.meter + 0x2d);
        c.w16c = 2;
        rfCostEffect(c, f);
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.d168 > 0) c.f3138 = 1;
    brake(c, BRAKE_025);
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2 || c.frame === 11) c.d168 = 0;
        if (c.frame === 3) c.voiceRequest = 0;
        if (c.frame === 12) c.voiceRequest = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
registerStates({
    250: charge,
    251: charge,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: (c)=>groundShot(c, true, -45.0, 0x194),
    257: (c)=>groundShot(c, false, -45.0, 0x194),
    258: (c)=>groundShot(c, false, -90.0, 0x193),
    259: state259,
    260: (c)=>diveShot(c, 45.0, 0x196),
    261: (c)=>diveShot(c, 90.0, 0x197),
    262: (c)=>airShot(c, false, 7, 9, -90.0, 0x193),
    263: (c)=>airShot(c, false, 7, 9, -45.0, 0x194),
    264: (c)=>airShot(c, false, 7, 9, 0.0, 0x195),
    265: (c)=>airShot(c, true, 8, 10, 45.0, 0x196),
    266: (c)=>airShot(c, true, 8, 10, 90.0, 0x197),
    267: (c)=>airFall(c, true),
    268: (c)=>wave(c, 0x190, 0, false),
    269: (c)=>wave(c, 0x191, 3, true),
    270: state270,
    271: (c)=>nearOpponent(c, false),
    272: (c)=>nearOpponent(c, true),
    273: state273,
    274: state274,
    275: state275,
    276: (c)=>burst438(c, false),
    277: (c)=>burst438(c, true),
    278: state278,
    279: (c)=>state279(c, false),
    280: (c)=>state279(c, true),
    281: state281,
    282: (c)=>airFall(c, false),
    283: (c)=>airFall(c, false)
});
function freeIfOffscreen(c, i) {
    const ch = c.children[i];
    if (ch.x > 700.0 || ch.x < -60.0) {
        c.freeChild(i);
        c.f3148 = 0;
    }
}
function child400(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 1;
        c.a3174[i] = c.a3174[i] + 1;
        ch.vx = 2.5;
    }
    if (ch.hitState > 0 && ch.frame < 0x31) {
        ch.frame = 0x31;
        ch.timer = 0;
        c.f3148 = 0;
        return;
    }
    if (ch.frame > 0x31) {
        ch.vx = ch.vx - 0.06;
        if (ch.vx < 0.3) ch.vx = 0.3;
    }
    freeIfOffscreen(c, i);
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 0x31 && c.a3174[i] < 5) {
            ch.frame = 0x1d;
            c.a3174[i] = c.a3174[i] + 1;
        }
        if (ch.frame === 0x31) c.f3148 = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child401(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 3;
        c.a3174[i] = c.a3174[i] + 1;
        ch.vx = 1.2;
    }
    if (ch.frame > 0x31) {
        ch.vx = ch.vx - 0.02;
        if (ch.vx < 0.3) ch.vx = 0.3;
    }
    if (ch.hitState > 0 && ch.frame < 0x31) {
        c.a3274[i] = c.a3274[i] + 1;
        if (ch.hitsLeft === 0) {
            ch.timer = 0;
            ch.frame = 0x31;
            c.f3148 = 0;
        }
    }
    freeIfOffscreen(c, i);
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (c.a3274[i] > 0x1e) {
            ch.hitState = 0;
            c.a3274[i] = 0;
        }
        if (ch.frame === 0x31 && c.a3174[i] < 7) {
            ch.frame = 0x1d;
            c.a3174[i] = c.a3174[i] + 1;
        }
        if (ch.frame === 0x31) c.f3148 = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child402(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 0x63;
        c.a3174[i] = c.a3174[i] + 1;
        ch.vx = 0.0;
    }
    ch.vx = ch.vx + 0.0025;
    if (ch.hitState > 0) c.a3274[i] = c.a3274[i] + 1;
    freeIfOffscreen(c, i);
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (c.a3274[i] > 0xf) {
            ch.hitState = 0;
            c.a3274[i] = 0;
        }
        if (ch.frame >= childCount) ch.frame = 0;
    }
}
function muzzle(c, i, states, airState) {
    const ch = c.children[i];
    if (ch.frame < 0x1a) {
        ch.x = c.x;
        ch.y = c.y;
    }
    let keep;
    if (states.includes(c.state) || c.state === airState) {
        keep = !(c.state === airState && c.frame < 6);
    } else {
        keep = false;
    }
    if (!keep && ch.frame < 0x1a) {
        ch.timer = 0;
        ch.frame = 0x1a;
        return;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child408(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    if (ch.timer === 0) {
        if (ch.frame === 0) ch.hitsLeft = 1;
        if (ch.frame === 0x12) ch.hitsLeft = 1;
    }
    if (ch.frame > 0x12) {
        c.a3174[i] = c.a3174[i] - 1;
        if (c.a3174[i] <= 0) {
            f.w04 = 0x199;
            const x = Math.trunc(ch.x) + 0x32;
            f.x = x - c.random(0, 100);
            const y = Math.trunc(ch.y) + 0x32;
            f.y = y - c.random(0, 100);
            f.b20 = 2;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
            c.a3174[i] = 0xf;
        }
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 0x10) c.voiceRequest = 4;
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            c.freeChild(i);
            c.f314c = 0;
        }
    }
}
function child409(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
registerChildren({
    400: child400,
    401: child401,
    402: child402,
    403: (c, i)=>muzzle(c, i, [
            0x102
        ], 0x106),
    404: (c, i)=>muzzle(c, i, [
            0x101,
            0x100
        ], 0x107),
    405: (c, i)=>muzzle(c, i, [
            0x103
        ], 0x108),
    406: (c, i)=>muzzle(c, i, [
            0x104
        ], 0x109),
    407: (c, i)=>muzzle(c, i, [
            0x105
        ], 0x10a),
    408: child408,
    409: child409
});
export function tickHookMishio(c) {
    const f = openSpawnFrame();
    if (c.f3168 > 0 && c.f3158 === 3) {
        if (c.state !== 0x13e) c.f3168 = c.f3168 - 1;
        if (c.f3168 <= 0) c.f3158 = 0;
    }
    if (c.f3158 <= 0) return;
    c.f315c = c.f315c - 1;
    if (c.f3158 === 3) {
        c.f3160 = c.f3160 + 1;
        if (c.f3160 > 0x90) c.f3160 = 0;
        if (c.f3160 === 0x12) c.requestFlash(0xd1, 0x1b);
        if (c.f3160 === 0x24) c.requestFlash(0xd0, 0x1b);
        if (c.f3160 === 0x36) c.requestFlash(0xcf, 0x1b);
        if (c.f3160 === 0x48) c.requestFlash(0xb1, 0x1b);
        if (c.f3160 === 0x5a) c.requestFlash(0xcf, 0x1b);
        if (c.f3160 === 0x6c) c.requestFlash(0xd0, 0x1b);
        if (c.f3160 === 0x7e) c.requestFlash(0xd1, 0x1b);
        if (c.f3160 === 0x90) c.requestFlash(0xd2, 0x1b);
    }
    if (c.f315c > 0) return;
    if (c.state >= 0x32 && c.state <= 0x95) return;
    if (c.f3158 === 1) f.w04 = 0x22;
    if (c.f3158 === 2) f.w04 = 0x24;
    if (c.f3158 === 3) {
        if (c.random(0, 100) > 0x32) {
            f.w04 = 0x24;
        } else {
            f.w04 = 0x22;
        }
    }
    const x = Math.trunc(c.x);
    f.x = x + (0x14 - c.random(0, 0x28)) * c.facing;
    const y = Math.trunc(c.y);
    f.y = y - c.random(0, 0x5a);
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
    c.f315c = 2;
}
