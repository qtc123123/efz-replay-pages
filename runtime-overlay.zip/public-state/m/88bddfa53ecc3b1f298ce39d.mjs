import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { CHAR_RESIDUE } from "./b3af6789bdfdda8f4380afef.mjs";
const lo = new Uint8Array(20).fill(1);
const hi = new Uint8Array(20).fill(1);
const unkLo = new Uint8Array(20).fill(1);
const unkHi = new Uint8Array(20).fill(1);
function cell(row, col) {
    return row * 5 + col;
}
function cellAt(off) {
    const rel = off + 0x484;
    return rel >= 0 && rel < 0x50 && (rel & 3) === 0 ? rel >> 2 : -1;
}
function setValue(i, v) {
    if (i < 0) return;
    lo[i] = (v & 0xffff) !== 0 ? 1 : 0;
    hi[i] = (v >>> 16 & 0xffff) !== 0 ? 1 : 0;
    unkLo[i] = 0;
    unkHi[i] = 0;
}
function setPointer(i) {
    setValue(i, 0x00010001);
}
function setWord(i, v) {
    if (i < 0) return;
    lo[i] = (v & 0xffff) !== 0 ? 1 : 0;
    unkLo[i] = 0;
}
function setUnknown(i) {
    if (i < 0) return;
    unkLo[i] = 1;
    unkHi[i] = 1;
}
function setUncertainValue(i, guess) {
    setValue(i, guess);
    unkLo[i] = 1;
    unkHi[i] = 1;
}
function state(i) {
    const nzLo = lo[i] === 1;
    const nzHi = hi[i] === 1;
    if (nzLo && !unkLo[i] || nzHi && !unkHi[i]) return 1;
    if (!unkLo[i] && !unkHi[i]) return nzLo || nzHi ? 1 : 0;
    return nzLo || nzHi ? 3 : 2;
}
function ptrAt(off) {
    setPointer(cellAt(off));
}
function valAt(off, v) {
    setValue(cellAt(off), v);
}
export function residueMatrix(m) {
    for(let i = 0; i < 4; i++){
        for(let j = 0; j < 5; j++)setValue(cell(i, j), m[i][j] ? 0xffffffff : 0);
    }
}
export function residueThrowColumn() {
    for(let i = 0; i < 4; i++)setValue(cell(i, 0), 1);
}
export function residueCell(i, j) {
    return state(cell(i, j));
}
const RENDER_VALUES = [
    0x001af9ac,
    0x77120c30,
    0xfa86656f,
    0xfffffffe,
    0x001af918,
    0x750f0d3f,
    0x04348588,
    0x00000000,
    0x001af924,
    0x77135f9e,
    0x7ffea000,
    0x0000aa64,
    0x77101451,
    0x001af970,
    0x001af974,
    0x77135f9e,
    0x04280048,
    0xffffffff,
    0x04346088,
    0x04280048
];
export function residueRender() {
    for(let i = 0; i < 20; i++)setValue(i, RENDER_VALUES[i]);
    setUncertainValue(cell(0, 1), RENDER_VALUES[1]);
    setUncertainValue(cell(0, 4), RENDER_VALUES[4]);
}
export function residueSound() {
    for(let i = 0; i < 20; i++)setPointer(i);
    setValue(cell(0, 4), 0);
    setUncertainValue(cell(2, 1), 1);
}
export function residueBgmVolume() {
    residueFinishFade(false);
}
export function residueFinishFade(first) {
    if (first) {
        setValue(cell(2, 4), 0);
        setValue(cell(3, 4), 0);
        return;
    }
    for(let i = 0; i < 20; i++)setPointer(i);
    setValue(cell(0, 1), 0);
    setValue(cell(3, 0), 0);
    setValue(cell(3, 4), 0);
}
export function residueUnknownAll(written = false) {
    for(let i = 0; i < 20; i++){
        if (written) setUncertainValue(i, 1);
        else setUnknown(i);
    }
}
function boxFrame(ebp, c) {
    ptrAt(ebp + 4);
    ptrAt(ebp);
    setWord(cellAt(ebp - 4), c.offsetX);
    valAt(ebp - 8, c.b);
    valAt(ebp - 0xc, c.r);
    valAt(ebp - 0x10, c.t);
    valAt(ebp - 0x14, c.l);
    setWord(cellAt(ebp - 0x18), c.offsetY);
    ptrAt(ebp - 0x1c);
    if (c.facingRight) {
        valAt(ebp - 0x20, c.offsetY << 16 >> 16);
        valAt(ebp - 0x24, c.offsetY << 16 >> 16);
        valAt(ebp - 0x28, c.offsetX << 16 >> 16);
        valAt(ebp - 0x2c, c.offsetX << 16 >> 16);
    } else {
        valAt(ebp - 0x30, c.offsetY << 16 >> 16);
        valAt(ebp - 0x34, c.offsetY << 16 >> 16);
        valAt(ebp - 0x38, c.offsetX << 16 >> 16);
        valAt(ebp - 0x3c, c.offsetX << 16 >> 16);
    }
}
export function residue7697d0Untouchable(callsBeingHit, beingHit, untouchable) {
    ptrAt(-0x454);
    ptrAt(-0x458);
    ptrAt(-0x45c);
    if (callsBeingHit) {
        ptrAt(-0x464);
        ptrAt(-0x468);
        ptrAt(-0x46c);
        valAt(-0x470, beingHit ? 1 : 0);
    }
    valAt(-0x460, untouchable ? 1 : 0);
}
export function residue7697d0Boxes(attack, hurt, body) {
    for (const c of [
        ...attack,
        ...hurt,
        body
    ]){
        ptrAt(-0x454);
        ptrAt(-0x458);
        ptrAt(-0x45c);
        boxFrame(-0x464, c);
    }
    ptrAt(-0x454);
    ptrAt(-0x458);
    ptrAt(-0x45c);
    ptrAt(-0x460);
    ptrAt(-0x464);
}
export function residue7697d0Hit() {
    residueUnknownAll(true);
}
export function residue76bd40Entry() {
    ptrAt(-0x474);
}
export function residue76bd40Boxes(lastAttack, lastHurt) {
    valAt(-0x440, lastAttack.l);
    valAt(-0x43c, lastAttack.t);
    valAt(-0x438, lastAttack.r);
    valAt(-0x450, lastHurt.l);
    valAt(-0x44c, lastHurt.t);
    valAt(-0x448, lastHurt.r);
    valAt(-0x444, lastHurt.b);
}
export function residue76bd40Hit() {
    residueUnknownAll(true);
}
export function residueFtolAt3f4(v) {
    ptrAt(-0x438);
    setFtol(v, -0x45c, -0x44c, -0x448, -0x444);
}
function setFtol(v, frac, intLo, intHi, flt) {
    const f = Math.fround(v);
    valAt(flt, f === 0 && !Object.is(f, -0) ? 0 : 1);
    const r = roundHalfEven(v);
    const low = (r % 4294967296 + 4294967296) % 4294967296;
    const high = Math.floor(r / 4294967296) >>> 0;
    valAt(intLo, low);
    valAt(intHi, high);
    if (low !== 0 || (high & 0x7fffffff) !== 0) {
        const d = Math.fround(v - r);
        valAt(frac, d === 0 && !Object.is(d, -0) ? 0 : 1);
    }
}
function roundHalfEven(v) {
    const f = Math.floor(v);
    const d = v - f;
    if (d > 0.5) return f + 1;
    if (d < 0.5) return f;
    return f % 2 === 0 ? f : f + 1;
}
export function residue76b090Hit() {
    residueUnknownAll(true);
}
export function residueStateCode(c, state, skipped) {
    const info = CHAR_RESIDUE[c.id];
    if (!info) return;
    const apply = (list)=>{
        for (const [i, v] of list){
            if (v === 0) setValue(i, 0);
            else if (v === 1) setPointer(i);
            else setUnknown(i);
        }
    };
    apply(info.main.always);
    const m = info.form1 && c.form === 1 ? info.form1 : info.main;
    if (m !== info.main) apply(m.always);
    if (skipped) return;
    apply(m.prefix);
    let mask = 0;
    if (state < m.first || state > m.last) {
        mask = m.default;
    } else {
        for (const [from, to, sm] of m.states){
            if (state >= from && state <= to) {
                mask = sm;
                break;
            }
        }
    }
    mask |= m.prefixUnknown;
    for(let i = 0; i < 20; i++){
        if (mask >> i & 1) setUnknown(i);
    }
}
export function residueChildCode(c, hasChildren) {
    if (hasChildren && (c.id === 0 || c.id === 14 || c.id === 23)) residueUnknownAll();
}
export function residuePattern() {
    let s = "";
    let g = "";
    for(let i = 0; i < 20; i++){
        const v = state(i);
        s += "01??"[v];
        g += "0101"[v];
    }
    return s + " " + g;
}
export function residuePoint(name) {
    globalThis.__stk?.(name, residuePattern());
}

export function __logicState(){return {lo,hi,unkLo,unkHi,RENDER_VALUES};}

export function __installInitialRoots(s){
if(lo!==s["lo"])throw Error('INITIAL_CONST_IDENTITY:lo');
if(hi!==s["hi"])throw Error('INITIAL_CONST_IDENTITY:hi');
if(unkLo!==s["unkLo"])throw Error('INITIAL_CONST_IDENTITY:unkLo');
if(unkHi!==s["unkHi"])throw Error('INITIAL_CONST_IDENTITY:unkHi');
if(RENDER_VALUES!==s["RENDER_VALUES"])throw Error('INITIAL_CONST_IDENTITY:RENDER_VALUES');
}
