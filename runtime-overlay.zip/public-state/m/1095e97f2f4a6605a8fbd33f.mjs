import PUBLIC_IDENTITIES from "./11a102e855d1170b0ca63b17.mjs";
import policy from "./d3bf6d242edb41cf3b92234f.mjs";
import {encodeGraphTo,inspectGraph,validateGraph,validateDocument,decodeGraph,DEFAULT_LIMITS} from "./f1bc7f795b4dedcee2444e70.mjs";
import {validatePublicBattleDocument,publicClassKeys} from "./53f1cc2f52c41342a5e4fc99.mjs";
export const PUBLIC_PROFILE='efz-public-battle/1';
const need=(v,c)=>{if(!v)throw Error('PUBLIC_BATTLE_'+c);};
const sameIdentities=value=>value&&JSON.stringify(Object.fromEntries(Object.entries(value).sort()))===JSON.stringify(Object.fromEntries(Object.entries(PUBLIC_IDENTITIES).sort()));
const admitted=new WeakSet(),installed=new WeakSet(),admissionCache=new WeakMap();
export function projectPublicBattle(port,host,identities){
 const raw=port.snapshot(),h=host.snapshot(),g=raw.gameState;
 const world=Object.fromEntries(policy.worldFields.map(k=>[k,g[k]]));
 const modules=Object.fromEntries(Object.entries(policy.moduleFields).map(([file,fields])=>{const source=raw.modules[file]??raw.modules['src/platform/audio.mjs'];return [file,Object.fromEntries(fields.map(k=>[k,source[k]]))];}));
 return {identities:{...identities},sourceStart:h.completed,selection:{characters:g.chars.map(c=>c.id),palettes:g.chars.map(c=>c.color),stage:g.stage,usePal:[...g.usePal]},world,battle:raw.machine.scenes[3],modules,host:{completed:h.completed,effectOrdinal:h.effectOrdinal,rng:{...h.rng},volume:h.volume}};
}
export function capturePublicBattle(port,host,identities,caps,sink){
 need(sameIdentities(identities),'PRODUCER_IDENTITIES');const raw=port.snapshot(),h=host.snapshot(),b=raw.machine.scenes[3];
 need(raw.scene===3&&raw.gameState.mode===4&&raw.gameState.replayMode===0&&b.enterState===1&&b.exit===0&&b.paused===0,'BOUNDARY');need(h.pending===null&&h.pair===null,'IDLE');caps.assertStable();
 for(const c of raw.gameState.chars)caps.registerClass('Actor:'+c.id+':'+c.side,c);
 if(raw.gameState.stageObject)caps.registerClass('Stage:'+raw.gameState.stageObject.stage,raw.gameState.stageObject);
 try{const value=projectPublicBattle(port,host,identities),info=encodeGraphTo(value,caps,sink);return {profile:PUBLIC_PROFILE,...info,sourceStart:value.sourceStart,identities,selection:value.selection};}finally{caps.finishCapture();}
}
export function admitPublicBattle(bytes,expected,hashBytes,caps){
 need(sameIdentities(expected.identities),'RECEIVER_IDENTITIES');need(expected.profile===PUBLIC_PROFILE&&bytes.length===expected.byteLength&&bytes.length<=DEFAULT_LIMITS.maxBytes,'DESCRIPTOR');need(typeof hashBytes==='function'&&/^[0-9a-f]{64}$/.test(expected.sha256)&&hashBytes(bytes)===expected.sha256,'DIGEST');
 const cacheKey=JSON.stringify([expected.sha256,expected.sourceStart,expected.identities,expected.selection,expected.nodes]);const cached=admissionCache.get(bytes);if(cached?.caps===caps&&cached.key===cacheKey)return cached.result;
 const doc=inspectGraph(bytes),semantic=validatePublicBattleDocument(doc,expected.identities);need(semantic.sourceStart===expected.sourceStart,'SOURCE_START');if(expected.nodes!==undefined)need(expected.nodes===doc.nodes.length,'NODE_COUNT');if(expected.selection!==undefined)need(JSON.stringify(Object.fromEntries(Object.entries(semantic.selection).sort()))===JSON.stringify(Object.fromEntries(Object.entries(expected.selection).sort())),'SELECTION');
 const checked=validateDocument(doc,{...caps,checkType:(type,keys)=>JSON.stringify(publicClassKeys(type))===JSON.stringify(keys)});
 const result={doc:checked,...semantic};admitted.add(result);admissionCache.set(bytes,{caps,key:cacheKey,result});return result;
}
export async function preparePublicFactories(port,caps,inspection,{createCharacter,createStageObject,preload}){
 need(admitted.has(inspection)&&port.phase()===0,'ADMISSION_REQUIRED');await preload(inspection.resourceIds);
 for(const type of new Set(inspection.doc.nodes.filter(n=>n.kind==='class').map(n=>n.type))){if(type.startsWith('Actor:')){const [,id,side]=type.split(':');const c=createCharacter(Number(id),Number(side));c.load();caps.registerClass(type,c);}else if(type.startsWith('Stage:'))caps.registerClass(type,createStageObject(Number(type.slice(6))));else need(caps.classObjects.has(type),'CLASS');}
}
export function installPublicBattle(port,host,bytes,expected,caps,hashBytes){
 need(!installed.has(port)&&port.phase()===0&&host.snapshot().completed===0,'FRESH_ONCE');const inspection=admitPublicBattle(bytes,expected,hashBytes,caps);caps.assertStable();
 // Capability/type existence is checked again after trusted factories load.
 const doc=validateDocument(inspection.doc,caps),anchors=new Map(),reverse=new Map();
 const prop=(t,k)=>{const v=doc.nodes[t[1]].props.find(e=>e[0]===k);need(v,'FIELD');return v[1];};
 function anchor(t,v){need(t[0]==='ref','ANCHOR_REF');if(anchors.has(t[1])){need(anchors.get(t[1])===v,'ANCHOR_ALIAS');return;}need(!reverse.has(v),'ANCHOR_ALIAS');anchors.set(t[1],v);reverse.set(v,t[1]);const n=doc.nodes[t[1]];if(n.kind==='view'){need(ArrayBuffer.isView(v)&&v.constructor.name===n.type&&v.length===n.length&&v.byteOffset===n.offset,'ANCHOR_VIEW');anchor(n.buffer,v.buffer);}else if(n.kind==='buffer')need(v.byteLength===n.bytes.length,'ANCHOR_BUFFER');}
 const mods=prop(doc.root,'modules');for(const {file,key,value}of caps.rootAnchors()){const canonical=file==='src/platform/audio.mjs'?'src/game/sound_events.mjs':file;if(policy.moduleFields[canonical]?.includes(key))anchor(prop(prop(mods,canonical),key),value);}
 for(let i=0;i<doc.nodes.length;i++){const n=doc.nodes[i];if(n.kind==='class')anchor(['ref',i],caps.classObjects.get(n.type).obj);}
 installed.add(port);port.__beginBattleInstall();try{const decoded=decodeGraph(doc,caps,anchors);port.__installBattleRoots(decoded.world,decoded.battle,decoded.modules,decoded.selection);host.install({started:true,pending:null,pair:null,events:[],renders:0,waits:0,...decoded.host});port.__finishBattleInstall();admissionCache.delete(bytes);return {sourceStart:decoded.sourceStart,selection:decoded.selection};}catch(e){port.__failBattleInstall();throw e;}
}
