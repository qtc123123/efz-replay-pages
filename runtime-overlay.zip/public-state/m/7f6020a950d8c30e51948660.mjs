import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { readSync } from "./197efe2647ca25903d217eb5.mjs";
const STORAGE_KEY = "efz.key.ini";
let data = null;
export function loadKeyIni() {
    const original = readSync("key.ini");
    data = original ? original.slice() : null;
    if (!data) return;
    try {
        const saved = __session.storage.getItem(STORAGE_KEY);
        if (saved) {
            const bytes = Uint8Array.from(atob(saved), (c)=>c.charCodeAt(0));
            if (bytes.length === data.length) data = bytes;
        }
    } catch  {}
}
export function keyIniData() {
    return data && data.length >= 0x20 ? data : null;
}
export function readKeyIniByte(idx) {
    const d = keyIniData();
    return d ? d[idx] ?? 0 : 0;
}
export function writeKeyIniByte(idx, value) {
    const d = keyIniData();
    if (!d || idx >= d.length) return;
    d[idx] = value & 0xff;
    try {
        __session.storage.setItem(STORAGE_KEY, btoa(String.fromCharCode(...d)));
    } catch  {}
}

export function __logicState(){return {data};}

export function __installInitialRoots(s){
data=s["data"];
}
