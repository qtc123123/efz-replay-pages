import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { HISTORY_LENGTH, NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
function hist(c, i) {
    return c.history[i - (i >= HISTORY_LENGTH ? 1 : 0) * HISTORY_LENGTH];
}
function buttonCommand(base, v) {
    return base + ((v & 0xe0) > 0 ? 1 : 0) + ((v & 0xc0) > 0 ? 1 : 0) + ((v & 0x80) > 0 ? 1 : 0);
}
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function cancelable(c) {
    return ((c.currentHit()?.defenseFlags ?? 0) & 8) > 0;
}
function priorityOk(c, target) {
    return (c.patterns[c.state]?.hdrB ?? 0) <= (c.patterns[target]?.hdrA ?? 0);
}
function cancelOk(c) {
    if (c.state >= 200 && c.d168 >= 2 && c.d168 !== 6) return true;
    return c.state < 200;
}
function rfOk(c) {
    return c.rfGauge >= 500.0 || c.rfBlue > 0;
}
function enter(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function moveOk(c, target) {
    return cancelable(c) && cancelOk(c) && priorityOk(c, target);
}
function crouching(c) {
    return c.inputY === 1 || (c.bufferedA & 4) !== 0 || (c.bufferedB & 4) !== 0;
}
function standing(c) {
    return c.inputY === 0 || (c.bufferedA & 4) === 0 || (c.bufferedB & 4) === 0;
}
function opponentThrowable(c) {
    return c.opponent.state < 50 || c.opponent.state > 156;
}
function buttonDown(c, k) {
    const bit = 0x10 << k;
    return c.pressed[k] === 1 || (c.bufferedA & bit) !== 0 || (c.bufferedB & bit) !== 0;
}
function within(c, d) {
    return c.x - c.opponent.x > -d && c.x - c.opponent.x < d;
}
function dashForward(c, dir) {
    const dx = c.opponent.x - c.x;
    return dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1;
}
function dashBackward(c, dir) {
    const dx = c.opponent.x - c.x;
    return dx * dir > 0.0 || dx === 0.0 && c.facing === dir;
}
export function parseCommandMio(c) {
    c.command = NO_COMMAND;
    const idx = c.historyIndex;
    const end = idx + HISTORY_LENGTH;
    const left = c.facing === -1 ? 1 : 0;
    const BACK = 2 - left;
    const FWD = 1 + left;
    const DOWN_BACK = 6 - left;
    const DOWN_FWD = 5 + left;
    let step;
    let v;
    step = 0;
    for(let i = idx + 0x2d; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 5) {
            c.command = 94;
            return;
        }
        if (v & 0x10 && step === 4) step = 5;
        if (v & 0xe0 && step === 4) break;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if (v & 0xe0 && step === 2) break;
        if (v & 0x10 && step === 2) step = 3;
        if (v === 0 && step === 1) step = 2;
        if (v & 0xd0 && step === 1) break;
        if (v & 0x20 && step === 0 && c.meter === 3000 && c.f3150 === 1) step = 1;
    }
    step = 0;
    for(let i = idx + 0x69; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 4) {
            c.command = buttonCommand(0x78, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 3) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x78, v);
                return;
            }
            step = 4;
        }
        if ((v & 0xf) === DOWN_BACK && step === 2) step = 3;
        if ((v & 0xf) === BACK && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0 && c.meter === 3000 && c.f3150 === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x6e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x6e, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_BACK && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x64, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x64, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_FWD && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x14, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x14, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0 && c.f3150 === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x28, v);
            return;
        }
        if ((v & 0xf) === 4 && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x28, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0 && c.f3150 === 1) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x1e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x1e, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0xaf; i < end; i++){
        v = hist(c, i);
        if (v & 8 && step === 1) {
            c.command = 6;
            return;
        }
        if (!(v & 8) && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 4) {
            c.command = 53;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0 && c.state === 96) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 4) {
            c.command = 52;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 4) {
            c.command = 51;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 4) {
            c.command = 50;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 1 && step === 3) {
            c.command = 1;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 1 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 2 && step === 3) {
            c.command = 0;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 2 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
}
export function dispatchMovesMio(c) {
    if (c.state < 200) c.bufferedA = 0;
    if (c.bufferTimer > 0) {
        c.bufferTimer = c.bufferTimer - 1 & 0xff;
    } else {
        c.bufferedB = 0;
    }
    if (c.bufferedB === 0) c.bufferTimer = 0;
    if (c.command === 52 && (c.rfGauge >= 500.0 && c.d168 > 1 || c.rfBlue > 0 && c.d168 > 1 && c.d168 !== 6) && cancelable(c) && priorityOk(c, 167)) {
        enter(c, 167);
        if (c.y < 0.0) c.state = 171;
        return;
    }
    if (c.f3150 === 0) {
        if (dispatchStance0(c)) return;
    }
    if (c.f3150 === 1) {
        if (dispatchStance1(c)) return;
    }
    if (c.d15c < 2 && buttonDown(c, 3)) {
        if (c.state !== 224 && priorityOk(c, 270) && cancelable(c) && c.y === 0.0 && cancelOk(c)) {
            enter(c, 270);
            return;
        }
        if (c.f3150 === 1 && c.y < -30.0 && priorityOk(c, 17) && cancelable(c) && c.y < 0.0 && cancelOk(c)) {
            enter(c, 17);
        }
    }
}
function dispatchStance0(c) {
    if (c.d15c < 2) {
        if (c.life < 3333 && c.command === 122 && c.meter >= 3000 && c.y === 0.0 && moveOk(c, 315)) {
            enter(c, 315);
            return true;
        }
        if (c.command === 112 && c.meter >= 3000 && c.y === 0.0 && moveOk(c, 311)) {
            enter(c, 311);
            return true;
        }
        if ((c.command === 111 || c.command === 112) && c.meter >= 2000 && c.y === 0.0 && moveOk(c, 310)) {
            enter(c, 310);
            return true;
        }
        if ((c.command === 110 || c.command === 111 || c.command === 112) && c.meter >= 1000 && c.y === 0.0 && moveOk(c, 309)) {
            enter(c, 309);
            return true;
        }
        if (c.command === 102 && c.meter >= 3000 && c.y === 0.0 && moveOk(c, 305)) {
            enter(c, 305);
            return true;
        }
        if ((c.command === 101 || c.command === 102) && c.meter >= 2000 && c.y === 0.0 && moveOk(c, 304)) {
            enter(c, 304);
            return true;
        }
        if ((c.command === 100 || c.command === 101 || c.command === 102) && c.meter >= 1000 && c.y === 0.0 && moveOk(c, 303)) {
            enter(c, 303);
            return true;
        }
        if (c.command === 22 && rfOk(c) && c.y === 0.0 && moveOk(c, 252)) {
            enter(c, 252);
            return true;
        }
        if ((c.command === 21 || c.command === 22) && c.y === 0.0 && moveOk(c, 251)) {
            enter(c, 251);
            return true;
        }
        if (c.command === 20 && c.y === 0.0 && moveOk(c, 250)) {
            enter(c, 250);
            return true;
        }
        if (c.command === 32 && rfOk(c) && c.y === 0.0 && moveOk(c, 260)) {
            enter(c, 260);
            return true;
        }
        if ((c.command === 31 || c.command === 32) && c.y === 0.0 && moveOk(c, 259)) {
            enter(c, 259);
            return true;
        }
        if (c.command === 30 && c.y === 0.0 && moveOk(c, 258)) {
            enter(c, 258);
            return true;
        }
        if (c.command === 12 && rfOk(c) && c.y === 0.0 && moveOk(c, 255)) {
            enter(c, 255);
            return true;
        }
        if ((c.command === 11 || c.command === 12) && c.y === 0.0 && moveOk(c, 271)) {
            enter(c, 271);
            return true;
        }
        if (c.command === 10 && c.y === 0.0 && moveOk(c, 254)) {
            enter(c, 254);
            return true;
        }
    }
    if (c.d15c < 1 && (c.command === 0 || c.command === 1)) {
        const dir = 1 - (c.command << 1);
        if (c.y < 0.0 && c.b159 < 1) {
            if (dashForward(c, dir) && priorityOk(c, 165) && c.state !== 170 && c.y < -40.0 && cancelable(c) && cancelOk(c)) {
                airDash(c, 165);
                c.frame = 3;
                return true;
            }
            if (dashBackward(c, dir) && priorityOk(c, 166) && c.state !== 170 && cancelable(c) && cancelOk(c)) {
                airDash(c, 166);
                c.frame = 3;
                return true;
            }
        }
        if (c.y === 0.0 && cancelable(c)) {
            if (dashForward(c, dir) && priorityOk(c, 163) && cancelOk(c)) {
                groundDash(c, 163);
                return true;
            }
            if (dashBackward(c, dir) && priorityOk(c, 164) && cancelOk(c)) {
                groundDash(c, 164);
                return true;
            }
        }
    }
    if (c.d15c < 3 && c.command === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && cancelOk(c) && priorityOk(c, 14)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.faceOpponent();
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return true;
    }
    if (buttonDown(c, 0)) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 230);
            if (c.inputY === 1) c.state = 233;
            return true;
        }
        if (c.y < 0.0) {
            if (moveOk(c, 207)) enter(c, 207);
            return true;
        }
        if (crouching(c) && moveOk(c, 204)) {
            enter(c, 204);
            return true;
        }
        if (standing(c) && moveOk(c, 200)) {
            enter(c, 200);
            return true;
        }
    }
    if (buttonDown(c, 1)) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 231);
            if (c.inputY === 1) c.state = 234;
            return true;
        }
        if (c.y < 0.0) {
            if (moveOk(c, 208)) enter(c, 208);
            return true;
        }
        if (crouching(c) && moveOk(c, 205)) {
            enter(c, 205);
            return true;
        }
        if (standing(c)) {
            if (priorityOk(c, 201) && cancelable(c) && within(c, 70.0) && cancelOk(c)) {
                enter(c, 201);
                return true;
            }
            if (moveOk(c, 202)) {
                enter(c, 202);
                return true;
            }
        }
    }
    if (buttonDown(c, 2)) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 232);
            if (c.inputY === 1) c.state = 235;
            return true;
        }
        if (c.y < 0.0) {
            if (c.inputX === c.facing && c.inputY === 0 && within(c, 100.0) && c.opponent.y < 0.0 && priorityOk(c, 248) && opponentThrowable(c) && cancelable(c) && cancelOk(c)) {
                enter(c, 248);
                return true;
            }
            if (priorityOk(c, 223) && cancelable(c) && cancelOk(c) && c.inputY === 1) {
                enter(c, 223);
            }
            if (priorityOk(c, 209) && cancelable(c) && cancelOk(c)) {
                enter(c, 209);
            }
            return true;
        }
        if (crouching(c) && moveOk(c, 206)) {
            enter(c, 206);
            return true;
        }
        if (standing(c)) {
            if (c.inputX !== 0 && c.opponent.y === 0.0 && within(c, 30.0) && priorityOk(c, 220) && opponentThrowable(c) && cancelable(c) && cancelOk(c)) {
                enter(c, 220);
                return true;
            }
            if (priorityOk(c, 225) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 225);
                return true;
            }
            if (moveOk(c, 203)) {
                enter(c, 203);
                return true;
            }
        }
    }
    return false;
}
function dispatchStance1(c) {
    if (c.d15c < 2) {
        if (c.life < 3333 && c.command === 94 && c.meter >= 3000 && cancelable(c) && c.y === 0.0 && c.d168 !== 6 && priorityOk(c, 330)) {
            enter(c, 330);
            return true;
        }
        if (c.command === 112 && c.meter >= 3000 && c.y === 0.0 && moveOk(c, 314)) {
            enter(c, 314);
            return true;
        }
        if ((c.command === 111 || c.command === 112) && c.meter >= 2000 && c.y === 0.0 && moveOk(c, 313)) {
            enter(c, 313);
            return true;
        }
        if ((c.command === 110 || c.command === 111 || c.command === 112) && c.meter >= 1000 && c.y === 0.0 && moveOk(c, 312)) {
            enter(c, 312);
            return true;
        }
        if (c.command === 102 && c.meter >= 3000 && moveOk(c, 308)) {
            enter(c, 308);
            if (c.y < 0.0) c.frame = 3;
            return true;
        }
        if ((c.command === 101 || c.command === 102) && c.meter >= 2000 && moveOk(c, 307)) {
            enter(c, 307);
            if (c.y < 0.0) c.frame = 3;
            return true;
        }
        if ((c.command === 100 || c.command === 101 || c.command === 102) && c.meter >= 1000 && moveOk(c, 306)) {
            enter(c, 306);
            if (c.y < 0.0) c.frame = 3;
            return true;
        }
        if (c.command === 32 && c.y === 0.0 && moveOk(c, 269)) {
            enter(c, 269);
            return true;
        }
        if (c.command === 31 && c.y === 0.0 && moveOk(c, 268)) {
            enter(c, 268);
            return true;
        }
        if (c.command === 30 && c.y === 0.0 && moveOk(c, 267)) {
            enter(c, 267);
            return true;
        }
        if (c.command === 12 && rfOk(c) && c.y === 0.0 && moveOk(c, 266)) {
            enter(c, 266);
            return true;
        }
        if ((c.command === 11 || c.command === 12) && c.y === 0.0 && moveOk(c, 265)) {
            enter(c, 265);
            return true;
        }
        if (c.command === 10 && c.y === 0.0 && moveOk(c, 264)) {
            enter(c, 264);
            return true;
        }
        if (c.command === 42 && rfOk(c) && moveOk(c, 263)) {
            enter(c, 263);
            if (c.y < 0.0) {
                c.frame = 3;
                c.f3138 = 100;
            }
            return true;
        }
        if ((c.command === 41 || c.command === 42) && moveOk(c, 262)) {
            enter(c, 262);
            if (c.y < 0.0) c.frame = 3;
            return true;
        }
        if (c.command === 40 && moveOk(c, 261)) {
            enter(c, 261);
            if (c.y < 0.0) c.frame = 3;
            return true;
        }
    }
    if (c.d15c < 1 && (c.command === 0 || c.command === 1)) {
        const dir = 1 - (c.command << 1);
        if (c.y < 0.0 && c.b159 < 2) {
            if (dashForward(c, dir) && priorityOk(c, 165) && c.state !== 170 && c.y < -40.0 && cancelable(c) && cancelOk(c)) {
                airDash(c, 165);
                return true;
            }
            if (dashBackward(c, dir) && priorityOk(c, 166) && c.state !== 170 && cancelable(c) && cancelOk(c)) {
                airDash(c, 166);
                return true;
            }
        }
        if (c.y === 0.0 && cancelable(c)) {
            if (dashForward(c, dir) && priorityOk(c, 163) && cancelOk(c)) {
                groundDash(c, 163);
                return true;
            }
            if (dashBackward(c, dir) && priorityOk(c, 164) && cancelOk(c)) {
                groundDash(c, 164);
                return true;
            }
        }
    }
    if (c.d15c < 3 && c.command === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && cancelOk(c) && priorityOk(c, 14)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return true;
    }
    if (buttonDown(c, 0)) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 236);
            if (c.inputY === 1) c.state = 239;
            return true;
        }
        if (c.y < 0.0) {
            if (moveOk(c, 217)) enter(c, 217);
            return true;
        }
        if (crouching(c) && priorityOk(c, 243) && cancelable(c) && within(c, 60.0) && cancelOk(c)) {
            enter(c, 243);
            return true;
        }
        if (crouching(c) && moveOk(c, 214)) {
            enter(c, 214);
            return true;
        }
        if (standing(c)) {
            if (priorityOk(c, 242) && cancelable(c) && within(c, 60.0) && cancelOk(c)) {
                enter(c, 242);
                return true;
            }
            if (moveOk(c, 210)) {
                enter(c, 210);
                return true;
            }
        }
    }
    if (buttonDown(c, 1)) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 237);
            if (c.inputY === 1) c.state = 240;
            return true;
        }
        if (c.y < 0.0) {
            if (c.inputY === 1 && moveOk(c, 227)) {
                enter(c, 227);
                return true;
            }
            if (moveOk(c, 218)) enter(c, 218);
            return true;
        }
        if (crouching(c) && moveOk(c, 215)) {
            enter(c, 215);
            return true;
        }
        if (standing(c)) {
            if (c.inputX === -c.facing && moveOk(c, 228)) {
                enter(c, 228);
                return true;
            }
            if (priorityOk(c, 211) && cancelable(c) && within(c, 70.0) && cancelOk(c)) {
                enter(c, 211);
                return true;
            }
            if (moveOk(c, 211)) {
                enter(c, 211);
                return true;
            }
        }
    }
    if (buttonDown(c, 2)) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 238);
            if (c.inputY === 1) c.state = 241;
            return true;
        }
        if (c.y < 0.0) {
            if (c.inputX === c.facing && c.inputY === 0 && within(c, 100.0) && c.opponent.y < 0.0 && priorityOk(c, 248) && opponentThrowable(c) && cancelable(c) && cancelOk(c)) {
                enter(c, 247);
                return true;
            }
            if (c.inputY === 1 && priorityOk(c, 229) && cancelable(c) && cancelOk(c)) {
                enter(c, 229);
            }
            if (priorityOk(c, 219) && cancelable(c) && cancelOk(c)) {
                enter(c, 219);
            }
            return true;
        }
        if (crouching(c) && moveOk(c, 216)) {
            enter(c, 216);
            return true;
        }
        if (standing(c)) {
            if (c.inputX !== 0 && c.opponent.y === 0.0 && within(c, 30.0) && priorityOk(c, 220) && opponentThrowable(c) && cancelable(c) && cancelOk(c)) {
                enter(c, 220);
                return true;
            }
            if (moveOk(c, 213)) {
                enter(c, 213);
                return true;
            }
        }
    }
    return false;
}
function airDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    c.b159 = c.b159 + 1 & 0xff;
    c.b15a = c.b15a + 1 & 0xff;
    c.bufferedA = 0;
}
function groundDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    if (s === 163) c.b158 = c.b158 + 1 & 0xff;
    c.bufferedA = 0;
}
