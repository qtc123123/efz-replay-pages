import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { registerChildren, registerStates } from "./4bfdef0d515a63cf0e27cdb5.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./7d17e301343a90178a9cad8e.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
function stepFrame(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    return true;
}
function superEffect(c, d, offX, offY) {
    d.w04 = 0x46;
    d.b2c = 0x40;
    d.x = ftol(c.x) + c.facing * offX;
    d.y = ftol(c.y) - offY;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function state300(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.freeze = 0xc6;
        c.meter = s16(c.meter - 0xbb8);
        c.superDarken(0xb0, 3);
        superEffect(c, d, 0x1d, 0x3f);
        c.w16c = 0x63;
        c.seRequest = 0x25;
    }
    if (c.frame > 2) c.showAltBackground(0xf);
    if (c.frame === 7 && c.timer === 0) {
        d.w04 = 0x19f;
        d.x = c.x - c.facing * 0x23;
        d.y = c.y - 67.0;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 0;
        d.b2c = 0xff;
        d.d30 = 1;
        d.d00 = 1;
        frameChild(c, d);
    }
    if (c.frame > 3) c.biasCameraY(0x32, 3);
    if (c.frame === 0xd && c.timer === 0) c.voiceRequest = 5;
    if (c.frame > 0xd && c.frame < 0x11) {
        c.f313c++;
        const r = c.random(0, 0x64);
        if (c.f313c * 0.08 + 60.0 < r) {
            d.w04 = 0x1a1;
            d.b21 = 1;
            d.d00 = 1;
            if (c.random(0, 0x64) > 0x32) {
                d.w04 = 0x1a0;
                d.b21 = 0;
            }
            d.x = c.x - c.facing * 0x12c;
            d.y = c.random(0, 0x140) - 0x140;
            d.b18 = c.facing;
            d.b20 = 2;
            frameChild(c, d);
        }
    }
    if (!stepFrame(c, dur)) return;
    if (c.f3138 < 0xd && c.frame === 0x11) {
        c.frame -= 3;
        c.f3138++;
        return;
    }
    if (c.frame >= cnt) {
        c.faceOpponent();
        c.onStateChange();
        c.state = 0;
        if (c.y < 0.0) {
            c.state = 9;
            c.ay = 0.035;
        }
    }
}
function state303(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.f3138 = 0xa;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.freeze = 0x78;
        c.meter = s16(c.meter - 0xbb8);
        c.superDarken(0xb0, 3);
        superEffect(c, d, 0, 0x28);
        c.w16c = 0x63;
    }
    if (c.frame > 6 && c.frame < 0xc) c.biasCameraY(0x32, 3);
    if (c.frame === 8 && c.timer === 0) {
        c.shakeScreen(3, 0x14);
        d.w04 = 0x1a2;
        d.x = c.x + 0.0 - 30.0;
        d.y = c.y;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        frameChild(c, d);
        d.x = c.x - c.facing * 0x28 - 30.0;
        d.b18 = -c.facing;
        frameChild(c, d);
        c.seRequest = 0x12;
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 0xd && c.f3138 > 0) {
        c.frame -= 2;
        c.f3138--;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state306(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.035;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.freeze = 0x78;
        c.meter = s16(c.meter - 0xbb8);
        c.superDarken(0xb0, 0x21);
        superEffect(c, d, 0, 0x28);
    }
    if (c.frame > 6 && c.frame < 0xc) c.biasCameraY(0x32, 3);
    if (c.frame === 8 && c.timer === 0) {
        d.w04 = 0x1aa;
        d.x = c.x;
        d.y = c.y;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        frameChild(c, d);
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame >= cnt) {
        c.state = 9;
        c.faceOpponent();
        c.onStateChange();
    }
}
function spawn309Body(c, d, pat) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 1;
    d.d00 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function spawn309Fixed(c, d, pat, layer) {
    d.w04 = pat;
    d.x = 0.0;
    d.y = 0.0;
    d.b20 = 2;
    d.b21 = layer;
    d.d00 = 1;
    d.d24 = 1;
    d.b18 = 1;
    d.d30 = 1;
    frameChild(c, d);
}
function state309(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 4 && c.timer === 0) {
        c.freeze = 0x78;
        c.meter = s16(c.meter - 0xbb8);
        c.superDarken(0xb0, 3);
        superEffect(c, d, 0, 0x28);
        d.w04 = 0x47;
        frameEffect(d);
        c.w16c = 0x63;
    }
    if (c.frame === 5 && c.timer === 0) spawn309Body(c, d, 0x1b2);
    if (c.frame === 0x10 && c.timer === 0) spawn309Body(c, d, 0x1b3);
    if ((c.frame === 8 || c.frame === 0x12) && c.d168 === 3) o.hitstop = 0x10e;
    if (c.frame === 0x20 && c.timer === 0) {
        spawn309Body(c, d, 0x1b0);
        o.w140 = 0x7530;
    }
    if (c.frame === 0x2c && c.timer === 0) {
        c.freeze = 0x23a;
        c.superDarken(0xb0, 0xbb8);
        d.w04 = 9;
        d.b2c = 5;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x28;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        c.w16c = 0x63;
        o.x = c.x;
        c.voiceRequest = 0xa;
        gs.specialTimerE = 0x7530;
    }
    if (c.frame === 0x33 && c.timer === 0) {
        c.vy = -7.5;
        c.ay = 0.035;
        spawn309Fixed(c, d, 0x1b4, 0);
        spawn309Fixed(c, d, 0x1b5, 0);
        spawn309Fixed(c, d, 0x1b6, 1);
        c.voiceRequest = 0xb;
    }
    if (c.frame === 0x35 && c.d168 === 3) {
        c.timer = 0;
        c.frame = 0x36;
        o.hitstop = 0xbb8;
        c.vy = -0.05;
        c.ay = 0.0;
        c.superDarken(0xb0, 3);
        c.voiceRequest = 0xc;
        d.w04 = 0x1b7;
        d.x = c.x;
        d.y = c.y - 160.0;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = 1;
        d.d30 = 1;
        frameChild(c, d);
        gs.specialTimerE = 0;
    }
    if (c.frame === 0x37 && c.timer === 0) {
        c.vy = -7.0;
        c.ay = 0.03;
        d.w04 = 0x1c0;
        d.x = c.x;
        d.y = c.y - 150.0;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = 1;
        d.d30 = 1;
        frameChild(c, d);
        d.x = c.x + 40.0;
        d.y = c.y - 140.0;
        frameChild(c, d);
        d.x = c.x - 50.0;
        d.y = c.y - 150.0;
        frameChild(c, d);
        d.w04 = 0x1b8;
        d.x = c.x;
        d.y = c.y - 150.0;
        frameChild(c, d);
    }
    if (c.frame === 0x37 && c.d168 === 3) o.w140 = 0;
    if (c.frame > 0 && c.frame < 0x37) c.biasCameraY(0x32, 3);
    if (c.frame > 0x25 && c.frame < 0x37) c.biasCamera(0x32, 3);
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.frame === 0x35 && c.vy > 1.0) c.vy = 1.0;
    if (c.frame > 0x37 && c.y + c.vy > 0.0) {
        c.stopMotion();
        c.onStateChange();
        c.y = 0.0;
        c.state = 0xd;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame < 0x12 || c.frame === 0x23 || c.frame > 0x32) c.d168 = 0;
    if (c.frame === 0xe && c.f3138 > 0) {
        c.frame -= 2;
        c.f3138--;
    }
    if (c.frame === 0x1b && (c.d168 !== 3 || o.life <= 0)) {
        c.onStateChange();
        c.faceOpponent();
        c.state = 0;
        return;
    }
    if (c.frame === 0x24 && c.d168 !== 3) {
        c.onStateChange();
        c.state = 0x136;
    }
    if (c.frame === 0x2b) {
        d.w04 = 0x1b1;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = c.facing;
        d.d30 = 1;
        frameChild(c, d);
    }
    if (c.frame === 0x35) c.voiceRequest = 9;
    if (c.frame === 0x36) c.frame -= 1;
    if (c.frame >= cnt) c.frame -= 2;
}
function state310(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
registerStates({
    300: state300,
    303: state303,
    306: state306,
    309: state309,
    310: state310
});
function childAdvance(c, i) {
    const ch = c.children[i];
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return ch.frame >= childCount;
}
function child415(c, i, kind) {
    const ch = c.children[i];
    if (c.a3154[i] === 0) {
        ch.hitsLeft = 1;
        c.a3154[i]++;
        if (kind === 0) {
            ch.vx = -3.0;
            ch.vy = 0.5;
        } else {
            ch.vx = c.random(0, 0x64) * 0.01 + (kind === 1 ? 1.0 : 3.5);
            ch.ay = c.random(0, 0x64) * (kind === 1 ? 0.0002 : 0.00015);
            ch.vy = 0.5;
            ch.frame = c.random(0, 0xf);
        }
    }
    ch.vy = ch.vy - ch.ay;
    ch.timer++;
    if (ch.x > 680.0 && ch.facing === 1 || ch.x < -60.0 && ch.facing === -1 || ch.y < -320.0) {
        c.freeChild(i);
        return;
    }
    if (childAdvance(c, i)) ch.frame = 0;
}
function child418(c, i) {
    const ch = c.children[i];
    if (c.state === 0x12f) ch.x = ch.facing * 0xa + c.x + 0.0;
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame === 9 && c.frame < 0xd && c.state === 0x12f) ch.frame -= 2;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childFollow(c, i, owner) {
    const ch = c.children[i];
    if (c.state !== owner) c.freeChild(i);
    ch.x = c.x;
    ch.y = c.y;
    ch.timer++;
    if (c.state === owner && c.hitstop > 0) ch.timer--;
    if (childAdvance(c, i)) c.freeChild(i);
}
function child426(c, i) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y;
    if (ch.frame === 0) ch.hitsLeft = 1;
    ch.timer++;
    if (childAdvance(c, i)) c.freeChild(i);
}
function child433(c, i) {
    const ch = c.children[i];
    if (c.state !== 0x135) c.freeChild(i);
    ch.drawWhileFrozen = 0x7530;
    ch.x = c.x;
    ch.y = c.y;
    ch.timer++;
    if (c.frame === 0x37 && ch.frame < 0x50) {
        ch.timer = 0;
        ch.frame = 0x50;
        return;
    }
    if (c.frame > 0x37) {
        c.freeChild(i);
        return;
    }
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame === 0x50 && c.frame < 0x37) ch.frame = 0x38;
    if (ch.frame >= childCount) ch.frame = 0x6c;
}
function child436(c, i) {
    const ch = c.children[i];
    ch.drawWhileFrozen = 0x7530;
    if (c.state !== 0x135 || c.frame > 0x35) c.freeChild(i);
    ch.timer++;
    if (childAdvance(c, i)) ch.frame = 0;
}
function child439(c, i) {
    const ch = c.children[i];
    if (c.state !== 0x135 || c.frame > 0x36) c.freeChild(i);
    c.a3154[i]++;
    const table = [
        [
            0x96,
            0x1ba
        ],
        [
            0xd2,
            0x1bb
        ],
        [
            0x10e,
            0x1bc
        ],
        [
            0x12c,
            0x1bd
        ],
        [
            0x14a,
            0x1be
        ],
        [
            0x153,
            0x1bf
        ]
    ];
    for (const [t, pat] of table){
        if (c.a3154[i] === t) {
            const d = childSpawnFrame;
            d.w04 = pat;
            d.x = ch.x;
            d.y = ch.y;
            d.b20 = 2;
            d.b21 = 1;
            d.d00 = 1;
            d.b18 = 1;
            d.d30 = 1;
            frameChild(c, d);
        }
    }
    ch.timer++;
    if (childAdvance(c, i)) ch.frame = 0;
}
function childOnce(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (childAdvance(c, i)) c.freeChild(i);
}
function child442(c, i) {
    const ch = c.children[i];
    if (c.state !== 0x135 || c.frame > 0x36) c.freeChild(i);
    ch.timer++;
    if (childAdvance(c, i)) ch.frame -= 2;
}
function coin() {
    return rand("src/game/chars/kanna/states_supers.ts:679:8", {
        consumer: "src/game/chars/kanna/states_supers.ts"
    }) > 0x3e80 ? 1 : 0;
}
function child495(c, i) {
    const ch = c.children[i];
    ch.vx = -0.02;
    ch.drawWhileFrozen = 0x7530;
    ch.timer++;
    if (c.state !== 0x57) c.freeChild(i);
    if (childAdvance(c, i)) ch.frame = 0;
}
function child496(c, i) {
    const ch = c.children[i];
    const s = c.state;
    const inStates = s === 0x53 || s === 0x54 || s === 0x55 || s === 0x56;
    const burst = !inStates || (s === 0x53 || s === 0x54) && c.frame > 1;
    if (burst) {
        const f = childSpawnFrame;
        const pieces = [
            [
                0x1f1,
                23,
                -4
            ],
            [
                0x1f1,
                -4,
                -6
            ],
            [
                0x1f1,
                -14,
                -26
            ],
            [
                0x1f1,
                0,
                0
            ],
            [
                0x1f1,
                30,
                -40
            ],
            [
                0x1f1,
                -25,
                -80
            ],
            [
                0x1f2,
                -35,
                -42
            ],
            [
                0x1f2,
                -18,
                -20
            ],
            [
                0x1f2,
                2,
                -65
            ],
            [
                0x1f2,
                16,
                -80
            ]
        ];
        for (const [pattern, dx, dy] of pieces){
            f.w04 = pattern;
            f.x = ftol(c.x) + c.facing * dx;
            f.y = ftol(c.y) + dy;
            f.b20 = 0;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        c.seRequest = 0x22;
        c.freeChild(i);
        c.f3144 = 0;
        return;
    }
    ch.timer++;
    if (childAdvance(c, i)) ch.frame = 0;
}
function debris(c, i, init, gravity) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3154[i] === 0) init();
    ch.vy = ch.vy + gravity;
    if (ch.y > 0.0 && ch.vy > 0.0) ch.vy = -ch.vy;
    if (c.a3254[i] < 10) ch.blend = 1;
    if (c.a3254[i] < 0) {
        c.freeChild(i);
        return;
    }
    ch.timer++;
    c.a3254[i]--;
    if (childAdvance(c, i)) ch.frame = 0;
}
function child497(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 40;
        c.a3254[i] = r1 + coin() * 20 + 80;
        c.a3154[i]++;
        const t1 = coin() * 1.2;
        const t2 = coin() * 0.7 + t1;
        ch.vx = coin() * 1.7 + t2 + -1.8;
        const u1 = coin() * 0.6;
        const u2 = coin() * 0.9 + u1;
        ch.vy = -1.2 - (coin() * 1.4 + u2);
    }, 0.05);
}
function child498(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 60;
        c.a3254[i] = r1 + coin() * 40 + 120;
        c.a3154[i]++;
        const t1 = coin();
        const t2 = coin() * 0.5 + t1;
        ch.vx = coin() * 1.5 + t2 + -1.5;
        const u1 = coin() * 0.5;
        const u2 = coin() * 0.8 + u1;
        ch.vy = -1.0 - (coin() * 1.2 + u2);
    }, 0.03);
}
function child499(c, i) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y;
    ch.timer++;
    if (childAdvance(c, i)) c.freeChild(i);
}
registerChildren({
    415: (c, i)=>child415(c, i, 0),
    416: (c, i)=>child415(c, i, 1),
    417: (c, i)=>child415(c, i, 2),
    418: child418,
    420: (c, i)=>childFollow(c, i, 0xc9),
    421: (c, i)=>childFollow(c, i, 0xca),
    422: (c, i)=>childFollow(c, i, 0xcd),
    423: (c, i)=>childFollow(c, i, 0xd0),
    424: (c, i)=>childFollow(c, i, 0xcb),
    425: (c, i)=>childFollow(c, i, 0xd1),
    426: child426,
    432: (c, i)=>childFollow(c, i, 0x135),
    433: child433,
    434: (c, i)=>childFollow(c, i, 0x135),
    435: (c, i)=>childFollow(c, i, 0x135),
    436: child436,
    437: child436,
    438: child436,
    439: child439,
    440: childOnce,
    442: child442,
    443: child442,
    444: child442,
    445: child442,
    446: child442,
    447: child442,
    448: childOnce,
    495: child495,
    496: child496,
    497: child497,
    498: child498,
    499: child499
});
