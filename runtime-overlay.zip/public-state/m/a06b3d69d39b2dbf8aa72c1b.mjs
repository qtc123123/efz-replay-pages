import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { angleOf, childCount, childDuration, childSpawnFrame, DEG, frameChild, frameEffect, openSpawnFrame } from "./8b7e65180486b4c98515924a.mjs";
import { registerChildren, registerStates } from "./d80c43470aa1f91788a9cb77.mjs";
import { frameCount, frameDuration, s16 } from "./7596266716c972d06fe8897a.mjs";
function rfCostEffect(c, f, dx) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = Math.trunc(c.x) + c.facing * dx;
    f.y = Math.trunc(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function spawnFromBody(c, f, pattern, dx, dy) {
    f.w04 = pattern;
    f.x = Math.trunc(c.x) + c.facing * dx;
    f.y = Math.trunc(c.y) - dy;
    f.b18 = c.facing;
    f.b21 = 1;
    f.b20 = 2;
    frameChild(c, f);
}
function hopMark(c, gain) {
    c.meter = s16(c.meter + gain);
    c.vx = 1.1;
    c.vy = -2.2;
    c.ay = 0.05;
    c.markChildrenNear(Math.trunc(c.x) + c.facing * 0x33, Math.trunc(c.y) - 0x3f, 0x24, 0x50);
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 1;
        if (c.y < 0.0) c.frame = 1;
    }
    if (c.frame === 2 && c.timer === 0) hopMark(c, 0x1e);
    if (c.frame === 6 && c.vy + c.y > 0.0) {
        c.timer = 0;
        c.y = 0.0;
        c.frame = 7;
        c.stopMotion();
        return;
    }
    if (c.frame > 1) c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 2;
        if (c.y < 0.0) c.frame = 1;
    }
    if (c.frame === 2 && c.timer === 0) hopMark(c, 0xf);
    if (c.frame === 5 && c.timer === 0) hopMark(c, 0xf);
    if (c.frame === 10 && c.vy + c.y > 0.0) {
        c.timer = 0;
        c.y = 0.0;
        c.frame = 11;
        c.stopMotion();
        return;
    }
    if (c.frame > 1) c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 8) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        rfCostEffect(c, f, 0x14);
        c.w16c = 3;
        c.stopMotion();
        if (c.y < 0.0) c.frame = 1;
    }
    if (c.frame === 2 && c.timer === 0) hopMark(c, 0xf);
    if (c.frame === 5 && c.timer === 0) hopMark(c, 0xf);
    if (c.frame === 11 && c.timer === 0) {
        c.meter = s16(c.meter + 0xf);
        c.vx = 1.1;
        c.vy = -2.8;
        c.ay = 0.05;
    }
    if ((c.frame === 21 || c.frame === 20) && c.vy + c.y > 0.0) {
        c.timer = 0;
        c.y = 0.0;
        c.frame = 22;
        c.stopMotion();
        return;
    }
    if (c.frame > 1) c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 14) c.d168 = 0;
        if (c.frame === 22 && c.y < 0.0) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function backHopTail(c, dur, cnt) {
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.vy = 0.0;
            c.ay = 0.0;
            c.vx = 0.0;
            c.onStateChange();
            c.state = 13;
            return;
        }
        if (c.frame >= cnt) c.frame = 1;
    }
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = -0.9;
        c.vy = -2.1;
        c.ay = 0.07;
        spawnFromBody(c, f, 0x195, 0xa, 0x1e);
    }
    backHopTail(c, dur, cnt);
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = -0.9;
        c.vy = -2.1;
        c.ay = 0.05;
        c.voiceRequest = 1;
        spawnFromBody(c, f, 0x190, 0x1e, 0x1e);
    }
    backHopTail(c, dur, cnt);
}
function state266(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = -0.9;
        c.vy = -2.1;
        c.ay = 0.04;
        c.voiceRequest = 1;
        spawnFromBody(c, f, 0x195, 0x1e, 0x1e);
    }
    backHopTail(c, dur, cnt);
}
function airBackHop(c, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter - 0x32);
        c.vx = -0.9;
        c.vy = -1.5;
        c.ay = 0.05;
        c.voiceRequest = 1;
        spawnFromBody(c, f, pattern, 0x1e, 0x1e);
    }
    backHopTail(c, dur, cnt);
}
function state275(c) {
    airBackHop(c, 0x190);
}
function state276(c) {
    airBackHop(c, 0x196);
}
function state277(c) {
    airBackHop(c, 0x198);
}
function groundShot(c, pattern, count3160) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame === 3 && c.timer === 0) {
        c.meter = s16(c.meter - 0x32);
        if (count3160) c.f3160 = c.f3160 + 1;
        spawnFromBody(c, f, pattern, 0x1e, 0x1e);
        c.voiceRequest = 1;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state255(c) {
    groundShot(c, 0x190, true);
}
function state256(c) {
    groundShot(c, 0x196, false);
}
function state257(c) {
    groundShot(c, 0x197, false);
}
function airShot(c, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter - 0x32);
        c.voiceRequest = 1;
        spawnFromBody(c, f, pattern, 0x1e, 0x1e);
    }
    if (c.y + c.vy > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.vx = 0.0;
        c.onStateChange();
        c.state = 0x107;
        return;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.vy = 0.0;
            c.ay = 0.0;
            c.vx = 0.0;
            c.onStateChange();
            c.state = 13;
            return;
        }
        if (c.frame >= cnt) c.frame = 1;
    }
}
function state260(c) {
    airShot(c, 0x190);
}
function state261(c) {
    airShot(c, 0x196);
}
function state262(c) {
    airShot(c, 0x198);
}
function state263(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function state265(c) {
    const dur = frameDuration(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.f3138 = 2;
    }
    if (c.frame === 3 && c.timer === 0) {
        spawnFromBody(c, f, 0x195, 0x1e, 0x1e);
        c.voiceRequest = 1;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 8) {
            if (c.f3138 > 1) {
                c.f3138 = c.f3138 - 1;
                c.frame = 1;
            } else {
                c.state = 0;
                c.onStateChange();
                c.faceOpponent();
            }
        }
    }
}
function modeSpawn(c, f, pattern) {
    if (c.f3138 !== 0) return;
    c.seRequest = 0x20;
    c.f3148 = 1;
    f.d00 = 1;
    f.w04 = pattern;
    f.x = Math.trunc(c.x) + c.facing * 0x21;
    f.y = Math.trunc(c.y) - 0x38;
    f.b18 = c.facing;
    f.b21 = 1;
    frameChild(c, f);
}
function modeTail(c, dur, cnt) {
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state267(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.f3154 = 0;
    }
    if (c.frame === 5 && c.timer === 0) modeSpawn(c, f, 0x19b);
    modeTail(c, dur, cnt);
}
function state268(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.f3154 = 0;
    }
    if (c.frame === 4 && c.timer === 0) modeSpawn(c, f, 0x19c);
    modeTail(c, dur, cnt);
}
function state269(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.f3154 = 0;
        c.stopMotion();
        rfCostEffect(c, f, 0);
    }
    if (c.frame === 5 && c.timer === 0) modeSpawn(c, f, 0x19d);
    modeTail(c, dur, cnt);
}
function stompEffect(c, f, hits) {
    f.w04 = 0x1f;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y);
    f.b20 = 0;
    f.b21 = 1;
    f.d1c = c.facing - 1 !== 0 ? 1 : 0;
    frameEffect(f);
    c.w16c = hits;
}
function stompFall(c) {
    if (c.frame > 3 && c.frame < 6) {
        c.vy = c.vy + c.ay;
        if (c.y < 0.0) {
            c.markChildrenNear(Math.trunc(c.x) - c.facing * 0x22, Math.trunc(c.y) - 0x42, 0x27, 0x2a);
        }
        if (c.vy + c.y > 0.0) {
            c.y = 0.0;
            c.frame = 6;
            c.timer = 0;
            c.stopMotion();
            c.seRequest = 0x23;
            return true;
        }
    }
    return false;
}
function stompSpawn(c, f) {
    c.f3160 = c.f3160 + 1;
    spawnFromBody(c, f, 0x190, 0x32, 0x1e);
    f.w04 = 0x19e;
    frameChild(c, f);
}
function state270(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame === 2 && c.timer === 0) stompEffect(c, f, 2);
    if (stompFall(c)) {
        c.markChildrenNear(Math.trunc(c.x) + c.facing * 0x27, Math.trunc(c.y) - 0x23, 0x46, 0x4b);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 7) c.d168 = 0;
        if (c.frame === 3) {
            c.vx = 1.5;
            c.vy = -1.4;
            c.ay = 0.09;
        }
        if (c.frame === 6) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state271(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame === 2 && c.timer === 0) stompEffect(c, f, 2);
    if (stompFall(c)) {
        stompSpawn(c, f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 7) c.d168 = 0;
        if (c.frame === 3) {
            c.vx = 0.8;
            c.vy = -3.3;
            c.ay = 0.09;
        }
        if (c.frame === 3 || c.frame === 7) c.d168 = 0;
        if (c.frame === 6) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state272(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        rfCostEffect(c, f, 0);
    }
    if (c.frame === 2 && c.timer === 0) stompEffect(c, f, 1);
    if (stompFall(c)) {
        c.w16c = 1;
        stompSpawn(c, f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (s16(c.w16c) > 0) c.d168 = 0;
        if (c.frame === 3) {
            c.vx = 1.8;
            c.vy = -1.0;
            c.ay = 0.03;
        }
        if (c.frame === 6) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function orderState(c, order, cmd, voice) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame === order && c.timer === 0) {
        c.f3154 = cmd;
        c.voiceRequest = voice;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state278(c) {
    orderState(c, 2, 1, 4);
}
function state279(c) {
    orderState(c, 2, -1, 3);
}
function state280(c) {
    orderState(c, 4, 2, 3);
}
registerStates({
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    265: state265,
    266: state266,
    267: state267,
    268: state268,
    269: state269,
    270: state270,
    271: state271,
    272: state272,
    275: state275,
    276: state276,
    277: state277,
    278: state278,
    279: state279,
    280: state280
});
function bob(c, i) {
    const ch = c.children[i];
    if (ch.ay === 0.0) ch.ay = -0.015;
    if (ch.vy > 0.7) ch.ay = -0.015;
    if (ch.vy < -0.7) ch.ay = 0.015;
    ch.vy = ch.vy + ch.ay;
}
function floatTail(c, i, ready) {
    const ch = c.children[i];
    if (c.a316c[i] === 1 && c.a32ac[i] <= 0 && ready) {
        const f = childSpawnFrame;
        f.d00 = 0;
        f.w04 = 0x195;
        f.x = Math.trunc(ch.x);
        f.y = Math.trunc(ch.y);
        f.b18 = ch.facing;
        f.b20 = 2;
        f.b21 = 1;
        frameChild(c, f);
        c.a316c[i] = 0;
        c.a32ac[i] = 0x78;
        if (c.f314c === 0) c.freeChild(i);
        return;
    }
    c.a316c[i] = 0;
    ch.timer++;
    c.a32ac[i] = c.a32ac[i] - 1;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            if (c.a31ac[i] < 0x10) {
                ch.frame = 0;
                c.a31ac[i] = c.a31ac[i] + 1;
            } else {
                c.freeChild(i);
            }
        }
    }
}
function child400(c, i) {
    if (c.a33ac[i] === 0) c.a33ac[i] = c.f3158 + 10;
    bob(c, i);
    floatTail(c, i, true);
}
function child406(c, i) {
    const ch = c.children[i];
    if (c.a33ac[i] === 2) bob(c, i);
    if (c.a33ac[i] === 0) {
        ch.vx = 1.8;
        c.a33ac[i] = 1;
    }
    if (c.a33ac[i] === 1) {
        ch.vx = ch.vx - 0.015;
        if (ch.vx < 0.0) {
            ch.vx = 0.0;
            c.a33ac[i] = 2;
        }
    }
    floatTail(c, i, c.a33ac[i] === 2);
}
function child407(c, i) {
    const ch = c.children[i];
    if (c.a33ac[i] === 2) bob(c, i);
    if (c.a33ac[i] === 0) {
        ch.vx = 1.8;
        ch.vy = -1.8;
        c.a33ac[i] = 1;
    }
    if (c.a33ac[i] === 1) {
        ch.vx = ch.vx - 0.015;
        ch.vy = ch.vy + 0.015;
        if (ch.vx < 0.0) {
            ch.vx = 0.0;
            ch.vy = 0.0;
            c.a33ac[i] = 2;
        }
    }
    floatTail(c, i, c.a33ac[i] === 2);
}
function child408(c, i) {
    const ch = c.children[i];
    if (c.a33ac[i] === 2) bob(c, i);
    if (c.a33ac[i] === 0) {
        ch.vx = 1.8;
        ch.vy = 1.8;
        c.a33ac[i] = 1;
    }
    if (c.a33ac[i] === 1) {
        ch.vx = ch.vx - 0.015;
        ch.vy = ch.vy - 0.015;
        if (ch.y > -10.0) {
            ch.vy = 0.0;
            ch.vx = 0.0;
            c.a33ac[i] = 2;
        }
        if (ch.vx < 0.0) {
            ch.vx = 0.0;
            ch.vy = 0.0;
            c.a33ac[i] = 2;
        }
    }
    floatTail(c, i, c.a33ac[i] === 2);
}
function child405(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    ch.vx = 0.0;
    ch.vy = 0.0;
    if (ch.frame === 5 && ch.timer === 0) c.voiceRequest = 1;
    if (ch.frame === 14 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.markChildrenNear(Math.trunc(ch.x), Math.trunc(ch.y), 0x5a, 0x5a);
        c.a316c[i] = 0;
    }
    if (ch.hitState === 3) {
        c.a31ac[i] = Math.trunc(angleOf(ch.x - o.x, ch.y - o.y - 50.0));
        const angle = c.a31ac[i];
        o.vx = __numerics.cos(angle / DEG) * 2.2;
        o.vy = __numerics.sin(angle / DEG) * 2.2;
        if (o.facing === 1) o.vx = o.vx * -1.0;
        ch.hitState = 1;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function servant(c, i, initVx, initVy, decel, steer, spawn413) {
    const ch = c.children[i];
    if (c.f3154 === 1) {
        ch.vy = ch.vy - 2.5;
        if (c.a31ac[i] > 1) ch.vx = ch.vx * 0.5;
        c.f3154 = 0;
    }
    if (c.f3154 === -1) {
        ch.vy = ch.vy + 2.5;
        if (c.a31ac[i] > 1) ch.vx = ch.vx * 0.5;
        c.f3154 = 0;
    }
    if (c.f3154 === 2) {
        c.f3148 = 1;
        c.a31ac[i] = 1;
        ch.vx = 3.0;
        if (c.facing !== ch.facing) ch.facing = c.facing;
        c.f3154 = 0;
    }
    if (ch.frame === 0 && ch.timer === 0 && c.a31ac[i] === 0) {
        ch.vx = initVx;
        ch.vy = initVy;
        ch.hitsLeft = 1;
        c.a31ac[i] = 1;
    }
    if (c.a31ac[i] === 1) {
        ch.vx = ch.vx - decel;
        if (ch.vx < 0.0) ch.vx = 0.0;
    }
    if (ch.vx === 0.0 && c.a31ac[i] === 1) {
        c.a31ac[i] = 2;
        c.f3148 = 2;
        ch.hitsLeft = 0;
    }
    if (c.a31ac[i] >= 2) {
        if (c.y - 50.0 > ch.y) ch.vy = ch.vy + 0.06;
        if (c.y - 70.0 < ch.y) ch.vy = ch.vy - 0.06;
        if (ch.x < c.x) ch.vx = ch.facing * steer + ch.vx;
        if (ch.x > c.x) ch.vx = ch.vx - ch.facing * steer;
        if (ch.vy < -2.0) {
            ch.vy = -2.0;
        } else if (ch.vy > 2.0) {
            ch.vy = 2.0;
        }
        if (ch.vx < -2.0) {
            ch.vx = -2.0;
        } else if (ch.vx > 2.0) {
            ch.vx = 2.0;
        }
        if (spawn413) {
            if (c.a31ac[i] > 1 && c.a32ac[i] > 0x59 && c.a33ac[i] < 5) {
                const f = childSpawnFrame;
                f.d00 = 0;
                f.w04 = 0x190;
                f.x = Math.trunc(ch.x);
                f.y = Math.trunc(ch.y);
                f.b18 = ch.facing;
                f.b20 = 2;
                f.b21 = 1;
                frameChild(c, f);
                f.w04 = 0x19e;
                frameChild(c, f);
                c.a32ac[i] = 0;
                c.a33ac[i] = c.a33ac[i] + 1;
            }
        }
        if (c.y - 70.0 < ch.y && c.y - 20.0 > ch.y && c.x - 10.0 < ch.x && c.x + 10.0 > ch.x && c.f3148 >= 2) {
            c.freeChild(i);
            c.f3148 = 0;
            c.seRequest = 0x1a;
            return true;
        }
    }
    return false;
}
function servantTail(c, i, count32ac) {
    const ch = c.children[i];
    ch.timer++;
    if (count32ac) c.a32ac[i] = c.a32ac[i] + 1;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = ch.frame - 2;
    }
}
function child411(c, i) {
    const ch = c.children[i];
    c.markChildrenNear(Math.trunc(ch.x), Math.trunc(ch.y), 0x1e, 0x1e);
    if (servant(c, i, 4.2, 0.0, 0.045, 0.04, false)) return;
    servantTail(c, i, false);
}
function child412(c, i) {
    const ch = c.children[i];
    c.markChildrenNear(Math.trunc(ch.x), Math.trunc(ch.y), 0x1e, 0x1e);
    if (servant(c, i, 2.0, -2.3, 0.03, 0.06, false)) return;
    servantTail(c, i, false);
}
function child413(c, i) {
    if (servant(c, i, 2.7, 0.0, 0.02, 0.04, true)) return;
    servantTail(c, i, true);
}
function child414(c, i) {
    const ch = c.children[i];
    ch.vx = 0.0;
    ch.vy = 0.0;
    if (ch.frame === 5 && ch.timer === 0) c.voiceRequest = 1;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child416(c, i) {
    const ch = c.children[i];
    ch.vx = 0.0;
    ch.vy = 0.0;
    if (ch.frame === 5 && ch.timer === 0) {
        c.voiceRequest = 1;
        c.f314c = 0;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            c.freeChild(i);
            c.f314c = 0;
        }
    }
}
registerChildren({
    400: child400,
    405: child405,
    406: child406,
    407: child407,
    408: child408,
    411: child411,
    412: child412,
    413: child413,
    414: child414,
    416: child416
});
