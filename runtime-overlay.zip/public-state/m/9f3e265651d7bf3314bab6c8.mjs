import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./d80c43470aa1f91788a9cb77.mjs";
import { DEG, angleOf, childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./8b7e65180486b4c98515924a.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function drawGauge(c, pattern, len) {
    const f = c.patterns[pattern]?.frames[0];
    if (!f) return;
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    const w = len(f.width);
    const src = makeRect(0, 0, w, f.height);
    const dst = c.side === 0 ? makeRect(0x31 - f.offsetX, 0x1f - f.offsetY, w, f.height) : makeRect(f.offsetX + 0x10f - w, 0x1f - f.offsetY, w, f.height);
    blit(dst, surf, src, c.colorKey, false);
}
export function renderOverlayNagamori(c) {
    if (c.f3150 > 0) drawGauge(c, 43, (w)=>w);
    if (c.f3150 > 0) drawGauge(c, 44, (w)=>Math.trunc(w * c.f3150 / 0x4b0));
}
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function endToNeutral(c) {
    c.state = 0;
    c.faceOpponent();
    c.onStateChange();
}
function superFreeze(c, freeze, cost, color) {
    c.freeze = freeze;
    c.meter = s16(c.meter - cost);
    c.superDarken(color, 3);
}
function superEffect(d, pat, sound, x, y) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = x;
    d.y = y;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function rushStart(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 1;
    }
    if (atFrame(c, 2)) {
        superFreeze(c, 0x78, p.cost, 0xb0);
        superEffect(d, p.pat, p.sound, ftol(c.x), ftol(c.y) - 0x28);
        if (p.big) c.seRequest = 0x25;
    }
    if (p.big && c.frame > 2) c.showAltBackground(0xf);
    if (c.frame > 2 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.state = p.next;
        o.state = 0x6b;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x25;
        d.y = ftol(c.y) - 0x2a;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.y = 0.0;
        o.x = c.x;
        return;
    }
    if (c.frame > 2 && c.d168 === 2) {
        c.timer = 0;
        c.frame = p.jump;
        c.d168 = 0;
    }
    if (atFrame(c, p.jump + 1)) {
        c.shakeScreen(3, 0);
        d.w04 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        frameEffect(d);
        c.seRequest = 7;
    }
    if (c.frame > p.jump - 1) {
        c.vx = c.vx - 0.06;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 3) c.vx = 2.0;
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function holdOpponent(c) {
    const o = c.opponent;
    o.state = 0x71;
    if (c.facing === 1 && c.x < 40.0) c.x = 40.0;
    if (c.facing === -1 && c.x > 620.0) c.x = 620.0;
    o.y = 0.0;
    o.x = c.x;
}
function comboHit(c, d, damage, proration) {
    c.opponent.hitstop = 0x1e;
    d.w04 = 0;
    d.b2c = 2;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    applyDirectDamage(c, damage, proration);
}
function rushCombo(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (p.big) c.showAltBackground(0xf);
    if (c.frame === 0) {
        o.w140 = 30000;
        c.w16c = 1;
        o.state = 0x68;
        o.x = c.facing * 0x23 + c.x;
        o.y = -35.0;
        c.d168 = 0;
        c.f3138 = 8;
    }
    if (c.frame === 1) holdOpponent(c);
    if (c.frame < 2) {
        c.vx = c.vx - 0.02;
        if (c.vx < 0.0) c.vx = 0.0;
    } else {
        c.vx = 0.0;
    }
    c.wF2 = 3;
    for (const [f, dmg, pr] of p.hits){
        if (atFrame(c, f)) comboHit(c, d, dmg, pr);
    }
    if (atFrame(c, p.lastFrame)) {
        d.w04 = 0;
        d.b2c = 2;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b2c = 0x16;
        c.shakeScreen(10, 10);
        frameEffect(d);
        o.w140 = 0;
        applyDirectDamage(c, p.lastDamage, 800.0);
        o.state = 0x62;
        o.onStateChange();
        o.hitstop = 0xb4;
    }
    if (c.frame > p.hold) {
        o.state = 0x63;
        o.frame = 0;
        o.timer = 0;
    }
    if (c.frame > p.tail) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.state = 0xd;
            c.onStateChange();
            c.stopMotion();
            return;
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 1) holdOpponent(c);
    if (c.frame === 2) c.x = (-17 - o.pointsX[1]) * c.facing + o.x;
    if (c.frame === 6 && c.f3138 === 0) c.frame = 7;
    if (c.frame === 7) {
        if (c.f3138 > 0) {
            c.frame -= 2;
            c.f3138--;
        } else {
            c.f3138 = 20;
        }
    }
    for (const [f, back, reset] of p.loops){
        if (c.frame !== f) continue;
        if (c.f3138 > 0) {
            c.frame -= back;
            c.f3138--;
        } else if (reset !== null) {
            c.f3138 = reset;
        }
    }
    if (c.frame === p.tail) {
        c.vx = -1.0;
        c.vy = -1.7;
        c.ay = 0.037;
    }
    c.d168 = 0;
    if (c.frame >= cnt) c.frame -= 2;
}
function groundShot(c, child, moveWhileFrozen) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        superFreeze(c, 0x78, 0x3e8, 0xb0);
        superEffect(d, 0x44, 0x13, ftol(c.x), ftol(c.y) - 0x28);
    }
    if (atFrame(c, 3)) {
        c.voiceRequest = 1;
        d.d00 = 0;
        d.w04 = child;
        d.x = ftol(c.x) + c.facing * 0x1e;
        d.y = ftol(c.y) - 0x1e;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        if (moveWhileFrozen) d.d30 = 1;
        frameChild(c, d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function state308(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        superFreeze(c, 0x78, 0x3e8, 0xb0);
        superEffect(d, 0x44, 0x13, ftol(c.x) - c.facing * 32, ftol(c.y) - 0x4b);
    }
    if (atFrame(c, 5)) {
        c.voiceRequest = 1;
        d.d00 = 1;
        d.w04 = 0x191;
        d.x = ftol(c.x) + c.facing * 0x32;
        d.y = ftol(c.y) - 0x3c;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function airLand(c) {
    if (c.y + c.vy > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.vx = 0.0;
        c.setState(0xd);
        return true;
    }
    return false;
}
function airShot(c, pat, sound, child) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        superFreeze(c, 0x78, 0x3e8, 0xb0);
        superEffect(d, pat, sound, ftol(c.x) + c.facing * 0x17, ftol(c.y) - 0x1e);
    }
    if (airLand(c)) return;
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 1) {
        c.vx = -0.9;
        c.vy = -2.1;
        c.ay = 0.05;
        c.voiceRequest = 1;
        d.w04 = child;
        d.x = ftol(c.x) + c.facing * 0x1e;
        d.y = ftol(c.y) - 0x1e;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 2;
        frameChild(c, d);
    }
    if (airLand(c)) return;
    if (c.frame >= cnt) c.frame = 1;
}
function state312(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.f313c === 0x2d) {
        d.d00 = 1;
        d.w04 = 0x1bf;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x32;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        d.d30 = 1;
        frameChild(c, d);
    }
    c.f313c++;
    if (atFrame(c, 6)) {
        superFreeze(c, 0xa0, 0xbb8, 0xb0);
        superEffect(d, 0x46, 0x40, ftol(c.x), ftol(c.y) - 0x28);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (atFrame(c, 7)) {
        c.voiceRequest = 0;
        c.screenFlash(1, 0x14, 0xf, 0xa);
        c.freeze = 0x12c;
    }
    if (atFrame(c, 8)) {
        if (c.f3140 === 0) {
            c.freeze = 0x4b0;
            c.superDarken(0xb1, 3);
            d.d00 = 1;
            d.w04 = 0x1a1;
            d.x = ftol(c.x) + c.facing * 0x1e;
            d.y = ftol(c.y) - 0x1e;
            d.b18 = c.facing;
            d.b20 = 0;
            d.b21 = 0;
            d.d30 = 1;
            c.voiceRequest = 2;
            frameChild(c, d);
        }
        if (c.f3140 === 5) {
            o.state = 0x3b;
            o.d128 = 1;
            o.onStateChange();
        }
        c.f3140++;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 2 && c.f3138 === 0) c.frame -= 2;
    if (c.frame === 4 && c.f3138 === 1) c.frame -= 2;
    if (c.frame === 6 && c.f3138 < 0xc) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame === 10 && c.f3138 < 0x18) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame >= cnt) {
        c.f3150 = 0x4b0;
        c.superDarken(0xb1, 3);
        endToNeutral(c);
    }
}
function burstSuper(c, cost, pat, sound, child) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (atFrame(c, 5)) {
        superFreeze(c, 0x78, cost, 0xb0);
        superEffect(d, pat, sound, ftol(c.x), ftol(c.y) - 0x73);
    }
    if (atFrame(c, 6)) {
        c.shakeScreen(10, 5);
        d.w04 = child;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x37;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        d.w04 = 0x1c5;
        d.d00 = 0;
        frameChild(c, d);
        c.f314c = 1;
        c.markChildrenNear(ftol(c.x), ftol(c.y), 0x3e8, 0x3e8);
        c.voiceRequest = 1;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
registerStates({
    300: (c)=>rushStart(c, {
            cost: 0x3e8,
            pat: 0x44,
            sound: 0x13,
            next: 0x12f,
            jump: 0xb,
            big: false
        }),
    301: (c)=>rushStart(c, {
            cost: 0x7d0,
            pat: 0x45,
            sound: 5,
            next: 0x130,
            jump: 0x13,
            big: false
        }),
    302: (c)=>rushStart(c, {
            cost: 0xbb8,
            pat: 0x46,
            sound: 0x40,
            next: 0x131,
            jump: 0x13,
            big: true
        }),
    303: (c)=>rushCombo(c, {
            hits: [
                [
                    6,
                    100,
                    980.0
                ]
            ],
            lastFrame: 9,
            lastDamage: 2000,
            hold: 11,
            tail: 14,
            loops: [],
            big: false
        }),
    304: (c)=>rushCombo(c, {
            hits: [
                [
                    6,
                    100,
                    990.0
                ],
                [
                    10,
                    100,
                    990.0
                ]
            ],
            lastFrame: 15,
            lastDamage: 2000,
            hold: 19,
            tail: 19,
            loops: [
                [
                    12,
                    5,
                    3
                ]
            ],
            big: false
        }),
    305: (c)=>rushCombo(c, {
            hits: [
                [
                    6,
                    100,
                    990.0
                ],
                [
                    10,
                    100,
                    990.0
                ],
                [
                    15,
                    150,
                    990.0
                ]
            ],
            lastFrame: 20,
            lastDamage: 2500,
            hold: 24,
            tail: 24,
            loops: [
                [
                    12,
                    5,
                    3
                ],
                [
                    17,
                    5,
                    null
                ]
            ],
            big: true
        }),
    306: (c)=>groundShot(c, 0x193, true),
    307: (c)=>groundShot(c, 0x192, false),
    308: state308,
    309: (c)=>airShot(c, 0x44, 0x13, 0x193),
    310: (c)=>airShot(c, 0x44, 0x13, 0x192),
    311: (c)=>airShot(c, 9, 5, 0x191),
    312: state312,
    313: (c)=>burstSuper(c, 0x3e8, 0x44, 0x13, 0x1c2),
    314: (c)=>burstSuper(c, 0x7d0, 0x45, 5, 0x1c3),
    315: (c)=>burstSuper(c, 0xbb8, 0x46, 0x40, 0x1c4)
});
function childTick(c, i) {
    const ch = c.children[i];
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    c.children[i].timer++;
    if (childTick(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function spawnAtChild(c, i, pat, owner) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    d.d00 = owner;
    d.w04 = pat;
    d.x = ftol(ch.x);
    d.y = ftol(ch.y);
    d.b18 = ch.facing;
    d.b20 = 2;
    d.b21 = 1;
    frameChild(c, d);
}
function hover(c, i) {
    const ch = c.children[i];
    if (ch.ay === 0.0) ch.ay = -0.015;
    if (ch.vy > 0.7) ch.ay = -0.015;
    if (ch.vy < -0.7) ch.ay = 0.015;
    ch.vy = ch.vy + ch.ay;
}
function touched(c, i, pat, ready, freeIf314c0) {
    if (c.a316c[i] !== 1 || c.a32ac[i] > 0 || !ready) return false;
    spawnAtChild(c, i, pat, 0);
    c.a316c[i] = 0;
    c.a32ac[i] = 0x78;
    if (freeIf314c0 && c.f314c === 0) c.freeChild(i);
    return true;
}
function loopOrFree(c, i, limit) {
    const ch = c.children[i];
    if (ch.frame < childCount) return;
    if (c.a31ac[i] < limit) {
        ch.frame = 0;
        c.a31ac[i]++;
    } else {
        c.freeChild(i);
    }
}
function child401(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.75;
        ch.vy = -2.5;
        c.f3164 = 0;
        c.f3168 = 1;
    }
    ch.vy = ch.vy + 0.045;
    if (!(ch.vy + ch.y < 0.0)) {
        ch.vy = -ch.vy;
        ch.y = 0.0;
    }
    if (ch.timer === 0 && c.a33ac[i] >= 0x14) {
        const d = childSpawnFrame;
        d.d00 = 0;
        d.w04 = 0x19a;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y);
        d.b18 = ch.facing;
        d.b20 = 2;
        d.b21 = 1;
        c.a33ac[i] = 0;
        frameChild(c, d);
    }
    if (ch.x > 680.0 || ch.x < -40.0) {
        c.freeChild(i);
        c.f3168 = 0;
    }
    ch.timer++;
    if (!childTick(c, i)) return;
    c.a33ac[i]++;
    if (ch.frame >= childCount) ch.frame = 9;
}
function child402(c, i) {
    const ch = c.children[i];
    c.a32ac[i]--;
    hover(c, i);
    if (touched(c, i, 0x195, true, false)) return;
    c.a316c[i] = 0;
    ch.timer++;
    if (!childTick(c, i)) return;
    loopOrFree(c, i, 0xc);
}
function child403(c, i) {
    const ch = c.children[i];
    if (c.a33ac[i] === 0) c.a33ac[i] = c.f3158 + 0xa;
    hover(c, i);
    if (touched(c, i, 0x1c6, true, true)) return;
    c.a316c[i] = 0;
    ch.timer++;
    c.a32ac[i]--;
    if (!childTick(c, i)) return;
    loopOrFree(c, i, 0x10);
}
function driftChild(c, i, s) {
    const ch = c.children[i];
    if (c.a33ac[i] === 2) hover(c, i);
    if (c.a33ac[i] === 0) {
        if (s.vx0 !== null) ch.vx = s.vx0;
        ch.vy = s.vy0;
        c.a33ac[i] = 1;
    }
    if (c.a33ac[i] === 1) {
        if (s.dvx !== 0) ch.vx = ch.vx + s.dvx;
        ch.vy = ch.vy + s.dvy;
        if (ch.y > -10.0) {
            ch.vy = 0.0;
            if (s.vx0 !== null) ch.vx = 0.0;
            c.a33ac[i] = 2;
        }
        if (s.stop(ch.vx, ch.vy)) {
            ch.vx = 0.0;
            ch.vy = 0.0;
            c.a33ac[i] = 2;
        }
    }
    if (touched(c, i, 0x195, c.a33ac[i] === 2, true)) return;
    c.a316c[i] = 0;
    ch.timer++;
    c.a32ac[i]--;
    if (!childTick(c, i)) return;
    loopOrFree(c, i, 0xa);
}
const DRIFT_409 = {
    vx0: null,
    vy0: -1.2,
    dvx: 0,
    dvy: 0.015,
    stop: (_vx, vy)=>vy > 0.0
};
const DRIFT_415 = {
    vx0: -1.2,
    vy0: 1.2,
    dvx: 0.015,
    dvy: -0.015,
    stop: (vx)=>vx > 0.0
};
const DRIFT_449 = {
    vx0: 1.2,
    vy0: 1.2,
    dvx: -0.015,
    dvy: -0.015,
    stop: (vx)=>vx < 0.0
};
function child410(c, i) {
    const ch = c.children[i];
    ch.vx = 0.0;
    ch.vy = 0.0;
    if (ch.frame === 5 && ch.timer === 0) c.voiceRequest = 1;
    if (ch.frame === 6 && ch.timer === 0) {
        c.f3164++;
        if (c.f3164 > 2) c.f3164 = 0;
        spawnAtChild(c, i, 0x1c1, 0);
        const d = childSpawnFrame;
        d.w04 = 0x19f;
        frameChild(c, d);
        d.w04 = 0x199;
        frameChild(c, d);
    }
    childOnce(c, i);
}
const TIMER_SPAWNS = [
    [
        1150,
        0x1a2,
        0.0,
        80.0,
        0,
        1
    ],
    [
        1140,
        0x1a3,
        190.0,
        320.0,
        0,
        1
    ],
    [
        1130,
        0x1a4,
        320.0,
        170.0,
        0,
        1
    ],
    [
        1120,
        0x1a5,
        0.0,
        120.0,
        0,
        1
    ],
    [
        1110,
        0x1a6,
        60.0,
        -80.0,
        0,
        1
    ],
    [
        1100,
        0x1a7,
        320.0,
        40.0,
        0,
        1
    ],
    [
        1080,
        0x1a8,
        240.0,
        320.0,
        0,
        1
    ],
    [
        1060,
        0x1a9,
        180.0,
        -80.0,
        0,
        1
    ],
    [
        1040,
        0x1aa,
        0.0,
        80.0,
        0,
        1
    ],
    [
        1020,
        0x1ab,
        180.0,
        -80.0,
        0,
        1
    ],
    [
        1000,
        0x1ac,
        320.0,
        210.0,
        0,
        1
    ],
    [
        980,
        0x1ad,
        80.0,
        320.0,
        0,
        1
    ],
    [
        970,
        0x1ae,
        240.0,
        320.0,
        0,
        1
    ],
    [
        950,
        0x1af,
        0.0,
        60.0,
        0,
        1
    ],
    [
        930,
        0x1b0,
        160.0,
        -80.0,
        0,
        1
    ],
    [
        910,
        0x1b1,
        320.0,
        80.0,
        0,
        1
    ],
    [
        890,
        0x1b2,
        180.0,
        320.0,
        0,
        1
    ],
    [
        870,
        0x1b3,
        0.0,
        160.0,
        0,
        1
    ],
    [
        850,
        0x1b4,
        60.0,
        -80.0,
        0,
        1
    ],
    [
        830,
        0x1b5,
        320.0,
        50.0,
        0,
        1
    ],
    [
        810,
        0x1b6,
        0.0,
        170.0,
        0,
        1
    ],
    [
        790,
        0x1b7,
        320.0,
        160.0,
        0,
        1
    ],
    [
        770,
        0x1b8,
        160.0,
        320.0,
        0,
        1
    ],
    [
        750,
        0x1b9,
        60.0,
        -80.0,
        0,
        1
    ],
    [
        730,
        0x1ba,
        0.0,
        120.0,
        0,
        1
    ],
    [
        710,
        0x1bb,
        190.0,
        320.0,
        0,
        1
    ],
    [
        690,
        0x1bc,
        120.0,
        -80.0,
        0,
        1
    ],
    [
        540,
        0x1bd,
        0.0,
        120.0,
        1,
        0
    ],
    [
        300,
        0x1be,
        320.0,
        160.0,
        1,
        0
    ]
];
function child417(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    c.f3150--;
    c.freeze = 0x4b0;
    o.w13a = 1;
    c.w13c = 1;
    c.meter = 0;
    o.w140 = 2;
    if (c.f3150 === 0) {
        c.freeze = 0;
        o.w13a = 0;
        c.freeChild(i);
        c.seRequest = 0x16;
        o.state = 0x3b;
        o.w140 = 0;
        c.w13c = 0;
        o.d128 = 1;
        if (o.life === 1) o.life = 0;
        o.knockX = -4.0;
        o.knockY = -1.0;
        return;
    }
    const d = childSpawnFrame;
    for (const [t, pat, x, y, owner, blend] of TIMER_SPAWNS){
        if (c.f3150 !== t) continue;
        d.d00 = owner;
        d.d24 = 1;
        d.w04 = pat;
        d.x = x;
        d.y = y;
        d.b18 = 1;
        d.b20 = blend;
        d.b21 = 0;
        d.d30 = 1;
        frameChild(c, d);
    }
    ch.timer++;
    if (childTick(c, i) && ch.frame >= childCount) ch.frame = 0;
}
function child447(c, i) {
    const ch = c.children[i];
    if (c.state !== 0x138) c.freeChild(i);
    if (ch.frame === 0x19) {
        if (c.f3138 === 0) {
            c.voiceRequest = 3;
            c.markChildrenNear(ftol(c.x), ftol(c.y), 0x140, 0x140);
            c.screenFlash(1, 3, 6, 9);
        }
        c.f3138 = 1;
    }
    if (ch.frame === 0x28) {
        if (c.f3138 === 1) c.voiceRequest = 4;
        c.f3138 = 2;
    }
    ch.timer++;
    if (childTick(c, i) && ch.frame >= childCount) {
        ch.frame = 0;
        ch.pattern = 0x1c0;
    }
}
function child448(c, i) {
    if (c.state !== 0x138) c.freeChild(i);
    childOnce(c, i);
}
function child450(c, i) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y - 55.0;
    if (ch.frame === 1 && ch.timer === 0) {
        ch.hitsLeft = 1;
        spawnAtChild(c, i, 0x1c5, 1);
    }
    childOnce(c, i);
}
function child453(c, i) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y - 55.0;
    if (ch.frame === 1 && ch.timer === 0) c.f314c = 0;
    childOnce(c, i);
}
function child454(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    ch.vx = 0.0;
    ch.vy = 0.0;
    if (ch.frame === 5 && ch.timer === 0) c.voiceRequest = 1;
    if (ch.frame === 0xd && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.markChildrenNear(ftol(ch.x), ftol(ch.y), 0x78, 0x78);
        c.a316c[i] = 0;
    }
    if (ch.hitState === 3) {
        c.a31ac[i] = ftol(angleOf(ch.x - o.x, ch.y - o.y - 50.0));
        o.vx = __numerics.cos(c.a31ac[i] / DEG) * 2.2;
        o.vy = __numerics.sin(c.a31ac[i] / DEG) * 2.2;
        if (o.facing === 1) o.vx = o.vx * -1.0;
        ch.hitState = 1;
    }
    childOnce(c, i);
}
registerChildren({
    401: child401,
    402: child402,
    403: child403,
    409: (c, i)=>driftChild(c, i, DRIFT_409),
    410: child410,
    415: (c, i)=>driftChild(c, i, DRIFT_415),
    417: child417,
    447: child447,
    448: child448,
    449: (c, i)=>driftChild(c, i, DRIFT_449),
    450: child450,
    451: child450,
    452: child450,
    453: child453,
    454: child454
});

export function __logicState(){return {DRIFT_409,DRIFT_415,DRIFT_449,TIMER_SPAWNS};}

export function __installInitialRoots(s){
if(DRIFT_409!==s["DRIFT_409"])throw Error('INITIAL_CONST_IDENTITY:DRIFT_409');
if(DRIFT_415!==s["DRIFT_415"])throw Error('INITIAL_CONST_IDENTITY:DRIFT_415');
if(DRIFT_449!==s["DRIFT_449"])throw Error('INITIAL_CONST_IDENTITY:DRIFT_449');
if(TIMER_SPAWNS!==s["TIMER_SPAWNS"])throw Error('INITIAL_CONST_IDENTITY:TIMER_SPAWNS');
}
