// Generated pinned public continuation identities. The receiver owns this value.
export const PUBLIC_IDENTITIES=Object.freeze({"adapter":"c8bfb528442163644e69c51f988f360c10774ef4b9b1f78ab3ed3a1054976992","core":"5a656188b6dcc3f3fd3b8a6389f0f93c63e6be6fba208fd17a2e135bdefa0b81","metadata":"65ca8a775af491f9331f0d4cb463b1e5b8e22968c9c1b7c7c4b79678afcad164","numerics":"b210067705fd1d342770cd819d433c502db5eb9f67cdcb5d8099d6fcb2c91f62","schema":"1154a179a227fb7a6e52a46a7dcece2eb8ec7f7acc1f2f71037e0e9c4a9cc528"});
export default PUBLIC_IDENTITIES;
