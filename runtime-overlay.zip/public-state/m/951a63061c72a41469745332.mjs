import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
export class UnportedCharacter extends Character {
    renderOverlay() {}
    parseCommand() {}
    dispatchMoves() {}
    think() {}
    updateState() {}
    updateChildren() {}
    tickHook() {}
}
