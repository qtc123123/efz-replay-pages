import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./8eb7102cae7a3c1156bb8cc7.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./da358c15d9881aea726bad32.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function endToNeutral(c) {
    c.state = 0;
    c.faceOpponent();
    c.onStateChange();
}
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function superEffect(d, pat, sound, x, y) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = x;
    d.y = y;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
const LEVEL_PAT = [
    0x44,
    0x45,
    0x46
];
const LEVEL_SOUND = [
    0x13,
    5,
    0x40
];
function airSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = -1.0;
        c.ay = 0.002;
        c.w16c = 1;
    }
    if (atFrame(c, 7)) {
        c.stopMotion();
        superFreeze(c, (p.level + 1) * 1000);
        superEffect(d, LEVEL_PAT[p.level], LEVEL_SOUND[p.level], ftol(c.x), ftol(c.y) - 0x28);
        if (p.big) c.seRequest = 0x25;
    }
    if (p.big && c.frame > 6) c.showAltBackground(0xf);
    if (c.frame === 7) c.biasCameraY(0x32, 3);
    if (c.frame > 7) c.biasCameraY(-0x2d, 3);
    if (atFrame(c, 9)) {
        c.vy = p.vy;
        c.ay = p.ay;
        c.seRequest = 0x16;
        d.d00 = 1;
        d.w04 = p.child;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (!(c.vx + c.y < 0.0)) {
        c.state = 0xd;
        c.onStateChange();
        return;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 0xd && c.vy < 0.0) c.frame = 10;
    if (c.frame >= cnt) endToNeutral(c);
}
function scatterChild(c, d, pat) {
    d.w04 = pat;
    d.x = ftol(c.x) + c.facing * 0x14;
    d.y = ftol(c.y) - 0x4a;
    d.b18 = c.facing;
    d.b20 = 0;
    d.b21 = 1;
}
function groundScatter(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (atFrame(c, 3)) {
        superFreeze(c, (p.level + 1) * 1000);
        superEffect(d, LEVEL_PAT[p.level], LEVEL_SOUND[p.level], ftol(c.x), ftol(c.y) - 0x28);
        c.biasCameraY(0x32, 0x2d);
        if (p.level === 1) c.w13c = 0x87;
        if (p.level === 2) {
            c.seRequest = 0x25;
            c.w13c = 0x99;
        }
    }
    if (p.level === 2 && c.frame > 2) c.showAltBackground(0xf);
    if (atFrame(c, 9)) {
        c.f3138 = 0;
        if (c.random(0, 100) < 0x32) {
            scatterChild(c, d, 0x19b);
            c.f3138++;
            frameChild(c, d);
        }
        if (c.random(0, 100) < 0x32 && c.f3138 === 0) {
            scatterChild(c, d, 0x19d);
            c.f3138++;
            frameChild(c, d);
        }
        if (c.f3138 === 0) {
            scatterChild(c, d, 0x19f);
            frameChild(c, d);
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 0xb && c.f313c < p.loops) {
        c.frame = 4;
        c.f313c += 2;
    }
    if (c.frame >= cnt) endToNeutral(c);
}
function pullSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (p.level < 2) {
        if (atFrame(c, 3)) {
            c.b158 = 0;
            c.stopMotion();
            superFreeze(c, (p.level + 1) * 1000);
            superEffect(d, LEVEL_PAT[p.level], LEVEL_SOUND[p.level], ftol(c.x), ftol(c.y) - 0x28);
            c.biasCameraY(0x32, 0x2d);
        }
        if (c.frame > 4 && o.y === 0.0) {
            c.w16c = 1;
        } else {
            c.w16c = 0;
        }
    } else {
        if (atStart(c)) {
            c.b158 = 0;
            c.stopMotion();
            superFreeze(c, 3000);
            superEffect(d, LEVEL_PAT[2], LEVEL_SOUND[2], ftol(c.x), ftol(c.y) - 0x28);
            c.biasCameraY(0x32, 0x2d);
            c.seRequest = 0x25;
        }
        c.showAltBackground(0xf);
        if (c.frame > 4) c.w16c = 1;
    }
    if (atFrame(c, 1)) c.f3140 = 0xf;
    if (atFrame(c, 5)) {
        const k = c.f313c;
        if (k === 0 || k === 3 || k === 6 || k === 9 || k === 12 || k === 15) {
            d.w04 = 0x1a2;
            d.x = ftol(c.x) + c.facing * 0xf;
            d.y = ftol(c.y);
            d.b20 = 2;
            d.b21 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
        }
    }
    if (c.frame > 4 && c.frame < 8) {
        c.f3138 += p.step;
        if (c.f3138 > p.limit) c.f3138 = p.limit - 1;
        c.d0d0 = 1;
        if (o.x > c.x) c.pushToOpponent = c.f3138 * 0.01 * -o.facing;
        if (o.x < c.x) c.pushToOpponent = c.f3138 * 0.01 * o.facing;
    }
    if (c.frame > 4 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        o.d128 = 1;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x1d;
        d.y = ftol(c.y) - 0x53;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        c.state = p.next;
        o.state = 0x67;
        o.y = -100.0;
        o.x = c.facing * 0x16 + c.x;
        o.facing = c.facing;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 5) c.seRequest = 0x12;
    if (c.frame === 8 && c.f313c < 0xf) {
        c.frame -= 3;
        c.f313c++;
    }
    if (c.frame >= cnt) endToNeutral(c);
}
function holdOpponent(c, y, dx) {
    const o = c.opponent;
    o.y = y;
    o.x = c.facing * dx + c.x;
}
function throwDown(c, proration) {
    const o = c.opponent;
    o.y = 0.0;
    o.x = c.facing * 0x21 + c.x;
    o.facing = -c.facing;
    o.onStateChange();
    o.state = 0x61;
    o.d12c = 1;
    applyDirectDamage(c, 300, proration);
}
function state309(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.startAfterimage(2);
    if (c.frame < 6) c.biasCameraY(0x32, 3);
    if (c.frame < 0xe && o.state === 0x63) o.onStateChange();
    if (c.frame > 8) {
        if (c.vy + c.y > 0.0 && c.frame < 0xe) {
            c.y = 0.0;
            c.frame = 0xe;
            c.timer = 0;
            c.stopMotion();
            c.shakeScreen(0xf, 0xa);
            c.seRequest = 0x16;
            applyDirectDamage(c, 1400, 900.0);
            o.w140 = 0;
            o.onStateChange();
            o.state = 0x62;
            d.w04 = 0x190;
            d.x = ftol(c.x);
            d.y = ftol(c.y);
            d.b20 = 2;
            d.b21 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
            d.w04 = 0;
            frameEffect(d);
            o.hitstop = 0xb4;
            return;
        }
        c.vy = c.vy + c.ay;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 1) {
        o.onStateChange();
        o.state = 0x67;
        holdOpponent(c, -98.0, 0x23);
    }
    if (c.frame === 2) {
        holdOpponent(c, -98.0, 0x21);
        if (c.f3138 > 0) c.timer = 0x96;
    }
    if (c.frame === 3) throwDown(c, 980.0);
    if (c.frame === 6 && c.f3138 < 3) {
        c.f3138++;
        c.frame = 0;
    }
    if (c.frame === 9) {
        c.vy = -7.0;
        c.vx = 0.3;
        c.ay = 0.15;
    }
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function state310(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.startAfterimage(2);
    if (c.frame < 6) c.biasCameraY(0x32, 3);
    if (c.frame > 0x10) c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 1) {
        o.onStateChange();
        o.state = 0x67;
        holdOpponent(c, -98.0, 0x23);
    }
    if (c.frame === 2) {
        holdOpponent(c, -98.0, 0x21);
        if (c.f3138 > 0) c.timer = 0xa5;
    }
    if (c.frame === 3) throwDown(c, 920.0);
    if (c.frame === 6 && c.f3138 < 6) {
        c.f3138++;
        c.frame = 0;
    }
    if (c.frame === 10) {
        o.stopMotion();
        o.onStateChange();
        o.d128 = 1;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0xf;
        d.y = ftol(c.y) - 5;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        o.state = 0x3f;
        o.y = 0.0;
        o.x = c.facing * 0x11 + c.x;
        o.facing = -c.facing;
        o.knockX = 0.0;
        o.knockY = -3.5;
        c.seRequest = 0x1a;
    }
    if (c.frame === 0x10) {
        c.vy = -3.0;
        c.ay = 0.035;
    }
    if (c.frame === 0x1b) {
        c.vy = -2.0;
        c.ay = 0.013;
        c.seRequest = 0x16;
        d.d00 = 1;
        d.w04 = 0x193;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (c.frame === 0x20 && c.f3140 < 0xb) {
        c.frame -= 3;
        c.f3140++;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0xfd;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state311(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) o.onStateChange();
    c.showAltBackground(0xf);
    if (c.frame < 7) {
        c.biasCameraY(0x32, 0x2d);
        o.hitstop = 3;
    }
    if (c.frame === 7) c.biasCameraY(0, 0);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 3 || c.frame === 6) {
        d.w04 = 0;
        d.b2c = 2;
        d.x = ftol(c.x) + c.facing * 0xe + c.random(0, 0x1e);
        d.y = ftol(c.y) + c.random(0, 0x1e) - 0x62;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
    }
    if (c.frame === 1) {
        o.state = 0x67;
        o.onStateChange();
        holdOpponent(c, -101.0, 0x15);
    }
    if (c.frame === 2) {
        holdOpponent(c, -99.0, 0xf);
        c.seRequest = 0x16;
        d.w04 = 0x193;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0xfa;
        d.b20 = 2;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (c.frame === 3) {
        c.shakeScreen(4, 0);
        o.state = 0x64;
        holdOpponent(c, -99.0, 0xf);
    }
    if (c.frame === 4) {
        o.state = 0x67;
        holdOpponent(c, -99.0, 0xf);
    }
    if (c.frame === 5) {
        o.state = 0x64;
        holdOpponent(c, -99.0, 0xf);
    }
    if (c.frame === 6) {
        o.state = 0x67;
        holdOpponent(c, -99.0, 0xf);
    }
    if (c.frame === 7 && c.f3138 > 8) {
        o.onStateChange();
        o.state = 0x3f;
        o.knockX = 0.2;
        o.knockY = -1.9;
        applyDirectDamage(c, 1000, 1000.0);
        c.w16c = 1;
    }
    if (c.frame === 7 && c.f3138 < 9) {
        c.f3138++;
        c.frame = 2;
    }
    if (c.frame === 0x10) {
        d.w04 = 0x1f;
        d.x = ftol(c.x);
        d.y = ftol(c.y) + 4;
        d.b20 = 0;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 1;
        frameEffect(d);
        d.w04 = 0x191;
        d.x = ftol(c.x) + c.facing * 0x28;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b18 = c.facing;
        d.d00 = 1;
        d.b21 = 1;
        frameChild(c, d);
        c.shakeScreen(10, 0x3c);
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
        c.faceOpponent();
    }
}
function stompSpawn(c, d, pat, dx) {
    d.w04 = 0x1f;
    d.x = ftol(c.x);
    d.y = ftol(c.y) + 4;
    d.b20 = 0;
    d.d00 = 1;
    d.b18 = c.facing;
    d.b21 = 1;
    frameEffect(d);
    d.w04 = pat;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b18 = c.facing;
    d.d00 = 1;
    d.b21 = 1;
    frameChild(c, d);
}
function state312(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.showAltBackground(0xf);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 2;
    }
    if (atFrame(c, 6)) {
        c.biasCameraY(0x32, 0x2d);
        c.freeze = 0x78;
        c.superDarken(0xb0, 3);
        superEffect(d, 0x46, 0x40, ftol(c.x) + c.facing * 0x17, ftol(c.y) - 0x1e);
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (atFrame(c, 2)) {
        c.freeze = 0;
        stompSpawn(c, d, 0x192, 0x2d);
    }
    if (atFrame(c, 8)) stompSpawn(c, d, 0x191, 0x28);
    if (c.frame === 2 && c.d168 === 3) {
        c.shakeScreen(6, 0x3c);
        o.hitstop = 500;
        c.showAltBackground(0xf);
    }
    if (atFrame(c, 10)) c.shakeScreen(10, 0x3c);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.d168 !== 3 && c.frame === 6) c.frame = 0xc;
    if (c.frame === 9 || c.frame === 1) c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state313(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.showAltBackground(0xf);
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        if (atFrame(c, 1)) c.meter = s16(c.meter - 3000);
        c.biasCameraY(0x32, 0x2d);
        c.freeze = 0x78;
        c.superDarken(0xb0, 3);
        c.meter = s16(c.meter - 3000);
        superEffect(d, 0x46, 0x40, ftol(c.x) + c.facing * 0x17, ftol(c.y) - 0x1e);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (c.d168 === 6 && c.frame === 2) {
        c.onStateChange();
        c.frame = 3;
        c.d168 = 0;
        c.freeze = 0xa0;
        c.seRequest = 3;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0xa;
        d.y = ftol(c.y) - 0x28;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 3) {
        c.frame = 4;
        return;
    }
    if (c.frame === 4) {
        c.onStateChange();
        c.state = 0x138;
        return;
    }
    if (c.frame >= cnt) endToNeutral(c);
}
registerStates({
    300: (c)=>airSuper(c, {
            level: 0,
            vy: -1.45,
            ay: 0.02,
            child: 0x1a3,
            big: false
        }),
    301: (c)=>airSuper(c, {
            level: 1,
            vy: -1.8,
            ay: 0.013,
            child: 0x193,
            big: false
        }),
    302: (c)=>airSuper(c, {
            level: 2,
            vy: -2.5,
            ay: 0.013,
            child: 0x1a7,
            big: true
        }),
    303: (c)=>groundScatter(c, {
            level: 0,
            loops: 0x1b
        }),
    304: (c)=>groundScatter(c, {
            level: 1,
            loops: 0x27
        }),
    305: (c)=>groundScatter(c, {
            level: 2,
            loops: 0x39
        }),
    306: (c)=>pullSuper(c, {
            level: 0,
            step: 1,
            limit: 0x97,
            next: 0x135
        }),
    307: (c)=>pullSuper(c, {
            level: 1,
            step: 1,
            limit: 0xc9,
            next: 0x136
        }),
    308: (c)=>pullSuper(c, {
            level: 2,
            step: 2,
            limit: 0xc9,
            next: 0x137
        }),
    309: state309,
    310: state310,
    311: state311,
    312: state312,
    313: state313
});
function childTick(c, i) {
    const ch = c.children[i];
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    c.children[i].timer++;
    if (childTick(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function spawnAtChild(c, pat, x, y, blend) {
    const d = childSpawnFrame;
    d.w04 = pat;
    d.x = x;
    d.y = y;
    d.b20 = blend;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function bounceChild(c, i, s) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = c.random(0, s.vxRange) * 0.1 + s.vxBase;
        ch.vy = s.vyBase - c.random(0, s.vyRange) * 0.1;
    }
    ch.vy = ch.vy + 0.05;
    if (!(ch.y < 0.0) && ch.vy > 0.0 && ch.frame === 1) {
        c.freeChild(i);
        return;
    }
    if ((!(ch.y < 0.0) || ch.hitState > 1) && ch.frame === 0) {
        ch.y = ch.y - 1.0;
        ch.frame = 1;
        ch.vy = -1.5;
        spawnAtChild(c, s.child, ftol(ch.x), ftol(ch.y), 0);
        c.voiceRequest = 1;
    }
    childOnce(c, i);
}
function shardChild(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = c.random(0, 10) * 0.1 + 1.5;
        ch.vy = -1.5;
    }
    ch.vy = ch.vy + 0.05;
    if (!(ch.y < 0.0) && ch.vy > 0.0) {
        c.freeChild(i);
        return;
    }
    childOnce(c, i);
}
function child418(c, i) {
    childOnce(c, i);
}
function chainSpawn(c, i, chain, ground) {
    const ch = c.children[i];
    ch.hitsLeft = 1;
    if (ch.frame === 1 && ch.timer === 0 && c.a3248[i] === 0) {
        if (ch.y < -80.0) spawnAtChild(c, chain, ftol(ch.x), ftol(ch.y) + 0x28, 2);
        if (!(ch.y < -80.0)) spawnAtChild(c, ground, ftol(ch.x), 0.0, 2);
        c.a3248[i]++;
    }
}
function child419(c, i) {
    chainSpawn(c, i, 0x1a3, 0x1a5);
    childOnce(c, i);
}
function child421(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3248[i] === 0) {
        spawnAtChild(c, 0x1a6, ftol(ch.x), ftol(ch.y), 2);
    }
    childOnce(c, i);
}
function loopHitChild(c, i, loops) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 1) ch.hitsLeft = 1;
    ch.timer++;
    if (!childTick(c, i)) return;
    if (c.a3148[i] < loops) {
        ch.frame = 0;
        c.a3148[i]++;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child423(c, i) {
    const ch = c.children[i];
    chainSpawn(c, i, 0x1a7, 0x1a9);
    ch.timer++;
    if (!childTick(c, i)) return;
    if (ch.frame < childCount) return;
    if (c.a3248[i] < 3) ch.frame = 0;
    if (c.a3248[i] === 3) c.freeChild(i);
    c.a3248[i]++;
}
function child425(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3248[i] === 0) {
        spawnAtChild(c, 0x1aa, ftol(ch.x), ftol(ch.y), 2);
    }
    ch.timer++;
    if (!childTick(c, i)) return;
    if (ch.frame < childCount) return;
    if (c.a3248[i] < 3) {
        c.a3248[i]++;
        ch.frame = 0;
        return;
    }
    c.freeChild(i);
}
registerChildren({
    411: (c, i)=>bounceChild(c, i, {
            vxRange: 10,
            vxBase: 2.5,
            vyRange: 20,
            vyBase: -1.2,
            child: 0x19c
        }),
    412: shardChild,
    413: (c, i)=>bounceChild(c, i, {
            vxRange: 20,
            vxBase: 1.7,
            vyRange: 10,
            vyBase: -0.5,
            child: 0x19e
        }),
    414: shardChild,
    415: (c, i)=>bounceChild(c, i, {
            vxRange: 10,
            vxBase: 1.0,
            vyRange: 20,
            vyBase: -1.8,
            child: 0x1a0
        }),
    416: shardChild,
    418: child418,
    419: child419,
    421: child421,
    422: (c, i)=>loopHitChild(c, i, 8),
    423: child423,
    425: child425,
    426: (c, i)=>loopHitChild(c, i, 0x1c)
});

export function __logicState(){return {LEVEL_PAT,LEVEL_SOUND};}

export function __installInitialRoots(s){
if(LEVEL_PAT!==s["LEVEL_PAT"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_PAT');
if(LEVEL_SOUND!==s["LEVEL_SOUND"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_SOUND');
}
