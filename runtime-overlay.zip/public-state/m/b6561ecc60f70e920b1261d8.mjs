import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { registerChildren, registerStates } from "./9410f25ccc5489d02b4dd080.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./1d4a8932dc5ab92063658a65.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function drawPart(c, f, x, y, w) {
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    blit(makeRect(x, y, w, f.height), surf, makeRect(0, 0, w, f.height), c.colorKey, false);
}
function patFrame0(c, pattern) {
    return c.patterns[pattern]?.frames[0];
}
function drawStock(c, x1, x2) {
    const f = patFrame0(c, 42);
    if (!f) return;
    drawPart(c, f, c.side === 0 ? x1 - f.offsetX : f.offsetX + x2 - f.width, 0xda - f.offsetY, f.width);
}
export function renderOverlayMisuzu(c) {
    if (c.f3464 > 0) drawStock(c, 0x20, 0x115);
    if (c.f3464 > 1) drawStock(c, 0x2a, 0x10b);
    if (c.f3464 > 2) drawStock(c, 0x34, 0x101);
    if (c.f3460 > 0) {
        const f = patFrame0(c, 43);
        if (f) drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - f.width, 0x1f - f.offsetY, f.width);
    }
    if (c.f3460 > 0) {
        const f = patFrame0(c, 44);
        if (f) {
            const w = Math.trunc(Math.imul(f.width, c.f345c) / 0xbb8);
            drawPart(c, f, c.side === 0 ? 0x31 - f.offsetX : f.offsetX + 0x10f - w, 0x1f - f.offsetY, w);
        }
    }
}
export function tickHookMisuzu(c) {
    const o = c.opponent;
    if (c.f345c > 0) c.f345c = c.f345c - 1;
    if (c.f3460 > 0) {
        o.requestFlash(0xcb, 3);
        c.f3458 = c.f3458 + 1;
        if (c.f3458 > 0x2d - c.f3460 * 7) {
            o.life = o.life - 0xa;
            if (o.life <= 0) o.life = 1;
            c.f3458 = 0;
        }
        if (c.state > 0x31 && c.state < 0x96) {
            c.f3460 = 0;
            c.f345c = 0;
        }
    }
    if (c.f345c <= 0 && c.f3460 > 0 || o.life <= 0) {
        c.f3460 = 0;
        c.f345c = 0;
    }
}
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function addMeter(c, v) {
    c.meter = s16(c.meter + v);
}
function finish(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function rfCostEffect(c, d, x) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    d.w04 = 0x21;
    d.b2c = 0xb;
    d.x = x;
    d.y = ftol(c.y) - 0x32;
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
}
function stateCallA(c, pat) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        addMeter(c, 0xf);
        d.w04 = pat;
        d.x = c.x;
        d.y = c.y - 80.0;
        d.b18 = c.facing;
        d.d00 = 1;
        d.b21 = 1;
        c.voiceRequest = 1;
        frameChild(c, d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    finish(c, cnt);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        if (c.y === 0.0) c.stopMotion();
        rfCostEffect(c, d, ftol(c.x) + c.facing * 0x14);
    }
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        addMeter(c, 0xf);
        d.w04 = 0x195;
        d.x = c.x;
        d.y = c.y - 80.0;
        d.b18 = c.facing;
        d.d00 = 1;
        d.b21 = 1;
        c.voiceRequest = 1;
        frameChild(c, d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    finish(c, cnt);
}
function stateCallLoop(c, pat, air) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        if (air) {
            if (c.y === 0.0) c.stopMotion();
            rfCostEffect(c, d, ftol(c.x) + c.facing * 0x14);
        } else {
            c.stopMotion();
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 5 && c.f3138 < 3) {
        c.frame = c.frame - 2;
        c.f3138 = c.f3138 + 1;
        if (c.f3138 === 1) {
            addMeter(c, 0xf);
            d.w04 = pat;
            d.x = c.facing * 0x1e + c.x;
            d.y = c.y;
            d.b18 = c.facing;
            d.d00 = 1;
            d.b21 = 1;
            frameChild(c, d);
        }
    }
    finish(c, cnt);
}
function stateSoraAttack(c, air) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        if (air) {
            if (c.y === 0.0) c.stopMotion();
            rfCostEffect(c, d, ftol(c.x) + c.facing * 0x14);
        } else {
            c.stopMotion();
        }
    }
    if (atFrame(c, 5)) addMeter(c, 0xf);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    finish(c, cnt);
}
function stateHop(c, p, air) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        if (c.y === 0.0) {
            c.vx = 0.0;
            c.vy = 0.0;
        }
    }
    if (air && atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
        rfCostEffect(c, d, ftol(c.x));
    }
    if (atFrame(c, 8)) {
        d.w04 = 0x1f;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 1;
        frameEffect(d);
        c.vx = p.vx;
        c.vy = p.vy;
        c.ay = 0.035;
        c.w16c = 1;
    }
    if (c.y + c.vx < 0.0) c.vy = c.vy + c.ay;
    c.timer++;
    if (c.frame > 8 && c.y + c.vy > 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
        c.vx = 0.0;
        c.frame = 0x11;
        c.timer = 0;
        return;
    }
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 0xa) c.voiceRequest = p.voice;
    if (c.frame === 0x11) c.frame = c.frame - 2;
    finish(c, cnt);
}
function stateShortHop(c, p, air) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (air && atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
        rfCostEffect(c, d, ftol(c.x));
    }
    if (atStart(c)) {
        c.vx = p.vx;
        c.vy = p.vy;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (c.y + c.vx < 0.0) c.vy = c.vy + c.ay;
    c.timer++;
    if (c.y + c.vy > 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
        c.vx = 0.0;
        c.frame = 9;
        c.timer = 0;
        return;
    }
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 2) c.voiceRequest = p.voice;
    if (c.frame === 9) c.frame = c.frame - 2;
    finish(c, cnt);
}
function stateSummon(c, pat, air) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        if (air) rfCostEffect(c, d, ftol(c.x));
    }
    if (atFrame(c, 0xc)) {
        addMeter(c, 0xf);
        d.w04 = pat;
        d.x = c.x;
        d.y = c.y;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 2;
        frameChild(c, d);
        c.voiceRequest = 6;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    finish(c, cnt);
}
registerStates({
    250: (c)=>stateCallA(c, 0x193),
    251: (c)=>stateCallA(c, 0x194),
    252: state252,
    253: (c)=>stateCallLoop(c, 0x196, false),
    254: (c)=>stateCallLoop(c, 0x197, false),
    255: (c)=>stateCallLoop(c, 0x198, true),
    256: (c)=>stateSoraAttack(c, false),
    257: (c)=>stateSoraAttack(c, false),
    258: (c)=>stateSoraAttack(c, true),
    259: (c)=>stateHop(c, {
            vx: 1.2,
            vy: -1.6,
            voice: 9
        }, false),
    260: (c)=>stateHop(c, {
            vx: 1.4,
            vy: -1.5,
            voice: 9
        }, false),
    261: (c)=>stateHop(c, {
            vx: 1.8,
            vy: -1.6,
            voice: 10
        }, true),
    262: (c)=>stateShortHop(c, {
            vx: 1.2,
            vy: -1.3,
            voice: 9
        }, false),
    263: (c)=>stateShortHop(c, {
            vx: 1.2,
            vy: -1.5,
            voice: 9
        }, false),
    264: (c)=>stateShortHop(c, {
            vx: 1.8,
            vy: -1.3,
            voice: 10
        }, true),
    265: (c)=>stateSummon(c, 0x19d, false),
    266: (c)=>stateSummon(c, 0x1a0, false),
    267: (c)=>stateSummon(c, 0x1a3, true)
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childSetPattern(c, i, pat) {
    const ch = c.children[i];
    ch.pattern = pat;
    ch.frame = 0;
    ch.timer = 0;
}
function child400(c, i) {
    const ch = c.children[i];
    c.f314c = ftol(ch.y);
    c.f3148 = ftol(ch.x);
    ch.facing = c.facing;
    if (c.state === 0x100 && c.frame === 5) {
        childSetPattern(c, i, 0x199);
        return;
    }
    if (c.state === 0x101 && c.frame === 5) {
        childSetPattern(c, i, 0x19a);
        return;
    }
    if (c.state === 0x102 && c.frame === 5) {
        childSetPattern(c, i, 0x19b);
        return;
    }
    if (c.state === 0x139 && c.frame === 2 && c.timer === 0) {
        childSetPattern(c, i, 0x1bb);
        ch.moveWhileFrozen = 1;
        return;
    }
    if (c.state === 0x13a && c.frame === 2 && c.timer === 0) {
        childSetPattern(c, i, 0x1bc);
        ch.moveWhileFrozen = 1;
        return;
    }
    if (c.state === 0x13b) {
        childSetPattern(c, i, 0x1bd);
        ch.moveWhileFrozen = 1;
        return;
    }
    ch.vx = (c.x - c.facing * 0x2d - ch.x) / 640.0 * 12.0 * ch.facing;
    if (ch.vx < 0.02 && ch.vx > -0.02) ch.vx = 0.0;
    if (ch.vx < -1.6) ch.vx = -1.6;
    if (ch.vx > 1.6) ch.vx = 1.6;
    ch.vy = (c.y - 100.0 - ch.y) / 480.0 * 12.0;
    if (ch.vy < 0.002 && ch.vy > -0.002) ch.vy = 0.0;
    if (ch.vy > 0.6) ch.vy = 0.6;
    if (ch.vy < -0.6) ch.vy = -0.6;
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) ch.frame = 0;
}
function childOnce(c, i) {
    const ch = c.children[i];
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childSoraDash(c, i, fall) {
    const ch = c.children[i];
    c.f3148 = ftol(ch.x);
    c.f314c = ftol(ch.y);
    c.f3150 = 1;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.hitsLeft = 1;
        c.voiceRequest = 4;
    }
    if (ch.frame < 4) ch.vy = ch.vy + fall;
    if (ch.frame === 4 && ch.timer === 0) {
        c.voiceRequest = 5;
        ch.vy = 0.0;
        ch.vx = 4.0;
    }
    if (ch.frame > 4) ch.vx = ch.vx - 0.06;
    if (ch.vx < 0.0) ch.vx = 0.0;
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.pattern = 0x190;
        c.f3150 = 0;
    }
}
function child411(c, i) {
    const ch = c.children[i];
    c.f3148 = ftol(ch.x);
    c.f314c = ftol(ch.y);
    c.f3150 = 1;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.hitsLeft = 5;
        c.voiceRequest = 4;
    }
    if (ch.frame < 4) ch.vy = ch.vy + 0.04;
    if (ch.frame > 4) ch.vx = ch.vx - 0.015;
    if (ch.vx < 0.0) ch.vx = 0.0;
    if (!childAdvance(c, i)) return;
    if (ch.frame === 4) {
        ch.vy = 1.0;
        ch.vx = 3.4;
        c.voiceRequest = 5;
        const d = childSpawnFrame;
        d.w04 = 0x19c;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (ch.frame === 5 && ch.y < 0.0) ch.frame = ch.frame - 1;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.pattern = 0x190;
        c.f3150 = 0;
    }
}
function child412(c, i) {
    const ch = c.children[i];
    ch.x = c.f3148;
    ch.y = c.f314c;
    if (c.f314c > 0) {
        c.freeChild(i);
        return;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) ch.frame = 0;
}
function childCharge(c, i, ownState, next, voice) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y;
    if (c.frame > 0x18 || c.state > 0x31 && c.state < 0x96 || c.state !== ownState) {
        c.freeChild(i);
        return;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame === 0xb) {
        const d = childSpawnFrame;
        d.w04 = next;
        d.x = ch.x;
        d.y = ch.y - 55.0;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        c.voiceRequest = voice;
        frameChild(c, d);
    }
    if (ch.frame >= childCount) ch.frame = ch.frame - 2;
}
function childChargeRelease(c, i, next) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) c.a3158[i] = 0;
    if (c.state > 0x31 && c.state < 0x96 || c.state > 0x108 && c.state < 0x10c && c.frame === 0) {
        c.a3158[i] = 1;
    }
    if (!childAdvance(c, i)) return;
    if (ch.frame === 0xa && c.a3158[i] !== 1) {
        const d = childSpawnFrame;
        d.w04 = next;
        d.x = ch.x;
        d.y = ch.y;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function childFeather(c, i, p) {
    const ch = c.children[i];
    if (c.a3158[i] === 0) {
        ch.vx = p.vx;
        ch.vy = p.vy;
        c.a3158[i] = c.a3158[i] + 1;
        ch.hitsLeft = 1;
    }
    c.a3258[i] = c.a3258[i] + 1;
    const end = c.state > 0x31 && c.state < 0x96 || c.a3358[i] > p.loops || ch.hitState > 0 || c.a3258[i] > 0x4b0 || c.state > 0x108 && c.state < 0x10c && c.frame === 0 || ch.x > 760.0 || !(ch.x >= -120.0);
    if (end) {
        ch.timer = 0;
        ch.frame = 0;
        ch.pattern = 0x1a8;
        ch.vx = 0.0;
        ch.vy = 0.0;
        if (ch.hitState === 3) {
            c.f3460 = c.f3460 + 1;
            if (p.accumulate) {
                if (c.f345c === 0) {
                    c.f345c = 0xbb8;
                } else {
                    c.f345c = c.f345c + 0x3e8;
                    if (c.f345c > 0xbb8) c.f345c = 0xbb8;
                }
            } else {
                c.f345c = 0xbb8;
            }
        }
        if (c.f3460 > 5) c.f3460 = 5;
        return;
    }
    if (c.a3158[i] === 1) {
        ch.vy = ch.vy + 0.01;
        if (ch.vy > 0.0) {
            c.a3158[i] = c.a3158[i] + 1;
            ch.ay = 0.01;
        }
    }
    if (ch.vy > p.vyMax) ch.ay = -0.01;
    if (ch.vy < -0.5) ch.ay = 0.01;
    if (c.a3158[i] > 1) ch.vy = ch.vy + ch.ay;
    if (!childAdvance(c, i)) return;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        c.a3358[i] = c.a3358[i] + 1;
    }
}
registerChildren({
    400: child400,
    401: childOnce,
    402: childOnce,
    409: (c, i)=>childSoraDash(c, i, 0.025),
    410: (c, i)=>childSoraDash(c, i, 0.02),
    411: child411,
    412: child412,
    413: (c, i)=>childCharge(c, i, 0x109, 0x19e, 7),
    414: (c, i)=>childChargeRelease(c, i, 0x1c8),
    415: (c, i)=>childFeather(c, i, {
            vx: 0.125,
            vy: -1.35,
            loops: 0x14,
            vyMax: 0.5,
            accumulate: true
        }),
    416: (c, i)=>childCharge(c, i, 0x10a, 0x1a1, 7),
    417: (c, i)=>childChargeRelease(c, i, 0x1c9),
    418: (c, i)=>childFeather(c, i, {
            vx: 0.15,
            vy: -1.5,
            loops: 6,
            vyMax: 0.7,
            accumulate: true
        }),
    419: (c, i)=>childCharge(c, i, 0x10b, 0x1a4, 8),
    420: (c, i)=>childChargeRelease(c, i, 0x1ca),
    421: (c, i)=>childFeather(c, i, {
            vx: 0.2,
            vy: -1.5,
            loops: 0x12,
            vyMax: 0.58,
            accumulate: true
        }),
    422: (c, i)=>childFeather(c, i, {
            vx: 0.4,
            vy: -1.7,
            loops: 0x12,
            vyMax: 0.58,
            accumulate: true
        }),
    423: (c, i)=>childFeather(c, i, {
            vx: 0.3,
            vy: -1.6,
            loops: 0x12,
            vyMax: 0.7,
            accumulate: false
        }),
    424: childOnce
});
