import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { registerChildren, registerStates } from "./5ebc1d602888d5d1fbd12f34.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./1ced9d0c06b49387c5b9e1d5.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function drawIcon(c, pattern, xOf) {
    const f = c.patterns[pattern]?.frames[0];
    if (!f) return;
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    const src = makeRect(0, 0, f.width, f.height);
    const dst = makeRect(xOf(f.offsetX), 0xbf - f.offsetY, f.width, f.height);
    blit(dst, surf, src, c.colorKey, false);
}
export function renderOverlayNayuki(c) {
    drawIcon(c, 44, (ox)=>c.side === 0 ? 2 - ox : ox + 0x118);
    drawIcon(c, 34 + c.f3148, (ox)=>c.side === 0 ? 2 - ox : 0x118 - ox);
}
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
const LEVEL_PAT = [
    0x44,
    0x45,
    0x46
];
const LEVEL_SOUND = [
    0x13,
    5,
    0x40
];
function superEffect(c, d, level) {
    d.w04 = LEVEL_PAT[level];
    d.b2c = LEVEL_SOUND[level];
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 0x28;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function summonSuper(c, level) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame < 3) c.biasCameraY(0x32, 3);
    if (atFrame(c, 2)) {
        superFreeze(c, (level + 1) * 1000);
        superEffect(c, d, level);
        if (level === 2) c.seRequest = 0x25;
    }
    if (level === 2) {
        if (c.frame > 2) c.showAltBackground(0xf);
    } else if (c.frame >= 2) {
        c.wF2 = 0xa;
    }
    if (atFrame(c, 4)) {
        d.d00 = 1;
        d.w04 = 0x196 + level;
        d.x = ftol(c.x) + c.facing * 0xe;
        d.y = ftol(c.y) - 0x29;
        d.b20 = 0;
        d.b21 = 0;
        d.d28 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.voiceRequest = 0;
    }
    c.timer++;
    if (!(c.timer >= dur || c.frame === 5 && c.timer === dur - c.f3148 * 6)) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function flySuper(c, level, speed, loops) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        superFreeze(c, (level + 1) * 1000);
        superEffect(c, d, level);
        if (level === 2) c.seRequest = 0x25;
    }
    if (level === 2 && c.frame > 3) c.showAltBackground(0xf);
    if (c.frame === 6 || c.frame === 7) {
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.inputY === -1) c.vy = -speed;
        if (c.inputY === 1) c.vy = speed;
        if (c.inputX === c.facing) c.vx = speed;
        if (c.inputX === -c.facing) c.vx = -speed;
    }
    if (c.frame > 7) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 7 && c.frame < 0xc) {
        c.stopMotion();
        c.y = 0.0;
        c.frame = 0xc;
        c.timer = 0;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 6) {
        d.d00 = 1;
        d.w04 = 0x19d;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x50;
        d.b18 = c.facing;
        d.b20 = 0;
        d.b21 = 1;
        frameChild(c, d);
        d.w04 = 0x19e;
        d.y = ftol(c.y);
        frameChild(c, d);
    }
    if (c.frame === 8) {
        if (c.f3138 < loops) {
            c.frame -= 2;
            c.f3138++;
        } else {
            c.ay = 0.015;
        }
    }
    if (c.frame === 0xc) c.frame -= 2;
    if (c.frame >= cnt) {
        c.state = 7;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state306(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 0x63;
    }
    if (c.frame > 0xe) c.vx = c.vx + 0.035;
    c.biasCameraY(0x32, 3);
    if (atStart(c)) {
        superFreeze(c, 0xbb8);
        superEffect(c, d, 2);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (c.frame > 2) c.showAltBackground(0xf);
    if (c.frame > 0xa && c.frame < 0xf) c.shakeScreen(3, 0xa);
    if (c.wallBlock() !== 0 && c.frame > 0xe && c.vx > 4.0) {
        c.vx = -2.7;
        c.vy = -3.5;
        c.ay = 0.035;
        c.state = 0x101;
        c.onStateChange();
        c.seRequest = 0x1f;
        d.w04 = 0;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        d.w04 = 0x19b;
        d.x = ftol(c.x) + c.facing * 0x32;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        d.w04 = 0x19b;
        d.x = ftol(c.x) - c.facing * 0x32;
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        return;
    }
    if (atFrame(c, 0xc)) {
        d.w04 = 0x1f;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 1;
        d.d1c = c.facing === -1 ? 1 : 0;
        frameEffect(d);
    }
    if (atFrame(c, 0xf)) {
        d.w04 = 0x1f;
        d.x = ftol(c.x) + c.facing * 0x14;
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 1;
        d.d1c = c.facing === -1 ? 1 : 0;
        frameEffect(d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 0xf) {
        if (c.f3138 < 0xa) {
            c.frame -= 4;
            c.f3138++;
        } else {
            d.w04 = 0x34;
            d.x = ftol(c.x);
            d.y = ftol(c.y) - 0x19;
            d.b20 = 2;
            d.b21 = 1;
            d.b2c = 0x16;
            frameEffect(d);
            c.vx = 0.5;
            c.shakeScreen(0xf, 0xa);
            d.d00 = 1;
            d.w04 = 0x1a1;
            d.x = ftol(c.x);
            d.y = ftol(c.y);
            d.b20 = 0;
            d.b21 = 0;
            d.d28 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
        }
    }
    if (c.frame >= cnt) c.frame -= 4;
}
registerStates({
    300: (c)=>summonSuper(c, 0),
    301: (c)=>summonSuper(c, 1),
    302: (c)=>summonSuper(c, 2),
    303: (c)=>flySuper(c, 0, 0.5, 0xe),
    304: (c)=>flySuper(c, 1, 0.65, 0x14),
    305: (c)=>flySuper(c, 2, 0.8, 0x14),
    306: state306
});
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    if (childStep(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function spawnChildAt(c, pat, x, y) {
    const d = childSpawnFrame;
    d.w04 = pat;
    d.x = x;
    d.y = y;
    d.b18 = c.facing;
    d.b20 = 2;
    d.b21 = 1;
    frameChild(c, d);
}
function dropStart(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.3;
        ch.vy = -1.2;
        c.voiceRequest = 0;
    }
    if (ch.frame === 0) {
        ch.vy = ch.vy + 0.045;
        if (ch.vy + ch.y > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.frame = 1;
            ch.layer = 1;
        }
    }
}
function child406(c, i) {
    const ch = c.children[i];
    dropStart(c, i);
    if (ch.frame === 5 && ch.timer === 0x1e) {
        c.shakeScreen(5, 0);
        spawnChildAt(c, 0x199, ftol(ch.x), ftol(ch.y));
        c.voiceRequest = 1;
    }
    childOnce(c, i);
}
function child407(c, i) {
    const ch = c.children[i];
    dropStart(c, i);
    if (ch.frame === 5 && ch.timer === 0x18) {
        c.shakeScreen(0xa, 0);
        spawnChildAt(c, 0x19a, ftol(ch.x) + 0x28, ftol(ch.y));
        c.voiceRequest = 1;
    }
    if (ch.frame === 5 && ch.timer === 0x1e) {
        spawnChildAt(c, 0x19a, ftol(ch.x) - 0x28, ftol(ch.y));
    }
    childOnce(c, i);
}
function child408(c, i) {
    const ch = c.children[i];
    dropStart(c, i);
    if (ch.frame === 5 && ch.timer === 0x13) {
        c.shakeScreen(0xf, 0);
        spawnChildAt(c, 0x19b, ftol(ch.x), ftol(ch.y) + 0xf);
        c.voiceRequest = 1;
    }
    if (ch.frame === 5 && ch.timer === 0x18) {
        spawnChildAt(c, 0x19b, ftol(ch.x) + 0x32, ftol(ch.y) - 0xa);
    }
    if (ch.frame === 5 && ch.timer === 0x1e) {
        spawnChildAt(c, 0x19b, ftol(ch.x) - 0x32, ftol(ch.y) - 0xa);
    }
    childOnce(c, i);
}
function childScatter(c, i, chance) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 1;
    }
    if (ch.frame < 0xc && c.random(0, 0x64) < chance) {
        const d = childSpawnFrame;
        d.w04 = 0x19c;
        const base = ch.x - 50.0;
        d.x = ftol(c.random(0, 0x64) + base);
        d.y = ftol(ch.y - c.random(0, 0x64));
        d.b20 = 2;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
    }
    childOnce(c, i);
}
function child412(c, i) {
    const ch = c.children[i];
    if (!(c.a315c[i] > 0)) {
        const d = childSpawnFrame;
        d.w04 = 0x22;
        d.x = ftol(ch.x) + (0x14 - c.random(0, 0x28)) * c.facing;
        d.y = ftol(ch.y) + 0x14 - c.random(0, 0x28);
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.a315c[i] = 2;
    }
    c.a315c[i]--;
    childOnce(c, i);
}
function childFollow(c, i, upper) {
    const ch = c.children[i];
    if ((c.state === 0x12f || c.state === 0x130 || c.state === 0x131) && c.frame < 8) {
        ch.x = c.x;
        ch.y = upper ? c.y - 80.0 : c.y;
    } else {
        ch.frame = 0;
        ch.timer = 0;
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.pattern = 0x195;
    }
    if (upper) {
        c.f314c = ftol(ch.x);
        c.f3154 = ftol(ch.y);
    } else {
        c.f3150 = ftol(ch.x);
        c.f3158 = ftol(ch.y);
    }
    if (ch.frame === 0 && ch.timer === 0 && !(c.a315c[i] > 0)) {
        const d = childSpawnFrame;
        d.w04 = upper ? 0x19f : 0x1a0;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y);
        d.b20 = 2;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
        c.a315c[i] = 3;
        if (c.state === 0x130) c.a315c[i] = 2;
        if (c.state === 0x131) c.a315c[i] = 1;
    }
    if (childStep(c, i) && ch.frame >= childCount) {
        ch.frame = 0;
        c.a315c[i]--;
    }
}
function childTrail(c, i, upper) {
    const ch = c.children[i];
    if (c.state === 0x12f || c.state === 0x130 || c.state === 0x131) {
        ch.x = upper ? c.f314c : c.f3150;
        ch.y = upper ? c.f3154 : c.f3158;
    }
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 2;
    }
    childOnce(c, i);
}
function child417(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && c.a315c[i] === 0) {
        c.a315c[i] = 1;
        ch.vx = -1.9;
        ch.vy = -2.5;
        ch.ay = 0.035;
    }
    ch.vy = ch.vy + ch.ay;
    if (!childStep(c, i)) return;
    if (ch.frame === 7) ch.blend = 1;
    if (ch.frame >= childCount) c.freeChild(i);
}
function childBounce(c, i, vx) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = vx;
        ch.vy = -3.5;
        ch.ay = 0.045;
    }
    ch.vy = ch.vy + ch.ay;
    if (ch.vy + ch.y > 0.0) ch.shadow = 0;
    if (ch.hitState > 1) {
        ch.timer = 0;
        ch.hitState = 0;
        ch.frame = 1;
        ch.vy = -1.5;
        ch.vx = -ch.vx * 0.5;
        ch.ay = 0.035;
    }
    if (ch.y > 60.0) c.freeChild(i);
    childOnce(c, i);
}
function child430(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.vx = 1.5;
    if (c.state !== 0x7b || c.frame > 2) c.freeChild(i);
    ch.vy = ch.vy + 0.02;
    if (childStep(c, i) && ch.frame >= childCount) ch.frame--;
}
registerChildren({
    405: childOnce,
    406: child406,
    407: child407,
    408: child408,
    409: (c, i)=>childScatter(c, i, 0xe),
    410: (c, i)=>childScatter(c, i, 0xc),
    411: (c, i)=>childScatter(c, i, 0xa),
    412: child412,
    413: (c, i)=>childFollow(c, i, true),
    414: (c, i)=>childFollow(c, i, false),
    415: (c, i)=>childTrail(c, i, true),
    416: (c, i)=>childTrail(c, i, false),
    417: child417,
    427: (c, i)=>childBounce(c, i, 0.3),
    428: (c, i)=>childBounce(c, i, 0.8),
    429: (c, i)=>childBounce(c, i, 1.3),
    430: child430
});

export function __logicState(){return {LEVEL_PAT,LEVEL_SOUND};}

export function __installInitialRoots(s){
if(LEVEL_PAT!==s["LEVEL_PAT"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_PAT');
if(LEVEL_SOUND!==s["LEVEL_SOUND"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_SOUND');
}
