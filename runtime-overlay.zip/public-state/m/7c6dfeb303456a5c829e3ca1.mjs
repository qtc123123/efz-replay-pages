import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./dfcb3299a1af62aa24eb2aa0.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./e4446f6179e9bf5107313c92.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
const w16 = (v)=>v & 0xffff;
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function attackStart(c, meter, se, hits) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = hits;
}
function fxAtSelf(c, d, pat, dy, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x);
    d.y = ftol(c.y) + dy;
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function cancelOk(c, cond) {
    return cond === "ge2" ? c.d168 >= 2 : c.d168 === 3;
}
function groundJumpCancel(c, cond) {
    if (c.inputY === -1 && c.frame > 0 && c.d15c < 3 && cancelOk(c, cond)) {
        jumpTo456(c);
        return true;
    }
    return false;
}
function airJumpCancel(c, cond, face) {
    if (c.inputY !== -1 || c.frame <= 0 || c.d15c >= 3 || !cancelOk(c, cond) || c.b15a !== 0) return false;
    if (face) c.faceOpponent();
    c.b15a = c.b15a + 1 & 0xff;
    c.state = 14;
    if (c.inputX === c.facing) c.state = 15;
    if (c.inputX === -c.facing) c.state = 16;
    c.d168 = 0;
    c.onStateChange();
    return true;
}
function groundNormalPrologue(c, decel) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - decel;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function stance1Prologue(c) {
    c.startAfterimage(3);
    c.vx = c.vx - 0.032;
    c.b158 = 0;
    if (c.vx < 0.0) c.vx = 0.0;
}
function endGround(c, base, crouch, face) {
    c.state = base;
    if (crouch && c.inputY === 1) c.state = 3;
    if (face) c.faceOpponent();
    c.onStateChange();
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function burstFx(c, d) {
    fxAtSelf(c, d, 9, -60, 2, 1);
    c.w16c = 1;
    c.seRequest = 62;
}
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        burstFx(c, d);
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 6)) {
        c.stopMotion();
        burstFx(c, d);
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 12) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.startAfterimage(3);
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (atStart(c)) {
        c.vy = 0.0;
        c.ay = 0.0;
    }
    c.vx = 1.7;
    c.b158 = 1;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f3140 = c.f3140 + 1.0;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) {
            c.frame = 0;
            return;
        }
    }
    if (c.inputX === c.facing && c.f3140 >= 100.0) c.setState(178);
    if (c.inputX !== c.facing && c.f3138 >= 60) c.setState(178);
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(2);
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if ((c.frame === 5 || c.frame === 6) && c.vy + c.y > 0.0) {
        c.timer = 0;
        c.stopMotion();
        c.frame = 7;
        c.y = 0.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 3) {
            c.vx = -2.0;
            c.vy = -1.3;
            c.voiceRequest = 1;
            c.ay = 0.04;
        }
        if (c.frame === 7) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.faceOpponent();
            c.setState(0);
        }
    }
}
function airDash(c, fwd, vx0, vx3, vxEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = vx0;
        c.vy = -0.4;
        if (fwd) {
            c.startAfterimage(3);
            c.ay = 0.0;
        } else {
            c.ay = 0.0;
            c.startAfterimage(3);
        }
        c.seRequest = 20;
    }
    if (atFrame(c, 3)) {
        c.vx = vx3;
        c.vy = 0.0;
        c.startAfterimage(3);
        c.ay = 0.0;
        c.seRequest = 20;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f3140 = c.f3140 + 1.0;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 3) c.frame = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    const hold = fwd ? c.facing : -c.facing;
    if (c.inputX === hold && c.f3140 >= 120.0) {
        c.setState(9);
        c.vx = vxEnd;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
    if (c.inputX !== hold && c.f3138 >= 48) {
        c.setState(9);
        c.vx = vxEnd;
        c.ay = 0.03;
        if (c.faceOpponent()) c.vx = -c.vx;
    }
}
const s165 = (c)=>airDash(c, true, 1.2, 1.8, 0.9);
const s166 = (c)=>airDash(c, false, -1.2, -1.8, -0.9);
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.showAltBackground(0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 0, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 0, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 0, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f3140 = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3148 === 0.0) {
        c.f3148 = c.f3148 + 1.0;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f3140 * 0.01;
    }
    if (c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f3140 = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 0, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f3140 * 0.01;
            if (c.ay === 0.0) c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.06;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.vx === 0.0) {
        c.setState(0);
        return;
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.frame = 0;
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 7) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 7;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 3) {
            c.voiceRequest = 1;
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 7) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function groundNormal(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundNormalPrologue(c, p.decel);
    if (p.cancel !== null && groundJumpCancel(c, p.cancel)) return;
    if (atFrame(c, p.atk)) attackStart(c, p.meter, p.se, p.hits);
    if (advance(c, dur)) {
        if (c.frame < p.clearBelow) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, p.end, p.crouch, p.face);
    }
}
const gn = (decel, cancel, atk, meter, se, clearBelow, end, crouch)=>(c)=>groundNormal(c, {
            decel,
            cancel,
            atk,
            meter,
            se,
            hits: 1,
            clearBelow,
            end,
            crouch,
            face: true
        });
const s200 = gn(0.06, "ge2", 2, 5, 21, 3, 0, false);
const s201 = gn(0.06, "ge2", 1, 15, 20, 4, 0, false);
const s202 = gn(0.03, "eq3", 2, 15, 20, 4, 0, false);
const s203 = gn(0.06, "eq3", 3, 35, 20, 6, 0, false);
const s204 = gn(0.06, "ge2", 1, 5, 21, 3, 0, true);
const s210 = gn(0.06, "ge2", 2, 5, 21, 3, 0, false);
const s211 = gn(0.06, "eq3", 1, 15, 20, 3, 0, false);
const s212 = gn(0.03, null, 2, 15, 20, 3, 0, false);
const s213 = gn(0.06, null, 3, 35, 20, 3, 0, false);
const s214 = gn(0.06, "ge2", 1, 5, 21, 3, 0, true);
const s228 = gn(0.06, "eq3", 4, 15, 20, 3, 0, false);
const s242 = gn(0.06, "ge2", 2, 5, 21, 3, 0, false);
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundNormalPrologue(c, 0.06);
    if (groundJumpCancel(c, "eq3")) return;
    if (atFrame(c, 2)) attackStart(c, 13, 20, 99);
    if (atFrame(c, 3)) c.seRequest = 20;
    if (advance(c, dur)) {
        if (s16(c.w16c) > 0) c.d168 = 0;
        if (c.frame === 5 && c.f3138 < 3) {
            c.f3138++;
            c.frame = 3;
        }
        if (c.frame >= cnt) endGround(c, 0, true, true);
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    if (atFrame(c, 2)) {
        c.vx = c.vx + 1.7;
        attackStart(c, 25, 20, 1);
    }
    if (c.vx > 0.0) c.vx = c.vx - 0.035;
    else c.vx = 0.0;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s215(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundNormalPrologue(c, 0.06);
    if (groundJumpCancel(c, "ge2")) return;
    if (atFrame(c, 2)) attackStart(c, 13, 20, 1);
    if (atFrame(c, 3)) c.seRequest = 20;
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, true, true);
    }
}
function s216(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0) {
        c.vx = c.vx - 0.04;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (atStart(c)) c.w16c = 7;
    if (atFrame(c, 2)) {
        addMeter(c, 25);
        c.seRequest = 20;
    }
    if (advance(c, dur)) {
        if (s16(c.w16c) > 0) c.d168 = 0;
        if (c.frame === 9 && c.f3138 === 0) {
            c.f3138++;
            c.frame = w16(c.frame - 2);
        }
        if (c.frame >= cnt) endGround(c, 0, true, true);
    }
}
function s243(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundNormalPrologue(c, 0.06);
    if (groundJumpCancel(c, "ge2")) return;
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (atFrame(c, 2)) attackStart(c, 5, 21, 1);
        if (c.frame >= cnt) endGround(c, 3, false, true);
    }
}
function airNormal(c, cond, face, atk, meter, se, hits, clearBelow) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c, cond, face)) return;
    if (atFrame(c, atk)) attackStart(c, meter, se, hits);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return;
    }
    if (advance(c, dur)) {
        if (c.frame < clearBelow) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s207 = (c)=>airNormal(c, "ge2", false, 1, 5, 21, 1, 3);
const s208 = (c)=>airNormal(c, "ge2", false, 1, 13, 20, 1, 4);
const s217 = (c)=>airNormal(c, "ge2", true, 1, 5, 21, 1, 3);
const s218 = (c)=>airNormal(c, "ge2", true, 1, 13, 20, 1, 3);
const s219 = (c)=>airNormal(c, "ge2", true, 2, 30, 20, 1, 3);
const s227 = (c)=>airNormal(c, "eq3", true, 1, 5, 21, 1, 3);
const s229 = (c)=>airNormal(c, "ge2", true, 2, 30, 20, 1, 3);
function s209(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (airJumpCancel(c, "ge2", false)) return;
    if (atFrame(c, 2)) attackStart(c, 30, 20, 3);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return;
    }
    if (advance(c, dur)) {
        if (s16(c.w16c) > 0) c.d168 = 0;
        if (c.frame === 6 && c.f3138 < 1) {
            c.f3138++;
            c.frame = w16(c.frame - 2);
        }
        if (c.frame >= cnt) c.setState(9);
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        if (o.x > 600.0) o.x = 600.0;
        if (o.x < 40.0) o.x = 40.0;
        c.onStateChange();
        o.onStateChange();
        c.state = 221;
        o.state = 107;
        const d = openSpawnFrame();
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x25;
        d.y = ftol(c.y) - 42;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.x = o.x - s16(o.pointsX[0]) * c.facing;
        c.y = s16(o.pointsY[0]) + 0x39 + c.y;
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 7, true, true);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    const d = openSpawnFrame();
    if (atStart(c)) {
        o.state = 107;
        c.x = o.x - s16(o.pointsX[0]) * c.facing;
        c.y = s16(o.pointsY[0]) + 0x39 + c.y;
        c.d168 = 0;
    }
    if ((c.f3138 > 600 && c.frame === 3 || o.life <= 0) && c.frame < 5) {
        c.facing = -c.facing;
        o.onStateChange();
        o.stopMotion();
        o.state = 98;
        o.y = 0.0;
        o.onStateChange();
        c.timer = 0;
        c.frame = 5;
        c.ay = 0.035;
        applyDirectDamage(c, 400, 1000.0);
        return;
    }
    if (c.frame > 2 && c.frame < 5) {
        c.f3140 = c.f3140 + 1.0;
        c.f3138++;
    }
    if (c.f3140 > 70.0 && c.frame < 5 && o.life > 0) {
        c.f3140 = 0.0;
        c.frame = 4;
        c.timer = 0;
    }
    if (atFrame(c, 4)) {
        o.hitstop = 30;
        c.f3140 = 0.0;
        d.w04 = 0;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 54;
        d.b20 = 2;
        d.b2c = 2;
        d.b21 = 1;
        frameEffect(d);
        applyDirectDamage(c, 100, 1000.0);
    }
    if (c.frame > 4) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy > 0.0) {
            c.stopMotion();
            c.y = 0.0;
            c.timer = 0;
            c.frame = 7;
        }
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 3) {
            d.w04 = 454;
            d.x = ftol(c.x);
            d.y = ftol(c.y);
            d.b20 = 0;
            d.d00 = 1;
            d.b18 = c.facing;
            d.b21 = 0;
            d.d28 = 1;
            frameChild(c, d);
        }
        if (c.frame === 5) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function s223(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.stopMotion();
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 2) {
            c.vx = 1.0;
            c.vy = 1.0;
            c.ay = 0.0;
            c.voiceRequest = 3;
            addMeter(c, 20);
            c.w16c = 1;
        }
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.y < 0.0 && c.vx > 0.0) {
        c.vx = c.vx + 0.035;
        c.vy = c.vy + 0.035;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.setState(224);
    }
}
function s224(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = 0.0;
    c.d168 = 3;
    c.vx = c.vx - 0.08;
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur) && c.frame >= cnt) endGround(c, 0, true, false);
}
function s225(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.w16c = 1;
    }
    if (atFrame(c, 3)) {
        c.vx = 2.0;
        addMeter(c, 15);
        c.seRequest = 20;
    }
    c.vx = c.vx - 0.05;
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur) && c.frame >= cnt) endGround(c, 0, true, false);
}
function stance1Normal(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stance1Prologue(c);
    if (p.cancel === "before" && groundJumpCancel(c, "eq3")) return;
    if (atStart(c)) c.vy = 0.0;
    if (atFrame(c, p.atk)) attackStart(c, p.meter, p.se, 1);
    if (p.cancel === "after" && groundJumpCancel(c, "eq3")) return;
    if (advance(c, dur)) {
        if (c.frame < p.clearBelow) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, p.end, p.crouch, p.face);
    }
}
const s1n = (cancel, atk, meter, se, clearBelow, end, crouch, face)=>(c)=>stance1Normal(c, {
            cancel,
            atk,
            meter,
            se,
            clearBelow,
            end,
            crouch,
            face
        });
const s230 = s1n(null, 1, 5, 21, 3, 0, false, false);
const s231 = s1n("after", 1, 10, 20, 4, 0, false, false);
const s232 = s1n(null, 1, 10, 20, 2, 0, false, false);
const s233 = s1n(null, 1, 5, 21, 3, 3, false, false);
const s234 = s1n(null, 0, 13, 20, 2, 0, true, true);
const s236 = s1n(null, 1, 5, 21, 3, 0, false, false);
const s237 = s1n("before", 1, 10, 20, 4, 0, false, false);
const s238 = s1n(null, 1, 10, 20, 6, 0, false, false);
const s239 = s1n(null, 1, 5, 21, 3, 7, true, false);
const s240 = s1n(null, 1, 10, 20, 4, 7, true, false);
function s235(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (atStart(c)) {
        c.ax = 0.0;
        c.w16c = 1;
    }
    if (atFrame(c, 2)) {
        c.seRequest = 21;
        c.vx = 2.3;
    }
    if (c.vx > 0.0) {
        c.vx = c.vx - 0.03;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function s241(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    stance1Prologue(c);
    if (atStart(c)) c.w16c = 7;
    if (atFrame(c, 2)) {
        addMeter(c, 25);
        c.seRequest = 20;
    }
    if (advance(c, dur)) {
        if (s16(c.w16c) > 0) c.d168 = 0;
        if (c.frame === 9 && c.f3138 < 3) {
            c.f3138++;
            c.frame = w16(c.frame - 2);
        }
        if (c.frame >= cnt) endGround(c, 7, true, true);
    }
}
registerStates({
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    215: s215,
    216: s216,
    217: s217,
    218: s218,
    219: s219,
    220: s220,
    221: s221,
    223: s223,
    224: s224,
    225: s225,
    227: s227,
    228: s228,
    229: s229,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    234: s234,
    235: s235,
    236: s236,
    237: s237,
    238: s238,
    239: s239,
    240: s240,
    241: s241,
    242: s242,
    243: s243
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    return true;
}
function child400(c, i) {
    const ch = c.children[i];
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = 0.5;
        ch.vy = -2.8;
    }
    ch.vy = ch.vy + 0.05;
    if (ch.y >= 0.0 && ch.vy > 0.0 || ch.hitState > 1) {
        ch.frame = 1;
        ch.vy = -1.5;
        const d = childSpawnFrame;
        d.w04 = 401;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        d.w04 = 402;
        frameChild(c, d);
        d.w04 = 403;
        frameChild(c, d);
        c.voiceRequest = 2;
        c.freeChild(i);
        return;
    }
    if (childAdvance(c, i) && ch.frame >= cnt) c.freeChild(i);
}
function debrisTail(c, i) {
    const ch = c.children[i];
    const cnt = childCount;
    ch.vy = ch.vy + 0.05;
    if (ch.y >= 0.0 && ch.vy > 0.0) {
        c.freeChild(i);
        return;
    }
    if (childAdvance(c, i) && ch.frame >= cnt) c.freeChild(i);
}
const coin = ()=>rand("src/game/chars/mio/states_template_b.ts:1197:20", {
        consumer: "src/game/chars/mio/states_template_b.ts"
    }) < 16000 ? 1 : 0;
function child401(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        const t = -1.0 - coin() * 0.5;
        ch.vx = t - coin() * 1.0;
        ch.vy = -1.5;
    }
    debrisTail(c, i);
}
function child402(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        const t = coin() * 0.5 + 1.0;
        ch.vx = coin() * 1.0 + t;
        ch.vy = -1.1;
    }
    debrisTail(c, i);
}
function child403(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        const t = coin() * 0.5;
        ch.vx = t - coin() * 1.0;
        ch.vy = -1.3;
    }
    debrisTail(c, i);
}
function flyStraight(c, i, vx) {
    const ch = c.children[i];
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.hitsLeft = 1;
        ch.vx = vx;
        c.a3158[i] = c.a3158[i] + 1;
    }
    if (childAdvance(c, i) && ch.frame >= cnt) ch.frame = 0;
    if (ch.x < -420.0 || ch.x > 1060.0) c.freeChild(i);
}
function child454(c, i) {
    const ch = c.children[i];
    const cnt = childCount;
    ch.frame = 0;
    if (c.frame === 4) ch.frame = 1;
    if (childAdvance(c, i) && ch.frame >= cnt) ch.frame = 0;
    if (!(c.state === 221 && c.frame <= 4)) c.freeChild(i);
}
registerChildren({
    400: child400,
    401: child401,
    402: child402,
    403: child403,
    420: (c, i)=>flyStraight(c, i, 2.3),
    421: (c, i)=>flyStraight(c, i, 2.6),
    423: (c, i)=>flyStraight(c, i, 3.0),
    454: child454
});

export function __logicState(){return {s200,s201,s202,s203,s204,s210,s211,s212,s213,s214,s228,s242,s230,s231,s232,s233,s234,s236,s237,s238,s239,s240};}

export function __installInitialRoots(s){
if(s200!==s["s200"])throw Error('INITIAL_CONST_IDENTITY:s200');
if(s201!==s["s201"])throw Error('INITIAL_CONST_IDENTITY:s201');
if(s202!==s["s202"])throw Error('INITIAL_CONST_IDENTITY:s202');
if(s203!==s["s203"])throw Error('INITIAL_CONST_IDENTITY:s203');
if(s204!==s["s204"])throw Error('INITIAL_CONST_IDENTITY:s204');
if(s210!==s["s210"])throw Error('INITIAL_CONST_IDENTITY:s210');
if(s211!==s["s211"])throw Error('INITIAL_CONST_IDENTITY:s211');
if(s212!==s["s212"])throw Error('INITIAL_CONST_IDENTITY:s212');
if(s213!==s["s213"])throw Error('INITIAL_CONST_IDENTITY:s213');
if(s214!==s["s214"])throw Error('INITIAL_CONST_IDENTITY:s214');
if(s228!==s["s228"])throw Error('INITIAL_CONST_IDENTITY:s228');
if(s242!==s["s242"])throw Error('INITIAL_CONST_IDENTITY:s242');
if(s230!==s["s230"])throw Error('INITIAL_CONST_IDENTITY:s230');
if(s231!==s["s231"])throw Error('INITIAL_CONST_IDENTITY:s231');
if(s232!==s["s232"])throw Error('INITIAL_CONST_IDENTITY:s232');
if(s233!==s["s233"])throw Error('INITIAL_CONST_IDENTITY:s233');
if(s234!==s["s234"])throw Error('INITIAL_CONST_IDENTITY:s234');
if(s236!==s["s236"])throw Error('INITIAL_CONST_IDENTITY:s236');
if(s237!==s["s237"])throw Error('INITIAL_CONST_IDENTITY:s237');
if(s238!==s["s238"])throw Error('INITIAL_CONST_IDENTITY:s238');
if(s239!==s["s239"])throw Error('INITIAL_CONST_IDENTITY:s239');
if(s240!==s["s240"])throw Error('INITIAL_CONST_IDENTITY:s240');
}
