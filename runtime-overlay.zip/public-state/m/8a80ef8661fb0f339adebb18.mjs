// Runtime-neutral qualified completed-update clock, ordered consumption log,
// Revival RNG and logical side-effect observer. Offline test host only.
export function createHookHost(seed,phase){
 if(!Number.isInteger(seed)||seed<1||seed>2147483646)throw Error('RNG_SEED');
 let started=false,index=0,pending=null,pair=null,state=seed,calls=0,recurrences=0,effectOrdinal=0,volume=0,events=[],renders=0,waits=0;
 function event(kind,data={}){if(events.length>=16384)throw Error('EVENT_BOUND');events.push({kind,...data});}
 const hooks={
  activeSession:()=>started,startSession(){if(started)throw Error('DUPLICATE_START');started=true;},
  beforeSeedRandom(){throw Error('PRESESSION_RNG');},
  readInput(player){if(!pair)throw Error('INPUT_IDLE');const value=pair[player];event('input',{player,value});return value;},
  auxiliary(code){if(!pair)throw Error('AUX_IDLE');const bit={F4:256,F5:512,Escape:8192}[code]??0,value=!!((pair[0]|pair[1])&bit);event('aux',{code,value});return value;},
  random(callsite,context={}){
   if(!pair)throw Error('RNG_IDLE');if(typeof callsite!=='string')throw Error('RNG_SITE');const preState=state,preRecurrences=recurrences;
   do{state=state*48271%2147483647;recurrences++;}while(state-1>0x3fffffff);
   const value=(state-1)&32767;calls++;
   event('rng',{callsite,context,sourceIndex:index,phase:phase(),preState,postState:state,value,callOrdinal:calls,recurrenceDelta:recurrences-preRecurrences,recurrenceOrdinal:recurrences});return value;
  },
  rngState:()=>state,
  now(){const value=(pending??index)*15.625;event('clock',{value});return value;},
  effect(e){if(e.kind==='setBGMVolume'&&e.args[0]>=-10000&&e.args[0]<=0)volume=e.args[0];event('effect',{...e,ordinal:effectOrdinal++});},
  render(){if(++renders>4096)throw Error('BOUNDARY_BOUND');event('compatibility');},
  wait(ms){if(++waits>4096)throw Error('WAIT_BOUND');event('wait',{ms});},
  resourceDecision(e){event('resourceDecision',e);},
 };
 return Object.freeze({hooks,
  begin(input){if(pair)throw Error('HOST_BUSY');pair=[...input];pending=index+1;events=[];renders=0;waits=0;event('sourceInput',{index,pair:[...pair]});},
  complete(){if(!pair)throw Error('HOST_IDLE');index=pending;pending=null;pair=null;},
  install(s){if(pair||pending!==null)throw Error('HOST_BUSY');started=s.started;index=s.completed;pending=null;pair=null;state=s.rng.state;calls=s.rng.calls;recurrences=s.rng.recurrences;effectOrdinal=s.effectOrdinal;volume=s.volume;events=s.events;renders=s.renders;waits=s.waits;},
  snapshot(){return {started,completed:index,pending,pair,rng:{state,calls,recurrences},effectOrdinal,volume,renders,waits,events};},
 });
}
