import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./2d89f5a5c2e93d6456ad7e4a.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame, setPolarVelocityChar } from "./59adbef650633f2bfaadb9d3.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function hitStart(c, se, hits) {
    c.seRequest = se;
    c.w16c = hits;
}
function fxAt(c, d, pat, dx, dy, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x) + dx;
    d.y = ftol(c.y) + dy;
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function groundJumpCancel(c, ok) {
    if (c.inputY !== -1 || c.frame <= 0 || c.d15c >= 3 || !ok) return false;
    jumpTo456(c);
    return true;
}
function airJumpCancel(c) {
    if (c.inputY !== -1 || c.frame <= 0 || c.d15c >= 3 || c.d168 < 2 || c.b15a !== 0) return false;
    c.b15a = c.b15a + 1 & 0xff;
    c.state = 14;
    if (c.inputX === c.facing) c.state = 15;
    if (c.inputX === -c.facing) c.state = 16;
    c.d168 = 0;
    c.onStateChange();
    return true;
}
function slide(c) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx -= 0.03;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGround(c, base, crouchable) {
    c.state = base;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function landTo13(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return true;
    }
    return false;
}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        c.b158 = 0;
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy += c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAt(c, d, 8, 0, 0, 2, 0);
    } else {
        c.vy += c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        fxAt(c, d, 9, 0, -70, 2, 1);
        c.w16c = 1;
        c.seRequest = 62;
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 4)) {
        c.stopMotion();
        fxAt(c, d, 9, 0, -70, 2, 1);
        c.w16c = 1;
        c.seRequest = 62;
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 15) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.startAfterimage(3);
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (atStart(c)) {
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 3) c.vx = 1.5;
    c.b158 = 1;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) {
            c.frame = w16(c.frame - 3);
            return;
        }
    }
    if (c.inputX === c.facing && c.f313c >= 80) c.setState(178);
    if (c.inputX !== c.facing && c.f3138 >= 60) c.setState(178);
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(2);
    c.b158 = 0;
    if (atStart(c) && c.f3138 === 0) {
        c.stopMotion();
        c.vx = -3.1;
        c.vy = 0.0;
        c.ay = 0.0;
        c.f3138 = 1;
        c.seRequest = 17;
    }
    if (c.frame > -1) c.vx += 0.04;
    if (c.vx >= 0.0 && c.frame > -1) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.setState(0);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.frame = 0;
}
function airDashEnd(c, vx, ay) {
    c.setState(9);
    c.vx = vx;
    c.ay = ay;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = 1.1;
        c.startAfterimage(3);
        c.vy = 0.0;
        c.ay = 0.0;
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = 0;
    }
    if (c.inputX === c.facing && c.f313c >= 120) airDashEnd(c, 0.9, 0.02);
    if (c.inputX !== c.facing && c.f3138 >= 48) airDashEnd(c, 0.9, 0.02);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -1.1;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = 0;
    }
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9, 0.02);
    if (c.inputX !== -c.facing && c.f3138 >= 48) airDashEnd(c, -0.9, 0.03);
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(0xb0, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAt(c, d, 1, 0, 0, 2, 1);
    }
    if (atFrame(c, 2)) fxAt(c, d, 4, 0, 0, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAt(c, d, 8, 0, 0, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        if (c.ay === 0.0) c.ay = 0.035;
        c.vx = 0.0;
        c.vy = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atStart(c)) {
        c.seRequest = 18;
        fxAt(c, d, 1, 0, 0, 2, 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            if (c.ay === 0.0) c.ay = 0.02;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx -= 0.03;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 9) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 9;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 2) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 9) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function groundNormal(c, jc, hitFrame, se, keepFrom, crouchable) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c);
    if (jc !== null && groundJumpCancel(c, jc(c))) return;
    if (atFrame(c, hitFrame)) hitStart(c, se, 1);
    if (advance(c, dur)) {
        if (c.frame < keepFrom) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, crouchable);
    }
}
const jcGe2 = (c)=>c.d168 >= 2;
const jcEq3 = (c)=>c.d168 === 3;
const jcHit = (c)=>c.d168 > 0 && c.d168 !== 6;
const s200 = (c)=>groundNormal(c, jcGe2, 2, 21, 3, false);
const s201 = (c)=>groundNormal(c, jcHit, 1, 20, 4, false);
const s202 = (c)=>groundNormal(c, null, 4, 20, 6, false);
const s203 = (c)=>groundNormal(c, jcEq3, 4, 20, 6, false);
const s204 = (c)=>groundNormal(c, jcGe2, 1, 21, 3, true);
const s205 = (c)=>groundNormal(c, jcGe2, 2, 20, 4, true);
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c);
    if (atFrame(c, 1)) hitStart(c, 21, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, true);
    }
}
function s207(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 2)) hitStart(c, 21, 1);
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s208(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 3)) hitStart(c, 20, 2);
    if (atFrame(c, 8)) c.seRequest = 20;
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame === 4 || c.frame === 9) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s209(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, 2)) c.w16c = 5;
    if (atFrame(c, 7)) c.seRequest = 20;
    if (atFrame(c, 10)) c.seRequest = 20;
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame === 7 || c.frame === 9 || c.frame === 11 || c.frame === 13) c.d168 = 0;
        if (c.frame === 14 && c.f3138 < 1) {
            c.f3138++;
            c.frame = w16(c.frame - 7);
        }
        if (c.frame >= cnt) c.setState(9);
    }
}
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (atFrame(c, 8)) {
        d.w04 = 409;
        d.x = ftol(c.x) + c.facing * 0x96;
        d.y = -40.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.f3138++;
        c.voiceRequest = 2;
        addMeter(c, -20);
    }
    if (advance(c, dur)) {
        if (c.frame < 8) c.d168 = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 3)) {
        c.vx = 1.2;
        c.vy = 1.2;
    }
    if (atFrame(c, 1)) c.w16c = 1;
    if (landTo13(c)) return;
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 1);
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0) slide(c);
    if (atFrame(c, 1)) {
        c.vx = 2.6;
        hitStart(c, 20, 1);
    }
    if (c.frame > 0) c.vx -= 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 4 && c.f3138 < 3) {
            c.f3138++;
            c.frame = w16(c.frame - 2);
        }
        if (c.frame >= cnt) endGround(c, 7, true);
    }
}
function airDive(c, angle, speed) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) c.w16c = 1;
    if (c.y + c.vy >= 0.0 && c.frame < 5) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 5;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 1) c.d168 = 0;
        if (c.frame === 3) setPolarVelocityChar(c, angle, speed);
        if (c.frame === 5) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 7;
            c.faceOpponent();
        }
    }
}
const s213 = (c)=>airDive(c, 30.0, 2.2);
const s214 = (c)=>airDive(c, 45.0, 1.7);
const s215 = (c)=>airDive(c, 60.0, 1.5);
const s217 = (c)=>groundNormal(c, null, 4, 20, 6, false);
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atFrame(c, 2) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 2 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = 221;
        o.state = 107;
        d.w04 = 0;
        d.y = -52.0;
        d.x = ftol(c.facing * 0x23 + c.x);
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 7, true);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atFrame(c, 2)) {
        o.hitstop = 30;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x4a;
        d.y = ftol(c.y) - 0x36;
        d.b20 = 2;
        d.b2c = 2;
        d.b21 = 1;
        frameEffect(d);
        applyDirectDamage(c, 1000, 750.0);
        o.onStateChange();
        o.state = 63;
        o.knockX = -2.0;
        o.knockY = -1.5;
    }
    if (advance(c, dur)) {
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.setState(0);
            c.faceOpponent();
        }
    }
}
function afterimageNormal(c, jc, hitFrame, se, hits, keepFrom, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (jc && groundJumpCancel(c, c.d168 === 3)) return;
    c.vx -= 0.01;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atStart(c)) {
        c.vy = 0.0;
        c.vx = 1.2;
    }
    if (atFrame(c, hitFrame)) hitStart(c, se, hits);
    if (advance(c, dur)) {
        if (keepFrom < 0 || c.frame < keepFrom) c.d168 = 0;
        if (c.frame >= cnt) c.setState(end);
    }
}
const s230 = (c)=>afterimageNormal(c, false, 1, 21, 1, 3, 0);
const s231 = (c)=>afterimageNormal(c, true, 4, 20, 1, 6, 0);
const s232 = (c)=>afterimageNormal(c, true, 2, 20, 1, 3, 0);
const s233 = (c)=>afterimageNormal(c, false, 1, 21, 1, 3, 3);
const s234 = (c)=>afterimageNormal(c, false, 2, 21, 1, 3, 3);
const s235 = (c)=>afterimageNormal(c, false, 2, 21, 6, -1, 3);
function s248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.vy += c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 249;
        o.state = 100;
        fxAt(c, d, 0, c.facing * 0x1d, -0x3e, 2, 1);
        o.x = c.facing * 0x1d + c.x;
        o.y = c.y - 62.0;
        c.biasCamera(50, 3);
        c.biasCameraY(50, 3);
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 209;
            c.frame = 2;
        }
    }
}
function s249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (c.frame < 5) c.biasCamera(50, 3);
    if (c.frame < 5) c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy += c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 5) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.state = 13;
        return;
    }
    if (c.frame === 2) {
        o.y = c.y - 47.0;
        o.x = c.facing * 0x1c + c.x;
        o.state = 101;
    }
    if (c.frame === 3) {
        o.y = c.y - 38.0;
        o.x = c.facing * 0x14 + c.x;
        o.state = 101;
        o.facing = c.facing;
    }
    if (c.frame === 4) {
        o.y = c.y - 62.0;
        o.x = c.facing * 0x1d + c.x;
        o.state = 100;
        o.facing = c.facing;
    }
    if (atFrame(c, 5)) {
        o.y = c.y - 72.0;
        o.x = c.x;
        o.state = 63;
        o.facing = c.facing;
        applyDirectDamage(c, 1200, 500.0);
        o.onStateChange();
        o.knockX = -1.0;
        o.knockY = -2.3;
    }
    if (atFrame(c, 12)) c.ay = 0.035;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
registerStates({
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    215: s215,
    217: s217,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    234: s234,
    235: s235,
    248: s248,
    249: s249
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    return true;
}
function cPlain(c, i) {
    if (childAdvance(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function childAtChild(c, i, pat, dx) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    d.w04 = pat;
    d.x = ftol(ch.x) + dx;
    d.y = ftol(ch.y);
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function c400(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0) ch.hitsLeft = 1;
    if (childAdvance(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function c401(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 1;
        c.a3174[i]++;
        ch.vx = 3.0;
    }
    if (ch.hitState > 0) {
        childAtChild(c, i, 403, 0);
        c.f316c--;
        c.freeChild(i);
        return;
    }
    if (ch.x > 680.0 || ch.x < -40.0) {
        c.freeChild(i);
        c.f316c--;
    }
    ch.vx -= 0.03;
    if (ch.vx < 1.5) ch.vx = 1.5;
    if (childAdvance(c, i) && ch.frame >= childCount) ch.frame = 6;
}
function c402(c, i) {
    const ch = c.children[i];
    if (childAdvance(c, i)) {
        if (ch.frame === 1) childAtChild(c, i, 401, ch.facing * 0x28);
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function c403(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.frame === 0) ch.hitsLeft = 1;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function c404(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 1;
        c.a3174[i]++;
        ch.vy = -3.0;
        ch.vx = 0.0;
    }
    if (ch.vx === 0.0) {
        ch.vy += 0.045;
        if (ch.vy > 0.0) ch.vy = 0.0;
    }
    if (ch.hitState > 0 || ch.y > 0.0) {
        childAtChild(c, i, 405, 0);
        c.freeChild(i);
        return;
    }
    if (childAdvance(c, i)) {
        if (ch.frame === 16) {
            if (c.a3174[i] < 4) {
                ch.frame = 0;
                c.a3174[i]++;
                return;
            }
            ch.vx = 3.0;
            ch.vy = 0.8;
            ch.hitsLeft = 1;
        }
        if (ch.frame >= childCount) ch.frame = w16(ch.frame - 1);
    }
}
function c409(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 1;
        c.a3174[i]++;
    }
    if (c.state === 210) c.d168 = ch.hitState;
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        if (ch.frame === 1) ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function c410(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 1;
        c.a3174[i]++;
    }
    if (childAdvance(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function c411(c, i) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        c.a3174[i]++;
        ch.vy = -0.2;
    }
    if (ch.frame === 1) ch.blend = 1;
    if (childAdvance(c, i) && ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    400: c400,
    401: c401,
    402: c402,
    403: c403,
    404: c404,
    405: cPlain,
    406: cPlain,
    407: cPlain,
    408: cPlain,
    409: c409,
    410: c410,
    411: c411
});
