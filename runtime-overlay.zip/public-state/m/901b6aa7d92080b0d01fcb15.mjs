import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { registerChildren, registerStates } from "./72fceafa5789cf9e4e3cf0ff.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./f2e83919002a3a51b71740fe.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { requestGameSpeed } from "./11a8544a0f705ad2a3ee4f96.mjs";
function drawGauge(c, pattern, len) {
    const f = c.patterns[pattern]?.frames[0];
    if (!f) return;
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    const w = len(f.width);
    const src = makeRect(0, 0, w, f.height);
    const dst = c.side === 0 ? makeRect(0x31 - f.offsetX, 0x1f - f.offsetY, w, f.height) : makeRect(f.offsetX + 0x10f - w, 0x1f - f.offsetY, w, f.height);
    blit(dst, surf, src, c.colorKey, false);
}
export function renderOverlayShiori(c) {
    if (c.f314c > 0) drawGauge(c, 43, (w)=>w);
    if (c.f314c > 0) drawGauge(c, 44, (w)=>Math.trunc(w * c.f314c / 0xe10));
}
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function superEffect(d, pat, sound, x, y) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = x;
    d.y = y;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
const LEVEL_PAT = [
    0x44,
    0x45,
    0x46
];
const LEVEL_SOUND = [
    0x13,
    5,
    0x40
];
function spawnOwned(c, d, pat, x, y, blend) {
    d.d00 = 1;
    d.w04 = pat;
    d.x = x;
    d.y = y;
    d.b18 = c.facing;
    d.b20 = blend;
    d.b21 = 1;
    frameChild(c, d);
}
function state300(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 1) c.showAltBackground(0xf);
    if (atFrame(c, 2)) {
        superFreeze(c, 3000);
        superEffect(d, 0x46, 0x40, ftol(c.x) - c.facing * 0x19, ftol(c.y) - 0x3b);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
        d.w04 = 0x1a3;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x5f;
        d.b20 = 0;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        d.d30 = 1;
        frameChild(c, d);
    }
    if (atFrame(c, 10)) {
        d.d00 = 1;
        d.w04 = 0x19a;
        d.x = ftol(c.x) + c.facing * 0x47;
        d.y = ftol(c.y) - 0x36;
        d.b18 = c.facing;
        d.b20 = 0;
        d.b21 = 1;
        frameChild(c, d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 8) c.x = c.facing * 0x35 + c.x;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function rerollHit(c) {
    if (c.random(0, 0x1e0) > 0xf0 || c.frame === 1) {
        if (c.w16c > 0) c.d168 = 0;
    }
}
function stackVoice(c) {
    if (atFrame(c, 2)) c.voiceRequest = 4;
    if (atFrame(c, 3)) c.voiceRequest = 3;
}
function endToCrouch(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 3;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state303(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        superFreeze(c, 1000);
        superEffect(d, 0x44, 0x13, ftol(c.x), ftol(c.y) - 0x2a);
        c.w16c = 5;
        c.stopMotion();
    }
    if (atFrame(c, 2)) {
        spawnOwned(c, d, 0x1ad, ftol(c.x) - c.facing * 0xf, ftol(c.y), 2);
        d.w04 = 0x1ae;
        frameChild(c, d);
    }
    stackVoice(c);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    rerollHit(c);
    endToCrouch(c, cnt);
}
function stackSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const big = p.level === 1;
    if (atStart(c)) {
        c.b158 = 0;
        superFreeze(c, big ? 3000 : 2000);
        superEffect(d, big ? 0x46 : 0x45, big ? 0x40 : 5, ftol(c.x), ftol(c.y) - 0x2a);
        c.w16c = p.hits;
        if (big) c.seRequest = 0x25;
        c.stopMotion();
    }
    if (big) c.showAltBackground(0xf);
    if (c.f3138 === 0) stackVoice(c);
    if (c.frame > 1 && !(c.f313c > 0) && c.f3140 < 5) {
        d.d00 = 1;
        if (big) d.w04 = 0x1ad;
        d.x = ftol(c.x) - c.facing * 0xf;
        d.y = ftol(c.y);
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        if (c.f3140 === 0) {
            d.w04 = 0x1ae;
            frameChild(c, d);
            if (big) {
                d.w04 = 0x1af;
                frameChild(c, d);
            }
        }
        d.y = c.f3140 * -0x50;
        d.w04 = 0x1ad;
        c.f313c = 0xf;
        c.f3140++;
        frameChild(c, d);
    }
    c.f313c--;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.f3138 < p.loops && c.frame === 10) {
        c.frame -= 6;
        c.f3138++;
    }
    rerollHit(c);
    endToCrouch(c, cnt);
}
function waveSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    c.b158 = 0;
    if (atFrame(c, 3)) {
        superFreeze(c, (p.level + 1) * 1000);
        superEffect(d, LEVEL_PAT[p.level], LEVEL_SOUND[p.level], ftol(c.x) - c.facing * 2, ftol(c.y) - 0x43);
        if (p.level === 2) c.seRequest = 0x25;
    }
    if (p.level === 2 && c.frame > 2) c.showAltBackground(0xf);
    const first = p.level === 0 ? c.f3138 === 0 : c.f313c === 0;
    if (atFrame(c, 6) && first) {
        d.d00 = 1;
        d.w04 = p.child;
        d.x = ftol(c.x) + c.facing * 0x32;
        d.y = 0.0;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
        if (p.level === 0) c.f3138++;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 9 && c.f313c < p.loops) {
        c.f313c++;
        c.frame -= 3;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function gaugeSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    c.b158 = 0;
    if (p.cost > 0 && atFrame(c, 4)) {
        superFreeze(c, p.cost);
        superEffect(d, 9, 5, ftol(c.x) + c.facing * 0x17, ftol(c.y) - 0x1e);
        if (p.cost === 3000) c.seRequest = 0x25;
    }
    if (p.cost === 3000 && c.frame > 3) c.showAltBackground(0xf);
    if (atFrame(c, 5)) {
        c.f314c = p.gauge;
        spawnOwned(c, d, p.child, ftol(c.x), ftol(c.y), 2);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    endToCrouch(c, cnt);
}
function barrageSpawn(c, d, dx, air) {
    d.d00 = 0;
    d.w04 = 0x1b3;
    const r = c.random(0, 2);
    d.x = ftol(c.x) + c.facing * dx - c.facing * 0x30 * (r === 0 ? 1 : 0);
    d.y = air ? ftol(c.y) + c.random(0, 5) - 0x20 : ftol(c.y) - 0x16;
    d.b18 = c.facing;
    d.b20 = 0;
    d.b21 = 1;
    frameChild(c, d);
    d.w04 = 0x1b4;
    d.b18 = c.facing;
    d.b20 = 2;
    frameChild(c, d);
    c.f3138 = 6;
    c.f3140++;
}
function airBarrage(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = c.vx * 0.5;
        c.vy = c.vy * 0.5;
        c.ay = 0.01;
    }
    const activate = ()=>{
        if (!atFrame(c, 1)) return;
        c.f313c = ftol(c.vx * 100.0);
        c.vx = 0.0;
        c.f3140 = ftol(c.vy * 100.0);
        c.vy = 0.0;
        superFreeze(c, (p.level + 1) * 1000);
        superEffect(d, LEVEL_PAT[p.level], LEVEL_SOUND[p.level], ftol(c.x), ftol(c.y) - 0x2a);
        c.stopMotion();
        if (p.level === 2) c.seRequest = 0x25;
    };
    if (p.level === 2) {
        activate();
        if (c.frame > 0) c.showAltBackground(0xf);
    }
    if (c.frame !== 1) c.vy = c.vy + c.ay;
    if (c.frame < 8 && c.vy > 0.2) c.vy = 0.2;
    if (p.level !== 2) activate();
    if (atFrame(c, 2)) {
        c.vx = c.f313c * 0.01;
        c.vy = c.f3140 * 0.01;
        c.f3138 = 0;
        c.f313c = 0;
        c.f3140 = 0;
    }
    if (c.frame > 4 && c.frame < 8 && !(c.f3138 > 0) && c.f3140 < p.shots) barrageSpawn(c, d, 0x1e, true);
    if (atFrame(c, 8)) c.ay = 0.035;
    if (c.frame > 7 && c.y + c.vy > 0.0) {
        c.onStateChange();
        c.state = 0xd;
        return;
    }
    c.f3138--;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 8 && c.f313c < p.loops) {
        c.f313c++;
        c.frame -= 4;
    }
    if (c.frame >= cnt) c.frame -= 2;
}
function groundBarrage(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atFrame(c, 1)) {
        c.b158 = 0;
        superFreeze(c, (p.level + 1) * 1000);
        superEffect(d, LEVEL_PAT[p.level], LEVEL_SOUND[p.level], ftol(c.x), ftol(c.y) - 0x2a);
        c.stopMotion();
        if (p.level === 2) c.seRequest = 0x25;
    }
    if (p.level === 2 && c.frame > 0) c.showAltBackground(0xf);
    if (c.frame > 4 && c.frame < 8 && !(c.f3138 > 0) && c.f3140 < p.shots) barrageSpawn(c, d, 0x11, false);
    c.f3138--;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 8 && c.f313c < p.loops) {
        c.f313c++;
        c.frame -= 4;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state318(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (atFrame(c, 3)) {
        d.w04 = 0x1a3;
        d.x = ftol(c.x) + c.facing * 6;
        d.y = ftol(c.y) - 0x34;
        d.b20 = 0;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = -c.facing;
        d.d30 = 1;
        frameChild(c, d);
    }
    if (c.frame > 2) {
        c.showAltBackground(3);
        c.superDarken(0xb0, 6);
    }
    if (atFrame(c, 4)) {
        superFreeze(c, 3000);
        superEffect(d, 0x46, 0x40, ftol(c.x) + c.facing * 0x1c, ftol(c.y) - 0x33);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (atFrame(c, 11)) spawnOwned(c, d, 0x1b8, ftol(c.x) + c.facing * 0x14, ftol(c.y) - 0x34, 2);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state319(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.w13e = 3;
    if (c.frame < 2) c.superDarken(0xb0, 3);
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 2;
    }
    if (atFrame(c, 1)) {
        c.x = o.x;
        c.vy = -6.5;
    }
    if (c.frame === 1 && c.d168 === 3) {
        c.shakeScreen(5, 0);
        o.x = c.facing + c.x;
        c.stopMotion();
        c.timer = 0;
        c.frame = 2;
        o.frame = 0;
        o.timer = 0;
        o.state = 0x79;
        d.d00 = 1;
        d.w04 = 0x1bd;
        d.x = o.x;
        d.y = o.y;
        d.b18 = c.facing;
        d.b20 = 0;
        d.b21 = 0;
        frameChild(c, d);
    }
    if (c.frame === 2) {
        c.f3138--;
        c.f313c++;
        if (!(c.f3138 > 0)) {
            c.f3138 = 0x18;
            c.y = c.y - 1.0;
            o.y = o.y - 1.0;
        }
        if (c.f313c === 0x168) {
            c.timer = 0;
            c.frame = 3;
            c.d168 = 0;
            c.vy = -3.5;
        }
    }
    if (c.frame === 3 && c.vy > 0.0) {
        c.timer = 0;
        c.frame = 4;
        requestGameSpeed(3);
    }
    if (c.frame >= 3) {
        o.biasCameraY(0x32, 3);
        if (o.state === 0x63) o.timer = 0;
        c.vy = c.vy + 0.035;
        if (c.y + c.vy > 0.0) {
            c.stopMotion();
            c.y = 0.0;
            c.onStateChange();
            c.state = 0xd;
            return;
        }
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) c.frame -= 2;
}
registerStates({
    300: state300,
    303: state303,
    304: (c)=>stackSuper(c, {
            level: 0,
            hits: 0xf,
            loops: 1
        }),
    305: (c)=>stackSuper(c, {
            level: 1,
            hits: 0x1e,
            loops: 3
        }),
    306: (c)=>waveSuper(c, {
            level: 0,
            child: 0x1b5,
            loops: 4
        }),
    307: (c)=>waveSuper(c, {
            level: 1,
            child: 0x1b6,
            loops: 4
        }),
    308: (c)=>waveSuper(c, {
            level: 2,
            child: 0x1b7,
            loops: 3
        }),
    309: (c)=>gaugeSuper(c, {
            cost: 0,
            gauge: 0xe10,
            child: 0x1a7
        }),
    310: (c)=>gaugeSuper(c, {
            cost: 2000,
            gauge: 0x12c0,
            child: 0x1a8
        }),
    311: (c)=>gaugeSuper(c, {
            cost: 3000,
            gauge: 0x12c0,
            child: 0x1a9
        }),
    312: (c)=>airBarrage(c, {
            level: 0,
            shots: 0xf,
            loops: 5
        }),
    313: (c)=>airBarrage(c, {
            level: 1,
            shots: 0x1b,
            loops: 8
        }),
    314: (c)=>airBarrage(c, {
            level: 2,
            shots: 0x32,
            loops: 0xd
        }),
    315: (c)=>groundBarrage(c, {
            level: 0,
            shots: 0xf,
            loops: 5
        }),
    316: (c)=>groundBarrage(c, {
            level: 1,
            shots: 0x1b,
            loops: 8
        }),
    317: (c)=>groundBarrage(c, {
            level: 2,
            shots: 0x32,
            loops: 0xd
        }),
    318: state318,
    319: state319
});
const DEG = 57.29579143313326;
function setPolarVelocity(c, i, angle, speed) {
    const ch = c.children[i];
    ch.vx = __numerics.cos(angle / DEG) * speed;
    ch.vy = __numerics.sin(angle / DEG) * speed;
}
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    if (childStep(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function followBody(c, i) {
    const ch = c.children[i];
    ch.x = c.facing * 0x14 + c.x;
    ch.y = c.y - 52.0;
}
function child419(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && c.a3158[i] === 0) {
        ch.vx = 0.5;
        ch.vy = -0.4;
        c.a3158[i]++;
    }
    ch.vy = ch.vy + 0.005;
    if (c.a3158[i] > 10) ch.blend = 1;
    if (c.a3158[i] > 0xf) c.freeChild(i);
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        ch.frame -= 2;
        c.a3158[i]++;
    }
}
function childPillar(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0) ch.hitsLeft = 1;
    if (ch.frame === 14 && ch.timer === 0) c.voiceRequest = 7;
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.pattern = 0x1b0;
    }
}
function childGauge(c, i, drain) {
    const ch = c.children[i];
    ch.x = c.x;
    ch.y = c.y - 50.0;
    ch.hitsLeft = 1;
    if (c.f314c < 0 && ch.frame < 0x1c) {
        ch.frame = 0x1c;
        ch.timer = 0;
        c.f314c = 0;
        return;
    }
    ch.facing = c.facing;
    ch.hitState = 0;
    c.f314c -= drain;
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 0x1c) ch.frame = 8;
    if (ch.frame >= childCount) {
        c.freeChild(i);
        c.f314c = 0;
    }
}
const bodyActive = (c)=>c.frame < 0x10 && c.state > 200;
function child429(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0x1c && ch.timer === 0 && bodyActive(c)) {
        const d = childSpawnFrame;
        d.d00 = 1;
        d.w04 = 0x1ad;
        d.x = ftol(c.x) - c.facing * 0xf;
        d.y = ch.y;
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
    }
    childOnce(c, i);
}
function childRepeat(c, i, pat) {
    const ch = c.children[i];
    if (ch.frame === 8 && ch.timer === 0 && bodyActive(c)) {
        const d = childSpawnFrame;
        d.d00 = 1;
        d.w04 = pat;
        d.x = ftol(c.x) - c.facing * 0xf;
        d.y = ftol(ch.y);
        d.b18 = c.facing;
        d.b20 = 2;
        d.b21 = 1;
        frameChild(c, d);
    }
    childOnce(c, i);
}
function child435(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && c.a3158[i] === 0) {
        ch.hitsLeft = 1;
        c.a3158[i]++;
        const speed = c.random(0x1e, 0x19) * 0.1;
        const angle = c.random(0, 0x5a) - 0x2d;
        setPolarVelocity(c, i, angle, speed);
    }
    if (ch.x > 660.0 || ch.x < -20.0) c.freeChild(i);
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) ch.frame = 0;
}
function spawnPillar(c, i, pat, y, layer) {
    const d = childSpawnFrame;
    d.d00 = 0;
    d.w04 = pat;
    d.x = ftol(c.children[i].x);
    d.y = y;
    d.b21 = layer;
    d.b18 = c.facing;
    d.b20 = 2;
    frameChild(c, d);
}
function child437(c, i) {
    const ch = c.children[i];
    ch.vx = 1.0;
    if (ch.frame === 0 && ch.timer === 0) spawnPillar(c, i, 0x1a4, 0.0, 1);
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        if (c.a3158[i] < 2) {
            c.a3158[i]++;
            ch.frame = 0;
            return;
        }
        c.freeChild(i);
    }
}
function child438(c, i) {
    const ch = c.children[i];
    if (c.a3358[i] === 0) {
        ch.vx = 1.5;
        c.a3358[i]++;
    }
    if (ch.frame === 0 && ch.timer === 0) spawnPillar(c, i, 0x1a5, 0.0, 1);
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        if (c.a3158[i] < 5) {
            c.a3158[i]++;
            ch.vx = ch.vx + 0.5;
            ch.frame = 0;
            return;
        }
        c.freeChild(i);
    }
}
function child439(c, i) {
    const ch = c.children[i];
    if (c.a3358[i] === 0) {
        ch.vx = 1.5;
        c.a3358[i]++;
    }
    if (ch.frame === 0 && ch.timer === 0) {
        if (c.a3258[i] === 1) spawnPillar(c, i, 0x1a6, -10.0, 0);
        else spawnPillar(c, i, 0x1a6, 10.0, 1);
    }
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        if (c.a3158[i] < 0xe) {
            c.a3158[i]++;
            ch.frame = 0;
            ch.vx = ch.vx + 0.4;
            c.a3258[i] = c.a3258[i] === 0 ? 1 : 0;
            return;
        }
        c.freeChild(i);
    }
}
function child440(c, i) {
    const ch = c.children[i];
    c.biasCameraY(0x32, 3);
    followBody(c, i);
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 0x63;
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.pattern = 0x1b9;
    }
}
function child441(c, i) {
    const ch = c.children[i];
    followBody(c, i);
    c.biasCameraY(0x32, 3);
    c.superDarken(0xb0, 3);
    if (c.state !== 0x13e) {
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 0x1bb;
        return;
    }
    if (ch.hitState === 3 && c.state === 0x13e) {
        ch.pattern = 0x1bc;
        c.f3150 = ftol(c.opponent.x);
        c.f3154 = ftol(c.opponent.y);
        c.onStateChange();
        c.state = 0x13f;
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 0x63;
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        if (c.a3158[i] === 0) {
            c.a3158[i]++;
            ch.frame = 0;
            return;
        }
        ch.frame = 0;
        ch.pattern = 0x1bb;
    }
}
function child443(c, i) {
    followBody(c, i);
    childOnce(c, i);
}
function jitterOpponent(c, yMax) {
    const o = c.opponent;
    o.x = c.f3150 + c.random(0, 0x50) - 0x28;
    o.y = c.f3154 - c.random(10, 0x3c);
    if (o.x > 620.0) o.x = 620.0;
    if (o.x < 20.0) o.x = 20.0;
    if (o.y > yMax) o.y = yMax;
}
function child442(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    c.w13e = 3;
    if (ch.frame > 6) o.biasCameraY(0x32, 3);
    if (ch.frame < 7) o.stopMotion();
    c.superDarken(0xb0, 3);
    if (ch.frame > 0xb) {
        ch.vy = ch.vy + 0.055;
        if (ch.vy > 0.0) ch.vy = 0.0;
    }
    if (!childStep(c, i)) return;
    if (ch.frame < 7) jitterOpponent(c, -10.0);
    if (ch.frame === 7) {
        o.ay = 0.035;
        o.vy = -10.5;
        o.vx = 0.5;
    }
    if (ch.frame === 9) {
        o.x = ch.facing * 0xdd + ch.x;
        o.y = ch.y - 44.0;
    }
    if (ch.frame === 10) {
        o.x = ch.facing * 0xe6 + ch.x;
        o.y = ch.y - 62.0;
    }
    if (ch.frame === 11) {
        o.x = ch.facing * 0xa3 + ch.x;
        o.y = ch.y - 119.0;
    }
    if (ch.frame === 12) {
        o.x = ch.facing * 0x8b + ch.x;
        o.y = ch.y - 160.0;
        ch.vy = -3.0;
    }
    if (ch.frame >= childCount) {
        if (c.a3158[i] === 0) {
            c.a3158[i]++;
            ch.frame = 0;
            return;
        }
        c.freeChild(i);
        c.timer = 0x23a;
    }
}
function child444(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    c.biasCameraY(0x32, 3);
    o.stopMotion();
    c.superDarken(0xb0, 3);
    o.w13c = 0x1e;
    if (!childStep(c, i)) return;
    jitterOpponent(c, -5.0);
    if (ch.frame >= childCount) {
        if (c.a3158[i] === 0) {
            c.a3158[i]++;
            ch.frame = 0;
            return;
        }
        ch.frame = 0;
        ch.pattern = 0x1ba;
    }
}
registerChildren({
    419: child419,
    420: childPillar,
    421: childPillar,
    422: childPillar,
    423: (c, i)=>childGauge(c, i, 4),
    424: (c, i)=>childGauge(c, i, 3),
    425: (c, i)=>childGauge(c, i, 2),
    429: child429,
    430: (c, i)=>childRepeat(c, i, 0x1ae),
    431: (c, i)=>childRepeat(c, i, 0x1af),
    432: childOnce,
    435: child435,
    436: childOnce,
    437: child437,
    438: child438,
    439: child439,
    440: child440,
    441: child441,
    442: child442,
    443: child443,
    444: child444
});

export function __logicState(){return {LEVEL_PAT,LEVEL_SOUND};}

export function __installInitialRoots(s){
if(LEVEL_PAT!==s["LEVEL_PAT"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_PAT');
if(LEVEL_SOUND!==s["LEVEL_SOUND"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_SOUND');
}
