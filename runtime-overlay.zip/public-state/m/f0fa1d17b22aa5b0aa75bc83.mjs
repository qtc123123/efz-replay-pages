import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { createImage } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { readSync } from "./197efe2647ca25903d217eb5.mjs";
export const SCREEN_WIDTH = 320;
export const SCREEN_HEIGHT = 240;
export function makeRect(x, y, w, h) {
    return {
        left: x,
        top: y,
        right: x + w,
        bottom: y + h
    };
}
export function createPalette() {
    return new Uint8Array(256 * 4);
}
export const backBuffer = createImage(SCREEN_WIDTH, SCREEN_HEIGHT);
const activePalette = createPalette();
export function activePaletteForTrace() {
    return activePalette;
}
let ctx = null;
let frame = null;
let frame32 = null;
const lut = new Uint32Array(256);
export function initGraphics(canvas) {}
export function loadPalette(pal, filename, srcStart, start, count) {
    const data = readSync(filename);
    if (!data) return false;
    for(let i = 0; i < count; i++){
        const s = 1 + (srcStart + i) * 3;
        const d = (start + i) * 4;
        if (d + 3 >= pal.length) break;
        pal[d + 0] = data[s + 2] ?? 0;
        pal[d + 1] = data[s + 1] ?? 0;
        pal[d + 2] = data[s + 0] ?? 0;
        pal[d + 3] = 0;
    }
    return true;
}
export function setPalette(pal) {
    activePalette.set(pal.subarray(0, 255 * 4));
}
export function setPaletteRange(pal, start, count) {
    activePalette.set(pal.subarray(start * 4, (start + count) * 4), start * 4);
}
export function setPaletteDarken(pal, start, end, pct) {
    const p = pct & 0xff;
    for(let i = start; i < end && i < 255; i++){
        const o = i * 4;
        for(let c = 0; c < 3; c++)activePalette[o + c] = Math.trunc(pal[o + c] * p / 100) & 0xff;
    }
}
export function setPaletteWhiten(pal, start, end, pct) {
    const p = pct & 0xff;
    for(let i = start; i < end && i < 255; i++){
        const o = i * 4;
        for(let c = 0; c < 3; c++){
            const v = pal[o + c];
            activePalette[o + c] = v + Math.trunc((255 - v) * (100 - p) / 100) & 0xff;
        }
    }
}
export function readColorKey(image) {
    return image.width > 0 && image.height > 0 ? image.pixels[0] : 0;
}
export function blit(dstRect, src, srcRect, colorKey, flipX = false) {
    const d = {
        ...dstRect
    };
    const s = {
        ...srcRect
    };
    const origSrcRight = s.right;
    if (!(d.top < d.bottom && d.left < d.right && s.top < s.bottom && s.left < s.right)) return;
    if (d.top < 0) {
        s.top -= d.top;
        d.top = 0;
    }
    if (d.left < 0) {
        s.left -= d.left;
        d.left = 0;
    }
    if (d.bottom > SCREEN_HEIGHT) {
        s.bottom -= d.bottom - SCREEN_HEIGHT;
        d.bottom = SCREEN_HEIGHT;
    }
    if (d.right > SCREEN_WIDTH) {
        s.right -= d.right - SCREEN_WIDTH;
        d.right = SCREEN_WIDTH;
    }
    if (flipX) {
        const l = origSrcRight - s.right;
        const r = origSrcRight - s.left;
        s.left = l;
        s.right = r;
    }
    if (!(d.top < d.bottom && d.left < d.right && s.top < s.bottom && s.left < s.right)) return;
    const reverse = flipX && colorKey !== 0;
    const w = d.right - d.left;
    const h = d.bottom - d.top;
    const out = backBuffer.pixels;
    const pix = src.pixels;
    for(let y = 0; y < h; y++){
        const sy = s.top + y;
        if (sy < 0 || sy >= src.height) continue;
        const srow = sy * src.pitch;
        const drow = (d.top + y) * backBuffer.pitch + d.left;
        for(let x = 0; x < w; x++){
            const sx = s.left + (reverse ? w - 1 - x : x);
            if (sx < 0 || sx >= src.width) continue;
            const p = pix[srow + sx];
            if (colorKey !== 0 && p === colorKey) continue;
            out[drow + x] = p;
        }
    }
}
const avgTable = new Uint8Array(256 * 256);
const addTable = new Uint8Array(256 * 256);
export var BlendTable = /*#__PURE__*/ function(BlendTable) {
    BlendTable[BlendTable["Average"] = 0] = "Average";
    BlendTable[BlendTable["Add"] = 1] = "Add";
    return BlendTable;
}({});
export function buildBlendTables(pal) {
    avgTable.fill(0);
    addTable.fill(0);
    const sq = (d)=>d * d >> 2;
    const nearest = (r, g, b)=>{
        let best = -1;
        let bestDist = 40000;
        for(let k = 1; k <= 254; k++){
            const o = k * 4;
            const dist = sq(pal[o] - r) + sq(pal[o + 1] - g) + sq(pal[o + 2] - b);
            if (dist < bestDist) {
                bestDist = dist;
                best = k;
            }
        }
        return best;
    };
    for(let i = 0; i < 256; i++){
        const oi = i * 4;
        for(let j = 0; j <= Math.min(i, 254); j++){
            const oj = j * 4;
            const r = pal[oi] + pal[oj];
            const g = pal[oi + 1] + pal[oj + 1];
            const b = pal[oi + 2] + pal[oj + 2];
            const a = nearest(r >> 1, g >> 1, b >> 1);
            if (a >= 0) avgTable[i * 256 + j] = a;
            const s = nearest(Math.min(r, 254), Math.min(g, 254), Math.min(b, 254));
            if (s >= 0) addTable[i * 256 + j] = s;
        }
    }
    for(let i = 0; i < 255; i++){
        for(let j = 0; j < i; j++){
            avgTable[j * 256 + i] = avgTable[i * 256 + j];
            addTable[j * 256 + i] = addTable[i * 256 + j];
        }
    }
}
function clipRects(dstRect, srcRect, flipX) {
    const d = {
        ...dstRect
    };
    const s = {
        ...srcRect
    };
    const origSrcRight = s.right;
    if (!(d.top < d.bottom && d.left < d.right && s.top < s.bottom && s.left < s.right)) return null;
    if (d.top < 0) {
        s.top -= d.top;
        d.top = 0;
    }
    if (d.left < 0) {
        s.left -= d.left;
        d.left = 0;
    }
    if (d.bottom > SCREEN_HEIGHT) {
        s.bottom -= d.bottom - SCREEN_HEIGHT;
        d.bottom = SCREEN_HEIGHT;
    }
    if (d.right > SCREEN_WIDTH) {
        s.right -= d.right - SCREEN_WIDTH;
        d.right = SCREEN_WIDTH;
    }
    if (flipX) {
        const l = origSrcRight - s.right;
        const r = origSrcRight - s.left;
        s.left = l;
        s.right = r;
    }
    if (!(d.top < d.bottom && d.left < d.right && s.top < s.bottom && s.left < s.right)) return null;
    return {
        d,
        s
    };
}
export function blitBlend(dstRect, src, srcRect, colorKey, flipX, table) {
    const c = clipRects(dstRect, srcRect, flipX);
    if (!c) return;
    const { d, s } = c;
    const lut = table === 0 ? avgTable : addTable;
    const w = d.right - d.left;
    const h = d.bottom - d.top;
    const out = backBuffer.pixels;
    for(let y = 0; y < h; y++){
        const sy = s.top + y;
        if (sy < 0 || sy >= src.height) continue;
        const srow = sy * src.pitch;
        const drow = (d.top + y) * backBuffer.pitch + d.left;
        for(let x = 0; x < w; x++){
            const sx = s.left + (flipX ? w - 1 - x : x);
            if (sx < 0 || sx >= src.width) continue;
            const p = src.pixels[srow + sx];
            if (colorKey !== 0 && p === colorKey) continue;
            out[drow + x] = lut[p * 256 + out[drow + x]];
        }
    }
}
export function blitTint(dstRect, src, srcRect, colorKey, flipX, color) {
    const c = clipRects(dstRect, srcRect, flipX);
    if (!c) return;
    const { d, s } = c;
    const w = d.right - d.left;
    const h = d.bottom - d.top;
    const out = backBuffer.pixels;
    for(let y = 0; y < h; y++){
        const sy = s.top + y;
        if (sy < 0 || sy >= src.height) continue;
        const srow = sy * src.pitch;
        const drow = (d.top + y) * backBuffer.pitch + d.left;
        for(let x = 0; x < w; x++){
            const sx = s.left + (flipX ? w - 1 - x : x);
            if (sx < 0 || sx >= src.width) continue;
            const p = src.pixels[srow + sx];
            if (colorKey !== 0 && p === colorKey) continue;
            out[drow + x] = addTable[p * 256 + (color & 0xff)];
        }
    }
}
export function blitShadow(dstRect, src, srcRect, colorKey, flipX, color) {
    const d = {
        ...dstRect
    };
    const s = {
        ...srcRect
    };
    if (!(d.top < d.bottom && d.left < d.right && s.top < s.bottom && s.left < s.right)) return;
    const origSrcRight = s.right;
    if (d.top < 0) d.top = 0;
    if (d.left < 0) {
        s.left -= d.left;
        d.left = 0;
    }
    if (d.bottom > SCREEN_HEIGHT) d.bottom = SCREEN_HEIGHT;
    if (d.right > SCREEN_WIDTH) {
        s.right -= d.right - SCREEN_WIDTH;
        d.right = SCREEN_WIDTH;
    }
    if (flipX) {
        const l = origSrcRight - s.right;
        const r = origSrcRight - s.left;
        s.left = l;
        s.right = r;
    }
    if (d.top > d.bottom || d.left > d.right || s.top > s.bottom || s.left > s.right) return;
    const w = d.right - d.left;
    const h = d.bottom - d.top;
    const out = backBuffer.pixels;
    const lut = color & 0xff;
    let sy = s.bottom - 1;
    let dy = d.top;
    let rows = h - 1;
    do {
        let x = w - 1;
        do {
            const dx = d.left + x;
            if (readMask(src, s.left + (flipX ? w - 1 - x : x), sy, colorKey) && dx >= 0 && dy >= 0 && dy < SCREEN_HEIGHT) {
                const o = dy * backBuffer.pitch + dx;
                out[o] = avgTable[out[o] * 256 + lut];
            }
            x--;
        }while (x >= 0)
        sy -= 3;
        dy++;
        rows--;
    }while (rows >= 0)
}
function readMask(src, sx, sy, colorKey) {
    const i = sy * src.pitch + sx;
    if (i < 0 || i >= src.pixels.length) return true;
    return src.pixels[i] !== colorKey;
}
export function blitDistort(dstRect, src, srcRect, colorKey, flipX) {
    const d = {
        ...dstRect
    };
    const s = {
        ...srcRect
    };
    const origSrcRight = s.right;
    if (!(d.top < d.bottom && d.left < d.right && s.top < s.bottom && s.left < s.right)) return;
    if (d.top < 0) {
        s.top -= d.top;
        d.top = 0;
    }
    if (d.left < 3) {
        s.left -= d.left;
        d.left = 3;
    }
    if (d.bottom > SCREEN_HEIGHT) {
        s.bottom -= d.bottom - SCREEN_HEIGHT;
        d.bottom = SCREEN_HEIGHT;
    }
    if (d.right > SCREEN_WIDTH) {
        s.right -= d.right - SCREEN_WIDTH;
        d.right = SCREEN_WIDTH;
    }
    if (flipX) {
        const l = origSrcRight - s.right;
        const r = origSrcRight - s.left;
        s.left = l;
        s.right = r;
    }
    if (!(d.top < d.bottom && d.left < d.right && s.top < s.bottom && s.left < s.right)) return;
    const w = d.right - d.left;
    const h = d.bottom - d.top;
    const out = backBuffer.pixels;
    for(let y = 0; y < h; y++){
        const sy = s.top + y;
        const drow = (d.top + y) * backBuffer.pitch + d.left;
        for(let x = w - 1; x >= 0; x--){
            if (colorKey !== 0 && !readMask(src, s.left + (flipX ? w - 1 - x : x), sy, colorKey)) continue;
            out[drow + x] = out[drow + x - 3];
        }
    }
}
export function fillRect(rect, color) {
    const x0 = Math.max(rect.left, 0);
    const y0 = Math.max(rect.top, 0);
    const x1 = Math.min(rect.right, SCREEN_WIDTH);
    const y1 = Math.min(rect.bottom, SCREEN_HEIGHT);
    if (x1 <= x0 || y1 <= y0) return;
    for(let y = y0; y < y1; y++){
        backBuffer.pixels.fill(color, y * backBuffer.pitch + x0, y * backBuffer.pitch + x1);
    }
}
export function clear(index = 0) {
    backBuffer.pixels.fill(index);
}
export function present() {
    if (!ctx || !frame || !frame32) return;
    for(let i = 0; i < 256; i++){
        const o = i * 4;
        lut[i] = 0xff000000 | activePalette[o + 2] << 16 | activePalette[o + 1] << 8 | activePalette[o + 0];
    }
    const src = backBuffer.pixels;
    const out = frame32;
    for(let i = 0; i < out.length; i++)out[i] = lut[src[i]];
    ctx.putImageData(frame, 0, 0);
}

export function __logicState(){return {backBuffer,activePalette,ctx,frame,frame32,lut,avgTable,addTable,BlendTable};}
