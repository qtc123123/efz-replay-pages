import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./4f243a87eb42ac119eae883d.mjs";
import { updateChildrenMayu } from "./8a0ae749d7e9ba4d08c1d570.mjs";
import { parseCommandMayu, dispatchMovesMayu } from "./3170591c2d43dde239890822.mjs";
import { thinkMayu } from "./264091127870fdf419a89d3c.mjs";
import "./3cccec9fe5b318ae0dc4d4d9.mjs";
import "./5d6abe4bc00f5ef8174d911d.mjs";
import "./e6fb4a4c179b8926c42c934c.mjs";
import "./a0bc23f3b460a131ef842376.mjs";
const POINTS_X = [
    -8,
    -16,
    14,
    25,
    28
];
const POINTS_Y = [
    -46,
    0,
    -5,
    -19,
    -35
];
export class Mayu extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    a3148 = new Int32Array(64);
    a3248 = new Int32Array(64);
    a3348 = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        0,
        6,
        3,
        4,
        0xff,
        0xff,
        0xff
    ];
    wF2 = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = this.f313c = this.f3140 = this.f3144 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a3148.fill(0);
        this.a3248.fill(0);
        this.a3348.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3148[i] = 0;
        this.a3248[i] = 0;
        this.a3348[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {}
    parseCommand() {
        parseCommandMayu(this);
    }
    dispatchMoves() {
        dispatchMovesMayu(this);
    }
    think() {
        thinkMayu(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMayu(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
