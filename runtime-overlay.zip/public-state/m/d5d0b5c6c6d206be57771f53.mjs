import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./0de4622b5e3457d2a8d81427.mjs";
import { updateChildrenAkane } from "./6237c3c562237f9de4952920.mjs";
import { parseCommandAkane, dispatchMovesAkane } from "./51a08684b04bf40b95804db5.mjs";
import { thinkAkane } from "./08f9b547d520040825e81a02.mjs";
import "./0b0c31d65795205b91e976e2.mjs";
import "./2d38c62e50b547ff28b09872.mjs";
import "./979ac22a23be3fb41c79d2d2.mjs";
import "./e62081fff2bdad0b7a075f03.mjs";
const POINTS_X = [
    -8,
    21,
    0,
    2,
    31
];
const POINTS_Y = [
    -53,
    0,
    -5,
    -13,
    -29
];
export class Akane extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    a314c = new Int32Array(64);
    a324c = new Int32Array(64);
    a334c = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        4,
        2,
        11,
        1,
        18,
        4,
        0xff,
        0xff
    ];
    w0dc = 0;
    b0de = 0;
    dblE8 = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = this.f313c = this.f3140 = this.f3144 = this.f3148 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a314c.fill(0);
        this.a324c.fill(0);
        this.a334c.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a314c[i] = 0;
        this.a324c[i] = 0;
        this.a334c[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {}
    parseCommand() {
        parseCommandAkane(this);
    }
    dispatchMoves() {
        dispatchMovesAkane(this);
    }
    think() {
        thinkAkane(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenAkane(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
