import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { HISTORY_LENGTH, NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { registerChildren } from "./9410f25ccc5489d02b4dd080.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect } from "./1d4a8932dc5ab92063658a65.mjs";
import { ftol } from "./7596266716c972d06fe8897a.mjs";
function hist(c, i) {
    return c.history[i - (i >= HISTORY_LENGTH ? 1 : 0) * HISTORY_LENGTH];
}
function buttonCommand(base, v) {
    return base + ((v & 0xe0) > 0 ? 1 : 0) + ((v & 0xc0) > 0 ? 1 : 0) + ((v & 0x80) > 0 ? 1 : 0);
}
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function cancelable(c) {
    return ((c.currentHit()?.defenseFlags ?? 0) & 8) > 0;
}
function priorityOk(c, s) {
    return (c.patterns[c.state]?.hdrB ?? 0) <= (c.patterns[s]?.hdrA ?? 0);
}
function cancelOk(c) {
    if (c.state >= 200 && c.d168 >= 2 && c.d168 !== 6) return true;
    return c.state < 200;
}
function rfOk(c) {
    return c.rfGauge >= 500.0 || c.rfBlue > 0;
}
function enter(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function moveOk(c, s) {
    return cancelable(c) && cancelOk(c) && priorityOk(c, s);
}
function crouchHeld(c) {
    return c.inputY === 1 || (c.bufferedA & 4) !== 0 || (c.bufferedB & 4) !== 0;
}
function standHeld(c) {
    return c.inputY === 0 || (c.bufferedA & 4) === 0 || (c.bufferedB & 4) === 0;
}
function oppThrowable(c) {
    return c.opponent.state < 50 || c.opponent.state > 156;
}
function partnerNear(c) {
    if (c.f3148 - 0x32 < c.x && c.f3148 + 0x32 > c.x && c.facing === 1) return true;
    return c.f3148 + 0x32 > c.x && c.f3148 - 0x32 < c.x && c.facing === -1;
}
export function parseCommandMisuzu(c) {
    c.command = NO_COMMAND;
    const idx = c.historyIndex;
    const end = idx + HISTORY_LENGTH;
    const left = c.facing === -1 ? 1 : 0;
    const BACK = 2 - left;
    const FWD = 1 + left;
    const DOWN_BACK = 6 - left;
    const DOWN_FWD = 5 + left;
    let step;
    let v;
    step = 0;
    for(let i = idx + 0x2d; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 5) {
            c.command = 0x5d;
            return;
        }
        if (v & 0x20 && step === 4) step = 5;
        if (v & 0xd0 && step === 4) break;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if (v & 0xe0 && step === 2) break;
        if (v & 0x10 && step === 2) step = 3;
        if (v === 0 && step === 1) step = 2;
        if (v & 0xe0 && step === 1) break;
        if (v & 0x10 && step === 0 && c.meter === 3000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x69; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 4) {
            c.command = buttonCommand(0x82, v);
            return;
        }
        if ((v & 0xf) === DOWN_BACK && step === 3) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x82, v);
                return;
            }
            step = 4;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) step = 3;
        if ((v & 0xf) === FWD && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x6e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x6e, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_BACK && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x64, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x64, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_FWD && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x46, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x46, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x3c, v);
            return;
        }
        if ((v & 0xf) === DOWN_BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x3c, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x14, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x14, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x1e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x1e, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0xaf; i < end; i++){
        v = hist(c, i);
        if (v & 8 && step === 1) {
            c.command = 6;
            return;
        }
        if (!(v & 8) && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 4) {
            c.command = 53;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0 && c.state === 96) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 4) {
            c.command = 52;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 4) {
            c.command = 51;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 4) {
            c.command = 50;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 1 && step === 3) {
            c.command = 1;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 1 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 2 && step === 3) {
            c.command = 0;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 2 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
}
function special(c, ok, ground, air) {
    if (!ok || !moveOk(c, ground)) return false;
    enter(c, ground);
    if (air !== 0 && c.y < 0.0) c.state = air;
    return true;
}
function partnerSpecial(c, ok, s, stocked) {
    if (c.f3150 !== 0 || !ok || !cancelable(c) || c.y !== 0.0 || !cancelOk(c) || !priorityOk(c, s)) return false;
    if (!partnerNear(c)) return false;
    enter(c, s);
    if (c.f3464 > 0) c.state = stocked;
    return true;
}
export function dispatchMovesMisuzu(c) {
    const cmd = c.command;
    if (c.state < 200) c.bufferedA = 0;
    if (c.bufferTimer > 0) {
        c.bufferTimer = c.bufferTimer - 1 & 0xff;
    } else {
        c.bufferedB = 0;
    }
    if (c.bufferedB === 0) c.bufferTimer = 0;
    if (cmd === 52 && rfOk(c) && c.d168 > 1 && c.d168 !== 6 && cancelable(c) && priorityOk(c, 167)) {
        enter(c, 167);
        if (c.y < 0.0) c.state = 171;
        return;
    }
    if (c.d15c < 2) {
        const ground = c.y === 0.0;
        if (c.life < 3333 && cmd === 93 && c.meter >= 3000 && ground && c.d168 !== 6 && cancelable(c) && priorityOk(c, 316)) {
            enter(c, 316);
            return;
        }
        if (special(c, cmd === 112 && ground && c.meter >= 3000, 302, 306)) return;
        if (special(c, (cmd === 111 || cmd === 112) && ground && c.meter >= 2000, 301, 305)) return;
        if (special(c, (cmd === 110 || cmd === 111 || cmd === 112) && ground && c.meter >= 1000, 300, 304)) return;
        if (special(c, cmd === 132 && c.meter >= 1000 && ground, 310, 0)) return;
        if (special(c, (cmd === 131 || cmd === 132) && c.meter >= 1000 && ground, 310, 0)) return;
        if (special(c, (cmd === 130 || cmd === 131 || cmd === 132) && c.meter >= 1000 && ground, 310, 0)) return;
        if (special(c, cmd === 102 && ground && c.meter >= 3000, 309, 0)) return;
        if (special(c, (cmd === 101 || cmd === 102) && ground && c.meter >= 2000, 308, 0)) return;
        if (special(c, (cmd === 100 || cmd === 101 || cmd === 102) && ground && c.meter >= 1000, 307, 0)) return;
        if (partnerSpecial(c, cmd === 72 && (rfOk(c) || c.f3464 > 0), 258, 315)) return;
        if (partnerSpecial(c, cmd === 71 || cmd === 72, 257, 314)) return;
        if (partnerSpecial(c, cmd === 70, 256, 313)) return;
        if (special(c, cmd === 22 && rfOk(c), 261, 264)) return;
        if (special(c, cmd === 21 || cmd === 22, 260, 263)) return;
        if (special(c, cmd === 20, 259, 262)) return;
        if (special(c, c.f3474 === 0 && cmd === 32 && rfOk(c) && ground, 252, 0)) return;
        if (special(c, cmd === 62 && rfOk(c) && ground, 267, 0)) return;
        if (special(c, (cmd === 61 || cmd === 62) && ground, 266, 0)) return;
        if (special(c, cmd === 60 && ground, 265, 0)) return;
        if (special(c, c.f3470 === 0 && (cmd === 31 || cmd === 32) && ground, 251, 0)) return;
        if (special(c, c.f346c === 0 && cmd === 30 && ground, 250, 0)) return;
        if (special(c, c.f3480 === 0 && cmd === 12 && rfOk(c) && ground, 255, 0)) return;
        if (special(c, c.f347c === 0 && (cmd === 11 || cmd === 12) && ground, 254, 0)) return;
        if (special(c, c.f3478 === 0 && cmd === 10 && ground, 253, 0)) return;
    }
    if (c.d15c < 1 && (cmd === 0 || cmd === 1)) {
        if (c.y < 0.0 && c.b159 < 1) {
            let dir = 1 - (cmd << 1);
            let dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 165) && c.state !== 170 && c.y < -30.0 && cancelable(c) && cancelOk(c) && c.state !== 253) {
                dash(c, 165, true);
                return;
            }
            dir = 1 - (cmd << 1);
            dx = c.opponent.x - c.x;
            if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && c.state !== 170 && priorityOk(c, 166) && cancelable(c) && cancelOk(c)) {
                dash(c, 166, true);
                return;
            }
        }
        if (c.y === 0.0 && cancelable(c)) {
            let dir = 1 - (cmd << 1);
            let dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 163) && cancelOk(c)) {
                dash(c, 163, false);
                return;
            }
            dir = 1 - (cmd << 1);
            dx = c.opponent.x - c.x;
            if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && priorityOk(c, 164) && cancelOk(c)) {
                dash(c, 164, false);
                return;
            }
        }
    }
    if (c.d15c < 3 && cmd === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && priorityOk(c, 14) && cancelOk(c)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return;
    }
    if (c.pressed[0] === 1 || c.bufferedA & 0x10 || c.bufferedB & 0x10) {
        if (c.y < 0.0) {
            if (moveOk(c, 207)) enter(c, 207);
            return;
        }
        if (crouchHeld(c) && moveOk(c, 204)) {
            enter(c, 204);
            return;
        }
        if (standHeld(c) && moveOk(c, 200)) {
            enter(c, 200);
            return;
        }
    }
    if (c.pressed[1] === 1 || c.bufferedA & 0x20 || c.bufferedB & 0x20) {
        if (c.y < 0.0) {
            if (moveOk(c, 208)) enter(c, 208);
            return;
        }
        if (crouchHeld(c) && moveOk(c, 205)) {
            enter(c, 205);
            return;
        }
        if (standHeld(c)) {
            if (priorityOk(c, 201) && cancelable(c) && c.x - c.opponent.x > -70.0 && c.x - c.opponent.x < 70.0 && cancelOk(c)) {
                enter(c, 201);
                return;
            }
            if (moveOk(c, 202)) {
                enter(c, 202);
                return;
            }
        }
    }
    if (!(c.pressed[2] === 1 || c.bufferedA & 0x40 || c.bufferedB & 0x40)) return;
    if (c.y < 0.0) {
        if (c.inputX === c.facing && c.inputY === 0 && c.x - c.opponent.x > -100.0 && c.x - c.opponent.x < 100.0 && c.opponent.y < 0.0 && priorityOk(c, 248) && oppThrowable(c) && cancelable(c) && cancelOk(c)) {
            enter(c, 248);
            return;
        }
        if (moveOk(c, 209)) enter(c, 209);
        return;
    }
    if (crouchHeld(c) && moveOk(c, 206)) {
        enter(c, 206);
        return;
    }
    if (!standHeld(c)) return;
    if (c.opponent.y === 0.0 && c.inputX !== 0 && c.x - c.opponent.x > -30.0 && c.x - c.opponent.x < 30.0 && priorityOk(c, 220) && oppThrowable(c) && cancelable(c) && cancelOk(c)) {
        enter(c, 220);
        return;
    }
    if (priorityOk(c, 211) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
        enter(c, 211);
        return;
    }
    if (moveOk(c, 203)) enter(c, 203);
}
function dash(c, s, air) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    if (air) {
        c.b159 = c.b159 + 1 & 0xff;
        c.b15a = c.b15a + 1 & 0xff;
    } else {
        c.b158 = c.b158 + 1 & 0xff;
    }
    c.bufferedA = 0;
}
function spawn447(c, i, dy, withD30) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    f.w04 = 0x1bf;
    f.x = ch.x;
    f.y = dy === 0 ? ch.y : ch.y - dy;
    f.b18 = c.facing;
    f.b20 = 2;
    f.b21 = 1;
    if (withD30) f.d30 = 1;
    frameChild(c, f);
}
function partnerLand(c, i) {
    const ch = c.children[i];
    if (ch.frame !== 1) return false;
    ch.vx = 0.7;
    ch.vy += ch.ay;
    if (ch.y > 0.0) {
        ch.y = 0.0;
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.timer = 0;
        ch.frame = 2;
        return true;
    }
    return false;
}
function child443(c, i) {
    const ch = c.children[i];
    c.f3150 = 1;
    if (c.state !== 0x139) ch.moveWhileFrozen = 0;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.ay = 0.05;
        ch.hitsLeft = 0x63;
        spawn447(c, i, 0, true);
    }
    if (partnerLand(c, i)) return;
    if (ch.frame === 0xe && c.freeze === 0 && ch.timer >= 0x1e) {
        ch.timer = 0;
        ch.frame = 0xf;
        ch.moveWhileFrozen = 0;
    }
    if (c.f3138 > 0 && ch.frame === 0) {
        ch.frame = 1;
        ch.timer = 0;
        ch.hitsLeft = 6;
        ch.vy = 0.0;
        ch.vx = 4.0;
    }
    if (ch.frame === 0x1b && ch.timer === 0) spawn447(c, i, 40.0, false);
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    if (ch.frame === 0x15) ch.hitState = 0;
    if (ch.frame === 0x16 && c.a3158[i] < 0xa) {
        ch.frame = ch.frame - 4 & 0xffff;
        c.a3158[i]++;
    }
    if (ch.frame >= childCount) {
        ch.timer = 0;
        ch.frame = 0;
        ch.pattern = 0x190;
        c.a3158[i] = 0;
        c.f3150 = 0;
    }
}
function child444(c, i) {
    const ch = c.children[i];
    c.f3150 = 1;
    if (c.state !== 0x13a) ch.moveWhileFrozen = 0;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.ay = 0.035;
        ch.hitsLeft = 0x63;
        spawn447(c, i, 0, true);
    }
    if (partnerLand(c, i)) return;
    if (ch.frame === 3 && c.freeze === 0) {
        ch.timer = 0;
        ch.frame = 4;
        ch.moveWhileFrozen = 0;
    }
    if (ch.frame === 9 && ch.timer === 0) {
        const f = childSpawnFrame;
        f.w04 = 0x1be;
        f.x = ch.facing * 0x24 + ch.x;
        f.y = ch.y - 56.0;
        f.b18 = ch.facing;
        f.b20 = 0;
        f.b21 = 1;
        frameChild(c, f);
    }
    if (ch.frame === 0xe && ch.timer === 0) c.f3468 = 1;
    if (ch.frame === 0x12 && ch.timer === 0) spawn447(c, i, 40.0, false);
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    if (ch.frame >= childCount) {
        ch.timer = 0;
        ch.frame = 0;
        ch.pattern = 0x190;
        c.a3158[i] = 0;
        c.f3468 = 0;
        c.f3150 = 0;
    }
}
function child445(c, i) {
    const ch = c.children[i];
    c.f3150 = 1;
    if (c.state !== 0x13b) ch.moveWhileFrozen = 0;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.ay = 0.035;
        ch.hitsLeft = 0xa;
        spawn447(c, i, 0, true);
    }
    if (partnerLand(c, i)) return;
    if (ch.frame === 3 && c.freeze === 0) {
        ch.timer = 0;
        ch.frame = 4;
        ch.moveWhileFrozen = 0;
    }
    if (ch.frame === 7 && ch.timer === 0) {
        ch.vx = 1.5;
        ch.vy = -3.5;
        ch.ay = 0.052;
    }
    if (ch.frame > 7 && ch.frame < 0xb) {
        ch.vy += ch.ay;
        ch.vx -= 0.015;
        if (ch.vx < 0.0) ch.vx = 0.0;
        if (ch.y > 0.0) {
            ch.y = 0.0;
            ch.vx = 0.0;
            ch.vy = 0.0;
            ch.timer = 0;
            ch.frame = 0xb;
        }
    }
    if (ch.frame === 0xe && ch.timer === 0) spawn447(c, i, 40.0, false);
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame === 9 && c.a3258[i] < 4) {
        ch.frame = ch.frame - 1 & 0xffff;
        c.a3258[i]++;
    }
    if (ch.frame === 0xb) ch.frame = ch.frame - 2 & 0xffff;
    if (ch.frame >= childCount) {
        ch.timer = 0;
        ch.frame = 0;
        ch.pattern = 0x190;
        c.a3158[i] = 0;
        c.a3258[i] = 0;
        c.f3468 = 0;
        c.f3150 = 0;
    }
}
function child446(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.2;
        ch.vy = -0.3;
        ch.ay = 0.01;
    }
    if (ch.frame === 0) ch.vy += ch.ay;
    if (c.f3468 === 1 && ch.frame === 0) {
        ch.frame = 1;
        ch.timer = 0;
        ch.hitsLeft = 0x63;
        ch.vy = 0.0;
        ch.vx = 3.5;
        const f = childSpawnFrame;
        f.w04 = 0;
        f.x = ftol(ch.x);
        f.y = ftol(ch.y);
        f.b20 = 2;
        c.seRequest = 2;
        f.b21 = 1;
        frameEffect(f);
    }
    if (ch.x > 680.0 || ch.x < -40.0) {
        c.freeChild(i);
        return;
    }
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = ch.frame - 2 & 0xffff;
}
function child447(c, i) {
    const ch = c.children[i];
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child448(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.vy = -3.0;
    ch.vy += 0.045;
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child449(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    ch.drawWhileFrozen = 0x7530;
    if (ch.frame === 0x10 && ch.timer === 0) {
        o.life = o.life - 0x1388;
        o.w140 = 0x7530;
        if (c.wins + 1 < gs.winRounds || o.life > 0) {
            o.state = 0x63;
            o.timer = 0;
            o.frame = 0;
            o.hitstop = 0;
            c.frame = 0;
            c.timer = 0;
            c.state = 0x13d;
        }
    }
    c.freeze = 2;
    if (ch.frame === 0x10 && ch.timer === 0x1c2) {
        c.screenFlash(1, 0x32, 0x64, 0x64);
        if (o.life <= 0 && c.wins + 1 === gs.winRounds) c.screenFlash(1, 0x32, 0x64, 0x50);
    }
    if (ch.frame === 0x11 && ch.timer === 0x258) c.screenFlash(1, 0x32, 0x64, 0x50);
    if (ch.frame === 0x12 && ch.timer === 0x384) {
        o.w140 = 0;
        o.hitstop = 0;
        c.freeze = 0;
        return;
    }
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame === 1 && o.life <= 0x1388 && c.wins + 1 === gs.winRounds) c.voiceRequest = 0xd;
    if (ch.frame === 0x11) {
        if (o.life <= 0 && c.wins + 1 === gs.winRounds) {
            ch.frame = 0x11;
        } else {
            c.freeChild(i);
            gs.specialTimerE = 0;
            gs.specialTimerE = 0;
            gs.specialTimerC = 0;
        }
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
function child450(c, i) {
    const ch = c.children[i];
    ch.x = c.facing * 7 + c.x;
    ch.y = c.y - 42.0;
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.pattern = 0x1c3;
    }
}
function child451(c, i) {
    const ch = c.children[i];
    ch.x = c.facing * 7 + c.x;
    ch.y = c.y - 42.0;
    if (ch.frame === 1 && ch.timer === 0) {
        c.voiceRequest = 0xc;
        const f = childSpawnFrame;
        f.w04 = 0x1c4;
        f.x = c.facing * 9 + c.x;
        f.y = c.y - 53.0;
        f.b18 = c.facing;
        f.b20 = 2;
        f.b21 = 0;
        f.d30 = 1;
        frameChild(c, f);
    }
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child452(c, i) {
    const ch = c.children[i];
    ch.x = c.facing * 9 + c.x;
    ch.y = c.y - 53.0;
    ch.timer = ch.timer + 1 & 0xffff;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame = ch.frame + 1 & 0xffff;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    443: child443,
    444: child444,
    445: child445,
    446: child446,
    447: child447,
    448: child448,
    449: child449,
    450: child450,
    451: child451,
    452: child452
});
