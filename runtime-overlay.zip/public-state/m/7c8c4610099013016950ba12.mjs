import {canonicalSnapshot} from "./47bb11ff5dfa3b58ac56f1ee.mjs";
import rootPolicy from "./71ed9a53d83b602c84c6b940.mjs";
const sourceFile=file=>file==='src/platform/audio.mjs'?'src/game/sound_events.mjs':file;
export const mutableConst=(file,key)=>(rootPolicy.mutableAnchors[sourceFile(file)]??[]).includes(key);
const ownKeys=v=>Object.keys(v).sort();
const need=(v,c)=>{if(!v)throw Error('INITIAL_CAP_'+c);};
/** Wrapping capability calls records identity, never asset byte contents. */
export function trackMetadata(provider,manifest,{mode='receiver'}={}){need(mode==='producer'||mode==='receiver','RESOURCE_MODE');const byValue=new WeakMap(),byId=new Map();let disposed=false;
 const known=id=>{const [kind,name,hash]=id.split(':');return kind==='pat'?manifest.patterns[name]?.sha256===hash:kind==='sprite'&&/^[a-z]+$/.test(name)&&Boolean(manifest.characters?.[name]??manifest.patterns[name+'/'+name+'.pat'])&&hash===(manifest.sha256??manifest.format);};
 function admit(id){need(!disposed,'RESOURCE_DISPOSED');if(mode==='receiver')need(byId.has(id)||byId.size<8,'RESOURCE_LIMIT');}
 function remember(v,id){if(v&&typeof v==='object'){const previous=byValue.get(v);need(!previous||previous===id,'RESOURCE_ALIAS');byValue.set(v,id);if(mode==='receiver')byId.set(id,v);}return v;}
 const resource={knows:known,identify:v=>byValue.get(v)??null,has:id=>byId.has(id),resolve(id){need(mode==='receiver','PRODUCER_NO_RESOLVE');need(byId.has(id),'RESOURCE_NOT_PREPARED');return byId.get(id);},stats:()=>({mode,strongResources:byId.size,disposed}),async prepare(ids){
  need(mode==='receiver'&&Array.isArray(ids)&&ids.length<=8,'RESOURCE_LIMIT');
  for(const id of ids){need(known(id),'RESOURCE_ID');if(byId.has(id))continue;const [kind,name]=id.split(':');if(kind==='pat')wrapped.patternBank(name);else wrapped.spritePresence(name);}
 }};
 const wrapped={...provider,patternBank(p){const info=manifest.patterns[p];need(info,'PAT_PATH '+p);const id='pat:'+p+':'+info.sha256;admit(id);return remember(provider.patternBank(p),id);},spritePresence(name){const id='sprite:'+name+':'+(manifest.sha256??manifest.format);admit(id);return remember(provider.spritePresence(name),id);},dispose(){try{provider.dispose?.();}finally{disposed=true;byId.clear();}}};
 return {provider:wrapped,resource};
}
/** Immutable binding allowlist is source-inventory driven and reviewed in factory-review.md. */
export function createCapabilities(port,inventory,resource,{factories={},mode='receiver'}={}){
 need(mode==='producer'||mode==='receiver','MODE');const byValue=new WeakMap(),byId=new Map(),classByPrototype=new Map(),classes=new Map(),attest=[],bindingChecks=[];
 const remember=(v,id)=>{if((typeof v==='object'&&v)||typeof v==='function'){if(byValue.has(v))return byValue.get(v);byValue.set(v,id);byId.set(id,v);}return id;};
 function codeTree(v,id,seen=new Set()){
  if(v===null||!['object','function'].includes(typeof v)||seen.has(v)||resource.identify(v)!==null)return;seen.add(v);
  if(typeof v==='function'){need(Reflect.ownKeys(v).every(k=>['length','name','arguments','caller','prototype'].includes(k)),'FUNCTION_OWN_STATE');Object.freeze(v);if(v.prototype)Object.freeze(v.prototype);remember(v,id);return;}
  if(v instanceof Map){let i=0;for(const [k,x]of v){codeTree(k,id+'/k'+i,seen);codeTree(x,id+'/v'+i++,seen);}}
  else if(v instanceof Set){let i=0;for(const x of v)codeTree(x,id+'/'+i++,seen);}
  else for(const k of ownKeys(v))codeTree(v[k],id+'/'+k,seen);
 }
 const raw=port.snapshot();
 // Stable full semantic location disambiguates same-source closures. Functions
 // inside tables are registered before tables themselves become capabilities.
 for(const file of Object.keys(raw.modules).sort())for(const key of ownKeys(raw.modules[file]))codeTree(raw.modules[file][key],'code:'+file+':'+key);
 function immutable(v,id){if(v===null||typeof v!=='object')return;const signature=()=>JSON.stringify(canonicalSnapshot(v,{functionIdentity:f=>byValue.get(f)??null}));const initial=signature();remember(v,id);attest.push(()=>need(signature()===initial,'IMMUTABLE_MUTATION '+id));}
 for(const file of Object.keys(raw.modules).sort()){
  const sf=sourceFile(file),fields=inventory[sf];need(fields,'ROOT_MODULE '+file);need(JSON.stringify(ownKeys(fields))===JSON.stringify(ownKeys(raw.modules[file])),'ROOT_FIELDS '+file);
  const classified=Object.values(rootPolicy).flatMap(category=>category[sf]??[]).sort();need(JSON.stringify(classified)===JSON.stringify(ownKeys(fields)),'POLICY_FIELDS '+file);
  for(const key of Object.keys(fields)){
   const v=raw.modules[file][key],immutableCap=(rootPolicy.immutableCapabilities[sf]??[]).includes(key),immutableScalar=(rootPolicy.immutableScalars[sf]??[]).includes(key);
   if(immutableCap||immutableScalar){
    if(file==='src/game/effects.mjs'&&key==='patterns'){need(resource.identify(v)!==null,'EFFECT_PAT');continue;}
    bindingChecks.push({file,key,value:v});
    if(immutableCap&&typeof v==='object'&&v!==null)immutable(v,'static:'+file+':'+key);
   }
  }
 }
 function registerClass(id,obj){need(obj&&Object.getPrototypeOf(obj)!==Object.prototype,'CLASS_OBJECT '+id);classes.set(id,{obj,keys:ownKeys(obj)});classByPrototype.set(Object.getPrototypeOf(obj),id);}
 registerClass('Machine',raw.machine);for(const scene of raw.machine.scenes)if(scene)registerClass('Scene:'+scene.constructor.name,scene);
 registerClass('ReplayFile',raw.gameState.replayFile);if(raw.modules['src/core/game_main.mjs'].sourceLoopTimer)registerClass('FrameTimer',raw.modules['src/core/game_main.mjs'].sourceLoopTimer);
 for(const [id,factory]of Object.entries(factories))registerClass(id,factory());
 function type(v){
  if(v&&Number.isInteger(v.id)&&Number.isInteger(v.side)&&v.id>=0&&v.id<=24&&v.side>=0&&v.side<=1){const cls=raw.modules['src/game/chars/index.mjs'].PORTED[v.id];if(Object.getPrototypeOf(v)===cls.prototype)return 'Actor:'+v.id+':'+v.side;}
  if(v&&[1,10,12,16].includes(v.stage)&&/^Stage(?:1|10|12|16)Object$/.test(v.constructor?.name))return 'Stage:'+v.stage;
  return classByPrototype.get(Object.getPrototypeOf(v))??null;
 }
 return {identify:v=>(v&&(typeof v==='object'||typeof v==='function')?resource.identify(v)??byValue.get(v):null)??null,
  has:id=>byId.has(id)||resource.has(id)||resource.knows(id),resolve:id=>{need(byId.has(id)||resource.has(id),'UNKNOWN '+id);return byId.get(id)??resource.resolve(id);},type,
  checkType:(id,keys)=>classes.has(id)&&JSON.stringify(classes.get(id).keys)===JSON.stringify(keys),
  construct:(id,keys)=>{need(classes.has(id),'FACTORY '+id);const c=classes.get(id);need(JSON.stringify(c.keys)===JSON.stringify(keys),'CLASS_KEYS '+id);return c.obj;},
  registerClass,assertStable(){const now=port.snapshot().modules;for(const {file,key,value}of bindingChecks)need(now[file][key]===value,'IMMUTABLE_BINDING '+file+':'+key);for(const f of attest)f();},
  rootAnchors(){const out=[];const now=port.snapshot();for(const [file,fields]of Object.entries(now.modules))for(const [key,v]of Object.entries(fields))if(mutableConst(file,key))out.push({file,key,value:v});return out;},
  classObjects:classes,
  finishCapture(){if(mode==='producer')for(const id of classes.keys())if(id.startsWith('Actor:')||id.startsWith('Stage:'))classes.delete(id);},
  stats(){return {mode,transientClasses:[...classes.keys()].filter(id=>id.startsWith('Actor:')||id.startsWith('Stage:')).length,resources:resource.stats()};},
 };
}
