import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { readSync } from "./197efe2647ca25903d217eb5.mjs";
export function createImage(width, height) {
    return {
        width,
        height,
        pitch: width,
        pixels: new Uint8Array(width * height)
    };
}
export function decompress(src, srcOffset, threshold, pixelOffset) {
    const width = src[srcOffset] | src[srcOffset + 1] << 8;
    const height = src[srcOffset + 2] | src[srcOffset + 3] << 8;
    const image = createImage(width, height);
    const dst = image.pixels;
    const add = pixelOffset & 0xff;
    threshold &= 0xff;
    let pos = srcOffset + 4;
    if (height === 0) return {
        image,
        consumed: 4
    };
    if (threshold === 0) {
        for(let row = 0; row < height; row++){
            const dstRow = (height - 1 - row) * image.pitch;
            for(let col = 0; col < width; col++){
                dst[dstRow + col] = src[pos + col] + add & 0xff;
            }
            pos += width;
        }
        return {
            image,
            consumed: pos - srcOffset
        };
    }
    let last = 0;
    let repeat = 0;
    for(let row = 0; row < height; row++){
        const dstRow = row * image.pitch;
        for(let col = 0; col < width; col++){
            if (repeat !== 0) {
                repeat = repeat - 1 & 0xff;
            } else {
                const b = src[pos++];
                if (b > threshold) {
                    repeat = b - threshold - 1 & 0xff;
                } else {
                    last = b + add & 0xff;
                }
            }
            dst[dstRow + col] = last;
        }
    }
    return {
        image,
        consumed: pos - srcOffset
    };
}
export function decompressMapped(src, srcOffset, threshold, base) {
    const width = src[srcOffset] | src[srcOffset + 1] << 8;
    const height = src[srcOffset + 2] | src[srcOffset + 3] << 8;
    const image = createImage(width, height);
    const dst = image.pixels;
    const map = (v)=>(v < 40 ? base + v : v + 135) & 0xff;
    threshold &= 0xff;
    let pos = srcOffset + 4;
    if (height === 0) return {
        image,
        consumed: 4
    };
    if (threshold === 0) {
        for(let row = 0; row < height; row++){
            const dstRow = (height - 1 - row) * image.pitch;
            for(let col = 0; col < width; col++)dst[dstRow + col] = map(src[pos + col]);
            pos += width;
        }
        return {
            image,
            consumed: pos - srcOffset
        };
    }
    let last = 0;
    let repeat = 0;
    for(let row = 0; row < height; row++){
        const dstRow = row * image.pitch;
        for(let col = 0; col < width; col++){
            if (repeat !== 0) {
                repeat = repeat - 1 & 0xff;
            } else {
                const b = src[pos++];
                if (b > threshold) repeat = b - threshold - 1 & 0xff;
                else last = map(b);
            }
            dst[dstRow + col] = last;
        }
    }
    return {
        image,
        consumed: pos - srcOffset
    };
}
export function imageDataOffset(buffer) {
    return 1 + 3 * buffer[0];
}
export function loadDat(filename, threshold, pixelOffset) {
    const buffer = readSync(filename);
    if (!buffer) {
        console.warn(`[dat] 找不到檔案：${filename}`);
        return createImage(0, 0);
    }
    return decompress(buffer, imageDataOffset(buffer), threshold, pixelOffset).image;
}
export function loadDatSequence(filename, count, threshold, pixelOffset) {
    const buffer = readSync(filename);
    const result = [];
    if (!buffer) {
        console.warn(`[dat] 找不到檔案：${filename}`);
        return result;
    }
    let pos = imageDataOffset(buffer);
    for(let i = 0; i < count && pos + 4 <= buffer.length; i++){
        const { image, consumed } = decompress(buffer, pos, threshold, pixelOffset);
        result.push(image);
        pos += consumed;
    }
    return result;
}
export function readDatPalette(filename) {
    const buffer = readSync(filename);
    if (!buffer) return null;
    const n = buffer[0];
    const rgb = new Uint8Array(n * 3);
    for(let i = 0; i < n; i++){
        rgb[i * 3 + 0] = buffer[1 + i * 3 + 2];
        rgb[i * 3 + 1] = buffer[1 + i * 3 + 1];
        rgb[i * 3 + 2] = buffer[1 + i * 3 + 0];
    }
    return rgb;
}
