import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./0de4622b5e3457d2a8d81427.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./6237c3c562237f9de4952920.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function superEffect(d, c, pat, sound) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) + c.facing * 0x17;
    d.y = ftol(c.y) - 0x1e;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function endToNeutral(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function rainSuper(c, flashFrame, cost, pat, sound, spawnMax, loopMax, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (atFrame(c, flashFrame)) {
        c.stopMotion();
        superFreeze(c, cost);
        superEffect(d, c, pat, sound);
        if (big) c.seRequest = 0x25;
    }
    if (big) c.showAltBackground(0xf);
    if (c.frame > 3) c.biasCameraY(0x32, 0xa);
    if (c.frame > 6 && c.frame < 0x10 && c.timer === 0 && c.f3138 < spawnMax) {
        c.voiceRequest = 3;
        d.w04 = 0x195;
        const r = (c.random(0, 0x50) & 0xffff) - 0x28;
        d.x = ftol(r + c.x);
        d.y = ftol(c.y) - 0x8c;
        d.b20 = 2;
        d.b21 = 1;
        if ((c.random(0, 0x64) & 0xffff) < 0x32) d.b21 = 0;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 0xf && c.f3138 < loopMax) {
        c.f3138++;
        c.frame = 7;
    }
    endToNeutral(c, cnt);
}
function pillarSuper(c, dx, dy) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        c.b158 = 0;
    }
    if (atFrame(c, 2)) {
        superFreeze(c, 0x3e8);
        superEffect(d, c, 0x44, 0x13);
    }
    if (c.frame > 3) c.biasCameraY(0x32, 0xa);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 5 && c.f3138 === 0) {
        c.voiceRequest = 2;
        d.w04 = 0x19c;
        d.x = ftol(c.x) + c.facing * dx;
        d.y = ftol(c.y) - dy;
        d.b20 = 2;
        d.b18 = c.facing;
        d.d00 = 1;
        d.b21 = 1;
        frameChild(c, d);
        d.w04 = 8;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b18 = c.facing;
        d.b21 = 1;
        frameEffect(d);
        d.w04 = 0x1f;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 0;
        d.b18 = c.facing;
        d.b21 = 1;
        frameEffect(d);
    }
    c.d168 = 0;
    if (c.frame === 8 && c.f3138 < 0) {
        c.f3138++;
        c.frame = 4;
    }
    endToNeutral(c, cnt);
}
function rushSuper(c, cost, pat, sound, child, d168, loop, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (atFrame(c, 3)) {
        c.stopMotion();
        superFreeze(c, cost);
        superEffect(d, c, pat, sound);
        d.w04 = child;
        d.x = ftol(c.x - c.facing * 0x140);
        d.y = ftol(c.y) - 0x140;
        d.b20 = 0;
        d.b21 = 1;
        d.d00 = 1;
        d.d28 = 1;
        d.b18 = c.facing;
        d.d30 = 1;
        frameChild(c, d);
        c.f3144 = 2;
        if (big) c.seRequest = 0x25;
    }
    if (c.frame < 4) c.biasCameraY(0x32, 0xa);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = d168;
    if (loop && c.frame === 0xa && c.f3144 > 1) c.frame -= 4;
    endToNeutral(c, cnt);
}
function state309(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.b158 = 0;
        c.w16c = 1;
        c.stopMotion();
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    if (c.frame < 4) c.showAltBackground(0xf);
    if (c.frame === 1) {
        c.vx = 0.8;
        c.startAfterimage(6);
    }
    c.biasCameraY(0x32, 0xa);
    if (c.frame > 0 && c.frame < 3 && c.d168 === 3) {
        c.startAfterimage(0);
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.frame = 3;
        o.state = 0x6b;
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0x11;
        d.y = ftol(c.y) - 0x36;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        o.x = c.x;
        o.y = 0.0;
    }
    if (c.frame === 4) {
        o.state = 0x79;
        c.superDarken(0xb0, 3);
        if (c.f3138 === 0) {
            c.comboCount = s16(c.comboCount + 1);
            c.comboDisplay = s16(c.comboDisplay + 1);
            d.w04 = 0;
            d.b2c = 2;
            const bx = c.x + 50.0;
            d.x = ftol(bx - (c.random(0, 0x64) & 0xffff));
            d.y = (c.random(0, 0x64) & 0xffff) - 0x64;
            d.b18 = c.facing;
            d.b20 = 2;
            d.d00 = 1;
            d.b21 = 1;
            frameEffect(d);
        }
        c.f3138++;
        if (c.f3138 === 0xd) c.f3138 = 0;
    }
    if (c.frame > 4 && c.frame < 8) o.timer = 0;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 5) {
        o.timer = 0;
        o.state = 0x63;
        applyDirectDamage(c, 0x1194, 1000.0);
        if (c.wins + 1 !== gs.winRounds) o.w140 = 0x7530;
        if (!(o.life > 0)) {
            d.w04 = 0x1ac;
            d.x = 0.0;
            d.y = 0.0;
            d.b20 = 0;
            d.b21 = 0;
            d.d00 = 1;
            d.d28 = 0;
            d.b18 = 1;
            d.d24 = 1;
            frameChild(c, d);
            c.voiceRequest = 4;
        }
    }
    c.d168 = 0;
    if (c.frame === 8 && c.f3140 < 3) {
        o.timer = 0;
        c.frame = 5;
        if (o.life > 0) c.f3140++;
    }
    if (c.frame === 8) o.w140 = 0;
    if (c.frame === 3 && c.f313c < 0xf) {
        c.f313c++;
        c.frame = 1;
        if (c.f313c > 0xe) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
    endToNeutral(c, cnt);
}
function state311(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) {
        c.w16c = 0;
        c.stopMotion();
        c.b158 = 0;
    }
    if (atFrame(c, 2)) {
        superFreeze(c, 0xbb8);
        superEffect(d, c, 9, 5);
    }
    c.biasCameraY(0x32, 0xa);
    if (c.frame === 5 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        o.state = 0x6b;
        if (c.x > 560.0 && c.facing === 1) c.x = 560.0;
        if (c.x < 80.0 && c.facing === -1) c.x = 80.0;
        o.x = (c.pointsX[2] + 0x47) * c.facing + c.x;
        o.y = 0.0;
        c.state = 0x138;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 5) {
        c.voiceRequest = 0x15;
        if (o.y === 0.0) c.w16c = 1;
    }
    c.d168 = 0;
    endToNeutral(c, cnt);
}
function throwChild(c, d, pat, sx, dy) {
    const o = c.opponent;
    d.w04 = pat;
    d.x = ftol(o.x) + sx * c.facing * 0x140;
    d.y = ftol(o.y) + dy;
    d.b20 = 0;
    d.d00 = 1;
    d.b18 = c.facing;
    d.b21 = 1;
    frameChild(c, d);
}
function state312(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 1) {
        o.x = (c.pointsX[2] + 0x3c) * c.facing + c.x;
        o.y = c.y - 13.0 - c.pointsY[2];
        o.state = 0x6b;
        o.onStateChange();
        o.stopMotion();
    }
    if (c.frame === 2) {
        o.x = (c.pointsX[3] + 0x2e) * c.facing + c.x;
        o.y = c.y - 16.0 - c.pointsY[3];
        o.state = 0x6e;
        o.onStateChange();
        o.stopMotion();
    }
    if (c.frame === 3) {
        o.x = (c.pointsX[4] + 0x1a) * c.facing + c.x;
        o.y = c.y - 41.0 - c.pointsY[4];
        o.state = 0x6f;
        o.onStateChange();
        o.stopMotion();
    }
    if (c.frame === 4) {
        o.onStateChange();
        o.stopMotion();
        o.knockX = 0.0;
        o.knockY = -2.9;
        o.state = 0x3f;
    }
    if (atFrame(c, 0xb)) {
        c.freeze = 0x78;
        c.superDarken(0xb0, 3);
        superEffect(d, c, 9, 5);
        c.w16c = 1;
    }
    if (c.frame > 0x10) c.f3138++;
    if (c.f3138 === 0x5a || c.f3138 === 0x12c) throwChild(c, d, 0x1a5, 1, 0);
    if (c.f3138 === 0x96 || c.f3138 === 0x168) throwChild(c, d, 0x1a6, 1, 0x40);
    if (c.f3138 === 0xf0 || c.f3138 === 0xc8) throwChild(c, d, 0x1a7, 1, 0x80);
    if (c.f3138 === 0x78 || c.f3138 === 0x10e) throwChild(c, d, 0x1a8, -1, 0);
    if (c.f3138 === 0xb4 || c.f3138 === 0x14a) throwChild(c, d, 0x1a9, -1, 0x50);
    if (c.f3138 === 0xd2 || c.f3138 === 0x186) throwChild(c, d, 0x1aa, -1, 0x7d);
    if (c.f3138 === 0x1f4) {
        d.w04 = 0x1ab;
        d.x = ftol(o.x);
        d.y = 0.0;
        d.b20 = 0;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
    }
    if (c.frame < 0x10) c.biasCameraY(0x32, 3);
    if (c.frame >= 0x10) o.biasCameraY(0x32, 3);
    if (o.state === 0x63 && c.frame < 0x14) {
        c.timer = 0;
        c.frame = 0x14;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 0x14) c.frame -= 3;
    c.d168 = 0;
    endToNeutral(c, cnt);
}
function state315(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        c.freeze = 0x78;
        c.meter = s16(c.meter - 0x3e8);
        c.superDarken(0, 0x28);
        superEffect(d, c, 9, 5);
    }
    c.vy += c.ay;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 1) {
        c.vx = -0.9;
        c.vy = -2.1;
        c.ay = 0.025;
        c.voiceRequest = 1;
        d.w04 = 0x192;
        d.x = ftol(c.x) + c.facing * 0x1e;
        d.y = ftol(c.y) - 0x1e;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 2;
        frameChild(c, d);
    }
    if (c.y + c.vy > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.vx = 0.0;
        c.onStateChange();
        c.state = 0xd;
        return;
    }
    if (c.frame >= cnt) c.frame = 1;
}
registerStates({
    300: (c)=>rainSuper(c, 4, 0x3e8, 0x44, 0x13, 2, 2, false),
    301: (c)=>rainSuper(c, 2, 0x7d0, 0x45, 5, 3, 3, false),
    302: (c)=>rainSuper(c, 0, 0xbb8, 0x46, 0x40, 4, 3, true),
    303: (c)=>pillarSuper(c, 0, 0x32),
    304: (c)=>pillarSuper(c, 0x64, 0x32),
    305: (c)=>pillarSuper(c, 0, 0x96),
    306: (c)=>rushSuper(c, 0x3e8, 0x44, 0x13, 0x1a1, 3, true, false),
    307: (c)=>rushSuper(c, 0x7d0, 0x45, 5, 0x1a2, 3, true, false),
    308: (c)=>rushSuper(c, 0xbb8, 0x46, 0x40, 0x1a3, 0, false, true),
    309: state309,
    311: state311,
    312: state312,
    315: state315
});
function childStep(c, i, dur) {
    const ch = c.children[i];
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function child405(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const o = c.opponent;
    ch.vx = 0.0;
    ch.vy = -8.0;
    if (ch.timer === 0) ch.hitsLeft = 1;
    if (ch.y < -1000.0) {
        ch.blend = 0;
        if ((c.random(0, 0x64) & 0xffff) < 0x32) {
            ch.hitState = 0;
            ch.pattern = 0x197;
            ch.frame = 0;
            ch.timer = 0;
            const base = ch.facing * ((ch.y - o.y) / 2.0) + o.x;
            const r = (c.random(0, 0x8c) & 0xffff) - 0x46;
            ch.x = ftol(r + base);
            return;
        }
        if ((c.random(0, 2) & 0xffff) === 0) {
            ch.pattern = 0x198;
            ch.frame = 0;
            ch.timer = 0;
            const base = ch.facing * 0x64 + o.x + ch.facing * (ch.y - o.y * 0.5);
            const r = (c.random(0, 0x8c) & 0xffff) - 0x46;
            ch.x = ftol(r + base);
            return;
        }
        ch.pattern = 0x196;
        ch.frame = 0;
        ch.timer = 0;
        const base = ch.facing * ((ch.y - o.y) / 4.0) + o.x;
        const r = (c.random(0, 0x8c) & 0xffff) - 0x46;
        ch.x = ftol(r + base);
        return;
    }
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame >= cnt) c.freeChild(i);
}
function fallingChild(c, i, vx) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.vx = vx;
    ch.vy = 8.0;
    if (c.a314c[i] === 0) c.a314c[i] = c.random(1, 0x14) & 0xffff;
    if (ch.frame >= 1) {
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    if (ch.frame === 0) ch.hitsLeft = 1;
    if (c.a314c[i] - 0xf <= ch.y && ch.frame === 0) {
        ch.frame = 1;
        ch.timer = 0;
    }
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame >= cnt) c.freeChild(i);
}
function child412(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0) {
        c.a314c[i] = 0;
        c.a324c[i] = 0;
        ch.vx = 2.0;
        ch.vy = 0.0;
        ch.hitsLeft = 1;
    }
    ch.vx -= 0.05;
    if (ch.vx < 0.1) ch.vx = 0.1;
    if (ch.frame < 0x1a && ch.hitsLeft === 0) {
        ch.frame = 0x1a;
        ch.timer = 0;
        if (ch.hitState === 3) c.opponent.hitstop = 0x5a;
        return;
    }
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (c.a324c[i] < 3 && ch.frame === 0x19) {
        c.a324c[i]++;
        ch.frame = 0xa;
    }
    if (ch.frame >= cnt) c.freeChild(i);
}
function bounced(c, i, setFlag) {
    const ch = c.children[i];
    if (ch.hitState !== 4 && ch.hitState !== 5) return false;
    ch.frame = 0;
    ch.timer = 0;
    ch.hitState = 0;
    ch.vx = -0.8;
    ch.vy = -3.0;
    ch.pattern = 0x19a;
    if (setFlag) c.f3144 = 1;
    return true;
}
function landed(c, i) {
    const ch = c.children[i];
    if (ch.frame < 2 && ch.y + ch.vy > 0.0) {
        ch.timer = 0;
        ch.frame = 2;
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.y = 0.0;
        return true;
    }
    return false;
}
function waitFreeze(c, i) {
    const ch = c.children[i];
    if (ch.frame === 4 && c.freeze === 0) {
        ch.frame = 5;
        ch.timer = 0;
        return true;
    }
    return false;
}
function offscreenFree(c, i) {
    const ch = c.children[i];
    const out = gs.viewLeft - 0x32 > ch.x && ch.facing === 1 || gs.viewRight + 0x32 < ch.x && ch.facing === -1;
    if (out && ch.frame > 0x14) {
        c.freeChild(i);
        c.f3144 = 0;
    }
}
function child417(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (bounced(c, i, true)) return;
    if (ch.frame > 4) ch.moveWhileFrozen = 0;
    if (c.state !== 0x132 && ch.frame < 0x12) {
        ch.timer = 0;
        ch.frame = 0x12;
        return;
    }
    if (ch.frame === 0 && ch.timer === 0 && c.a314c[i] === 0) {
        ch.vx = 4.0;
        ch.vy = 0.0;
        ch.hitsLeft = 0xb;
        c.a314c[i]++;
    }
    if (landed(c, i)) return;
    if (waitFreeze(c, i)) return;
    if (ch.timer === 0 && (ch.frame === 6 || ch.frame === 0xa || ch.frame === 0xe)) {
        ch.vx = 0.0;
        c.seRequest = 0x14;
    }
    if (ch.vx < 0.0 && ch.frame < 0x14) ch.vx = 0.0;
    if (ch.frame < 2) ch.vy += 0.085;
    ch.timer++;
    if (childStep(c, i, dur)) {
        ch.hitState = 0;
        if (ch.frame === 2) ch.frame -= 2;
        if (ch.frame === 0xc && c.a324c[i] < 3) {
            ch.frame = 5;
            if (c.a324c[i] > 1) c.f3144 = 1;
            c.a324c[i]++;
        }
        if (ch.frame === 0x15) {
            ch.vx = -4.4;
            ch.vy = -3.8;
        }
        if (ch.frame >= cnt) ch.frame -= 2;
    }
    offscreenFree(c, i);
}
function child418(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (bounced(c, i, true)) return;
    if (ch.frame > 4) ch.moveWhileFrozen = 0;
    if (c.state !== 0x133 && ch.frame < 0x19) {
        ch.timer = 0;
        ch.frame = 0x19;
        return;
    }
    if (ch.frame === 0 && ch.timer === 0 && c.a314c[i] === 0) {
        ch.vx = 4.0;
        ch.vy = 0.0;
        ch.hitsLeft = 0x63;
        c.a314c[i]++;
    }
    if (landed(c, i)) return;
    if (waitFreeze(c, i)) return;
    if (ch.timer === 0 && ch.frame === 0x15) {
        ch.vx = 2.2;
        c.seRequest = 0x14;
    }
    if (ch.vx > 0.0 && ch.frame > 4) ch.vx -= 0.105;
    if (ch.vx < 0.0 && ch.frame < 0x14) ch.vx = 0.0;
    if (ch.frame < 2) ch.vy += 0.085;
    ch.timer++;
    if (childStep(c, i, dur)) {
        ch.hitState = 0;
        if (ch.frame === 2) ch.frame -= 2;
        if (ch.frame === 0x14 && c.a324c[i] < 6) {
            ch.frame = 5;
            if (c.a324c[i] > 4) c.f3144 = 1;
            c.a324c[i]++;
        }
        if (ch.frame === 0x1c) {
            ch.vx = -4.4;
            ch.vy = -3.8;
        }
        if (ch.frame >= cnt) ch.frame -= 2;
    }
    offscreenFree(c, i);
}
function child419(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const o = c.opponent;
    if (bounced(c, i, false)) return;
    c.showAltBackground(0xf);
    if (ch.frame > 4) ch.moveWhileFrozen = 0;
    if (ch.frame === 0 && ch.timer === 0 && c.a314c[i] === 0) {
        ch.vx = 4.0;
        ch.vy = 0.0;
        ch.hitsLeft = 1;
        c.a314c[i]++;
    }
    if (landed(c, i)) return;
    if (waitFreeze(c, i)) return;
    if (ch.frame === 0x16 && ch.hitState === 3) {
        ch.vx = 0.05;
        ch.vy = -0.2;
        o.hitstop = 0x78;
        ch.hitState = 0;
        const d = childSpawnFrame;
        d.w04 = 0x1a4;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y);
        d.b20 = 1;
        d.b21 = 0;
        d.d00 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (ch.frame === 0x16 && o.hitstop === 0) {
        ch.vx = 1.5;
        ch.vy = -6.0;
    }
    if (ch.frame < 2) ch.vy += 0.085;
    ch.timer++;
    if (childStep(c, i, dur)) {
        ch.hitState = 0;
        if (ch.frame === 2) ch.frame -= 2;
        if (ch.frame === 0x14 && c.a324c[i] < 0xa) {
            ch.frame = 5;
            c.a324c[i]++;
        }
        if (ch.frame === 0x16) {
            ch.vx = 1.5;
            ch.vy = -6.0;
            c.seRequest = 0x14;
        }
        if (ch.frame === 0x17) ch.frame -= 1;
        if (ch.frame >= cnt) ch.frame -= 2;
    }
    if (ch.y < -640.0 && ch.frame > 0x14) {
        c.freeChild(i);
        c.f3144 = 0;
    }
}
function child420(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.vx = 0.05;
    ch.vy = -0.2;
    if (c.opponent.hitstop === 0) {
        c.freeChild(i);
        return;
    }
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame >= cnt) ch.frame = 0;
}
function child428(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const o = c.opponent;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    ch.hitState = 0;
    if (ch.frame === 0x38 && o.w140 > 0) c.screenFlash(1, 0x14, 0x78, 0x14);
    if (ch.frame < cnt) return;
    if (c.wins + 1 !== gs.winRounds) {
        c.freeChild(i);
        c.f3140 = 0xa;
    }
    if (c.wins + 1 === gs.winRounds) {
        ch.frame -= 1;
        o.w140 = 0;
    }
}
registerChildren({
    405: child405,
    406: (c, i)=>fallingChild(c, i, 2.0),
    407: (c, i)=>fallingChild(c, i, 4.0),
    408: (c, i)=>fallingChild(c, i, 7.0),
    412: child412,
    417: child417,
    418: child418,
    419: child419,
    420: child420,
    428: child428
});
