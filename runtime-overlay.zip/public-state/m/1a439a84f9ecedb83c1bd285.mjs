import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./1f5919024557a92ec3a28767.mjs";
import { parseCommandExNanase, dispatchMovesExNanase } from "./635970d57b452aa9e1ea403b.mjs";
import { thinkExNanase } from "./abd8efe7f2fca373908b691e.mjs";
import { updateChildrenExNanase } from "./6bb9439be7e0aefdefc21b73.mjs";
import { tickHookExNanase } from "./8a89a0568611be815dd47e66.mjs";
import "./f4bdc872b60001e00dc1295d.mjs";
import "./767b2579f7571dd7e006c96e.mjs";
const POINTS_X = [
    -12,
    18,
    16,
    21,
    33
];
const POINTS_Y = [
    -58,
    0,
    -9,
    -14,
    -26
];
export class ExNanase extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    a3154 = new Int32Array(64);
    a3254 = new Int32Array(64);
    a3354 = new Int32Array(64);
    f3454 = 0;
    b3460 = 0;
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        5,
        6,
        2,
        5,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    wF2 = 0;
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    exOn() {
        return this.f3454 === 1 ? 1 : 0;
    }
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = this.f313c = this.f3140 = this.f3144 = this.f3148 = 0;
        this.f3454 = 0;
        this.f314c = this.f3150 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a3154.fill(0);
        this.a3254.fill(0);
        this.a3354.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3154[i] = 0;
        this.a3254[i] = 0;
        this.a3354[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {
        tickHookExNanase(this);
    }
    parseCommand() {
        parseCommandExNanase(this);
    }
    dispatchMoves() {
        dispatchMovesExNanase(this);
    }
    think() {
        thinkExNanase(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenExNanase(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
