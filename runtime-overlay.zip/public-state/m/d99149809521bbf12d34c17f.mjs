import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { abortChildWalk, childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./f2e83919002a3a51b71740fe.mjs";
import { registerChildren, registerStates } from "./72fceafa5789cf9e4e3cf0ff.mjs";
import { frameCount, frameDuration, s16 } from "./7596266716c972d06fe8897a.mjs";
function rfCostEffect(c, f) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function spawnFromBody(c, f, pattern, dx, dy, blend) {
    f.w04 = pattern;
    f.x = Math.trunc(c.x) + c.facing * dx;
    f.y = Math.trunc(c.y) - dy;
    f.b20 = blend;
    f.b21 = 1;
    f.b18 = c.facing;
    frameChild(c, f);
}
function shot401(c, loops) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.meter = s16(c.meter + 0x2d);
        c.f3138 = loops;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 4) {
            spawnFromBody(c, f, 0x191, 0x26, 0x28, 2);
            c.voiceRequest = 5;
        }
        if (c.frame === 7 && c.f3138 > 0) {
            c.frame = c.frame - 2;
            c.f3138 = c.f3138 - 1;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state250(c) {
    shot401(c, 5);
}
function state251(c) {
    shot401(c, 3);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.vx = c.vx + c.ax;
    c.b158 = 0;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame === 0 && c.timer === 0) {
        rfCostEffect(c, f);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.meter = s16(c.meter + 0x2d);
        c.f3138 = 6;
    }
    if (c.f313c === 0x14) {
        spawnFromBody(c, f, 0x1ab, 0x2d, 0x14, 2);
        c.voiceRequest = 5;
    }
    if (c.f313c === 0x28) {
        spawnFromBody(c, f, 0x1ab, 0x2d, 0x3c, 2);
        c.voiceRequest = 5;
    }
    if (c.frame > 4) c.f313c = c.f313c + 1;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 5) {
            f.b2c = 1;
            spawnFromBody(c, f, 0x1ab, 0x26, 0x28, 2);
            c.voiceRequest = 5;
        }
        if (c.frame === 7 && c.f3138 > 0) {
            c.frame = c.frame - 2;
            c.f3138 = c.f3138 - 1;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        rfCostEffect(c, f);
        c.meter = s16(c.meter + 0x2d);
        c.f3138 = 6;
        c.vx = c.vx * 0.5;
        c.vy = c.vy * 0.5;
        c.ay = 0.01;
        c.meter = s16(c.meter + 0x2d);
    }
    c.vy = c.vy + c.ay;
    if (c.f313c === 0x14) {
        f.w04 = 0x1ac;
        f.x = Math.trunc(c.x) + c.facing * 0x24;
        f.y = Math.trunc(c.y) - 0x26;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        c.f3140 = 1;
        frameChild(c, f);
        c.voiceRequest = 5;
    }
    if (c.f313c === 0x28) {
        f.w04 = 0x1ac;
        f.x = Math.trunc(c.x) + c.facing * 0x24;
        f.y = Math.trunc(c.y) - 0x48;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        c.f3140 = 2;
        frameChild(c, f);
        c.voiceRequest = 5;
    }
    if (c.frame > 4) c.f313c = c.f313c + 1;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 5) {
            f.b2c = 1;
            spawnFromBody(c, f, 0x1ac, 0x1d, 0x34, 2);
            c.voiceRequest = 5;
        }
        if (c.frame === 7 && c.f3138 > 0) {
            c.frame = c.frame - 2;
            c.f3138 = c.f3138 - 1;
        }
        if (c.frame >= cnt) {
            c.state = 9;
            c.onStateChange();
        }
    }
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.f3138 = 6;
        c.w16c = 5;
    }
    if (c.frame === 4 && c.timer === 0) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 1);
    }
    if (c.frame === 6 && c.timer === 0) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 1);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.w16c > 0) c.d168 = 0;
        if (c.frame === 7 && c.f3138 > 0) {
            c.frame = c.frame - 4;
            c.f3138 = c.f3138 - 1;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.f3138 = 8;
        c.w16c = 9;
    }
    if (c.frame === 4 && c.timer === 0) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 1);
    }
    if (c.frame === 6 && c.timer === 0) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 1);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 7 && c.f3138 > 0) {
            c.frame = c.frame - 4;
            c.f3138 = c.f3138 - 1;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
        c.w16c = 0x12;
        rfCostEffect(c, f);
    }
    if (c.frame === 3 && c.timer === 0 && c.f3138 === 0) {
        spawnFromBody(c, f, 0x1a1, 0x17, 0x30, 2);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 1);
    }
    if (c.frame === 6 && c.timer === 0) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 1);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.w16c > 0) c.d168 = 0;
        if (c.frame === 7 && c.f3138 < 0xc) {
            c.frame = c.frame - 4;
            c.f3138 = c.f3138 + 1;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function diveShotTail(c, f, cnt, pattern, loops) {
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame === 4 && c.timer === 0) {
        c.ay = 0.01;
        c.voiceRequest = 1;
        spawnFromBody(c, f, pattern, 0xe, 0, 0);
        spawnFromBody(c, f, pattern, 0x3c, 0x10, 0);
    }
    if (c.frame === 7 && c.f3138 < loops) {
        c.frame = c.frame - 2;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame >= cnt) {
        c.frame = 0;
        c.state = 9;
        c.ay = 0.028;
        c.onStateChange();
    }
}
function diveStart(c) {
    c.vx = c.vx * 0.25;
    c.vy = c.vy * 0.25;
    c.ay = 0.01;
}
function dive402(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) diveStart(c);
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.vy > 0.2) c.vy = 0.2;
    if (c.y === 0.0 && c.vy >= 0.0) c.vy = 0.0;
    if (c.timer >= dur) diveShotTail(c, f, cnt, 0x192, 4);
}
function state256(c) {
    dive402(c);
}
function state257(c) {
    dive402(c);
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) rfCostEffect(c, f);
    if (c.frame === 0 && c.timer === 0) diveStart(c);
    c.vy = c.vy + c.ay;
    if (c.vy > 0.2) c.vy = 0.2;
    c.timer++;
    if (c.y === 0.0 && c.vy >= 0.0) c.vy = 0.0;
    if (c.timer >= dur) diveShotTail(c, f, cnt, 0x194, 3);
}
function homingShotTail(c, f, cnt, pattern, loops) {
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame === 2) {
        spawnFromBody(c, f, pattern, -0x1e, 0x1e, 2);
    }
    if (c.frame === 7 && c.f3138 < loops) {
        c.f3138 = c.f3138 + 1;
        c.frame = c.frame - 4;
        return;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    c.timer++;
    if (c.timer >= dur) homingShotTail(c, f, cnt, 0x197, 1);
}
function state260(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    c.timer++;
    if (c.timer >= dur) homingShotTail(c, f, cnt, 0x19a, 1);
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        rfCostEffect(c, f);
    }
    c.timer++;
    if (c.timer >= dur) homingShotTail(c, f, cnt, 0x1c4, 3);
}
function airShot408(c, loops) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = c.vx * 0.5;
        c.vy = c.vy * 0.5;
        c.ay = 0.01;
        c.meter = s16(c.meter + 0x2d);
        c.f3138 = loops;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 4) {
            spawnFromBody(c, f, 0x198, 0x24, 0x30, 2);
            c.voiceRequest = 5;
        }
        if (c.frame === 7 && c.f3138 > 0) {
            c.frame = c.frame - 2;
            c.f3138 = c.f3138 - 1;
        }
        if (c.frame >= cnt) {
            c.state = 9;
            c.onStateChange();
        }
    }
}
function state262(c) {
    airShot408(c, 4);
}
function state263(c) {
    airShot408(c, 3);
}
function rain418(c, dx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.f3138 = 2;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.voiceRequest = 6;
        spawnFromBody(c, f, 0x1a2, dx[0], 0x1e0, 2);
        f.x = Math.trunc(c.x) + c.facing * dx[1];
        f.y = Math.trunc(c.y) - 0x208;
        frameChild(c, f);
        f.x = Math.trunc(c.x) + c.facing * dx[2];
        f.y = Math.trunc(c.y) - 0x212;
        frameChild(c, f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state265(c) {
    rain418(c, [
        0x64,
        0x50,
        0x82
    ]);
}
function state266(c) {
    rain418(c, [
        0xb4,
        0xa0,
        0xd2
    ]);
}
function state267(c) {
    rain418(c, [
        0x104,
        0xf0,
        0x122
    ]);
}
function airHomingShot(c, pattern, loops0, guard) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = c.vx * 0.5;
        c.vy = c.vy * 0.5;
        c.ay = 0.01;
        c.meter = s16(c.meter + 0x2d);
        c.f3138 = loops0;
        if (guard) rfCostEffect(c, f);
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 2 && c.timer === 0) {
            spawnFromBody(c, f, pattern, -0x1e, 0x1e, 2);
        }
        if (c.frame === 7 && c.f3138 < 3) {
            c.f3138 = c.f3138 + 1;
            c.frame = c.frame - 4;
            return;
        }
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 9;
            c.ay = 0.035;
        }
    }
}
function state268(c) {
    airHomingShot(c, 0x197, 3, false);
}
function state269(c) {
    airHomingShot(c, 0x1c2, 3, false);
}
function state270(c) {
    airHomingShot(c, 0x1c4, 0, true);
}
registerStates({
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    265: state265,
    266: state266,
    267: state267,
    268: state268,
    269: state269,
    270: state270
});
function childAnimFree(c, i, clearHit) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (clearHit) ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function simpleHit(c, i, hits) {
    const ch = c.children[i];
    if (ch.frame === 0) ch.hitsLeft = hits;
    childAnimFree(c, i, true);
}
function child401(c, i) {
    simpleHit(c, i, 3);
}
function fallLanding(c, i) {
    const ch = c.children[i];
    if (ch.frame === 1 && ch.timer === 0x5f) ch.blend = 1;
    if (ch.y > 0.0 && ch.frame === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.frame = 1;
        c.seRequest = 4;
        ch.timer = 0;
    }
}
function child402(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0) {
        ch.vx = 2.0;
        ch.vy = 2.0;
        ch.hitsLeft = 1;
    }
    fallLanding(c, i);
    childAnimFree(c, i, true);
}
function child404(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && c.a3158[i] === 0) {
        ch.vx = 2.0;
        ch.vy = 2.0;
        ch.hitsLeft = 4;
        c.a3158[i] = c.a3158[i] + 1;
    }
    fallLanding(c, i);
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 1) ch.frame = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function homing(c, i, maxVx, countUp) {
    const ch = c.children[i];
    ch.vx = ch.vx + ch.ax;
    ch.vy = ch.vy + ch.ay;
    if (ch.vx < -maxVx) {
        ch.vx = -maxVx;
    } else if (ch.vx > maxVx) {
        ch.vx = maxVx;
    }
    if (ch.vy < -0.4) {
        ch.vy = -0.4;
    } else if (ch.vy > 0.4) {
        ch.vy = 0.4;
    }
    if (countUp) c.a3158[i] = c.a3158[i] + 1;
    if (ch.facing !== c.facing) {
        ch.vx = -ch.vx;
        ch.facing = c.facing;
    }
    if (ch.x <= c.x) ch.ax = c.facing * 0.01;
    if (ch.x > c.x) ch.ax = c.facing * -0.01;
    if (c.y - 40.0 >= ch.y) ch.ay = 0.01;
    if (c.y - 40.0 < ch.y) ch.ay = -0.01;
}
function child405(c, i) {
    const ch = c.children[i];
    c.f3148 = 1;
    if (c.state > 0x31 && c.state < 0x96) {
        c.freeChild(i);
        c.f3148 = 0;
        return;
    }
    if (c.a3158[i] >= 0x208) {
        ch.pattern = 0x199;
        ch.timer = 0;
        ch.frame = 0;
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.blend = 2;
        ch.hitsLeft = 1;
        c.voiceRequest = 5;
        c.f3148 = 0;
        return;
    }
    homing(c, i, 0.7, true);
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
}
function launcher(c, i, pattern) {
    const ch = c.children[i];
    if (ch.frame === 2 && ch.timer === 0) {
        const f = childSpawnFrame;
        f.w04 = pattern;
        f.x = Math.trunc(ch.x);
        f.y = Math.trunc(ch.y);
        f.b18 = ch.facing;
        f.b21 = 1;
        f.b20 = 0;
        f.d00 = 1;
        frameChild(c, f);
    }
    childAnimFree(c, i, true);
}
function child407(c, i) {
    launcher(c, i, 0x1b1);
}
function child408(c, i) {
    const ch = c.children[i];
    if (c.state === 0x106 || c.state === 0x107 || c.state === 0x108) {
        ch.x = c.facing * 0x24 + c.x;
        ch.y = c.y - 48.0;
    }
    if (ch.frame === 0) ch.hitsLeft = 3;
    childAnimFree(c, i, true);
}
function child409(c, i) {
    simpleHit(c, i, 1);
}
function child410(c, i) {
    launcher(c, i, 0x1b2);
}
function child417(c, i) {
    const ch = c.children[i];
    if (c.state === 0xff) {
        ch.x = c.facing * 0x17 + c.x;
        ch.y = c.y - 48.0;
    }
    if (c.state !== 0xff) c.freeChild(i);
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 0x18 && c.frame < 7) ch.frame = 0;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child418(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = 0.0;
        ch.vy = 2.0;
        ch.ay = 0.035;
    }
    if (ch.frame === 0) {
        ch.vy = ch.vy + ch.ay;
        if (ch.hitState > 1 || ch.y >= 0.0) {
            ch.frame = 1;
            c.shakeScreen(3, 0);
            ch.timer = 0;
            c.seRequest = 0x22;
            ch.vy = 0.0;
        }
    }
    childAnimFree(c, i, false);
}
function child427(c, i) {
    simpleHit(c, i, 1);
}
function child428(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        if (c.f3140 === 0) {
            c.a3158[i] = 0x1d;
            c.a3258[i] = -52;
        }
        if (c.f3140 === 1) {
            c.a3158[i] = 0x24;
            c.a3258[i] = -38;
        }
        if (c.f3140 === 2) {
            c.a3158[i] = 0x24;
            c.a3258[i] = -72;
        }
    }
    if (c.state === 0x106 || c.state === 0x107 || c.state === 0x108) {
        ch.x = c.facing * c.a3158[i] + c.x;
        ch.y = c.a3258[i] + c.y;
    }
    if (ch.frame === 0) ch.hitsLeft = 1;
    childAnimFree(c, i, true);
}
function burstIfHit(c, i, facing) {
    const ch = c.children[i];
    if (c.state > 0x31 && c.state < 0x96 || ch.hitState === 4 || ch.hitState === 5) {
        const f = childSpawnFrame;
        f.w04 = 0x19c;
        f.x = Math.trunc(ch.x);
        f.y = Math.trunc(ch.y);
        f.b20 = 0;
        f.b21 = 1;
        f.b18 = facing;
        frameChild(c, f);
        f.w04 = 0x19d;
        frameChild(c, f);
        f.w04 = 0x19e;
        frameChild(c, f);
        f.w04 = 0x19f;
        frameChild(c, f);
        f.w04 = 0x1a0;
        frameChild(c, f);
        c.freeChild(i);
        c.f3148 = 0;
        return true;
    }
    return false;
}
function dashDecel(c, i) {
    const ch = c.children[i];
    if (ch.frame > 3) {
        ch.vx = ch.vx - 0.15;
        if (ch.vx < 0.1) ch.vx = 0.1;
    }
}
function child433(c, i) {
    const ch = c.children[i];
    c.f3148 = 1;
    if (burstIfHit(c, i, c.facing)) return;
    if (ch.frame < 4) homing(c, i, 0.7, false);
    dashDecel(c, i);
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame === 4 && c.a3158[i] < 1) {
        ch.frame = 0;
        c.a3158[i] = c.a3158[i] + 1;
        abortChildWalk();
        return;
    }
    if (ch.frame === 4) {
        ch.hitsLeft = 1;
        ch.vx = 4.0;
        ch.vy = 0.0;
        c.seRequest = 0x14;
        abortChildWalk();
        return;
    }
    if (ch.frame === 7 && c.a3158[i] < 3) {
        ch.frame = 3;
        c.a3158[i] = c.a3158[i] + 1;
    }
    if (ch.frame === 8) ch.blend = 1;
    if (ch.frame >= childCount) {
        c.freeChild(i);
        c.f3148 = 0;
    }
}
function burst409Tail(c, i, spawnFacing) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame === 4 && c.a3158[i] < 2) {
        ch.frame = 0;
        c.a3158[i] = c.a3158[i] + 1;
        abortChildWalk();
        return;
    }
    if (ch.frame === 5 && c.a3158[i] < 3) {
        ch.frame = ch.frame - 1;
        c.a3158[i] = c.a3158[i] + 1;
        ch.vx = 0.0;
        ch.vy = 0.0;
        const f = childSpawnFrame;
        f.w04 = 0x199;
        f.x = Math.trunc(ch.x) + ch.facing * 0x13;
        f.y = Math.trunc(ch.y) + 2;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = spawnFacing();
        frameChild(c, f);
        c.voiceRequest = 5;
    }
    if (ch.frame === 6) ch.blend = 1;
    if (ch.frame >= childCount) {
        c.freeChild(i);
        c.f3148 = 0;
    }
}
function child434(c, i) {
    const ch = c.children[i];
    c.f3148 = 1;
    if (burstIfHit(c, i, c.facing)) return;
    if (ch.frame < 4) homing(c, i, 0.8, false);
    dashDecel(c, i);
    burst409Tail(c, i, ()=>c.facing);
}
function child450(c, i) {
    launcher(c, i, 0x1c3);
}
function child451(c, i) {
    const ch = c.children[i];
    c.f3148 = 1;
    ch.vx = 0.0;
    ch.vy = 0.0;
    if (burstIfHit(c, i, ch.facing)) return;
    burst409Tail(c, i, ()=>ch.facing);
}
function child452(c, i) {
    launcher(c, i, 0x1c6);
}
function child453(c, i) {
    const ch = c.children[i];
    c.f3148 = 1;
    ch.hitsLeft = 1;
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 0xc || ch.frame === 0x18) ch.hitState = 0;
    if (ch.frame === 0x18 && c.a3158[i] < 3) {
        ch.frame = 0;
        c.a3158[i] = c.a3158[i] + 1;
        return;
    }
    if (ch.frame >= childCount) {
        c.freeChild(i);
        c.f3148 = 0;
    }
}
function child454(c, i) {
    const ch = c.children[i];
    c.f3148 = 1;
    if (burstIfHit(c, i, c.facing)) return;
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.vx = 1.65;
        ch.vy = 0.5;
    }
    ch.vx = ch.vx - 0.01;
    ch.vy = ch.vy - 0.013;
    if (ch.vx < 0.0) ch.vx = 0.0;
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame < childCount) return;
    if (c.a3158[i] < 0) {
        c.a3158[i] = c.a3158[i] + 1;
        ch.frame = 0;
        return;
    }
    ch.pattern = 0x1c5;
    ch.frame = 0;
    ch.timer = 0;
    ch.blend = 2;
    ch.hitState = 0;
    ch.vx = 0.0;
    ch.vy = 0.0;
    c.a3158[i] = 0;
}
registerChildren({
    401: child401,
    402: child402,
    404: child404,
    405: child405,
    407: child407,
    408: child408,
    409: child409,
    410: child410,
    417: child417,
    418: child418,
    427: child427,
    428: child428,
    433: child433,
    434: child434,
    450: child450,
    451: child451,
    452: child452,
    453: child453,
    454: child454
});
