import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerStates } from "./dfcb3299a1af62aa24eb2aa0.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./e4446f6179e9bf5107313c92.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function drawIcon(c, pattern) {
    const f = c.patterns[pattern]?.frames[0];
    if (!f) return;
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    const src = makeRect(0, 0, f.width, f.height);
    const x = c.side === 0 ? 0x2d - f.offsetX : f.offsetX + 0x113 - f.width;
    const dst = makeRect(x, 0x1f - f.offsetY, f.width, f.height);
    blit(dst, surf, src, c.colorKey, false);
}
export function renderOverlayMio(c) {
    if (c.f3150 === 0) drawIcon(c, 43);
    if (c.f3150 === 1) drawIcon(c, 44);
}
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
const LEVEL_PAT = [
    0x44,
    0x45,
    0x46
];
const LEVEL_SOUND = [
    0x13,
    5,
    0x40
];
function superStart(c, d, cost, level, x, y) {
    c.stopMotion();
    c.freeze = 0x78;
    if (cost !== 0) c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
    d.w04 = LEVEL_PAT[level];
    d.b2c = LEVEL_SOUND[level];
    d.x = x;
    d.y = y;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function endToNeutral(c, state = 0) {
    c.state = state;
    c.faceOpponent();
    c.onStateChange();
}
function jumpSuper(c, level, childPat) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 3)) {
        c.vy = -1.1;
        c.vx = c.vx * 0.5;
    }
    if (atFrame(c, 3)) {
        superStart(c, d, (level + 1) * 1000, level, ftol(c.x), ftol(c.y) - 0x28);
        if (level === 2) c.seRequest = 0x25;
    }
    if (level === 2 && c.frame > 4) c.showAltBackground(0xf);
    if (c.frame > 2 && c.frame < 7) c.vy = c.vy + 0.012;
    if (c.frame === 8 || c.frame === 9) c.vy = c.vy + 0.03;
    if (c.frame === 5) c.vy = 0.0;
    if (atFrame(c, 9) && c.f3138 === 0) {
        d.w04 = childPat;
        d.x = ftol(c.x) + c.facing * 0x3c;
        d.y = ftol(c.y) - 0x2f;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 2;
        frameChild(c, d);
    }
    if ((c.frame === 9 || c.frame === 10) && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.timer = 0;
        c.frame = 0xb;
        c.stopMotion();
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 9) {
        c.seRequest = 0x16;
        c.vx = c.vx - 0.7;
        c.vy = c.vy - 1.5;
    }
    if (c.frame === 0xb && c.f3138 < 0x10) {
        c.f3138++;
        c.frame -= 2;
    }
    if (c.frame === 0xc && c.y < 0.0) {
        c.state = 9;
        c.onStateChange();
    }
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function shotSuper(c, level) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) {
        superStart(c, d, (level + 1) * 1000, level, ftol(c.x), ftol(c.y) - 0x26);
        c.w16c = level === 0 ? 8 : 0xf;
    }
    if (c.frame > 2 && c.frame < 6 && !(c.f3140 > 0.0)) {
        d.w04 = 0x1be;
        d.x = ftol(c.x) + c.facing * 0x32;
        d.y = ftol(c.y) - 0x2b;
        d.b20 = 2;
        d.d00 = 0;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.f3140 = level === 0 ? 21.0 : 15.0;
        c.voiceRequest = 6;
    }
    c.f3140 = c.f3140 - 1.0;
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 6) {
        c.f3138++;
        if (level === 0) {
            if (c.f3138 > 5) c.w16c = 0;
            if (c.f3138 < 8) c.frame -= 2;
        } else if (c.f3138 < 7) {
            c.frame -= 2;
        }
    }
    if (c.frame >= cnt) endToNeutral(c);
}
function state311(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) {
        superStart(c, d, 0xbb8, 2, ftol(c.x), ftol(c.y) - 0x26);
        c.w16c = 1;
        c.seRequest = 0x25;
    }
    c.showAltBackground(3);
    if (atFrame(c, 3)) {
        c.seRequest = 0x12;
        d.w04 = 0x1be;
        d.x = ftol(c.x) + c.facing * 0x32;
        d.y = ftol(c.y) - 0x2b;
        d.b20 = 2;
        d.d00 = 0;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.voiceRequest = 6;
    }
    if (c.d168 === 3 && c.f3138 === 0) {
        const o = c.opponent;
        o.hitstop = s16(o.hitstop + 0xb4);
        c.f3138++;
        d.w04 = 0x1bf;
        d.x = ftol(o.x);
        d.y = ftol(o.y) - 0x32;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function spawn426x3(c, d, resetLayers) {
    c.seRequest = 0x20;
    d.w04 = 0x1aa;
    d.x = ftol(c.x) - c.facing * 0xf;
    d.y = ftol(c.y) - 0x41;
    d.b18 = c.facing;
    d.b21 = 1;
    d.b20 = 0;
    frameChild(c, d);
    d.x = ftol(c.x) - c.facing * 0x14;
    d.y = ftol(c.y) - 0x2d;
    if (resetLayers) d.b21 = 0;
    frameChild(c, d);
    d.x = ftol(c.x) - c.facing * 0x19;
    d.y = ftol(c.y) - 0x19;
    if (resetLayers) d.b21 = 0;
    frameChild(c, d);
}
function multiSuper(c, level, loops) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) {
        superStart(c, d, (level + 1) * 1000, level, ftol(c.x) - c.facing * 0xa, ftol(c.y) - 0x28);
        if (level === 2) c.seRequest = 0x25;
    }
    if (level === 2) c.showAltBackground(0xf);
    if (atFrame(c, 0xc)) spawn426x3(c, d, true);
    if (atFrame(c, 0x10)) spawn426x3(c, d, false);
    if (atFrame(c, 0x14)) spawn426x3(c, d, true);
    if (atFrame(c, 0x18)) spawn426x3(c, d, false);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 0x13) {
        c.f3138++;
        if (c.f3138 < loops) c.frame -= 8;
    }
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function state315(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) {
        superStart(c, d, 0xbb8, 2, ftol(c.x), ftol(c.y) - 0x26);
        c.w16c = 1;
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    c.showAltBackground(0xf);
    if (c.d168 === 2 && c.frame > 1 && c.frame < 0xd) {
        c.frame = 0xd;
        c.timer = 0;
        return;
    }
    if (atFrame(c, 0xd)) {
        c.shakeScreen(3, 0);
        d.w04 = 3;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        frameEffect(d);
        c.seRequest = 7;
    }
    if (c.frame > 0xc) {
        c.vx = c.vx - 0.035;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.w16c === 0 && c.frame < 0xd && c.pressed[0] === 1) {
        c.onStateChange();
        c.state = 0x13c;
        c.stopMotion();
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 7) c.vx = 2.0;
    if (c.frame === 0xd) {
        c.f3138++;
        if (c.f3138 < 3) c.frame -= 3;
    }
    if (c.frame >= cnt) endToNeutral(c, 0x60);
}
function comboLink(c, lo, hi, key, next) {
    if (c.d168 === 3 && c.frame > lo && c.frame < hi && c.pressed[key] === 1) {
        c.onStateChange();
        c.state = next;
        c.stopMotion();
        return true;
    }
    return false;
}
function comboAdvance(c, dur, cnt) {
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 1) c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function state316(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.showAltBackground(0xf);
    if (atStart(c)) c.w16c = 1;
    if (atFrame(c, 1)) c.seRequest = 0x14;
    if (comboLink(c, 1, 4, 1, 0x13d)) return;
    comboAdvance(c, dur, cnt);
}
function state317(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.w16c = 1;
    c.showAltBackground(0xf);
    if (atFrame(c, 2)) c.seRequest = 0x14;
    if (comboLink(c, 2, 5, 2, 0x13e)) return;
    comboAdvance(c, dur, cnt);
}
function state318(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.w16c = 1;
    c.showAltBackground(0xf);
    if (atFrame(c, 3)) c.seRequest = 0x15;
    if (comboLink(c, 5, 7, 0, 0x13f)) return;
    comboAdvance(c, dur, cnt);
}
function state319(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.w16c = 1;
    c.showAltBackground(0xf);
    if (atStart(c)) c.seRequest = 0x14;
    if (comboLink(c, 0, 4, 1, 0x140)) return;
    comboAdvance(c, dur, cnt);
}
function state320(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.w16c = 1;
    c.showAltBackground(0xf);
    if (atFrame(c, 1)) c.seRequest = 0x14;
    if (comboLink(c, 1, 4, 2, 0x141)) return;
    comboAdvance(c, dur, cnt);
}
function state321(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.w16c = 4;
    c.showAltBackground(0xf);
    if (atFrame(c, 1)) c.seRequest = 0x14;
    if (c.w16c === 0 && c.frame > 2 && c.frame < 5 && c.pressed[3] === 1) {
        c.onStateChange();
        c.state = 0x142;
        c.stopMotion();
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 5 && c.f3138 < 4) {
        c.frame -= 2;
        c.f3138++;
    }
    if (c.frame >= cnt) endToNeutral(c);
}
function state322(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.w16c = 1;
    c.showAltBackground(0x78);
    if (c.frame > 3) c.showAltBackground(0xf);
    if (atFrame(c, 2)) c.seRequest = 0x14;
    if (c.d168 === 3 && c.frame > 2 && c.frame < 5 && c.command === 0x16) {
        c.onStateChange();
        c.state = 0x143;
        c.stopMotion();
        return;
    }
    if (c.d168 === 3 && c.frame > 2 && c.frame < 5 && c.command === 0xc) {
        c.onStateChange();
        c.state = 0x144;
        c.stopMotion();
        return;
    }
    comboAdvance(c, dur, cnt);
}
function state323(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        superStart(c, d, 0, 2, ftol(c.x), ftol(c.y) - 0xf);
        d.w04 = 0x47;
        frameEffect(d);
        c.w16c = 2;
    }
    c.showAltBackground(0xf);
    if (c.vx > 0.0) c.vx = c.vx - 0.035;
    if (c.vx < 0.0) c.vx = 0.0;
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 0xc) {
        c.frame = 0xc;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame === 7) {
        c.vy = -1.0;
        c.ay = 0.035;
        c.vx = 4.0;
    }
    if (c.frame >= cnt) endToNeutral(c);
}
function state324(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        superStart(c, d, 0, 2, ftol(c.x) - c.facing * 0xf, ftol(c.y) - 0x14);
        d.w04 = 0x47;
        frameEffect(d);
    }
    c.showAltBackground(0xf);
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 4) {
        d.w04 = 0x1ba;
        d.x = ftol(c.x) + c.facing * 0xb;
        d.y = ftol(c.y) - 0x35;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 2;
        frameChild(c, d);
    }
    if (c.frame === 6) {
        c.f3138++;
        if (c.f3138 < 0xf) c.frame -= 2;
    }
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function state330(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) {
        superStart(c, d, 0xbb8, 2, ftol(c.x), ftol(c.y) - 0x26);
        c.w16c = 1;
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    c.showAltBackground(0xf);
    if (c.d168 === 3 && c.frame === 3) {
        c.onStateChange();
        c.stopMotion();
        c.state = 0x14b;
        const o = c.opponent;
        o.onStateChange();
        o.stopMotion();
        o.state = 0x79;
        o.y = 0.0;
        if (o.x > 480.0) o.x = 480.0;
        if (o.x < 160.0) o.x = 160.0;
        return;
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    if (c.frame >= cnt) endToNeutral(c);
}
function spawn331Pair(c, d, pat, x, y) {
    d.w04 = pat;
    d.x = x;
    d.y = y;
    d.b18 = c.facing;
    d.b21 = 1;
    d.b20 = 0;
    d.d28 = 1;
    frameChild(c, d);
    d.w04 = 0x1b9;
    d.b21 = 0;
    d.y = 0.0;
    d.b20 = 2;
    frameChild(c, d);
}
function state331(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.d128 = 1;
    c.biasCameraY(0x32, 3);
    o.biasCamera(0x32, 3);
    if (o.state === 0x63 || o.state === 0x79) o.timer = 0;
    if (c.frame < 6) c.superDarken(0xb0, 3);
    else c.f3148 = 1.0;
    c.showAltBackground(0xf);
    if (c.f3140 === 1.0 && o.state !== 0x47) {
        applyDirectDamage(c, 0x1388, 800.0);
        o.onStateChange();
        o.stopMotion();
        o.state = 0x47;
        o.knockY = -15.0;
        o.knockX = 0.0;
        o.y = -10.0;
        o.vx = 0.0;
    }
    c.timer++;
    if (c.frame < 6 && c.timer >= dur - 0x1e) c.f3148 = 1.0;
    if (c.timer < dur) return;
    c.f3148 = 0.0;
    c.timer = 0;
    c.frame++;
    const ox = ()=>ftol(o.x);
    if (c.frame === 1) {
        spawn331Pair(c, d, 0x1ab, ox() + c.facing * 0x1e, 0.0);
        spawn331Pair(c, d, 0x1b2, ox() - c.facing * 0x1e, 0.0);
        o.state = 0x63;
        c.voiceRequest = 9;
    }
    if (c.frame === 2) {
        spawn331Pair(c, d, 0x1ac, ox() + c.facing * 0x28, -40.0);
        spawn331Pair(c, d, 0x1b3, ox() - c.facing * 0x1e, 0.0);
        o.state = 0x63;
        c.voiceRequest = 9;
    }
    if (c.frame === 3) {
        spawn331Pair(c, d, 0x1ad, ox() + c.facing * 0x3c, 0.0);
        spawn331Pair(c, d, 0x1b4, ox(), 0.0);
        d.w04 = 0x1b9;
        d.b21 = 0;
        d.x = ox() - c.facing * 0x3c;
        d.b20 = 2;
        frameChild(c, d);
        o.state = 0x63;
        c.voiceRequest = 9;
    }
    if (c.frame === 4) {
        spawn331Pair(c, d, 0x1ae, ox() + c.facing * 0x1e, 0.0);
        spawn331Pair(c, d, 0x1b5, ox() - c.facing * 0x1e, 0.0);
        o.state = 0x63;
        c.voiceRequest = 9;
    }
    if (c.frame === 5) {
        spawn331Pair(c, d, 0x1af, ox() + c.facing * 0x3c, 0.0);
        spawn331Pair(c, d, 0x1b6, ox() + c.facing * 0xf, 0.0);
        d.w04 = 0x1b9;
        d.b21 = 0;
        d.x = ox() - c.facing * 0x41;
        frameChild(c, d);
        o.state = 0x63;
        c.voiceRequest = 9;
    }
    if (c.frame === 6) {
        d.w04 = 0x1b0;
        d.x = ox() + c.facing * 0x3c;
        d.y = 0.0;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 0;
        d.d28 = 1;
        frameChild(c, d);
        d.w04 = 0x1b7;
        d.x = ox() - c.facing * 0x3c;
        d.y = 0.0;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 0;
        d.d28 = 1;
        frameChild(c, d);
        o.state = 0x63;
        c.voiceRequest = 9;
    }
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0x47;
        c.faceOpponent();
        c.onStateChange();
        c.stopMotion();
        c.knockY = -3.0;
        c.knockX = 0.0;
        c.y = -640.0;
    }
}
registerStates({
    306: (c)=>jumpSuper(c, 0, 0x1a2),
    307: (c)=>jumpSuper(c, 1, 0x1a8),
    308: (c)=>jumpSuper(c, 2, 0x1a9),
    309: (c)=>shotSuper(c, 0),
    310: (c)=>shotSuper(c, 1),
    311: state311,
    312: (c)=>multiSuper(c, 0, 1),
    313: (c)=>multiSuper(c, 1, 2),
    314: (c)=>multiSuper(c, 2, 4),
    315: state315,
    316: state316,
    317: state317,
    318: state318,
    319: state319,
    320: state320,
    321: state321,
    322: state322,
    323: state323,
    324: state324,
    330: state330,
    331: state331
});
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    if (childStep(c, i) && c.children[i].frame >= childCount) c.freeChild(i);
}
function childOnceRise(c, i) {
    childOnce(c, i);
    if (c.children[i].y < -640.0) c.freeChild(i);
}
function childGrab(c, i) {
    childOnce(c, i);
    if (c.f3148 === 1.0) {
        c.freeChild(i);
        c.opponent.onStateChange();
        c.opponent.state = 0x79;
    }
}
function childMultiHitStep(c, i, loopFrame) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    const f = ch.frame;
    if (f === 2 || f === 5 || f === 8 || f === 0xb || f === 0xe || f === 0x11 || f === 0x14 || f === 0x17) ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = loopFrame;
}
function childOffscreen(c, i) {
    const ch = c.children[i];
    if (ch.x < -100.0 || ch.x > 800.0 || ch.y > 0.0) c.freeChild(i);
}
function childMultiHitInit(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) {
        ch.hitsLeft = 7;
        ch.vx = 1.0;
        c.a3158[i]++;
    }
}
function spawn419(c, i) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    d.w04 = 0x1a3;
    d.x = ftol(ch.x) + ch.facing * 0x28;
    d.y = ftol(ch.y);
    d.b18 = c.facing;
    d.b20 = 2;
    d.b21 = 1;
    frameChild(c, d);
}
function child418(c, i) {
    const ch = c.children[i];
    childMultiHitInit(c, i);
    ch.vx = ch.vx + 0.02;
    childMultiHitStep(c, i, 0);
    childOffscreen(c, i);
}
function child424(c, i) {
    const ch = c.children[i];
    childMultiHitInit(c, i);
    if (c.a3258[i] < 0) {
        spawn419(c, i);
        c.a3258[i] = 0x12;
    }
    c.a3258[i]--;
    ch.vx = ch.vx + 0.03;
    childMultiHitStep(c, i, 1);
    childOffscreen(c, i);
}
function child425(c, i) {
    const ch = c.children[i];
    childMultiHitInit(c, i);
    const d = childSpawnFrame;
    d.w04 = 0x24;
    const ex = ftol(ch.x) + 0x28;
    d.x = ex - c.random(0, 0x50);
    const ey = ftol(ch.y) + 0x28;
    d.y = ey - c.random(0, 0x50);
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    if (c.a3258[i] < 0) {
        spawn419(c, i);
        c.a3258[i] = 6;
        if (ch.y > -80.0 && c.a3358[i] < 0) {
            d.w04 = 0x1f;
            d.x = ftol(ch.x);
            d.y = 0.0;
            d.b20 = 0;
            d.b21 = 1;
            d.d1c = ch.facing === -1 ? 1 : 0;
            frameEffect(d);
            c.a3358[i] = 3;
        }
        c.a3358[i]--;
    }
    c.a3258[i]--;
    ch.vx = ch.vx + 0.04;
    childMultiHitStep(c, i, 1);
    childOffscreen(c, i);
}
function child426(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        ch.vx = 6.0;
        ch.vy = -4.5;
    }
    childOnceRise(c, i);
}
function child432(c, i) {
    const ch = c.children[i];
    childOnce(c, i);
    if (c.f3140 === 1.0) {
        ch.timer = 0;
        ch.pattern = 0x1b1;
    }
}
function child433(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = -15.0;
    }
    childOnceRise(c, i);
}
function child439(c, i) {
    const ch = c.children[i];
    if (ch.frame === 1 && ch.timer === 0) c.voiceRequest = 0xa;
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        const d = childSpawnFrame;
        d.w04 = 0x1bb;
        d.x = ftol(c.opponent.x);
        d.y = 0.0;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 2;
        frameChild(c, d);
        ch.timer = 0;
        ch.frame = 0;
        ch.pattern = 0x1b8;
        ch.vy = -15.0;
        c.f3140 = 1.0;
        c.voiceRequest = 8;
    }
}
function child441(c, i) {
    childOnce(c, i);
    if (c.f3148 === 1.0) c.freeChild(i);
}
function child442(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 2;
    if (c.state !== 0x144 || c.frame > 5) {
        c.freeChild(i);
        return;
    }
    if (childStep(c, i) && ch.frame >= childCount) ch.frame = 0;
}
registerChildren({
    418: child418,
    419: childOnce,
    424: child424,
    425: child425,
    426: child426,
    427: childGrab,
    428: childGrab,
    429: childGrab,
    430: childGrab,
    431: childGrab,
    432: child432,
    433: child433,
    434: childGrab,
    435: childGrab,
    436: childGrab,
    437: childGrab,
    438: childGrab,
    439: child439,
    440: childOnceRise,
    441: child441,
    442: child442,
    443: childOnceRise,
    446: childOnce,
    447: childOnce
});

export function __logicState(){return {LEVEL_PAT,LEVEL_SOUND};}

export function __installInitialRoots(s){
if(LEVEL_PAT!==s["LEVEL_PAT"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_PAT');
if(LEVEL_SOUND!==s["LEVEL_SOUND"])throw Error('INITIAL_CONST_IDENTITY:LEVEL_SOUND');
}
