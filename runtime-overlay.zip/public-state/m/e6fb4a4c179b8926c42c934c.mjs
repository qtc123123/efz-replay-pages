import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { frameEffect, openSpawnFrame } from "./8a0ae749d7e9ba4d08c1d570.mjs";
import { registerStates } from "./4f243a87eb42ac119eae883d.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
function rfCost(c) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
}
function effect21(c, f) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = ftol(c.x) + c.facing * 0x14;
    f.y = ftol(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function grabConnect(c, f, next, stopSelf) {
    const o = c.opponent;
    o.onStateChange();
    o.stopMotion();
    o.state = 0x6b;
    c.onStateChange();
    if (stopSelf) c.stopMotion();
    c.state = next;
    c.y = c.pointsY[0] + 0x32;
    c.x = (-c.pointsX[0] - 0x14) * c.facing + o.x;
    f.w04 = 0;
    f.x = ftol(c.x) + c.facing * 7;
    f.y = ftol(c.y) - 0x2c;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function opponentPoint0(o) {
    return {
        x: o.pointsX[0],
        y: o.pointsY[0]
    };
}
function rushGrab(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 0) {
        if (p.ex) {
            c.w16c = 0;
            c.stopMotion();
            rfCost(c);
            effect21(c, f);
        } else {
            c.stopMotion();
            c.w16c = 0;
        }
    }
    if (c.frame > 2 && c.frame < 8 && c.d168 === 3) {
        grabConnect(c, f, p.next, p.ex);
        return;
    }
    if (c.frame > 2 && c.frame < 8 && (!p.needF3140 || c.f3140 > 0)) {
        if (o.y === 0.0) c.w16c = 1;
        else c.w16c = 0;
    }
    if (c.frame === 6) c.f3140 = 1;
    if (c.frame > 7) {
        c.vx = c.vx - 0.035;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 1) c.w16c = 0;
        if (c.frame === 3) c.vx = p.speed;
        if (c.frame === 8) {
            c.frame = 3;
            c.f3138++;
        }
        if (c.frame === 6 && c.f3138 > p.loops) c.frame = 8;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 3;
            c.faceOpponent();
        }
    }
}
function state250(c) {
    rushGrab(c, {
        ex: false,
        needF3140: false,
        speed: 1.8,
        loops: 1,
        next: 0xfd
    });
}
function state251(c) {
    rushGrab(c, {
        ex: false,
        needF3140: true,
        speed: 2.4,
        loops: 2,
        next: 0xfd
    });
}
function state252(c) {
    rushGrab(c, {
        ex: true,
        needF3140: false,
        speed: 1.8,
        loops: 1,
        next: 0xfe
    });
}
function throwCarry(c) {
    const o = c.opponent;
    if (c.frame < 3) {
        c.vx = c.vx - 0.035;
        if (c.vx < 0.0) c.vx = 0.0;
        if (o.wallBlock() !== 0) {
            c.stopMotion();
            o.stopMotion();
        }
        if (o.wallBlock() === 0) {
            o.x = (c.pointsX[0] + 0x14) * c.facing + c.x;
        }
    }
    if (c.frame === 3) {
        o.state = 0x76;
        o.x = (15.0 + c.vx) * c.facing + c.x;
        o.y = -69.0 + c.vy + c.y;
    }
    if (c.frame > 2) c.vy = c.vy + c.ay;
    if (c.frame > 3 && c.vy + c.y > 0.0) {
        c.onStateChange();
        c.stopMotion();
        c.state = 3;
        c.y = 0.0;
        return true;
    }
    return false;
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (throwCarry(c)) return;
    if (c.frame === 4 && c.timer === 0) {
        o.onStateChange();
        o.state = 0x3f;
        o.x = (-31.0 + c.vx) * c.facing + c.x;
        o.y = -33.0 + c.vy + c.y;
        applyDirectDamage(c, 0x1f4, 750.0);
        c.comboCount = s16(c.comboCount - 1);
        c.comboDisplay = s16(c.comboDisplay - 1);
        o.knockX = 0.8;
        o.knockY = -3.2;
    }
    if (c.frame < 4) {
        c.biasCamera(0x32, 3);
        c.biasCameraY(0x32, 3);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 3) {
            c.vx = -1.0;
            c.vy = -1.3;
            c.ay = 0.03;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (throwCarry(c)) return;
    if (c.frame === 4 && c.timer === 0) {
        o.onStateChange();
        o.state = 0x43;
        o.x = (-41.0 + c.vx) * c.facing + c.x;
        o.y = -43.0 + c.vy + c.y;
        applyDirectDamage(c, 0x3e8, 800.0);
        c.comboCount = s16(c.comboCount - 1);
        c.comboDisplay = s16(c.comboDisplay - 1);
        o.facing = c.facing;
        o.knockX = -4.0;
        o.knockY = -0.8;
    }
    if (c.frame < 4) {
        c.biasCamera(0x32, 3);
        c.biasCameraY(0x32, 3);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 3) {
            c.vx = -1.0;
            c.vy = -2.1;
            c.ay = 0.025;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = c.vx * 0.3;
        c.vy = c.vy * 0.5;
        c.ay = 0.035;
        c.w16c = 9;
    }
    if ((c.frame === 1 || c.frame === 3 || c.frame === 7) && c.timer === 0) c.seRequest = 0x15;
    if (c.frame > 10) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0) {
        c.onStateChange();
        c.stopMotion();
        c.state = 0x102;
        c.y = 0.0;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 5 && c.f3138 < 3) {
            c.f3138++;
            c.frame = 0;
        }
    }
    if (c.frame >= cnt) c.frame = c.frame - 4 & 0xffff;
}
function dive(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        if (p.face) c.faceOpponent();
        c.stopMotion();
    }
    if (c.frame === 3 && c.timer === 0) {
        c.vx = p.vx;
        c.vy = p.vy;
        c.w16c = 1;
        c.seRequest = 0x23;
        c.meter = s16(c.meter + 0x23);
    }
    if (p.hitTo288 && c.d168 > 0) {
        c.onStateChange();
        c.stopMotion();
        c.state = 0x120;
        return;
    }
    if (c.y + c.vy > 0.0 && c.frame > 2) {
        c.timer = 0;
        c.frame = 0;
        c.y = 0.0;
        c.stopMotion();
        c.state = p.land;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.w16c > 0) c.d168 = 0;
        if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
    }
}
function state256(c) {
    dive(c, {
        face: true,
        vx: 0.5,
        vy: 3.0,
        hitTo288: false,
        land: 0x101
    });
}
function state269(c) {
    dive(c, {
        face: false,
        vx: 0.5,
        vy: 3.0,
        hitTo288: false,
        land: 0x108
    });
}
function state270(c) {
    dive(c, {
        face: false,
        vx: 2.2,
        vy: 2.2,
        hitTo288: false,
        land: 0x108
    });
}
function state285(c) {
    dive(c, {
        face: false,
        vx: 0.5,
        vy: 3.0,
        hitTo288: true,
        land: 0x109
    });
}
function state286(c) {
    dive(c, {
        face: false,
        vx: 2.2,
        vy: 2.2,
        hitTo288: true,
        land: 0x109
    });
}
function state287(c) {
    dive(c, {
        face: false,
        vx: 4.0,
        vy: 1.5,
        hitTo288: true,
        land: 0x109
    });
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.04;
    if (c.vx < 0.0) c.vx = 0.0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
        }
    }
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.05;
    if (c.vx < 0.0) c.vx = 0.0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 3;
            c.stopMotion();
        }
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame > 8 && c.frame < 15 && c.isHeld(0) > 0) {
        c.setState(0x106);
        return;
    }
    if (c.frame > 8 && c.frame < 15 && c.isHeld(1) > 0) {
        c.setState(0x107);
        return;
    }
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame > 7) {
        c.vx = c.vx - 0.02;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame === 7 && c.timer === 0) {
        c.w16c = 1;
        c.vx = 3.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.w16c > 0) c.d168 = 0;
        if (c.frame === 12 && c.f3138 < 3) {
            c.frame -= 4;
            c.f3138++;
        }
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state260(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    c.vy = c.vy + c.ay;
    if (c.frame > 13) {
        c.vx = c.vx - 0.03;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.command === 10 && c.frame > 13) {
        c.setState(0x122);
        return;
    }
    if (c.y < 0.0 && c.vy > 0.0 && c.pressed[0] === 1) {
        c.onStateChange();
        c.stopMotion();
        c.state = 0x100;
        return;
    }
    if (c.vy + c.y > 0.0 && c.frame > 5 && c.frame < 10) {
        c.frame = 14;
        c.timer = 0;
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        return;
    }
    if (c.vy + c.y > 0.0 && c.frame > 9 && c.frame < 14) {
        c.frame = 14;
        c.timer = 0;
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 1) c.d168 = 0;
        if (c.frame === 3) {
            c.vx = 1.2;
            c.vy = -3.3;
            c.ay = 0.055;
            c.w16c = 1;
        }
        if (c.frame === 10) c.frame -= 4;
        if (c.frame === 14) c.frame -= 4;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        rfCost(c);
        effect21(c, f);
        c.y = c.y - 25.0;
        c.vx = 3.0;
        c.w16c = 1;
    }
    c.vy = c.vy + c.ay;
    if (c.frame > 9) {
        c.vx = c.vx - 0.03;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.d168 > 1 && c.frame > 1 && c.frame < 6) {
        c.frame = 6;
        c.timer = 0;
        c.vx = -c.vx * 0.1;
        c.vy = -1.5;
        c.ay = 0.036;
        return;
    }
    if (c.vy + c.y > 0.0 && c.frame > 5 && c.frame < 10) {
        c.frame = 10;
        c.timer = 0;
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.w16c > 0) c.d168 = 0;
        if (c.frame === 6) {
            if (c.f3138 < 4) {
                c.frame -= 4;
                c.f3138++;
            } else {
                c.frame = 10;
                c.y = 0.0;
                return;
            }
        }
        if (c.frame === 10) c.frame -= 4;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.035;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.y < 0.0) {
        c.ay = 0.055;
        c.vy = c.vy + c.ay;
    }
    if (c.frame > 4 && c.frame < 15 && c.y + c.vy > 0.0) {
        c.timer = 0;
        c.frame = 15;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 7) c.d168 = 0;
        if (c.frame === 4) {
            c.vy = -3.3;
            c.w16c = 3;
        }
        if (c.frame === 15) c.frame -= 4;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 3;
        }
    }
}
function state263(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    c.vy = c.vy + c.ay;
    if (c.frame > 10) {
        c.vx = c.vx - 0.03;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.y < 0.0 && c.vy > 0.0 && c.pressed[0] === 1) {
        c.onStateChange();
        c.stopMotion();
        c.state = 0x100;
        return;
    }
    if (c.vy + c.y > 0.0 && c.frame > 2 && c.frame < 10) {
        c.onStateChange();
        c.stopMotion();
        c.y = 0.0;
        c.state = 0x102;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 1) c.d168 = 0;
        if (c.frame === 3) {
            c.vx = 0.8;
            c.vy = -3.1;
            c.ay = 0.055;
            c.w16c = 1;
        }
        if (c.frame >= cnt) c.frame = c.frame - 4 & 0xffff;
    }
}
function hop(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.w16c = 1;
    }
    if (c.frame === 2 && c.timer === 0) {
        c.seRequest = 0x15;
        c.meter = s16(c.meter + 0x23);
        c.w16c = 1;
    }
    if (c.frame > 1) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - p.decel;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.y + c.vy > 0.0 && c.frame === 7) {
        c.frame = 8;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 2) {
            c.ay = p.ay;
            c.vy = p.vy;
            c.vx = p.vx;
        }
        if (c.frame === 6 && c.f3138 < 1) {
            c.frame -= 2;
            c.f3138++;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state266(c) {
    hop(c, {
        decel: 0.06,
        ay: 0.09,
        vy: -3.0,
        vx: 3.0
    });
}
function state267(c) {
    hop(c, {
        decel: 0.06,
        ay: 0.11,
        vy: -4.5,
        vx: 4.0
    });
}
function state268(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.w16c = 1;
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 2 && c.timer === 0) {
        c.seRequest = 0x15;
        c.meter = s16(c.meter + 0x23);
        c.w16c = 1;
    }
    if (c.frame > 1) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - 0.04;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.y + c.vy > 0.0 && c.frame > 8 && c.frame < 13) {
        c.frame = 13;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 1) c.d168 = 0;
        if (c.frame === 2) {
            c.ay = 0.09;
            c.vy = -4.0;
            c.vx = 2.0;
        }
        if (c.frame === 6 && c.f3138 < 1) {
            c.frame -= 2;
            c.f3138++;
        }
        if (c.frame === 13) c.frame -= 4;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function state271(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + 0x28);
        c.w16c = 4;
    }
    if (c.frame > 9 && c.frame < 14) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.y = 0.0;
            c.stopMotion();
            c.onStateChange();
            c.frame = 14;
            return;
        }
    }
    if (c.frame < 7) {
        c.vy = c.vy + c.ay;
        if (c.vy + c.y > 0.0) {
            c.y = 0.0;
            c.vy = 0.0;
            c.onStateChange();
            c.f3138 = ftol(c.vx * 100.0);
            c.vx = 0.0;
            c.frame = 7;
            return;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 7 || c.frame === 14) {
            c.frame -= 4;
            c.f3138++;
        }
        if (c.frame === 9) {
            c.vx = c.f3138 * 0.005;
            c.vy = -0.8;
        }
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
        }
    }
}
function stickToScreenEdge(c) {
    if (c.frame > 11 && c.frame < 16) {
        if (c.facing === 1) c.x = gs.viewLeft + 0xf;
        if (c.facing === -1) c.x = gs.viewRight - 0xf;
    }
}
function wallHit(c, flip) {
    if (c.wallBlock() !== 0 && c.frame > 4 && c.frame < 12) {
        c.vx = 0.0;
        c.vy = 0.0;
        if (flip) c.facing = -c.facing;
        c.frame = 12;
        c.timer = 0;
        c.seRequest = 0x1a;
        return true;
    }
    return false;
}
function wallJump(c, vx4, flip) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame > 19 && c.command === 10) {
        c.setState(0x106);
        return;
    }
    if (c.frame === 4 && c.timer === 0) {
        c.ay = 0.03;
        c.vy = -2.0;
        c.vx = vx4;
    }
    if (c.frame > 15 && c.frame < 20) {
        if (c.inputX === c.facing) c.vx = c.vx + 0.015;
        if (c.inputX === -c.facing) c.vx = c.vx - 0.015;
        if (c.vx < -2.5) {
            c.vx = -2.5;
        } else if (c.vx > 2.5) {
            c.vx = 2.5;
        }
        const derive = c.pressed[0] === 1 ? 0x10d : c.pressed[1] === 1 ? 0x10e : c.pressed[2] === 1 ? 0x10f : 0;
        if (derive !== 0) {
            c.setState(derive);
            if (c.inputX === -c.facing) c.facing = -c.facing;
            return;
        }
    }
    if (c.frame > 4 && c.frame < 12 || c.frame > 15 && c.frame < 20) c.vy = c.vy + c.ay;
    stickToScreenEdge(c);
    if (!(c.y + c.vy < 0.0) && c.frame > 4 && c.frame < 20) {
        c.y = 0.0;
        c.stopMotion();
        c.frame = 20;
        c.timer = 0;
        return;
    }
    if (wallHit(c, flip)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 12) c.frame -= 4;
        if (c.frame === 16) {
            c.vx = 1.5;
            c.vy = -2.5;
            c.ay = 0.035;
        }
        if (c.frame === 20) c.frame -= 4;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state272(c) {
    wallJump(c, -3.0, false);
}
function state274(c) {
    wallJump(c, 3.0, true);
}
function pounceHead(c) {
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 4 && c.timer === 0) {
        c.ay = 0.03;
        c.vy = -1.5;
        c.vx = -3.0;
    }
    if (c.frame === 18 && c.opponent.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
}
function pounceBody(c) {
    if (c.frame > 4 && c.frame < 12 || c.frame > 15 && c.frame < 19) c.vy = c.vy + c.ay;
    stickToScreenEdge(c);
    if (!(c.y + c.vy < 0.0) && c.frame > 15 && c.frame < 19) {
        c.y = 0.0;
        c.stopMotion();
        c.frame = 20;
        c.timer = 0;
        return true;
    }
    return wallHit(c, false);
}
function state273(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    pounceHead(c);
    if (c.frame === 18 && c.d168 === 3) {
        grabConnect(c, f, 0x113, true);
        return;
    }
    if (pounceBody(c)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 12) c.frame -= 4;
        if (c.frame === 16) {
            c.vx = 2.2;
            c.vy = -0.5;
            c.ay = 0.035;
        }
        if (c.frame === 19) c.frame -= 1;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state289(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    pounceHead(c);
    if (pounceBody(c)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 12) c.frame -= 4;
        if (c.frame === 16) {
            c.onStateChange();
            c.stopMotion();
            c.state = 0x11f;
            const o = c.opponent;
            if (c.x - o.x < 140.0 && c.x - o.x > -140.0) c.state = 0x11e;
            if (c.x - o.x < 70.0 && c.x - o.x > -70.0) c.state = 0x11d;
            return;
        }
        if (c.frame === 19) c.frame -= 1;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state275(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.biasCamera(0x32, 3);
    c.biasCameraY(0x32, 3);
    if (c.frame === 4) {
        o.state = 0x67;
        o.x = (23.0 + c.vx) * c.facing + c.x;
        o.y = -54.0 + c.vy + c.y;
    }
    if (c.frame === 5) {
        o.state = 0x67;
        o.x = (15.0 + c.vx) * c.facing + c.x;
        o.y = -70.0 + c.vy + c.y;
    }
    if (c.frame === 6) {
        o.state = 0x76;
        o.x = (-31.0 + c.vx) * c.facing + c.x;
        o.y = -62.0 + c.vy + c.y;
        o.facing = c.facing;
    }
    if (c.frame === 7) {
        o.state = 0x75;
        o.x = (-34.0 + c.vx) * c.facing + c.x;
        o.y = -34.0 + c.vy + c.y;
        o.facing = c.facing;
    }
    if (c.frame === 8) {
        o.state = 0x68;
        o.x = (-6.0 + c.vx) * c.facing + c.x;
        o.y = -3.0 + c.vy + c.y;
        o.facing = -c.facing;
    }
    if (c.frame === 9) {
        o.state = 0x68;
        o.x = (-4.0 + c.vx) * c.facing + c.x;
        o.y = -2.0 + c.vy + c.y;
        o.facing = -c.facing;
    }
    if (c.frame === 10 && c.timer === 0) {
        o.stopMotion();
        o.onStateChange();
        o.state = 0x62;
        o.y = 0.0;
        o.x = c.x;
        applyDirectDamage(c, 0x4b0, 960.0);
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b2c = 2;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
    }
    if (c.frame === 19 && c.y + c.vy > 0.0) {
        c.onStateChange();
        c.stopMotion();
        c.y = 0.0;
        c.state = 0xd;
        return;
    }
    if (c.frame > 15) c.vy = c.vy + c.ay;
    if (c.frame > 13 && o.state === 0x63) o.timer = 0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 16) {
            c.vx = -0.5;
            c.vy = -1.3;
            c.ay = 0.05;
        }
        if (c.frame >= cnt) c.frame = c.frame - 1 & 0xffff;
    }
}
function airDive(c, dur, cnt, vx5, ex) {
    if (c.y + c.vy > 0.0 && c.frame > 4) {
        c.timer = 0;
        c.frame = 12;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    if (c.frame === 5 && c.d168 === 3) {
        if (ex) {
            c.timer = 0;
            c.frame = 8;
            c.w16c = 0x63;
        } else {
            c.vx = c.vx * 0.15;
            c.vy = c.vy * 0.15;
            c.setState(0x123);
        }
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 5) {
            c.vx = vx5;
            c.vy = 2.0;
        }
        if (c.frame === 6) c.frame -= 1;
        if (c.frame === 12) c.frame -= 6;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.faceOpponent();
            c.state = 3;
        }
    }
}
function state280(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.faceOpponent();
        c.stopMotion();
        c.w16c = 1;
    }
    airDive(c, dur, cnt, 0.7, false);
}
function state281(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.faceOpponent();
        c.stopMotion();
        c.w16c = 1;
    }
    airDive(c, dur, cnt, 2.0, false);
}
function state282(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.faceOpponent();
        c.stopMotion();
        rfCost(c);
        effect21(c, f);
        c.f3138++;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
    }
    airDive(c, dur, cnt, 2.0, true);
}
function state283(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 2 && c.d168 === 3) {
        c.stopMotion();
        c.onStateChange();
        o.stopMotion();
        o.onStateChange();
        c.state = 0x11c;
        o.state = 0x6b;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 2 && c.timer === 0 && o.y === 0.0 && (o.state < 0x32 || o.state > 0x95)) {
            c.w16c = 1;
        } else {
            c.w16c = 0;
        }
        if (c.frame === 2) c.meter = s16(c.meter + 0x19);
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state284(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.biasCameraY(-0x32, 3);
    o.hitstop = 3;
    c.timer++;
    if (c.frame > 3) {
        c.vx = 1.0;
        c.vy = c.vy + 0.025;
    }
    if (c.frame > 3 && c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        o.onStateChange();
        c.state = 0xd;
        o.state = 0x48;
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 1) {
            const p = opponentPoint0(o);
            c.x = o.x - p.x * c.facing;
            c.y = p.y + o.y - 20.0;
        }
        if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
    }
}
function state288(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = -0.4;
        c.vy = -0.9;
        c.ay = 0.045;
    }
    c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 8) {
        c.timer = 0;
        c.frame = 8;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.w16c > 0) c.d168 = 0;
        if (c.frame === 8) c.frame -= 4;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.faceOpponent();
            c.state = 3;
        }
    }
}
function state291(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.faceOpponent();
        c.stopMotion();
        c.w16c = 5;
    }
    if (c.frame > 14) {
        c.vy = c.vy + c.ay;
        if (c.y + c.vy > 0.0) {
            c.timer = 0;
            c.frame = 22;
            c.y = 0.0;
            c.stopMotion();
            return;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 14) {
            c.vx = 0.5;
            c.vy = 0.0;
            c.ay = 0.045;
        }
        if (c.frame === 22) c.frame -= 4;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.faceOpponent();
            c.state = 3;
        }
    }
}
function superStart(c, f, cost, pat, sound, w13c) {
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame === 1 && c.timer === 0) {
        c.freeze = 0x78;
        c.meter = s16(c.meter - cost);
        c.superDarken(0xb0, 3);
        f.w04 = pat;
        f.b2c = sound;
        f.x = ftol(c.x);
        f.y = ftol(c.y) - 0x28;
        f.b20 = 2;
        f.d00 = 1;
        f.b21 = 1;
        frameEffect(f);
        c.w13c = w13c;
        c.biasCameraY(0x32, 0x78);
    }
}
function superStep(c, loops) {
    if (c.frame === 6) c.x = c.facing * 0xf + c.x;
    if (c.frame === 7) c.x = c.facing * 0xf + c.x;
    if (c.frame === 9) c.x = c.facing * 0xf + c.x;
    if (c.frame === 10) {
        if (c.f3138 > loops) {
            c.frame = 12;
            return true;
        }
        c.x = c.facing * 0xf + c.x;
    }
    if (c.frame === 12 && c.f3138 < loops) {
        c.frame = 2;
        c.f3138++;
    }
    return false;
}
function state300(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    superStart(c, f, 0x3e8, 0x44, 0x13, 0x7e);
    if (c.frame >= 1) c.wF2 = 0xa;
    if ((c.frame === 2 || c.frame === 7) && c.timer === 0) {
        c.seRequest = 0x15;
        c.w16c = 1;
    }
    if (c.frame === 16 && c.timer === 0) {
        c.seRequest = 0x14;
        c.w16c = 1;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.w16c > 0) c.d168 = 0;
        if (c.frame === 2) c.w13c = 9;
        if (superStep(c, 1)) return;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
        }
    }
}
function state301(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    superStart(c, f, 0x7d0, 0x45, 5, 0x84);
    if (c.frame >= 1) c.wF2 = 0xa;
    if ((c.frame === 2 || c.frame === 7) && c.timer === 0) {
        c.seRequest = 0x15;
        c.w16c = 1;
    }
    if (c.frame === 14 && c.timer === 0) {
        c.seRequest = 0x14;
        c.w16c = 1;
    }
    if (c.frame === 21 && c.timer === 0) {
        c.seRequest = 0x15;
        c.w16c = 1;
    }
    if (c.frame > 20 && c.frame < 28) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - 0.04;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame > 20 && c.frame < 28 && c.y + c.vy > 0.0) {
        c.frame = 28;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.w16c > 0) c.d168 = 0;
        if (c.frame === 2) c.w13c = 0x1e;
        if (superStep(c, 2)) return;
        if (c.frame === 20) {
            c.ay = 0.06;
            c.vy = -3.0;
            c.vx = 2.0;
        }
        if (c.frame === 28) c.frame -= 4;
        if (c.frame >= cnt) {
            c.state = 10;
            c.onStateChange();
        }
    }
}
function state302(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    superStart(c, f, 0xbb8, 0x46, 0x40, 0x84);
    if (c.frame === 1 && c.timer === 0) c.seRequest = 0x25;
    if (c.frame > 1) c.showAltBackground(0xf);
    if ((c.frame === 2 || c.frame === 7) && c.timer === 0) {
        c.seRequest = 0x15;
        c.w16c = 1;
    }
    if (c.frame === 14 && c.timer === 0) {
        c.seRequest = 0x14;
        c.w16c = 1;
    }
    if (c.frame === 18 && c.timer === 0) {
        c.seRequest = 0x15;
        c.w16c = 1;
        c.vx = 3.0;
    }
    if (c.frame > 18 && c.frame < 23) {
        c.vx = c.vx - 0.04;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame > 20 && c.frame < 23 || c.frame > 28) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - 0.04;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame === 24 && c.timer === 0) {
        c.vx = 1.8;
        c.w16c = 0x63;
    }
    if (c.frame === 32 && c.timer === 0) {
        c.seRequest = 0x14;
        c.w16c = 1;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.w16c > 0 || c.frame < 34 && c.frame > 27) c.d168 = 0;
        if (c.frame === 2) c.w13c = 0x3c;
        if (superStep(c, 3)) return;
        if (c.frame === 28 && c.f3138 < 8) {
            c.frame -= 4;
            c.f3138++;
        }
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
        }
    }
}
registerStates({
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state257,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    265: state264,
    266: state266,
    267: state267,
    268: state268,
    269: state269,
    270: state270,
    271: state271,
    272: state272,
    273: state273,
    274: state274,
    275: state275,
    280: state280,
    281: state281,
    282: state282,
    283: state283,
    284: state284,
    285: state285,
    286: state286,
    287: state287,
    288: state288,
    289: state289,
    290: state262,
    291: state291,
    300: state300,
    301: state301,
    302: state302
});
