import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { spawnEffect } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { registerChildren, registerStates } from "./65b7ada33d910b3c78926926.mjs";
import { childFrameCount, childFrameDuration, frameCount, frameDuration, ftol, s16 } from "./e2bb73ea5d34f44e96511e06.mjs";
function superEffect(c, pat, sound, offX, offY) {
    spawnEffect({
        owner: 1,
        pat,
        x: ftol(c.x) + c.facing * offX,
        y: ftol(c.y) - offY,
        blend: 2,
        layer: 1,
        sound
    });
}
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function stepFrame(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    return true;
}
function childStep(c, i, dur) {
    const ch = c.children[i];
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function groundSuperHead(c) {
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame < 3) c.biasCameraY(0x32, 3);
}
function groundSuperTail(c, dur, cnt) {
    if (stepFrame(c, dur) && c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state300(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundSuperHead(c);
    if (c.frame === 1 && c.timer === 0) {
        superFreeze(c, 0x3e8);
        superEffect(c, 0x44, 0x13, 0, 0x28);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.spawnChild({
            type: 1,
            pattern: 0x195,
            x: ftol(c.x) + c.facing * 0xf,
            y: ftol(c.y) - 0x2a,
            facing: c.facing,
            blend: 2,
            layer: 1
        });
    }
    groundSuperTail(c, dur, cnt);
}
function state301(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundSuperHead(c);
    if (c.frame === 1 && c.timer === 0) {
        superFreeze(c, 0x7d0);
        superEffect(c, 0x45, 5, 0, 0x28);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.spawnChild({
            type: 1,
            pattern: 0x1a3,
            x: ftol(c.x) + c.facing * 0xf,
            y: ftol(c.y) - 0x2a,
            facing: c.facing,
            blend: 2,
            layer: 1
        });
    }
    groundSuperTail(c, dur, cnt);
}
function spawn1a4(c, param, offY) {
    c.f314c = param;
    c.spawnChild({
        type: 1,
        pattern: 0x1a4,
        x: ftol(c.x) + c.facing * 0xf,
        y: ftol(c.y) - offY,
        facing: c.facing,
        blend: 2,
        layer: 1
    });
}
function state302(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    groundSuperHead(c);
    if (c.frame === 1 && c.timer === 0) {
        superFreeze(c, 0xbb8);
        superEffect(c, 0x46, 0x40, 0, 0x28);
        c.seRequest = 0x25;
    }
    if (c.frame > 1) c.showAltBackground(0xf);
    if (c.frame === 4 && c.timer === 0) spawn1a4(c, 0x2d, 0x16);
    if (c.frame === 0xd && c.timer === 0) spawn1a4(c, 0x1e, 0x3e);
    if (c.frame === 0x16 && c.timer === 0) spawn1a4(c, 0xf, 0x2a);
    groundSuperTail(c, dur, cnt);
}
function airSuperHead(c) {
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.w16c = 1;
    }
    if (c.frame < 3) c.biasCameraY(0x19, 0xa);
}
function airSuperTail(c, dur, cnt, accelY) {
    c.timer++;
    if (c.frame > 2) {
        c.vy += accelY;
        c.vx += 0.05;
        if (c.vx > -0.5) c.vx = -0.5;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.onStateChange();
        }
    }
}
function state303(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    airSuperHead(c);
    if (c.frame === 1 && c.timer === 0) {
        superFreeze(c, 0x3e8);
        superEffect(c, 0x44, 0x13, 0, 0x28);
    }
    if (c.frame === 3 && c.timer === 0) {
        c.vx = -1.9;
        c.vy = -1.5;
        c.spawnChild({
            type: 1,
            pattern: 0x195,
            x: ftol(c.x) + c.facing * 0xf,
            y: ftol(c.y) - 0x2a,
            facing: c.facing,
            blend: 2,
            layer: 1
        });
    }
    airSuperTail(c, dur, cnt, c.ay);
}
function state304(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    airSuperHead(c);
    if (c.frame === 1 && c.timer === 0) {
        superFreeze(c, 0x7d0);
        superEffect(c, 0x45, 5, 0, 0x28);
    }
    if (c.frame === 3 && c.timer === 0) {
        c.vx = -1.9;
        c.vy = -1.5;
        c.spawnChild({
            type: 1,
            pattern: 0x1a3,
            x: ftol(c.x) + c.facing * 0xf,
            y: ftol(c.y) - 0x2a,
            facing: c.facing,
            blend: 2,
            layer: 1
        });
    }
    airSuperTail(c, dur, cnt, c.ay);
}
function state305(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    airSuperHead(c);
    if (c.frame === 1 && c.timer === 0) {
        superFreeze(c, 0xbb8);
        superEffect(c, 0x46, 5, 0, 0x28);
        c.seRequest = 0x25;
    }
    if (c.frame > 1) c.showAltBackground(0xf);
    if (c.frame === 4 && c.timer === 0) {
        c.vx = -1.2;
        c.vy = -1.0;
        spawn1a4(c, 0x32, 0x16);
    }
    if (c.frame === 0xd && c.timer === 0) {
        c.vx = -1.2;
        c.vy = -1.0;
        spawn1a4(c, 0x23, 0x3e);
    }
    if (c.frame === 0x16 && c.timer === 0) {
        c.vx = -1.9;
        c.vy = -2.3;
        spawn1a4(c, 0x14, 0x2a);
    }
    airSuperTail(c, dur, cnt, 0.025);
}
function spawnPair(c, pattern, dist, sub) {
    const y = c.y;
    if (sub !== 0) {
        c.spawnChild({
            type: 0,
            pattern,
            x: c.facing * dist + c.x - sub,
            y,
            facing: c.facing,
            blend: 2,
            layer: 1
        });
        c.spawnChild({
            type: 0,
            pattern,
            x: c.x - c.facing * dist - sub,
            y,
            facing: -c.facing,
            blend: 2,
            layer: 1
        });
    } else {
        c.spawnChild({
            type: 0,
            pattern,
            x: c.facing * dist + c.x,
            y,
            facing: c.facing,
            blend: 2,
            layer: 1
        });
        c.spawnChild({
            type: 0,
            pattern,
            x: c.x - c.facing * dist,
            y,
            facing: -c.facing,
            blend: 2,
            layer: 1
        });
    }
}
function state306(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.f3138 = 4;
    }
    if (c.frame === 0 && c.timer === 0) {
        superFreeze(c, 0x3e8);
        superEffect(c, 0x44, 0x13, 0, 0x28);
        c.w16c = 1;
    }
    if (c.frame > 6 && c.frame < 0xc) c.biasCameraY(0x32, 3);
    if (c.frame === 8 && c.timer === 0) {
        c.shakeScreen(3, 0x14);
        spawnPair(c, 0x1a5, 0x28, 30.0);
        c.seRequest = 0x12;
    }
    if (stepFrame(c, dur) && c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state307(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.f3138 = 8;
        superFreeze(c, 0x7d0);
        superEffect(c, 0x45, 5, 0, 0x28);
        c.w16c = 0x63;
    }
    if (c.frame > 0 && c.frame < 0xc) c.biasCameraY(0x32, 3);
    if (c.frame === 8 && c.timer === 0) {
        c.shakeScreen(6, 0x3c);
        spawnPair(c, 0x196, 0xa, 0);
        c.seRequest = 0x12;
    }
    if (stepFrame(c, dur)) {
        if (c.frame === 0xa) c.w13c = 0x2d;
        if (c.frame === 0xc && c.f3138 !== 0) {
            c.f3138--;
            c.frame -= 2;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state308(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.f3138 = 8;
        superFreeze(c, 0xbb8);
        superEffect(c, 0x46, 0x40, 0, 0x28);
        c.w16c = 0x63;
        c.seRequest = 0x25;
    }
    if (c.frame > 0) c.showAltBackground(0xf);
    if (c.frame > 0 && c.frame < 0xc) c.biasCameraY(0x32, 3);
    if (c.frame === 8 && c.timer === 0) {
        c.w16c = 1;
        c.shakeScreen(3, 0xa);
        spawnPair(c, 0x1a5, 0xa, 0);
        c.seRequest = 0x12;
    }
    if (c.frame === 0x18 && c.timer === 0) {
        c.w16c = 1;
        c.shakeScreen(5, 0x14);
        spawnPair(c, 0x196, 0xa, 0);
        c.seRequest = 0x12;
    }
    if (c.frame === 0x28 && c.timer === 0) {
        c.w16c = 0x63;
        c.shakeScreen(6, 0x3c);
        spawnPair(c, 0x197, 0xa, 0);
        c.seRequest = 0x12;
    }
    if (stepFrame(c, dur)) {
        if (c.frame === 0x2c && c.f3138 !== 0) {
            c.f3138--;
            c.frame -= 2;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function dashSuperHead(c) {
    if (c.frame > 0) c.vx += c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame === 0 && c.timer === 0) {
        c.startAfterimage(5);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
}
function dashSuperLaunch(c, vx, ax) {
    if (c.frame === 6 && c.timer === 0) {
        c.spawnChild({
            type: 1,
            pattern: 0x1a2,
            x: c.facing * 0x44 + c.x,
            y: c.y - 63.0,
            facing: c.facing,
            blend: 2,
            layer: 1,
            b6c: 0xff
        });
    }
    if (c.frame === 6 && c.timer === 0) {
        c.vx = vx;
        c.ax = ax;
    }
}
function state315(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    dashSuperHead(c);
    if (c.frame === 2 && c.timer === 0 && c.f3138 === 0) {
        superFreeze(c, 0x3e8);
        superEffect(c, 0x44, 0x13, 0, 0x28);
        c.w16c = 5;
        c.f3138++;
    }
    dashSuperLaunch(c, 3.0, -0.03);
    if (stepFrame(c, dur)) {
        if (c.frame === 4 && c.freeze > 0) c.frame -= 2;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state316(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    dashSuperHead(c);
    if (c.frame === 2 && c.timer === 0 && c.f3138 === 0) {
        superFreeze(c, 0x7d0);
        superEffect(c, 0x45, 5, 0, 0x28);
        c.w16c = 0x63;
        c.f3138++;
    }
    dashSuperLaunch(c, 4.0, -0.05);
    if (stepFrame(c, dur)) {
        if (c.frame === 4 && c.freeze > 0) c.frame -= 2;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state317(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    dashSuperHead(c);
    if (c.frame === 1 && c.timer === 0 && c.f3138 === 0) {
        superFreeze(c, 0xbb8);
        superEffect(c, 0x46, 0x40, 0, 0x28);
        c.w16c = 0x63;
        c.f3138++;
        c.seRequest = 0x25;
    }
    if (c.frame > 1) c.showAltBackground(0xf);
    dashSuperLaunch(c, 4.0, -0.04);
    if (stepFrame(c, dur)) {
        if (c.frame === 4 && c.f3140 < 8) {
            c.frame -= 2;
            c.f3140++;
        }
        if (c.frame === 0xe && c.f313c < 1) {
            c.frame -= 2;
            c.f313c++;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state318(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame === 2 && c.timer === 6) {
        superFreeze(c, 0xfa0);
        superEffect(c, 0x46, 0x40, 0x1d, 0x3f);
        c.w16c = 0x63;
        c.seRequest = 0x25;
        superEffect(c, 0x47, 0x40, 0x1d, 0x3f);
    }
    if (c.frame > 2) c.showAltBackground(0xf);
    if (c.frame === 2 && c.timer === 0x5c) {
        c.spawnChild({
            type: 1,
            pattern: 0x19e,
            x: c.x - c.facing * 4,
            y: c.y - 45.0,
            facing: c.facing,
            blend: 2,
            layer: 0,
            b6c: 0xff,
            moveWhileFrozen: 1
        });
    }
    if (c.frame === 5 && c.timer === 0) {
        c.voiceRequest = 5;
        c.vy = -0.1;
    }
    if (c.frame === 7 && c.timer === 0) {
        c.spawnChild({
            type: 0,
            pattern: 0x19f,
            x: c.x,
            y: c.y - 45.0,
            facing: c.facing,
            blend: 2,
            layer: 1,
            b6c: 0xff
        });
    }
    if (c.frame > 3) c.biasCameraY(0x32, 3);
    if (c.frame === 0xf || c.frame === 0x10) {
        const r = c.random(0, 100) & 0xffff;
        if (c.f3138 * 7.3 + 20.0 < r) {
            let pattern = 0x1a0;
            let layer = 1;
            if ((c.random(0, 100) & 0xffff) > 0x32) {
                pattern = 0x1a1;
                layer = 0;
            }
            const x = c.x - c.facing * 0x12c;
            const y = (c.random(0, 0x140) & 0xffff) - 0x140;
            c.spawnChild({
                type: 0,
                pattern,
                x,
                y,
                facing: c.facing,
                blend: 2,
                layer
            });
        }
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame < cnt) return;
    if (c.f3138 < 0xd) {
        c.frame -= 5;
        c.f3138++;
        return;
    }
    c.state = 9;
    c.spawnChild({
        type: 0,
        pattern: 0x19f,
        x: c.x,
        y: c.y - 45.0,
        facing: c.facing,
        blend: 2,
        layer: 1,
        b6c: 0xff
    });
    c.ay = 0.015;
    c.faceOpponent();
    c.onStateChange();
}
registerStates({
    300: state300,
    301: state301,
    302: state302,
    303: state303,
    304: state304,
    305: state305,
    306: state306,
    307: state307,
    308: state308,
    315: state315,
    316: state316,
    317: state317,
    318: state318
});
function child411(c, i) {
    const ch = c.children[i];
    const dur = childFrameDuration(c, i);
    const cnt = childFrameCount(c, i);
    ch.vy += 0.05;
    c.f3148 = 1;
    if (ch.frame === 0 && ch.timer === 0 && c.a3150[i] === 0) {
        ch.vx = 0.6;
        if (c.inputX === c.facing) ch.vx = 1.4;
        ch.vy = -3.0;
        c.a3150[i] = 1;
        ch.hitsLeft = 1;
    }
    if (ch.y > 0.0 || ch.hitState > 1) {
        ch.pattern = 0x1a7;
        ch.vy = -2.0;
    }
    if (c.pressed[3] === 1) {
        ch.pattern = 0x1a6;
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    ch.timer++;
    if (ch.hitState === 1) c.freeChild(i);
    if (childStep(c, i, dur) && ch.frame >= cnt) ch.frame = 0;
}
function child412(c, i) {
    const ch = c.children[i];
    const dur = childFrameDuration(c, i);
    const cnt = childFrameCount(c, i);
    c.f3148 = 1;
    if (ch.hitState > 1) {
        ch.pattern = 0x1a7;
        ch.vy = -2.0;
    }
    ch.timer++;
    if (ch.hitState === 1) c.freeChild(i);
    if (childStep(c, i, dur) && ch.frame >= cnt) {
        if (c.a3150[i] > 5) ch.pattern = 0x1a7;
        ch.frame = 0;
        c.a3150[i]++;
    }
}
function child413(c, i) {
    const ch = c.children[i];
    const dur = childFrameDuration(c, i);
    const cnt = childFrameCount(c, i);
    ch.vy += 0.05;
    c.f3148 = 0;
    ch.timer++;
    if (ch.hitState === 1) c.freeChild(i);
    if (childStep(c, i, dur) && ch.frame >= cnt) ch.frame = 0;
    if (ch.y > 100.0) c.freeChild(i);
}
function child414(c, i) {
    const ch = c.children[i];
    const dur = childFrameDuration(c, i);
    const cnt = childFrameCount(c, i);
    ch.x = c.x - c.facing * 4;
    ch.y = c.y - 45.0;
    ch.timer = ch.timer + 1 & 0xffff;
    if (c.state !== 0x13e) {
        c.freeChild(i);
        return;
    }
    if (ch.frame === 0xc && ch.timer === 0) {
        c.spawnChild({
            type: 0,
            pattern: 0x19f,
            x: ch.x,
            y: ch.y,
            facing: ch.facing,
            d4c: 0,
            blend: 2,
            layer: 1
        });
    }
    if (childStep(c, i, dur) && ch.frame >= cnt) ch.frame -= 2;
}
function child415(c, i) {
    const ch = c.children[i];
    const dur = childFrameDuration(c, i);
    const cnt = childFrameCount(c, i);
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 7;
    }
    ch.timer++;
    if (childStep(c, i, dur) && ch.frame >= cnt) c.freeChild(i);
}
function fallingChild(c, i, baseVx, ayScale) {
    const ch = c.children[i];
    const dur = childFrameDuration(c, i);
    const cnt = childFrameCount(c, i);
    if (c.a3150[i] === 0) {
        ch.hitsLeft = 1;
        c.a3150[i]++;
        ch.vx = (c.random(0, 100) & 0xffff) * 0.01 + baseVx;
        ch.ay = (c.random(0, 100) & 0xffff) * ayScale;
        ch.vy = 0.5;
        ch.frame = c.random(0, 0xf) & 0xffff;
    }
    ch.vy -= ch.ay;
    ch.timer++;
    if (ch.x > 680.0 && ch.facing === 1 || ch.x < -60.0 && ch.facing === -1 || ch.y < -320.0) {
        c.freeChild(i);
        return;
    }
    if (childStep(c, i, dur) && ch.frame >= cnt) ch.frame = 0;
}
function child416(c, i) {
    fallingChild(c, i, 2.5, 0.00015);
}
function child417(c, i) {
    fallingChild(c, i, 1.0, 0.0002);
}
function child418(c, i) {
    const ch = c.children[i];
    const dur = childFrameDuration(c, i);
    const cnt = childFrameCount(c, i);
    ch.x = c.facing * 0x44 + c.x;
    ch.y = c.y - 63.0;
    if (c.state === 0x13d) ch.x = c.facing * 0x5c + c.x;
    if ((c.state === 0x13b || c.state === 0x13c || c.state === 0x13d) && c.hitstop > 0) ch.timer--;
    ch.timer++;
    if (childStep(c, i, dur) && ch.frame >= cnt) c.freeChild(i);
}
function waveChild(c, i, initVx, decel, loops) {
    const ch = c.children[i];
    const dur = childFrameDuration(c, i);
    const cnt = childFrameCount(c, i);
    ch.vy = 0.0;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 0x63;
        ch.vx = initVx();
    }
    ch.vx -= decel;
    if (ch.vx <= 0.3) ch.vx = 0.3;
    ch.timer++;
    if (ch.timer < dur) return;
    ch.timer = 0;
    if (ch.frame === 6 || ch.frame === 0xc || ch.frame === 0x12) ch.hitState = 0;
    ch.frame++;
    if (ch.frame < cnt) return;
    if (c.a3150[i] < loops) {
        ch.frame = 1;
        c.a3150[i]++;
        return;
    }
    c.freeChild(i);
}
function child419(c, i) {
    waveChild(c, i, ()=>3.3, 0.04, 3);
}
function child420(c, i) {
    waveChild(c, i, ()=>c.f314c * 0.1, 0.05, 4);
}
function child421(c, i) {
    const ch = c.children[i];
    const dur = childFrameDuration(c, i);
    const cnt = childFrameCount(c, i);
    if (c.state === 0x132 || c.state === 0x134) ch.x = ch.facing * 0xa + c.x + 0.0;
    ch.timer++;
    if (!childStep(c, i, dur)) return;
    if (ch.frame === 7 && (c.state === 0x132 && c.frame < 0xd || c.state === 0x134 && c.frame < 0xd)) ch.frame -= 2;
    if (ch.frame >= cnt) c.freeChild(i);
}
registerChildren({
    411: child411,
    412: child412,
    413: child413,
    414: child414,
    415: child415,
    416: child416,
    417: child417,
    418: child418,
    419: child419,
    420: child420,
    421: child421
});
