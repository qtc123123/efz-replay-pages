import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./62d688cb05fea0c19aa52424.mjs";
import { updateChildrenMishio } from "./1d012cc8875ecbb32aaeb678.mjs";
import { parseCommandMishio, dispatchMovesMishio, renderOverlayMishio } from "./3a34da8d4a46ff39232906e0.mjs";
import { thinkMishio } from "./aba956262ef2328ae0f52d6f.mjs";
import { tickHookMishio } from "./4f13f3afe3d5f0abb2e04a1f.mjs";
import "./38e230f26e5186846223b990.mjs";
import "./ca3bd08b6cc5f515c2ad2a3f.mjs";
import "./bbe494d31c2c6aa23a82dad1.mjs";
const POINTS_X = [
    -4,
    18,
    21,
    18,
    38
];
const POINTS_Y = [
    -57,
    0,
    -12,
    -15,
    -39
];
export class Mishio extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    f3154 = 0;
    f3158 = 0;
    f315c = 0;
    f3160 = 0;
    f3164 = 0;
    f3168 = 0;
    f316c = 0;
    f3170 = 0;
    a3174 = new Int32Array(64);
    a3274 = new Int32Array(64);
    a3374 = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        7,
        3,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = 0;
        this.f314c = 0;
        this.f3150 = 0;
        this.f3154 = 0;
        this.f3158 = 0;
        this.f315c = 0;
        this.f3160 = 0;
        this.f3164 = 0;
        this.f3168 = 0;
        this.f316c = 0;
        this.f3170 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a3174.fill(0);
        this.a3274.fill(0);
        this.a3374.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3174[i] = 0;
        this.a3274[i] = 0;
        this.a3374[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayMishio(this);
    }
    tickHook() {
        tickHookMishio(this);
    }
    parseCommand() {
        parseCommandMishio(this);
    }
    dispatchMoves() {
        dispatchMovesMishio(this);
    }
    think() {
        thinkMishio(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMishio(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
