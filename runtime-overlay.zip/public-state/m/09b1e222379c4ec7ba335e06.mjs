import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { registerChildren, registerStates, setDefaultStateHandler } from "./c2c7a57dacaa46758b7f3f58.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./7b1ab9c36f2b6b5ca7dcee6a.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function advance(c, dur, cnt) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return c.frame >= cnt;
}
function advanceChild(c, i, dur, cnt) {
    const ch = c.children[i];
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return ch.frame >= cnt;
}
function landFromHit(c) {
    c.y = 0.0;
    if (c.d12c !== 0) c.setState(0x61);
    else c.setState(0x62);
}
function wallPush(c, y, k) {
    if (c.x - 20.0 <= 0.0 || !(c.x + 20.0 < 639.0)) {
        c.pushToOpponent = (1.0 - (y < 0.0 ? 1 : 0) * k) * c.vx;
    } else {
        c.pushToOpponent = 0.0;
    }
}
function rfDrain(c, v) {
    if (c.rfBlue !== 0) c.rfGauge -= v;
}
function stateDefault(c) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (advance(c, dur, cnt)) c.frame = 0;
}
function walk(c, vx) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = vx;
    c.vy = 0.0;
    if (advance(c, dur, cnt)) c.frame = 0;
}
function state3(c) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.frame = 0;
}
function jumpLanding(c) {
    if (c.y + c.vy >= 0.0 && c.frame > 2) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function jump(c, vx) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.faceOpponent();
        c.vx = 0.0;
    }
    if (c.frame === 2 && c.timer === 0) {
        c.ay = 0.048;
        c.vy = -3.2;
        if (vx !== null) c.vx = vx;
    }
    if (c.frame > 1) c.vy += c.ay;
    if (advance(c, dur, cnt)) c.setState(9);
    jumpLanding(c);
}
function quickJump(c, vx) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.ay = 0.048;
        c.vy = -3.2;
        c.vx = vx;
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.setState(9);
    jumpLanding(c);
}
function transition(c, next) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(next);
}
function state9(c) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.seRequest = 9;
        c.setState(13);
    }
}
function state13(c) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.stopMotion();
    c.y = 0.0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(c.inputY === 1 ? 3 : 7);
}
function state40(c) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0 && c.f3138 === 0) {
        c.f3138++;
        c.rfGauge -= 100.0;
        if (c.vy > 0.0) c.vy *= 0.5;
    }
    c.rfGauge -= 1.0;
    if (c.frame === 2 && c.timer === 0) c.seRequest = 0x11;
    c.vy += 0.03;
    c.vx = c.inputX * 0.045 * c.facing + c.vx;
    c.vy = c.inputY * 0.015 + c.vy;
    if (c.vy < -3.0) c.vy = -3.0;
    else if (c.vy > 1.0) c.vy = 1.0;
    if (c.vx < -1.0) c.vx = -1.0;
    else if (c.vx > 1.0) c.vx = 1.0;
    if (c.inputY === 1) {
        c.setState(9);
        return;
    }
    if (advance(c, dur, cnt)) c.frame = 0;
    jumpLanding(c);
}
function state47(c) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.3;
        c.ay = 0.035;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 2) {
        c.timer = 0;
        c.frame = 2;
        c.seRequest = 7;
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2) c.frame = c.frame - 2 & 0xffff;
        if (c.frame >= cnt) c.frame = c.frame - 1 & 0xffff;
    }
}
function hitStand(c, meter, k, guard, standUp) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + meter);
        c.vx = (2.0 - c.opponent.proration / 10000.0) * k;
        rfDrain(c, guard);
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    wallPush(c, c.y, 0.2);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 0);
        else c.setState(3);
    }
}
function hitAir(c, wall, mix, clamp, ay) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (wall && c.frame > 0 && c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = mix ? c.vy * 0.75 + c.knockY : c.knockY;
        if (clamp !== null) {
            if (c.vy < clamp) c.vy = clamp;
            else if (c.vy > -0.5) c.vy = -0.5;
        }
        c.ay = ay;
    }
    if (!(c.vy > 0.0)) {
        c.frame = 1;
        c.timer = 0;
    }
    if (c.vy >= 0.0 && c.frame <= 1) {
        c.frame = 2;
        c.timer = 0;
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = c.frame - 2 & 0xffff;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function state68(c) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    c.timer++;
    if (c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state69(c) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    if (advance(c, dur, cnt)) c.frame = c.frame - 2 & 0xffff;
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state70(c) {
    const f = openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0 && c.f3138 === 0) {
        c.meter = s16(c.meter + 30);
        c.f3138++;
        c.hitstun = s16(c.hitstun + 120);
        c.vx = 0.5;
        c.vy = -2.5;
        c.ay = 0.025;
        c.seRequest = 0x1f;
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function grounded(c, standUp) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    c.vx = 0.0;
    c.vy = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function slide(c, standUp) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + 30);
        rfDrain(c, 30.0);
        c.vx = 2.2;
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.ay = 0.0;
    c.ax = 0.06;
    c.vx -= c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function state81(c) {
    const f = openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0) {
        f.w04 = 0x1f3;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    c.vx += 0.02;
    c.vy += c.ay;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) c.frame = c.frame - 1 & 0xffff;
    if (c.y + c.vy >= 0.0 && c.frame === 1) landFromHit(c);
}
function state82(c) {
    openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0 && c.f3138 === 0) {
        c.seRequest = 0x1e;
        c.vy = -0.45;
        c.vx = -0.1;
        c.f3138++;
        c.meter = s16(c.meter + 30);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    if (c.vy > 0.0 && c.frame === 4) {
        c.frame = 5;
        c.timer = 0;
    }
    if (c.frame > 3) c.vy += c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 4 && c.f3138 < 8) {
            c.frame = 0;
            c.f3138++;
        }
        if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
    }
    if (c.y + c.vy >= 0.0 && c.frame > 4) landFromHit(c);
}
function spawn496(c, f) {
    if (c.f3144 === 0) {
        f.w04 = 0x1f0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 0;
        f.b21 = 0;
        f.d00 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        c.f3144 = 1;
    }
}
function state83(c) {
    const f = openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        spawn496(c, f);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vy = -1.5;
        c.vx = -0.8;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (c.frame === 0 && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.timer = 0;
        c.frame = 1;
        return;
    }
    if (c.frame === 1) c.vx += 0.01;
    if (c.frame === 2 && c.timer === 0) c.vx = -2.0;
    if (c.frame > 1) c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
}
function state85(c) {
    const f = openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        spawn496(c, f);
        rfDrain(c, 30.0);
        c.seRequest = 0x21;
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state86(c) {
    const f = openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        spawn496(c, f);
        if (c.f3138 === 0) {
            rfDrain(c, 30.0);
            c.seRequest = 0x21;
            c.vx = c.knockX;
            c.vy = c.knockY;
            c.meter = s16(c.meter + 30);
            c.f3138++;
        }
    }
    c.vy += 0.06;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state87(c) {
    const f = openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        f.w04 = 0x1ef;
        f.x = 60.0;
        f.y = 40.0;
        f.d24 = 1;
        f.b18 = 1;
        f.b20 = 0;
        f.b21 = 0;
        frameChild(c, f);
    }
    if (advance(c, dur, cnt)) c.setState(0);
}
function waveCommon(c, f, dur, cnt, pattern) {
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.voiceRequest = 8;
        f.w04 = pattern;
        f.d00 = 1;
        f.x = ftol(c.x) + c.facing * 0x29;
        f.y = ftol(c.y) - 0x37;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    c.d168 = 3;
    if (c.frame >= cnt) c.setState(0);
}
function state260(c) {
    const f = openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    waveCommon(c, f, dur, cnt, 0x19f);
}
function state261(c) {
    const f = openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    waveCommon(c, f, dur, cnt, 0x1a2);
}
function state262(c) {
    const f = openSpawnFrame();
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        f.w04 = 0x21;
        f.b2c = 0xb;
        f.x = ftol(c.x);
        f.y = ftol(c.y) - 0x32;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.startAfterimage(3);
        c.vx = 0.0;
        if (c.rfBlue === 0) c.rfGauge -= 500.0;
        else c.rfGauge -= 250.0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ax = 0.0;
    }
    waveCommon(c, f, dur, cnt, 0x1a4);
}
setDefaultStateHandler(stateDefault);
registerStates({
    1: (c)=>walk(c, 0.8),
    2: (c)=>walk(c, -0.8),
    3: state3,
    4: (c)=>jump(c, null),
    5: (c)=>jump(c, 0.9),
    6: (c)=>jump(c, -0.9),
    7: (c)=>transition(c, 0),
    8: (c)=>transition(c, 3),
    9: state9,
    13: state13,
    14: (c)=>quickJump(c, 0.0),
    15: (c)=>quickJump(c, 0.9),
    16: (c)=>quickJump(c, -0.9),
    40: state40,
    47: state47,
    50: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    51: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    52: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    53: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    54: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    55: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    56: (c)=>hitStand(c, 10, -1.1, 10.0, false),
    57: (c)=>hitStand(c, 15, -1.5, 20.0, false),
    58: (c)=>hitStand(c, 20, -1.8, 30.0, false),
    59: (c)=>hitAir(c, false, true, -2.0, 0.032),
    60: (c)=>hitAir(c, false, true, -4.0, 0.032),
    61: (c)=>hitAir(c, false, true, -6.0, 0.032),
    62: (c)=>hitAir(c, false, true, null, 0.032),
    63: (c)=>hitAir(c, false, false, null, 0.032),
    64: (c)=>hitAir(c, true, true, -2.0, 0.032),
    65: (c)=>hitAir(c, true, true, -4.0, 0.032),
    66: (c)=>hitAir(c, true, true, null, 0.032),
    67: (c)=>hitAir(c, true, false, null, 0.032),
    68: state68,
    69: state69,
    70: state70,
    71: (c)=>hitAir(c, false, false, null, 0.072),
    72: (c)=>grounded(c, true),
    73: (c)=>grounded(c, true),
    74: (c)=>grounded(c, false),
    75: (c)=>slide(c, true),
    76: (c)=>slide(c, true),
    77: (c)=>slide(c, false),
    81: state81,
    82: state82,
    83: state83,
    84: state83,
    85: state85,
    86: state86,
    87: state87,
    260: state260,
    261: state261,
    262: state262
});
function childLauncher(c, i, next) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.timer++;
    if (ch.timer < dur) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame === 5) {
        const f = childSpawnFrame;
        f.w04 = next;
        f.d00 = 1;
        f.x = ch.facing * 0x32 + ch.x;
        f.y = ch.y + 15.0;
        f.b18 = ch.facing;
        f.b20 = 2;
        f.b21 = 1;
        frameChild(c, f);
    }
    if (ch.frame >= cnt) c.freeChild(i);
}
function spawn417(c, i, yFixed) {
    const ch = c.children[i];
    if (ch.timer !== 0) return;
    const f = childSpawnFrame;
    f.w04 = 0x1a1;
    const bx = ch.x + 45.0;
    f.x = ftol(bx - (c.random(0, 0x5a) & 0xffff));
    if (yFixed) {
        f.y = -(c.random(0, 0x46) & 0xffff);
    } else {
        const by = ch.y + 30.0;
        f.y = ftol(by - (c.random(0, 0x5a) & 0xffff));
    }
    f.b20 = 2;
    f.b21 = 1;
    f.b18 = ch.facing;
    frameChild(c, f);
}
function childWave(c, i, ownerState, vx, limit) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0 && c.a3164[i] === 0) {
        ch.hitsLeft = 0;
        c.a3164[i]++;
        if (vx !== null) ch.vx = vx;
    }
    if (c.state === ownerState && c.frame === 0) {
        c.freeChild(i);
        return;
    }
    spawn417(c, i, false);
    drainGuard(c, i);
    ch.timer++;
    if (ch.timer < dur) return;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    if (ch.frame < cnt) return;
    ch.hitsLeft = 0;
    if (c.a3264[i] < limit) {
        ch.frame = 0;
        c.a3264[i]++;
    } else {
        c.freeChild(i);
    }
}
function drainGuard(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    if (!(ch.x - o.x < 50.0)) return;
    if (!(ch.x - o.x > -50.0)) return;
    if (!(o.y > -50.0)) return;
    if (c.a3364[i] > 0) {
        c.a3364[i]--;
    } else {
        o.rfGauge -= 1.0;
        c.a3364[i] = 1;
    }
}
function child417(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.timer++;
    if (advanceChild(c, i, dur, cnt)) c.freeChild(i);
}
function child421(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0 && c.a3164[i] === 0) {
        ch.hitsLeft = 0xc;
        c.a3164[i]++;
        ch.vx = 1.8;
    }
    spawn417(c, i, true);
    ch.timer++;
    if (ch.timer >= dur) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= cnt) {
            if (c.a3264[i] < 0x1e) {
                ch.frame = 0;
                c.a3264[i]++;
                ch.hitState = 0;
            } else {
                c.freeChild(i);
            }
        }
    }
    if (ch.x < -100.0 || ch.x > 800.0 || !(ch.y >= -480.0)) c.freeChild(i);
}
function child495(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.vx = -0.02;
    ch.drawWhileFrozen = 30000;
    ch.timer++;
    if (c.state !== 0x57) c.freeChild(i);
    if (advanceChild(c, i, dur, cnt)) ch.frame = 0;
}
function child496(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const s = c.state;
    const inStates = s === 0x53 || s === 0x54 || s === 0x55 || s === 0x56;
    const burst = !inStates || (s === 0x53 || s === 0x54) && c.frame > 1;
    if (burst) {
        const f = childSpawnFrame;
        const pieces = [
            [
                0x1f1,
                23,
                -4
            ],
            [
                0x1f1,
                -4,
                -6
            ],
            [
                0x1f1,
                -14,
                -26
            ],
            [
                0x1f1,
                0,
                0
            ],
            [
                0x1f1,
                30,
                -40
            ],
            [
                0x1f1,
                -25,
                -80
            ],
            [
                0x1f2,
                -35,
                -42
            ],
            [
                0x1f2,
                -18,
                -20
            ],
            [
                0x1f2,
                2,
                -65
            ],
            [
                0x1f2,
                16,
                -80
            ]
        ];
        for (const [pattern, dx, dy] of pieces){
            f.w04 = pattern;
            f.x = ftol(c.x) + c.facing * dx;
            f.y = ftol(c.y) + dy;
            f.b20 = 0;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        c.seRequest = 0x22;
        c.freeChild(i);
        c.f3144 = 0;
        return;
    }
    ch.timer++;
    if (advanceChild(c, i, dur, cnt)) ch.frame = 0;
}
function coin() {
    return rand("src/game/chars/akiko/states_template_a.ts:1055:8", {
        consumer: "src/game/chars/akiko/states_template_a.ts"
    }) > 0x3e80 ? 1 : 0;
}
function debris(c, i, init, gravity) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0 && c.a3164[i] === 0) init();
    ch.vy += gravity;
    if (ch.y > 0.0 && ch.vy > 0.0) ch.vy = -ch.vy;
    if (c.a3264[i] < 10) ch.blend = 1;
    if (c.a3264[i] < 0) {
        c.freeChild(i);
        return;
    }
    ch.timer++;
    c.a3264[i]--;
    if (advanceChild(c, i, dur, cnt)) ch.frame = 0;
}
function child497(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 40;
        c.a3264[i] = r1 + coin() * 20 + 80;
        c.a3164[i]++;
        const t1 = coin() * 1.2;
        const t2 = coin() * 0.7 + t1;
        ch.vx = coin() * 1.7 + t2 + -1.8;
        const u1 = coin() * 0.6;
        const u2 = coin() * 0.9 + u1;
        ch.vy = -1.2 - (coin() * 1.4 + u2);
    }, 0.05);
}
function child498(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 60;
        c.a3264[i] = r1 + coin() * 40 + 120;
        c.a3164[i]++;
        const t1 = coin();
        const t2 = coin() * 0.5 + t1;
        ch.vx = coin() * 1.5 + t2 + -1.5;
        const u1 = coin() * 0.5;
        const u2 = coin() * 0.8 + u1;
        ch.vy = -1.0 - (coin() * 1.2 + u2);
    }, 0.03);
}
function child499(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.x = c.x;
    ch.y = c.y;
    ch.timer++;
    if (advanceChild(c, i, dur, cnt)) c.freeChild(i);
}
registerChildren({
    415: (c, i)=>childLauncher(c, i, 0x1a0),
    416: (c, i)=>childWave(c, i, 0x104, null, 0xf),
    417: child417,
    418: (c, i)=>childLauncher(c, i, 0x1a3),
    419: (c, i)=>childWave(c, i, 0x105, 0.3, 0x1e),
    420: (c, i)=>childLauncher(c, i, 0x1a5),
    421: child421,
    495: child495,
    496: child496,
    497: child497,
    498: child498,
    499: child499
});
