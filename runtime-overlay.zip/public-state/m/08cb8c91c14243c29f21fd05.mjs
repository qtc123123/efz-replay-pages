import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { s8 } from "./7596266716c972d06fe8897a.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
export function thinkKanna(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    c.f314c--;
    c.f3150--;
    if (c.f314c < 0) c.f314c = 0;
    if (c.state > 0x31 && c.state < 0xa1) c.f314c = 0xb4;
    if (c.f3150 < 0) c.f3150 = 0;
    {
        const air = c.y < 0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 0xaa ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 0x95 && c.state < 0x9d ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40 * c.aiLevel > r && c.state > 0xc7) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 0xc8) c.aiMode = 0;
        return;
    }
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 0x32 && c.state <= 0x96 && c.timer === 0) {
        c.aiMode = 8 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 0x32 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 0xf0) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 0x140) < dx ? 1 : 0;
        if (o.state > 0xc7 && o.state < 0xfa && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if (c.state === 0xa8 && c.timer < 6) {
        if (o.state !== 0xc8 && o.state !== 0xcc && o.state < 0xfa && o.y === 0.0 && o.w16c === 0) {
            if (dx < 45.0 && 2 * c.aiLevel > rnd(c, 0, 100)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 60.0 && chance(c, 1)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
        }
        if ((o.state === 0xc9 || o.state === 0xca || o.state === 0xcd) && o.state < 0xfa && o.y === 0.0 && o.w16c === 0 && dx > 60.0 && dx < 80.0 && chance(c, 1)) {
            c.pressed[1] = 1;
            c.inputY = 1;
            c.inputX = 0;
            return;
        }
    }
    if (c.state === 0xa8 || c.state === 0xa9) {
        {
            const r = rnd(c, 0, 8000);
            if (c.aiLevel * c.aiLevel * 4 > r && c.rfGauge > 500.0) {
                c.command = 0xc;
                return;
            }
        }
        if (dx < 20.0) {
            {
                const r = rnd(c, 0, 1800);
                if (c.aiLevel * 4 > r && c.rfGauge > 500.0) {
                    c.command = 0x14;
                    return;
                }
            }
            if (dx < 60.0 && chance(c, 1)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
            if (chance(c, 1) && c.meter === 0xbb8) {
                c.command = 0x5c;
                return;
            }
            if (chance(c, 3) && dx < 120.0 && c.meter >= 0x7d0) {
                c.command = 0x65;
                return;
            }
        }
        if (dx < 150.0 && dx > 100.0) {
            if (chance(c, 3) && c.rfGauge > 500.0) {
                c.command = 0xc;
                return;
            }
            if (dx < 120.0 && chance(c, 1)) {
                c.pressed[0] = 2;
                c.inputY = 0;
                return;
            }
            if (chance(c, 1)) {
                c.pressed[2] = 1;
                c.inputY = 1;
                return;
            }
            if (chance(c, 1) && c.meter === 0xbb8 && o.state < 0xdc) {
                c.command = 0x64;
                return;
            }
        }
        if (dx > 150.0) {
            if (chance(c, 1) && c.rfGauge > 500.0) {
                c.command = 0xc;
                return;
            }
            if (chance(c, 1)) {
                c.command = 0x64;
                return;
            }
        }
    }
    if (c.state === 0xaa && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -40.0 && dx < 80.0 && chance(c, 5)) {
            c.pressed[0] = 1;
            return;
        }
        if (c.y - o.y > -100.0 && c.y - o.y < -50.0 && dx < 80.0 && chance(c, 5)) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y > -50.0 && c.y - o.y < -50.0 && dx < 120.0 && chance(c, 5)) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return;
        }
        if (dy < 50.0 && dx < 100.0 && c.aiLevel + c.aiLevel > rnd(c, 0, 100)) {
            c.command = rnd(c, 0, 2) + 0xa;
            return;
        }
        if (c.aiLevel + c.aiLevel > rnd(c, 0, 1000)) {
            c.command = 0x64;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y === 0.0 && 15 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0) {
            c.command = 0x16;
            return;
        }
        if (c.aiRoll < 0x11 && c.aiRoll > 0xc && c.meter >= 0xbb8) {
            c.command = 0x64;
            return;
        }
        if (c.aiRoll < 0x12 && c.aiRoll > 0x14 && c.meter === 0xbb8) {
            c.command = 0x65;
            return;
        }
        if (c.aiRoll > 0x41) {
            c.aiMode = 2;
            return;
        }
    }
    if ((o.state === 0xa8 || o.state === 0xa9 || o.state === 0xaa) && c.y < 0.0 && 15 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.aiRoll < 2 && c.meter >= 0xbb8) {
            c.command = 0x64;
            return;
        }
        if (c.aiRoll < 4 && c.meter >= 0xbb8) {
            c.command = 0x65;
            return;
        }
        if (c.aiRoll > 0x3a) {
            c.aiMode = 2;
            return;
        }
    }
    if ((c.rfGauge > 500.0 || c.rfBlue > 0) && 8 * c.aiLevel > rnd(c, 0, 100) && o.state > 0x95 && o.state < 0x9d) {
        if (c.state === 0x100 || c.state === 0xe8 && rnd(c, 0, 10) === 0 || c.state === 0xeb && rnd(c, 0, 7) === 0) {
            c.command = 0x34;
            return;
        }
    }
    if (c.y === 0.0 && c.state < 4 && o.state > 0x31 && o.state < 0x96 && c.aiMode === 0) {
        if (o.y < 0.0 && dy < 100.0 && dx < 130.0 && (o.hitstun > 0x18 || o.d128 === 1 || o.state === 0x52 && o.frame < 4)) {
            c.aiMode = 0x1f;
            return;
        }
        if (o.y < 0.0 && dy < 50.0 && dx < 70.0 && (o.hitstun > 0x12 || o.d128 === 1 || o.state === 0x52 && o.frame < 4)) {
            c.aiMode = 0x1e;
            return;
        }
        if (o.state === 0x46 && c.meter >= 0xbb8 && rnd(c, 0, 0) !== 0) {
            if (dx < 150.0) {
                c.command = 0x65;
                return;
            }
            if (dx > 150.0) {
                c.command = 0x64;
                return;
            }
        }
    }
    if (c.aiMode > 0 && c.state > 0x31 && c.state < 0x9e) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 0xc8) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 3 && c.state === 0xd) c.aiMode = 0;
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = s8(rnd(c, 0, 2) - 1);
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = c.facing === 1 ? 1 : 0;
            if (c.state === 0xa5) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 0x32) {
        c.command = c.facing === 1 ? 1 : 0;
        if (c.state === 0xa3) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6 && c.state < 0x32) {
        c.inputX = 0;
        c.inputY = -1;
        if (c.state === 4) c.aiMode = 8;
        return;
    }
    if (c.aiMode === 7 && c.state < 0x32) {
        c.inputX = c.facing;
        c.inputY = -1;
        if (c.state === 5) c.aiMode = 8;
        return;
    }
    if (c.aiMode === 8 && c.state < 0x32) {
        c.inputX = c.facing;
        c.inputY = 1;
        if (c.state === 0x12) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 9 && c.state < 0x32) {
        c.inputX = c.facing;
        c.inputY = -1;
        if (c.state === 5) c.aiMode = 0xa;
        return;
    }
    if (c.aiMode === 0xa && c.state < 0x32) {
        c.pressed[1] = 1;
        if (c.state === 0xd0 || c.y === 0.0) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0xb && c.state < 0x32) {
        c.inputX = 0;
        c.inputY = -1;
        if (c.state === 4) c.aiMode = 0xc;
        return;
    }
    if (c.aiMode === 0xc && c.state < 0x32) {
        c.pressed[0] = 1;
        if (c.state === 0xcf || c.y === 0.0) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0xd && c.state < 0x32) {
        c.pressed[0] = 1;
        if (c.state === 0xd0 || c.y === 0.0) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 0xe) {
        c.inputY = -1;
        c.inputX = c.facing;
        if (c.state === 5) c.aiMode = 0xf;
        return;
    }
    if (c.aiMode === 0xf) {
        if (!(o.hitstun > 0)) c.aiMode = 0;
        if (dy < 80.0 && o.y < c.y) {
            c.pressed[0] = 1;
            if (c.state === 0xcf) {
                c.aiMode = 0x10;
                return;
            }
        }
        if (dy < 100.0) {
            c.pressed[1] = 1;
            if (o.hitstun < 0x18) c.pressed[0] = 1;
            if (c.state === 0xd0 || c.state === 0xcf) {
                c.aiMode = 0x10;
                return;
            }
        }
        return;
    }
    if (c.aiMode === 0x10) {
        if (!(o.hitstun > 0)) c.aiMode = 0;
        if (c.state === 0xcf && c.d168 === 3) {
            c.pressed[1] = 1;
            return;
        }
        if (c.state === 0xd0) c.aiMode = 0x11;
        return;
    }
    if (c.aiMode === 0x11) {
        if (o.hitstun <= 0 || c.y === 0.0) c.aiMode = 0;
        if (rnd(c, 0, 200) === 1 && c.meter === 0xbb8) {
            c.command = 0x65;
            return;
        }
        if (c.state === 0xd1) {
            c.aiMode = 0;
            return;
        }
        if (c.state === 0xfd) {
            c.aiMode = 0;
            return;
        }
        if (c.state === 0xa5) {
            c.aiMode = 0x14;
            return;
        }
        if (c.state === 0xf) {
            c.aiMode = 0x14;
            return;
        }
        if (c.state === 0xd0 && c.d168 === 3 && c.frame > 5) {
            if (dx > 80.0 && c.vx < 0.0 && o.y - c.y > -40.0) {
                c.command = 0xa;
                return;
            }
            if (o.hitstun < 0x2d && c.b15a > 0 && dy < 40.0 && o.y - c.y < 0.0) {
                c.command = 0xa;
                return;
            }
            if (o.hitstun < 0x2d && !(c.vx < 0.0)) {
                c.pressed[2] = 1;
                return;
            }
            if ((dy < 20.0 && o.y > c.y || o.y < c.y) && o.hitstun > 0x54 && c.b15a < 2) {
                c.inputX = c.facing;
                c.inputY = 0;
                return;
            }
            if (dy > 90.0 && o.y < c.y && o.hitstun > 0x2d && c.b15a < 2) {
                c.inputX = c.facing;
                c.inputY = -1;
                return;
            }
        }
        return;
    }
    if (c.aiMode === 0x14) {
        if (o.hitstun <= 0 || c.y === 0.0) c.aiMode = 0;
        if (c.state === 0xd0) {
            c.aiMode = 0x11;
            return;
        }
        if (dx < 130.0) c.pressed[1] = 1;
        return;
    }
    if (c.aiMode === 0x15) {
        if (o.hitstun <= 0 || c.y === 0.0) c.aiMode = 0;
        if (c.state === 0xd0) {
            c.aiMode = 0x16;
            return;
        }
        if (dx < 130.0) c.pressed[1] = 1;
        return;
    }
    if (c.aiMode === 0x16) {
        if (o.hitstun <= 0 || c.y === 0.0) c.aiMode = 0;
        if (c.state === 0xd1) {
            c.aiMode = 0;
            return;
        }
        if (dx < 130.0) c.pressed[2] = 1;
        return;
    }
    if (c.aiMode === 0x1e) {
        if (o.hitstun <= 0 || o.y === 0.0) c.aiMode = 0;
        if (c.state === 0xc8) {
            c.aiMode = 0x1f;
            return;
        }
        if (dx < 130.0) c.pressed[0] = 1;
        return;
    }
    if (c.aiMode === 0x1f) {
        if (o.hitstun <= 0 || o.y === 0.0) c.aiMode = 0;
        if (c.state === 0xc9 || c.state === 0xca) {
            c.aiMode = 0x20;
            return;
        }
        c.pressed[1] = 1;
        return;
    }
    if (c.aiMode === 0x20) {
        if (o.hitstun <= 0 || o.y === 0.0) c.aiMode = 0;
        if (c.state === 0xcb) {
            c.aiMode = 0x21;
            return;
        }
        if (o.hitstun < 0x3c) {
            c.pressed[2] = 1;
            return;
        }
        c.aiMode = 0xe;
        return;
    }
    if (c.aiMode === 0x21) {
        if (o.hitstun <= 0 || o.y === 0.0) c.aiMode = 0;
        if (c.state === 0xfa || c.state === 0xfb || c.state === 0x12f) {
            c.aiMode = 0;
            return;
        }
        if (rnd(c, 0, 100) < 2 && c.meter >= 0xbb8) {
            c.command = 0x65;
            return;
        }
        if (rnd(c, 0, 100) < 4 && (c.rfGauge > 500.0 || c.rfBlue > 0)) {
            c.command = 0xc;
            return;
        }
        if (rnd(c, 0, 100) < 0xa) {
            c.command = 0xa;
            return;
        }
    }
    if (c.aiMode === 0x22) {
        if (c.state > 4) c.aiMode = 0;
        if (dx < 50.0) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return;
        }
        if (dx < 90.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return;
        }
    }
    if (c.aiMode === 0x24) {
        if (c.state < 4) c.aiMode = 0;
        if (c.state === 0xab || c.state === 0xa7) {
            c.aiMode = 0x25;
            return;
        }
        c.command = 0x34;
        return;
    }
    if (c.aiMode === 0x25) {
        if (c.y === 0.0) c.aiMode = 0;
        if (c.state === 0xd0) {
            c.aiMode = 0;
            return;
        }
        c.pressed[1] = 1;
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && 25 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.state === 0xc8) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 130.0 && c.aiRoll > 0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
            if (dx < 100.0 && c.aiRoll > 0x12c && c.aiRoll < 0x258) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
        }
        if (c.state === 0xc9) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3 && o.hitstun > 0x3c) {
                c.aiMode = 0xe;
                return;
            }
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3 && o.hitstun <= 0x3c) {
                c.aiMode = 0x1e;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x258 && c.aiRoll < 0x2ee) {
                c.inputX = c.facing;
                c.inputY = -1;
                c.aiMode = 0xd;
                return;
            }
            if (c.aiRoll > 0x64 && c.aiRoll < 0x15e && dx < 110.0) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.d168 === 2 && c.aiRoll > 0x15e && c.aiRoll < 0x163) {
                c.inputX = c.facing;
                c.inputY = -1;
                if (rnd(c, 0, 100) < 0x32) c.aiMode = 6;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0x1c2 && c.aiRoll < 0x2bc && dx < 150.0) {
                c.pressed[2] = 1;
                return;
            }
        }
        if (c.state === 0xca) {
            if (c.aiRoll > 0 && c.aiRoll < 0xa) {
                c.command = rnd(c, 1, 3) + 0x46;
                return;
            }
            if (o.y < 0.0 && c.aiRoll > 0xfa && c.aiRoll < 0xff && c.meter >= 0xbb8 && c.d168 === 3) {
                c.command = 0x65;
                return;
            }
            if (c.aiRoll > 0x12c && c.aiRoll < 0x258 && dx < 140.0) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
        }
        if (c.state === 0xcb) {
            if (o.y < 0.0 && c.aiRoll < 0x12c && c.d168 === 3) {
                c.command = rnd(c, 0, 3) + 0xa;
                return;
            }
            if (c.aiRoll > 0x12c && c.aiRoll < 0x258) {
                c.command = rnd(c, 0, 5) + 0x46;
                return;
            }
            if (c.aiRoll > 0x15e && c.aiRoll < 0x258 && c.d168 === 2) {
                c.command = 0x1f;
                if (dx < 120.0) c.command = 0x1e;
                return;
            }
            if (c.aiRoll > 0x384) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcc) {
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 70.0 && c.aiRoll > 0 && c.aiRoll < 0xc8) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 130.0 && c.aiRoll > 0xc8 && c.aiRoll < 0x258) {
                c.pressed[1] = 1;
                c.inputY = 1;
                return;
            }
        }
        if (c.state === 0xcd) {
            if (o.y < 0.0 && c.aiRoll > 0 && c.aiRoll < 0x1f4) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll < 0x12c) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x12c && c.aiRoll < 0x1c2 && dx < 120.0) {
                c.pressed[1] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x1c2 && c.aiRoll < 0x28a) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x226 && c.aiRoll < 0x276) {
                c.command = rnd(c, 0, 5) + 0x46;
                return;
            }
        }
        if (c.state === 0xce) {
            if (c.aiRoll > 0 && c.aiRoll < 0x32) {
                c.command = rnd(c, 0, 3) + 0x46;
                return;
            }
            if (c.aiRoll > 0x12c && c.aiRoll < 0x320 && c.d168 === 3 && (c.rfGauge > 500.0 || c.rfBlue === 1)) {
                c.command = 0x16;
                return;
            }
            if (c.aiRoll > 0x384) {
                c.aiMode = 1;
                return;
            }
        }
        if (c.state === 0xcf) {
            if (c.d168 === 3 && o.y < 0.0) {
                c.aiMode = 0x10;
                return;
            }
            if (o.y < 0.0 && c.aiRoll < 0x12c) {
                c.pressed[1] = 1;
                return;
            }
            if (dx < 60.0 && c.aiRoll < 0x190) {
                c.pressed[0] = 1;
                return;
            }
            if (dx < 125.0 && c.aiRoll > 0x18f && c.aiRoll < 0x2bc) {
                c.pressed[2] = 1;
                c.inputY = 0;
                return;
            }
            if (c.aiRoll > 0x2bb) {
                c.aiMode = 1;
                if (rnd(c, 0, 4) === 0) c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd0) {
            if (c.d168 === 3 && o.y < 0.0) {
                c.aiMode = 0x11;
                return;
            }
            if (c.aiRoll > 0x14 && c.aiRoll < 0x3c && c.d168 === 3 && o.y < 0.0) {
                c.command = 0xa;
                return;
            }
            if (c.aiRoll > 0x50 && c.aiRoll < 0x12c) {
                c.pressed[2] = 1;
                return;
            }
            if (c.aiRoll > 0x3b6 && c.d168 !== 3) {
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (o.y === 0.0 && c.aiRoll > 0x15e && c.aiRoll < 0x28a && c.y > -40.0 && c.d168 === 3) {
                c.aiMode = 0x22;
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xd1) {
            if (c.aiRoll < 0xc8 && c.d168 === 3) {
                c.command = rnd(c, 0, 2) + 0x1f;
                return;
            }
            if (c.aiRoll > 0x384 && c.d168 !== 3) {
                c.inputX = c.facing;
                return;
            }
            if (o.y === 0.0 && c.aiRoll < 0x15e && (c.rfGauge > 500.0 || c.rfBlue > 0) && c.d168 === 3 && c.timer < 3 && c.frame === 4) {
                c.aiMode = 0x24;
                return;
            }
            if (o.y === 0.0 && c.aiRoll > 0x96 && c.aiRoll < 0x28a && c.y > -70.0 && c.d168 === 3) {
                c.aiMode = 0x22;
                return;
            }
            if (c.aiRoll > 0x289) {
                c.aiMode = 3;
                return;
            }
        }
        if (c.state === 0xfa && dx < 120.0 && c.rfGauge > 500.0 && c.frame === 5 && c.aiRoll < 0x64) {
            c.command = 0x34;
            return;
        }
        if (c.state > 0x106 && c.state < 0x10b && rnd(c, 0, 100) < 0x28) {
            c.aiMode = 5;
            return;
        }
    }
    {
        const r = rnd(c, 0, 0x100);
        if (c.aiLevel * c.aiLevel * c.aiLevel * c.aiLevel > r) {
            c.aiRoll = rnd(c, 0, 1000);
            if (dx < 40.0 && dy < 90.0 && o.state > 0xc7 && rnd(c, 0, 2500) < 0xa) {
                c.command = 0x14;
                return;
            }
            if (dy < 90.0 && o.state > 0xc7 && rnd(c, 0, 10000) < 0xa && (c.rfGauge > 500.0 || c.rfBlue === 1)) {
                c.command = 0xc;
                return;
            }
            if (c.y === 0.0) {
                if (o.y === 0.0 && o.state !== 0x63) {
                    if (dx < 80.0) {
                        const hit = o.state > 0x31 && o.state < 0x9c ? 1 : 0;
                        if (c.aiRoll < hit * 0xf + 0xf && c.f314c === 0) {
                            c.pressed[0] = 1;
                            c.inputY = 1;
                            return;
                        }
                    }
                    if (dx < 75.0) {
                        const hit = o.state > 0x31 && o.state < 0x9c ? 1 : 0;
                        if (c.aiRoll < hit * 0xf + 0x14 && c.f314c === 0) {
                            c.pressed[0] = 1;
                            c.inputY = 0;
                            return;
                        }
                    }
                    if (dx > 40.0 && dx < 140.0) {
                        const hit = o.state > 0x31 && o.state < 0x9c ? 1 : 0;
                        if (c.aiRoll < hit * 0xf + 0x2d && c.aiRoll > 0x1e && c.f314c === 0) {
                            c.pressed[1] = 1;
                            c.inputY = 1;
                            return;
                        }
                    }
                    if (dx < 140.0 && dx > 60.0 && c.aiRoll < 0x82 && c.aiRoll > 0x50 && c.f314c === 0) {
                        c.pressed[1] = 1;
                        c.inputY = rnd(c, 0, 10) < 5 ? 1 : 0;
                        return;
                    }
                    if (dx < 70.0 && c.aiRoll < 0x87 && c.aiRoll > 0x82 && c.f314c === 0) {
                        c.aiMode = 9;
                        return;
                    }
                    if (dx < 120.0 && c.aiRoll < 0x96 && c.aiRoll > 0x91 && c.f314c === 0) {
                        c.aiMode = 0xb;
                        return;
                    }
                    if (dx > 50.0 && dx < 180.0 && dy < 50.0 && c.aiRoll < 0x12c && c.aiRoll > 0xfa && c.f314c === 0) {
                        c.command = 0xa;
                        return;
                    }
                    if (dy < 90.0 && c.aiRoll < (o.state > 0xc7 ? 1 : 0) * 0xf + 0x131 && c.aiRoll > 0x12c && c.f314c === 0 && c.rfGauge > 500.0) {
                        c.command = 0xc;
                        return;
                    }
                    if (dx > 130.0 && c.aiRoll < 0x145 && c.aiRoll > 0x136 && c.f314c === 0) {
                        c.command = 0x46;
                        return;
                    }
                    if (dx > 130.0 && c.aiRoll < 0x14a && c.aiRoll > 0x145 && c.f314c === 0) {
                        c.command = 0x48;
                        return;
                    }
                    if (dx < 130.0 && c.aiRoll < 0x159 && c.aiRoll > 0x154 && c.f314c === 0 && c.rfGauge > 500.0) {
                        c.command = 0x48;
                        return;
                    }
                    if (dx > 200.0 && dx < 240.0 && c.aiRoll < 0x172 && c.aiRoll > 0x16d && c.f314c === 0) {
                        c.command = 0x1e;
                        return;
                    }
                    if (dx > 180.0 && dx < 320.0 && c.aiRoll < 0x17c && c.aiRoll > 0x172 && c.f314c === 0) {
                        c.command = 0x1f;
                        return;
                    }
                    if (dx > 240.0 && dx < 320.0 && c.aiRoll < 0x190 && c.aiRoll > 0x17c && c.f314c === 0) {
                        c.command = 0x20;
                        return;
                    }
                    if (dx < 120.0 && c.aiRoll < 0x195 && c.aiRoll > 0x190 && c.f314c === 0 && c.meter >= 0xbb8 && o.wins !== 0) {
                        c.command = 0x5c;
                        return;
                    }
                }
                if (o.y < 0.0) {
                    if (dx < 80.0 && c.rfGauge > 500.0 && c.aiRoll < 2) {
                        c.command = 0x16;
                        return;
                    }
                    if (o.vy < 0.0) {
                        if (dx < 80.0 && dy < 120.0 && c.aiRoll < 0xa) {
                            c.inputY = -1;
                            c.inputX = s8(-c.facing);
                            return;
                        }
                        if (dx < 40.0 && dy < 120.0 && c.aiRoll < 0x1e) {
                            c.inputY = 0;
                            c.pressed[1] = 1;
                            return;
                        }
                    }
                    if (o.vy > 0.0) {
                        if (dx < 90.0 && dy < 140.0 && c.aiRoll < (o.state > 0xc7 ? 1 : 0) * 0x2d + 0xf && (c.rfGauge > 500.0 || c.rfBlue > 0)) {
                            c.command = 0x14;
                            return;
                        }
                        if (dx < 100.0 && dy < 170.0 && dy > 80.0 && c.aiRoll < 0x6e && c.aiRoll > 0x3c) {
                            c.pressed[1] = 1;
                            c.inputY = 0;
                            return;
                        }
                        if (dx < 60.0 && dy < 210.0 && dy > 120.0 && c.aiRoll < 0xb4 && c.aiRoll > 0x64) {
                            c.pressed[2] = 1;
                            c.inputY = 1;
                            return;
                        }
                    }
                }
            }
            if (c.y < 0.0 && c.aiMode !== 3) {
                if (dx < 180.0 && dy < 180.0 && o.state > 0xc8 && c.aiRoll < 5 && c.meter >= 0xbb8) {
                    c.command = 0x65;
                    return;
                }
                if (o.y === 0.0) {
                    if (dx < 100.0 && dy < 100.0 && c.aiRoll > 0 && c.aiRoll < 0x258) {
                        c.pressed[1] = 1;
                        return;
                    }
                    if (dx < 110.0 && dy < 180.0 && c.aiRoll > 0x258 && c.aiRoll < 0x28a) {
                        c.pressed[2] = 1;
                        return;
                    }
                }
                if (o.y < 0.0) {
                    if (dx < 80.0 && dy < 100.0 && c.aiRoll < 0xc8 && o.y < c.y) {
                        c.pressed[0] = 1;
                        return;
                    }
                    if (dx > 20.0 && dx < 140.0 && dy > 60.0 && dy < 140.0 && o.y > c.y && c.aiRoll > 0xc8 && c.aiRoll < 0xfa) {
                        c.pressed[1] = 1;
                        return;
                    }
                }
            }
        }
    }
    if (c.state < 0x32 && (o.state > 0x95 && o.state < 0x9c || o.state > 0x31 && o.state < 0x3b) && c.y === 0.0) {
        const r = rnd(c, 0, 5000);
        if (4 * c.aiLevel * c.aiLevel * c.aiLevel > r && c.f314c === 0) {
            c.command = c.facing === 1 ? 1 : 0;
            return;
        }
    }
    if (c.state < 0x32 && o.state < 0x32 && dx > 80.0 && dx < 120.0) {
        const r = rnd(c, 0, 10000);
        if (c.aiLevel * c.aiLevel * c.aiLevel > r && c.x > 150.0 && c.x < 490.0) {
            c.command = c.facing !== 1 ? 1 : 0;
            return;
        }
    }
    if (c.state === 9 || c.state === 0xa || c.state > 0xd && c.state < 0x15) {
        if (dx > 100.0) {
            if (rnd(c, 0, 1100) < 2 && c.f3150 === 0) c.f3150 = 0xb4;
            if (rnd(c, 0, 100) < 2 && c.y > -180.0 && c.f3150 === 0) {
                c.inputY = -1;
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (rnd(c, 0, 100) < 4 && c.f3150 === 0) {
                c.inputX = c.facing;
                return;
            }
            if (rnd(c, 0, 100) < 2 && c.f3150 === 0) {
                c.inputX = c.facing;
                c.inputY = 1;
                return;
            }
            if (rnd(c, 0, 0) !== 0) {
                c.inputX = c.facing;
                c.inputY = 1;
                return;
            }
        }
        if (dx < 100.0) {
            if (rnd(c, 0, 1000) < 2) {
                c.inputY = 1;
                c.inputX = s8(rnd(c, 0, 2) - 1);
                return;
            }
            if (rnd(c, 0, 500) < 2 && c.f3150 === 0) {
                c.inputX = s8(-c.facing);
                return;
            }
            if (rnd(c, 0, 100) < 2 && c.f3150 === 0) {
                c.inputX = c.facing;
                return;
            }
            if (rnd(c, 0, 100) < 4 && c.f3150 === 0) {
                c.inputX = c.facing;
                c.inputY = 1;
                return;
            }
        }
    }
    if (rnd(c, 0, 500) < 0xa && c.y === 0.0) {
        if (rnd(c, 0, 100) < 4) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx > 40.0 && dx < 150.0 && rnd(c, 0, 500) < 2) {
            c.aiMode = 6;
            return;
        }
        if (dx > 150.0 && rnd(c, 0, 500) < 2) {
            c.aiMode = 7;
            return;
        }
        if (dx > 200.0 && rnd(c, 0, 500) < 2) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
        if (dx < 100.0 && rnd(c, 0, 500) < 2) {
            c.inputX = s8(-c.facing);
            c.inputY = -1;
            return;
        }
    }
    if (c.y !== 0.0) return;
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 0xf) c.aiTimer1a0 = 0xf;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 0xf) c.aiTimer1a4 = 0xf;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 1000) < 2) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 0xc8) + 0x3c;
        else c.aiTimer1a0 = rnd(c, 0, 0xc8) + 0x3c;
    }
    if (rnd(c, 0, 100) < 2) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 0x190) + 0x3c;
        else c.aiTimer1a4 = rnd(c, 0, 0x190) + 0x3c;
    }
}
