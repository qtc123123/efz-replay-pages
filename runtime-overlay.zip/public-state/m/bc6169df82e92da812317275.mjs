import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { HISTORY_LENGTH, NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { registerChildren, registerChildren2 } from "./00697db762b413ef9f6a1cba.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect } from "./0a57f8c3d343150e3ded7bb7.mjs";
import { ftol } from "./7596266716c972d06fe8897a.mjs";
function hist(c, i) {
    return c.history[i - (i >= HISTORY_LENGTH ? 1 : 0) * HISTORY_LENGTH];
}
function buttonCommand(base, v) {
    return base + ((v & 0xe0) > 0 ? 1 : 0) + ((v & 0xc0) > 0 ? 1 : 0) + ((v & 0x80) > 0 ? 1 : 0);
}
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function cancelable(c) {
    return ((c.currentHit()?.defenseFlags ?? 0) & 8) > 0;
}
function priorityOk(c, target) {
    return (c.patterns[c.state]?.hdrB ?? 0) <= (c.patterns[target]?.hdrA ?? 0);
}
function priorityOrRekka(c, target) {
    if (priorityOk(c, target)) return true;
    return c.state > 252 && c.state < 256 && c.d168 === 3;
}
function cancelOk(c) {
    if (c.state >= 200 && c.d168 >= 2 && c.d168 !== 6) return true;
    return c.state < 200;
}
function rfOk(c) {
    return c.rfGauge >= 500.0 || c.rfBlue > 0;
}
function enter(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function normalOk(c, target) {
    return priorityOk(c, target) && cancelable(c) && cancelOk(c);
}
function cmdIn(c, lo, hi) {
    return c.command >= lo && c.command <= hi;
}
export function parseCommandNanase(c) {
    c.command = NO_COMMAND;
    const idx = c.historyIndex;
    const end = idx + HISTORY_LENGTH;
    const left = c.facing === -1 ? 1 : 0;
    const BACK = 2 - left;
    const FWD = 1 + left;
    const DOWN_BACK = 6 - left;
    const DOWN_FWD = 5 + left;
    let step;
    let v;
    step = 0;
    for(let i = idx + 0x2d; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 7) {
            c.command = buttonCommand(0x96, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x96, v);
                return;
            }
            step = 8;
        }
        if ((v & 0xf) === DOWN_FWD && step === 6) step = 7;
        if ((v & 0xf) === DOWN_BACK && step === 5) step = 6;
        if ((v & 0xf) === BACK && step === 4) step = 5;
        if ((v & 0xf) === FWD && step === 3) step = 4;
        if ((v & 0xf) === DOWN_FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x6e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x6e, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_BACK && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000 && c.f344c === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x64, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x64, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_FWD && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000 && c.f344c === 1) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x46, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x46, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x14, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x14, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x28, v);
            return;
        }
        if ((v & 0xf) === 4 && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x28, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x1e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x1e, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0xaf; i < end; i++){
        v = hist(c, i);
        if (v & 8 && step === 1) {
            c.command = 6;
            return;
        }
        if (!(v & 8) && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 4) {
            c.command = 53;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0 && c.state === 96) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 4) {
            c.command = 52;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 4) {
            c.command = 51;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 4) {
            c.command = 50;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 1 && step === 3) {
            c.command = 1;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 1 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 2 && step === 3) {
            c.command = 0;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 2 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
}
export function dispatchMovesNanase(c) {
    if (c.state < 200) c.bufferedA = 0;
    if (c.bufferTimer > 0) {
        c.bufferTimer = c.bufferTimer - 1 & 0xff;
    } else {
        c.bufferedB = 0;
    }
    if (c.bufferedB === 0) c.bufferTimer = 0;
    if (c.command === 52) {
        if ((c.rfGauge >= 500.0 || c.rfBlue > 0) && c.d168 > 1 && c.d168 !== 6 && cancelable(c) && priorityOk(c, 167)) {
            enter(c, 167);
            if (c.y < 0.0) c.state = 171;
            return;
        }
    }
    if (c.d15c < 2) {
        if (dispatchSpecials(c)) return;
    }
    if (c.d15c < 1 && (c.command === 0 || c.command === 1)) {
        if (dispatchDash(c)) return;
    }
    if (c.d15c < 3 && c.command === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && priorityOk(c, 14) && cancelOk(c)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return;
    }
    if (c.pressed[0] === 1 || c.bufferedA & 0x10 || c.bufferedB & 0x10) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 230);
            if (c.inputY === 1) c.state = 233;
            return;
        }
        if (c.y < 0.0) {
            if (normalOk(c, 207)) enter(c, 207);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 204)) {
            enter(c, 204);
            return;
        }
        if ((c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) && normalOk(c, 200)) {
            enter(c, 200);
            return;
        }
    }
    if (c.pressed[1] === 1 || c.bufferedA & 0x20 || c.bufferedB & 0x20) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 231);
            if (c.inputY === 1) c.state = 234;
            return;
        }
        if (c.y < 0.0) {
            if (normalOk(c, 208)) enter(c, 208);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 205)) {
            enter(c, 205);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (priorityOk(c, 201) && cancelable(c) && c.x - c.opponent.x > -70.0 && c.x - c.opponent.x < 70.0 && cancelOk(c)) {
                enter(c, 201);
                return;
            }
            if (normalOk(c, 202)) {
                enter(c, 202);
                return;
            }
        }
    }
    if (c.pressed[2] === 1 || c.bufferedA & 0x40 || c.bufferedB & 0x40) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 232);
            if (c.inputY === 1) c.state = 235;
            return;
        }
        if (c.y < 0.0) {
            if (c.inputX === c.facing && c.inputY === 0 && c.x - c.opponent.x > -100.0 && c.x - c.opponent.x < 100.0 && c.opponent.y < 0.0 && priorityOk(c, 248) && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 248);
                return;
            }
            if (normalOk(c, 209)) enter(c, 209);
            return;
        }
        if ((c.inputY === 1 || c.bufferedA & 4 || c.bufferedB & 4) && normalOk(c, 206)) {
            enter(c, 206);
            return;
        }
        if (c.inputY === 0 || !(c.bufferedA & 4) || !(c.bufferedB & 4)) {
            if (c.inputX !== 0 && c.opponent.y === 0.0 && c.x - c.opponent.x > -30.0 && c.x - c.opponent.x < 30.0 && priorityOk(c, 220) && (c.opponent.state < 50 || c.opponent.state > 156) && cancelable(c) && cancelOk(c)) {
                enter(c, 220);
                return;
            }
            if (normalOk(c, 203)) {
                enter(c, 203);
                return;
            }
        }
    }
}
function dispatchSpecials(c) {
    if (c.command === 153 && c.life < 3333 && c.meter >= 3000 && cancelable(c) && c.y === 0.0 && c.f344c === 0 && cancelOk(c) && priorityOk(c, 307)) {
        enter(c, 307);
        return true;
    }
    if (c.command === 152 && c.meter >= 3000 && cancelable(c) && c.y === 0.0 && c.f344c === 0 && cancelOk(c) && priorityOrRekka(c, 310)) {
        enter(c, 310);
        return true;
    }
    if (cmdIn(c, 151, 152) && c.meter >= 2000 && cancelable(c) && c.y === 0.0 && c.f344c === 0 && cancelOk(c) && priorityOrRekka(c, 309)) {
        enter(c, 309);
        return true;
    }
    if (cmdIn(c, 150, 152) && c.meter >= 1000 && cancelable(c) && c.y === 0.0 && c.f344c === 0 && cancelOk(c) && priorityOrRekka(c, 308)) {
        enter(c, 308);
        return true;
    }
    if (c.command === 102 && c.meter >= 3000 && c.y === 0.0 && cancelable(c) && c.f344c === 1 && cancelOk(c) && priorityOk(c, 305)) {
        enter(c, 305);
        return true;
    }
    if (cmdIn(c, 101, 102) && c.meter >= 2000 && c.y === 0.0 && cancelable(c) && c.f344c === 1 && cancelOk(c) && priorityOk(c, 304)) {
        enter(c, 304);
        return true;
    }
    if (cmdIn(c, 100, 102) && c.meter >= 1000 && c.y === 0.0 && cancelable(c) && c.f344c === 1 && cancelOk(c) && priorityOk(c, 303)) {
        enter(c, 303);
        return true;
    }
    if (c.command === 112 && c.meter >= 3000 && c.y === 0.0 && cancelable(c) && c.f344c === 0 && priorityOk(c, 302) && cancelOk(c)) {
        enter(c, 302);
        return true;
    }
    if (cmdIn(c, 111, 112) && c.meter >= 2000 && c.y === 0.0 && cancelable(c) && c.f344c === 0 && priorityOk(c, 301) && cancelOk(c)) {
        enter(c, 301);
        return true;
    }
    if (cmdIn(c, 110, 112) && c.meter >= 1000 && c.y === 0.0 && cancelable(c) && c.f344c === 0 && priorityOk(c, 300) && cancelOk(c)) {
        enter(c, 300);
        return true;
    }
    if (c.command === 22 && rfOk(c) && cancelable(c) && c.f344c === 0 && priorityOk(c, 258) && cancelOk(c)) {
        enter(c, 258);
        if (c.y < 0.0) {
            c.frame = 9;
            c.f3140 = 1;
            c.d168 = 3;
        }
        return true;
    }
    if (cmdIn(c, 21, 22) && cancelable(c) && c.f344c === 0 && priorityOk(c, 257) && cancelOk(c)) {
        enter(c, 257);
        if (c.y < 0.0) {
            c.frame = 9;
            c.d168 = 3;
        }
        return true;
    }
    if (c.command === 20 && cancelable(c) && c.f344c === 0 && priorityOk(c, 256) && cancelOk(c)) {
        enter(c, 256);
        if (c.y < 0.0) {
            c.frame = 9;
            c.d168 = 3;
        }
        return true;
    }
    if (c.command === 32 && rfOk(c) && cancelable(c) && c.y === 0.0 && c.f344c === 0 && priorityOk(c, 261) && cancelOk(c)) {
        enter(c, 261);
        return true;
    }
    if (cmdIn(c, 31, 32) && cancelable(c) && c.y === 0.0 && c.f344c === 0 && priorityOk(c, 260) && cancelOk(c)) {
        enter(c, 260);
        return true;
    }
    if (c.command === 30 && cancelable(c) && c.y === 0.0 && c.f344c === 0 && priorityOk(c, 259) && cancelOk(c)) {
        enter(c, 259);
        return true;
    }
    if (c.command === 72 && cancelable(c) && c.y === 0.0 && priorityOk(c, 250) && cancelOk(c)) {
        enter(c, 250);
        if (c.f344c === 0) c.state = 264;
        return true;
    }
    if (c.command === 71 && cancelable(c) && c.y === 0.0 && priorityOk(c, 250) && cancelOk(c)) {
        enter(c, 250);
        if (c.f344c === 0) c.state = 263;
        return true;
    }
    if (c.command === 70 && cancelable(c) && c.y === 0.0 && priorityOk(c, 250) && cancelOk(c)) {
        enter(c, 250);
        return true;
    }
    if (c.command === 12 && rfOk(c) && cancelable(c) && c.y === 0.0 && c.f344c === 0 && priorityOk(c, 255) && cancelOk(c)) {
        enter(c, 255);
        return true;
    }
    if (cmdIn(c, 11, 12) && cancelable(c) && c.y === 0.0 && c.f344c === 0 && priorityOk(c, 254) && cancelOk(c)) {
        enter(c, 254);
        return true;
    }
    if (c.command === 10 && cancelable(c) && c.y === 0.0 && c.f344c === 0 && priorityOk(c, 253) && cancelOk(c)) {
        enter(c, 253);
        return true;
    }
    return false;
}
function dispatchDash(c) {
    const dir = 1 - (c.command << 1);
    if (c.y < 0.0 && c.b159 < 1) {
        const dx = c.opponent.x - c.x;
        if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 165) && c.state !== 170 && c.y < -40.0 && cancelable(c) && cancelOk(c)) {
            airDash(c, 165);
            return true;
        }
        if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && priorityOk(c, 166) && c.state !== 170 && cancelable(c) && cancelOk(c)) {
            airDash(c, 166);
            return true;
        }
    }
    if (c.y === 0.0 && cancelable(c)) {
        const dx = c.opponent.x - c.x;
        if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 163) && cancelOk(c)) {
            if (c.state !== 163) c.onStateChange();
            c.state = 163;
            c.faceOpponent();
            c.b158 = c.b158 + 1 & 0xff;
            c.bufferedA = 0;
            return true;
        }
        if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && priorityOk(c, 164) && cancelOk(c)) {
            if (c.state !== 164) c.onStateChange();
            c.state = 164;
            c.faceOpponent();
            c.bufferedA = 0;
            return true;
        }
    }
    return false;
}
function airDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    c.b159 = c.b159 + 1 & 0xff;
    c.b15a = c.b15a + 1 & 0xff;
    c.bufferedA = 0;
}
function tickTimer(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
function spawnLanding(c, i, pattern) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    f.w04 = pattern;
    f.x = ftol(ch.x);
    f.y = 0.0;
    f.b18 = c.facing;
    c.voiceRequest = 2;
    f.b21 = 1;
    f.b20 = 2;
    frameChild(c, f);
}
function clampShinai(c, i) {
    const ch = c.children[i];
    if (ch.x > 620.0) {
        ch.x = 620.0;
        ch.vx = 0.0;
    }
    if (ch.x < 20.0) {
        ch.x = 20.0;
        ch.vx = 0.0;
    }
}
function flyingShinaiHead(c, i) {
    const ch = c.children[i];
    if (c.a314c[i] === 0) {
        ch.hitsLeft = 99;
        c.a314c[i]++;
        ch.hitState = 0;
    }
    if (c.a324c[i] >= 15) {
        c.a324c[i] = 0;
        ch.hitState = 0;
    }
    c.a324c[i]++;
    ch.vx = 3.0;
    ch.vy = 1.8;
    clampShinai(c, i);
}
function bounceTo403(c, i) {
    const ch = c.children[i];
    ch.pattern = 403;
    ch.frame = 0;
    ch.timer = 0;
    ch.vx = 0.8;
    ch.vy = -3.1;
    ch.ay = 0.02;
}
function maybeSpawn427(c, i) {
    const ch = c.children[i];
    if (ch.frame >= 12) return;
    if ((c.random(0, 100) & 0xffff) >= 10) return;
    const f = childSpawnFrame;
    f.w04 = 427;
    const bx = ch.x - 50.0;
    f.x = ftol((c.random(0, 100) & 0xffff) + bx);
    f.y = ftol(ch.y - (c.random(0, 100) & 0xffff));
    f.b20 = 2;
    f.b18 = c.facing;
    f.b21 = 1;
    frameChild(c, f);
}
function child400(c, i) {
    const ch = c.children[i];
    if (c.a314c[i] === 0) {
        ch.hitsLeft = 1;
        c.a314c[i]++;
    }
    ch.vx = 3.0;
    ch.vy = 1.8;
    if (ch.y > 0.0) {
        c.freeChild(i);
        spawnLanding(c, i, 402);
        return;
    }
    if (!tickTimer(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame -= 2;
}
function child401(c, i) {
    const ch = c.children[i];
    if (c.a314c[i] === 0) {
        ch.hitsLeft = 1;
        c.a314c[i]++;
    }
    ch.vx = 3.0;
    ch.vy = 1.8;
    if (ch.y > 0.0) c.freeChild(i);
    if (!tickTimer(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = 0;
}
function child402(c, i) {
    const ch = c.children[i];
    if (!tickTimer(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    400: child400,
    401: child401,
    402: child402
});
function child400f1(c, i) {
    const ch = c.children[i];
    flyingShinaiHead(c, i);
    if (ch.y > 0.0) {
        bounceTo403(c, i);
        spawnLanding(c, i, 402);
        return;
    }
    if (!tickTimer(c, i)) return;
    if (ch.frame >= childCount) ch.frame -= 2;
}
function child401f1(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    f.w04 = 0x22;
    const ix = ftol(ch.x) + 0x28;
    f.x = ix - (c.random(0, 0x50) & 0xffff);
    const iy = ftol(ch.y) + 0x14;
    f.y = iy - (c.random(0, 0x28) & 0xffff);
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
    if (c.a314c[i] === 0) {
        ch.hitsLeft = 99;
        c.a314c[i]++;
        ch.hitState = 0;
    }
    ch.vx = 3.0;
    ch.vy = 1.8;
    if (ch.y > 0.0) c.freeChild(i);
    clampShinai(c, i);
    if (!tickTimer(c, i)) return;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        ch.hitState = 0;
    }
}
function child402f1(c, i) {
    const ch = c.children[i];
    if (ch.frame === 1) ch.hitsLeft = 1;
    maybeSpawn427(c, i);
    if (!tickTimer(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
function child403(c, i) {
    const ch = c.children[i];
    ch.vy = ch.vy + ch.ay;
    if (ch.y + ch.vy > 0.0) {
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.y = 0.0;
        ch.ay = 0.0;
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 404;
        return;
    }
    if (ch.x > 620.0) {
        ch.x = 620.0;
        ch.vx = -ch.vx;
    }
    if (ch.x < 20.0) {
        ch.x = 20.0;
        ch.vx = -ch.vx;
    }
    if (!tickTimer(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = 0;
}
function child404(c, i) {
    const ch = c.children[i];
    const dx = ch.x - c.x;
    if (dx < 30.0 && dx > -30.0 && c.pressed[3] === 1 && c.state < 3) {
        c.freeChild(i);
        c.state = 0x12b;
        c.onStateChange();
        c.setForm(0);
        c.f344c = 0;
        return;
    }
    if (!tickTimer(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = 0;
}
function child413(c, i) {
    const ch = c.children[i];
    flyingShinaiHead(c, i);
    if (ch.y > 0.0) {
        bounceTo403(c, i);
        spawnLanding(c, i, 414);
        return;
    }
    if (!tickTimer(c, i)) return;
    if (ch.frame >= childCount) ch.frame -= 2;
}
function child414(c, i) {
    const ch = c.children[i];
    ch.hitsLeft = 1;
    if (ch.frame === 4 && ch.timer === 0 && ch.y > -10.0) {
        const f = childSpawnFrame;
        f.w04 = 0x19e;
        const bx = ch.x + 60.0;
        f.x = ftol(bx - (c.random(0, 0x78) & 0xffff));
        f.y = ftol(ch.y - 4.0);
        f.b18 = c.facing;
        c.voiceRequest = 2;
        f.b21 = 1;
        f.b20 = 2;
        frameChild(c, f);
    }
    maybeSpawn427(c, i);
    if (!tickTimer(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren2({
    400: child400f1,
    401: child401f1,
    402: child402f1,
    403: child403,
    404: child404,
    413: child413,
    414: child414
});
