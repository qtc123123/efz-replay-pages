import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./f72d22da4bca50f9c6c4bb45.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./3a3de9c9ca972e4115fbd40f.mjs";
import { frameCount, frameDuration, ftol, s8, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function fxAt(c, d, pat, dx, dy, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x) + dx;
    d.y = ftol(c.y) + dy;
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function fxAtSelf(c, d, pat, blend, layer) {
    fxAt(c, d, pat, 0, 0, blend, layer);
}
function spawnAt(c, pat, dx, dy) {
    const d = openSpawnFrame();
    d.w04 = pat;
    d.x = ftol(c.x) + dx;
    d.y = ftol(c.y) + dy;
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function jumpCancel(c, checkD15c, minD168, exact3 = false) {
    if (c.inputY !== -1 || c.frame <= 0) return false;
    if (checkD15c && c.d15c >= 3) return false;
    if (exact3 ? c.d168 !== 3 : c.d168 < minD168) return false;
    jumpTo456(c);
    return true;
}
function airJumpCancel(c) {
    if (c.inputY !== -1 || c.frame <= 0) return false;
    if (c.d168 < 2 || c.b15a !== 0 || c.d15c >= 3) return false;
    c.b15a = c.b15a + 1 & 0xff;
    c.state = 14;
    if (c.inputX === c.facing) c.state = 15;
    if (c.inputX === -c.facing) c.state = 16;
    c.d168 = 0;
    c.onStateChange();
    return true;
}
function attackStart(c, meter, se, hits) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = hits;
}
function stopIfNotDashing(c) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
}
function dashInertia(c, decel) {
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx = c.vx - decel;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGroundNormal(c, crouchable) {
    c.state = 0;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = 5.0 * c.rfGauge + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(176, 3);
}
function toAirOr179(c) {
    c.setState(9);
    if (c.f3458 > 0) {
        c.state = 179;
        c.frame = 7;
    }
}
function airDashEnd(c, vx, check3458) {
    c.setState(9);
    c.vx = vx;
    c.ay = 0.03;
    if (check3458 && c.f3458 > 0) {
        c.state = 179;
        c.frame = 7;
    }
    if (c.faceOpponent()) c.vx = -c.vx;
}
function airNormalDrift(c) {
    if (c.f3458 === 0) c.vy = c.vy + c.ay;
    if (c.f3458 > 0) {
        if (c.vx > 0.1) c.vx = c.vx - 0.025;
        if (c.vx < -0.1) c.vx = c.vx + 0.025;
        if (c.vx < 0.1 && c.vx > -0.1) c.vx = 0.0;
        if (c.vy > 0.1) c.vy = c.vy - 0.025;
        if (c.vy < -0.1) c.vy = c.vy + 0.025;
        if (c.vy < 0.1 && c.vy > -0.1) c.vy = 0.0;
    }
}
function airNormalLand(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.state = 13;
        c.f3458 = 0;
        c.onStateChange();
        return true;
    }
    return false;
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.stopMotion();
    if (c.frame > 9) c.f313c++;
    if (atFrame(c, 2)) c.vx = 1.5;
    if (atFrame(c, 5)) c.blend = 1;
    if (atFrame(c, 6)) c.blend = 3;
    c.b158 = 1;
    if (advance(c, dur) && c.frame >= cnt) {
        c.frame = w16(c.frame - 8);
        return;
    }
    if (c.inputX === c.facing && c.f313c >= 42) {
        c.state = 178;
        c.blend = 1;
        c.onStateChange();
    }
    if (c.inputX !== c.facing && c.f313c >= 24) {
        c.state = 178;
        c.blend = 1;
        c.onStateChange();
    }
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.stopMotion();
    c.b158 = 0;
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -2.5;
        c.vy = -1.3;
    }
    c.vy = c.vy + 0.045;
    if (c.vy + c.y > 0.0 && c.frame < 12) {
        c.stopMotion();
        c.timer = 0;
        c.frame = 12;
        c.y = 0.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 4) c.blend = 1;
        if (c.frame === 5) c.blend = 3;
        if (c.frame === 7) c.blend = 1;
        if (c.frame === 8) c.blend = 0;
        if (c.frame === 12) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 7;
        }
    }
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = 2.0;
        c.startAfterimage(3);
        c.vy = 0.0;
        c.ay = 0.0;
        c.seRequest = 17;
    }
    if (c.f3458 > 0) c.f3458--;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 120) airDashEnd(c, 1.3, false);
    if (c.inputX !== c.facing && c.f3138 >= 40) airDashEnd(c, 1.3, true);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -2.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
        c.seRequest = 17;
    }
    if (c.f3458 > 0) c.f3458--;
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9, false);
    if (c.inputX !== -c.facing && c.f3138 >= 40) airDashEnd(c, -0.9, true);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.blend = 0;
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAtSelf(c, d, 8, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.f3458 = 0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) toAirOr179(c);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAtSelf(c, d, 1, 2, 1);
    }
    if (atFrame(c, 2)) fxAtSelf(c, d, 4, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
            if (c.f3458 > 0) {
                c.state = 179;
                c.frame = 7;
            }
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 1) c.blend = 0;
        if (c.frame >= cnt) c.setState(0);
    }
}
function hoverCommon(c) {
    c.b159 = 0;
    if (c.opponent.life <= 0) c.f3458 = 0;
}
function hoverEnd(c) {
    if (c.f3458 >= 0) return false;
    c.ay = 0.035;
    c.onStateChange();
    c.state = 9;
    return true;
}
function s179(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    hoverCommon(c);
    if (atStart(c)) {
        c.b15a = 1;
        c.f3458 = 1000;
        c.vy = -2.5;
        c.vx = 0.0;
    }
    if (c.frame < 7) {
        c.vy = c.vy + 0.035;
        if (c.vy > 0.0) c.vy = 0.0;
    }
    c.faceOpponent();
    if (c.frame > 6) {
        c.f3458--;
        if (hoverEnd(c)) return;
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.inputY === 1) c.vy = 1.0;
        if (c.inputY === -1) c.vy = -1.0;
        if (c.inputX === c.facing) {
            c.onStateChange();
            c.state = 180;
            return;
        }
        if (c.inputX === -c.facing) {
            c.onStateChange();
            c.state = 181;
            return;
        }
        if (c.pressed[3] === 1) c.f3458 = 0;
    }
    c.blend = 0;
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 4);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    hoverCommon(c);
    if (atStart(c)) c.vx = 1.5;
    c.blend = 0;
    c.f3458--;
    if (hoverEnd(c)) return;
    if (c.inputY === 1) c.vy = 1.0;
    if (c.inputY === 0) c.vy = 0.0;
    if (c.inputY === -1) c.vy = -1.0;
    if (c.inputX === 0) {
        c.onStateChange();
        c.frame = 7;
        c.state = 179;
        return;
    }
    if (c.inputX === -c.facing) {
        c.onStateChange();
        c.state = 181;
        return;
    }
    if (c.pressed[3] === 1) c.f3458 = 0;
    if (hoverEnd(c)) return;
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 2);
}
function s181(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    hoverCommon(c);
    if (atStart(c)) c.vx = -1.5;
    c.blend = 0;
    c.f3458--;
    if (hoverEnd(c)) return;
    if (c.inputY === 1) c.vy = 1.0;
    if (c.inputY === -1) c.vy = -1.0;
    if (c.inputY === 0) c.vy = 0.0;
    if (c.inputX === 0) {
        c.onStateChange();
        c.frame = 7;
        c.state = 179;
        return;
    }
    if (c.inputX === c.facing) {
        c.onStateChange();
        c.state = 180;
        return;
    }
    if (c.pressed[3] === 1) c.f3458 = 0;
    if (hoverEnd(c)) return;
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 2);
}
function s200(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    stopIfNotDashing(c);
    dashInertia(c, 0.06);
    if (jumpCancel(c, true, 2)) return;
    if (atFrame(c, 2)) attackStart(c, 5, 21, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) spawnAt(c, 441, -c.facing * 0x28, -33);
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s201(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    stopIfNotDashing(c);
    dashInertia(c, 0.03);
    if (jumpCancel(c, true, 2)) return;
    if (atFrame(c, 1)) spawnAt(c, 400, -c.facing * 0x15, -31);
    if (atFrame(c, 2)) attackStart(c, 15, 20, 1);
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s202(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    stopIfNotDashing(c);
    dashInertia(c, 0.06);
    if (atFrame(c, 2)) {
        attackStart(c, 15, 20, 1);
        spawnAt(c, 401, -c.facing * 0x24, -53);
    }
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 5)) {
        const d = openSpawnFrame();
        fxAt(c, d, 3, c.facing * 0x37, 0, 2, 1);
        c.voiceRequest = 10;
    }
    if (atFrame(c, 4)) {
        addMeter(c, 35);
        c.w16c = 1;
    }
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s204(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    stopIfNotDashing(c);
    dashInertia(c, 0.03);
    if (jumpCancel(c, true, 2)) return;
    if (atFrame(c, 1)) {
        attackStart(c, 5, 21, 1);
        spawnAt(c, 442, -c.facing * 0x28, -10);
    }
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s205(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    stopIfNotDashing(c);
    dashInertia(c, 0.03);
    if (jumpCancel(c, true, 2)) return;
    if (atFrame(c, 2)) {
        attackStart(c, 13, 20, 1);
        spawnAt(c, 402, -c.facing * 0x1a, -16);
    }
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    if (c.b158 === 0 && atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1 && c.frame < 3) c.vx = c.vx - 0.03;
    else c.b158 = 0;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atFrame(c, 1)) c.w16c = 1;
    if (atFrame(c, 3) && c.f3138 === 0) {
        addMeter(c, 25);
        c.seRequest = 20;
        c.vx = 3.5;
        c.f3138++;
    }
    if (c.vx > 0.0) c.vx = c.vx - 0.036;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 4 && c.vx > 0.6) c.frame = 2;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (jumpCancel(c, false, 2)) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 3)) attackStart(c, 30, 20, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, false);
    }
}
function s207(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    airNormalDrift(c);
    if (airJumpCancel(c)) return;
    if (atFrame(c, 2)) {
        attackStart(c, 5, 21, 1);
        spawnAt(c, 443, -c.facing * 7, -47);
    }
    if (airNormalLand(c)) return;
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) toAirOr179(c);
    }
}
function s208(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    airNormalDrift(c);
    if (airJumpCancel(c)) return;
    if (atFrame(c, 2)) {
        attackStart(c, 13, 20, 2);
        spawnAt(c, 404, c.facing * 0x25, -72);
    }
    if (airNormalLand(c)) return;
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) toAirOr179(c);
    }
}
function s209(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    airNormalDrift(c);
    if (airJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 30, 20, 3);
    if (airNormalLand(c)) return;
    if (advance(c, dur)) {
        if (c.frame < 5) c.d168 = 0;
        if (c.frame === 5) spawnAt(c, 405, c.facing * 4, 5);
        if (c.frame === 8 && c.f3138 < 2) {
            c.frame = w16(c.frame - 3);
            c.f3138++;
            c.d168 = 0;
        }
        if (c.frame >= cnt) toAirOr179(c);
    }
}
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.blend = 0;
    airNormalDrift(c);
    if (airJumpCancel(c)) return;
    if (atFrame(c, 1)) attackStart(c, 30, 20, 1);
    if (airNormalLand(c)) return;
    if (advance(c, dur)) {
        if (c.frame < 5) c.d168 = 0;
        if (c.frame === 5) spawnAt(c, 460, c.facing * 0x37, -44);
        if (c.frame >= cnt) toAirOr179(c);
    }
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy = c.vy + c.ay;
    if (atStart(c)) {
        attackStart(c, 30, 20, 1);
        c.vx = c.vx / 2.0;
        c.ay = 0.07;
    }
    if (c.d168 > 1) {
        c.setState(213);
        c.stopMotion();
        return;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.shakeScreen(3, 0);
        const d = openSpawnFrame();
        d.b2c = 7;
        fxAtSelf(c, d, 3, 2, 0);
        c.setState(214);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy = c.vy + c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        const d = openSpawnFrame();
        d.b2c = 7;
        fxAtSelf(c, d, 3, 2, 0);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    c.blend = 0;
    c.b158 = 0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.onStateChange();
        c.stopMotion();
        o.stopMotion();
        c.state = 221;
        const d = openSpawnFrame();
        fxAt(c, d, 0, c.facing * 0x25, -42, 2, 1);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGroundNormal(c, true);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (atStart(c)) {
        o.frame = 0;
        o.timer = 0;
        o.stopMotion();
        o.knockX = 0.0;
        o.knockY = -2.5;
        o.state = 59;
    }
    if (atFrame(c, 1)) {
        const d = openSpawnFrame();
        const pats = [
            456,
            457,
            458
        ];
        const offs = [
            -c.facing * 0x50,
            0,
            c.facing * 0x50
        ];
        for(let k = 0; k < 3; k++){
            d.w04 = pats[k];
            d.x = ftol(o.x) + offs[k];
            d.y = 0.0;
            d.b20 = 0;
            d.b21 = 0;
            d.d28 = 1;
            d.b18 = c.facing;
            frameChild(c, d);
        }
    }
    if (c.frame === 3) c.faceOpponent();
    if (o.state === 64 && c.frame === 3) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function blendW13c(c) {
    if (c.blend === 3 || c.blend === 1) c.w13c = 2;
}
function blendFade(c) {
    if (c.blend === 1) c.blend = 0;
    if (c.blend === 3) c.blend = 1;
}
function decel003(c) {
    c.vx = c.vx - 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
}
function dashStart(c) {
    if (atStart(c)) {
        c.vx = 2.0;
        c.vy = 0.0;
    }
}
function s230(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    decel003(c);
    c.b158 = 0;
    dashStart(c);
    if (atFrame(c, 1)) attackStart(c, 15, 21, 1);
    blendW13c(c);
    if (advance(c, dur)) {
        if (c.frame === 1) c.d168 = 0;
        if (c.frame === 1) spawnAt(c, 441, -c.facing * 0x28, -33);
        blendFade(c);
        if (c.frame >= cnt) {
            c.blend = 0;
            c.setState(0);
        }
    }
}
function s231(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    if (jumpCancel(c, true, 2)) return;
    decel003(c);
    dashStart(c);
    if (c.vx < 0.0) c.vx = 0.0;
    if (atFrame(c, 1)) spawnAt(c, 400, -c.facing * 0x15, -31);
    if (atFrame(c, 3)) attackStart(c, 15, 20, 1);
    blendW13c(c);
    if (advance(c, dur)) {
        if (c.frame === 1) c.d168 = 0;
        blendFade(c);
        if (c.frame >= cnt) c.setState(0);
    }
}
function s232(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    decel003(c);
    c.b158 = 0;
    dashStart(c);
    if (atFrame(c, 5)) {
        const d = openSpawnFrame();
        fxAt(c, d, 3, c.facing * 0x37, 0, 2, 1);
        c.voiceRequest = 10;
    }
    if (atFrame(c, 4)) attackStart(c, 35, 20, 1);
    blendW13c(c);
    if (advance(c, dur)) {
        if (c.frame === 1) c.d168 = 0;
        blendFade(c);
        if (c.frame >= cnt) c.setState(0);
    }
}
function chAdvance(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    return true;
}
function chPlayOnce(c, i) {
    const ch = c.children[i];
    if (chAdvance(c, i)) {
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
const cPlayOnce = (c, i)=>chPlayOnce(c, i);
function c404(c, i) {
    const ch = c.children[i];
    if (c.state !== 208) c.freeChild(i);
    ch.x = c.facing * 0x25 + c.x;
    ch.y = c.y - 72.0;
    chPlayOnce(c, i);
}
function c405(c, i) {
    const ch = c.children[i];
    ch.x = (c.facing << 2) + c.x;
    ch.y = c.y + 5.0;
    if (chAdvance(c, i)) {
        ch.hitState = 0;
        if (ch.frame === 4 && c.state === 209 && c.frame < 8) ch.frame = w16(ch.frame - 2);
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function c406(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 0;
    }
    if (chAdvance(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function c443(c, i) {
    const ch = c.children[i];
    ch.x = c.x - c.facing * 7;
    ch.y = c.y - 41.0;
    if (c.state !== 207) c.freeChild(i);
    chPlayOnce(c, i);
}
function sideTail(c, i, onRun) {
    const ch = c.children[i];
    if (ch.frame > 2 && ch.frame < 6 && c.a3148[i] === 0) {
        ch.vx = 2.1;
        onRun();
    }
    if (ch.frame > 7) ch.vx = 3.1;
    if ((ch.x < -30.0 || ch.x > 670.0) && ch.frame > 7) c.freeChild(i);
    if (chAdvance(c, i)) {
        if (ch.frame === 6) ch.frame = w16(ch.frame - 3);
        if (ch.frame >= childCount) ch.frame = w16(ch.frame - 3);
    }
}
function cSide(c, i, vx0) {
    const ch = c.children[i];
    const o = c.opponent;
    ch.facing = s8(c.f3450);
    if (ch.frame === 1 && ch.timer === 0) {
        ch.vx = vx0;
        ch.vy = -2.3;
    }
    if (ch.y < 0.0) ch.vy = ch.vy + 0.035;
    if (ch.frame === 1 && o.state === 113) {
        ch.frame = 2;
        ch.timer = 0;
        ch.vx = 0.0;
    }
    if (ch.frame === 2 && ch.vy + ch.y > 0.0) {
        ch.y = 0.0;
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.frame = 3;
        ch.timer = 0;
    }
    sideTail(c, i, ()=>{
        if (o.state === 64) {
            ch.vx = 0.0;
            ch.frame = 6;
            ch.timer = 0;
        }
    });
}
const c456 = (c, i)=>cSide(c, i, 1.5);
const c458 = (c, i)=>cSide(c, i, -1.5);
function c457(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    c.f3450 = ch.facing;
    if (ch.frame === 1 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = -2.3;
    }
    if (ch.y < 0.0) ch.vy = ch.vy + 0.035;
    if (ch.frame === 1 && o.y - ch.y > 0.0) {
        const d = childSpawnFrame;
        fxAt(c, d, 0, c.facing * 0x25, -42, 2, 1);
        c.seRequest = 26;
        o.state = 113;
        o.timer = 0;
        o.frame = 0;
        o.stopMotion();
        ch.frame = 2;
        ch.timer = 0;
    }
    if (ch.frame === 2) {
        o.y = ch.y - 50.0;
        o.x = ch.x;
        if (ch.vy + ch.y > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.frame = 3;
            ch.timer = 0;
            ch.facing = 1;
            c.f3450 = 1;
            if (ch.x > 320.0) {
                ch.facing = -1;
                c.f3450 = -1;
            }
        }
    }
    sideTail(c, i, ()=>{
        o.y = ch.y - 50.0;
        o.x = ch.x;
        if (ch.x - c.x > 160.0 || ch.x - c.x < -160.0) {
            ch.frame = 6;
            ch.vx = 0.0;
            ch.timer = 0;
            o.frame = 0;
            o.timer = 0;
            o.facing = s8(-ch.facing);
            o.knockX = -2.1;
            o.knockY = -1.5;
            o.state = 64;
            applyDirectDamage(c, 1200, 750.0);
        }
    });
}
function c460(c, i) {
    const ch = c.children[i];
    ch.x = c.facing * 0x38 + c.x;
    ch.y = c.y - 44.0;
    if (chAdvance(c, i)) {
        ch.hitState = 0;
        if (ch.frame === 4 && c.state === 210 && c.frame < 9) ch.frame = w16(ch.frame - 2);
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
registerStates({
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    179: s179,
    180: s180,
    181: s181,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232
});
registerChildren({
    400: cPlayOnce,
    401: cPlayOnce,
    402: cPlayOnce,
    403: cPlayOnce,
    404: c404,
    405: c405,
    406: c406,
    441: cPlayOnce,
    442: cPlayOnce,
    443: c443,
    456: c456,
    457: c457,
    458: c458,
    460: c460
});
