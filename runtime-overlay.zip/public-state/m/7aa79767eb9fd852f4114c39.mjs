import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./2d89f5a5c2e93d6456ad7e4a.mjs";
import { updateChildrenKano } from "./59adbef650633f2bfaadb9d3.mjs";
import { parseCommandKano, dispatchMovesKano } from "./c7d2a8ac70abf58a2f45b073.mjs";
import { thinkKano, renderOverlayKano, tickHookKano } from "./231bc6e10b5ffef6198059bc.mjs";
import "./dc00fa8a8c0d1cd1a50ef2e1.mjs";
import "./1489aa3e05f58930936155a5.mjs";
import "./65df41ec4822522b80d2b637.mjs";
import "./cd8c68cda6d9c6f266d0baea.mjs";
const CTOR_POINTS_X = [
    -13,
    19,
    11,
    -3,
    -22
];
const CTOR_POINTS_Y = [
    -56,
    0,
    -7,
    -19,
    -38
];
const RESET_POINTS_X = [
    -4,
    18,
    21,
    18,
    38
];
const RESET_POINTS_Y = [
    -57,
    0,
    -12,
    -15,
    -39
];
export class Kano extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    f3154 = 0;
    f3158 = 0;
    f315c = 0;
    f3160 = 0;
    f3164 = 0;
    f3168 = 0;
    f316c = 0;
    f3170 = 0;
    a3174 = new Int32Array(64);
    a3274 = new Int32Array(64);
    a3374 = new Int32Array(64);
    pointsX = [
        ...CTOR_POINTS_X
    ];
    pointsY = [
        ...CTOR_POINTS_Y
    ];
    params = [
        5,
        0x17,
        0x18,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff,
        0xff,
        0x14
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = 0;
        this.f314c = 0;
        this.f3150 = 0;
        this.f3154 = 0;
        this.f3158 = 0;
        this.f315c = 0;
        this.f3160 = 0;
        this.f3164 = 0;
        this.f3168 = 0;
        this.f316c = 0;
        this.f3170 = 0;
        for(let k = 0; k < 5; k++){
            this.pointsX[k] = RESET_POINTS_X[k];
            this.pointsY[k] = RESET_POINTS_Y[k];
        }
        this.a3174.fill(0);
        this.a3274.fill(0);
        this.a3374.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3174[i] = 0;
        this.a3274[i] = 0;
        this.a3374[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayKano(this);
    }
    tickHook() {
        tickHookKano(this);
    }
    parseCommand() {
        parseCommandKano(this);
    }
    dispatchMoves() {
        dispatchMovesKano(this);
    }
    think() {
        thinkKano(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenKano(this);
    }
}

export function __logicState(){return {CTOR_POINTS_X,CTOR_POINTS_Y,RESET_POINTS_X,RESET_POINTS_Y};}

export function __installInitialRoots(s){
if(CTOR_POINTS_X!==s["CTOR_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_X');
if(CTOR_POINTS_Y!==s["CTOR_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_Y');
if(RESET_POINTS_X!==s["RESET_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_X');
if(RESET_POINTS_Y!==s["RESET_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_Y');
}
