import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./2d89f5a5c2e93d6456ad7e4a.mjs";
import { angleOf, childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame, setPolarVelocity } from "./59adbef650633f2bfaadb9d3.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
function advance(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return true;
}
function addMeter(c, v) {
    c.meter = s16(c.meter + v);
}
function startCommon(c) {
    c.b158 = 0;
    c.stopMotion();
    c.voiceRequest = 0;
}
function stopAt(c, n) {
    if (c.frame === n && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
}
function spawnFlash(c, d) {
    d.w04 = 0x196;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
    d.w04 = 0x197;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 0;
    d.b18 = c.facing;
    frameChild(c, d);
}
function charge(c, reset) {
    if (c.frame > 2 && c.frame < 7) c.f3150 = c.f3150 + 0x4b;
    if (c.frame > 2 && c.frame < 7 && c.f3150 >= 0x2710) {
        c.f3150 = reset;
        c.frame = 7;
        c.timer = 0;
        return true;
    }
    return false;
}
function cancelTo251(c, minFrame) {
    if (c.frame > minFrame && c.command === 0xd) {
        if (c.rfGauge >= 500.0 || c.rfBlue > 0) {
            c.onStateChange();
            c.stopMotion();
            c.state = 0xfb;
            return true;
        }
    }
    return false;
}
function rfCost(c) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) startCommon(c);
    if (c.frame > 2 && c.frame < 7) {
        c.f3150 = c.f3150 + 0x4b;
        c.f3138 = c.f3138 + 1;
        if (c.f3150 > 0x2710) c.f3150 = 0x2710;
    }
    if (c.frame > 2 && c.frame < 7 && c.pressed[3] === 1 || c.f3150 >= 0x2710 && c.frame < 7) {
        c.timer = 0;
        c.frame = 7;
        return;
    }
    if (c.frame === 3 && c.timer === 0) spawnFlash(c, d);
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 7) c.frame = c.frame - 4;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function state251(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 3) {
        c.w16c = 1;
        rfCost(c);
        c.f3150 = 0x2710;
        d.w04 = 0x198;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x28;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        d.w04 = 0x197;
        d.x = ftol(c.x);
        d.y = ftol(c.y);
        d.b20 = 2;
        d.b21 = 0;
        d.b18 = c.facing;
        frameChild(c, d);
        c.voiceRequest = 1;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function stateWave(c, reset, pat, cost) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) startCommon(c);
    if (c.frame === 3 && c.timer === 0) spawnFlash(c, d);
    stopAt(c, 7);
    if (charge(c, reset)) return;
    if (cancelTo251(c, 0xf)) return;
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame === 7) c.frame = c.frame - 4;
    if (c.frame === 0x10 && c.f3138 < 1) {
        d.w04 = pat;
        d.x = ftol(c.x) + (c.facing * 0x96 + c.inputX * 0x46);
        d.y = 0.0;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.voiceRequest = 3;
        c.f3170 = c.f3170 + 1;
        if (cost !== 0) addMeter(c, -cost);
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function headSpecial(c, d, reset, minFrame) {
    if (atStart(c)) startCommon(c);
    stopAt(c, 7);
    if (charge(c, reset)) return true;
    if (cancelTo251(c, minFrame)) return true;
    if (c.frame === 3 && c.timer === 0) spawnFlash(c, d);
    return false;
}
function spawn401(c, d, dy) {
    d.w04 = 0x191;
    d.x = ftol(c.x) + c.facing * 0x26;
    d.y = ftol(c.y) + dy;
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = c.facing;
    d.d00 = 1;
    frameChild(c, d);
}
function state257(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (headSpecial(c, d, 0x1d4c, 0x10)) return;
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame === 7) c.frame = c.frame - 4;
    if (c.frame === 0x11 && c.f3138 < 1) {
        spawn401(c, d, -0x2d);
        c.voiceRequest = 5;
        c.f316c = c.f316c + 1;
    }
    if (c.frame === 0x13 && c.f3138 < 1) {
        c.frame = c.frame - 3;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function stateDrill(c, reset, cost, loops) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (headSpecial(c, d, reset, 0x10)) return;
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame === 7) c.frame = c.frame - 4;
    if (c.frame === 0x11) {
        if (c.f3138 === 0) {
            spawn401(c, d, -0x2d);
            c.voiceRequest = 5;
            c.f316c = c.f316c + 1;
            addMeter(c, -cost);
        }
        if (c.f3138 === 1) {
            spawn401(c, d, -0x14);
            c.f316c = c.f316c + 1;
            addMeter(c, -cost);
            spawn401(c, d, -0x46);
            c.voiceRequest = 5;
            c.f316c = c.f316c + 1;
            addMeter(c, -cost);
        }
        if (loops === 3 && c.f3138 === 2) {
            spawn401(c, d, 5);
            c.f316c = c.f316c + 1;
            addMeter(c, -cost);
            spawn401(c, d, -0x5f);
            c.voiceRequest = 5;
            c.f316c = c.f316c + 1;
            addMeter(c, -cost);
        }
    }
    if (c.frame === 0x13 && c.f3138 < loops) {
        c.frame = c.frame - 3;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function stateAim(c, reset, pat, cost) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (headSpecial(c, d, reset, 0xb)) return;
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame === 7) c.frame = c.frame - 4;
    if (c.frame === 0xc && c.timer === 0) {
        d.w04 = pat;
        d.x = c.x;
        d.y = -80.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        d.d00 = 1;
        frameChild(c, d);
        c.f3168 = c.f3168 + 1;
        c.voiceRequest = 4;
        c.f313c = 0x15;
        c.f3138 = c.f3138 + 1;
        if (cost !== 0) addMeter(c, -cost);
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function stateBlast(c, dx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) startCommon(c);
    stopAt(c, 6);
    if (c.frame > 2 && c.frame < 6) c.f3150 = c.f3150 + 0x12c;
    if (c.frame > 2 && c.frame < 6 && c.f3150 >= 0x2710) {
        c.f3150 = 0;
        c.frame = 7;
        c.timer = 0;
        return;
    }
    if (c.frame === 0xf) c.f313c = c.f313c - 1;
    if (c.frame === 0xc && c.f3138 < 1) {
        d.w04 = 0x199;
        d.x = ftol(c.x) + c.facing * dx;
        d.y = -40.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.f3138 = c.f3138 + 1;
        c.voiceRequest = 2;
    }
    if (c.frame === 3 && c.timer === 0) spawnFlash(c, d);
    if (!advance(c, dur)) return;
    c.d168 = 3;
    if (c.frame === 6) c.frame = c.frame - 3;
    if (c.frame === 0x10 && c.f3138 < 2) {
        c.frame = c.frame - 3;
        c.f3138 = c.f3138 + 1;
    }
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function stateRain(c, dx1, dx2, dx3) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.stopMotion();
        c.f3138 = 2;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.voiceRequest = 6;
        d.w04 = 0x1a2;
        d.x = ftol(c.x) + c.facing * dx1;
        d.y = ftol(c.y) - 0x1e0;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 2;
        frameChild(c, d);
        d.x = ftol(c.x) + c.facing * dx2;
        d.y = ftol(c.y) - 0x208;
        frameChild(c, d);
        d.x = ftol(c.x) + c.facing * dx3;
        d.y = ftol(c.y) - 0x212;
        frameChild(c, d);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
        c.faceOpponent();
    }
}
function stateAir(c, extra) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = c.vx * 0.5;
        c.vy = c.vy * 0.5;
        c.ay = 0.01;
        addMeter(c, 0x2d);
        c.f3138 = 3;
        if (extra) {
            rfCost(c);
            d.w04 = 0x21;
            d.b2c = 0xb;
            d.x = ftol(c.x);
            d.y = ftol(c.y) - 0x32;
            d.b20 = 2;
            d.b21 = 1;
            frameEffect(d);
        }
    }
    c.vy = c.vy + c.ay;
    if (c.frame === 2 && c.timer === 0) {
        d.w04 = 0x197;
        d.x = ftol(c.x) - c.facing * 0x1e;
        d.y = ftol(c.y) - 0x1e;
        d.b18 = c.facing;
        d.b21 = 1;
        d.b20 = 2;
        frameChild(c, d);
    }
    if (extra) {
        if (c.frame > 1) c.f313c = c.f313c + 1;
        if (c.f313c === 0x10) spawn407At(c, d, 0x1e, -0x1e);
        if (c.f313c === 0x20) spawn407At(c, d, 0x14, -0xa);
        if (c.f313c === 0x30) spawn407At(c, d, -0x14, -0xa);
    }
    if (!advance(c, dur)) return;
    c.d168 = 0;
    if (c.frame === 7 && c.f3138 < 3) {
        c.f3138 = c.f3138 + 1;
        c.frame = c.frame - 4;
        return;
    }
    if (c.frame >= cnt) {
        c.onStateChange();
        c.state = 9;
        c.ay = 0.035;
    }
}
function spawn407At(c, d, fx, dy) {
    d.w04 = 0x197;
    d.x = ftol(c.x) + c.facing * fx;
    d.y = ftol(c.y) + dy;
    d.b18 = c.facing;
    d.b21 = 1;
    d.b20 = 2;
    frameChild(c, d);
}
registerStates({
    250: state250,
    251: state251,
    254: (c)=>stateWave(c, 0x1d4c, 0x1bb, 0),
    255: (c)=>stateWave(c, 0x1388, 0x1bc, 0x14),
    256: (c)=>stateWave(c, 0x9c4, 0x1bd, 0x32),
    257: state257,
    258: (c)=>stateDrill(c, 0x1388, 7, 2),
    259: (c)=>stateDrill(c, 0x9c4, 0xa, 3),
    260: (c)=>stateAim(c, 0x1d4c, 0x1b8, 0),
    261: (c)=>stateAim(c, 0x1388, 0x1b9, 0x14),
    262: (c)=>stateAim(c, 0x9c4, 0x1ba, 0x32),
    263: (c)=>stateBlast(c, 0x6e),
    264: (c)=>stateBlast(c, 0xa0),
    265: (c)=>stateRain(c, 0x64, 0x50, 0x82),
    266: (c)=>stateRain(c, 0xb4, 0xa0, 0xd2),
    267: (c)=>stateRain(c, 0x104, 0xf0, 0x122),
    268: (c)=>stateAir(c, false),
    269: (c)=>stateAir(c, false),
    270: (c)=>stateAir(c, true)
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    return true;
}
const ownerHit = (c)=>c.state > 0x31 && c.state < 0x96;
function spawn405(c, i) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    d.w04 = 0x195;
    d.x = ftol(ch.x);
    d.y = ftol(ch.y);
    d.b20 = 2;
    d.b21 = 1;
    d.b18 = c.facing;
    frameChild(c, d);
}
function childBullet(c, i, angle) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 1;
        c.a3174[i] = c.a3174[i] + 1;
        setPolarVelocity(c, i, angle, 3.0);
    }
    if (ch.hitState > 0 || ch.y > 0.0 || ownerHit(c)) {
        spawn405(c, i);
        c.freeChild(i);
        c.f3168 = c.f3168 - 1;
        return;
    }
    if (ch.x > 680.0 || ch.x < -40.0) {
        c.freeChild(i);
        c.f3168 = c.f3168 - 1;
    }
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = ch.frame - 1;
}
function aimPattern(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    const d = childSpawnFrame;
    if (ch.facing === 1) {
        d.w04 = 0x1b3;
        if (ch.x > o.x) {
            if (angleOf(ch.x - o.x, ch.y - o.y) < 70.0) d.w04 = 0x1b4;
            if (angleOf(ch.x - o.x, ch.y - o.y) < 55.0) d.w04 = 0x1b5;
            if (angleOf(ch.x - o.x, ch.y - o.y) < 40.0) d.w04 = 0x1b6;
            if (angleOf(ch.x - o.x, ch.y - o.y) < 25.0) d.w04 = 0x1b7;
        }
        if (ch.x < o.x) {
            if (angleOf(o.x - ch.x, o.y - ch.y) < 70.0) d.w04 = 0x1b4;
            if (angleOf(o.x - ch.x, o.y - ch.y) < 55.0) d.w04 = 0x1b5;
            if (angleOf(o.x - ch.x, o.y - ch.y) < 40.0) d.w04 = 0x1b6;
            if (angleOf(o.x - ch.x, o.y - ch.y) < 25.0) d.w04 = 0x1b7;
        }
    }
    if (ch.facing === -1) {
        d.w04 = 0x1b3;
        if (ch.x > o.x) {
            if (angleOf(ch.x - o.x, ch.y - o.y) > 110.0) d.w04 = 0x1b4;
            if (angleOf(ch.x - o.x, ch.y - o.y) > 125.0) d.w04 = 0x1b5;
            if (angleOf(ch.x - o.x, ch.y - o.y) > 140.0) d.w04 = 0x1b6;
            if (angleOf(ch.x - o.x, ch.y - o.y) > 165.0) d.w04 = 0x1b7;
        }
        if (ch.x > o.x) {
            if (angleOf(o.x - ch.x, o.y - ch.y) > 110.0) d.w04 = 0x1b4;
            if (angleOf(o.x - ch.x, o.y - ch.y) > 125.0) d.w04 = 0x1b5;
            if (angleOf(o.x - ch.x, o.y - ch.y) > 140.0) d.w04 = 0x1b6;
            if (angleOf(o.x - ch.x, o.y - ch.y) > 165.0) d.w04 = 0x1b7;
        }
    }
}
function childLauncher(c, i, limit) {
    const ch = c.children[i];
    if (c.a3174[i] === 0) {
        ch.hitsLeft = 1;
        c.a3174[i] = c.a3174[i] + 1;
        ch.vy = -3.0;
        ch.vx = 0.0;
    }
    if (ch.vx === 0.0) {
        ch.vy = ch.vy + 0.045;
        if (ch.vy > 0.0) ch.vy = 0.0;
    }
    if (ownerHit(c)) {
        spawn405(c, i);
        c.freeChild(i);
        c.f3168 = c.f3168 - 1;
        return;
    }
    const ready = limit === 0 ? ch.timer === 0 : c.a3374[i] > 0xf;
    if (c.a3174[i] > 2 && ready) {
        aimPattern(c, i);
        const d = childSpawnFrame;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y);
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        if (limit === 0) {
            c.freeChild(i);
            return;
        }
        c.f3168 = c.f3168 + 1;
        if (c.a3274[i] === limit) {
            c.freeChild(i);
            c.f3168 = c.f3168 - 1;
        }
        c.a3274[i] = c.a3274[i] + 1;
        c.a3374[i] = 0;
        return;
    }
    if (limit !== 0) c.a3374[i] = c.a3374[i] + 1;
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) {
        ch.frame = 0;
        c.a3174[i] = c.a3174[i] + 1;
    }
}
function childPillar(c, i, kind) {
    const ch = c.children[i];
    if (ch.timer === 0) {
        const d = childSpawnFrame;
        d.w04 = 0x190;
        if (kind === 443) {
            d.x = ftol(ch.x);
        } else if (kind === 444) {
            d.x = ftol(ch.x) + (c.a3174[i] - 1) * 0x19 * ch.facing;
        } else {
            d.x = ftol(ch.x) + (c.a3174[i] * 0x19 - 0x32) * ch.facing;
        }
        d.y = ftol(ch.y);
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (ownerHit(c)) {
        c.freeChild(i);
        c.f3170 = c.f3170 - 1;
        return;
    }
    if (!childAdvance(c, i)) return;
    ch.hitState = 0;
    if (ch.frame >= childCount) {
        const limit = kind === 443 ? 0 : kind === 444 ? 2 : 4;
        if (c.a3174[i] < limit) {
            ch.frame = ch.frame - 1;
            c.a3174[i] = c.a3174[i] + 1;
            return;
        }
        c.freeChild(i);
        c.f3170 = c.f3170 - 1;
    }
}
registerChildren({
    435: (c, i)=>childBullet(c, i, 70.0),
    436: (c, i)=>childBullet(c, i, 55.0),
    437: (c, i)=>childBullet(c, i, 40.0),
    438: (c, i)=>childBullet(c, i, 25.0),
    439: (c, i)=>childBullet(c, i, 10.0),
    440: (c, i)=>childLauncher(c, i, 0),
    441: (c, i)=>childLauncher(c, i, 2),
    442: (c, i)=>childLauncher(c, i, 4),
    443: (c, i)=>childPillar(c, i, 443),
    444: (c, i)=>childPillar(c, i, 444),
    445: (c, i)=>childPillar(c, i, 445)
});
