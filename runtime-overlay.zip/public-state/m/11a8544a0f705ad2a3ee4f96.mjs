import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { createImage, loadDat, loadDatSequence } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { ReplayFile } from "./8d7f594b1298130b3a745321.mjs";
import { createPalette, loadPalette, readColorKey } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { createStageObject } from "./c6d7e3bfd7316f9666e0cf6b.mjs";
export var GameMode = /*#__PURE__*/ function(GameMode) {
    GameMode[GameMode["Arcade"] = 0] = "Arcade";
    GameMode[GameMode["Practice"] = 1] = "Practice";
    GameMode[GameMode["Score"] = 2] = "Score";
    GameMode[GameMode["VsCom"] = 3] = "VsCom";
    GameMode[GameMode["VsPlayer"] = 4] = "VsPlayer";
    GameMode[GameMode["Replay"] = 5] = "Replay";
    GameMode[GameMode["Demo"] = 6] = "Demo";
    return GameMode;
}({});
export function requestGameSpeed(ticks) {
    gameState.speedRequest = 1;
    gameState.speedTicks = ticks & 0xff;
}
export function setBgmRamp(target, step) {
    gameState.bgmTarget = target | 0;
    gameState.bgmStep = step << 16 >> 16;
}
export function loadOptions(read) {
    if (read(0x21) > 0) {
        gameState.hasSavedOptions = 1;
        gameState.option3 = read(0x21);
        gameState.option0 = read(0x22) - 1;
        gameState.option2 = read(0x23) - 1;
        gameState.option1 = read(0x24);
        gameState.winRoundsConfig = read(0x26);
    } else {
        gameState.option3 = 2;
        gameState.option0 = 1;
        gameState.option2 = 1;
        gameState.option1 = 2;
        gameState.winRoundsConfig = 2;
    }
}
export const EFFECT_COUNT = 920;
export function loadBattleCommon() {
    gameState.effects = loadDatSequence("system\\effect\\effect.dat", EFFECT_COUNT, 0x51, 0xaf);
    gameState.objectSurf = loadDat("system\\object.dat", 0, 175);
    loadPalette(gameState.palette, "system\\object.dat", 0, 175, 80);
    gameState.objectKey = readColorKey(gameState.objectSurf);
}
export function loadStageBackground(stage) {
    const base = `system\\bg\\bg${String(stage).padStart(2, "0")}`;
    gameState.bgSurf = loadDat(`${base}.dat`, 0, 1);
    loadPalette(gameState.palette, `${base}.dat`, 0, 1, 0x5e);
    gameState.bgbSurf = loadDat(`${base}b.dat`, 0, 0xaf);
    const obj = createStageObject(stage);
    if (obj) gameState.stageObject = obj;
    gameState.bgZoom = stage === 16 ? 0.125 : 1.0;
}
export function deleteStageObject() {
    gameState.stageObject = null;
}
function emptyInput() {
    return {
        moveX: 0,
        moveY: 0,
        a: 0,
        b: 0,
        c: 0,
        d: 0
    };
}
export const gameState = {
    input: [
        emptyInput(),
        emptyInput()
    ],
    palette: createPalette(),
    effects: [],
    objectSurf: createImage(0, 0),
    objectKey: 0,
    bgSurf: createImage(0, 0),
    bgbSurf: createImage(0, 0),
    bgZoom: 1.0,
    introState: 0,
    roundOver: 0,
    roundNumber: 1,
    winner: 0,
    practiceDummyStance: 0,
    practiceAutoGuard: 0,
    specialTimerC: 0,
    specialTimerE: 0,
    frameParity: 0,
    chars: [
        null,
        null
    ],
    shakeAmp: 0,
    shakeHold: 0,
    shakeX: 0,
    shakeY: 0,
    shakePhaseX: 0,
    shakePhaseY: 0,
    cameraBias: 0,
    cameraBiasFrames: 0,
    cameraYBias: 0,
    cameraYBiasFrames: 0,
    viewLeft: 0,
    viewTop: 0,
    viewRight: 0,
    viewBottom: 0,
    bgbFrames: 0,
    bgmTarget: 0,
    bgmVolume: 0,
    bgmStep: 0,
    stageObject: null,
    speedRequest: 0,
    speedTicks: 0,
    darkenSide: 0,
    flashMode: 0,
    flashValue: 0,
    flashIn: 0,
    flashHold: 0,
    flashOut: 0,
    fighters: [
        null,
        null
    ],
    stage: 0,
    usePal: [
        0,
        0
    ],
    fileCheck: 1,
    round: 0,
    defeatedMask: 0,
    stageMask: 0,
    option0: 1,
    option1: 2,
    option2: 1,
    option3: 2,
    hasSavedOptions: 0,
    continued: 0,
    continueRound: 0,
    startPlayer: 0,
    cpuSide: [
        0,
        0
    ],
    winRounds: 0,
    winRoundsConfig: 2,
    mode: 0,
    replayRow: 0,
    replayCol: 0,
    replayMode: 0,
    replayFile: new ReplayFile(),
    replayVersion: 0,
    lastTitleCursor: 0
};

export function __logicState(){return {GameMode,gameState};}

export function __installInitialRoots(s){
GameMode=s["GameMode"];
if(gameState!==s["gameState"])throw Error('INITIAL_CONST_IDENTITY:gameState');
}
