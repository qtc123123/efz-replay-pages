import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { s8 } from "./7596266716c972d06fe8897a.mjs";
function rnd(c, lo, hi) {
    return c.random(lo, hi) & 0xffff;
}
function chance(c, k) {
    const r = rnd(c, 0, 100);
    return k * c.aiLevel > r;
}
function forwardDash(c) {
    return c.facing === 1 ? 1 : 0;
}
function startJump(c) {
    c.aiMode = 4;
    c.inputY = -1;
    c.inputX = s8(rnd(c, 0, 2) - 1);
}
function rfOk(c) {
    return c.rfGauge > 500.0 || c.rfBlue > 0;
}
export function thinkExNanase(c) {
    const o = c.opponent;
    c.command = NO_COMMAND;
    if (c.aiTimer1a0 > 0) c.aiTimer1a0--;
    if (c.aiTimer1a4 > 0) c.aiTimer1a4--;
    c.inputX = 0;
    c.inputY = 0;
    c.pressed[0] = 0;
    c.pressed[1] = 0;
    c.pressed[2] = 0;
    c.pressed[3] = 0;
    c.backWindow = 0;
    {
        const air = c.y < 0.0 ? 1 : 0;
        const r = rnd(c, 0, 1000);
        const thr = 25.0 * c.aiLevel + air * 30 * c.aiLevel + (c.aiMode === 3 ? 1 : 0) * 400 + (c.state === 170 ? 1 : 0) * 300;
        if (thr > r) c.backWindow = 60;
    }
    {
        const blocking = c.state > 149 && c.state < 157 ? 1 : 0;
        const r = rnd(c, 0, 2000);
        const thr = ((c.b130 > 0 ? 1 : 0) * 4.0 + 1.0) * 8.0 * c.aiLevel * (blocking + blocking + 1);
        if (thr > r) c.backWindow = 60;
    }
    {
        const r = rnd(c, 0, 1000);
        if (40.0 * c.aiLevel > r && c.state > 199) c.backWindow = 60;
    }
    if (c.d170 === 1 && c.aiMode === 2) {
        c.backWindow = 30;
        if (c.state < 200) c.aiMode = 0;
        return;
    }
    if (o.state === 96) return;
    const dx = (o.x - c.x) * c.facing;
    const dy = Math.abs(c.y - o.y);
    if (c.state >= 50 && c.state <= 150 && c.timer === 0) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        c.inputX = 1 - 2 * (rnd(c, 0, 100) < 50 ? 1 : 0);
        c.pressed[3] = rnd(c, 0, 240) < dy ? 1 : 0;
        c.pressed[3] = rnd(c, 0, 320) < dx ? 1 : 0;
        if (o.state > 199 && o.state < 250 && o.frame < 3 && dy < 100.0 && dx < 150.0) c.pressed[3] = 0;
        return;
    }
    if ((c.state >= 4 && c.state <= 6 || c.state >= 10 && c.state <= 12) && c.y === 0.0) return;
    if (o.state >= 50 && o.state < 150 && c.state === 264 && c.w16c > 1) return;
    if (c.state === 251) {
        if (o.vy > 0.0 && o.y > -280.0 && o.y < -20.0 && rnd(c, 0, 1000) < 2) {
            c.command = 10;
            return;
        }
        if (o.vy > 0.0 && o.y > -220.0 && o.y < -20.0) {
            if (rnd(c, 0, 1000) < 30) c.command = 11;
            if (rnd(c, 0, 1000) < 10 && c.meter === 3000 && o.y < -100.0) c.command = 12;
            return;
        }
    }
    if (c.state === 168 && c.timer < 6) {
        if (o.state !== 200 && o.state !== 204 && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx < 40.0 && chance(c, 3.0) && o.y === 0.0) {
                c.command = 70;
                return;
            }
            if (dx < 60.0 && chance(c, 3.0)) {
                c.pressed[0] = 1;
                c.inputY = 0;
                return;
            }
            if (dx < 60.0 && chance(c, 3.0)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
        }
        if ((o.state === 201 || o.state === 202 || o.state === 205) && o.state < 250 && o.y === 0.0 && o.w16c === 0) {
            if (dx > 40.0 && dx < 80.0 && chance(c, 3.0)) {
                c.pressed[1] = 1;
                c.inputY = 0;
                c.inputX = 0;
                return;
            }
            if (dx > 60.0 && dx < 120.0 && chance(c, 3.0)) {
                c.pressed[0] = 1;
                c.inputY = 1;
                return;
            }
        }
    }
    if (c.state === 168 || c.state === 169) {
        if (dx < 100.0) {
            {
                const r = rnd(c, 0, 100);
                if (c.aiLevel + c.aiLevel > r && o.y === 0.0 && dx < 40.0 && o.y === 0.0) {
                    c.command = 70;
                    return;
                }
            }
            if (chance(c, 3.0) && c.rfGauge > 500.0) {
                c.command = 20;
                return;
            }
            {
                const g = c.rfGauge > 500.0 ? 1 : 0;
                const r = rnd(c, 0, 100);
                if (c.aiLevel * 3.0 + g * 2 > r && o.y === 0.0) {
                    c.command = 12;
                    return;
                }
            }
            {
                const g = c.rfGauge > 500.0 ? 1 : 0;
                const r = rnd(c, 0, 100);
                if (c.aiLevel * 3.0 + g * 2 > r) {
                    c.command = rnd(c, 0, 1) === 1 ? 32 : 31;
                    return;
                }
            }
            if (chance(c, 3.0) && c.meter >= 1000 && o.y === 0.0) {
                c.command = 110;
                return;
            }
            if (chance(c, 3.0) && dx < 150.0 && c.meter >= 1000 && o.y === 0.0) {
                c.command = 100;
                return;
            }
        }
        if (dx < 160.0 && chance(c, 3.0) && c.rfGauge > 500.0) {
            c.command = 12;
            return;
        }
        if (dx < 220.0 && dx > 160.0 && chance(c, 1.0)) {
            c.command = rnd(c, 0, 2) + 10;
            return;
        }
        if (dx > 220.0 && chance(c, 1.0) && c.rfGauge > 500.0) {
            c.command = rnd(c, 0, 2) + 10;
            return;
        }
    }
    if (c.state === 170 && c.frame === 1 && c.timer === 0) {
        if (chance(c, 5.0)) {
            c.aiMode = 3;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -60.0 && dx < 80.0 && chance(c, 5.0)) {
            c.pressed[0] = 1;
            return;
        }
        if (dy < 80.0 && dx < 100.0 && chance(c, 5.0)) {
            c.pressed[1] = 1;
            return;
        }
        if (c.y - o.y < 0.0 && c.y - o.y > -60.0 && dx < 80.0 && chance(c, 5.0)) {
            c.pressed[2] = 1;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y === 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 3 && c.rfGauge > 500.0) {
            c.command = 20;
            return;
        }
        if (c.aiRoll < 7 && c.rfGauge > 500.0) {
            c.command = 12;
            return;
        }
        if (c.aiRoll < 10 && c.rfGauge > 500.0) {
            c.command = 32;
            return;
        }
        if (c.aiRoll < 13 && c.rfGauge > 500.0) {
            c.command = 22;
            return;
        }
        if (c.aiRoll < 17 && c.aiRoll > 12 && c.meter >= 1000) {
            c.command = rnd(c, 0, 2) + 110;
            return;
        }
        if (c.aiRoll < 18 && c.aiRoll > 22 && c.meter >= 1000) {
            c.command = rnd(c, 0, 2) + 100;
            return;
        }
    }
    if ((o.state === 168 || o.state === 169 || o.state === 170) && c.y < 0.0 && 15.0 * c.aiLevel > rnd(c, 0, 100) && c.aiMode !== 2 && o.freeze === 0) {
        c.aiRoll = rnd(c, 0, 100);
        if (c.aiRoll < 20) {
            c.aiMode = 2;
            return;
        }
        if (dx < 200.0 && c.aiRoll < 32 && o.y === 0.0 && dx * 0.5 > dy && dx * 0.3 < dy) {
            c.command = 22;
            return;
        }
    }
    if (rfOk(c) && 8.0 * c.aiLevel > rnd(c, 0, 100) && o.state > 149 && o.state < 157 && (c.state === 256 || c.state === 257 || c.state === 259 || c.state === 300 || c.state === 301 || c.state === 302)) {
        c.command = 52;
        return;
    }
    if (rfOk(c) && 1.0 * c.aiLevel > rnd(c, 0, 100) && c.d168 === 3 && (c.state === 253 && c.frame === 13 || c.state === 254 && c.frame === 13)) {
        c.command = 52;
        return;
    }
    if (c.aiMode > 0 && c.state > 49 && c.state < 158) c.aiMode = 0;
    if (c.aiMode === 1 && c.state < 200) c.aiMode = 0;
    if (c.aiMode === 2 && c.d170 !== 1) {
        c.aiMode = 0;
        return;
    }
    if (c.aiMode === 4) {
        c.inputY = -1;
        c.inputX = s8(rnd(c, 0, 2) - 1);
        if (c.state === 4 || c.state === 5 || c.state === 6) {
            c.command = forwardDash(c);
            if (c.state === 165) c.aiMode = 0;
            c.inputY = 0;
            c.inputX = 0;
            return;
        }
    }
    if (c.aiMode === 5 && c.state < 50) {
        c.command = forwardDash(c);
        if (c.state === 163) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 6 && c.state < 50) {
        c.command = forwardDash(c);
        if (c.state === 163) c.aiMode = 7;
        return;
    }
    if (c.aiMode === 7 && c.state === 163) {
        c.pressed[0] = 1;
        if (c.state === 230) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 8 && c.state < 50) {
        c.command = forwardDash(c);
        if (c.state === 163) c.aiMode = 9;
        return;
    }
    if (c.aiMode === 9 && c.state === 163) {
        c.pressed[0] = 2;
        if (c.state === 231) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 10 && c.state < 50) {
        c.command = forwardDash(c);
        if (c.state === 163) c.aiMode = 11;
        return;
    }
    if (c.aiMode === 11 && c.state === 163) {
        c.pressed[0] = 3;
        if (c.state === 232) c.aiMode = 0;
        return;
    }
    if (c.aiMode === 12 && c.state < 50) {
        c.command = 70;
        if (c.state === 250) c.aiMode = 0;
        return;
    }
    if (c.d168 > 1 && c.hitstop === 0 && c.aiLevel * 25.0 > rnd(c, 0, 100) && c.aiMode !== 1 && c.aiMode !== 2) {
        c.aiRoll = rnd(c, 0, 1000);
        if (comboExNanase(c, dx)) return;
    }
    if (25.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.aiRoll = rnd(c, 0, 1000);
        if (c.y === 0.0) {
            if (o.y === 0.0 && o.state !== 99) {
                if (dx < 40.0 && o.y === 0.0 && c.aiRoll < 3) {
                    c.pressed[2] = 1;
                    c.inputX = s8(-c.facing);
                    c.inputY = 0;
                    return;
                }
                if (dx < 50.0 && o.y === 0.0 && c.aiRoll < 8) {
                    c.command = 70;
                    return;
                }
                if (dx < 100.0 && c.aiRoll < 20) {
                    c.pressed[0] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 30) {
                    c.pressed[0] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 100.0 && dx > 70.0 && c.aiRoll < 15) {
                    c.pressed[1] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 140.0 && c.aiRoll < 20) {
                    c.pressed[1] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx > 160.0 && c.aiRoll < 26) {
                    c.aiMode = 8;
                    return;
                }
                if (dx > 160.0 && c.aiRoll < 32) {
                    c.aiMode = 10;
                    return;
                }
                if (dx < 170.0 && dx > 120.0 && c.aiRoll < 37) {
                    c.pressed[2] = 1;
                    c.inputY = 1;
                    return;
                }
                if (dx < 220.0 && dx > 70.0 && c.aiRoll < 40) {
                    c.pressed[2] = 1;
                    c.inputY = 0;
                    return;
                }
                if (dx < 80.0 && c.aiRoll < 42 && c.aiRoll > 40) {
                    c.command = 20;
                    return;
                }
                if (c.aiRoll < 42 && c.aiRoll > 50) {
                    c.command = c.facing & 0xffff;
                    c.aiMode = 5;
                    return;
                }
                if (dx > 180.0 && c.aiRoll > 250 && c.aiRoll < 252 && c.meter >= 1000) {
                    c.command = rnd(c, 0, 2) + 110;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (o.vy < 0.0) {
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < 10) {
                        c.inputY = -1;
                        c.inputX = s8(-c.facing);
                        return;
                    }
                    if (dx < 120.0 && c.aiRoll < 30) {
                        c.pressed[1] = 1;
                        c.inputY = 1;
                        return;
                    }
                    if (dx > 80.0 && dx < 120.0 && dy > 70.0 && c.aiRoll < 30) {
                        c.pressed[1] = 1;
                        c.inputY = 1;
                        return;
                    }
                    if (dx > 120.0 && dx < 180.0 && dy > 90.0 && c.aiRoll < 30) return;
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < 35) {
                        c.command = 21;
                        return;
                    }
                }
                if (o.vy > 0.0) {
                    if (dx < 80.0 && dy < 120.0 && c.aiRoll < (rfOk(c) ? 1 : 0) * 5 + 6) {
                        c.command = 20;
                        return;
                    }
                    if (dx < 90.0 && dy < 120.0 && dy > 90.0 && c.aiRoll < 15) {
                        c.pressed[1] = 1;
                        c.inputY = 1;
                        return;
                    }
                    if (dx < 120.0 && dy < 100.0 && c.aiRoll < 17 && c.meter === 3000) {
                        c.command = 153;
                        return;
                    }
                }
            }
        }
        if (c.y < 0.0 && c.aiMode !== 3) {
            if (o.y === 0.0) {
                if (dx < 100.0 && dy < 100.0 && c.aiRoll < (o.y === 0.0 ? 1 : 0) * 100 + 100) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 120.0 && dy < 100.0 && c.aiRoll > 200 && c.aiRoll < 260) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 140.0 && dx > 80.0 && dy > 40.0 && dy < 80.0 && c.aiRoll > 260 && c.aiRoll < 265) {
                    c.pressed[2] = 1;
                    return;
                }
            }
            if (o.y < 0.0) {
                if (dx < 120.0 && dy < 90.0 && o.y > c.y && c.aiRoll < 110) {
                    c.pressed[0] = 1;
                    return;
                }
                if (dx < 120.0 && dy < 90.0 && c.aiRoll < 310) {
                    c.pressed[1] = 1;
                    return;
                }
                if (dx < 150.0 && dx > 100.0 && dy < 90.0 && c.aiRoll < 400) {
                    c.pressed[2] = 1;
                    return;
                }
            }
        }
    }
    if (c.state < 50 && (o.state > 149 && o.state < 156 || o.state > 49 && o.state < 59) && c.y === 0.0 && 3.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.command = forwardDash(c);
        return;
    }
    if (c.state < 50 && o.state < 50 && dx > 60.0 && dx < 100.0 && 1.0 * c.aiLevel > rnd(c, 0, 100)) {
        c.command = c.facing === 1 ? 0 : 1;
        return;
    }
    if (rnd(c, 0, 1000) < 2) {
        c.aiMode = 4;
        return;
    }
    if (rnd(c, 0, 100) < 2) {
        c.aiMode = 8.0 * c.aiLevel > rnd(c, 0, 100) ? 3 : 0;
        if (dx > 160.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 100.0 && c.y === 0.0 && rnd(c, 0, 100) < 2) {
            c.inputX = 0;
            c.inputY = -1;
            return;
        }
        if (dx < 170.0 && dx > 120.0 && c.y === 0.0) {
            c.inputX = c.facing;
            c.inputY = -1;
            return;
        }
    }
    if (c.aiTimer1a0 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a0 > 15) c.aiTimer1a0 = 15;
        c.inputX = 1;
        return;
    }
    if (c.aiTimer1a4 > 0) {
        if (c.wallBlock() !== 0 && c.aiTimer1a4 > 15) c.aiTimer1a4 = 15;
        c.inputX = -1;
        return;
    }
    if (rnd(c, 0, 100) < 50 && dx < 120.0) {
        if (c.facing === 1) c.aiTimer1a4 = rnd(c, 0, 200) + 60;
        else c.aiTimer1a0 = rnd(c, 0, 200) + 60;
    }
    if (rnd(c, 0, 100) < 60) {
        if (c.facing === 1) c.aiTimer1a0 = rnd(c, 0, 200) + 30;
        else c.aiTimer1a4 = rnd(c, 0, 200) + 30;
        return;
    }
    if (c.facing === -1) c.aiTimer1a0 = rnd(c, 0, 200) + 30;
    else c.aiTimer1a4 = rnd(c, 0, 200) + 30;
}
function comboExNanase(c, dx) {
    const o = c.opponent;
    const roll = c.aiRoll;
    if (c.state === 200) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (dx < 40.0 && roll < 10) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 125.0 && roll > 100 && roll < 400) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 400 && roll < 440) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) c.aiMode = 6;
            if (c.d168 === 3 && rnd(c, 0, 3) === 0) c.aiMode = 12;
            return true;
        }
    }
    if (c.state === 201) {
        if (o.y < 0.0 && roll < 200 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (o.y < 0.0 && roll < 200 && c.d168 === 3) {
            c.inputX = c.facing;
            c.inputY = -1;
            return true;
        }
        if (o.y < 0.0 && roll > 320 && roll < 600 && dx < 100.0) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll < 200 && c.d168 === 3 && o.y === 0.0 && dx < 80.0) {
            c.command = 30;
            return true;
        }
        if (roll < 400 && c.d168 === 3 && o.y === 0.0 && dx < 80.0) {
            c.command = 10;
            return true;
        }
        if (roll < 350 && o.y === 0.0) {
            c.command = rnd(c, 0, 2) + 10;
            return true;
        }
        if (roll > 350 && roll < 550 && dx < 90.0) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (o.y < 0.0 && roll > 550 && roll < 700) {
            c.pressed[2] = 1;
            c.inputY = rnd(c, 0, 1) === 0 ? 1 : 0;
            return true;
        }
        if (roll > 920) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
                return true;
            }
        }
    }
    if (c.state === 202) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (roll < 100) {
            c.pressed[2] = 1;
            c.inputY = rnd(c, 0, 1) === 0 ? 1 : 0;
            return true;
        }
        if (roll > 100 && roll < 400 && c.d168 === 3) {
            c.command = 10;
            return true;
        }
        if (roll > 100 && roll < 300) {
            c.command = rnd(c, 0, 2) + 10;
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) {
                c.aiMode = 6;
                if (dx > 110.0) c.aiMode = 8;
                return true;
            }
        }
    }
    if (c.state === 203) {
        if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
        if (roll > 0 && roll < 400) {
            c.command = 70;
            return true;
        }
    }
    if (c.state === 204) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 40.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 1;
            return true;
        }
        if (dx < 50.0 && roll < 400) {
            c.pressed[0] = 1;
            c.inputY = 0;
            if (c.d168 === 2 && rnd(c, 0, 100) < 20) {
                c.pressed[2] = 1;
                c.inputY = 1;
            }
            return true;
        }
        if (dx < 135.0 && roll < 600) {
            c.pressed[1] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 950) {
            startJump(c);
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 1) === 0) c.aiMode = 5;
            return true;
        }
    }
    if (c.state === 205) {
        if (roll < 400 && dx < 80.0 && c.d168 === 3) {
            c.command = 10;
            return true;
        }
        if (roll < 100 && o.y === 0.0) {
            c.pressed[2] = 1;
            c.inputY = 1;
            return true;
        }
        if (roll > 300 && roll < 600) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 900) {
            startJump(c);
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            return true;
        }
    }
    if (c.state === 206) {
        if (roll > 0 && roll < 400) {
            c.command = 70;
            return true;
        }
        if (roll > 0 && roll < 300) {
            c.command = rnd(c, 0, 2) + 10;
            return true;
        }
        if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
        if (roll > 400 && roll < 450 && c.d168 === 3 && c.meter >= 1000 && dx < 90.0) {
            c.command = rnd(c, 0, 2) + 110;
            return true;
        }
        if (roll > 700) {
            c.aiMode = 1;
            return true;
        }
    }
    if (c.state === 207) {
        if (o.y < 0.0 && roll < 300) {
            c.pressed[1] = 1;
            return true;
        }
        if (dx < 60.0 && roll < 400) {
            c.pressed[0] = 1;
            return true;
        }
        if (dx < 125.0 && roll > 399 && roll < 700) {
            c.pressed[2] = 1;
            c.inputY = 0;
            return true;
        }
        if (roll > 699) {
            c.aiMode = 1;
            if (rnd(c, 0, 4) === 0) c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 208) {
        if (roll > 80 && roll < 300) {
            c.pressed[2] = 1;
            return true;
        }
        if (roll > 950) {
            c.inputX = s8(rnd(c, 0, 2) - 1);
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 209) {
        if (roll > 950) {
            c.inputX = s8(rnd(c, 0, 2) - 1);
            return true;
        }
        if (roll > 649) {
            c.aiMode = 3;
            return true;
        }
    }
    if (c.state === 231) {
        if (o.y < 0.0 && roll < 300 && c.d168 === 3) {
            c.command = rnd(c, 0, 2) + 20;
            return true;
        }
        if (roll > 0 && roll < 400) {
            c.command = 70;
            return true;
        }
        if (roll > 0 && roll < 200) {
            c.command = 10;
            return true;
        }
        if (roll > 350 && roll < 400 && c.rfGauge > 500.0) {
            c.command = 52;
            return true;
        }
        if (roll > 400 && roll < 700) {
            c.command = rnd(c, 0, 2) + 30;
            return true;
        }
        if (roll > 649 && rnd(c, 0, 3) === 0) {
            c.aiMode = 6;
            if (dx > 110.0) c.aiMode = 8;
        }
    }
    return false;
}
