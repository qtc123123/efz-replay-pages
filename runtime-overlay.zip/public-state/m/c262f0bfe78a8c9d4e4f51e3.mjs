import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { decompressMapped, imageDataOffset, createImage } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { parseCharacterPat } from "./fc9672cb87477a10c4e4290f.mjs";
import { exists, readSync } from "./197efe2647ca25903d217eb5.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { readRec, writeRec } from "./ad76ef61597c869da76b5edb.mjs";
import { BlendTable, blit, blitBlend, blitDistort, blitShadow, blitTint, loadPalette, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { playWave } from "./4bc01372141f4e276b2208f4.mjs";
import { readMask } from "./06124acd5a2cf7a08d774a8d.mjs";
import { GameMode, gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { GROUND_Y } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { WIN_QUOTE_PARAMS } from "./ed94471e7e2b500bb335f7ed.mjs";
export const CHILD_SLOTS = 64;
const AFTERIMAGE_LENGTH = 60;
export const HISTORY_LENGTH = 180;
export const NO_COMMAND = 0x63;
const VOICE_COUNT = 50;
const VOICE_VOLUME = -500;
export const WALL_LEFT = 20;
export const WALL_RIGHT = 619;
export const MAX_DISTANCE = 280;
function newChild() {
    return {
        pattern: 0,
        frame: 0,
        timer: 0,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        ax: 0,
        ay: 0,
        facing: 1,
        d4c: 0,
        blend: 0,
        layer: 0,
        fixed: 0,
        shadow: 0,
        clip: [
            0,
            0,
            0,
            0
        ],
        b6c: 0xff,
        dbl70: 0,
        dbl78: 0,
        hitState: 0,
        hitsLeft: 0,
        hitstop: 0,
        moveWhileFrozen: 0,
        drawWhileFrozen: 0
    };
}
export class Character {
    side;
    id;
    name;
    color = 0;
    opponent;
    state = 0;
    frame = 0;
    timer = 0;
    patterns = [];
    sprites = [];
    colorKey = 0;
    x = 0;
    y = 0;
    vx = 0;
    vy = 0;
    ax = 0;
    ay = 0;
    facing = 1;
    blend = 0;
    shadow = 1;
    isCPU = 0;
    aiLevel = 0;
    wins = 0;
    pushVelocity = 0;
    pushToOpponent = 0;
    knockX = 0;
    knockY = 0;
    d0d0 = 0;
    comboDisplay = 0;
    dblF8 = 10000;
    comboDamage = 0;
    comboTimer = 0;
    life = 9999;
    redLife = 9999;
    shownLife = 9999;
    rfGauge = 0;
    rfBlue = 0;
    hitstun = 0;
    d128 = 0;
    d12c = 0;
    b130 = 0;
    guardGauge = 0;
    w138 = 0;
    w13a = 0;
    w13c = 0;
    w13e = 0;
    w140 = 0;
    d144 = 0;
    meter = 0;
    hitstop = 0;
    freeze = 0;
    backWindow = 0;
    heldHorizontal = 0;
    b158 = 0;
    b159 = 0;
    b15a = 0;
    d15c = 0;
    d160 = 0;
    d168 = 0;
    w16c = 0;
    d170 = 0;
    comboCount = 0;
    proration = 10000;
    dbl180 = 1.0;
    inputX = 0;
    inputY = 0;
    pressed = [
        0,
        0,
        0,
        0
    ];
    held = [
        0,
        0,
        0,
        0
    ];
    bufferedA = 0;
    bufferedB = 0;
    bufferTimer = 0;
    history = new Uint8Array(HISTORY_LENGTH);
    historyIndex = 0;
    command = NO_COMMAND;
    voices = [];
    voiceRequest = 0xff;
    seRequest = 0xff;
    childHead = 0;
    childTail = 0;
    childType = new Int32Array(CHILD_SLOTS);
    childActive = new Int32Array(CHILD_SLOTS);
    children = Array.from({
        length: CHILD_SLOTS
    }, newChild);
    afterimage = {
        count: 0,
        step: 0,
        fade: 0,
        x: new Float64Array(AFTERIMAGE_LENGTH),
        y: new Float64Array(AFTERIMAGE_LENGTH),
        facing: new Int8Array(AFTERIMAGE_LENGTH),
        state: new Uint16Array(AFTERIMAGE_LENGTH),
        frame: new Uint16Array(AFTERIMAGE_LENGTH),
        index: 0
    };
    flashColor = 0;
    flashFrames = 0;
    darkenColor = 0;
    darkenFrames = 0;
    score = 0;
    scoreHigh = 0;
    hitCount = 0;
    maxCombo = 0;
    maxComboDamage = 0;
    lifeBonus = 0;
    d30e0 = 0;
    d30e4 = 0;
    loaded = 0;
    debugGauge = 0;
    debugLife = 0;
    cycle = 0;
    pointsX = [
        0,
        0,
        0,
        0,
        0
    ];
    pointsY = [
        0,
        0,
        0,
        0,
        0
    ];
    get winQuoteCount() {
        return WIN_QUOTE_PARAMS[this.id]?.[0] ?? 1;
    }
    winQuoteTarget(k) {
        return WIN_QUOTE_PARAMS[this.id]?.[1 + k] ?? 0xff;
    }
    clearAfterimage() {
        this.afterimage.count = 0;
        this.afterimage.fade = 0;
    }
    constructor(side, id, name){
        this.side = side;
        this.id = id;
        this.name = name;
    }
    currentFrame() {
        return this.patterns[this.state]?.frames[this.frame];
    }
    currentHit() {
        return this.patterns[this.state]?.hits[this.frame];
    }
    get paletteBase() {
        return 95 + 40 * this.side;
    }
    files() {
        const n = this.name;
        return [
            `${n}\\${n}.dat`,
            `${n}\\${n}.pat`,
            `${n}\\${n}${this.color + 1}.pal`,
            ...Array.from({
                length: VOICE_COUNT
            }, (_, i)=>this.voicePath(i))
        ];
    }
    voicePath(i) {
        return `${this.name}\\wave\\${String(i).padStart(2, "0")}.wav`;
    }
    load() {
        if (!this.loaded) {
            this.loadSprites();
            this.loadPatterns();
            this.loadVoices();
            this.loaded = 1;
        } else {
            this.loadPalette(false);
        }
        this.resetRound();
        this.countPlay();
    }
    countPlay() {
        if (this.isCPU !== 0) return;
        const mode = gs.mode;
        let count;
        if ((mode === GameMode.Arcade || mode === GameMode.Score) && gs.round === 1) count = true;
        else count = mode === GameMode.Practice || mode === GameMode.VsCom || mode === GameMode.VsPlayer;
        if (!count) return;
        const rec = readRec(this.name);
        rec[0] = rec[0] + 1;
        writeRec(this.name, rec);
    }
    loadSprites() {
        const path = `${this.name}\\${this.name}.dat`;
        const data = readSync(path);
        this.sprites = [];
        if (!data) {
            console.warn(`[character] 找不到檔案：${path}`);
            return;
        }
        let pos = imageDataOffset(data);
        while(pos + 4 <= data.length){
            const { image, consumed } = decompressMapped(data, pos, 0x80, this.paletteBase);
            this.sprites.push(image);
            pos += consumed;
        }
        this.loadPalette(true);
        this.colorKey = this.sprites[0]?.pixels[0] ?? 0;
    }
    loadPalette(first) {
        const dat = `${this.name}\\${this.name}.dat`;
        if (gs.usePal[this.side]) {
            const pal = `${this.name}\\${this.name}${this.color + 1}.pal`;
            if (!loadPalette(gs.palette, pal, 0, this.paletteBase, 40) && !first) {
                loadPalette(gs.palette, dat, 40 * this.color, this.paletteBase, 40);
            }
        } else {
            loadPalette(gs.palette, dat, 40 * this.color, this.paletteBase, 40);
        }
    }
    loadPatterns() {
        const data = readSync(`${this.name}\\${this.name}.pat`);
        this.patterns = data ? parseCharacterPat(data) : [];
    }
    loadVoices() {
        this.voices = Array.from({
            length: VOICE_COUNT
        }, (_, i)=>this.voicePath(i));
    }
    playVoice(i) {
        const path = this.voices[i];
        if (path) playWave(path, VOICE_VOLUME);
    }
    hasVoice(i) {
        const path = this.voices[i];
        return path !== undefined && exists(path);
    }
    resetRound() {
        this.x = 240 + 160 * this.side;
        this.y = 0;
        this.facing = 1 - 2 * this.side;
        this.vx = this.vy = this.ax = this.ay = this.pushToOpponent = 0;
        this.pushVelocity = 0;
        this.d0d0 = 0;
        this.state = this.frame = this.timer = 0;
        this.flashFrames = this.darkenFrames = 0;
        this.life = this.redLife = this.shownLife = 9999;
        this.meter = 0;
        this.rfGauge = 0;
        this.rfBlue = 0;
        this.freeze = 0;
        this.b159 = this.b158 = this.b15a = 0;
        this.backWindow = 0;
        this.heldHorizontal = 0;
        this.wins = 0;
        this.w138 = this.w13a = this.w13c = this.w13e = this.w140 = 0;
        this.d15c = this.d160 = this.d168 = 0;
        this.hitstop = 0;
        this.guardGauge = 0;
        this.comboCount = 0;
        this.comboDisplay = 0;
        this.comboTimer = 0;
        this.proration = 10000;
        this.dblF8 = 10000;
        this.d170 = 0;
        this.dbl180 = 1.0;
        this.bufferedA = this.bufferedB = 0;
        this.command = NO_COMMAND;
        this.historyIndex = 0;
        this.history.fill(0);
        this.voiceRequest = this.seRequest = 0xff;
        this.childHead = this.childTail = 0;
        this.childActive.fill(0);
        this.childType.fill(0);
        this.afterimage.index = 0;
        this.afterimage.count = this.afterimage.fade = 0;
        this.cycle = 0;
        this.debugGauge = 0;
        this.blend = 0;
        this.shadow = 1;
        this.lifeBonus = this.maxCombo = this.maxComboDamage = 0;
    }
    groundMovement() {
        this.neutralMovement();
    }
    onStateChange() {
        this.frame = 0;
        this.timer = 0;
        this.pushToOpponent = 0;
        this.d168 = 0;
        this.d170 = 0;
        this.afterimage.fade = this.afterimage.count * 3;
        this.afterimage.count = 0;
    }
    setState(state) {
        this.onStateChange();
        this.state = state;
    }
    faceOpponent() {
        const old = this.facing;
        if (this.x < this.opponent.x) this.facing = 1;
        else if (this.x > this.opponent.x) this.facing = -1;
        else return false;
        return this.facing !== old;
    }
    isGuarding() {
        return this.state >= 150 && this.state <= 156 || this.state >= 168 && this.state <= 171;
    }
    isBeingHit() {
        const o = this.opponent.state;
        return this.state >= 50 && this.state < 150 && !(o >= 0x60 && o <= 0x63);
    }
    isReadyPose() {
        return this.state >= 0xa3 && this.state <= 0xa6;
    }
    wallBlock() {
        const o = this.opponent;
        if (this.x - WALL_LEFT <= (o.x <= WALL_LEFT ? 1 : 0) || o.x - this.x > MAX_DISTANCE) return 1;
        if (this.x + 20 >= 639 - (o.x >= WALL_RIGHT ? 1 : 0) || this.x - o.x > MAX_DISTANCE) return -1;
        return 0;
    }
    isHeld(k) {
        return this.held[k] ?? 0;
    }
    requestFlash(color, frames) {
        this.flashColor = color;
        this.flashFrames = gs.option0 === 0 ? Math.trunc(frames / 2) : frames;
    }
    clearInputHistory() {
        this.history.fill(0);
        this.command = NO_COMMAND;
    }
    childFrame(i) {
        const c = this.children[i];
        const p = this.patterns[c.pattern];
        return {
            frame: p?.frames[c.frame],
            hit: p?.hits[c.frame]
        };
    }
    random(lo, hi) {
        let r = rand("src/game/character.ts:648:10", {
            consumer: "Character.random"
        }) & 0xffff;
        if (gs.replayMode === 1) r = gs.replayFile.readWord() & 0xffff;
        else if (gs.replayMode === 2) gs.replayFile.writeWord(r);
        return lo + Math.trunc((hi - lo) * r / 32768) << 16 >> 16;
    }
    readInput() {
        if (this.isCPU) {
            if (gs.mode === GameMode.Practice) {
                this.pressed.fill(0);
                this.inputX = 0;
                this.inputY = gs.practiceDummyStance === 1 ? -1 : gs.practiceDummyStance === 2 ? 1 : 0;
                return;
            }
            this.think();
            if (gs.introState || gs.roundOver) {
                this.pressed.fill(0);
                this.command = NO_COMMAND;
            }
            return;
        }
        let raw = readMask(this.side);
        if (gs.replayMode === 1) raw = gs.replayFile.readWord() & 0xff;
        else if (gs.replayMode === 2) gs.replayFile.writeWord(raw & 0xff);
        this.inputX = 0;
        this.inputY = 0;
        this.pressed.fill(0);
        if (raw & 8) this.inputY = -1;
        else if (raw & 4) this.inputY = 1;
        if (this.facing > 0) {
            if (raw & 2) this.inputX = -1;
            else if (raw & 1) this.inputX = 1;
        } else {
            if (raw & 1) this.inputX = 1;
            else if (raw & 2) this.inputX = -1;
        }
        for(let k = 0; k < 4; k++){
            const on = (raw & 0x10 << k) !== 0;
            this.pressed[k] = on && !this.held[k] ? 1 : 0;
            this.held[k] = on ? 1 : 0;
        }
        if (gs.introState || gs.roundOver) {
            this.pressed.fill(0);
            this.command = NO_COMMAND;
        }
        const code = (this.inputX === 1 ? 1 : 0) | (this.inputX === -1 ? 2 : 0) | (this.inputY === 1 ? 4 : 0) | (this.inputY === -1 ? 8 : 0) | this.pressed[0] << 4 | this.pressed[1] << 5 | this.pressed[2] << 6 | this.pressed[3] << 7;
        this.history[this.historyIndex] = code;
        if (code >= 0x10) {
            if (this.state >= 200) this.bufferedA = code;
            if (this.state >= 0xa3 && this.state <= 0xa6) {
                this.bufferedB = code;
                this.bufferTimer = 15;
            }
        }
        if (++this.historyIndex >= HISTORY_LENGTH) this.historyIndex = 0;
        const d = this.opponent.x - this.x > 0 ? 1 : 0;
        if (this.inputX === 1 - 2 * d && !this.backWindow && !this.heldHorizontal) this.backWindow = 60;
        if (this.opponent.hitstop === 0 && this.backWindow > 0) this.backWindow--;
        this.heldHorizontal = this.inputX !== 0 ? 1 : 0;
        this.parseCommand();
    }
    preTick() {
        const o = this.opponent;
        if (this.hitstop !== 0 || o.freeze !== 0) return;
        if (!(this.state >= 50 && this.state <= 150) || this.state === 0x60) {
            this.hitstun = 0;
            this.d12c = 0;
            o.comboCount = 0;
            o.proration = o.proration > 10000 ? o.proration - 20 : 10000;
        }
        if (this.state < 50) {
            this.groundMovement();
            this.pushToOpponent = 0;
            o.pushToOpponent = 0;
            if (this.debugGauge && o.state < 50) {
                this.meter = 3000;
                this.life = this.debugLife << 16 >> 16;
                if (this.debugGauge > 0) {
                    if (this.debugGauge < 1000) {
                        this.rfGauge = this.debugGauge;
                        this.rfBlue = 0;
                    } else {
                        this.rfGauge = 2000 - this.debugGauge;
                        this.rfBlue = 1;
                    }
                }
            }
        }
        if (this.state >= 50 && this.state < 150 && this.guardGauge <= 0.0 && !((this.currentHit()?.attackFlags ?? 0) & 0x400)) {
            this.airRecovery();
        }
        this.dispatchMoves();
    }
    airRecovery() {
        if (this.hitstun > 0) {
            this.hitstun--;
            return;
        }
        if (this.y < 0 && this.d128 === 0 && this.pressed.some((v)=>v)) {
            const target = this.inputX === this.facing ? 0x9d : this.inputX === -this.facing ? 0x9e : -1;
            if (target >= 0) {
                if (this.state !== target) this.onStateChange();
                this.state = target;
            }
        }
    }
    neutralMovement() {
        if (this.y === 0) this.b159 = this.b15a = 0;
        if (this.y < 0 || [
            4,
            5,
            6,
            10,
            11,
            12
        ].includes(this.state)) return;
        const change = (s)=>{
            if (this.state !== s) {
                this.onStateChange();
                this.state = s;
            }
        };
        if (this.d15c < 3 && this.inputY === -1) {
            this.faceOpponent();
            if (this.command === 3 || this.command === 4 || this.command === 5) change(this.command + 7);
            else if (this.inputX === 0) change(4);
            else if (this.inputX === this.facing) change(5);
            else change(6);
            return;
        }
        if (this.inputY === 1) {
            if (this.state !== 8 && this.state !== 3) {
                this.state = 8;
                this.onStateChange();
                this.faceOpponent();
            } else if (this.state === 3) {
                this.faceOpponent();
            }
        } else if (this.inputX !== 0) {
            this.faceOpponent();
            change(this.inputX === this.facing ? 1 : 2);
        } else if (this.state === 3 || this.state === 8) {
            this.state = 7;
            this.faceOpponent();
            this.onStateChange();
        } else if (this.state === 7 || this.state === 13) {
            this.faceOpponent();
        } else {
            change(0);
            this.faceOpponent();
        }
    }
    integrate() {
        const o = this.opponent;
        if (this.hitstop === 0 && o.freeze === 0) {
            const e = o.d0d0 !== 0 && this.freeze === 0 ? 1 : 0;
            const v = this.vx + this.pushVelocity + e * o.pushToOpponent;
            if (this.wallBlock() * this.facing * v >= 0) this.x += v * this.facing;
            const left = WALL_LEFT + (o.wallBlock() === 1 && o.x <= WALL_LEFT ? 1 : 0);
            if (this.x < left) {
                this.x = left;
            } else {
                const right = WALL_RIGHT - (o.wallBlock() === -1 && o.x >= WALL_RIGHT ? 1 : 0);
                if (this.x > right) this.x = right;
            }
            this.y += this.vy;
            if (this.y > 0) this.y = 0;
        }
        for(let j = this.childTail; j !== this.childHead; j = (j + 1) % CHILD_SLOTS){
            const c = this.children[j];
            if (!this.childActive[j]) continue;
            if (this.freeze > 0 && c.moveWhileFrozen === 0) continue;
            if (c.hitstop !== 0 || o.freeze !== 0) continue;
            c.x += (0.0 * c.dbl70 + c.vx) * c.facing;
            c.y += c.vy;
        }
    }
    tickTimers() {
        const o = this.opponent;
        if (o.freeze <= 0) {
            this.hitstop = Math.max(this.hitstop - 1, 0);
            if (!this.isGuarding()) {
                this.guardGauge -= this.isBeingHit() ? 1 / (4 * (this.y === 0 ? 1 : 0) + 1) : Math.fround(0.075);
                this.guardGauge = Math.fround(this.guardGauge);
                if (this.guardGauge < 0) this.guardGauge = 0;
            }
            this.b130 = Math.max(this.b130 - 1, 0);
            if ((this.currentHit()?.defenseFlags ?? 0) & 0x40) this.b130 = 27;
            this.w138 = Math.max(this.w138 - 1, 0);
            this.w13a = Math.max(this.w13a - 1, 0);
            this.w13c = Math.max(this.w13c - 1, 0);
            this.w13e = Math.max(this.w13e - 1, 0);
            this.w140 = Math.max(this.w140 - 1, 0);
            const k1 = !this.isBeingHit() && this.rfBlue === 0 ? 1 : 0;
            const k2 = this.rfGauge < 500 ? 1 : 0;
            this.rfGauge += ((this.isGuarding() ? 1 : 0) + 1) * k1 * (2 * k2 + 1) / 10.0;
            if (this.rfGauge >= 1000 && this.rfBlue === 0) {
                this.rfBlue = 1;
                this.rfGauge = 1000;
            } else if (this.rfGauge <= 0) {
                this.rfBlue = 0;
                this.rfGauge = 0;
            }
            for(let j = this.childTail; j !== this.childHead; j = (j + 1) % CHILD_SLOTS){
                if (this.childActive[j]) this.children[j].hitstop = Math.max(this.children[j].hitstop - 1, 0);
            }
            if (o.isBeingHit()) {
                this.d30e4 = 900;
                this.d30e0 = 12;
            }
            if ((o.state < 50 || o.state >= 200) && !gs.introState && !gs.roundOver) {
                if (this.d30e4) {
                    this.d30e4--;
                } else {
                    if (this.d30e0 > 1) this.d30e0--;
                    if (this.hitCount) this.hitCount--;
                    this.d30e4 = this.d30e0 * 15;
                }
            }
        }
        this.meter = Math.min(Math.max(this.meter, 0), 3000);
        this.rfGauge = Math.min(Math.max(this.rfGauge, 0), 1000);
        if (--this.cycle <= 0) this.cycle = 12600;
        if (this.comboTimer > 0 && this.comboCount === 0) this.comboTimer--;
    }
    spawnChild(t) {
        const i = this.childHead;
        this.childType[i] = t.type;
        this.childActive[i] = 1;
        const c = this.children[i];
        Object.assign(c, newChild(), {
            pattern: t.pattern,
            x: t.x,
            y: t.y,
            facing: t.facing,
            d4c: t.d4c ?? 0,
            blend: t.blend ?? 0,
            layer: t.layer ?? 0,
            fixed: t.fixed ?? 0,
            shadow: t.shadow ?? 0,
            b6c: t.b6c ?? 0xff,
            moveWhileFrozen: t.moveWhileFrozen ?? 0,
            clip: t.clip ?? [
                0,
                0,
                0,
                0
            ]
        });
        let n = 0;
        do {
            this.childHead = (this.childHead + 1) % CHILD_SLOTS;
            if (this.childHead === this.childTail) {
                this.childTail = (this.childTail + 1) % CHILD_SLOTS;
                this.skipInactiveTail();
            }
            n++;
        }while (this.childType[this.childHead] !== 0 && n < CHILD_SLOTS - 1)
        return i;
    }
    freeChild(i) {
        this.childActive[i] = 0;
        this.childType[i] = 0;
        if (i === this.childTail) this.skipInactiveTail();
    }
    skipInactiveTail() {
        while(this.childTail !== this.childHead && !this.childActive[this.childTail]){
            this.childTail = (this.childTail + 1) % CHILD_SLOTS;
        }
    }
    sampleAfterimage() {
        if (this.opponent.freeze !== 0) return;
        const a = this.afterimage;
        if (a.count) {
            a.step = a.count;
            a.x[a.index] = this.x;
            a.y[a.index] = this.y;
            a.facing[a.index] = this.facing;
            a.state[a.index] = this.state;
            a.frame[a.index] = this.frame;
            a.index = (a.index + 1) % AFTERIMAGE_LENGTH;
            a.fade = 0;
        } else if (a.fade > 0) {
            a.fade--;
        }
    }
    startAfterimage(n) {
        const a = this.afterimage;
        if (a.count === 0 && a.fade === 0) {
            for(let i = 0; i < AFTERIMAGE_LENGTH; i++){
                a.x[i] = this.x;
                a.y[i] = this.y;
                a.facing[i] = this.facing;
                a.state[i] = this.state;
                a.frame[i] = this.frame;
            }
        }
        a.count = n & 0xff;
        a.step = n & 0xff;
    }
    stopMotion() {
        this.vx = this.vy = this.ax = this.ay = 0;
        this.pushToOpponent = 0;
    }
    superDarken(color, frames) {
        this.darkenColor = color & 0xff;
        this.darkenFrames = gs.option0 === 0 ? Math.trunc(frames / 2) : frames;
        gs.darkenSide = this.side;
    }
    shakeScreen(amp, hold) {
        gs.shakeAmp = amp;
        gs.shakeHold = hold;
    }
    biasCamera(v, frames) {
        gs.cameraBias = (1 - 2 * this.side) * v;
        gs.cameraBiasFrames = frames;
    }
    biasCameraY(v, frames) {
        gs.cameraYBias = (1 - 2 * this.side) * v;
        gs.cameraYBiasFrames = frames;
    }
    showAltBackground(frames) {
        gs.bgbFrames = gs.option0 === 0 ? Math.trunc(frames / 2) : frames;
    }
    screenFlash(mode, fadeIn, hold, fadeOut) {
        gs.flashMode = mode;
        gs.flashIn = fadeIn;
        gs.flashHold = hold;
        gs.flashOut = fadeOut;
    }
    screenRect(f, x, y, facing, camX, camY) {
        const left = Math.trunc(x) + camX - (facing === 1 ? f.offsetX : f.width - f.offsetX);
        const top = Math.trunc(y) + GROUND_Y - (y < 0 ? 1 : 0) + camY - f.offsetY;
        return {
            left,
            top
        };
    }
    draw(camX, camY) {
        const a = this.afterimage;
        if (a.count || a.fade) {
            const n = a.count * 3 + a.fade;
            let s = a.index - n;
            const step = Math.max(a.step, 1);
            for(let i = 0; i < n; i += step){
                s = (s % AFTERIMAGE_LENGTH + AFTERIMAGE_LENGTH) % AFTERIMAGE_LENGTH;
                const f = this.patterns[a.state[s]]?.frames[a.frame[s]];
                const surf = f && this.sprites[f.sprite];
                if (f && surf) {
                    const { left, top } = this.screenRect(f, a.x[s], a.y[s], a.facing[s], camX, camY);
                    blitBlend(makeRect(left, top, f.width, f.height), surf, makeRect(0, 0, f.width, f.height), this.colorKey, a.facing[s] === -1, BlendTable.Average);
                }
                s += step;
            }
        }
        const f = this.currentFrame();
        const surf = f && this.sprites[f.sprite];
        if (!f || !surf) return;
        const { left, top } = this.screenRect(f, this.x, this.y, this.facing, camX, camY);
        const flip = this.facing === -1;
        const src = makeRect(0, 0, f.width, f.height);
        const dst = makeRect(left, top, f.width, f.height);
        if (top >= 240) {
            if (this.w13e === 0) {
                const g = this.patterns[49]?.frames[0];
                const gs2 = g && this.sprites[g.sprite];
                if (g && gs2) {
                    const l = Math.trunc(this.x) + camX - (this.facing === 1 ? g.offsetX : g.width - g.offsetX);
                    blit(makeRect(l, 239 - g.offsetY, g.width, g.height), gs2, makeRect(0, 0, g.width, g.height), this.colorKey, flip);
                }
            }
            return;
        }
        if (this.flashFrames !== 0) {
            blitTint(dst, surf, src, this.colorKey, flip, this.flashColor);
            this.flashFrames--;
        } else if (this.blend === 3) {
            blitDistort(dst, surf, src, this.colorKey, flip);
        } else if (this.blend > 0) {
            blitBlend(dst, surf, src, this.colorKey, flip, this.blend === 1 ? BlendTable.Average : BlendTable.Add);
        } else {
            blit(dst, surf, src, this.colorKey, flip);
        }
    }
    drawShadow(camX, camY) {
        if (!this.shadow) return;
        const f = this.currentFrame();
        const surf = f && this.sprites[f.sprite];
        if (!f || !surf) return;
        this.drawShadowOf(f, surf, this.x, this.y, this.facing, camX, camY, true);
        for(let j = this.childTail; j !== this.childHead; j = (j + 1) % CHILD_SLOTS){
            const c = this.children[j];
            if (!this.childActive[j] || !c.shadow) continue;
            if (!c.drawWhileFrozen && gs.specialTimerE !== 0) continue;
            const cf = this.patterns[c.pattern]?.frames[c.frame];
            const cs = cf && this.sprites[cf.sprite];
            if (cf && cs) this.drawShadowOf(cf, cs, c.x, c.y, c.facing, camX, camY, false);
        }
    }
    drawShadowOf(f, surf, x, y, facing, camX, camY, isBody) {
        const sh = f.offsetY < f.height ? f.offsetY : f.height;
        const adj = f.offsetY < f.height ? 0 : f.offsetY - f.height;
        const neg = isBody && y < 0 ? 1 : 0;
        const top = GROUND_Y - (Math.trunc(y) - neg) + camY + adj;
        const bottom = top + Math.trunc(sh / 3);
        if (!(top < 240 && bottom > 0)) return;
        const left = isBody ? Math.trunc(x) + camX - (facing === 1 ? f.offsetX : 0) - (facing === -1 ? f.width - f.offsetX : 0) : Math.trunc(x) + camX - (facing === -1 ? f.width - f.offsetX : f.offsetX);
        blitShadow({
            left,
            top,
            right: left + f.width,
            bottom
        }, surf, makeRect(0, 0, f.width, sh), this.colorKey, facing === -1, 0xb0);
    }
    drawChildren(camX, camY, layer) {
        for(let j = this.childTail; j !== this.childHead; j = (j + 1) % CHILD_SLOTS){
            const c = this.children[j];
            if (!this.childActive[j] || c.layer !== layer) continue;
            if (!c.drawWhileFrozen && gs.specialTimerE !== 0) continue;
            const f = this.patterns[c.pattern]?.frames[c.frame];
            const surf = f && this.sprites[f.sprite];
            if (!f || !surf) continue;
            const ss = c.fixed === 0 ? 1 : 0;
            const flip = c.facing === -1;
            const left = Math.trunc(c.x) + ss * camX - (flip ? f.width - f.offsetX : f.offsetX);
            const top = ss * (camY + GROUND_Y) + Math.trunc(c.y) - f.offsetY;
            let dst = makeRect(left, top, f.width, f.height);
            let src = makeRect(0, 0, f.width, f.height);
            const [cl, ct, cr, cb] = c.clip;
            if (ct !== cb) {
                const nl = Math.max(dst.left, cl);
                const nt = Math.max(dst.top, ct);
                const nr = Math.min(dst.right, cr);
                const nb = Math.min(dst.bottom, cb);
                src = {
                    left: src.left + (nl - dst.left),
                    top: src.top + (nt - dst.top),
                    right: src.right - (dst.right - nr),
                    bottom: src.bottom - (dst.bottom - nb)
                };
                dst = {
                    left: nl,
                    top: nt,
                    right: nr,
                    bottom: nb
                };
            }
            if (c.blend === 3) blitDistort(dst, surf, src, this.colorKey, flip);
            else if (c.blend > 0) blitBlend(dst, surf, src, this.colorKey, flip, c.blend === 1 ? BlendTable.Average : BlendTable.Add);
            else blit(dst, surf, src, this.colorKey, flip);
        }
    }
    static EMPTY = createImage(0, 0);
}

export function __logicState(){return {VOICE_VOLUME};}

export function __installInitialRoots(s){
if(VOICE_VOLUME!==s["VOICE_VOLUME"])throw Error('INITIAL_CONST_IDENTITY:VOICE_VOLUME');
}
