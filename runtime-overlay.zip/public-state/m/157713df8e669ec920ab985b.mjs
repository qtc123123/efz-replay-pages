import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./4fd020f21e3ef9d96dc087c0.mjs";
import { frameChild, openSpawnFrame, updateChildrenMinagi } from "./b1bf50e501f736bc8b07bfdb.mjs";
import { parseCommandMinagi, dispatchMovesMinagi } from "./7ee188755a5bff129e6ae2d7.mjs";
import { thinkMinagi } from "./d9af6645b151f36374eaf6f4.mjs";
import { ftol } from "./7596266716c972d06fe8897a.mjs";
import "./08ef43e1c38fa65b0fb10168.mjs";
import "./50d284ee8e64b4fbd9451226.mjs";
import "./28d5940e9eae934d66052f96.mjs";
import "./a53cd0c32891bfccbe2f782a.mjs";
const CTOR_POINTS_X = [
    -8,
    -19,
    3,
    9,
    35
];
const CTOR_POINTS_Y = [
    -66,
    0,
    -7,
    -2,
    -37
];
const RESET_POINTS_X = [
    -13,
    14,
    17,
    7,
    27
];
const RESET_POINTS_Y = [
    -60,
    0,
    -6,
    -25,
    -25
];
export class Minagi extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    a3154 = new Int32Array(64);
    a3254 = new Int32Array(64);
    a3354 = new Int32Array(64);
    pointsX = [
        ...CTOR_POINTS_X
    ];
    pointsY = [
        ...CTOR_POINTS_Y
    ];
    params = [
        8,
        1,
        0,
        0xb,
        0x18,
        2,
        0x13,
        0x17,
        0xff,
        0xff,
        0xff,
        7
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = 0;
        this.f314c = 0;
        this.f3150 = 0;
        for(let k = 0; k < 5; k++){
            this.pointsX[k] = RESET_POINTS_X[k];
            this.pointsY[k] = RESET_POINTS_Y[k];
        }
        this.a3154.fill(0);
        this.a3254.fill(0);
        this.a3354.fill(0);
        super.resetRound();
        const f = openSpawnFrame();
        f.w04 = 0x190;
        f.x = ftol(this.x) - this.facing * 0x28;
        f.y = ftol(this.y);
        f.b20 = 0;
        f.d24 = 0;
        f.b21 = 0;
        f.d28 = 1;
        f.d00 = 1;
        f.b18 = this.facing;
        frameChild(this, f);
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3154[i] = 0;
        this.a3254[i] = 0;
        this.a3354[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {}
    tickHook() {}
    parseCommand() {
        parseCommandMinagi(this);
    }
    dispatchMoves() {
        dispatchMovesMinagi(this);
    }
    think() {
        thinkMinagi(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenMinagi(this);
    }
}

export function __logicState(){return {CTOR_POINTS_X,CTOR_POINTS_Y,RESET_POINTS_X,RESET_POINTS_Y};}

export function __installInitialRoots(s){
if(CTOR_POINTS_X!==s["CTOR_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_X');
if(CTOR_POINTS_Y!==s["CTOR_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:CTOR_POINTS_Y');
if(RESET_POINTS_X!==s["RESET_POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_X');
if(RESET_POINTS_Y!==s["RESET_POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:RESET_POINTS_Y');
}
