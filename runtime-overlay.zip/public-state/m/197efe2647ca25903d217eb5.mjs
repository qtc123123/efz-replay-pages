import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
const files = new Map();
const cache = new Map();
export function normalizePath(path) {
    return path.replace(/\\/g, "/").replace(/^\.?\/+/, "").toLowerCase();
}
export function mountFiles(list) {
    files.clear();
    cache.clear();
    const entries = [
        ...list
    ].map((e)=>({
            path: normalizePath(e.path),
            file: e.file
        }));
    const root = findGameRoot(entries.map((e)=>e.path));
    for (const e of entries){
        if (!e.path.startsWith(root)) continue;
        files.set(e.path.slice(root.length), e.file);
    }
}
function findGameRoot(paths) {
    let best = null;
    for (const p of paths){
        const m = /^(.*?)(?:efz\.exe|system\/title\.dat)$/.exec(p);
        if (m && (best === null || m[1].length < best.length)) best = m[1];
    }
    return best ?? "";
}
export function fileCount() {
    return files.size;
}
export function mountedFiles() {
    return [
        ...files
    ].map(([path, file])=>({
            path,
            file
        }));
}
export function exists(path) {
    const present=files.has(normalizePath(path)); __session.resourceDecision?.({path:normalizePath(path),present}); return present;
}
export function list(dir) {
    const prefix = normalizePath(dir).replace(/\/?$/, "/");
    return [
        ...files.keys()
    ].filter((p)=>p.startsWith(prefix));
}
export async function preload(paths) {
    await Promise.all(paths.map(async (path)=>{
        const key = normalizePath(path);
        if (cache.has(key)) return;
        const file = files.get(key);
        if (!file) return;
        cache.set(key, new Uint8Array(await file.arrayBuffer()));
    }));
}
export function readSync(path) {
    return cache.get(normalizePath(path)) ?? null;
}
export async function read(path) {
    await preload([
        path
    ]);
    return readSync(path);
}
export function evict(path) {
    cache.delete(normalizePath(path));
}

export function __logicState(){return {files,cache};}
