import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
const hasWritable = typeof FileSystemFileHandle !== "undefined" && "createWritable" in FileSystemFileHandle.prototype;
export function canWriteOpfs() {
    return typeof navigator !== "undefined" && !!navigator.storage?.getDirectory && (hasWritable || typeof Worker !== "undefined");
}
let worker = null;
let nextId = 0;
const pending = new Map();
function getWorker() {
    if (!worker) {
        worker = new Worker(new URL("./opfs_write.worker.ts", import.meta.url));
        worker.addEventListener("message", (e)=>{
            const job = pending.get(e.data.id);
            if (!job) return;
            pending.delete(e.data.id);
            if (e.data.error) job.reject(new Error(e.data.error));
            else job.resolve();
        });
    }
    return worker;
}
export async function writeOpfsFile(path, data) {
    const blob = typeof data === "string" ? new Blob([
        data
    ]) : data;
    if (hasWritable) {
        let dir = await navigator.storage.getDirectory();
        for (const name of path.slice(0, -1))dir = await dir.getDirectoryHandle(name, {
            create: true
        });
        const handle = await dir.getFileHandle(path[path.length - 1], {
            create: true
        });
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        return;
    }
    const id = nextId++;
    await new Promise((resolve, reject)=>{
        pending.set(id, {
            resolve,
            reject
        });
        getWorker().postMessage({
            id,
            path,
            data: blob
        });
    });
}

export function __logicState(){return {hasWritable,worker,nextId,pending};}
