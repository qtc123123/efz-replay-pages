import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
export function frameDuration(c) {
    return c.patterns[c.state]?.frames[c.frame]?.duration ?? 0;
}
export function frameCount(c) {
    return c.patterns[c.state]?.count ?? 0;
}
export function childFrameDuration(c, i) {
    const ch = c.children[i];
    return c.patterns[ch.pattern]?.frames[ch.frame]?.duration ?? 0;
}
export function childFrameCount(c, i) {
    return c.patterns[c.children[i].pattern]?.count ?? 0;
}
export const ftol = Math.trunc;
export const s16 = (v)=>v << 16 >> 16;
export const s8 = (v)=>v << 24 >> 24;

export function __logicState(){return {ftol};}

export function __installInitialRoots(s){
if(ftol!==s["ftol"])throw Error('INITIAL_CONST_IDENTITY:ftol');
}
