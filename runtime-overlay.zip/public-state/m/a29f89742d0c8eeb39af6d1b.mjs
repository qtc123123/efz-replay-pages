import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./98eccc84a6920bb332239618.mjs";
import { registerChildren, registerStates } from "./4ab9307bcb6cd4f39f8feacd.mjs";
import { frameCount, frameDuration, s16 } from "./7596266716c972d06fe8897a.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
function rfCost(c) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
}
function effect21(c, f) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function effect1f(c, f) {
    f.w04 = 0x1f;
    f.x = Math.trunc(c.x);
    f.y = 0.0;
    f.b20 = 0;
    f.b21 = 0;
    f.d1c = c.facing - 1 !== 0 ? 1 : 0;
    frameEffect(f);
}
function endToNeutral(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function throwShard(c, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.meter = s16(c.meter + 0x2d);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 3) {
            f.w04 = pattern;
            f.x = Math.trunc(c.x) + c.facing * 0x17;
            f.y = Math.trunc(c.y) - 0x4c;
            f.b20 = 0;
            f.d00 = 1;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
            c.seRequest = 0x15;
            c.voiceRequest = 5;
        }
        endToNeutral(c, cnt);
    }
}
function state250(c) {
    throwShard(c, 0x193);
}
function state251(c) {
    throwShard(c, 0x194);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.meter = s16(c.meter + 0x2d);
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 3) {
        f.w04 = 0x195;
        f.x = Math.trunc(c.x) + c.facing * 0x17;
        f.y = Math.trunc(c.y) - 0x4c;
        f.b20 = 0;
        f.d00 = 1;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        c.seRequest = 0x15;
        c.voiceRequest = 5;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 3) {
            f.w04 = 0x195;
            f.x = Math.trunc(c.x) + c.facing * 0x17;
            f.y = Math.trunc(c.y) - 0x4c;
            f.b20 = 0;
            f.d00 = 1;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
            c.seRequest = 0x15;
        }
        endToNeutral(c, cnt);
    }
}
function spawnRoller(c, f, pattern) {
    f.w04 = pattern;
    f.x = Math.trunc(c.x) + c.facing * 0x11;
    f.y = Math.trunc(c.y) - 0x1a;
    f.b20 = 0;
    f.d00 = 1;
    f.b21 = 1;
    f.b18 = c.facing;
    f.d28 = 1;
    frameChild(c, f);
    c.seRequest = 0x15;
}
function roller(c, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.meter = s16(c.meter + 0x2d);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 4) spawnRoller(c, f, pattern);
        endToNeutral(c, cnt);
    }
}
function state253(c) {
    roller(c, 0x196);
}
function state254(c) {
    roller(c, 0x197);
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.meter = s16(c.meter + 0x2d);
        rfCost(c);
        effect21(c, f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 4) spawnRoller(c, f, 0x198);
        endToNeutral(c, cnt);
    }
}
function jumpPhysics(c) {
    if (c.frame > 1) {
        c.vy = c.vy + c.ay;
        c.vx = c.vx - 0.045;
        if (c.vx < 0.0) c.vx = 0.0;
    }
}
function landAt(c, from, to) {
    if (c.frame < to && c.frame > from && c.vy + c.y > 0.0) {
        c.frame = to;
        c.timer = 0;
        c.y = 0.0;
        c.stopMotion();
        return true;
    }
    return false;
}
function takeOff(c, f, vx, vy) {
    c.vx = vx;
    c.vy = vy;
    c.ay = 0.05;
    effect1f(c, f);
}
function attackStart(c) {
    c.seRequest = 0x15;
    c.w16c = 1;
    c.meter = s16(c.meter + 0x1e);
}
function hop(c, jumpVy) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    jumpPhysics(c);
    if (landAt(c, 1, 8)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 1) takeOff(c, f, 1.5, jumpVy);
        if (c.frame === 3) attackStart(c);
        endToNeutral(c, cnt);
    }
}
function state256(c) {
    hop(c, -1.5);
}
function state257(c) {
    hop(c, -1.8);
}
function state258(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        rfCost(c);
        effect21(c, f);
    }
    jumpPhysics(c);
    if (landAt(c, 1, 8)) return;
    if (landAt(c, 12, 19)) return;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 1) takeOff(c, f, 0.9, -1.0);
        if (c.frame === 3) attackStart(c);
        if (c.frame === 12) {
            c.vx = 1.4;
            c.vy = -2.9;
            c.ay = 0.05;
            c.d168 = 0;
            effect1f(c, f);
        }
        if (c.frame === 13) attackStart(c);
        endToNeutral(c, cnt);
    }
}
function spawnBall(c, f, pattern, dx, face402) {
    f.w04 = pattern;
    f.x = Math.trunc(c.x) + dx;
    f.y = Math.trunc(c.y) - 0x4e;
    f.b18 = c.facing;
    f.b21 = 1;
    f.d00 = 1;
    f.b20 = 2;
    frameChild(c, f);
    f.w04 = 0x192;
    f.x = Math.trunc(c.x) + dx;
    f.y = Math.trunc(c.y) - 0x4e;
    f.b18 = face402;
    f.b21 = 1;
    f.b20 = 2;
    frameChild(c, f);
    c.voiceRequest = 0;
    c.f3148 = 1;
}
function ballAdvance(c, dur, cnt) {
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state259(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame === 4 && c.timer === 0) spawnBall(c, f, 0x19a, c.facing * 0x24, c.facing);
    ballAdvance(c, dur, cnt);
}
function state260(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
    }
    if (c.frame === 4 && c.timer === 0) spawnBall(c, f, 0x19b, -(c.facing * 0x24), -c.facing);
    ballAdvance(c, dur, cnt);
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 4 && c.timer === 0) spawnBall(c, f, 0x19c, c.facing * 0x24, c.facing);
    ballAdvance(c, dur, cnt);
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = c.vx * 0.25;
        c.vy = c.vy * 0.25;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame === 4) {
            c.meter = s16(c.meter + 0x2d);
            f.w04 = 0x196;
            f.x = Math.trunc(c.x) + c.facing * 0xe;
            f.y = Math.trunc(c.y) - 0x23;
            f.b20 = 0;
            f.d00 = 1;
            f.b21 = 1;
            f.b18 = c.facing;
            f.d28 = 1;
            frameChild(c, f);
            c.seRequest = 0x15;
        }
        if (c.frame >= cnt) {
            c.state = 9;
            c.onStateChange();
        }
    }
}
registerStates({
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262
});
function shard(c, i, init, loops) {
    const ch = c.children[i];
    const opp = c.opponent;
    c.a324c[i] = c.a324c[i] - 1;
    if (ch.frame < 6 && c.a324c[i] <= 0) {
        const f = childSpawnFrame;
        f.w04 = 0x22;
        f.x = Math.trunc(ch.x);
        f.y = Math.trunc(ch.y);
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.a324c[i] = 3;
    }
    if (ch.frame === 0 && c.a314c[i] === 0) {
        init();
        c.a314c[i]++;
    }
    if (ch.y + ch.vy > 0.0 && ch.frame < 3) {
        ch.y = 0.0;
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.timer = 0;
        ch.frame = 3;
        return;
    }
    if (opp.state < 50 || opp.state > 199) {
        if (ch.frame > 2 && ch.frame < 6) {
            let explode = false;
            const near = ch.x - opp.x < 25.0 && ch.x - opp.x > -25.0 && opp.y > -20.0;
            if (near && (opp.state < 50 || opp.state > 150)) explode = true;
            else if (c.state > 249 && c.state < 253) explode = true;
            if (explode) {
                ch.blend = 2;
                c.voiceRequest = 0;
                ch.hitsLeft = 1;
                ch.frame = 6;
                ch.timer = 0;
                ch.vx = 0.0;
                return;
            }
        }
    }
    if (ch.frame > 2 && ch.frame < 6) {
        if (ch.vx > 2.0) ch.ax = -0.18;
        if (ch.vx < -2.0) ch.ax = 0.18;
        ch.vx = ch.vx + ch.ax;
    }
    ch.timer++;
    if (ch.y < 0.0) ch.vy = ch.vy + 0.035;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 3) ch.frame -= 3;
        if (ch.frame === 6 && c.a314c[i] < loops) {
            ch.frame -= 3;
            c.a314c[i]++;
        }
        if (ch.frame === 6) {
            ch.blend = 2;
            c.voiceRequest = 0;
            ch.hitsLeft = 1;
            ch.vx = 0.0;
        }
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child403(c, i) {
    const ch = c.children[i];
    shard(c, i, ()=>{
        ch.vx = 0.5;
        ch.vy = -2.7;
        ch.ax = 0.18;
    }, 6);
}
function child404(c, i) {
    const ch = c.children[i];
    shard(c, i, ()=>{
        ch.vx = 1.1;
        ch.vy = -2.2;
        ch.ax = 0.18;
    }, 8);
}
function child405(c, i) {
    const ch = c.children[i];
    shard(c, i, ()=>{
        ch.vx = (c.random(0, 15) & 0xffff) * 0.1 + 0.5;
        ch.vy = -1.5 - (c.random(0, 10) & 0xffff) * 0.1;
        ch.ax = 0.18;
    }, 30);
}
function rollerInterrupted(c, i) {
    const ch = c.children[i];
    if (ch.hitState === 4 || ch.hitState === 5 || c.state < 256 && c.state > 252 && c.frame === 0) {
        if (ch.frame < 3) {
            ch.frame = 3;
            ch.timer = 0;
            ch.hitState = 0;
            ch.vx = -0.8;
            ch.vy = -1.0;
            ch.blend = 1;
            return true;
        }
    }
    return false;
}
function spawn409(c, x, y) {
    const f = childSpawnFrame;
    f.w04 = 0x199;
    f.x = x;
    f.y = y;
    frameChild(c, f);
}
function trail409(c, i, interval) {
    const ch = c.children[i];
    if (ch.frame === 2 && c.a324c[i] <= 0) {
        const f = childSpawnFrame;
        f.w04 = 0x199;
        f.x = Math.trunc(ch.x);
        f.y = 0.0;
        f.b20 = 2;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        c.a324c[i] = interval;
    }
}
function roller406(c, i, vx0, loops) {
    const ch = c.children[i];
    c.a324c[i] = c.a324c[i] - 1;
    if (rollerInterrupted(c, i)) return;
    if (ch.frame === 0 && c.a314c[i] === 0) {
        ch.vx = vx0;
        ch.vy = -0.5;
        c.a314c[i]++;
    }
    trail409(c, i, 0xf);
    if (ch.y + ch.vy > 0.0 && ch.frame === 0) {
        ch.y = 0.0;
        ch.vy = 0.0;
        ch.timer = 0;
        ch.frame = 1;
        return;
    }
    ch.timer++;
    if (ch.y < 0.0) ch.vy = ch.vy + 0.035;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 3) {
            if (c.a314c[i] < loops) {
                ch.frame -= 2;
                c.a314c[i]++;
            } else {
                const f = childSpawnFrame;
                f.w04 = 0x199;
                f.x = Math.trunc(ch.x);
                f.y = 5.0;
                f.b20 = 2;
                f.b21 = 1;
                f.b18 = c.facing;
                frameChild(c, f);
                spawn409(c, Math.trunc(ch.x) - 5, 0.0);
                spawn409(c, Math.trunc(ch.x) + 5, 0.0);
                spawn409(c, Math.trunc(ch.x), -5.0);
                c.freeChild(i);
            }
        }
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child406(c, i) {
    roller406(c, i, 0.2, 3);
}
function child408(c, i) {
    roller406(c, i, 0.3, 6);
}
function child407(c, i) {
    const ch = c.children[i];
    c.a324c[i] = c.a324c[i] - 1;
    if (rollerInterrupted(c, i)) return;
    if (ch.frame === 0 && c.a314c[i] === 0) {
        ch.vx = 0.4;
        ch.vy = -0.5;
        c.a314c[i]++;
    }
    trail409(c, i, 0x15);
    c.a324c[i] = c.a324c[i] - 1;
    if (ch.y + ch.vy > 0.0 && ch.frame === 0) {
        ch.y = 0.0;
        ch.vy = 0.0;
        ch.timer = 0;
        ch.frame = 1;
        ch.vx = 0.0;
        return;
    }
    ch.timer++;
    if (ch.y < 0.0) ch.vy = ch.vy + 0.035;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function child409(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && c.a314c[i] === 0) {
        ch.vy = -1.5;
        ch.hitsLeft = 1;
        c.a314c[i]++;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
function viewRect() {
    return {
        viewLeft: gs.viewLeft,
        viewTop: gs.viewTop,
        viewRight: gs.viewRight,
        viewBottom: gs.viewBottom
    };
}
function ball(c, i, s) {
    const ch = c.children[i];
    const flag = c[s.initFlag];
    if (ch.frame === 0 && flag[i] === 0) {
        ch.hitsLeft = 1;
        flag[i] = 1;
        if (s.startFrame !== null) ch.frame = s.startFrame;
    }
    if (s.freeWhenSpent && ch.hitsLeft === 0) {
        c.freeChild(i);
        c.f3148 = 0;
    }
    const v = viewRect();
    const bounce = (df)=>{
        ch.frame += df;
        c.a314c[i]++;
        c.voiceRequest = 1;
        if (s.rearm) ch.hitsLeft = 1;
        if (c.a314c[i] > s.limit) {
            c.freeChild(i);
            c.f3148 = 0;
        }
    };
    const hitTop = ()=>v.viewTop > ch.y;
    const hitBottom = ()=>v.viewBottom < ch.y;
    const hitRight = ()=>v.viewRight < ch.x;
    const hitLeft = ()=>v.viewLeft > ch.x;
    if (ch.facing === 1 || ch.facing === -1) {
        const hitFront = ch.facing === 1 ? hitRight : hitLeft;
        const hitBack = ch.facing === 1 ? hitLeft : hitRight;
        if (ch.frame === 0 || ch.frame === 1) {
            ch.vx = s.speed;
            ch.vy = -s.speed;
            if (hitTop()) return bounce(2);
            if (hitFront()) return bounce(6);
        }
        if (ch.frame === 2 || ch.frame === 3) {
            ch.vx = s.speed;
            ch.vy = s.speed;
            if (hitBottom()) return bounce(-2);
            if (hitFront()) return bounce(2);
        }
        if (ch.frame === 4 || ch.frame === 5) {
            ch.vx = -s.speed;
            ch.vy = s.speed;
            if (hitBottom()) return bounce(2);
            if (hitBack()) return bounce(-2);
        }
        if (ch.frame === 6 || ch.frame === 7) {
            ch.vx = -s.speed;
            ch.vy = -s.speed;
            if (hitTop()) return bounce(-2);
            if (hitBack()) return bounce(-6);
        }
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 2 || ch.frame === 4 || ch.frame === 6 || ch.frame === 8) ch.frame -= 2;
        if (ch.frame >= childCount) {
            c.freeChild(i);
            c.f3148 = 0;
        }
    }
}
function child410(c, i) {
    ball(c, i, {
        initFlag: "a314c",
        startFrame: null,
        freeWhenSpent: true,
        speed: 1.5,
        rearm: false,
        limit: 3
    });
}
function child411(c, i) {
    ball(c, i, {
        initFlag: "a324c",
        startFrame: 6,
        freeWhenSpent: true,
        speed: 1.5,
        rearm: false,
        limit: 3
    });
}
function child412(c, i) {
    ball(c, i, {
        initFlag: "a324c",
        startFrame: null,
        freeWhenSpent: false,
        speed: 3.0,
        rearm: true,
        limit: 7
    });
}
registerChildren({
    403: child403,
    404: child404,
    405: child405,
    406: child406,
    407: child407,
    408: child408,
    409: child409,
    410: child410,
    411: child411,
    412: child412
});
