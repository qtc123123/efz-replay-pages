import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerChildren2, registerStates, registerStates2 } from "./81433295782a220b1d5e4d42.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./2ed079700202e720d67705c7.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function stepFrame(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    return true;
}
function endToNeutral(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function superFreeze(c, cost) {
    c.b158 = 0;
    c.freeze = 0x78;
    if (cost !== 0) c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function superEffect(d, c, pat, sound, offX, offY) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) + c.facing * offX;
    d.y = ftol(c.y) - offY;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function state300(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
        c.freeze = 0x78;
        c.superDarken(0xb0, 3);
        superEffect(d, c, 0x46, 0x40, 0, 0x2b);
        c.seRequest = 0x25;
    }
    c.biasCameraY(0x32, 3);
    if (atFrame(c, 4)) {
        d.w04 = 0x19e;
        d.x = ftol(c.x) - c.facing * 5;
        d.y = ftol(c.y) - 0x36;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        c.shakeScreen(0xa, 0);
        c.voiceRequest = 6;
        c.voiceRequest = 7;
    }
    if (!stepFrame(c, dur) || c.frame < cnt) return;
    if (c.f3140 < 8) {
        c.f3140++;
        c.frame -= 2;
        return;
    }
    c.state = 0;
    c.onStateChange();
    c.f3150 = 0x4ec;
    c.f314c = 0xa;
    c.setForm(1);
}
function grabSuper(c, cost, pat, sound, next, altBg) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (atStart(c)) c.stopMotion();
    if (altBg && c.frame > 0) c.showAltBackground(0xf);
    if (atFrame(c, 1)) {
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, 0x1f, 0x58);
        c.stopMotion();
    }
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        o.stopMotion();
        c.state = next;
        o.state = 0x67;
        o.x = c.facing * 0x19 + c.x;
        o.y = -84.0;
        c.biasCameraY(0x32, 0x1e);
        d.w04 = 0;
        d.x = ftol(c.x) + c.facing * 0xd;
        d.y = ftol(c.y) - 0x41;
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
    }
    if (!stepFrame(c, dur)) return;
    c.w16c = c.frame === 1 && o.y === 0.0 ? 1 : 0;
    endToNeutral(c, cnt);
}
function throwSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame < 0xb) c.biasCameraY(0x32, 3);
    if (p.altBg && c.frame < 0xb) c.showAltBackground(0xf);
    if ((c.frame === 4 || c.frame === 6) && c.timer === 0) {
        d.w04 = 0;
        o.hitstop = 0x1e;
        const ex = ftol(c.x);
        d.x = ex + ((c.random(0, 0x28) & 0xffff) + 0xa) * c.facing;
        const ey = ftol(c.y) - 0x32;
        d.y = ey - (c.random(0, 0x14) & 0xffff);
        d.b20 = 2;
        d.b21 = 1;
        d.b2c = 2;
        frameEffect(d);
        d.w04 = p.hitChild;
        const cx = ftol(o.x);
        d.x = cx + (c.random(0, 0xa) & 0xffff) - 5;
        const cy = ftol(c.y) - 0x32;
        d.y = cy - (c.random(0, 0x14) & 0xffff);
        d.b20 = 0;
        d.b21 = 1;
        if (p.childFacing === "random") {
            d.b18 = (c.random(0, 0x64) & 0xffff) < 0x32 ? c.facing : -c.facing;
        } else {
            if (p.childFacing === "rollThenFacing") {
                d.b18 = (c.random(0, 0x64) & 0xffff) < 0x32 ? c.facing : -c.facing;
            }
            d.b18 = c.facing;
        }
        frameChild(c, d);
    }
    c.timer++;
    if (c.timer < dur) return;
    c.timer = 0;
    c.frame++;
    if (c.frame === 1) {
        o.x = c.facing * 0x1e + c.x;
        o.y = c.y - 87.0;
    }
    if (c.frame === 2) {
        o.x = c.facing * 0x1f + c.x;
        o.y = c.y - 88.0;
    }
    if (c.frame === 3) {
        c.voiceRequest = 8;
        c.shakeScreen(p.shake, 0x1e);
        d.w04 = p.child;
        d.x = ftol(c.x) + c.facing * 0x1e;
        d.y = 0.0;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
        d.w04 = p.child;
        d.x = ftol(c.x) + c.facing * 0x1e;
        d.y = -160.0;
        d.b20 = 2;
        d.b21 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (c.f3138 < p.loops && c.frame === 7) {
        c.frame -= 4;
        c.f3138++;
    }
    if (c.frame === 0xb) {
        o.x = c.facing * 0xb + c.x;
        o.y = c.y - 75.0;
    }
    if (c.frame === 0xc) {
        o.x = c.facing * 0xa + c.x;
        o.y = c.y - 74.0;
    }
    if (c.frame === 0xd) {
        o.onStateChange();
        o.state = 0x3f;
        o.knockX = -1.2;
        o.knockY = -0.5;
        o.y = -40.0;
        o.x = c.facing * 0x1e + c.x;
        applyDirectDamage(c, p.damage, 500.0);
        o.hitstop = 0;
    }
    endToNeutral(c, cnt);
}
const throw304 = (damage)=>(c)=>throwSuper(c, {
            child: 0x19f,
            loops: 8,
            shake: 3,
            damage,
            hitChild: 0x1d6,
            altBg: false,
            childFacing: "random"
        });
const throw306 = (damage)=>(c)=>throwSuper(c, {
            child: 0x1a0,
            loops: 0xc,
            shake: 3,
            damage,
            hitChild: 0x1d6,
            altBg: false,
            childFacing: "random"
        });
function projSuper(c, child, loops) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        superFreeze(c, 0x3e8);
        superEffect(d, c, 0x44, 0x13, 4, 0x2f);
        c.stopMotion();
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 5) {
        d.w04 = child;
        d.x = ftol(c.x);
        d.y = 0.0;
        d.b20 = 1;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 0;
        frameChild(c, d);
    }
    if (c.frame === 7 && c.f3138 < loops) {
        c.frame -= 2;
        c.f3138++;
    }
    endToNeutral(c, cnt);
}
function stanceSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (p.altBg && c.frame > 0) c.showAltBackground(0xf);
    if (atFrame(c, 1)) {
        superFreeze(c, p.cost);
        superEffect(d, c, p.pat, p.sound, 0, 0x32);
        c.stopMotion();
    }
    if (atFrame(c, 3)) superEffect(d, c, 0xe, 4, 0x16, 0x3b);
    if (!stepFrame(c, dur)) return;
    if (c.frame === 0xe) {
        c.f315c = p.stance;
        c.voiceRequest = 0xa;
        d.w04 = 0x1a7;
        d.x = ftol(c.x) + c.facing * 0x29;
        d.y = 0.0;
        d.b20 = 2;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 0;
        frameChild(c, d);
    }
    if (c.frame === 0x10 && c.f3138 < 3) {
        c.frame -= 2;
        c.f3138++;
        if (p.setHit) c.d168 = 3;
    }
    endToNeutral(c, cnt);
}
function spawnAtOpponent(c, d, main, follow, around) {
    const o = c.opponent;
    d.w04 = main;
    d.x = ftol(o.x);
    d.y = 0.0;
    d.b20 = 2;
    d.d00 = 1;
    d.b18 = c.facing;
    d.b21 = 1;
    frameChild(c, d);
    if (follow) {
        d.w04 = 0x1a7;
        d.b21 = 0;
        frameChild(c, d);
    }
    for (const [dx, y] of around){
        d.w04 = 0x1a9;
        d.x = ftol(o.x) + dx;
        d.y = y;
        d.b20 = 2;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
        d.w04 = 0x1a7;
        d.b21 = 0;
        frameChild(c, d);
    }
}
const AROUND_4 = [
    [
        0x19,
        -10.0
    ],
    [
        -0x19,
        -10.0
    ],
    [
        0x2d,
        10.0
    ],
    [
        -0x2d,
        10.0
    ]
];
const AROUND_6 = [
    [
        0x23,
        -10.0
    ],
    [
        -0x23,
        -10.0
    ],
    [
        0x46,
        0.0
    ],
    [
        -0x46,
        0.0
    ],
    [
        0x28,
        10.0
    ],
    [
        -0x28,
        10.0
    ]
];
function followSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (p.altBg && c.frame > 2) c.showAltBackground(0xf);
    if (atFrame(c, 3)) {
        superFreeze(c, 0);
        superEffect(d, c, p.pat, p.sound, 0x1f, 0x34);
        c.stopMotion();
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 5) {
        c.f315c = 0;
        spawnAtOpponent(c, d, p.main, p.main === 0x1a8, p.around);
    }
    endToNeutral(c, cnt);
}
function directSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (p.altBg && c.frame > 0) c.showAltBackground(0xf);
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 1)) {
        superFreeze(c, p.cost);
        superEffect(d, c, p.pat, p.sound, p.offX, p.offY);
        c.stopMotion();
    }
    if (atFrame(c, 3)) superEffect(d, c, 0xe, 4, 0x16, 0x3b);
    if (!stepFrame(c, dur)) return;
    if (c.frame === 0xe) spawnAtOpponent(c, d, p.main, p.main === 0x1a8, p.around);
    if (c.frame === 0x10 && c.f3138 < 6) {
        c.frame -= 2;
        c.f3138++;
    }
    endToNeutral(c, cnt);
}
const state303 = (c)=>grabSuper(c, 0x3e8, 0x44, 0x13, 0x130, false);
const state305 = (c)=>grabSuper(c, 0x7d0, 0x45, 5, 0x132, false);
const state307 = (c)=>grabSuper(c, 0xbb8, 0x46, 0x40, 0x134, true);
const state312 = (setHit)=>(c)=>stanceSuper(c, {
            cost: 0x3e8,
            pat: 0x44,
            sound: 0x13,
            stance: 1,
            altBg: false,
            setHit
        });
const state313 = (setHit)=>(c)=>stanceSuper(c, {
            cost: 0x7d0,
            pat: 0x45,
            sound: 5,
            stance: 2,
            altBg: false,
            setHit
        });
const state314 = (setHit)=>(c)=>stanceSuper(c, {
            cost: 0xbb8,
            pat: 0x46,
            sound: 0x40,
            stance: 3,
            altBg: true,
            setHit
        });
const state315 = (c)=>followSuper(c, {
        pat: 0x44,
        sound: 0x13,
        main: 0x1a8,
        around: [],
        altBg: false
    });
const state316 = (c)=>followSuper(c, {
        pat: 0x45,
        sound: 5,
        main: 0x1aa,
        around: AROUND_4,
        altBg: false
    });
const state317 = (c)=>followSuper(c, {
        pat: 0x46,
        sound: 0x40,
        main: 0x1ab,
        around: AROUND_6,
        altBg: true
    });
const state318 = (c)=>directSuper(c, {
        cost: 0x3e8,
        pat: 0x44,
        sound: 0x13,
        offX: 0,
        offY: 0x32,
        main: 0x1a8,
        around: [],
        altBg: false
    });
const state319 = (c)=>directSuper(c, {
        cost: 0x7d0,
        pat: 0x45,
        sound: 5,
        offX: 0,
        offY: 0x32,
        main: 0x1aa,
        around: AROUND_4,
        altBg: false
    });
const state320 = (c)=>directSuper(c, {
        cost: 0xbb8,
        pat: 0x46,
        sound: 0x40,
        offX: -0xb,
        offY: 0x65,
        main: 0x1ab,
        around: AROUND_6,
        altBg: true
    });
registerStates({
    300: state300,
    303: state303,
    304: throw304(0x7d0),
    305: state305,
    306: throw306(0xbb8),
    307: state307,
    308: (c)=>throwSuper(c, {
            child: 0x1a1,
            loops: 0xc,
            shake: 4,
            damage: 0x1004,
            hitChild: 0x1de,
            altBg: true,
            childFacing: "facing"
        }),
    309: (c)=>projSuper(c, 0x1a4, 2),
    310: (c)=>projSuper(c, 0x1a5, 2),
    311: (c)=>projSuper(c, 0x1a6, 2),
    312: state312(true),
    313: state313(true),
    314: state314(true),
    315: state315,
    316: state316,
    317: state317,
    318: state318,
    319: state319,
    320: state320
});
registerStates2({
    300: state300,
    303: state303,
    304: throw304(0xaf0),
    305: state305,
    306: throw306(0xed8),
    307: state307,
    308: (c)=>throwSuper(c, {
            child: 0x1a1,
            loops: 0xc,
            shake: 4,
            damage: 0x157c,
            hitChild: 0x1de,
            altBg: true,
            childFacing: "rollThenFacing"
        }),
    309: (c)=>projSuper(c, 0x1a4, 5),
    310: (c)=>projSuper(c, 0x1a5, 5),
    311: (c)=>projSuper(c, 0x1a6, 5),
    312: state312(false),
    313: state313(false),
    314: state314(false),
    315: state315,
    316: state316,
    317: state317,
    318: state318,
    319: state319,
    320: state320
});
function childStep(c, i, resetHit) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    if (resetHit) ch.hitState = 0;
    return true;
}
function childOnce(c, i, resetHit) {
    if (childStep(c, i, resetHit) && c.children[i].frame >= childCount) c.freeChild(i);
}
function toVanish(c, i) {
    const ch = c.children[i];
    ch.frame = 0;
    ch.timer = 0;
    ch.vx = 0.0;
    ch.vy = 0.0;
    ch.pattern = 0x1ae;
}
const ownerHit = (c)=>c.state > 0x31 && c.state < 0x96;
function opponentAhead(c, i, dist) {
    const ch = c.children[i];
    const ox = c.opponent.x;
    if (ch.x - ox < dist && ch.facing === -1) return true;
    return ox - ch.x < dist && ch.facing === 1;
}
const child414 = (c, i)=>childOnce(c, i, true);
const childPlain = (c, i)=>childOnce(c, i, false);
function rushLoop(c, i) {
    const ch = c.children[i];
    if (!childStep(c, i, false)) return;
    if (ch.frame === 0x28 && c.frame < 7) ch.frame = 0;
    if (ch.frame >= childCount) c.freeChild(i);
}
const child415 = (c, i)=>rushLoop(c, i);
function child417(c, i) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    if (ch.timer === 0 && (ch.frame === 0 || ch.frame === 0xa || ch.frame === 0x14 || ch.frame === 0x1e)) {
        d.w04 = 0x1a2;
        if ((c.random(0, 0x64) & 0xffff) < 0x32) d.w04 = 0x1a3;
        const bx = ftol(ch.x);
        d.x = bx + (c.random(0, 0x78) & 0xffff) - 0x3c;
        const by = ftol(ch.y);
        d.y = by - (c.random(0, 0xa0) & 0xffff);
        d.b18 = ch.facing;
        if ((c.random(0, 0x64) & 0xffff) < 0x32) d.b18 = -ch.facing;
        d.b21 = 1;
        d.b20 = 2;
        frameChild(c, d);
    }
    rushLoop(c, i);
}
function child420(c, i, form1) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    if (ownerHit(c)) {
        toVanish(c, i);
        return;
    }
    if (ch.frame === 0x1b && ch.timer === 0) {
        ch.vy = 0.0;
        ch.vx = 2.5;
        ch.hitsLeft = 3;
    }
    if (ch.frame === (form1 ? 0x1f : 0x1b) && ch.timer === 0) c.a3260[i] = 1;
    if (ch.frame === 0x25 && ch.timer === 0) {
        c.seRequest = 0x14;
        d.w04 = 0x191;
        d.x = ftol(ch.x);
        d.y = ch.y;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = ch.facing;
        frameChild(c, d);
        c.voiceRequest = 2;
    }
    if (ch.frame > 0x26) {
        ch.vx = ch.vx - (form1 ? 0.045 : 0.07);
        if (ch.vx < 0.0) ch.vx = 0.0;
    }
    if (opponentAhead(c, i, 150.0) && c.a3260[i] !== 0 && ch.frame < 0x23) {
        ch.timer = 0;
        ch.frame = 0x23;
        return;
    }
    if (!childStep(c, i, true)) return;
    if (ch.frame === 2 && c.a3160[i] < (form1 ? 8 : 0)) {
        c.a3160[i]++;
        ch.frame -= 2;
    }
    if (!form1 && ch.frame === 0xc) ch.frame = 0x1b;
    if (ch.frame === 0x1b && c.a3160[i] < (form1 ? 1 : 0)) {
        c.a3160[i]++;
        ch.frame = 5;
    }
    if (ch.frame === 0x23 && c.a3360[i] < 1) {
        ch.frame -= 8;
        c.a3360[i]++;
    }
    if (ch.frame >= childCount) toVanish(c, i);
}
function child421(c, i) {
    const ch = c.children[i];
    if (ownerHit(c)) {
        toVanish(c, i);
        return;
    }
    if (ch.frame > 4 && ch.frame < 0x1b && opponentAhead(c, i, 50.0)) {
        ch.timer = 0;
        ch.frame = 0x1b;
        return;
    }
    if ((ch.frame === 0x1e || ch.frame === 0x26 || ch.frame === 0x2f) && ch.timer === 0) {
        c.seRequest = 0x15;
        ch.hitsLeft = 1;
    }
    if (ch.y < 0.0) {
        ch.vy = ch.vy + 0.035;
        if (ch.y + ch.vy > 0.0 && ch.frame < 0x37) {
            ch.timer = 0;
            ch.frame = 0x37;
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            return;
        }
    }
    if (!childStep(c, i, true)) return;
    if (ch.frame === 2 && c.a3160[i] < 8) {
        c.a3160[i]++;
        ch.frame -= 2;
    }
    if (ch.frame === 0x1b && c.a3160[i] < 0xd) {
        c.a3160[i]++;
        ch.frame = 5;
    }
    if (ch.frame === 0x2d) {
        ch.vx = 1.0;
        ch.vy = -1.5;
    }
    if (ch.frame === 0x37) ch.frame -= 2;
    if (ch.frame >= childCount) toVanish(c, i);
}
function child422(c, i) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    if (ownerHit(c)) {
        toVanish(c, i);
        return;
    }
    if (ch.frame === 6) ch.vx = 0.6;
    if (opponentAhead(c, i, 50.0) && ch.frame > 5 && ch.frame < 0xe) {
        ch.timer = 0;
        ch.frame = 0xe;
        ch.vx = 0.0;
        return;
    }
    if (!childStep(c, i, true)) return;
    if (ch.frame === 2 && c.a3160[i] < 8) {
        c.a3160[i]++;
        ch.frame -= 2;
    }
    if (ch.frame === 0xe && c.a3260[i] < 5) {
        c.a3260[i]++;
        ch.frame = 6;
        return;
    }
    if (ch.frame === 0xe) ch.vx = 0.0;
    if (ch.frame === 0x15) {
        d.w04 = 0x1ac;
        d.x = ftol(ch.x) + ch.facing * 0x32;
        d.y = 0.0;
        d.b20 = 2;
        d.b21 = 1;
        d.d00 = 1;
        d.b18 = c.facing;
        frameChild(c, d);
    }
    if (ch.frame >= childCount) toVanish(c, i);
}
function childStrike(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.hitsLeft = 1;
        c.voiceRequest = 9;
    }
    childOnce(c, i, false);
}
function child425(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 0;
    childOnce(c, i, false);
}
function child428(c, i) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    if (ch.frame === 0) ch.hitsLeft = 1;
    if (ch.frame === 0 && ch.timer === 0) {
        d.w04 = 0x1ad;
        d.x = ftol(ch.x);
        d.y = ftol(ch.y);
        d.b18 = ch.facing;
        d.b21 = 1;
        d.b20 = 2;
        d.d00 = 1;
        frameChild(c, d);
        c.voiceRequest = 1;
    }
    childOnce(c, i, true);
}
function child429(c, i, hits) {
    const ch = c.children[i];
    if (ch.frame === 0) ch.hitsLeft = hits;
    if (ch.hitsLeft === 0 && ch.frame < 0x2f) {
        ch.timer = 0;
        ch.frame = 0x2f;
        return;
    }
    if (!childStep(c, i, false)) return;
    if (ch.frame === 0x2f && c.a3160[i] < 3) {
        c.a3160[i]++;
        ch.frame = 0x20;
        ch.hitState = 0;
    }
    if (ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    414: child414,
    415: child415,
    416: child415,
    417: child417,
    418: childPlain,
    419: childPlain,
    420: (c, i)=>child420(c, i, false),
    421: child421,
    422: child422,
    423: childPlain,
    424: childStrike,
    425: child425,
    426: childStrike,
    427: childStrike,
    428: child428,
    429: (c, i)=>child429(c, i, 4),
    430: childPlain
});
registerChildren2({
    414: child414,
    415: child415,
    416: child415,
    417: child417,
    418: childPlain,
    419: childPlain,
    420: (c, i)=>child420(c, i, true),
    421: child421,
    422: child422,
    423: childPlain,
    424: childStrike,
    425: child425,
    426: childStrike,
    427: childStrike,
    428: child428,
    429: (c, i)=>child429(c, i, 2),
    430: childPlain
});

export function __logicState(){return {AROUND_4,AROUND_6};}

export function __installInitialRoots(s){
if(AROUND_4!==s["AROUND_4"])throw Error('INITIAL_CONST_IDENTITY:AROUND_4');
if(AROUND_6!==s["AROUND_6"])throw Error('INITIAL_CONST_IDENTITY:AROUND_6');
}
