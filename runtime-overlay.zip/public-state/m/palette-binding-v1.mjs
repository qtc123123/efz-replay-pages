export const CUSTOM_PALETTE_PROFILE='revival-custom-rgb0/1';
const need=(v,c)=>{if(!v)throw Error('PALETTE_BINDING_'+c);};
const uint=(v,max)=>Number.isInteger(v)&&v>=0&&v<=max;
function record(v,keys){need(v&&[Object.prototype,null].includes(Object.getPrototypeOf(v)),'OBJECT');const ds=Object.getOwnPropertyDescriptors(v),names=Reflect.ownKeys(ds);need(names.length===keys.length&&keys.every(k=>Object.hasOwn(ds,k)),'FIELDS');for(const k of names)need(Object.hasOwn(ds[k],'value')&&ds[k].enumerable,'ACCESSOR');return Object.fromEntries(keys.map(k=>[k,ds[k].value]));}
function array(v,max){need(Array.isArray(v)&&Object.getPrototypeOf(v)===Array.prototype&&v.length<=max,'ARRAY');const ds=Object.getOwnPropertyDescriptors(v);need(Reflect.ownKeys(ds).length===v.length+1,'ARRAY_FIELDS');return Array.from({length:v.length},(_,i)=>{need(ds[i]&&Object.hasOwn(ds[i],'value')&&ds[i].enumerable,'ACCESSOR');return ds[i].value;});}
export function validatePaletteBinding(value,context,selection){
 const v=record(value,['profile','gameId','epoch','sourceStart','artifactSha256','ranges']);need(v.profile===CUSTOM_PALETTE_PROFILE,'PROFILE');
 need(typeof v.gameId==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(v.gameId)&&uint(v.epoch,2147483647)&&v.epoch>0&&uint(v.sourceStart,524288)&&typeof v.artifactSha256==='string'&&/^[a-f0-9]{64}$/.test(v.artifactSha256),'IDENTITY');
 for(const k of ['gameId','epoch','sourceStart','artifactSha256'])need(v[k]===context[k],'CONTEXT');
 let seen=0;const ranges=array(v.ranges,2).map(raw=>{const r=record(raw,['side','characterId','paletteIndex','rgb0']);need(uint(r.side,1)&&!(seen&(1<<r.side))&&uint(r.characterId,24)&&uint(r.paletteIndex,5),'KEY');seen|=1<<r.side;const rgb0=array(r.rgb0,160);need(rgb0.length===160&&rgb0.every((x,i)=>uint(x,255)&&(i%4!==3||x===0)),'RGB0');if(selection)need(!!selection.usePal[r.side]&&r.characterId===selection.characters[r.side]&&r.paletteIndex===selection.palettes[r.side],'SELECTION');return Object.freeze({...r,rgb0:Object.freeze(rgb0)});});
 if(selection)for(let side=0;side<2;side++)need(!!(seen&(1<<side))===!!selection.usePal[side],'MISSING');
 return Object.freeze({...v,ranges:Object.freeze(ranges)});
}
