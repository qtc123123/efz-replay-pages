export const RESOLVED_PALETTE_PROFILE='revival-palette-resolution/1';
export const CUSTOM_PALETTE_PROFILE='revival-custom-rgb0/1';
const need=(v,c)=>{if(!v)throw Error('PALETTE_BINDING_'+c);};
const uint=(v,max)=>Number.isInteger(v)&&v>=0&&v<=max;
function record(v,keys){need(v&&[Object.prototype,null].includes(Object.getPrototypeOf(v)),'OBJECT');const ds=Object.getOwnPropertyDescriptors(v),names=Reflect.ownKeys(ds);need(names.length===keys.length&&keys.every(k=>Object.hasOwn(ds,k)),'FIELDS');for(const k of names)need(Object.hasOwn(ds[k],'value')&&ds[k].enumerable,'ACCESSOR');return Object.fromEntries(keys.map(k=>[k,ds[k].value]));}
function array(v,max){need(Array.isArray(v)&&Object.getPrototypeOf(v)===Array.prototype&&v.length<=max,'ARRAY');const ds=Object.getOwnPropertyDescriptors(v);need(Reflect.ownKeys(ds).length===v.length+1,'ARRAY_FIELDS');return Array.from({length:v.length},(_,i)=>{need(ds[i]&&Object.hasOwn(ds[i],'value')&&ds[i].enumerable,'ACCESSOR');return ds[i].value;});}
export function validatePaletteBinding(value,context,selection){
 const resolved=Object.getOwnPropertyDescriptor(value??{},'profile')?.value===RESOLVED_PALETTE_PROFILE;
 const v=record(value,['profile','gameId','epoch','sourceStart','artifactSha256','ranges',...(resolved?['resolutions']:[])]);need(v.profile===(resolved?RESOLVED_PALETTE_PROFILE:CUSTOM_PALETTE_PROFILE),'PROFILE');
 need(typeof v.gameId==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(v.gameId)&&uint(v.epoch,2147483647)&&v.epoch>0&&uint(v.sourceStart,524288)&&typeof v.artifactSha256==='string'&&/^[a-f0-9]{64}$/.test(v.artifactSha256),'IDENTITY');
 for(const k of ['gameId','epoch','sourceStart','artifactSha256'])need(v[k]===context[k],'CONTEXT');
 let seen=0;const ranges=array(v.ranges,2).map(raw=>{const r=record(raw,['side','characterId','paletteIndex','rgb0']);need(uint(r.side,1)&&!(seen&(1<<r.side))&&uint(r.characterId,24)&&uint(r.paletteIndex,5),'KEY');seen|=1<<r.side;const rgb0=array(r.rgb0,160);need(rgb0.length===160&&rgb0.every((x,i)=>uint(x,255)&&(i%4!==3||x===0)),'RGB0');if(selection)need(!!selection.usePal[r.side]&&r.characterId===selection.characters[r.side]&&r.paletteIndex===selection.palettes[r.side],'SELECTION');return Object.freeze({...r,rgb0:Object.freeze(rgb0)});});
 let resolutionSeen=0;
 if(resolved){need(Array.isArray(v.resolutions)&&v.resolutions.length>=1,'RESOLUTION_EMPTY');v.resolutions=Object.freeze(array(v.resolutions,2).map(raw=>{const r=record(raw,['side','characterId','paletteIndex','kind']);need(uint(r.side,1)&&!(resolutionSeen&(1<<r.side))&&uint(r.characterId,24)&&uint(r.paletteIndex,5)&&['stock','stock-cache','custom'].includes(r.kind),'RESOLUTION_KEY');resolutionSeen|=1<<r.side;const range=ranges.find(x=>x.side===r.side);need(r.kind!=='stock'?range&&range.characterId===r.characterId&&range.paletteIndex===r.paletteIndex:!range,'RESOLUTION_RANGE');if(selection)need(!!selection.usePal[r.side]&&r.characterId===selection.characters[r.side]&&r.paletteIndex===selection.palettes[r.side],'SELECTION');return Object.freeze(r);}));need((seen&~resolutionSeen)===0,'RESOLUTION_MISSING');}
 if(selection)for(let side=0;side<2;side++)need(!!((resolved?resolutionSeen:seen)&(1<<side))===!!selection.usePal[side],'MISSING');
 return Object.freeze({...v,ranges:Object.freeze(ranges)});
}
