import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./4fd020f21e3ef9d96dc087c0.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./b1bf50e501f736bc8b07bfdb.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function stopAtStart(c) {
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
}
function superActivate(c, d, cost, pat, sound, dx, dy) {
    c.stopMotion();
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) + c.facing * dx;
    d.y = ftol(c.y) - dy;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function stepFrame(c, dur, hit) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = hit;
    return true;
}
function endGround(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function endAir(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 9;
        c.b159 = 1;
        c.b15a = c.b15a + 1 & 0xff;
        c.ay = 0.035;
        c.onStateChange();
    }
}
function superGround(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    stopAtStart(c);
    if (c.frame === 2 && c.timer === p.at) {
        superActivate(c, d, p.cost, p.pat, p.sound, 0, 0x28);
        if (p.se) c.seRequest = 0x25;
    }
    if (!stepFrame(c, dur, 0)) return;
    endGround(c, cnt);
}
function superAir(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    stopAtStart(c);
    if (c.frame === 1 && c.timer === p.at) {
        superActivate(c, d, p.cost, p.pat, p.sound, -0x12, 0x57);
        if (p.se) c.seRequest = 0x25;
    }
    if (!stepFrame(c, dur, 3)) return;
    endAir(c, cnt);
}
const P1000_T3 = {
    cost: 0x3e8,
    pat: 0x44,
    sound: 0x13,
    at: 3,
    se: false
};
const P2000_T3 = {
    cost: 0x7d0,
    pat: 0x45,
    sound: 5,
    at: 3,
    se: false
};
const P3000_T3 = {
    cost: 0xbb8,
    pat: 0x46,
    sound: 0x40,
    at: 3,
    se: true
};
const P1000_T0 = {
    cost: 0x3e8,
    pat: 0x44,
    sound: 0x13,
    at: 0,
    se: false
};
const P2000_T0 = {
    cost: 0x7d0,
    pat: 0x45,
    sound: 5,
    at: 0,
    se: false
};
const P3000_T0 = {
    cost: 0xbb8,
    pat: 0x46,
    sound: 0x40,
    at: 0,
    se: true
};
function state312(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    stopAtStart(c);
    if (p.alt && c.frame > 2) c.showAltBackground(0xf);
    if (c.frame === 2 && c.timer === 3) {
        superActivate(c, d, p.cost, p.pat, p.sound, 0, 0x28);
        if (p.se) c.seRequest = 0x25;
    }
    if (c.frame === 4 && c.timer === 0) c.voiceRequest = 0;
    if (c.frame > 4 && c.frame < 9) {
        c.f3138 = c.f3138 - 1;
        if (c.f3138 <= 0) {
            d.w04 = p.child;
            d.x = ftol(c.x) + c.facing * 0x1e;
            d.y = ftol(c.y) - 0x32;
            d.b20 = 2;
            d.b18 = c.facing;
            d.b21 = 1;
            frameChild(c, d);
            c.f3138 = p.interval;
        }
    }
    if (!stepFrame(c, dur, 0)) return;
    if (c.frame === 9 && c.f313c < p.loops) {
        c.f313c++;
        c.frame -= 4;
    }
    endGround(c, cnt);
}
function state315(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (c.frame > 3) c.showAltBackground(0xf);
    if (c.frame === 3 && c.timer === 3) {
        c.stopMotion();
        c.meter = s16(c.meter - 0xbb8);
        c.biasCameraY(0x32, 0x2d);
        c.freeze = 0x78;
        c.superDarken(0xb0, 3);
        d.w04 = 0x46;
        d.b2c = 0x40;
        d.x = ftol(c.x) - c.facing * 0xd;
        d.y = ftol(c.y) - 0x43;
        d.b20 = 2;
        d.d00 = 1;
        d.b21 = 1;
        frameEffect(d);
        d.w04 = 0x47;
        frameEffect(d);
        c.seRequest = 0x25;
        c.w16c = 1;
    }
    if (!stepFrame(c, dur, 0)) return;
    if (c.frame === 0xb && c.f3138 < 2) {
        c.frame -= 4;
        c.f3138++;
        return;
    }
    endGround(c, cnt);
}
registerStates({
    300: (c)=>superGround(c, P1000_T3),
    301: (c)=>superGround(c, P2000_T3),
    302: (c)=>superGround(c, P3000_T3),
    303: (c)=>superGround(c, P1000_T0),
    304: (c)=>superGround(c, P2000_T0),
    305: (c)=>superGround(c, P3000_T0),
    306: (c)=>superAir(c, P1000_T3),
    307: (c)=>superAir(c, P2000_T3),
    308: (c)=>superAir(c, P3000_T3),
    309: (c)=>superAir(c, P1000_T0),
    310: (c)=>superAir(c, P2000_T0),
    311: (c)=>superAir(c, P3000_T0),
    312: (c)=>state312(c, {
            cost: 0x3e8,
            pat: 0x44,
            sound: 0x13,
            se: false,
            alt: false,
            child: 0x1b8,
            interval: 0x1e,
            loops: 3
        }),
    313: (c)=>state312(c, {
            cost: 0x7d0,
            pat: 0x45,
            sound: 5,
            se: false,
            alt: false,
            child: 0x1b9,
            interval: 0x15,
            loops: 5
        }),
    314: (c)=>state312(c, {
            cost: 0xbb8,
            pat: 0x46,
            sound: 0x40,
            se: true,
            alt: true,
            child: 0x1ba,
            interval: 0xc,
            loops: 7
        }),
    315: state315,
    316: (c)=>superGround(c, P1000_T3),
    317: (c)=>superGround(c, P2000_T3),
    318: (c)=>superGround(c, P3000_T3),
    319: (c)=>superAir(c, P1000_T3),
    320: (c)=>superAir(c, P2000_T3),
    321: (c)=>superAir(c, P3000_T3)
});
function childStep(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function partnerCancelled(c, i) {
    const ch = c.children[i];
    if (ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 0x193;
        ch.frame = 0;
        ch.timer = 0;
        return true;
    }
    return false;
}
function clampPartnerX(c, i) {
    const ch = c.children[i];
    if (ch.x > 620.0) {
        ch.vx = 0.0;
        ch.x = 620.0;
    }
    if (ch.x < 20.0) {
        ch.vx = 0.0;
        ch.x = 20.0;
    }
}
function partnerEffect31(c, i) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    d.w04 = 0x1f;
    d.x = ftol(ch.x);
    d.y = ftol(ch.y);
    d.b20 = 0;
    d.b21 = 1;
    d.d1c = ch.facing === 1 ? 1 : 0;
    frameEffect(d);
    ch.hitsLeft = 1;
}
function partner416(c, i, p) {
    const ch = c.children[i];
    c.f3148 = 4;
    if (p.camY && ch.frame < 0x10) c.opponent.biasCameraY(0x32, 0x1e);
    if (p.alt) c.showAltBackground(0xf);
    if (partnerCancelled(c, i)) return;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        c.a3154[i] = 0;
    }
    if (ch.frame === 4 && ch.timer === 0) partnerEffect31(c, i);
    if (ch.frame === 5 && ch.hitState === 3 && c.a3154[i] === 0) {
        c.opponent.hitstop = p.stop;
        ch.hitstop = p.stop;
        c.a3154[i] = 1;
    }
    clampPartnerX(c, i);
    if (!childStep(c, i)) return;
    if (ch.frame >= childCount) {
        ch.pattern = 0x190;
        ch.frame = 0;
        c.f3148 = 0;
    }
}
function partner417(c, i, stop, loops) {
    const ch = c.children[i];
    c.f3148 = 4;
    if (ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 0x193;
        ch.frame = 0;
        ch.timer = 0;
        c.a3154[i] = 0;
        return;
    }
    if (ch.frame > 1 && ch.frame < 6) {
        if (ch.x - c.opponent.x > -50.0 && ch.x - c.opponent.x < 50.0) {
            ch.timer = 0;
            ch.frame = 6;
        }
        ch.vx = 2.2;
    }
    if (ch.frame > 5) ch.vx = ch.vx - 0.1;
    if (ch.vx < 0.0) ch.vx = 0.0;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        c.a3154[i] = 0;
    }
    if (ch.frame === 0xa && ch.timer === 0) partnerEffect31(c, i);
    if (ch.frame === 0xb && ch.hitState === 3 && c.a3154[i] === 0) {
        c.opponent.hitstop = stop;
        ch.hitstop = stop;
        c.a3154[i] = 1;
    }
    clampPartnerX(c, i);
    if (!childStep(c, i)) return;
    if (ch.frame === 6 && c.a3254[i] < loops) {
        ch.frame -= 4;
        c.a3254[i]++;
    }
    if (ch.frame >= childCount) {
        ch.pattern = 0x190;
        ch.frame = 0;
        c.f3148 = 0;
        c.a3154[i] = 0;
        c.a3254[i] = 0;
    }
}
function child437(c, i) {
    const ch = c.children[i];
    c.f3148 = 4;
    if (partnerCancelled(c, i)) return;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.moveWhileFrozen = 1;
    }
    if (c.state !== 0x138 && c.state !== 0x139 && c.state !== 0x13a) ch.moveWhileFrozen = 0;
    clampPartnerX(c, i);
    if (ch.frame > 3 && ch.frame < 8) {
        c.a3354[i]--;
        if (c.a3354[i] <= 0) {
            const d = childSpawnFrame;
            d.w04 = 0x1bb;
            d.x = ftol(ch.x) + ch.facing * 0x17;
            d.y = ftol(ch.y) - 0x21;
            d.b20 = 2;
            d.b18 = ch.facing;
            d.b21 = 1;
            frameChild(c, d);
            c.a3354[i] = 0x15;
        }
    }
    if (!childStep(c, i)) return;
    const limit = (c.state === 0x139 ? 1 : 0) * 3 + (c.state === 0x13a ? 1 : 0) * 6 + 5;
    if (ch.frame === 8 && c.a3254[i] < limit) {
        ch.frame -= 4;
        c.a3254[i]++;
    }
    if (ch.frame >= childCount) {
        ch.pattern = 0x190;
        ch.frame = 0;
        ch.timer = 0;
        c.f3148 = 0;
        c.a3254[i] = 0;
        ch.moveWhileFrozen = 0;
    }
}
function child440(c, i, base, floor) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3254[i] === 0) {
        ch.hitsLeft = 1;
        c.a3254[i]++;
        ch.vx = (c.random(0, 0xa) & 0xffff) * 0.1 + base;
        ch.vy = (c.random(0, 0xa) & 0xffff) * 0.1 + 0.0;
    }
    if (ch.vx > 0.8) {
        ch.vx = ch.vx - 0.015;
        if (ch.vx < floor) ch.vx = floor;
    }
    ch.vy = ch.vy - 0.015;
    if (ch.hitState > 0 && ch.frame < 0x18) {
        ch.timer = 0;
        ch.frame = 0x18;
    }
    if (childStep(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function child446(c, i) {
    const ch = c.children[i];
    c.f3148 = 4;
    if (ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 0x193;
        ch.frame = 0;
        ch.timer = 0;
        c.a3254[i] = 0;
        return;
    }
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.moveWhileFrozen = 1;
        c.voiceRequest = 2;
    }
    if (c.state !== 0x13b) ch.moveWhileFrozen = 0;
    clampPartnerX(c, i);
    if (ch.frame > 9 && ch.frame < 0x16) {
        c.a3354[i]--;
        if (c.a3354[i] <= 0) {
            const d = childSpawnFrame;
            d.w04 = 0x1bf;
            d.d00 = 1;
            const r = c.random(0, 0x1e0) & 0xffff;
            d.x = c.x - r + 240.0 - ch.facing * 0x78;
            d.y = -480.0;
            d.b20 = 2;
            d.b18 = ch.facing;
            d.b21 = 1;
            frameChild(c, d);
            c.a3354[i] = 0x12;
        }
    }
    if (!childStep(c, i)) return;
    if (ch.frame === 0x16 && c.a3254[i] < 0x11) {
        ch.frame -= 6;
        c.a3254[i]++;
    }
    if (ch.frame >= childCount) {
        ch.pattern = 0x190;
        ch.frame = 0;
        ch.timer = 0;
        c.f3148 = 0;
        c.a3254[i] = 0;
        ch.moveWhileFrozen = 0;
    }
}
function child447(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a3254[i] === 0) {
        ch.hitsLeft = 1;
        c.a3254[i]++;
        ch.vx = 1.5;
        ch.vy = 3.0;
    }
    c.a3354[i]--;
    if (c.a3354[i] <= 0) {
        const d = childSpawnFrame;
        d.w04 = c.a3254[i] + 0x1c0 & 0xffff;
        d.x = ch.x;
        d.y = ch.y;
        d.b20 = 2;
        d.b18 = ch.facing;
        d.b21 = 0;
        frameChild(c, d);
        c.a3354[i] = 6;
        c.a3254[i]++;
        if (c.a3254[i] > 4) c.a3254[i] = 0;
    }
    if (ch.y > 200.0) {
        c.freeChild(i);
        return;
    }
    if (childStep(c, i) && ch.frame >= childCount) ch.frame = 0;
}
function child448(c, i) {
    const ch = c.children[i];
    if (childStep(c, i) && ch.frame >= childCount) c.freeChild(i);
}
function partner454(c, i, p) {
    const ch = c.children[i];
    c.f3148 = 4;
    if (partnerCancelled(c, i)) return;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.moveWhileFrozen = 1;
    }
    if (c.state !== p.s1 && c.state !== p.s2) ch.moveWhileFrozen = 0;
    if (ch.y < 0.0 && ch.frame > 3 && ch.frame < 8) {
        ch.vy = ch.vy + p.gravity;
        if (ch.vy + ch.y > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.timer = 0;
            ch.frame = 8;
            c.seRequest = 7;
            return;
        }
    }
    clampPartnerX(c, i);
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame > 3 && ch.frame < 9) p.spawn(c, i, childSpawnFrame);
    if (ch.frame === 1 || ch.frame === 5 || ch.frame === 7) ch.hitState = 0;
    if (ch.frame === 4) {
        ch.hitsLeft = 0x63;
        ch.vx = p.vx;
        ch.vy = p.vy;
        return;
    }
    if (ch.frame === 8) {
        ch.frame -= 4;
        c.a3154[i]++;
    }
    if (ch.frame >= childCount) {
        ch.pattern = 0x190;
        ch.frame = 0;
        c.f3148 = 0;
        c.a3154[i] = 0;
    }
}
function spawnNear(c, i, d, rx, ry, addY) {
    const ch = c.children[i];
    const rX = c.random(0, rx) & 0xffff;
    d.x = rX * ch.facing + ch.x;
    const rY = c.random(0, ry) & 0xffff;
    d.y = ch.y - rY + addY - 30.0;
    d.b18 = ch.facing;
    d.b21 = 1;
    d.b20 = 2;
    frameChild(c, d);
}
const PARTNER454 = {
    s1: 0x12c,
    s2: 0x132,
    gravity: 0.0035,
    vx: 0.5,
    vy: -0.5,
    spawn: (c, i, d)=>{
        d.w04 = 0x1cf;
        spawnNear(c, i, d, 0x1e, 0x50, 40.0);
    }
};
const PARTNER455 = {
    s1: 0x12d,
    s2: 0x133,
    gravity: 0.0035,
    vx: 0.65,
    vy: -0.52,
    spawn: (c, i, d)=>{
        d.w04 = (c.random(0, 0x64) & 0xffff) > 0x32 ? 0x1d0 : 0x1cf;
        spawnNear(c, i, d, 0x28, 0x78, 60.0);
    }
};
const PARTNER456 = {
    s1: 0x12e,
    s2: 0x134,
    gravity: 0.003,
    vx: 0.85,
    vy: -0.55,
    spawn: (c, i, d)=>{
        const a = (c.random(0, 0x64) & 0xffff) > 0x46 ? 1 : 0;
        const b = (c.random(0, 0x64) & 0xffff) > 0x1e ? 1 : 0;
        d.w04 = a + b + 0x1cf;
        spawnNear(c, i, d, 0x28, 0x8c, 70.0);
    }
};
function child463(c, i, vx) {
    const ch = c.children[i];
    ch.vx = vx;
    if (childStep(c, i) && ch.frame >= childCount) c.freeChild(i);
}
registerChildren({
    416: (c, i)=>partner416(c, i, {
            camY: false,
            alt: false,
            stop: 0x2d
        }),
    417: (c, i)=>partner417(c, i, 0x5a, 2),
    418: (c, i)=>partner416(c, i, {
            camY: true,
            alt: false,
            stop: 0x4b
        }),
    419: (c, i)=>partner417(c, i, 0x96, 4),
    420: (c, i)=>partner416(c, i, {
            camY: true,
            alt: true,
            stop: 0x64
        }),
    421: (c, i)=>partner417(c, i, 0xc8, 6),
    437: child437,
    440: (c, i)=>child440(c, i, 1.2, 0.8),
    441: (c, i)=>child440(c, i, 1.6, 0.8),
    442: (c, i)=>child440(c, i, 2.0, 0.8),
    443: (c, i)=>child440(c, i, 0.5, 0.0),
    446: child446,
    447: child447,
    448: child448,
    449: child448,
    450: child448,
    451: child448,
    452: child448,
    454: (c, i)=>partner454(c, i, PARTNER454),
    455: (c, i)=>partner454(c, i, PARTNER455),
    456: (c, i)=>partner454(c, i, PARTNER456),
    463: (c, i)=>child463(c, i, 2.0),
    464: (c, i)=>child463(c, i, 2.5),
    465: (c, i)=>child463(c, i, 3.0)
});

export function __logicState(){return {P1000_T3,P2000_T3,P3000_T3,P1000_T0,P2000_T0,P3000_T0,PARTNER454,PARTNER455,PARTNER456};}

export function __installInitialRoots(s){
if(P1000_T3!==s["P1000_T3"])throw Error('INITIAL_CONST_IDENTITY:P1000_T3');
if(P2000_T3!==s["P2000_T3"])throw Error('INITIAL_CONST_IDENTITY:P2000_T3');
if(P3000_T3!==s["P3000_T3"])throw Error('INITIAL_CONST_IDENTITY:P3000_T3');
if(P1000_T0!==s["P1000_T0"])throw Error('INITIAL_CONST_IDENTITY:P1000_T0');
if(P2000_T0!==s["P2000_T0"])throw Error('INITIAL_CONST_IDENTITY:P2000_T0');
if(P3000_T0!==s["P3000_T0"])throw Error('INITIAL_CONST_IDENTITY:P3000_T0');
if(PARTNER454!==s["PARTNER454"])throw Error('INITIAL_CONST_IDENTITY:PARTNER454');
if(PARTNER455!==s["PARTNER455"])throw Error('INITIAL_CONST_IDENTITY:PARTNER455');
if(PARTNER456!==s["PARTNER456"])throw Error('INITIAL_CONST_IDENTITY:PARTNER456');
}
