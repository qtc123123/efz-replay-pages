let sourceLoopTimer = null;
import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { list, preload, readSync } from "./197efe2647ca25903d217eb5.mjs";
import { parseEffectPat } from "./fc9672cb87477a10c4e4290f.mjs";
import { setEffectPatterns } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { srand } from "./b095411d693646582d2f298b.mjs";
import { loadKeyIni, readKeyIniByte } from "./7f6020a950d8c30e51948660.mjs";
import { GameMode, gameState, loadBattleCommon, loadOptions } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { setTouchFunctionKeys } from "./5eb6ec5baba5ae2ef1895683.mjs";
import { checkFiles } from "./ed94471e7e2b500bb335f7ed.mjs";
import { CharacterSelectScene } from "./413f85bac525ebf5e75e7c4f.mjs";
import { LoadingScene } from "./f836a63a249111e2716c4368.mjs";
import { ConfigScene } from "./3199e8db2a5309a581f4d81b.mjs";
import { BattleScene } from "./fd36e47c48595d56412b79f4.mjs";
import { ResultScene } from "./cc70d292392eee89c1806e64.mjs";
import { initGraphics } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { initInput, isQuitRequested } from "./06124acd5a2cf7a08d774a8d.mjs";
import { initAudio, loadSystemSE } from "./4bc01372141f4e276b2208f4.mjs";
import { SceneMachine, State } from "./2215c2ad4aabedb03c1f6b16.mjs";
import { TitleScene } from "./e4dd01dc9059aff9b2f6d9cf.mjs";
import { StaffRollScene } from "./333eb7bf8acb5a80ebcf807a.mjs";
import { ReplayScene } from "./1a698cef549c091ba55e5149.mjs";
import { FrameTimer } from "./79570e25e06545d452dd916b.mjs";
function battleFunctionKeys() {
    const mode = gameState.mode;
    const keys = [];
    if (mode !== GameMode.Arcade && mode !== GameMode.Score && mode !== GameMode.Demo) keys.push("F4", "F5");
    if (mode === GameMode.Practice || mode === GameMode.Replay && gameState.replayMode === 2) keys.push("F6");
    if (mode === GameMode.Practice) keys.push("F7");
    keys.push("F8");
    return keys;
}
export async function startGame(canvas, onReady) {
    srand(1);
    initGraphics(canvas);
    await preload([
        "key.ini",
        ...list("system").filter((p)=>!p.startsWith("system/nl/"))
    ]);
    loadKeyIni();
    initInput();
    initAudio();
    void loadSystemSE();
    loadOptions(readKeyIniByte);
    gameState.fileCheck = checkFiles();
    const effectPat = readSync("system\\effect\\effect.pat");
    if (effectPat) setEffectPatterns(parseEffectPat(effectPat));
    loadBattleCommon();
    const machine = new SceneMachine();
    machine.scenes[State.Title] = new TitleScene();
    machine.scenes[State.CharacterSelect] = new CharacterSelectScene();
    machine.scenes[State.Loading] = new LoadingScene();
    machine.scenes[State.Battle] = new BattleScene();
    machine.scenes[State.Result] = new ResultScene();
    machine.scenes[State.Config] = new ConfigScene();
    machine.scenes[State.StaffRoll] = new StaffRollScene();
    machine.scenes[State.Replay] = new ReplayScene();
    __session.sourceReady(machine);
    onReady?.();
    const timer = sourceLoopTimer = new FrameTimer();
    while(await __session.nextOriginalUpdate()){
        await machine.tick();
        setTouchFunctionKeys(machine.current === State.Battle ? battleFunctionKeys() : []);
        await timer.wait();
    }
    machine.dispose();
    __session.originalLoopClosed();
}
export async function __prepareSourceSession(canvas) {
    srand(1);
    initGraphics(canvas);
    await preload([
        "key.ini",
        ...list("system").filter((p)=>!p.startsWith("system/nl/"))
    ]);
    loadKeyIni();
    initInput();
    initAudio();
    void loadSystemSE();
    loadOptions(readKeyIniByte);
    gameState.fileCheck = checkFiles();
    const effectPat = readSync("system\\effect\\effect.pat");
    if (effectPat) setEffectPatterns(parseEffectPat(effectPat));
    loadBattleCommon();
    const machine = new SceneMachine();
    machine.scenes[State.Title] = new TitleScene();
    machine.scenes[State.CharacterSelect] = new CharacterSelectScene();
    machine.scenes[State.Loading] = new LoadingScene();
    machine.scenes[State.Battle] = new BattleScene();
    machine.scenes[State.Result] = new ResultScene();
    machine.scenes[State.Config] = new ConfigScene();
    machine.scenes[State.StaffRoll] = new StaffRollScene();
    machine.scenes[State.Replay] = new ReplayScene();
    __session.sourceReady(machine);
    return machine;
}

export function __logicState(){return {sourceLoopTimer};}

export function __installInitialRoots(s){
sourceLoopTimer=s["sourceLoopTimer"];
}
