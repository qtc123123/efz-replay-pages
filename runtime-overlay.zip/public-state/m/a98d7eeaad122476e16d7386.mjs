import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { registerChildren, registerStates, setDefaultStateHandler } from "./dfcb3299a1af62aa24eb2aa0.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./e4446f6179e9bf5107313c92.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const JUMP_GRAVITY = 0.045;
const JUMP_VY = -3.0;
const JUMP_VY_STANCE1 = -2.0;
const JUMP_GRAVITY_STANCE1 = 0.02;
const w16 = (v)=>v & 0xffff;
function advance(c, dur, cnt) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return c.frame >= cnt;
}
function advanceChild(c, i, dur, cnt) {
    const ch = c.children[i];
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    return ch.frame >= cnt;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function landFromHit(c) {
    c.y = 0.0;
    if (c.d12c !== 0) c.setState(97);
    else c.setState(98);
}
function wallPush(c, y, k) {
    if (c.x - 20.0 <= 0.0 || !(c.x + 20.0 < 639.0)) {
        c.pushToOpponent = (1.0 - (y < 0.0 ? 1 : 0) * k) * c.vx;
    } else {
        c.pushToOpponent = 0.0;
    }
}
function rfDrain(c, v) {
    if (c.rfBlue !== 0) c.rfGauge -= v;
}
function fxAtSelf(c, pat, blend, layer) {
    const f = openSpawnFrame();
    f.w04 = pat;
    f.x = ftol(c.x);
    f.y = ftol(c.y);
    f.b20 = blend;
    f.b21 = layer;
    frameEffect(f);
}
function airLand(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function stateDefault(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.vx = 0.0;
    c.vy = 0.0;
    if (advance(c, dur, cnt)) c.frame = 0;
}
function walk(c, v1, v0) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.vx = v1;
    if (c.f3150 === 0) c.vx = v0;
    c.vy = 0.0;
    if (advance(c, dur, cnt)) c.frame = 0;
}
function state3(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.frame = 0;
}
function jumpLanding(c) {
    if (c.y + c.vy >= 0.0 && c.frame > 3) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function jump(c, vx, dashVx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        if (c.b158 === 0) c.faceOpponent();
        c.vx = 0.0;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.ay = JUMP_GRAVITY;
        c.vy = JUMP_VY;
        if (vx !== null) c.vx = vx;
        if (dashVx !== null && c.b158 === 1) {
            c.vx = dashVx;
            c.b158 = 0;
        }
        if (c.f3150 === 1) {
            c.vy = JUMP_VY_STANCE1;
            c.ay = JUMP_GRAVITY_STANCE1;
        }
    }
    if (c.frame > 3) c.vy += c.ay;
    if (advance(c, dur, cnt)) c.setState(9);
    jumpLanding(c);
}
function quickJump(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = JUMP_VY;
        c.vx = vx;
        c.ay = JUMP_GRAVITY;
        if (c.f3150 === 1) {
            c.vy = JUMP_VY_STANCE1;
            c.ay = JUMP_GRAVITY_STANCE1;
        }
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.setState(9);
    jumpLanding(c);
}
function transition(c, next) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(next);
}
function state9(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    c.b158 = 0;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.setState(13);
    }
}
function state13(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(c.inputY === 1 ? 3 : 0);
}
function state17(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = c.vx * 0.25;
        c.vy = c.vy * 0.25;
    }
    c.rfGauge = c.rfGauge - 1.0;
    if (atStart(c)) c.seRequest = 21;
    if (c.frame === 2 && c.timer === 0) c.seRequest = 21;
    if (c.inputY === 1 && c.f3138 > 2) {
        c.setState(9);
        return;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 2) {
            c.f3138++;
            if (c.f3138 < 2) c.frame = 0;
        }
        if (c.frame >= cnt) {
            c.frame = w16(c.frame - 2);
            c.f3138++;
            if (c.f3138 > 15) {
                c.onStateChange();
                c.state = 9;
                return;
            }
        }
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function state47(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.ay = 0.035;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 2) {
        c.timer = 0;
        c.frame = 2;
        c.seRequest = 7;
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.vx = 0.0;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 2) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) c.frame = w16(c.frame - 1);
    }
}
function hitStand(c, meter, k, guard, crouchable) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    c.b158 = 0;
    if (atStart(c)) {
        c.meter = s16(c.meter + meter);
        c.vx = (2.0 - c.opponent.proration / 10000.0) * k;
        rfDrain(c, guard);
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    wallPush(c, c.y, 0.2);
    if (advance(c, dur, cnt)) {
        if (crouchable) c.setState(c.inputY === 1 ? 3 : 0);
        else c.setState(3);
    }
}
function hitAir(c, wall, mix, clamp, ay) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (wall && c.frame > 0 && c.wallBlock() !== 0) {
        c.setState(70);
        return;
    }
    if (atStart(c)) {
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = mix ? c.vy * 0.75 + c.knockY : c.knockY;
        if (clamp !== null) {
            if (c.vy < clamp) c.vy = clamp;
            else if (c.vy > -0.5) c.vy = -0.5;
        }
        c.ay = ay;
    }
    c.vy += c.ay;
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 11) c.frame = 3;
        if (c.frame === 4 && c.vy > -0.5) c.frame = 11;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function state68(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    c.timer = w16(c.timer + 1);
    if (c.wallBlock() !== 0) {
        c.setState(70);
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state69(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    if (advance(c, dur, cnt)) c.frame = w16(c.frame - 2);
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state70(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (atStart(c) && c.f3138 === 0) {
        c.meter = s16(c.meter + 30);
        c.f3138++;
        c.hitstun = s16(c.hitstun + 120);
        c.vx = 0.5;
        c.vy = -2.5;
        c.ay = 0.025;
        c.seRequest = 0x1f;
        const f = openSpawnFrame();
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function grounded(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    c.b158 = 0;
    c.vx = 0.0;
    c.vy = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function slide(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    c.b158 = 0;
    if (atStart(c)) {
        c.meter = s16(c.meter + 30);
        rfDrain(c, 30.0);
        c.vx = 2.2;
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.ay = 0.0;
    c.ax = 0.06;
    c.vx -= c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function state81(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (atStart(c)) {
        const f = openSpawnFrame();
        f.w04 = 499;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b18 = c.facing;
        f.b21 = 1;
        frameChild(c, f);
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    c.vx += 0.02;
    c.vy += c.ay;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) c.frame = w16(c.frame - 1);
    if (c.y + c.vy >= 0.0 && c.frame === 1) landFromHit(c);
}
function state82(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (atStart(c) && c.f3138 === 0) {
        c.seRequest = 30;
        c.vy = -0.45;
        c.vx = -0.1;
        c.f3138++;
        c.meter = s16(c.meter + 30);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.ay = 0.032;
    }
    if (c.vy > 0.0 && c.frame === 4) {
        c.frame = 5;
        c.timer = 0;
    }
    if (c.frame > 3) c.vy += c.ay;
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 4 && c.f3138 < 8) {
            c.frame = 0;
            c.f3138++;
        }
        if (c.frame === 15) c.frame = 7;
        if (c.frame === 8 && c.vy > -0.5) c.frame = 15;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.y + c.vy >= 0.0 && c.frame > 5) landFromHit(c);
}
function spawn496(c) {
    if (c.f3154 === 0) {
        const f = openSpawnFrame();
        f.w04 = 496;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 0;
        f.b21 = 0;
        f.d00 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        c.f3154 = 1;
    }
}
function state83(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 33;
        c.vy = -1.5;
        c.vx = -0.8;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (c.frame === 0 && c.vy + c.y > 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        c.timer = 0;
        c.frame = 1;
        return;
    }
    if (c.frame === 1) c.vx += 0.01;
    if (c.frame === 2 && c.timer === 0) c.vx = -2.0;
    if (c.frame > 1) c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
}
function state85(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        spawn496(c);
        rfDrain(c, 30.0);
        c.seRequest = 33;
        c.vx = c.knockX;
        c.vy = c.knockY;
        c.meter = s16(c.meter + 30);
    }
    c.vy += 0.04;
    if (advance(c, dur, cnt)) {
        c.setState(0);
        c.faceOpponent();
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state86(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        spawn496(c);
        if (c.f3138 === 0) {
            rfDrain(c, 30.0);
            c.seRequest = 33;
            c.vx = c.knockX;
            c.vy = c.knockY;
            c.meter = s16(c.meter + 30);
            c.f3138++;
        }
    }
    c.vy += 0.06;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state87(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        const f = openSpawnFrame();
        f.w04 = 495;
        f.x = 60.0;
        f.y = 40.0;
        f.d24 = 1;
        f.b18 = 1;
        f.b20 = 0;
        f.b21 = 0;
        frameChild(c, f);
    }
    if (advance(c, dur, cnt)) c.setState(0);
}
function state96(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.y < 0.0) c.vy += 0.04;
    if (c.y + c.vy > 0.0 && c.frame > 1) {
        c.y = 0.0;
        c.vy = 0.0;
        c.timer = 0;
        c.frame = 7;
    }
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 1) c.vy = -1.0;
        if (c.frame === cnt - 1) c.faceOpponent();
        if (c.frame >= cnt) c.setState(c.inputY === 1 ? 3 : 0);
    }
}
function state97(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) {
        c.shakeScreen(3, 0);
        fxAtSelf(c, 3, 2, 0);
        c.seRequest = 7;
    }
    if (advance(c, dur, cnt)) c.setState(99);
}
function state99(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.timer = w16(c.timer + 1);
    c.b158 = 0;
    if (c.life > 0 && c.timer > 99 && c.frame === 0) c.setState(96);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(96);
    }
}
function guardGround(c, crouchState, standState, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouchState;
    if (c.inputY !== 1) c.state = standState;
    if (atStart(c)) {
        c.b158 = 0;
        c.meter = s16(c.meter + meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx = c.vx + 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || !(c.x + 20.0 < 639.0)) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) c.setState(c.inputY === 1 ? 3 : 0);
            else c.setState(3);
        }
    }
}
function state156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.b158 = 0;
        c.vy = -2.6;
        c.meter = s16(c.meter + 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy = c.vy + c.ay;
    if (advance(c, dur, cnt)) c.setState(9);
    airLand(c);
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.b158 = 0;
        c.vy = -2.3;
        fxAtSelf(c, 8, 2, 0);
    } else {
        c.vy = c.vy + c.ay;
    }
    if (advance(c, dur, cnt)) c.setState(9);
    airLand(c);
}
setDefaultStateHandler(stateDefault);
registerStates({
    1: (c)=>walk(c, 0.5, 0.7),
    2: (c)=>walk(c, -0.5, -0.7),
    3: state3,
    4: (c)=>jump(c, null, 0.4),
    5: (c)=>jump(c, 0.7, 1.1),
    6: (c)=>jump(c, -0.7, null),
    7: (c)=>transition(c, 0),
    8: (c)=>transition(c, 3),
    9: state9,
    13: state13,
    14: (c)=>quickJump(c, 0.0),
    15: (c)=>quickJump(c, 0.7),
    16: (c)=>quickJump(c, -0.7),
    17: state17,
    47: state47,
    50: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    51: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    52: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    53: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    54: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    55: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    56: (c)=>hitStand(c, 10, -1.1, 10.0, false),
    57: (c)=>hitStand(c, 15, -1.5, 20.0, false),
    58: (c)=>hitStand(c, 20, -1.8, 30.0, false),
    59: (c)=>hitAir(c, false, true, -2.0, 0.032),
    60: (c)=>hitAir(c, false, true, -4.0, 0.032),
    61: (c)=>hitAir(c, false, true, -6.0, 0.032),
    62: (c)=>hitAir(c, false, true, null, 0.032),
    63: (c)=>hitAir(c, false, false, null, 0.032),
    64: (c)=>hitAir(c, true, true, -2.0, 0.032),
    65: (c)=>hitAir(c, true, true, -4.0, 0.032),
    66: (c)=>hitAir(c, true, true, null, 0.032),
    67: (c)=>hitAir(c, true, false, null, 0.032),
    68: state68,
    69: state69,
    70: state70,
    71: (c)=>hitAir(c, false, false, null, 0.072),
    72: (c)=>grounded(c, true),
    73: (c)=>grounded(c, true),
    74: (c)=>grounded(c, false),
    75: (c)=>slide(c, true),
    76: (c)=>slide(c, true),
    77: (c)=>slide(c, false),
    81: state81,
    82: state82,
    83: state83,
    84: state83,
    85: state85,
    86: state86,
    87: state87,
    96: state96,
    97: state97,
    98: state97,
    99: state99,
    150: (c)=>guardGround(c, 153, 150, 10, -1.5, true),
    151: (c)=>guardGround(c, 154, 151, 15, -1.8, true),
    152: (c)=>guardGround(c, 155, 152, 20, -2.3, true),
    153: (c)=>guardGround(c, 153, 150, 10, -1.5, false),
    154: (c)=>guardGround(c, 154, 151, 15, -1.8, false),
    155: (c)=>guardGround(c, 155, 152, 20, -2.3, false),
    156: state156,
    157: (c)=>airRecover(c, 1.0),
    158: (c)=>airRecover(c, -1.0)
});
function coin() {
    return rand("src/game/chars/mio/states_template_a.ts:1019:8", {
        consumer: "src/game/chars/mio/states_template_a.ts"
    }) > 0x3e80 ? 1 : 0;
}
function debris(c, i, init, gravity) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    if (ch.frame === 0 && ch.timer === 0 && c.a3158[i] === 0) init();
    ch.vy += gravity;
    if (ch.y > 0.0 && ch.vy > 0.0) ch.vy = -ch.vy;
    if (c.a3258[i] < 10) ch.blend = 1;
    if (c.a3258[i] < 0) {
        c.freeChild(i);
        return;
    }
    ch.timer = w16(ch.timer + 1);
    c.a3258[i]--;
    if (advanceChild(c, i, dur, cnt)) ch.frame = 0;
}
function child495(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.vx = -0.02;
    ch.drawWhileFrozen = 30000;
    ch.timer = w16(ch.timer + 1);
    if (c.state !== 87) c.freeChild(i);
    if (advanceChild(c, i, dur, cnt)) ch.frame = 0;
}
function child496(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    const s = c.state;
    const inStates = s === 83 || s === 84 || s === 85 || s === 86;
    const burst = !inStates || (s === 83 || s === 84) && c.frame > 1;
    if (burst) {
        const f = childSpawnFrame;
        const pieces = [
            [
                497,
                23,
                -4
            ],
            [
                497,
                -4,
                -6
            ],
            [
                497,
                -14,
                -26
            ],
            [
                497,
                0,
                0
            ],
            [
                497,
                30,
                -40
            ],
            [
                497,
                -25,
                -80
            ],
            [
                498,
                -35,
                -42
            ],
            [
                498,
                -18,
                -20
            ],
            [
                498,
                2,
                -65
            ],
            [
                498,
                16,
                -80
            ]
        ];
        for (const [pattern, dx, dy] of pieces){
            f.w04 = pattern;
            f.x = ftol(c.x) + c.facing * dx;
            f.y = ftol(c.y) + dy;
            f.b20 = 0;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
        }
        c.seRequest = 34;
        c.freeChild(i);
        c.f3154 = 0;
        return;
    }
    ch.timer = w16(ch.timer + 1);
    if (advanceChild(c, i, dur, cnt)) ch.frame = 0;
}
function child497(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 40;
        c.a3258[i] = r1 + coin() * 20 + 80;
        c.a3158[i]++;
        const t1 = coin() * 1.2;
        const t2 = coin() * 0.7 + t1;
        ch.vx = coin() * 1.7 + t2 + -1.8;
        const u1 = coin() * 0.6;
        const u2 = coin() * 0.9 + u1;
        ch.vy = -1.2 - (coin() * 1.4 + u2);
    }, 0.05);
}
function child498(c, i) {
    const ch = c.children[i];
    debris(c, i, ()=>{
        const r1 = coin() * 60;
        c.a3258[i] = r1 + coin() * 40 + 120;
        c.a3158[i]++;
        const t1 = coin();
        const t2 = coin() * 0.5 + t1;
        ch.vx = coin() * 1.5 + t2 + -1.5;
        const u1 = coin() * 0.5;
        const u2 = coin() * 0.8 + u1;
        ch.vy = -1.0 - (coin() * 1.2 + u2);
    }, 0.03);
}
function child499(c, i) {
    const ch = c.children[i];
    const dur = childDuration;
    const cnt = childCount;
    ch.x = c.x;
    ch.y = c.y;
    ch.timer = w16(ch.timer + 1);
    if (advanceChild(c, i, dur, cnt)) c.freeChild(i);
}
registerChildren({
    495: child495,
    496: child496,
    497: child497,
    498: child498,
    499: child499
});

export function __logicState(){return {JUMP_VY,JUMP_VY_STANCE1};}

export function __installInitialRoots(s){
if(JUMP_VY!==s["JUMP_VY"])throw Error('INITIAL_CONST_IDENTITY:JUMP_VY');
if(JUMP_VY_STANCE1!==s["JUMP_VY_STANCE1"])throw Error('INITIAL_CONST_IDENTITY:JUMP_VY_STANCE1');
}
