import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { createImage, loadDat } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { preload } from "./197efe2647ca25903d217eb5.mjs";
import { replayPath } from "./8d7f594b1298130b3a745321.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { blit, loadPalette, makeRect, present } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { playBGM } from "./4bc01372141f4e276b2208f4.mjs";
import { FadeMode, Scene, fadeIn, fadeOut } from "./494d0271e10bf938cecabb23.mjs";
import { GameMode, gameState as gs, loadStageBackground } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { createCharacter } from "./3c855c5012961734a479c319.mjs";
import { resetBattleState } from "./fd36e47c48595d56412b79f4.mjs";
import { buildBlendTables } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { preloadWaves } from "./4bc01372141f4e276b2208f4.mjs";
import { State } from "./2215c2ad4aabedb03c1f6b16.mjs";
import { CHARACTER_STAGE, STAGE_COUNT, isCharacterLocked, isStageLocked } from "./ed94471e7e2b500bb335f7ed.mjs";
const ILLUSTRATION_COUNT = 175;
export class LoadingScene extends Scene {
    surf = createImage(0, 0);
    async update() {
        const file = `system\\nl\\nl${String(rand("src/game/scene_loading.ts:37:39", {
            consumer: "LoadingScene.update"
        }) % ILLUSTRATION_COUNT).padStart(3, "0")}.dat`;
        await preload([
            file
        ]);
        this.surf = loadDat(file, 0, 1);
        loadPalette(this.palette, file, 0, 1, 254);
        this.render();
        await fadeIn(this, FadeMode.Black);
        await this.loadBattleData();
        await fadeOut(this, FadeMode.Black, -500, 200);
        this.surf = createImage(0, 0);
        playBGM(gs.stage + 10);
        return State.Battle;
    }
    async loadBattleData() {
        if (gs.mode === GameMode.Arcade && !gs.continued || gs.mode === GameMode.Score) {
            this.chooseOpponent();
        } else if (gs.mode === GameMode.Demo) {
            this.chooseDemo();
        } else if (gs.mode === GameMode.Replay) {
            this.openReplay();
        }
        loadStageBackground(gs.stage);
        const chars = [];
        for(let side = 0; side < 2; side++){
            const f = gs.fighters[side];
            const prev = gs.chars[side];
            if (prev) {
                chars.push(prev);
                continue;
            }
            const c = createCharacter(f?.id ?? 0, side);
            c.color = f?.color ?? 0;
            c.isCPU = f?.isCPU ?? 0;
            chars.push(c);
        }
        chars[0].opponent = chars[1];
        chars[1].opponent = chars[0];
        gs.chars = [
            chars[0],
            chars[1]
        ];
        await preload(chars.flatMap((c)=>c.files()));
        for (const c of chars){
            c.load();
            c.aiLevel = gs.mode === GameMode.Score ? Math.fround(gs.round / 1.5) : gs.option3;
        }
        await preloadWaves(chars.flatMap((c)=>c.files().filter((p)=>p.endsWith(".wav"))));
        resetBattleState();
        buildBlendTables(gs.palette);
    }
    chooseOpponent() {
        const human = gs.cpuSide[0] ? 1 : 0;
        const cpu = 1 - human;
        let id;
        const boss = gs.mode === GameMode.Arcade ? gs.round === 8 ? gs.fileCheck === 0 || gs.continueRound !== 0 && gs.continueRound !== 8 ? 24 : 19 : -1 : gs.round === 7 ? 24 : gs.round === 8 ? gs.fileCheck === 0 ? 24 : 19 : -1;
        if (boss >= 0) {
            id = boss;
        } else {
            do {
                id = rand("src/game/scene_loading.ts:107:9", {
                    consumer: "LoadingScene.chooseOpponent"
                }) % 24;
            }while (gs.defeatedMask & 1 << id || id === 18 || id === 19 || id === 22 || isCharacterLocked(id, gs.fileCheck))
        }
        this.createCPU(cpu, human, id);
        gs.stage = CHARACTER_STAGE[id] ?? 0;
    }
    chooseDemo() {
        for(let side = 0; side < 2; side++){
            let id;
            do {
                id = rand("src/game/scene_loading.ts:119:9", {
                    consumer: "LoadingScene.chooseDemo"
                }) % 24;
            }while (id === 19 || id === 22 || isCharacterLocked(id, gs.fileCheck))
            this.createCPU(side, 1 - side, id);
        }
        gs.fighters[0].color = 0;
        gs.fighters[1].color = gs.fighters[1].id === gs.fighters[0].id ? 1 : 0;
        let stage;
        do {
            stage = rand("src/game/scene_loading.ts:129:11", {
                consumer: "LoadingScene.chooseDemo"
            }) % STAGE_COUNT;
        }while (isStageLocked(stage, gs.fileCheck))
        gs.stage = stage;
        gs.usePal[0] = 0;
        gs.usePal[1] = 0;
    }
    openReplay() {
        const path = replayPath(gs.replayCol + 1, gs.replayRow + 1);
        const file = gs.replayFile;
        const s8 = (v)=>v << 24 >> 24;
        if (gs.replayMode === 1) {
            file.openRead(path);
            for(let side = 0; side < 2; side++){
                gs.fighters[side] = {
                    id: s8(file.readWord()),
                    color: 0,
                    isCPU: gs.cpuSide[side]
                };
            }
            gs.stage = s8(file.readWord());
            if (gs.stage > 100) {
                gs.replayVersion = gs.stage;
                gs.stage = s8(file.readWord());
            } else {
                gs.replayVersion = 0;
            }
            gs.fighters[0].color = s8(file.readWord());
            gs.fighters[1].color = s8(file.readWord());
        } else if (gs.replayMode === 2) {
            file.create(path);
            const [f1, f2] = gs.fighters;
            file.writeWord(f1?.id ?? 0);
            file.writeWord(f2?.id ?? 0);
            file.writeWord(0x68);
            file.writeWord(gs.stage);
            file.writeWord(f1?.color ?? 0);
            file.writeWord(f2?.color ?? 0);
        }
    }
    createCPU(side, other, id) {
        const opp = gs.fighters[other];
        const color = opp && opp.id === id && opp.color === 0 ? 1 : 0;
        gs.fighters[side] = {
            id,
            color,
            isCPU: 1
        };
    }
    render() {
        __session.render();
        blit(makeRect(0, 0, 320, 240), this.surf, makeRect(0, 0, 320, 240), 0);
        present();
    }
}
