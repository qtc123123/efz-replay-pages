import {bind} from "./d2882f15591f302cc6d00380.mjs";
import {moduleRoots} from "./33129031b2b9f03f12e9853d.mjs";
import {rootWriters} from "./3af6b666ad269deb227fc089.mjs";
import {gameState,loadBattleCommon} from "./11a8544a0f705ad2a3ee4f96.mjs";
import {SceneMachine} from "./2215c2ad4aabedb03c1f6b16.mjs";
import {BattleScene} from "./fd36e47c48595d56412b79f4.mjs";
import {mountFiles,preload,readSync} from "./197efe2647ca25903d217eb5.mjs";
import {parseEffectPat} from "./fc9672cb87477a10c4e4290f.mjs";
import {setEffectPatterns} from "./7f2701ba2d6ce15107cdc8f7.mjs";
import {setInstantSleepForTrace} from "./79570e25e06545d452dd916b.mjs";
import {__inputState,initInput} from "./06124acd5a2cf7a08d774a8d.mjs";
import {backBuffer,activePaletteForTrace,initGraphics} from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import {__audioState,initAudio} from "./4bc01372141f4e276b2208f4.mjs";
import policy from "./d3bf6d242edb41cf3b92234f.mjs";
const need=(ok,code)=>{if(!ok)throw Error('BATTLE_RENDER_'+code);};
/** Exactly one instance per dedicated module realm/Worker. */
export function createRenderedBattlePort(resources){
 let state='fresh',prepared=false,busy=false,machine=null;
 return Object.freeze({
  async prepare(hooks){
   need(!prepared,'PREPARE_ONCE');prepared=true;need(state==='fresh','NOT_READY');
   try{
    bind({...hooks,storage:{getItem(){throw Error('BATTLE_STORAGE_FORBIDDEN');},setItem(){throw Error('BATTLE_STORAGE_FORBIDDEN');}}});
    mountFiles(resources);setInstantSleepForTrace(true);initGraphics(null);initInput();initAudio();
    await preload(['system/effect/effect.pat','system/effect/effect.dat','system/object.dat']);
    const pat=readSync('system/effect/effect.pat');need(pat&&readSync('system/effect/effect.dat')&&readSync('system/object.dat'),'COMMON_ASSETS');
    setEffectPatterns(parseEffectPat(pat));loadBattleCommon();
    machine=new SceneMachine();machine.scenes[3]=new BattleScene();hooks.startSession();state='prepared';
   }catch(error){state='failed';throw error;}
  },
  phase(){return machine?.current??0;},
  status(){return state;},
  snapshot(){need(state!=='failed'&&state!=='closed','FAILED');need(machine,'NOT_READY');return {modules:moduleRoots(),scene:machine.current,machine,gameState,input:__inputState(),backBuffer,palette:activePaletteForTrace(),audio:__audioState(),storage:[]};},
  __beginBattleInstall(){need(state==='prepared','INSTALL_ONCE');state='installing';},
  __finishBattleInstall(){need(state==='installing'&&machine.current===3,'INSTALL_STATE');state='battle';},
  __failBattleInstall(){if(state!=='closed')state='failed';},
  __installBattleRoots(world,battle,modules,selection){
   need(state==='installing','INSTALL_STATE');
   for(const key of policy.worldFields)gameState[key]=world[key];
   for(const [file,fields]of Object.entries(modules)){
    const mapped=file==='src/game/sound_events.mjs'?'src/platform/audio.mjs':file;
    need(policy.moduleFields[file]&&rootWriters[mapped],'MODULE');
    // Writers also contain immutable fields. Keep these locally pinned values;
    // the untrusted public payload supplies only admitted mutable fields.
    rootWriters[mapped]({...moduleRoots()[mapped],...fields});
   }
   if(selection){gameState.stage=selection.stage;gameState.usePal=[...selection.usePal];}
   machine.scenes[3]=battle;machine.current=3;
  },
  async tick(){
   need(state==='battle'&&!busy,'NOT_READY');busy=true;
   try{await machine.tick();if(machine.current!==3)state='terminal';}
   catch(error){state='failed';throw error;}finally{busy=false;}
  },
  async dispose(){if(state==='closed')return;state='closed';mountFiles([]);machine?.scenes.fill(null);machine=null;}
 });
}
