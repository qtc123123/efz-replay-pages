import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { loadDat } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { blit, loadPalette, makeRect, present, readColorKey, setPalette } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { playSE } from "./4bc01372141f4e276b2208f4.mjs";
import { checkEscapeKey, pollInput, requestQuit } from "./06124acd5a2cf7a08d774a8d.mjs";
import { FadeMode, Scene, fadeIn, fadeOut } from "./494d0271e10bf938cecabb23.mjs";
import { GameMode, gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { State } from "./2215c2ad4aabedb03c1f6b16.mjs";
const TITLE_DAT = "system\\title.dat";
const TITLE_OB_DAT = "system\\title_ob.dat";
const MENU_LAST = 6;
const MENU_ITEM_HEIGHT = 14;
const IDLE_LIMIT = 1800;
export class TitleScene extends Scene {
    surfBG = loadDat(TITLE_DAT, 0, 1);
    surfOB = loadDat(TITLE_OB_DAT, 0, 193);
    colorKey;
    cursor = 0;
    latch = [
        0,
        0
    ];
    idleTimer = 0;
    constructor(){
        super();
        loadPalette(this.palette, TITLE_DAT, 0, 1, 192);
        loadPalette(this.palette, TITLE_OB_DAT, 0, 193, 48);
        this.colorKey = readColorKey(this.surfOB);
        this.enterState = 1;
    }
    async update() {
        switch(this.enterState){
            case 1:
                this.enterState = 0;
                setPalette(this.palette);
                break;
            case 2:
                await fadeIn(this, FadeMode.White);
                this.enterState = 0;
                break;
            case 3:
                setPalette(this.palette);
                await fadeIn(this, FadeMode.White);
                this.enterState = 0;
                break;
        }
        if (this.idleTimer > IDLE_LIMIT) {
            this.idleTimer = 0;
            gs.mode = GameMode.Demo;
            await fadeOut(this, FadeMode.White, 0, 0);
            this.enterState = 2;
            return State.Loading;
        }
        if (checkEscapeKey()) requestQuit();
        pollInput();
        for(let p = 0; p < 2; p++){
            const v = gs.input[p].moveY;
            if (!this.latch[p] && v !== 0) {
                playSE(8);
                this.cursor += v;
                if (this.cursor > MENU_LAST) this.cursor = 0;
                if (this.cursor < 0) this.cursor = MENU_LAST;
                this.latch[p] = 1;
            }
            if (v === 0) {
                this.latch[p] = 0;
                this.idleTimer++;
            } else {
                this.idleTimer = 0;
            }
            if (gs.input[p].a === 1) {
                gs.lastTitleCursor = this.cursor;
                const next = await this.select(p);
                if (next !== null) return next;
            }
        }
        this.render();
        return State.Title;
    }
    async select(p) {
        const human = [
            p === 1 ? 1 : 0,
            p === 0 ? 1 : 0
        ];
        const enter = async ()=>{
            playSE(6);
            await fadeOut(this, FadeMode.White, 0, 0);
        };
        switch(this.cursor){
            case 0:
                await enter();
                gs.cpuSide = human;
                gs.startPlayer = p;
                gs.mode = GameMode.Arcade;
                gs.winRounds = 2;
                this.enterState = 2;
                return State.CharacterSelect;
            case 1:
                await enter();
                gs.cpuSide = human;
                gs.mode = GameMode.VsCom;
                gs.winRounds = gs.winRoundsConfig;
                this.enterState = 2;
                return State.CharacterSelect;
            case 2:
                await enter();
                gs.cpuSide = [
                    0,
                    0
                ];
                gs.mode = GameMode.VsPlayer;
                gs.winRounds = gs.winRoundsConfig;
                this.enterState = 2;
                return State.CharacterSelect;
            case 3:
                await enter();
                gs.cpuSide = human;
                gs.startPlayer = p;
                gs.mode = GameMode.Practice;
                gs.winRounds = 2;
                this.enterState = 2;
                return State.CharacterSelect;
            case 4:
                await enter();
                gs.cpuSide = [
                    0,
                    0
                ];
                gs.mode = GameMode.Replay;
                gs.winRounds = 2;
                this.enterState = 3;
                return State.Replay;
            case 5:
                await enter();
                this.enterState = 3;
                return State.Config;
            default:
                requestQuit();
                return null;
        }
    }
    render() {
        __session.render();
        blit(makeRect(0, 0, 320, 240), this.surfBG, makeRect(0, 0, 320, 240), 0);
        blit(makeRect(195, 130, 120, 98), this.surfOB, makeRect(0, 0, 120, 98), this.colorKey);
        const y = MENU_ITEM_HEIGHT * this.cursor;
        blit(makeRect(195, 130 + y, 120, MENU_ITEM_HEIGHT), this.surfOB, makeRect(0, 98 + y, 120, MENU_ITEM_HEIGHT), this.colorKey);
        present();
    }
    static files = [
        TITLE_DAT,
        TITLE_OB_DAT
    ];
}
