const need=(v,c)=>{if(!v)throw Error('INITIAL_FETCH_'+c);};
export const webSHA256=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
export async function fetchInitialArtifact(origin,descriptor,{fetcher=fetch,signal,hashBytes=webSHA256}={}){
 const base=new URL(origin);need(base.protocol==='https:'&&!base.username&&!base.password&&base.pathname==='/'&&!base.search&&!base.hash,'ORIGIN');
 const d=descriptor;need(d?.profile==='efz-public-battle/1'&&Number.isInteger(d.byteLength)&&d.byteLength>0&&d.byteLength<=1048576&&/^[a-f0-9]{64}$/.test(d.sha256)&&Number.isInteger(d.epoch)&&d.epoch>=1&&d.epoch<=2147483647,'DESCRIPTOR');
 const bytes=new Uint8Array(d.byteLength);
 try{
  for(let offset=0;offset<bytes.length;){
   signal?.throwIfAborted();const length=Math.min(4096,bytes.length-offset);
   const url=new URL('/api/live/artifacts/'+d.sha256,base);url.searchParams.set('epoch',String(d.epoch));url.searchParams.set('offset',String(offset));url.searchParams.set('length',String(length));
   const r=await fetcher(url.href,{signal,credentials:'omit',redirect:'error',cache:'no-store'});need(r.ok&&r.body,'HTTP');
   if(r.headers.get('content-type')?.split(';')[0].trim().toLowerCase()!=='application/octet-stream'){await r.body.cancel().catch(()=>{});throw Error('INITIAL_FETCH_TYPE');}
   const declared=r.headers.get('content-length'),encoding=r.headers.get('content-encoding')?.trim().toLowerCase();if((!encoding||encoding==='identity')&&declared!==null&&Number(declared)!==length){await r.body.cancel().catch(()=>{});throw Error('INITIAL_FETCH_EXTENT');}
   const reader=r.body.getReader();let got=0;
   try{for(;;){const {done,value}=await reader.read();if(done)break;need(value instanceof Uint8Array&&got+value.length<=length,'EXTENT');bytes.set(value,offset+got);got+=value.length;}need(got===length,'EXTENT');}
   catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
   offset+=length;
  }
  signal?.throwIfAborted();need(await hashBytes(bytes)===d.sha256,'DIGEST');return bytes;
 }catch(error){bytes.fill(0);throw error;}
}
