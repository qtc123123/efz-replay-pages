const need=(v,c)=>{if(!v)throw Error('INITIAL_FETCH_'+c);};
export const webSHA256=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
/** Two body-inclusive streams, at most 40 starts/s per fetch; no retries or shared cache. */
export async function fetchInitialArtifact(origin,descriptor,{fetcher=fetch,signal,hashBytes=webSHA256}={}){
 const base=new URL(origin);need(base.protocol==='https:'&&!base.username&&!base.password&&base.pathname==='/'&&!base.search&&!base.hash,'ORIGIN');
 const d={profile:descriptor?.profile,byteLength:descriptor?.byteLength,sha256:descriptor?.sha256,epoch:descriptor?.epoch};need(d.profile==='efz-public-battle/1'&&Number.isInteger(d.byteLength)&&d.byteLength>0&&d.byteLength<=1048576&&/^[a-f0-9]{64}$/.test(d.sha256)&&Number.isInteger(d.epoch)&&d.epoch>=1&&d.epoch<=2147483647,'DESCRIPTOR');
 signal?.throwIfAborted();const bytes=new Uint8Array(d.byteLength),controller=new AbortController(),local=controller.signal,readers=new Set();let next=0;
 const stop=reason=>{if(!local.aborted)controller.abort(reason);};
 const externalAbort=()=>stop(signal.reason);
 const cancelReaders=()=>{for(const reader of readers)void reader.cancel().catch(()=>{});};
 local.addEventListener('abort',cancelReaders,{once:true});signal?.addEventListener('abort',externalAbort,{once:true});
 // Serialize admission only, not response bodies. No accumulated credits after a stall.
 let admission=Promise.resolve(),lastStart=-Infinity;
 function pacedStart(start){
  const granted=admission.then(async()=>{
   local.throwIfAborted();
   while(performance.now()-lastStart<25){
    const delay=25-(performance.now()-lastStart);
    await new Promise((resolve,reject)=>{
     const abort=()=>{clearTimeout(timer);local.removeEventListener('abort',abort);reject(local.reason);};
     const timer=setTimeout(()=>{local.removeEventListener('abort',abort);resolve();},Math.max(1,Math.ceil(delay)));
     local.addEventListener('abort',abort,{once:true});if(local.aborted)abort();
    });
    local.throwIfAborted();
   }
   lastStart=performance.now();return {response:start()};
  });
  admission=granted.then(()=>{},()=>{});
  return granted.then(({response})=>response);
 }
 async function chunk(offset,length){
  let response,reader,complete=false;
  try{
   local.throwIfAborted();const url=new URL('/api/live/artifacts/'+d.sha256,base);url.searchParams.set('epoch',String(d.epoch));url.searchParams.set('offset',String(offset));url.searchParams.set('length',String(length));
   response=await pacedStart(()=>fetcher(url.href,{signal:local,credentials:'omit',redirect:'error',cache:'no-store'}));local.throwIfAborted();need(response.ok&&response.body,'HTTP');
   need(response.headers.get('content-type')?.split(';')[0].trim().toLowerCase()==='application/octet-stream','TYPE');
   const declared=response.headers.get('content-length'),encoding=response.headers.get('content-encoding')?.trim().toLowerCase();if((!encoding||encoding==='identity')&&declared!==null)need(Number(declared)===length,'EXTENT');
   reader=response.body.getReader();readers.add(reader);let got=0;
   for(;;){local.throwIfAborted();const {done,value}=await reader.read();local.throwIfAborted();if(done)break;need(value instanceof Uint8Array&&got+value.length<=length,'EXTENT');bytes.set(value,offset+got);got+=value.length;}
   need(got===length,'EXTENT');complete=true;
  }catch(error){stop(error);throw error;}
  finally{if(reader){readers.delete(reader);if(!complete)await reader.cancel().catch(()=>{});reader.releaseLock();}else if(response?.body)await response.body.cancel().catch(()=>{});}
 }
 async function worker(){for(;;){local.throwIfAborted();if(next>=bytes.length)return;const offset=next,length=Math.min(4096,bytes.length-offset);next+=length;await chunk(offset,length);}}
 try{
  // Join every worker before returning or wiping, preventing late completion writes.
  const results=await Promise.allSettled(Array.from({length:Math.min(2,Math.ceil(bytes.length/4096))},()=>worker()));
  local.throwIfAborted();const rejected=results.find(r=>r.status==='rejected');if(rejected)throw rejected.reason;
  const digest=await hashBytes(bytes);local.throwIfAborted();need(digest===d.sha256,'DIGEST');return bytes;
 }catch(error){stop(error);bytes.fill(0);throw error;}
 finally{signal?.removeEventListener('abort',externalAbort);local.removeEventListener('abort',cancelReaders);}
}
