import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { loadDat } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { parseEffectPat } from "./fc9672cb87477a10c4e4290f.mjs";
import { readSync } from "./197efe2647ca25903d217eb5.mjs";
import { blit, blitBlend, makeRect, readColorKey } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
function stageDir(stage) {
    return `${stage >= 10 ? "system\\bg\\bg" : "system\\bg\\bg0"}${stage}`;
}
export class StageObject {
    stage;
    lastImage;
    images = [];
    instances = [];
    patterns = [];
    colorKey = 0;
    constructor(stage, lastImage, count, layerOf){
        this.stage = stage;
        this.lastImage = lastImage;
        this.loadImages();
        this.loadPatterns();
        for(let i = 0; i < count; i++){
            this.instances.push({
                pattern: i,
                frame: 0,
                tick: 0,
                x: 0.0,
                y: -450.0,
                dir: 1,
                blend: 2,
                layer: layerOf(i) & 0xff
            });
        }
    }
    loadImages() {
        for(let i = 0; i <= this.lastImage; i++){
            const num = i >= 100 ? `\\${i}` : i >= 10 ? `\\0${i}` : `\\00${i}`;
            this.images[i] = loadDat(`${stageDir(this.stage)}${num}.dat`, 0, 1);
        }
        this.colorKey = this.images[0] ? readColorKey(this.images[0]) : 0;
    }
    loadPatterns() {
        const name = this.stage >= 10 ? `\\bg${this.stage}` : `\\bg0${this.stage}`;
        const data = readSync(`${stageDir(this.stage)}${name}.pat`);
        if (!data) {
            console.warn(`[stage] 找不到舞台 ${this.stage} 的 .pat`);
            return;
        }
        this.patterns = parseEffectPat(data);
    }
    animate() {
        for (const inst of this.instances){
            const pat = this.patterns[inst.pattern];
            const fr = pat?.frames[inst.frame];
            if (!pat || !fr) continue;
            if (inst.pattern < 0 || inst.pattern > 1) continue;
            inst.tick = inst.tick + 1 & 0xffff;
            if (inst.tick < (fr.duration & 0xffff)) continue;
            inst.tick = 0;
            inst.frame = inst.frame + 1 & 0xffff;
            if (inst.frame >= pat.count) inst.frame = 0;
        }
    }
    drawInstance(inst, camX, camY, dx) {
        const fr = this.patterns[inst.pattern]?.frames[inst.frame];
        if (!fr) return;
        const surf = this.images[fr.sprite];
        if (!surf) return;
        const src = makeRect(0, 0, fr.width, fr.height);
        const flip = inst.dir === -1;
        const left = (flip ? Math.trunc(inst.x) + camX - (fr.width - fr.offsetX) : Math.trunc(inst.x) + camX - fr.offsetX) + dx(fr.width);
        const top = camY + Math.trunc(inst.y) + 0xd2 - fr.offsetY;
        const dst = makeRect(left, top, fr.width, fr.height);
        if (inst.blend > 0) blitBlend(dst, surf, src, this.colorKey, flip, inst.blend - 1);
        else blit(dst, surf, src, this.colorKey, flip);
    }
}
class Stage1Object extends StageObject {
    constructor(){
        super(1, 0x39, 2, ()=>0);
    }
    update() {
        this.animate();
    }
    draw(camX, camY, layer) {
        if (layer === 1) return;
        for (const inst of this.instances)this.drawInstance(inst, camX, camY, ()=>0);
    }
}
class Stage10Object extends StageObject {
    constructor(){
        super(10, 4, 1, ()=>1);
    }
    update() {
        this.animate();
    }
    draw(camX, camY, layer) {
        if (layer === 0) return;
        for (const inst of this.instances)this.drawInstance(inst, camX, camY, ()=>0);
    }
}
class Stage12Object extends StageObject {
    constructor(){
        super(12, 1, 2, (i)=>1 - i);
    }
    update() {
        for (const inst of this.instances){
            if (inst.pattern !== 0 && inst.pattern !== 1) continue;
            if (inst.pattern === 0) {
                inst.x += 0.5;
                if (!(inst.x < 640.0)) inst.x = 0.0;
            }
            inst.x += 0.25;
            if (!(inst.x < 640.0)) inst.x = 0.0;
        }
    }
    draw(camX, camY, layer) {
        for (const inst of this.instances){
            if (layer !== inst.layer) continue;
            this.drawInstance(inst, camX, camY, ()=>0);
            this.drawInstance(inst, camX, camY, ()=>-0x280);
        }
    }
}
class Stage16Object extends StageObject {
    constructor(){
        super(16, 3, 4, (i)=>i > 1 ? 1 : 0);
    }
    update() {
        for (const inst of this.instances){
            switch(inst.pattern){
                case 0:
                    inst.x += 1.0;
                    if (!(inst.x < 850.0)) inst.x -= 850.0;
                    break;
                case 1:
                    inst.x += 1.4;
                    if (!(inst.x < 806.0)) inst.x -= 806.0;
                    break;
                case 2:
                    inst.x += 1.8;
                    if (!(inst.x < 789.0)) inst.x -= 789.0;
                    break;
                case 3:
                    inst.x += 2.2;
                    if (!(inst.x < 947.0)) inst.x = 947.0;
                    break;
            }
        }
    }
    draw(camX, camY, layer) {
        for (const inst of this.instances){
            if (layer !== inst.layer) continue;
            this.drawInstance(inst, camX, camY, ()=>0);
            this.drawInstance(inst, camX, camY, (w)=>-w);
        }
    }
}
export function createStageObject(stage) {
    switch(stage){
        case 1:
            return new Stage1Object();
        case 10:
            return new Stage10Object();
        case 12:
            return new Stage12Object();
        case 16:
            return new Stage16Object();
        default:
            return null;
    }
}
