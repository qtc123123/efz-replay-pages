import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { createImage, loadDat } from "./eb4b977c284a5c8b3f4dda6f.mjs";
import { preload } from "./197efe2647ca25903d217eb5.mjs";
import { writeKeyIniByte } from "./7f6020a950d8c30e51948660.mjs";
import { readRec } from "./ad76ef61597c869da76b5edb.mjs";
import { blit, loadPalette, makeRect, present, readColorKey, setPalette, setPaletteDarken } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { playBGM, playSE, stopBGM } from "./4bc01372141f4e276b2208f4.mjs";
import { checkEscapeKey, pollInput } from "./06124acd5a2cf7a08d774a8d.mjs";
import { FadeMode, Scene, fadeIn, fadeOut } from "./494d0271e10bf938cecabb23.mjs";
import { gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { State } from "./2215c2ad4aabedb03c1f6b16.mjs";
import { winSleep } from "./79570e25e06545d452dd916b.mjs";
const BG_DAT = "system\\config_bg.dat";
const OB_DAT = "system\\config_ob.dat";
const SCORE_DAT = "system\\score.dat";
const SCORE_NAMES = [
    "nanase",
    "ayu",
    "mai",
    "makoto",
    "akane",
    "mayu",
    "nagamori",
    "misaki",
    "shiori",
    "sayuri",
    "nayuki",
    "mio",
    "misuzu",
    "minagi",
    "kano",
    "mizukab",
    "exnanase",
    "kaori",
    "ikumi",
    "mishio",
    "nayukib",
    "akiko",
    "kanna"
];
const MENU_LAST = 7;
const GALLERY_LAST = 0xae;
var Mode = /*#__PURE__*/ function(Mode) {
    Mode[Mode["Menu"] = 0] = "Menu";
    Mode[Mode["Score"] = 1] = "Score";
    Mode[Mode["Gallery"] = 2] = "Gallery";
    return Mode;
}(Mode || {});
const sleep = winSleep;
const cosd = (deg)=>__numerics.cos(deg / 57.29579143313326);
export class ConfigScene extends Scene {
    surfBG = loadDat(BG_DAT, 0, 1);
    surfOB = loadDat(OB_DAT, 0, 0xa1);
    surfScore = loadDat(SCORE_DAT, 0, 0xa1);
    surfPortrait = createImage(0, 0);
    surfGallery = createImage(0, 0);
    obKey;
    scoreKey;
    portraitKey = 0;
    cursor = 0;
    scoreIndex = 0;
    latch = [
        0,
        0
    ];
    mode = 0;
    rec = new Int32Array(8);
    portraitX = 0;
    slide = 0;
    galleryIndex = 0;
    exit = 0;
    tick = 0;
    constructor(){
        super();
        loadPalette(this.palette, BG_DAT, 0, 1, 0xa1);
        loadPalette(this.palette, OB_DAT, 0, 0xa2, 0x20);
        this.obKey = readColorKey(this.surfOB);
        this.scoreKey = readColorKey(this.surfScore);
        this.enterState = 1;
    }
    async step() {
        this.render();
        await sleep(this.tick++ % 2 === 0 ? 16 : 15);
    }
    async update() {
        if (checkEscapeKey()) this.exit = 1;
        if (this.enterState === 1) {
            this.cursor = 0;
            this.scoreIndex = 0;
            this.enterState = 0;
            this.mode = 0;
            loadPalette(this.palette, OB_DAT, 0, 0xa1, 0x20);
            playBGM(gs.fileCheck === 0 ? 6 : 7);
            await fadeIn(this, FadeMode.White);
        }
        if (this.exit === 1) {
            await fadeOut(this, FadeMode.White, 0, 100);
            stopBGM();
            this.enterState = 1;
            this.exit = 0;
            this.mode = 0;
            return State.Title;
        }
        pollInput();
        for(let p = 0; p < 2; p++){
            const { moveX: dx, moveY: dy, a, b } = gs.input[p];
            switch(this.mode){
                case 0:
                    await this.updateMenu(p, dx, dy, a, b);
                    break;
                case 1:
                    await this.updateScore(p, dx, dy, a, b);
                    break;
                case 2:
                    await this.updateGallery(dx, dy, a, b);
                    break;
            }
        }
        this.render();
        return State.Config;
    }
    async updateMenu(p, dx, dy, a, b) {
        if (dy && !this.latch[p]) {
            this.cursor += dy;
            if (this.cursor > MENU_LAST) this.cursor = 0;
            if (this.cursor < 0) this.cursor = MENU_LAST;
            playSE(8);
            this.latch[p] = 1;
        }
        if (dx && !this.latch[p] && this.cursor <= 4) {
            switch(this.cursor){
                case 0:
                    gs.option0 = wrap(gs.option0 + dx, 0, 1);
                    writeKeyIniByte(0x22, gs.option0 + 1);
                    break;
                case 1:
                    gs.option1 = wrap(gs.option1 + dx, 1, 3);
                    writeKeyIniByte(0x24, gs.option1);
                    break;
                case 2:
                    gs.option2 = wrap(gs.option2 + dx, 0, 1);
                    writeKeyIniByte(0x23, gs.option2 + 1);
                    break;
                case 3:
                    gs.option3 = wrap(gs.option3 + dx, 1, 4);
                    writeKeyIniByte(0x21, gs.option3);
                    break;
                case 4:
                    gs.winRoundsConfig = wrap(gs.winRoundsConfig + dx, 1, 3);
                    writeKeyIniByte(0x26, gs.winRoundsConfig);
                    break;
            }
            playSE(8);
            this.latch[p] = 1;
        }
        if (!dx && !dy) this.latch[p] = 0;
        if (a === 1) {
            if (this.cursor === 5) {
                playSE(6);
                await this.showGallery();
            } else if (this.cursor === 6) {
                playSE(6);
                await this.slideTo(0);
                loadPalette(this.palette, SCORE_DAT, 0, 0xa1, 0x20);
                this.mode = 1;
                this.loadCharacter();
                setPalette(this.palette);
                await this.slideTo(1);
            } else if (this.cursor === 7) {
                this.exit = 1;
            }
        }
        if (b === 1) this.exit = 1;
    }
    async updateScore(p, dx, dy, a, b) {
        if (dx && !this.latch[p]) {
            playSE(8);
            let idx = this.scoreIndex + dx;
            if (gs.fileCheck === 0) {
                if (idx === 12) idx = 15;
                if (idx === 14) idx = 11;
            }
            if (gs.fileCheck === -1) {
                if (idx === 16) idx = 20;
                if (idx === 19) idx = 15;
                if (idx === 22) idx = dx > 0 ? 0 : 20;
            }
            if (idx > 22) idx = 0;
            if (idx < 0) idx = 22;
            this.scoreIndex = idx;
            await this.flipPage();
            this.latch[p] = 1;
        }
        if (!dx && !dy) this.latch[p] = 0;
        if (a || b) {
            if (a) playSE(6);
            await this.slideTo(0);
            loadPalette(this.palette, OB_DAT, 0, 0xa1, 0x20);
            setPalette(this.palette);
            this.mode = 0;
            await this.slideTo(1);
        }
    }
    async updateGallery(dx, dy, a, b) {
        if (dx || dy) {
            playSE(8);
            this.galleryIndex += dx + dy * 10;
            if (this.galleryIndex > GALLERY_LAST) this.galleryIndex = 0;
            if (this.galleryIndex < 0) this.galleryIndex = GALLERY_LAST;
            await this.showGallery();
        }
        if (a || b) {
            if (a) playSE(6);
            for(let i = 20; i >= 0; i--)await this.darkenStep(1, 255, i * 5);
            loadPalette(this.palette, BG_DAT, 0, 1, 0xa0);
            loadPalette(this.palette, OB_DAT, 0, 0xa1, 0x20);
            this.mode = 0;
            for(let i = 0; i <= 20; i++)await this.darkenStep(0, 255, i * 5);
        }
    }
    async darkenStep(start, end, pct) {
        this.render();
        setPaletteDarken(this.palette, start, end, pct);
        present();
        await sleep(this.tick++ % 2 === 0 ? 16 : 15);
    }
    async slideTo(dir) {
        for(let k = 0; k <= 18; k++){
            const i = dir === 0 ? k * 5 : 90 - k * 5;
            this.slide = Math.trunc((1 - cosd(i)) * 320) << 16 >> 16;
            await this.step();
        }
    }
    async flipPage() {
        for(let i = 0; i <= 360; i += 10){
            await this.step();
            this.portraitX = Math.trunc(160 - 160 * cosd(i));
            if (i === 180) {
                this.loadCharacter();
                setPalette(this.palette);
            }
        }
        this.portraitX = 0;
    }
    loadCharacter() {
        const name = SCORE_NAMES[this.scoreIndex];
        const path = `system\\${name}\\${name}.dat`;
        this.surfPortrait = loadDat(path, 0, 0xd6);
        loadPalette(this.palette, path, 0, 0xd6, 0x28);
        this.portraitKey = readColorKey(this.surfPortrait);
        this.rec = readRec(name);
    }
    async showGallery() {
        for(let i = 10; i >= 0; i--)await this.darkenStep(0, 255, i * 10);
        const path = `system\\nl\\nl${String(this.galleryIndex).padStart(3, "0")}.dat`;
        await preload([
            path
        ]);
        this.surfGallery = loadDat(path, 0, 1);
        loadPalette(this.palette, path, 0, 1, 0xfe);
        this.mode = 2;
        for(let i = 0; i <= 10; i++)await this.darkenStep(0, 255, i * 10);
    }
    drawNumber(x, y, value) {
        let v = value >>> 0;
        do {
            const d = v % 10;
            blit(makeRect(x - 14, y, 12, 14), this.surfScore, rect(d * 16 + 2, 0xf0, d * 16 + 14, 0xfe), this.scoreKey);
            x -= 10;
            v = Math.trunc(v / 10);
        }while (v > 0)
    }
    render() {
        __session.render();
        const s = this.slide;
        if (this.mode === 2) {
            blit(makeRect(0, 0, 320, 240), this.surfGallery, makeRect(0, 0, 320, 240), 0);
            present();
            return;
        }
        blit(makeRect(0, 0, 320, 240), this.surfBG, makeRect(0, 0, 320, 240), 0xff);
        const sheet = this.mode === 0 ? this.surfOB : this.surfScore;
        const key = this.mode === 0 ? this.obKey : this.scoreKey;
        blit(rect(0, -s, 320, 40 - s), sheet, rect(0, 0, 320, 40), key);
        blit(rect(0, 40 + s, 320, 240 + s), sheet, rect(0, 40, 320, 240), key);
        if (this.mode === 0) {
            const ob = this.surfOB;
            const c = this.cursor;
            const w = c <= 4 ? 0x70 : 0x140;
            const srcY = 0x105 + 0x12 * c;
            const dstY = s + 0x5f + 0x12 * c;
            blit(rect(0, dstY, w, dstY + 14), ob, rect(0, srcY, w, srcY + 14), this.obKey);
            const value = (x, width, srcY, dstY)=>{
                blit(rect(x, s + dstY, x + width, s + dstY + 14), ob, rect(x, srcY, x + width, srcY + 14), this.obKey);
            };
            value(gs.option0 === 0 ? 0x70 : 0xc0, 0x50, 0x105, 0x5f);
            value([
                0x70,
                0xb0,
                0xf0
            ][gs.option1 - 1] ?? 0x70, 0x40, 0x117, 0x71);
            value(gs.option2 === 0 ? 0x70 : 0xa0, 0x30, 0x129, 0x83);
            value([
                0x80,
                0x98,
                0xb0,
                0xc8
            ][gs.option3 - 1] ?? 0x80, 0x18, 0x13b, 0x95);
            value([
                0x80,
                0x98,
                0xb0
            ][gs.winRoundsConfig - 1] ?? 0x80, 0x18, 0x14d, 0xa7);
        } else {
            const x = 0x50 + this.portraitX;
            blit(rect(x, s, x + 320, s + 240), this.surfPortrait, rect(0, 0, 320, 240), this.portraitKey);
            this.drawNumber(0xa0, s + 0x8f, this.rec[0]);
            this.drawNumber(0xa0, s + 0xa1, this.rec[1]);
            this.drawNumber(0xa0, s + 0xb3, this.rec[2]);
            this.drawNumber(0xa0, s + 0xc5, this.rec[7]);
            this.drawNumber(0xa0, s + 0xd7, this.rec[6]);
        }
        present();
    }
    static files = [
        BG_DAT,
        OB_DAT,
        SCORE_DAT
    ];
}
function rect(left, top, right, bottom) {
    return {
        left,
        top,
        right,
        bottom
    };
}
function wrap(v, min, max) {
    if (v > max) return min;
    if (v < min) return max;
    return v;
}

export function __logicState(){return {SCORE_NAMES,Mode,sleep};}

export function __installInitialRoots(s){
if(SCORE_NAMES!==s["SCORE_NAMES"])throw Error('INITIAL_CONST_IDENTITY:SCORE_NAMES');
Mode=s["Mode"];
if(sleep!==s["sleep"])throw Error('INITIAL_CONST_IDENTITY:sleep');
}
