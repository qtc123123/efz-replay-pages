import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
export const stateHandlers = new Map();
export const childHandlers = new Map();
export let defaultStateHandler = null;
export function registerStates(map) {
    for (const [k, v] of Object.entries(map))stateHandlers.set(Number(k), v);
}
export function registerChildren(map) {
    for (const [k, v] of Object.entries(map))childHandlers.set(Number(k), v);
}
export function setDefaultStateHandler(fn) {
    defaultStateHandler = fn;
}

export function __logicState(){return {stateHandlers,childHandlers,defaultStateHandler};}

export function __installInitialRoots(s){
if(stateHandlers!==s["stateHandlers"])throw Error('INITIAL_CONST_IDENTITY:stateHandlers');
if(childHandlers!==s["childHandlers"])throw Error('INITIAL_CONST_IDENTITY:childHandlers');
defaultStateHandler=s["defaultStateHandler"];
}
