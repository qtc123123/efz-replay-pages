import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { Character } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { defaultStateHandler, stateHandlers } from "./6a48da560917c25ba78d9332.mjs";
import { updateChildrenNayukiB } from "./a955fd4a77ee18da4a262fee.mjs";
import { parseCommandNayukiB, dispatchMovesNayukiB } from "./915d462d22635247e345c8cc.mjs";
import { thinkNayukiB } from "./315f14744675505bc34535ba.mjs";
import { renderOverlayNayukiB, tickHookNayukiB } from "./02a3385f8827aaaaf0ffbbb7.mjs";
import "./02d3dfcb9cb7676e0c017f5d.mjs";
import "./046068486a6b8922db6dc7b1.mjs";
import "./98bd0fab08be764e15a83b45.mjs";
const POINTS_X = [
    -5,
    8,
    17,
    19,
    22
];
const POINTS_Y = [
    -61,
    0,
    -15,
    -11,
    -30
];
export class NayukiB extends Character {
    f3138 = 0;
    f313c = 0;
    f3140 = 0;
    f3144 = 0;
    f3148 = 0;
    f314c = 0;
    f3150 = 0;
    f3154 = 0;
    a3158 = new Int32Array(64);
    a3258 = new Int32Array(64);
    a3358 = new Int32Array(64);
    pointsX = [
        ...POINTS_X
    ];
    pointsY = [
        ...POINTS_Y
    ];
    params = [
        7,
        0x11,
        1,
        0xd,
        0x10,
        0xa,
        3,
        6
    ];
    aiTimer1a0 = 0;
    aiTimer1a4 = 0;
    aiRoll = 0;
    aiMode = 0;
    onStateChange() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        super.onStateChange();
    }
    resetRound() {
        this.f3138 = 0;
        this.f313c = 0;
        this.f3140 = 0;
        this.f3144 = 0;
        this.f3148 = 0;
        this.f314c = 0;
        this.f3150 = 0;
        this.f3154 = 0;
        for(let i = 0; i < 5; i++){
            this.pointsX[i] = POINTS_X[i];
            this.pointsY[i] = POINTS_Y[i];
        }
        this.a3158.fill(0);
        this.a3258.fill(0);
        this.a3358.fill(0);
        super.resetRound();
    }
    spawnChild(t) {
        this.freeChild(this.childHead);
        return super.spawnChild(t);
    }
    freeChild(i) {
        this.a3158[i] = 0;
        this.a3258[i] = 0;
        this.a3358[i] = 0;
        super.freeChild(i);
    }
    renderOverlay() {
        renderOverlayNayukiB(this);
    }
    tickHook() {
        tickHookNayukiB(this);
    }
    parseCommand() {
        parseCommandNayukiB(this);
    }
    dispatchMoves() {
        dispatchMovesNayukiB(this);
    }
    think() {
        thinkNayukiB(this);
    }
    updateState() {
        if (this.hitstop > 0 || this.opponent.freeze > 0) return;
        const handler = stateHandlers.get(this.state) ?? defaultStateHandler;
        handler?.(this);
    }
    updateChildren() {
        updateChildrenNayukiB(this);
    }
}

export function __logicState(){return {POINTS_X,POINTS_Y};}

export function __installInitialRoots(s){
if(POINTS_X!==s["POINTS_X"])throw Error('INITIAL_CONST_IDENTITY:POINTS_X');
if(POINTS_Y!==s["POINTS_Y"])throw Error('INITIAL_CONST_IDENTITY:POINTS_Y');
}
