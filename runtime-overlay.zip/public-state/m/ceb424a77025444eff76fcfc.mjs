import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { rand } from "./b095411d693646582d2f298b.mjs";
import { CHILD_SLOTS } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
import { spawnEffect } from "./7f2701ba2d6ce15107cdc8f7.mjs";
import { GameMode, gameState as gs } from "./11a8544a0f705ad2a3ee4f96.mjs";
import { residue7697d0Boxes, residue7697d0Hit, residue7697d0Untouchable, residue76b090Hit, residue76bd40Boxes, residue76bd40Entry, residue76bd40Hit, residueCell, residueFtolAt3f4, residueMatrix, residuePoint, residueThrowColumn } from "./88bddfa53ecc3b1f298ce39d.mjs";
function boxToWorld(box, frame, x, y, facing) {
    const ox = frame.offsetX;
    const oy = frame.offsetY;
    const t = Math.trunc(y - oy + box.top);
    const b = Math.trunc(y - oy + box.bottom);
    if (facing === 1) return {
        l: Math.trunc(x - 0.5 - ox + box.left),
        t,
        r: Math.trunc(x - 0.5 - ox + box.right),
        b
    };
    return {
        l: Math.trunc(x + 0.5 + ox - box.right),
        t,
        r: Math.trunc(x + 0.5 + ox - box.left),
        b
    };
}
function ftolResidue(box, frame, x, y, facing) {
    const ox = frame.offsetX;
    const oy = frame.offsetY;
    residueFtolAt3f4(y - oy + box.top);
    residueFtolAt3f4(y - oy + box.bottom);
    if (facing === 1) {
        residueFtolAt3f4(x - 0.5 - ox + box.left);
        residueFtolAt3f4(x - 0.5 - ox + box.right);
    } else {
        residueFtolAt3f4(x + 0.5 + ox - box.right);
        residueFtolAt3f4(x + 0.5 + ox - box.left);
    }
}
function overlap(a, b) {
    if (a.r <= a.l || a.b <= a.t || b.r <= b.l || b.b <= b.t) return false;
    return b.r >= a.l && a.r >= b.l && b.b >= a.t && a.b >= b.t;
}
function testHit(src, dHit, dFrame, dx, dy, dFacing, spark) {
    const throwMove = (src.hit.attackFlags & 0x40) !== 0;
    const targets = throwMove ? [
        dHit.body
    ] : dHit.hurt;
    let hit = false;
    for (const ab of src.hit.attack){
        const a = boxToWorld(ab, src.frame, src.x, src.y, src.facing);
        for (const tb of targets){
            const t = boxToWorld(tb, dFrame, dx, dy, dFacing);
            if (!overlap(a, t)) continue;
            hit = true;
            spark.l = Math.max(spark.l, a.l, t.l);
            spark.t = Math.max(spark.t, a.t, t.t);
            spark.r = Math.min(spark.r, a.r, t.r);
            spark.b = Math.min(spark.b, a.b, t.b);
            if (throwMove) return true;
        }
    }
    return hit;
}
function testHitMatrix(src, dHit, dFrame, dx, dy, dFacing, spark) {
    const atk = src.hit.attack.map((ab)=>boxToWorld(ab, src.frame, src.x, src.y, src.facing));
    const hurt = dHit.hurt.map((tb)=>boxToWorld(tb, dFrame, dx, dy, dFacing));
    const body = boxToWorld(dHit.body, dFrame, dx, dy, dFacing);
    const throwMove = (src.hit.attackFlags & 0x40) !== 0;
    if (src.child) {
        residue7697d0Boxes(src.hit.attack.map((ab)=>boxCall(ab, src.frame, src.x, src.y, src.facing)), dHit.hurt.map((tb)=>boxCall(tb, dFrame, dx, dy, dFacing)), boxCall(dHit.body, dFrame, dx, dy, dFacing));
    }
    const matrix = [];
    let hit = false;
    if (throwMove) {
        if (!src.child) residueThrowColumn();
        for(let i = 0; i < 4; i++){
            const row = [
                1
            ];
            for(let j = 1; j < 5; j++)row.push(src.child ? 3 : residueCell(i, j));
            matrix.push(row);
            if (overlap(atk[i], body)) hit = true;
        }
    } else {
        for(let i = 0; i < 4; i++){
            const row = [];
            for(let j = 0; j < 5; j++){
                row.push(overlap(atk[i], hurt[j]) ? 1 : 0);
                if (row[j]) hit = true;
            }
            matrix.push(row);
        }
        if (!src.child) residueMatrix(matrix.map((r)=>r.map((v)=>v !== 0)));
    }
    if (!hit) return false;
    accumulateSpark(spark, atk, hurt, matrix);
    return true;
}
function boxCall(box, frame, x, y, facing) {
    const w = boxToWorld(box, frame, x, y, facing);
    return {
        facingRight: facing === 1,
        offsetX: frame.offsetX,
        offsetY: frame.offsetY,
        l: w.l,
        t: w.t,
        r: w.r,
        b: w.b
    };
}
function accumulateSpark(spark, atk, hurt, matrix) {
    for(let i = 0; i < 4; i++){
        for(let j = 0; j < 5; j++){
            const v = matrix[i][j];
            if (v === 0 || v === 2) continue;
            const a = atk[i];
            const t = hurt[j];
            spark.l = Math.max(spark.l, a.l, t.l);
            spark.t = Math.max(spark.t, a.t, t.t);
            spark.r = Math.min(spark.r, a.r, t.r);
            spark.b = Math.min(spark.b, a.b, t.b);
        }
    }
}
function newSpark() {
    return {
        l: -10000,
        t: -10000,
        r: 10000,
        b: 10000
    };
}
function sparkCenter(s) {
    return {
        x: Math.trunc((s.l + s.r) / 2),
        y: Math.trunc((s.t + s.b) / 2)
    };
}
function spawnHitEffect(pat, spark, mirror, sound) {
    if (pat < 0) return;
    const { x, y } = sparkCenter(spark);
    spawnEffect({
        pat,
        x,
        y,
        mirror: mirror ? 1 : 0,
        blend: 2,
        layer: 1,
        sound
    });
}
function untouchable(d) {
    return d.hitstun <= 0 && d.y < 0 && d.d128 === 0 && d.isBeingHit();
}
function canGuard(d, atk) {
    if (d.isCPU) {
        if (gs.mode === GameMode.Practice) {
            if (gs.practiceAutoGuard === 0) return false;
        } else {
            if (!(rand("src/game/hit.ts:213:9", {
                consumer: "src/game/hit.ts"
            }) <= Math.fround(d.aiLevel * 10000.0))) return false;
            if (!(atk & 1)) d.inputY = 1;
            else if (!(atk & 2)) d.inputY = 0;
        }
    } else {
        const dir = d.opponent.x - d.x > 0 ? 1 : 0;
        if (!(d.inputX === 1 - 2 * dir || d.isGuarding() && d.inputX !== 0)) return false;
    }
    if (d.y === 0) return d.inputY === 1 ? (atk & 2) !== 0 : (atk & 1) !== 0;
    return true;
}
function canGuardFull(d, atk, def) {
    if (d.w13a > 0 || atk & 0x80 || !(def & 0x10)) return false;
    if (!(atk & 4) && d.y < 0 && d.backWindow < 30) return false;
    return canGuard(d, atk);
}
function damageScale(a) {
    const base = a.rfGauge / 10000 + 1.0;
    if (gs.mode === GameMode.Score) return base;
    if (gs.option1 === 1) return base / 2;
    if (gs.option1 === 2) return base;
    return base * 2;
}
function gutsScale(d) {
    return (d.life * 0.5 / 10000 + 0.5) * d.dbl180;
}
function prorationScale(a) {
    return Math.min(a.proration / 10000, 1.0);
}
export function applyDirectDamage(a, damage, proration) {
    const d = a.opponent;
    if (a.comboCount === 0) d.redLife = d.life;
    d.life -= Math.trunc(damage * damageScale(a) * gutsScale(d) * prorationScale(a));
    a.dblF8 = a.proration / 100.0;
    a.proration *= proration / 1000;
    if (a.proration > 10000.0) a.proration *= proration / 1000;
    a.comboCount++;
    a.comboDisplay = a.comboCount;
    a.comboTimer = 0xb4;
    a.comboDamage = d.redLife - d.life;
    if (a.comboCount >>> 0 > a.maxCombo >>> 0) a.maxCombo = a.comboCount;
    if (a.comboDamage >>> 0 > a.maxComboDamage >>> 0) a.maxComboDamage = a.comboDamage;
    a.hitCount++;
    addScore(a, Math.trunc(damage / 100) * a.hitCount * a.maxCombo * a.comboCount);
}
function addScore(a, v) {
    a.score += v;
    if (a.score > 100000000) {
        a.score -= 100000000;
        a.scoreHigh++;
    }
}
function recordStats(a, atk) {
    a.maxCombo = Math.max(a.maxCombo, a.comboCount);
    a.maxComboDamage = Math.max(a.maxComboDamage, a.comboDamage);
    a.hitCount++;
    addScore(a, Math.trunc(atk.damage / 100) * a.hitCount * a.maxCombo * a.comboCount);
}
function turnDefender(src, d) {
    if (src.child) d.facing = -src.child.facing;
    else d.faceOpponent();
}
function applyHit(src, d, def, spark, guardable) {
    const a = src.owner;
    const atk = src.hit;
    const af = atk.attackFlags;
    if ((def & 4 || d.w138) && !(af & 0x100) && !(af & 0x40)) {
        a.comboCount = 0;
        if (guardable) {
            if (src.child) {
                src.child.hitState = 7;
                d.requestFlash(0xe9, 3);
            } else {
                d.requestFlash(0xdf, 3);
                a.d168 = 7;
            }
        } else {
            d.requestFlash(0xdf, 2);
        }
    } else {
        if (d.y < 0) d.state = atk.airHitState > 0 ? atk.airHitState : 0x3b;
        else if (atk.groundHitState > 0) d.state = atk.groundHitState;
        else if ((def & 3) === 3) d.state = 0x3b;
        else if (def & 1) d.state = 0x32 + 3 * (af & 8 ? 1 : 0) + (af & 0x10 ? 1 : 0) + 2 * (af & 0x20 ? 1 : 0);
        else if (def & 2) d.state = 0x38 + (af & 0x10 ? 1 : 0) + 2 * (af & 0x20 ? 1 : 0);
        if (guardable) {
            if (src.child) src.child.hitState = 3;
            else a.d168 = 3;
        }
        d.onStateChange();
        turnDefender(src, d);
    }
    if (def & 0x10) {
        a.comboCount = 0;
        a.proration = a.proration > 10000.0 ? a.proration - 20.0 : 10000.0;
    }
    d.knockX = atk.knockbackX;
    d.knockY = atk.knockbackY;
    const projectileHit = guardable && src.child !== undefined;
    d.d0d0 = projectileHit ? 0 : 1;
    if (a.comboCount === 0) d.redLife = d.life;
    const link = af & 0x2000 && def & 0x2000 ? 1 : 0;
    if (guardable && !src.child) a.d144 = link;
    const dmg = Math.trunc(atk.damage * damageScale(a) * gutsScale(d) * prorationScale(a));
    d.life -= dmg;
    if (projectileHit) {
        d.hitstun = Math.trunc(atk.hitstun * (a.proration / 10000) * (link + 1));
    } else {
        d.hitstun = Math.trunc(atk.hitstun * (a.proration / 10000 * 0.8));
    }
    d.d128 = af & 0x400 ? 1 : 0;
    d.d12c = af & 0x800 ? 1 : 0;
    d.b158 = d.b159 = d.b15a = 0;
    a.dblF8 = a.proration / 100.0;
    a.proration *= atk.proration / 1000.0;
    if (a.proration > 10000.0) a.proration *= atk.proration / 1000.0;
    a.comboCount++;
    a.comboDisplay = a.comboCount;
    a.comboTimer = 0xb4;
    a.comboDamage = d.redLife - d.life;
    a.meter += atk.meterOnHit;
    if (projectileHit) src.child.hitstop = atk.attackerHitstop;
    else a.hitstop = atk.attackerHitstop;
    d.hitstop = atk.defenderHitstop;
    if (guardable && !src.child) a.w16c--;
    if (projectileHit) src.child.hitsLeft--;
    if (guardable) spawnHitEffect(atk.hitEffect, spark, a.facing < 0, atk.hitEffectParam);
    if (d.life <= 0 && d.w140 === 0) {
        d.state = atk.airHitState;
        d.onStateChange();
        d.faceOpponent();
    }
    recordStats(a, atk);
}
function applyRecoilGuard(src, d, spark, state, clearDefender) {
    const a = src.owner;
    if (src.child) {
        src.child.hitState = 2;
        src.child.hitsLeft--;
    } else {
        a.d168 = 2;
        a.w16c--;
    }
    a.meter += src.hit.meterOnGuard;
    d.d0d0 = 1;
    spawnHitEffect(0x11, spark, d.facing === -1, 0x0a);
    d.onStateChange();
    turnDefender(src, d);
    d.state = state;
    a.clearInputHistory();
    d.clearInputHistory();
    d.freeze = 0x3c;
    if (clearDefender) d.d170 = 0;
    a.d170 = 1;
}
function resolve(src, d, sD) {
    const a = src.owner;
    const atk = src.hit.attackFlags;
    const dHit = sD.hit;
    const dFrame = sD.frame;
    if (!dHit || !dFrame) return;
    const def = dHit.defenseFlags;
    if (src.child) {
        if (src.child.hitState !== 0 || src.child.hitsLeft <= 0) return;
    }
    if (def & 0x20) return;
    if (d.b130 > 0 && atk & 0x40) return;
    const unt = untouchable(d);
    if (src.child) residue7697d0Untouchable(d.hitstun <= 0 && d.y < 0 && d.d128 === 0, d.isBeingHit(), unt);
    if (unt || d.w13c !== 0) return;
    const spark = newSpark();
    if (!testHitMatrix(src, dHit, dFrame, sD.x, sD.y, sD.facing, spark)) return;
    if (src.child) residue7697d0Hit();
    if (src.child) {
        if (def & 0x400 && !(atk & 0x100)) {
            src.child.hitsLeft--;
            src.child.hitState = 2;
            a.d168 = 6;
            d.d168 = 6;
            return;
        }
    } else if (def & 0x1000 && !(atk & 0x100) && atk & 1 || def & 0x800 && !(atk & 0x100) && atk & 2) {
        a.w16c--;
        a.d168 = 6;
        d.d168 = 6;
        return;
    }
    if (d.d170 && d.backWindow >= 30 && d.w13a === 0 && canGuard(d, atk) && !(atk & 0x80)) {
        applyRecoilGuard(src, d, spark, d.y === 0 ? d.inputY === 1 ? 0xa9 : 0xa8 : 0xaa, true);
        return;
    }
    if (d.backWindow >= 30 && d.y < 0 && canGuardFull(d, atk, def)) {
        applyRecoilGuard(src, d, spark, 0xaa, false);
        return;
    }
    if (canGuardFull(d, atk, def) && d.backWindow >= 30 && d.y === 0 && d.state !== 0xa8 && d.state !== 0xa9) {
        applyRecoilGuard(src, d, spark, d.inputY === 1 ? 0xa9 : 0xa8, true);
        return;
    }
    const gp = dHit.attackFlags;
    const gpStand = def & 0x200 && gp & 1 && atk & 1;
    const gpCrouch = def & 0x200 && gp & 2 && atk & 2;
    const gpAir = def & 0x200 && gp & 4 && atk & 4 && d.y < 0;
    if (gpStand || gpCrouch || gpAir) {
        if (src.child) {
            src.child.hitsLeft--;
            a.d168 = 2;
        } else {
            a.w16c--;
            a.d168 = 2;
        }
        spawnHitEffect(2, spark, d.facing === -1, 3);
        a.hitstop = src.hit.attackerHitstop;
        d.hitstop = src.hit.defenderHitstop;
        d.life -= src.hit.chip;
        if (d.life <= 0) d.life = 1;
        if (gpStand || gpCrouch) d.guardGauge = Math.min(Math.fround(d.guardGauge + Math.trunc(src.hit.damage / 30)), 360.0);
        return;
    }
    if (canGuardFull(d, atk, def)) {
        if (src.child) {
            src.child.hitState = 2;
            src.child.hitsLeft--;
        } else {
            a.d168 = 2;
            a.w16c--;
        }
        a.meter += src.hit.meterOnGuard;
        d.d0d0 = src.child ? 0 : 1;
        const guardMirror = src.child ? a.facing < 0 : d.facing === -1;
        const crouch = d.inputY === 1 || !(atk & def & 5) && d.isCPU !== 0 ? 1 : 0;
        const lvl = (atk & 0x10 ? 1 : 0) + (atk & 0x20 ? 2 : 0);
        d.state = 0x96 + lvl + 3 * crouch;
        if (d.y < 0) d.state = 0x9c;
        d.onStateChange();
        turnDefender(src, d);
        if (src.child) src.child.hitstop = src.hit.attackerHitstop;
        else a.hitstop = src.hit.attackerHitstop;
        d.hitstop = src.hit.defenderHitstop;
        d.life -= src.hit.chip;
        if (d.life <= 0) d.life = 1;
        const g = Math.trunc(src.hit.damage / 30);
        if (a.guardGauge > 0) {
            a.guardGauge = Math.fround(a.guardGauge - g);
            if (a.guardGauge < 0) {
                d.guardGauge = Math.fround(d.guardGauge - a.guardGauge);
                a.guardGauge = 0;
            }
        } else {
            d.guardGauge = Math.fround(d.guardGauge + g);
            if (d.guardGauge > 360) d.guardGauge = 360;
        }
        spawnHitEffect(2, spark, guardMirror, 3);
        return;
    }
    applyHit(src, d, def, spark, true);
}
function snapshot(c) {
    return {
        hit: c.currentHit(),
        frame: c.currentFrame(),
        x: c.x,
        y: c.y,
        facing: c.facing,
        d168: 0,
        w16c: 0
    };
}
function bodySource(c, s) {
    if (!s.hit || !s.frame) return null;
    return {
        owner: c,
        hit: s.hit,
        frame: s.frame,
        x: s.x,
        y: s.y,
        facing: s.facing
    };
}
function childSource(c, i) {
    const ch = c.children[i];
    const { frame, hit } = c.childFrame(i);
    if (!frame || !hit) return null;
    return {
        owner: c,
        child: ch,
        hit,
        frame,
        x: ch.x,
        y: ch.y,
        facing: ch.facing
    };
}
function prejudge(a, d, sA, sD) {
    const atkHit = sA.hit;
    if (!atkHit || !sD.hit || !sD.frame) return 0;
    const atk = atkHit.attackFlags;
    if (a.d168 !== 0 || sD.hit.defenseFlags & 0x20 || a.w16c <= 0) return 0;
    if (d.b130 > 0 && atk & 0x40) return 0;
    if (untouchable(d) || d.w13c !== 0) return 0;
    const src = bodySource(a, sA);
    if (!src || !testHitMatrix(src, sD.hit, sD.frame, sD.x, sD.y, sD.facing, newSpark())) return 0;
    return d.d170 && d.backWindow >= 30 && d.w13a === 0 && canGuard(d, atk) && !(atk & 0x80) ? 1 : 0;
}
function projectileClash(cA, cB, i, j) {
    const pA = cA.children[i];
    const pB = cB.children[j];
    if (pA.hitState || pB.hitState || pA.hitsLeft <= 0 || pB.hitsLeft <= 0) return;
    const prA = cA.patterns[pA.pattern]?.hdrA ?? 0;
    const prB = cB.patterns[pB.pattern]?.hdrA ?? 0;
    if (prA <= 0 || prB <= 0) return;
    const fa = cA.childFrame(i);
    const fb = cB.childFrame(j);
    if (!fa.frame || !fa.hit || !fb.frame || !fb.hit) return;
    const a = boxToWorld(fa.hit.body, fa.frame, pA.x, pA.y, pA.facing);
    const b = boxToWorld(fb.hit.body, fb.frame, pB.x, pB.y, pB.facing);
    if (!overlap(a, b)) return;
    if (prB === prA) {
        pA.hitState = 4;
        pB.hitState = 4;
    } else if (prB > prA) {
        pA.hitState = 4;
    } else {
        pB.hitState = 4;
    }
    if (prB > 1) pA.hitsLeft--;
    if (prA > 1) pB.hitsLeft--;
}
function projectileHitsProjectile(cA, cB, i, j) {
    const pA = cA.children[i];
    const pB = cB.children[j];
    const src = childSource(cA, i);
    const fb = cB.childFrame(j);
    if (!src || !fb.frame || !fb.hit) return;
    if (pA.hitState !== 0 || pA.hitsLeft <= 0 || src.hit.attackFlags & 0x40) return;
    for (const ab of src.hit.attack)ftolResidue(ab, src.frame, src.x, src.y, src.facing);
    for (const tb of fb.hit.hurt)ftolResidue(tb, fb.frame, pB.x, pB.y, pB.facing);
    const spark = newSpark();
    if (!testHit(src, fb.hit, fb.frame, pB.x, pB.y, pB.facing, spark)) return;
    residue76b090Hit();
    if (!(fb.hit.defenseFlags & 0x10)) {
        pA.hitsLeft--;
        pA.hitState = 5;
    }
    pB.hitState = 5;
    if (fb.hit.defenseFlags & 0x2000) {
        const sB = snapshot(cB);
        if (sB.hit) applyHit(src, cB, sB.hit.defenseFlags, spark, false);
    }
    spawnHitEffect(src.hit.hitEffect, spark, cA.facing < 0, src.hit.hitEffectParam);
}
function meleeHitsProjectile(a, b, sA, i) {
    residue76bd40Entry();
    const src = bodySource(a, sA);
    if (!src) return;
    if (a.d168 !== 0 || a.w16c <= 0 || src.hit.attackFlags & 0x40) return;
    const p = b.children[i];
    const fp = b.childFrame(i);
    if (!fp.frame || !fp.hit) return;
    residue76bd40Boxes(boxCall(src.hit.attack[3], src.frame, src.x, src.y, src.facing), boxCall(fp.hit.hurt[4], fp.frame, p.x, p.y, p.facing));
    const spark = newSpark();
    if (!testHit(src, fp.hit, fp.frame, p.x, p.y, p.facing, spark)) return;
    residue76bd40Hit();
    if (!(fp.hit.defenseFlags & 0x10)) {
        a.w16c--;
        a.d168 = 5;
    }
    p.hitState = 5;
    if (fp.hit.defenseFlags & 0x2000) {
        const sB = snapshot(b);
        if (sB.hit) applyHit(src, b, sB.hit.defenseFlags, spark, false);
    }
    spawnHitEffect(src.hit.hitEffect, spark, a.facing < 0, src.hit.hitEffectParam);
}
export function resolveHits(p1, p2) {
    const s1 = snapshot(p1);
    const s2 = snapshot(p2);
    const r1 = prejudge(p1, p2, s1, s2);
    residuePoint("h_pj1");
    const r2 = prejudge(p2, p1, s2, s1);
    residuePoint("h_pj2");
    p1.d144 = 0;
    p2.d144 = 0;
    forEachSlot(p1, (i, ai)=>forEachSlot(p2, (j, aj)=>{
            if (ai && aj) projectileClash(p1, p2, i, j);
            residuePoint("h_clash");
        }));
    forEachSlot(p1, (i, ai)=>forEachSlot(p2, (j, aj)=>{
            if (ai && aj) {
                projectileHitsProjectile(p1, p2, i, j);
                residuePoint("h_pp1");
                projectileHitsProjectile(p2, p1, j, i);
            }
            residuePoint("h_pp2");
        }));
    forEachSlot(p2, (i, active)=>{
        if (active) {
            const src = childSource(p2, i);
            if (src) resolve(src, p1, s1);
            residuePoint("h_97d0a");
            meleeHitsProjectile(p1, p2, s1, i);
        }
        residuePoint("h_bd40a");
    });
    forEachSlot(p1, (i, active)=>{
        if (active) {
            const src = childSource(p1, i);
            if (src) resolve(src, p2, s2);
            residuePoint("h_97d0b");
            meleeHitsProjectile(p2, p1, s2, i);
        }
        residuePoint("h_bd40b");
    });
    s1.d168 = p1.d168;
    s1.w16c = p1.w16c;
    s2.d168 = p2.d168;
    s2.w16c = p2.w16c;
    if (r2 === 0) resolveBody(p1, p2, s1, s2);
    residuePoint("h_7f60a");
    if (r1 === 0) resolveBody(p2, p1, s2, s1);
    residuePoint("h_7f60b");
}
function forEachSlot(c, fn) {
    for(let j = c.childTail; j !== c.childHead; j = (j + 1) % CHILD_SLOTS)fn(j, c.childActive[j] !== 0);
}
function resolveBody(a, d, sA, sD) {
    if (sA.d168 !== 0 || sA.w16c <= 0) return;
    const src = bodySource(a, sA);
    if (src) resolve(src, d, sD);
}
export function resolvePush(p1, p2) {
    let v1 = p1.vx;
    let v2 = p2.vx;
    p1.pushVelocity = 0;
    p2.pushVelocity = 0;
    const h1 = p1.currentHit();
    const h2 = p2.currentHit();
    const f1 = p1.currentFrame();
    const f2 = p2.currentFrame();
    if (!h1 || !h2 || !f1 || !f2) return;
    const b1 = boxToWorld(h1.body, f1, p1.x, p1.y, p1.facing);
    const b2 = boxToWorld(h2.body, f2, p2.x, p2.y, p2.facing);
    if (!overlap(b1, b2)) return;
    const fa = p1.facing;
    const fb = p2.facing;
    const a = fa * v1;
    const b = fb * v2;
    const write = ()=>{
        p1.pushVelocity = v1 - p1.vx;
        p2.pushVelocity = v2 - p2.vx;
    };
    if (b1.l + b1.r - (b2.l + b2.r) > 0) {
        const ov = b2.r - b1.l;
        p1.x += ov / 2.0;
        p2.x -= ov / 2.0;
        if (p1.wallBlock() === -1) {
            v1 = a < 0 ? v1 : 0;
            v2 = fa * v1 + b < 0 ? v2 : 0;
            if (fb * v2 > fa * v1) {
                const avg = (fa * v1 + fb * v2) / 2;
                v2 = fb * avg;
                write();
            }
        } else if (p2.wallBlock() === 1) {
            v2 = b > 0 ? v2 : 0;
            v1 = b + fa * v1 > 0 ? v1 : 0;
            if (fa * v1 < fb * v2) {
                const avg = (fa * v1 + fb * v2) / 2;
                v1 = fa * avg;
                write();
            }
        } else if (b >= 0 && a <= 0) {
            const avg = (a + b) / 2;
            v1 = fa * avg;
            v2 = fb * avg;
            write();
        }
    } else {
        const ov = b2.l - b1.r;
        p1.x += ov / 2.0;
        p2.x -= ov / 2.0;
        if (p1.wallBlock() === 1) {
            v1 = a > 0 ? v1 : 0;
            v2 = fa * v1 + b > 0 ? v2 : 0;
            if (fb * v2 < fa * v1) {
                const avg = (fa * v1 + fb * v2) / 2;
                v2 = fb * avg;
                write();
            }
        } else if (p2.wallBlock() === -1) {
            v2 = b < 0 ? v2 : 0;
            v1 = fa * v1 + fb * v2 < 0 ? v1 : 0;
            if (fb * v2 > fa * v1) {
                const avg = (fa * v1 + fb * v2) / 2;
                v1 = fa * avg;
                write();
            }
        } else if (b <= 0 && a >= 0) {
            const avg = (a + b) / 2;
            v1 = fa * avg;
            v2 = fb * avg;
            write();
        }
    }
}
