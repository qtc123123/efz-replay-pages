import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { frameChild, frameEffect, openSpawnFrame } from "./0a57f8c3d343150e3ded7bb7.mjs";
import { registerStates, registerStates2 } from "./00697db762b413ef9f6a1cba.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { frameCount, frameDuration, s16 } from "./7596266716c972d06fe8897a.mjs";
function rfCost(c) {
    if (c.rfBlue === 0) c.rfGauge = c.rfGauge - 500.0;
    else c.rfGauge = c.rfGauge - 250.0;
}
function effect21(c, f) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function oppStateOutside(c, max) {
    const st = c.opponent.state;
    return st < 50 || st > max;
}
function grab248(c, grabFrame, endFrame) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === grabFrame && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.stopMotion();
        o.d128 = 1;
        f.w04 = 0;
        f.x = Math.trunc(c.x) + c.facing * 0x25;
        f.y = Math.trunc(c.y) - 0x2a;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.frame = 0;
        c.timer = 0;
        c.state = 0xf9;
        o.x = c.facing * 0x19 + c.x;
        o.y = c.y - 80.0;
        o.state = 0x65;
        o.onStateChange();
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === grabFrame && o.y < 0.0 && oppStateOutside(c, 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0xd1;
            c.frame = endFrame;
        }
    }
}
function state248(c) {
    grab248(c, 2, 5);
}
function state248b(c) {
    grab248(c, 1, 2);
}
function throw249(c, damage) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.w13e = 0x1e;
    o.w13e = 0x1e;
    c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 0) c.stopMotion();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 1.0;
        c.vy = -2.0;
        c.ay = 0.04;
    }
    c.vy = c.vy + c.ay;
    if (c.vy + c.y > 0.0 && c.frame === 1) {
        c.y = 0.0;
        c.stopMotion();
        c.frame = 2;
        c.timer = 0;
        return;
    }
    if (c.x > 600.0 || c.x < 40.0) c.vx = 0.0;
    if (c.frame === 0) {
        o.x = c.facing * 0x19 + c.x;
        o.y = c.y - 80.0;
        o.state = 0x65;
        o.onStateChange();
    }
    if (c.frame === 1) {
        o.x = c.facing * 0xa + c.x;
        o.y = c.y - 90.0;
        o.state = 0x76;
        o.onStateChange();
    }
    if (c.frame === 2) {
        o.x = c.facing * 0x1e + c.x;
        o.y = c.y - 60.0;
        o.state = 0x69;
        o.onStateChange();
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 3) {
            o.x = c.facing * 0x28 + c.x;
            o.y = 0.0;
            o.state = 0x62;
            o.onStateChange();
            applyDirectDamage(c, damage, 500.0);
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state249(c) {
    throw249(c, 0x578);
}
function state249b(c) {
    throw249(c, 0x44c);
}
function state250(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.b158 = 0;
    c.vx = 0.0;
    c.vy = 0.0;
    if (c.frame === 2 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.pushToOpponent = 0.0;
        c.onStateChange();
        o.onStateChange();
        c.state = 0xfb;
        o.state = 0x6b;
        o.x = c.facing * 0x28 + c.x;
        o.d128 = 1;
        o.stopMotion();
        f.w04 = 0;
        f.x = Math.trunc(c.x) + c.facing * 0x37;
        f.y = Math.trunc(c.y) - 0x29;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 2 && o.y === 0.0 && oppStateOutside(c, 150)) c.w16c = 1;
        else c.w16c = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 8;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function throw251(c, form0) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.stopMotion();
    if (form0) {
        c.biasCameraY(50, 3);
        if (c.frame > 5 && c.command === 10) {
            c.state = 0x106;
            c.faceOpponent();
            c.onStateChange();
            return;
        }
        if (c.frame === 9 && c.command === 11) {
            c.state = 0xfc;
            c.onStateChange();
            return;
        }
        if (c.frame === 9 && c.command === 12 && c.meter >= 0xbb8 && c.life <= 0xd05) {
            c.state = 0x132;
            c.onStateChange();
            return;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 1) {
            o.x = c.facing * 0xb + c.x;
            o.y = -62.0;
            o.state = 100;
            o.onStateChange();
        }
        if (c.frame === 2) {
            o.x = c.x - c.facing * 0xb;
            o.y = -57.0;
            o.state = 100;
            o.onStateChange();
        }
        if (c.frame === 3) {
            o.x = c.x - c.facing * 0xb;
            o.y = -52.0;
            o.state = 0x68;
            o.onStateChange();
        }
        if (c.frame === 4) {
            o.x = c.x - c.facing * 0x19;
            o.y = -55.0;
            o.state = 0x68;
            o.onStateChange();
        }
        if (c.frame === 5) {
            o.x = c.x - c.facing * 0x25;
            o.y = -54.0;
            o.state = 0x3f;
            o.onStateChange();
            if (form0) {
                o.knockX = 0.0;
                o.knockY = -5.0;
            } else {
                o.knockX = 0.5;
                o.knockY = -2.6;
            }
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state251(c) {
    throw251(c, true);
}
function state251b(c) {
    throw251(c, false);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.biasCameraY(50, 3);
    if (c.frame === 2 && c.timer === 0) {
        c.seRequest = 0x14;
        if (o.y > -80.0 && o.y < 0.0) {
            c.seRequest = 0x24;
            o.state = 0x47;
            o.faceOpponent();
            o.onStateChange();
            o.stopMotion();
            o.knockX = (o.y / 80.0 + 1.0) * 8.0;
            o.knockY = -((o.y / 80.0 + 1.0) * 8.0);
            if (o.y > -30.0) c.voiceRequest = 4;
            applyDirectDamage(c, Math.trunc((o.y / 80.0 + 1.0) * 4500.0), 500.0);
            c.hitstop = s16(Math.trunc((o.y / 80.0 + 1.0) * 120.0));
            o.hitstop = s16(Math.trunc((o.y / 80.0 + 1.0) * 120.0));
            c.shakeScreen(Math.trunc((o.y / 80.0 + 1.0) * 10.0), 0);
            f.w04 = 0;
            f.x = Math.trunc(o.x);
            f.y = Math.trunc(o.y) - 0x32;
            f.b20 = 2;
            f.b21 = 1;
            frameEffect(f);
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.d168 = 0;
        c.frame++;
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state252b(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.biasCameraY(50, 3);
    if (c.frame === 3 && c.timer === 0) {
        c.seRequest = 0x14;
        c.w16c = 1;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.d168 = 0;
        c.frame++;
        if (c.frame === 4) {
            c.frame = 6;
            if (o.y > -80.0) c.frame = 5;
            if (o.y > -40.0) c.frame = 4;
            return;
        }
        if (c.frame === 5 || c.frame === 6) c.frame = 7;
        if (c.frame >= cnt) {
            c.state = 0;
            if (c.inputY === 1) c.state = 3;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function dashSlash(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    if (p.clearB158) c.b158 = 0;
    if (c.frame > 2 && c.frame < 11 && (c.d168 === 2 || c.d168 === 7)) {
        c.timer = 0;
        c.frame = 19;
        c.d168 = 0;
        c.ax = 0.025;
        return;
    }
    if (c.frame > 2 && c.frame < 11 && c.d168 === 3 && o.y === 0.0) {
        c.timer = 0;
        c.frame = 11;
        c.d168 = 0;
        return;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 2;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 0xf);
        c.vx = p.speed;
    }
    if (c.frame === 11 && c.timer === 0) c.stopMotion();
    if (c.frame === 14 && c.timer === 0) c.vx = 1.4;
    if (c.frame === 19 && c.timer === 0) c.stopMotion();
    if (c.frame === 20 && c.timer === 0) c.ax = -0.035;
    c.vx = c.vx + c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    c.timer++;
    if (c.frame > 12 && c.frame < 19 && o.hitstop === 0 && o.state === 0x49) {
        o.state = 0x62;
        o.onStateChange();
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 11) {
            if (c.f3138 >= p.limit) {
                c.frame = 22;
                c.ax = -0.02;
                return;
            }
            c.frame = c.frame - 8 & 0xffff;
            c.f3138++;
        }
        if (c.frame === 19) {
            c.onStateChange();
            c.state = 0;
            c.faceOpponent();
            return;
        }
        if (c.frame === 22) {
            c.onStateChange();
            c.state = 3;
            return;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
const DASH_253 = {
    clearB158: true,
    speed: 1.6,
    limit: 0
};
const DASH_254 = {
    clearB158: true,
    speed: 3.0,
    limit: 1
};
const DASH_253B = {
    clearB158: false,
    speed: 1.6,
    limit: 0
};
const DASH_254B = {
    clearB158: false,
    speed: 3.0,
    limit: 1
};
const DASH_255B = {
    clearB158: false,
    speed: 2.0,
    limit: 0
};
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.b158 = 0;
    if (c.frame > 2 && c.frame < 11 && (c.d168 === 2 || c.d168 === 7)) {
        c.timer = 0;
        c.frame = 24;
        c.d168 = 0;
        c.ax = 0.025;
        return;
    }
    if (c.frame > 2 && c.frame < 11 && c.d168 === 3 && o.y === 0.0) {
        c.timer = 0;
        c.frame = 11;
        c.d168 = 0;
        return;
    }
    if (c.frame > 2 && c.frame < 11 && c.f3140 <= 0) {
        f.w04 = 0x22;
        f.x = Math.trunc(c.x) + c.facing * 0x47;
        f.y = Math.trunc(c.y) - 0x31;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        c.f3140 = 2;
    }
    c.f3140 = c.f3140 - 1;
    if (c.frame === 0 && c.timer === 0) {
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 3;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.seRequest = 0x14;
        c.meter = s16(c.meter + 0xf);
        c.vx = 2.0;
    }
    if (c.frame === 11 && c.timer === 0) c.stopMotion();
    if (c.frame === 24 && c.timer === 0) c.vx = 1.4;
    if (c.frame === 29 && c.timer === 0) c.stopMotion();
    if (c.frame === 25 && c.timer === 0) c.ax = -0.035;
    c.vx = c.vx + c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 11) {
            if (c.f3138 >= 0) {
                c.frame = 27;
                c.ax = -0.02;
                return;
            }
            c.frame = c.frame - 8 & 0xffff;
            c.f3138++;
        }
        if (c.frame === 24) {
            c.onStateChange();
            c.state = 0;
            c.faceOpponent();
            return;
        }
        if (c.frame === 27) {
            c.onStateChange();
            c.state = 3;
            return;
        }
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function throwShinai(c, kick, ay, shinai, ex) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
        if (ex) {
            rfCost(c);
            effect21(c, f);
        }
    }
    if (ex && c.f3140 === 1) {
        c.f3140 = 0;
        c.w16c = 1;
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 4 && c.timer === 0) {
        c.vy = c.vy - kick;
        c.ay = ay;
    }
    if (c.frame === 13 && c.timer === 0) {
        f.w04 = shinai;
        f.x = Math.trunc(c.x) + c.facing * 0x4b;
        f.y = Math.trunc(c.y) - 0x2c;
        f.b18 = c.facing;
        f.b21 = 0;
        f.d28 = 1;
        f.d00 = 1;
        f.b20 = 0;
        frameChild(c, f);
        f.w04 = 0x191;
        f.x = Math.trunc(c.x) + c.facing * 0x4b;
        f.y = Math.trunc(c.y) - 0x2c;
        f.b18 = c.facing;
        f.b21 = 1;
        f.b20 = 2;
        frameChild(c, f);
        c.setForm(1);
        c.f344c = 1;
        c.voiceRequest = 3;
    }
    if (c.frame > 12) {
        c.setForm(1);
        c.f344c = 1;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.frame > 13 && c.frame < 19 && c.y + c.vy > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 19;
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame < 2) c.d168 = 0;
        if (c.frame === 19) c.frame = c.frame - 2 & 0xffff;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 3;
        }
    }
}
function state256(c) {
    throwShinai(c, 1.5, 0.026, 0x190, false);
}
function state257(c) {
    throwShinai(c, 2.5, 0.028, 0x190, false);
}
function state258(c) {
    throwShinai(c, 2.5, 0.028, 0x19d, true);
}
function throwShinaiB(c, kick, ay, shinai) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.frame === 4 && c.timer === 0) {
        c.vx = 0.5;
        c.vy = c.vy - kick;
        c.ay = ay;
    }
    if (c.frame === 13 && c.timer === 0) {
        f.w04 = shinai;
        f.x = Math.trunc(c.x) + c.facing * 0x4b;
        f.y = Math.trunc(c.y) - 0x2c;
        f.b18 = c.facing;
        f.b21 = 0;
        f.b20 = 0;
        frameChild(c, f);
        f.w04 = 0x191;
        f.x = Math.trunc(c.x) + c.facing * 0x4b;
        f.y = Math.trunc(c.y) - 0x2c;
        f.b18 = c.facing;
        f.b21 = 1;
        f.b20 = 2;
        frameChild(c, f);
        c.setForm(1);
        c.voiceRequest = 3;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.frame > 13 && c.frame < 19 && c.y + c.vy > 0.0) {
        c.y = 0.0;
        c.stopMotion();
        c.timer = 0;
        c.frame = 19;
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 19) c.frame = c.frame - 2 & 0xffff;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 3;
        }
    }
}
function state256b(c) {
    throwShinaiB(c, 1.5, 0.026, 0x190);
}
function state257b(c) {
    throwShinaiB(c, 2.5, 0.028, 0x190);
}
function state258b(c) {
    throwShinaiB(c, 2.5, 0.028, 0x195);
}
function scatterSlash(c, f, base, range) {
    f.w04 = (c.random(0, range) & 0xffff) + base & 0xffff;
    const k = c.facing * (0x28 - (c.random(0, 0x46) & 0xffff));
    f.x = Math.trunc(k + c.x);
    f.y = Math.trunc(c.y);
}
function trailSlash(c, f) {
    f.w04 = (c.random(0, 1) & 0xffff) + 0x199 & 0xffff;
    f.x = Math.trunc(c.x) + c.facing * 0xa;
    f.y = Math.trunc(c.y);
    frameChild(c, f);
}
function slashBurst(c, form0, count, shake) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (form0) c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        if (form0) c.w16c = 1;
    }
    if (form0 && c.d168 > 1 && c.f3138 === 0) {
        c.f3138++;
        c.opponent.hitstop = s16(c.opponent.hitstop + 0x1e);
    }
    if (c.frame === (form0 ? 5 : 6) && c.timer === 0) {
        for(let n = 0; n < count; n++){
            if (form0) scatterSlash(c, f, 0x199, 1);
            else scatterSlash(c, f, 0x195, 3);
            if (n === 0) {
                f.b18 = c.facing;
                f.b21 = 1;
                f.b20 = 0;
            }
            frameChild(c, f);
        }
        f.w04 = 0x19b;
        f.x = Math.trunc(c.x) + c.facing * 0xa;
        f.y = Math.trunc(c.y);
        frameChild(c, f);
        for(let n = 0; n < 5; n++)trailSlash(c, f);
        c.shakeScreen(shake, 0);
        c.voiceRequest = 0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (!form0 || c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state259(c) {
    slashBurst(c, true, 5, 6);
}
function state260(c) {
    slashBurst(c, true, 8, 10);
}
function state259b(c) {
    slashBurst(c, false, 5, 6);
}
function state260b(c) {
    slashBurst(c, false, 8, 10);
}
function state261(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.w16c = 1;
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 6 && c.timer === 0) {
        f.w04 = 0x1ad;
        f.x = Math.trunc(c.x) + (c.facing << 4);
        f.y = Math.trunc(c.y);
        f.b18 = c.facing;
        f.b21 = 1;
        f.b20 = 0;
        frameChild(c, f);
        c.shakeScreen(6, 0);
        c.voiceRequest = 0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state261b(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 6 && c.timer === 0) {
        for(let n = 0; n < 5; n++){
            f.w04 = (c.random(0, 3) & 0xffff) + 0x195 & 0xffff;
            const k = c.facing * (0x28 - (c.random(0, 0x46) & 0xffff));
            f.x = Math.trunc(k + c.x + Math.imul(Math.imul(c.f3138, 0x50), c.facing));
            f.y = Math.trunc(c.y);
            if (n === 0) {
                f.b18 = c.facing;
                f.b21 = 1;
                f.b20 = 0;
            }
            frameChild(c, f);
        }
        f.w04 = 0x19b;
        f.x = Math.trunc(c.x) + Math.imul(Math.imul(c.f3138, 0x50), c.facing) + 0xa;
        f.y = Math.trunc(c.y);
        frameChild(c, f);
        for(let n = 0; n < 5; n++){
            f.w04 = (c.random(0, 1) & 0xffff) + 0x199 & 0xffff;
            const k = c.facing * (0x28 - (c.random(0, 0x46) & 0xffff));
            f.x = Math.trunc(k + c.x + Math.imul(Math.imul(c.f3138, 0x50), c.facing));
            f.y = Math.trunc(c.y);
            frameChild(c, f);
        }
        c.shakeScreen(6, 0);
        c.voiceRequest = 0;
    }
    c.timer++;
    if (c.frame === 8 && c.f3138 > 1 && c.f3138 < 0x78) {
        c.f3138++;
        c.timer = c.timer - 1 & 0xffff;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            if (c.f3138 < 2) {
                c.f3138++;
                c.frame = 0;
                c.timer = 1;
                return;
            }
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state262(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame < 3) c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 0) c.w16c = 1;
    if (c.d168 === 3 && c.frame === 2) {
        c.timer = 0;
        c.frame = 3;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 3) c.frame = 5;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
            c.faceOpponent();
        }
    }
}
function state262b(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = c.vx * 0.5;
        c.vy = c.vy * 0.5;
        c.ay = 0.01;
        c.meter = s16(c.meter + 0x2d);
        c.f3138 = 4;
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 5) {
            f.w04 = 0x198;
            f.x = Math.trunc(c.x) + c.facing * 0x24;
            f.y = Math.trunc(c.y) - 0x30;
            f.b20 = 2;
            f.b21 = 1;
            f.b18 = c.facing;
            frameChild(c, f);
            c.voiceRequest = 6;
        }
        if (c.frame === 7 && c.f3138 > 0) {
            c.frame = c.frame - 2 & 0xffff;
            c.f3138--;
        }
        if (c.frame >= cnt) {
            c.state = 9;
            c.onStateChange();
        }
    }
}
function spawn405(c, f) {
    f.w04 = 0x195;
    f.x = Math.trunc(c.x) + c.facing * 0x1e;
    f.y = Math.trunc(c.y) - 0x1e;
    f.b18 = c.facing;
    f.b21 = 1;
    f.b20 = 2;
    frameChild(c, f);
}
function state265b(c) {
    const dur = frameDuration(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.stopMotion();
        c.f3138 = 2;
    }
    if (c.frame === 3 && c.timer === 0) {
        spawn405(c, f);
        c.voiceRequest = 1;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 8) {
            if (c.f3138 > 1) {
                c.f3138--;
                c.frame = 1;
                return;
            }
            c.state = 0;
            c.onStateChange();
            c.faceOpponent();
        }
    }
}
function state266b(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.vx = -0.9;
        c.vy = -2.1;
        c.ay = 0.04;
        c.voiceRequest = 1;
        spawn405(c, f);
    }
    c.vy = c.vy + c.ay;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.y + c.vy > 0.0) {
            c.y = 0.0;
            c.vy = 0.0;
            c.ay = 0.0;
            c.vx = 0.0;
            c.onStateChange();
            c.state = 0xd;
            return;
        }
        if (c.frame >= cnt) c.frame = 1;
    }
}
registerStates({
    248: state248,
    249: state249,
    250: state250,
    251: state251,
    252: state252,
    253: (c)=>dashSlash(c, DASH_253),
    254: (c)=>dashSlash(c, DASH_254),
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state250,
    264: state250
});
registerStates2({
    248: state248b,
    249: state249b,
    250: state250,
    251: state251b,
    252: state252b,
    253: (c)=>dashSlash(c, DASH_253B),
    254: (c)=>dashSlash(c, DASH_254B),
    255: (c)=>dashSlash(c, DASH_255B),
    256: state256b,
    257: state257b,
    258: state258b,
    259: state259b,
    260: state260b,
    261: state261b,
    262: state262b,
    265: state265b,
    266: state266b
});

export function __logicState(){return {DASH_253,DASH_254,DASH_253B,DASH_254B,DASH_255B};}

export function __installInitialRoots(s){
if(DASH_253!==s["DASH_253"])throw Error('INITIAL_CONST_IDENTITY:DASH_253');
if(DASH_254!==s["DASH_254"])throw Error('INITIAL_CONST_IDENTITY:DASH_254');
if(DASH_253B!==s["DASH_253B"])throw Error('INITIAL_CONST_IDENTITY:DASH_253B');
if(DASH_254B!==s["DASH_254B"])throw Error('INITIAL_CONST_IDENTITY:DASH_254B');
if(DASH_255B!==s["DASH_255B"])throw Error('INITIAL_CONST_IDENTITY:DASH_255B');
}
