import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerChildren, registerStates } from "./4fd020f21e3ef9d96dc087c0.mjs";
import { childCount, childDuration, frameChild, frameEffect, openSpawnFrame } from "./b1bf50e501f736bc8b07bfdb.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
const w16 = (v)=>v & 0xffff;
function advance(c, dur) {
    c.timer = w16(c.timer + 1);
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame = w16(c.frame + 1);
    return true;
}
function atStart(c) {
    return c.frame === 0 && c.timer === 0;
}
function atFrame(c, n) {
    return c.frame === n && c.timer === 0;
}
function addMeter(c, n) {
    c.meter = s16(c.meter + n);
}
function normalHit(c, meter, se) {
    addMeter(c, meter);
    c.seRequest = se;
    c.w16c = 1;
}
function fxAt(c, d, pat, dx, dy, blend, layer) {
    d.w04 = pat;
    d.x = ftol(c.x) + dx;
    d.y = ftol(c.y) + dy;
    d.b20 = blend;
    d.b21 = layer;
    frameEffect(d);
}
function jumpTo456(c) {
    c.state = 4;
    if (c.inputX === c.facing) c.state = 5;
    if (c.inputX === -c.facing) c.state = 6;
    c.d168 = 0;
    c.onStateChange();
}
function groundJumpCancel(c, ok) {
    if (c.inputY !== -1 || c.frame <= 0 || c.d15c >= 3 || !ok) return false;
    jumpTo456(c);
    return true;
}
function airJumpCancel(c) {
    if (c.inputY !== -1 || c.frame <= 0 || c.d15c >= 3 || c.d168 < 2 || c.b15a !== 0) return false;
    c.b15a = c.b15a + 1 & 0xff;
    c.state = 14;
    if (c.inputX === c.facing) c.state = 15;
    if (c.inputX === -c.facing) c.state = 16;
    c.d168 = 0;
    c.onStateChange();
    return true;
}
function slide(c, decel) {
    if (c.b158 === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1) {
        c.vx -= decel;
    } else {
        c.vx = 0.0;
        c.b158 = 0;
    }
}
function endGround(c, base, crouchable) {
    c.state = base;
    if (crouchable && c.inputY === 1) c.state = 3;
    c.faceOpponent();
    c.onStateChange();
}
function landTo13(c) {
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.setState(13);
        return true;
    }
    return false;
}
function guardGround(c, crouch, stand, meter, vx0, standEnd) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.inputY === 1) c.state = crouch;
    if (c.inputY !== 1) c.state = stand;
    if (atStart(c)) {
        c.b158 = 0;
        addMeter(c, meter);
        c.vx = vx0;
        c.vy = 0.0;
        c.y = 0.0;
    }
    c.vy = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.x - 20.0 <= 0.0 || c.x + 20.0 >= 639.0) c.pushToOpponent = c.vx;
    else c.pushToOpponent = 0.0;
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) {
            if (standEnd) {
                c.state = 0;
                if (c.inputY === 1) c.state = 3;
            } else {
                c.state = 3;
            }
            c.onStateChange();
        }
    }
}
const s150 = (c)=>guardGround(c, 153, 150, 10, -1.5, true);
const s151 = (c)=>guardGround(c, 154, 151, 15, -1.8, true);
const s152 = (c)=>guardGround(c, 155, 152, 20, -2.3, true);
const s153 = (c)=>guardGround(c, 153, 150, 10, -1.5, false);
const s154 = (c)=>guardGround(c, 154, 151, 15, -1.8, false);
const s155 = (c)=>guardGround(c, 155, 152, 20, -2.3, false);
function s156(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vy = -2.6;
        addMeter(c, 15);
        c.ay = 0.06;
    }
    c.vx = -1.2;
    c.vy += c.ay;
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function airRecover(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = vx;
    c.ay = 0.045;
    if (atStart(c)) {
        c.vy = -2.3;
        fxAt(c, d, 8, 0, 0, 2, 0);
    } else {
        c.vy += c.ay;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
const s157 = (c)=>airRecover(c, 1.0);
const s158 = (c)=>airRecover(c, -1.0);
function s161(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.stopMotion();
        fxAt(c, d, 9, 0, -70, 2, 1);
        c.w16c = 1;
        c.seRequest = 62;
        c.f3138++;
    }
    if (advance(c, dur) && c.frame >= cnt) {
        c.setState(9);
        c.ay = 0.035;
    }
}
function s162(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2)) {
        c.vy = -1.5;
        c.ay = 0.025;
        c.w16c = 1;
    }
    if (atFrame(c, 6)) {
        c.stopMotion();
        fxAt(c, d, 9, 0, -70, 2, 1);
        c.w16c = 1;
        c.seRequest = 62;
        addMeter(c, -1000);
        c.f3138++;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0) {
        c.state = 13;
        c.onStateChange();
        c.onStateChange();
        c.y = 0.0;
        return;
    }
    if (advance(c, dur)) {
        if (c.frame === 15) c.ay = 0.035;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s163(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(3);
        c.stopMotion();
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (c.frame < 5 && c.frame > 1) {
        c.vx = 1.6;
        if (c.f3138 === 0) c.seRequest = 17;
    }
    c.b158 = 1;
    c.f3138++;
    c.timer = w16(c.timer + 1);
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame === 4) c.frame = w16(c.frame - 2);
        if (c.frame >= cnt) {
            c.setState(0);
            return;
        }
    }
    if (c.inputX === c.facing && c.f3138 >= 120 && c.frame < 5) c.setState(178);
    if (c.inputX !== c.facing && c.f3138 >= 60 && c.frame < 5) c.setState(178);
}
function s164(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(2);
    c.b158 = 0;
    if (atStart(c)) c.stopMotion();
    if (atFrame(c, 2) && c.f3138 === 0) {
        c.vx = -2.5;
        c.vy = -1.0;
        c.ay = 0.0;
        c.f3138 = 1;
    }
    c.vx += 0.04;
    if (c.vx > 0.0) c.vx = 0.0;
    if (c.y < 0.0 && c.frame > 2) c.vy += 0.031;
    if (c.y + c.vy > 0.0) {
        c.vy = 0.0;
        c.y = 0.0;
    }
    if (c.vx >= 0.0 && c.y === 0.0 && c.frame > 2) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.setState(13);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.frame = w16(c.frame - 1);
}
function airDashEnd(c, vx, ay) {
    c.setState(9);
    c.vx = vx;
    c.ay = ay;
    if (c.faceOpponent()) c.vx = -c.vx;
}
function s165(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = 1.4;
        c.startAfterimage(3);
        c.vy = 0.0;
        c.ay = 0.0;
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === c.facing && c.f313c >= 120) airDashEnd(c, 1.3, 0.03);
    if (c.inputX !== c.facing && c.f3138 >= 48) airDashEnd(c, 1.3, 0.03);
}
function s166(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c) && c.f3138 === 0) {
        c.vx = -1.4;
        c.vy = 0.0;
        c.ay = 0.0;
        c.startAfterimage(3);
        c.seRequest = 17;
    }
    c.timer = w16(c.timer + 1);
    c.f3138++;
    c.f313c++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame = w16(c.frame + 1);
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
    if (c.inputX === -c.facing && c.f313c >= 120) airDashEnd(c, -0.9, 0.03);
    if (c.inputX !== -c.facing && c.f3138 >= 48) airDashEnd(c, -0.9, 0.03);
}
function icFlash(c) {
    if (c.rfBlue === 1) c.proration = c.rfGauge * 5.0 + c.proration;
    c.rfGauge = 0.0;
    c.freeze = 90;
    c.superDarken(0xb0, 3);
}
function s167(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAt(c, d, 1, 0, 0, 2, 1);
    }
    if (atFrame(c, 2)) fxAt(c, d, 4, 0, 0, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function recoilGuard(c, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.ax = 0.0;
        fxAt(c, d, 8, 0, 0, 2, 1);
    }
    if (advance(c, dur)) {
        if (c.frame === cnt) c.faceOpponent();
        if (c.frame >= cnt) c.setState(end);
    }
}
const s168 = (c)=>recoilGuard(c, 0);
const s169 = (c)=>recoilGuard(c, 3);
function s170(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        if (c.ay === 0.0) c.ay = 0.035;
        c.backWindow = 0;
        c.pushToOpponent = 0.0;
        c.freeze = 60;
    }
    if (c.freeze === 0 && c.f3140 === 0) {
        c.f3140++;
        c.vx = c.f3138 * 0.01;
        c.vy = c.f313c * 0.01;
    }
    if (c.freeze === 0) c.vy += c.ay;
    if (c.vy + c.y > 0.0) {
        c.stopMotion();
        c.y = 0.0;
        c.state = 169;
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(9);
}
function s171(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.f3138 = ftol(c.vx * 100.0);
        c.f313c = ftol(c.vy * 100.0);
        c.vx = 0.0;
        c.vy = 0.0;
        icFlash(c);
    }
    if (atFrame(c, 1)) {
        c.seRequest = 18;
        fxAt(c, d, 1, 0, 0, 2, 1);
    }
    if (atFrame(c, 2)) fxAt(c, d, 4, 0, 0, 2, 1);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 9;
            c.vx = c.f3138 * 0.01;
            c.vy = c.f313c * 0.01;
            c.ay = 0.035;
            c.onStateChange();
        }
    }
}
function s178(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx -= 0.03;
    if (c.vx < 0.0) {
        c.vx = 0.0;
        c.b158 = 0;
    }
    if (c.inputY === -1 && c.frame > 0) {
        jumpTo456(c);
        return;
    }
    if (advance(c, dur) && c.frame >= cnt) c.setState(0);
}
function s180(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.startAfterimage(2);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.y < 0.0) c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 9) {
        c.stopMotion();
        c.y = 0.0;
        c.timer = 0;
        c.frame = 9;
        c.seRequest = 9;
    }
    if (advance(c, dur)) {
        if (c.frame === 2) {
            c.vx = -0.5;
            c.vy = -1.0;
            c.ay = 0.028;
        }
        if (c.frame === 9) c.frame = w16(c.frame - 1);
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
        }
    }
}
function groundNormal(c, decel, jc, hitFrame, vx0, meter, se, crouchable) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c, decel);
    if (jc !== null && groundJumpCancel(c, jc(c))) return;
    if (atFrame(c, hitFrame)) {
        if (vx0 !== null) c.vx = vx0;
        normalHit(c, meter, se);
    }
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, crouchable);
    }
}
const jcGe2 = (c)=>c.d168 >= 2;
const jcEq3 = (c)=>c.d168 === 3;
const s200 = (c)=>groundNormal(c, 0.06, jcGe2, 2, null, 5, 21, false);
const s201 = (c)=>groundNormal(c, 0.03, jcGe2, 2, 0.2, 15, 20, false);
const s202 = (c)=>groundNormal(c, 0.06, null, 2, 0.2, 15, 20, false);
function s203(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    slide(c, 0.06);
    if (groundJumpCancel(c, jcEq3(c))) return;
    if (atFrame(c, 6)) normalHit(c, 25, 20);
    if (atFrame(c, 12)) normalHit(c, 25, 20);
    if (advance(c, dur)) {
        if (c.frame < 3) c.d168 = 0;
        if (c.frame === 12) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
const s204 = (c)=>groundNormal(c, 0.03, jcGe2, 1, null, 5, 21, true);
const s205 = (c)=>groundNormal(c, 0.03, jcGe2, 2, null, 13, 20, true);
function s206(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.b158 === 0 && atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (c.vx > 0.0 && c.b158 === 1) c.vx -= 0.03;
    else c.b158 = 0;
    if (c.vx < 0.0) c.vx = 0.0;
    if (atFrame(c, 1)) c.w16c = 1;
    if (atFrame(c, 3) && c.f3138 === 0) {
        addMeter(c, 25);
        c.seRequest = 20;
        c.f3138++;
    }
    if (advance(c, dur)) {
        if (c.frame < 2) c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, true);
    }
}
function airNormal(c, hitFrame, meter, se, keepFrom) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    if (airJumpCancel(c)) return;
    if (atFrame(c, hitFrame)) normalHit(c, meter, se);
    if (landTo13(c)) return;
    if (advance(c, dur)) {
        if (c.frame < keepFrom) c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
const s207 = (c)=>airNormal(c, 2, 5, 21, 3);
const s208 = (c)=>airNormal(c, 3, 13, 20, 4);
const s209 = (c)=>airNormal(c, 4, 30, 20, 3);
function s210(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 1)) {
        c.vx = 1.4;
        c.vy = -1.5;
        c.ay = 0.08;
    }
    if (atFrame(c, 2)) normalHit(c, 15, 20);
    if (atFrame(c, 5)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
    }
    if (c.frame > 0) c.vy += c.ay;
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 5) {
            if (c.y + c.vy < 0.0) c.frame = w16(c.frame - 1);
            else c.y = 0.0;
        }
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function s211(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (groundJumpCancel(c, jcGe2(c))) return;
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    if (atFrame(c, 3)) normalHit(c, 30, 20);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function landImpact(c, d) {
    c.shakeScreen(3, 0);
    d.w04 = 3;
    d.x = ftol(c.x);
    d.y = ftol(c.y);
    d.b20 = 2;
    d.b21 = 0;
    d.b2c = 7;
    frameEffect(d);
}
function s212(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vy += c.ay;
    if (atStart(c)) {
        normalHit(c, 30, 20);
        c.vx = c.vx / 2.0;
        c.ay = 0.07;
    }
    if (c.d168 > 1) {
        c.setState(213);
        c.stopMotion();
        return;
    }
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.vy = 0.0;
        landImpact(c, d);
        c.setState(214);
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
function s213(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.ay = 0.042;
    c.vy += c.ay;
    if (atStart(c)) {
        c.vx = -1.0;
        c.vy = -2.4;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) c.setState(9);
    }
}
function s214(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.vx = 0.0;
    c.vy = 0.0;
    if (atStart(c)) landImpact(c, d);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 7, true);
    }
}
function s220(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const o = c.opponent;
    c.vx = 0.0;
    c.vy = 0.0;
    if (atFrame(c, 1) && o.y === 0.0) c.w16c = 1;
    else c.w16c = 0;
    if (c.frame === 1 && c.d168 === 3) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.onStateChange();
        c.stopMotion();
        o.stopMotion();
        o.onStateChange();
        c.state = 221;
        o.d128 = 1;
        return;
    }
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame >= cnt) endGround(c, 0, true);
    }
}
function s221(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atFrame(c, 4)) applyDirectDamage(c, 1250, 750.0);
    if (advance(c, dur)) {
        c.d168 = 0;
        if (c.frame === 1) c.w16c = 1;
        if (c.frame >= cnt) endGround(c, 0, false);
    }
}
function afterimageNormal(c, jc, hitFrame, meter, se, keepFrom, end) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.startAfterimage(3);
    c.b158 = 0;
    c.vx -= 0.03;
    if (c.vx < 0.0) c.vx = 0.0;
    if (jc && groundJumpCancel(c, jcEq3(c))) return;
    if (atStart(c)) {
        c.vx = 2.0;
        c.vy = 0.0;
    }
    if (atFrame(c, hitFrame)) normalHit(c, meter, se);
    if (advance(c, dur)) {
        if (c.frame < keepFrom) c.d168 = 0;
        if (c.frame >= cnt) c.setState(end);
    }
}
const s230 = (c)=>afterimageNormal(c, false, 2, 5, 21, 3, 0);
const s231 = (c)=>afterimageNormal(c, false, 2, 10, 20, 3, 0);
const s232 = (c)=>afterimageNormal(c, false, 2, 10, 20, 3, 0);
const s233 = (c)=>afterimageNormal(c, false, 1, 5, 21, 5, 3);
const s234 = (c)=>afterimageNormal(c, false, 3, 10, 20, 3, 3);
const s235 = (c)=>afterimageNormal(c, true, 2, 10, 20, 3, 0);
function s248(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.vy += c.ay;
    if (c.frame === 1 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.stopMotion();
        c.state = 249;
        o.state = 100;
        fxAt(c, d, 0, c.facing * 32, -62, 2, 1);
        o.x = c.facing * 32 + c.x;
        o.y = c.y - 72.0;
    }
    if (advance(c, dur)) {
        if (c.frame === 1 && o.y < 0.0 && (o.state < 50 || o.state > 149)) c.w16c = 1;
        else c.w16c = 0;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 209;
            c.frame = 2;
        }
    }
}
function s249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    if (c.frame < 8) c.biasCamera(50, 3);
    if (c.frame < 8) c.biasCameraY(50, 3);
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy += c.ay;
    if (c.vy + c.y > 0.0 && c.frame > 5) {
        c.stopMotion();
        c.y = 0.0;
        c.onStateChange();
        c.state = 13;
        return;
    }
    if (atFrame(c, 8)) c.ay = 0.035;
    if (advance(c, dur)) {
        if (c.frame === 2) {
            o.onStateChange();
            o.state = 121;
        }
        if (c.frame === 6) {
            d.w04 = 453;
            d.x = c.facing * 6 + c.x;
            d.y = c.y - 14.0;
            d.b18 = c.facing;
            d.b21 = 1;
            d.b20 = 0;
            d.d00 = 1;
            frameChild(c, d);
        }
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = w16(c.frame - 2);
    }
}
registerStates({
    150: s150,
    151: s151,
    152: s152,
    153: s153,
    154: s154,
    155: s155,
    156: s156,
    157: s157,
    158: s158,
    161: s161,
    162: s162,
    163: s163,
    164: s164,
    165: s165,
    166: s166,
    167: s167,
    168: s168,
    169: s169,
    170: s170,
    171: s171,
    178: s178,
    180: s180,
    200: s200,
    201: s201,
    202: s202,
    203: s203,
    204: s204,
    205: s205,
    206: s206,
    207: s207,
    208: s208,
    209: s209,
    210: s210,
    211: s211,
    212: s212,
    213: s213,
    214: s214,
    220: s220,
    221: s221,
    230: s230,
    231: s231,
    232: s232,
    233: s233,
    234: s234,
    235: s235,
    248: s248,
    249: s249
});
function childAdvance(c, i) {
    const ch = c.children[i];
    ch.timer = w16(ch.timer + 1);
    if (ch.timer < childDuration) return false;
    ch.timer = 0;
    ch.frame = w16(ch.frame + 1);
    ch.hitState = 0;
    return true;
}
function partnerStart(c, i) {
    const ch = c.children[i];
    c.f3148 = 4;
    if (ch.hitState === 4 || ch.hitState === 5) {
        ch.pattern = 403;
        ch.frame = 0;
        ch.timer = 0;
        return true;
    }
    return false;
}
function partnerClampX(c, i) {
    const ch = c.children[i];
    if (ch.x > 620.0) {
        ch.vx = 0.0;
        ch.x = 620.0;
    }
    if (ch.x < 20.0) {
        ch.vx = 0.0;
        ch.x = 20.0;
    }
}
function partnerEnd(c, i) {
    const ch = c.children[i];
    if (ch.frame >= childCount) {
        ch.pattern = 400;
        ch.frame = 0;
        c.f3148 = 0;
    }
}
function cJump(c, i, vx, vy, hits) {
    const ch = c.children[i];
    if (partnerStart(c, i)) return;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
    if (ch.frame === 9 && ch.timer === 0) {
        ch.vx = vx;
        ch.vy = vy;
        ch.ay = 0.025;
        ch.hitsLeft = hits;
    }
    if (ch.y < 0.0 && ch.frame < 12) {
        ch.vy += ch.ay;
        if (ch.y + ch.vy > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.timer = 0;
            ch.frame = 12;
            return;
        }
    }
    if (ch.hitState > 0) {
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 425;
        return;
    }
    partnerClampX(c, i);
    if (childAdvance(c, i)) {
        if (ch.frame === 12) ch.frame = w16(ch.frame - 2);
        partnerEnd(c, i);
    }
}
const c404 = (c, i)=>cJump(c, i, 0.9, -1.1, 1);
const c405 = (c, i)=>cJump(c, i, 1.5, -1.4, 1);
const c406 = (c, i)=>cJump(c, i, 2.0, -1.4, 5);
function cDouble(c, i, vx, vy, ay, back, is409) {
    const ch = c.children[i];
    const o = c.opponent;
    if (partnerStart(c, i)) return;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.hitsLeft = 0;
    }
    if (ch.frame === 9 && ch.timer === 0) {
        ch.vx = vx;
        ch.vy = vy;
        ch.ay = ay;
    }
    if (ch.frame === 9) {
        if (o.y < 0.0) ch.hitsLeft = 1;
        else ch.hitsLeft = 0;
    }
    if (ch.frame === 10 && ch.timer === 0) ch.hitsLeft = 1;
    if (is409 && ch.y < 0.0 && ch.vx > 0.0 && ch.x - o.x < 50.0 && ch.x - o.x > -50.0 && ch.frame < 17) {
        ch.vx -= 0.02;
        if (ch.vx < 0.0) ch.vx = 0.0;
    }
    if (ch.y < 0.0 && ch.frame < 15) {
        ch.vy += ch.ay;
        if (ch.y + ch.vy > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.timer = 0;
            ch.frame = 15;
            if (is409) ch.hitState = 0;
        }
    }
    if (ch.frame === 18 && ch.timer === 0) {
        ch.vx = back;
        ch.vy = -1.0;
        ch.ay = 0.035;
        ch.hitsLeft = 1;
    }
    if (ch.y < 0.0 && ch.frame < 23 && ch.frame > 18) {
        ch.vy += ch.ay;
        if (ch.y + ch.vy > 0.0) {
            ch.y = 0.0;
            ch.vy = 0.0;
            ch.vx = 0.0;
            ch.timer = 0;
            ch.frame = 23;
            if (is409) ch.hitState = 0;
        }
    }
    partnerClampX(c, i);
    if (childAdvance(c, i)) {
        if (ch.frame === 15) ch.frame = w16(ch.frame - 1);
        if (ch.frame === 23) ch.frame = w16(ch.frame - 1);
        partnerEnd(c, i);
    }
}
const c407 = (c, i)=>cDouble(c, i, 0.2, -2.5, 0.035, -0.8, false);
const c408 = (c, i)=>cDouble(c, i, 0.5, -2.5, 0.035, -0.8, false);
const c409 = (c, i)=>cDouble(c, i, 1.3, -3.5, 0.045, -1.0, true);
function c453(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    if (ch.frame === 0) {
        ch.vy = 3.0;
        o.x = ch.x;
        o.y = ch.y;
    }
    if (ch.frame === 0 && ch.y + ch.vy > 0.0) {
        ch.timer = 0;
        ch.frame = 1;
        o.onStateChange();
        o.state = 98;
        o.y = 0.0;
        o.x = ch.x;
        applyDirectDamage(c, 1200, 500.0);
        ch.vy = 0.0;
    }
    ch.timer = w16(ch.timer + 1);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame = w16(ch.frame + 1);
        if (ch.frame === 3) ch.blend = 1;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
}
registerChildren({
    404: c404,
    405: c405,
    406: c406,
    407: c407,
    408: c408,
    409: c409,
    453: c453
});
