import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { blit, makeRect } from "./f0fa1d17b22aa5b0aa75bc83.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
import { registerChildren, registerChildren2, registerStates, registerStates2 } from "./00697db762b413ef9f6a1cba.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./0a57f8c3d343150e3ded7bb7.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
function drawGauge(c, pattern, len) {
    const f = c.patterns[pattern]?.frames[0];
    if (!f) return;
    const surf = c.sprites[f.sprite];
    if (!surf) return;
    const w = len(f.width);
    const src = makeRect(0, 0, w, f.height);
    const dst = c.side === 0 ? makeRect(0x31 - f.offsetX, 0x1f - f.offsetY, w, f.height) : makeRect(f.offsetX + 0x10f - w, 0x1f - f.offsetY, w, f.height);
    blit(dst, surf, src, c.colorKey, false);
}
export function renderOverlayNanase(c) {
    if (c.f3148 > 0) drawGauge(c, 43, (w)=>w);
    if (c.f3148 > 0) drawGauge(c, 44, (w)=>Math.trunc(w * c.f3148 / 0xbb8));
}
const atStart = (c)=>c.frame === 0 && c.timer === 0;
const atFrame = (c, f)=>c.frame === f && c.timer === 0;
function stepFrame(c, dur) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    c.d168 = 0;
    return true;
}
function endToNeutral(c, cnt) {
    if (c.frame >= cnt) {
        c.state = 0;
        c.onStateChange();
    }
}
function superFreeze(c, cost) {
    c.freeze = 0x78;
    c.meter = s16(c.meter - cost);
    c.superDarken(0xb0, 3);
}
function superEffect(d, c, pat, sound, offX, offY) {
    d.w04 = pat;
    d.b2c = sound;
    d.x = ftol(c.x) + c.facing * offX;
    d.y = ftol(c.y) - offY;
    d.b20 = 2;
    d.d00 = 1;
    d.b21 = 1;
    frameEffect(d);
}
function state299(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        c.seRequest = 0x1a;
    }
    if (stepFrame(c, dur) && c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state299b(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (atStart(c)) c.stopMotion();
    if (stepFrame(c, dur) && c.frame >= cnt) {
        c.state = 0;
        c.faceOpponent();
        c.onStateChange();
    }
}
function beamSuper(c, cost, pat, sound) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
    }
    c.biasCameraY(0x32, 3);
    if (atFrame(c, 2)) {
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, -0xd, 0x5d);
    }
    if (c.frame >= 1) c.wF2 = 0xa;
    if (atFrame(c, 6)) {
        c.shakeScreen(0x14, 0);
        c.seRequest = 0x16;
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function state302(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
    }
    c.biasCameraY(0x32, 3);
    if (atFrame(c, 2)) {
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40, -0xd, 0x5d);
        c.seRequest = 0x25;
    }
    if (c.frame >= 2) c.showAltBackground(0xf);
    if (atFrame(c, 6)) {
        c.shakeScreen(0x14, 0);
        c.seRequest = 0x16;
        if (c.d168 === 3) c.opponent.hitstop = 0x168;
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function state300b(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
    }
    c.biasCameraY(0x32, 3);
    if (atFrame(c, 2)) {
        superFreeze(c, 0x3e8);
        superEffect(d, c, 9, 5, -0xd, 0x5d);
    }
    if (c.frame >= 1) c.wF2 = 0xa;
    if (atFrame(c, 6)) {
        c.shakeScreen(0x14, 0);
        c.voiceRequest = 0x16;
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function rushSuper(c, cost, pat, sound, big) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (atFrame(c, 4)) {
        c.biasCameraY(0x32, 0x78);
        superFreeze(c, cost);
        superEffect(d, c, pat, sound, 0x13, 0x22);
        if (big) c.seRequest = 0x25;
    }
    if (big) {
        if (c.frame >= 4) c.showAltBackground(0xf);
    } else if (c.frame >= 1) {
        c.wF2 = 0xa;
    }
    if (atFrame(c, 5)) c.vx = 6.0;
    if (c.frame > 8) {
        c.vx = c.vx - 0.2;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.d168 === 3) c.shakeScreen(0xa, 0);
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
function spawn412(c, d) {
    d.w04 = 0x19c;
    d.x = ftol(c.x);
    d.y = ftol(c.y) - 0x26;
    d.b18 = c.facing;
    d.b21 = 1;
    d.b20 = 2;
    frameChild(c, d);
}
function state306(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.biasCameraY(0x32, 3);
    if (atStart(c)) {
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40, 0, 0x28);
        c.seRequest = 0x25;
        d.w04 = 0x47;
        frameEffect(d);
    }
    c.showAltBackground(0xf);
    if (atFrame(c, 2)) spawn412(c, d);
    if (atFrame(c, 2)) {
        c.seRequest = 0x14;
        if (o.y > -80.0 && o.y < 0.0) {
            c.seRequest = 0x24;
            o.state = 0x47;
            o.faceOpponent();
            o.onStateChange();
            o.stopMotion();
            o.knockX = (o.y / 80.0 + 1.0) * 8.0 + 1.0;
            o.knockY = -((o.y / 80.0 + 1.0) * 8.0);
            applyDirectDamage(c, ftol((o.y / 80.0 + 1.0) * 6500.0), 500.0);
            if (o.y > -30.0) c.voiceRequest = 4;
            c.hitstop = s16(ftol((o.y / 80.0 + 1.0) * 120.0));
            o.hitstop = s16(ftol((o.y / 80.0 + 1.0) * 120.0));
            c.shakeScreen(ftol((o.y / 80.0 + 1.0) * 10.0), 0);
            d.w04 = 0;
            d.x = ftol(o.x);
            d.y = ftol(o.y) - 0x32;
            d.b20 = 2;
            d.b21 = 1;
            frameEffect(d);
        }
    }
    if (stepFrame(c, dur) && c.frame >= cnt) {
        c.state = 0;
        if (c.inputY === 1) c.state = 3;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state306b(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    const o = c.opponent;
    c.biasCameraY(0x32, 3);
    if (atStart(c)) {
        superFreeze(c, 0xbb8);
        superEffect(d, c, 9, 5, 0, 0x28);
    }
    if (atFrame(c, 2)) spawn412(c, d);
    if (atFrame(c, 3)) {
        c.seRequest = 0x14;
        c.w16c = 1;
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 4) {
        c.frame = 6;
        if (o.y > -80.0) c.frame = 5;
        if (o.y > -40.0) c.frame = 4;
        return;
    }
    if (c.frame === 5 || c.frame === 6) c.frame = 7;
    if (c.frame >= cnt) {
        c.state = 0;
        if (c.inputY === 1) c.state = 3;
        c.faceOpponent();
        c.onStateChange();
    }
}
function state307(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    c.b158 = 0;
    if (atStart(c)) {
        c.stopMotion();
        c.w16c = 1;
    }
    if (c.frame < 4) c.f3138--;
    if (atStart(c)) {
        c.f3138 = 0x42;
        c.biasCameraY(0x32, 0x78);
        superFreeze(c, 0xbb8);
        superEffect(d, c, 0x46, 0x40, 0x13, 0x22);
        c.seRequest = 0x25;
    }
    c.showAltBackground(0xf);
    if (c.f3138 < 1 && c.frame < 4) {
        c.timer = 0;
        c.frame = 4;
        return;
    }
    if (!stepFrame(c, dur)) return;
    if (c.frame === 4) c.frame -= 3;
    if (c.frame === 9) {
        c.shakeScreen(0xa, 0);
        c.voiceRequest = 3;
        d.w04 = 0x1af;
        d.x = ftol(c.x);
        d.y = ftol(c.y) - 0x26;
        d.b18 = c.facing;
        d.b21 = 0;
        d.b20 = 2;
        d.d00 = 1;
        frameChild(c, d);
        c.f3148 = 0xbb8;
    }
    if (c.frame === 0xb) {
        c.f313c++;
        if (c.f313c > 2) c.w16c = 0;
        if (c.f313c < 0xa) c.frame -= 2;
    }
    endToNeutral(c, cnt);
}
function throwSuper(c, p) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const d = openSpawnFrame();
    if (atStart(c)) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
    }
    c.biasCameraY(0x32, 3);
    if (atStart(c)) {
        superFreeze(c, p.cost);
        superEffect(d, c, p.pat, p.sound, 0, 0x2b);
        if (p.big) c.seRequest = 0x25;
    }
    if (p.big && c.frame > 0) c.showAltBackground(0xf);
    if (atFrame(c, 0xc)) {
        p.cue(c);
        d.w04 = p.child;
        d.x = ftol(c.x) + c.facing * 0x28;
        d.y = ftol(c.y) - 0x28;
        d.b18 = c.facing;
        d.b20 = 0;
        d.d00 = 1;
        d.b21 = 1;
        if (p.shadow) d.d28 = 1;
        frameChild(c, d);
        d.w04 = 0x1a7;
        d.b20 = 2;
        d.d00 = 1;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
        c.f344c = 1;
        if (p.setForm) c.setForm(1);
    }
    if (stepFrame(c, dur)) endToNeutral(c, cnt);
}
const voice5 = (c)=>{
    c.voiceRequest = 5;
};
registerStates({
    299: state299,
    300: (c)=>beamSuper(c, 0x3e8, 0x44, 0x13),
    301: (c)=>beamSuper(c, 0x7d0, 0x45, 5),
    302: state302,
    306: state306,
    307: state307,
    308: (c)=>throwSuper(c, {
            cost: 0x3e8,
            pat: 0x44,
            sound: 0x13,
            big: false,
            cue: voice5,
            child: 0x1a3,
            shadow: true,
            setForm: true
        }),
    309: (c)=>throwSuper(c, {
            cost: 0x7d0,
            pat: 0x45,
            sound: 5,
            big: false,
            cue: voice5,
            child: 0x1a4,
            shadow: true,
            setForm: true
        }),
    310: (c)=>throwSuper(c, {
            cost: 0xbb8,
            pat: 0x46,
            sound: 0x40,
            big: true,
            cue: voice5,
            child: 0x1ac,
            shadow: true,
            setForm: true
        })
});
registerStates2({
    299: state299b,
    300: state300b,
    303: (c)=>rushSuper(c, 0x3e8, 0x44, 0x13, false),
    304: (c)=>rushSuper(c, 0x7d0, 0x45, 5, false),
    305: (c)=>rushSuper(c, 0xbb8, 0x46, 0x40, true),
    306: state306b,
    308: (c)=>throwSuper(c, {
            cost: 0x3e8,
            pat: 9,
            sound: 5,
            big: false,
            child: 0x1a3,
            shadow: false,
            setForm: false,
            cue: (c)=>{
                c.shakeScreen(0x14, 0);
                c.seRequest = 0x16;
            }
        }),
    309: (c)=>throwSuper(c, {
            cost: 0x7d0,
            pat: 9,
            sound: 5,
            big: false,
            cue: voice5,
            child: 0x1a4,
            shadow: true,
            setForm: true
        }),
    310: (c)=>throwSuper(c, {
            cost: 0xbb8,
            pat: 9,
            sound: 5,
            big: true,
            cue: voice5,
            child: 0x1a5,
            shadow: true,
            setForm: true
        })
});
function childStep(c, i, dur) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < dur) return false;
    ch.timer = 0;
    ch.frame++;
    ch.hitState = 0;
    return true;
}
function childOnce(c, i) {
    if (childStep(c, i, childDuration) && c.children[i].frame >= childCount) c.freeChild(i);
}
function childLoopHits(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer < childDuration) return;
    ch.timer = 0;
    ch.frame++;
    if (ch.frame === 1 || ch.frame === 5) ch.hitsLeft = 1;
    ch.hitState = 0;
    if (ch.frame >= childCount) ch.frame = 0;
}
function child412(c, i) {
    childOnce(c, i);
}
function shinaiFall(c, i, s) {
    const ch = c.children[i];
    c.f3450 = ftol(ch.x);
    c.f3454 = ftol(ch.y);
    if (c.a314c[i] === 0) {
        ch.vx = s.initVx;
        ch.vy = s.initVy;
        c.a314c[i] = 1;
    }
    if (s.clamp) {
        if (ch.x > 620.0) {
            ch.x = 620.0;
            ch.vx = 0.0;
        }
        if (ch.x < 20.0) {
            ch.x = 20.0;
            ch.vx = 0.0;
        }
    }
    if (ch.vy + ch.y > 0.0 && c.a314c[i] === 1) {
        if (s.impact) c.seRequest = 0x16;
        const d = childSpawnFrame;
        for (const [pat, dx, y] of s.spawns){
            d.w04 = pat;
            if (dx === 0) d.x = ftol(ch.x);
            else if (dx > 0) d.x = ftol(c.facing * dx + ch.x);
            else d.x = ftol(ch.x - c.facing * -dx);
            d.y = y;
            d.b18 = c.facing;
            d.b21 = 1;
            d.b20 = 2;
            frameChild(c, d);
        }
        c.f3454 = 0;
        if (s.impact) c.shakeScreen(0xa, 0);
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 0x1a8;
        ch.y = 0.0;
        ch.vx = s.landVx;
        ch.vy = s.landVy;
        ch.ay = s.landAy;
        ch.blend = 0;
        return;
    }
    childLoopHits(c, i);
}
const SHINAI_419_F0 = {
    initVx: 2.0,
    initVy: 1.0,
    clamp: false,
    impact: false,
    spawns: [
        [
            0x1a6,
            0,
            0.0
        ]
    ],
    landVx: 2.0,
    landVy: -8.5,
    landAy: 0.035
};
const SHINAI_419_F1 = {
    initVx: 2.0,
    initVy: 1.2,
    clamp: true,
    impact: true,
    spawns: [
        [
            0x1a6,
            0,
            0.0
        ]
    ],
    landVx: 0.1,
    landVy: -3.5,
    landAy: 0.01
};
const SHINAI_420_F0 = {
    initVx: 2.4,
    initVy: 0.8,
    clamp: true,
    impact: true,
    spawns: [
        [
            0x1a9,
            0,
            0.0
        ],
        [
            0x1a5,
            0x50,
            15.0
        ],
        [
            0x1a5,
            -0x50,
            15.0
        ]
    ],
    landVx: 0.1,
    landVy: -5.5,
    landAy: 0.01
};
const SHINAI_420_F1 = {
    initVx: 2.4,
    initVy: 0.8,
    clamp: true,
    impact: true,
    spawns: [
        [
            0x1a9,
            0,
            0.0
        ],
        [
            0x1a5,
            0x28,
            15.0
        ],
        [
            0x1a5,
            -0x28,
            15.0
        ]
    ],
    landVx: 0.1,
    landVy: -3.5,
    landAy: 0.01
};
const SHINAI_428_F0 = {
    initVx: 2.4,
    initVy: 0.4,
    clamp: true,
    impact: true,
    spawns: [
        [
            0x1aa,
            0,
            0.0
        ],
        [
            0x1a5,
            0x50,
            15.0
        ],
        [
            0x1a5,
            -0x50,
            15.0
        ],
        [
            0x1a5,
            0x28,
            -80.0
        ],
        [
            0x1a5,
            -0x28,
            -80.0
        ]
    ],
    landVx: 0.1,
    landVy: -5.5,
    landAy: 0.01
};
const SHINAI_428_F1 = {
    initVx: 2.4,
    initVy: 0.4,
    clamp: true,
    impact: true,
    spawns: [
        [
            0x1aa,
            0,
            0.0
        ],
        [
            0x1a5,
            0x3c,
            15.0
        ],
        [
            0x1a5,
            -0x3c,
            15.0
        ],
        [
            0x1a5,
            0x1e,
            -30.0
        ],
        [
            0x1a5,
            -0x1e,
            -30.0
        ]
    ],
    landVx: 0.1,
    landVy: -3.5,
    landAy: 0.01
};
function child423(c, i) {
    const ch = c.children[i];
    ch.x = c.f3450;
    ch.y = c.f3454;
    if (c.f3454 === 0) {
        c.freeChild(i);
        return;
    }
    childLoopHits(c, i);
}
function child423b(c, i) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    ch.x = c.f3450;
    ch.y = c.f3454;
    d.w04 = 0x22;
    d.x = ftol(ch.x) + 0x28 - (c.random(0, 0x50) & 0xffff);
    d.y = ftol(ch.y) + 0x14 - (c.random(0, 0x28) & 0xffff);
    d.b20 = 2;
    d.b21 = 1;
    frameEffect(d);
    if (c.f3454 === 0) {
        c.freeChild(i);
        return;
    }
    childLoopHits(c, i);
}
function impactChild(c, i, chance, hit1) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    if (hit1 && ch.frame === 1) ch.hitsLeft = 1;
    if (ch.frame < 0xc && (c.random(0, 0x64) & 0xffff) < chance) {
        d.w04 = 0x1ab;
        const base = ch.x - 50.0;
        d.x = ftol((c.random(0, 0x64) & 0xffff) + base);
        d.y = ftol(ch.y - (c.random(0, 0x64) & 0xffff));
        d.b20 = 2;
        d.b18 = c.facing;
        d.b21 = 1;
        frameChild(c, d);
    }
    childOnce(c, i);
}
function child424(c, i) {
    const ch = c.children[i];
    ch.vy = ch.vy + ch.ay;
    if (ch.y + ch.vy > 0.0) {
        ch.vy = 0.0;
        ch.vx = 0.0;
        ch.y = 0.0;
        ch.ay = 0.0;
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 0x194;
        return;
    }
    if (ch.x > 620.0) {
        ch.x = 620.0;
        ch.vx = -ch.vx;
    }
    if (ch.x < 20.0) {
        ch.x = 20.0;
        ch.vx = -ch.vx;
    }
    if (childStep(c, i, childDuration) && ch.frame >= childCount) ch.frame = 0;
}
function child431(c, i, form1) {
    const ch = c.children[i];
    const d = childSpawnFrame;
    c.w138 = 2;
    c.w13a = 2;
    c.f3148--;
    c.startAfterimage(1);
    c.dbl180 = 0.5;
    if (c.f3148 <= 0) {
        if (form1) {
            c.dbl180 = 1.0;
            c.f3148 = 0;
            c.freeChild(i);
            c.w138 = 0;
            c.w13a = 0;
        } else {
            c.f3148 = 0;
            c.freeChild(i);
            c.w138 = 0;
            c.w13a = 0;
            c.dbl180 = 1.0;
        }
        return;
    }
    if (c.a314c[i] <= 0) {
        d.w04 = 0x22;
        d.x = ftol(c.x) + (0x14 - (c.random(0, 0x28) & 0xffff)) * c.facing;
        d.y = ftol(c.y) - (c.random(0, 0x5a) & 0xffff);
        d.b20 = 2;
        d.b21 = 1;
        frameEffect(d);
        c.a314c[i] = 2;
    }
    c.a314c[i]--;
    if (childStep(c, i, childDuration) && ch.frame >= childCount) ch.frame = 0;
}
registerChildren({
    412: child412,
    419: (c, i)=>shinaiFall(c, i, SHINAI_419_F0),
    420: (c, i)=>shinaiFall(c, i, SHINAI_420_F0),
    423: child423,
    428: (c, i)=>shinaiFall(c, i, SHINAI_428_F0),
    431: (c, i)=>child431(c, i, false)
});
registerChildren2({
    412: child412,
    419: (c, i)=>shinaiFall(c, i, SHINAI_419_F1),
    420: (c, i)=>shinaiFall(c, i, SHINAI_420_F1),
    421: (c, i)=>impactChild(c, i, 0xa, false),
    422: (c, i)=>impactChild(c, i, 0x14, true),
    423: child423b,
    424: child424,
    425: (c, i)=>impactChild(c, i, 0x14, true),
    426: (c, i)=>impactChild(c, i, 0x14, true),
    428: (c, i)=>shinaiFall(c, i, SHINAI_428_F1),
    431: (c, i)=>child431(c, i, true)
});

export function __logicState(){return {SHINAI_419_F0,SHINAI_419_F1,SHINAI_420_F0,SHINAI_420_F1,SHINAI_428_F0,SHINAI_428_F1};}

export function __installInitialRoots(s){
if(SHINAI_419_F0!==s["SHINAI_419_F0"])throw Error('INITIAL_CONST_IDENTITY:SHINAI_419_F0');
if(SHINAI_419_F1!==s["SHINAI_419_F1"])throw Error('INITIAL_CONST_IDENTITY:SHINAI_419_F1');
if(SHINAI_420_F0!==s["SHINAI_420_F0"])throw Error('INITIAL_CONST_IDENTITY:SHINAI_420_F0');
if(SHINAI_420_F1!==s["SHINAI_420_F1"])throw Error('INITIAL_CONST_IDENTITY:SHINAI_420_F1');
if(SHINAI_428_F0!==s["SHINAI_428_F0"])throw Error('INITIAL_CONST_IDENTITY:SHINAI_428_F0');
if(SHINAI_428_F1!==s["SHINAI_428_F1"])throw Error('INITIAL_CONST_IDENTITY:SHINAI_428_F1');
}
