import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { childCount, childDuration, childSpawnFrame, frameChild, frameEffect, openSpawnFrame } from "./6237c3c562237f9de4952920.mjs";
import { registerChildren, registerStates } from "./0de4622b5e3457d2a8d81427.mjs";
import { frameCount, frameDuration, s16 } from "./7596266716c972d06fe8897a.mjs";
import { applyDirectDamage } from "./ceb424a77025444eff76fcfc.mjs";
function rfCost(c) {
    if (c.rfBlue === 0) {
        c.rfGauge = c.rfGauge - 500.0;
    } else {
        c.rfGauge = c.rfGauge - 250.0;
    }
}
function effect21(c, f) {
    f.w04 = 0x21;
    f.b2c = 0xb;
    f.x = Math.trunc(c.x);
    f.y = Math.trunc(c.y) - 0x32;
    f.b20 = 2;
    f.b21 = 1;
    frameEffect(f);
}
function isZero(v) {
    return v === 0 ? 1 : 0;
}
function state249(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.w0dc = 4;
        c.b0de = 0xec;
        c.vx = 0.0;
        c.w16c = 1;
        c.backWindow = 0;
        c.freeze = 0x3c;
        f.w04 = 0x28;
        f.x = Math.trunc(c.x) + c.facing * 10;
        f.y = Math.trunc(c.y) - 0x28;
        f.b20 = 2;
        f.b21 = 1;
        f.b2c = 0x13;
        frameEffect(f);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function spawnAtScreen(c, f, pattern, y, s) {
    const o = c.opponent;
    c.f3144 = 1;
    if (Math.trunc(Math.trunc(c.x + o.x) / 2) > 0x1e0) {
        c.f3140 = c.f3140 + 1;
        f.d28 = 1;
        f.w04 = pattern;
        f.x = isZero(s - 1) * 0x118 + isZero(s + 1) * 0x2a8;
        f.y = y;
        f.b18 = s;
        f.b20 = 0;
        f.d00 = 1;
        f.b21 = 1;
        frameChild(c, f);
    }
    if (Math.trunc(Math.trunc(c.x + o.x) / 2) < 0xa0) {
        c.f3140 = c.f3140 + 1;
        f.d28 = 1;
        f.w04 = pattern;
        f.x = isZero(s - 1) * -0x28 + isZero(s + 1) * 0x168;
        f.y = y;
        f.b18 = s;
        f.b20 = 0;
        f.d00 = 1;
        f.b21 = 1;
        frameChild(c, f);
    }
    if (c.f3140 === 0) {
        f.w04 = pattern;
        f.d28 = 1;
        f.x = (c.x + o.x) / 2.0 - s * 0xa0;
        f.y = y;
        f.b18 = s;
        f.b20 = 0;
        f.d00 = 1;
        f.b21 = 1;
        frameChild(c, f);
    }
    c.f3138 = c.f3138 + 1;
}
function screenThrow(c, pattern, spawnFrame, y) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.f313c = 0;
        c.stopMotion();
    }
    if (c.frame === spawnFrame && c.timer === 0 && c.f3138 === 0) {
        spawnAtScreen(c, f, pattern, y, c.facing);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state250(c) {
    screenThrow(c, 0x19e, 0, -80.0);
}
function state251(c) {
    screenThrow(c, 0x19f, 1, 0.0);
}
function state252(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 0 && c.timer === 0x1d && c.f3138 === 0) {
        spawnAtScreen(c, f, 0x199, 0.0, -c.facing);
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function state253(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.meter = s16(c.meter + 0x2d);
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.w16c = 1;
    }
    if (c.frame === 3 && c.timer === 0 && c.f3138 === 0) {
        c.vx = 0.5;
        c.vy = -1.5;
        c.ay = 0.035;
    }
    if (c.frame === 3 && c.timer === 0) c.w16c = 1;
    if (c.frame === 5 && c.timer === 0) c.w16c = 1;
    if (c.frame > 6) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame > 7 && c.frame < 11) {
        c.y = 0.0;
        c.stopMotion();
        c.onStateChange();
        c.frame = 11;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 7 && c.f3138 < 2) {
            c.frame = 3;
            c.f3138 = c.f3138 + 1;
        }
        if (c.frame === 11) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 3;
            c.faceOpponent();
        }
    }
}
function dashUpper(c, dur, cnt, loops) {
    if (c.frame === 2 && c.timer === 0) c.vx = 1.8;
    if (c.frame === 4 && c.timer === 0) c.vx = 0.0;
    if (c.frame === 6 && c.timer === 0) {
        c.vx = 0.8;
        c.vy = -2.4;
        c.ay = 0.035;
    }
    if (c.frame > 5) c.vy = c.vy + c.ay;
    if (c.y + c.vy > 0.0 && c.frame > 10 && c.frame < 14) {
        c.y = 0.0;
        c.onStateChange();
        c.stopMotion();
        c.frame = 14;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2) c.w13c = 0xc;
        if (c.frame === 1 || c.frame === 3 || c.frame === 4 || c.frame === 7 || c.frame === 9 || c.frame === 14) c.d168 = 0;
        if (c.frame === 4 && c.f313c < loops) {
            c.frame = c.frame - 2;
            c.f313c = c.f313c + 1;
        }
        if (c.frame === 10 && c.f3140 < loops) {
            c.frame = c.frame - 4;
            c.f3140 = c.f3140 + 1;
        }
        if (c.frame === 14) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 3;
            c.faceOpponent();
        }
    }
}
function state254(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.stopMotion();
        c.w16c = 0x63;
    }
    dashUpper(c, dur, cnt, 1);
}
function state255(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        rfCost(c);
        effect21(c, f);
        c.stopMotion();
        c.w16c = 0x63;
    }
    dashUpper(c, dur, cnt, 2);
}
function jumpBranch(c, back) {
    c.f3138 = c.f3138 + 1;
    if (c.f3138 <= 0x34) return false;
    if (c.command === 10) {
        c.state = 0x106;
        c.onStateChange();
        return true;
    }
    if (c.command === 11) {
        c.state = 0x107;
        c.onStateChange();
        return true;
    }
    if (c.command === 12 && (c.rfGauge >= 500.0 || c.rfBlue === 1)) {
        c.state = 0x108;
        c.onStateChange();
        return true;
    }
    if (c.pressed[2] === 1) {
        c.state = 0x109;
        if (back) {
            if (c.inputX !== c.facing) c.faceOpponent();
            if (c.inputY === 0 && c.inputX === -c.facing) c.state = 0x10b;
        } else {
            if (c.inputY === 1) c.state = 0x10a;
        }
        c.onStateChange();
        return true;
    }
    return false;
}
function jumpBack(c, vx, vy, ay, landState) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        if (c.y < 0.0) c.frame = 3;
    }
    if (c.frame === 3 && c.timer === 0) {
        c.vx = vx;
        c.vy = vy;
        c.ay = ay;
    }
    if (jumpBranch(c, true)) return;
    c.vy = (c.frame > 2 ? 1 : 0) * c.ay + c.vy;
    if (!(c.y + c.vy < 0.0) && c.frame > 3) {
        c.vy = 0.0;
        c.ay = 0.0;
        c.state = landState;
        c.onStateChange();
        c.seRequest = 9;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = 6;
    }
}
function state256(c) {
    jumpBack(c, 0.5, -3.5, 0.055, 0x10e);
}
function state257(c) {
    jumpBack(c, -0.5, -2.8, 0.037, 0x10d);
}
function state258(c) {
    jumpBack(c, 1.5, -2.8, 0.037, 0x10e);
}
function jumpForward(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.b158 = 0;
        c.vx = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        if (c.y < 0.0) c.frame = 3;
    }
    c.vx = c.vx - 0.2;
    if (c.vx < 0.0) c.vx = 0.0;
    if (c.frame === 3 && c.timer === 0) {
        c.vx = vx;
        c.vy = -3.0;
        c.ay = 0.035;
    }
    if (jumpBranch(c, false)) return;
    c.vy = (c.frame > 2 ? 1 : 0) * c.ay + c.vy;
    if (!(c.y + c.vy < 0.0) && c.frame > 3) {
        c.vx = 0.5;
        c.vy = 0.0;
        c.ay = 0.0;
        c.state = 0x10d;
        c.onStateChange();
        c.seRequest = 9;
        return;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) c.frame = 6;
    }
}
function state259(c) {
    jumpForward(c, 4.5);
}
function state260(c) {
    jumpForward(c, 6.6);
}
function state261(c) {
    jumpForward(c, 7.9);
}
function airShot(c, f, pattern, vx, ay) {
    c.faceOpponent();
    c.meter = s16(c.meter + 0x19);
    c.vx = vx;
    c.vy = -1.0;
    c.ay = ay;
    c.voiceRequest = 1;
    const offsets = [
        [
            0x28,
            0x2d
        ],
        [
            0x14,
            0x19
        ],
        [
            0x36,
            0x18
        ]
    ];
    for (const [dx, dy] of offsets){
        f.w04 = pattern;
        f.x = Math.trunc(c.x) + c.facing * dx;
        f.y = Math.trunc(c.y) - dy;
        f.b20 = 0;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
    }
}
function airShotTail(c, dur, cnt) {
    c.vy = c.vy + c.ay;
    if (!(c.y + c.vy < 0.0)) {
        c.vx = 0.5;
        c.vy = 0.0;
        c.ay = 0.0;
        c.state = 0x10d;
        c.onStateChange();
        c.seRequest = 9;
        return;
    }
    c.timer++;
    c.vy = c.vy + c.ay;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 3;
        if (c.frame >= cnt) {
            c.state = 0;
            c.onStateChange();
        }
    }
}
function airShotLight(c, pattern) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 3 && c.timer === 0) {
        airShot(c, f, pattern, -0.5, 0.015);
    }
    airShotTail(c, dur, cnt);
}
function state262(c) {
    airShotLight(c, 0x190);
}
function state263(c) {
    airShotLight(c, 0x191);
}
function state264(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        rfCost(c);
        effect21(c, f);
    }
    if (c.frame === 3 && c.timer === 0) {
        airShot(c, f, 0x192, -1.0, 0.02);
    }
    airShotTail(c, dur, cnt);
}
function state265(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.ay = 0.0;
        c.vy = 0.0;
        c.vx = 0.0;
    }
    if (c.frame === 1 && c.timer === 0) {
        c.seRequest = 0x15;
        c.meter = s16(c.meter + 0x23);
        c.w16c = 1;
        c.vx = 1.0;
        c.vy = 2.0;
    }
    if (!(c.y + c.vy < 0.0) && c.frame < 2) {
        c.vx = 0.5;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.frame = 2;
        c.timer = 0;
        c.seRequest = 9;
    }
    if (c.vx > 0.0 && c.y === 0.0) {
        c.vx = c.vx - 0.03;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.timer++;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
        }
    }
}
function state266(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.w16c = 3;
        c.stopMotion();
    }
    if (c.frame === 4 && c.timer === 0) {
        c.meter = s16(c.meter + 2);
        c.vx = 0.0;
        c.vy = 2.1;
        c.ay = 0.0;
        c.seRequest = 0x14;
        c.f3138 = 0x63;
    }
    if (!(c.y + c.vy < 0.0) && c.frame < 6) {
        c.vx = 0.0;
        c.vy = 0.0;
        c.y = 0.0;
        c.ay = 0.0;
        c.frame = 6;
        c.timer = 0;
        c.seRequest = 9;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame === 6) c.frame = c.frame - 2;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
        }
    }
}
function state267(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    c.vy = c.vy + c.ay;
    if (c.frame === 2 && c.d168 === 3) {
        o.stopMotion();
        o.onStateChange();
        c.onStateChange();
        c.vx = 1.0;
        c.vy = -2.5;
        c.ay = 0.035;
        c.state = 0x10c;
        o.state = 0x6b;
        f.w04 = 0;
        f.x = Math.trunc(c.x) + c.facing * 0x1d;
        f.y = Math.trunc(c.y) - 0x27;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        o.x = c.x;
        o.y = 0.0;
    }
    if (c.y + c.vy > 0.0 && c.frame < 4) {
        c.y = 0.0;
        c.vy = 0.0;
        c.vx = 0.0;
        c.frame = 4;
        c.timer = 0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2) {
            c.w16c = 1;
        } else {
            c.w16c = 0;
        }
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
const HOLD = [
    [
        35.0,
        0,
        0x64
    ],
    [
        55.0,
        0x15,
        0x73
    ],
    [
        71.0,
        0x14,
        0x68
    ],
    [
        76.0,
        0xf,
        0x68
    ],
    [
        77.0,
        0xc,
        0x68
    ],
    [
        55.0,
        0x13,
        0x75
    ]
];
function state268(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    const o = c.opponent;
    if (c.frame === 0 && c.timer === 1) o.facing = -c.facing;
    c.vy = c.vy + c.ay;
    if (c.facing === 1 && c.x > 630.0) {
        c.x = 630.0;
        c.vx = 0.0;
    }
    if (c.facing === -1 && c.x < 30.0) {
        c.x = 30.0;
        c.vx = 0.0;
    }
    if (c.vy + c.y > 0.0 && c.frame === 4) {
        c.stopMotion();
        c.y = 0.0;
        c.frame = 5;
        c.timer = 0;
    }
    for(let k = 0; k < HOLD.length; k++){
        if (c.frame !== k) continue;
        const [dy, dx, st] = HOLD[k];
        o.y = c.y - dy;
        o.x = k === 0 ? c.x : c.x - c.facing * dx;
        o.state = st;
    }
    if (c.frame === 6 && c.timer === 0) {
        c.shakeScreen(4, 0);
        f.w04 = 3;
        f.b2c = 7;
        f.x = Math.trunc(c.x) + c.facing * 0xf;
        f.y = Math.trunc(c.y);
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        o.x = c.facing * 0xf + c.x;
        o.state = 0x3f;
        o.knockX = -1.0;
        o.knockY = -3.0;
        o.ay = 0.035;
        o.x = c.facing * 0xf + c.x;
        applyDirectDamage(c, 0x3e8, 790.0);
        o.hitstun = s16(Math.trunc(200.0 * c.proration * 0.0001));
        o.onStateChange();
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 0;
            c.faceOpponent();
            c.onStateChange();
        }
    }
}
function state269(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.vx > 0.0) {
        c.vx = c.vx - 0.03;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    c.y = 0.0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame >= cnt) {
            c.state = 7;
            if (c.inputY === 1) c.state = 3;
            c.onStateChange();
        }
    }
}
function state270(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) c.vx = 1.0;
    if (c.vx > 0.0) {
        c.vx = c.vx - 0.015;
        if (c.vx < 0.0) c.vx = 0.0;
    }
    if (c.frame === 1 && c.timer === 0) c.w16c = 1;
    c.y = 0.0;
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        c.d168 = 0;
        if (c.frame >= cnt) {
            c.state = 3;
            c.onStateChange();
        }
    }
}
function airDiveTail(c, dur, cnt, bounceVx, bounceVy, diveVx, diveVy, partialD168) {
    if ((c.frame === 9 || c.frame === 13) && c.timer === 0) c.seRequest = 0x14;
    if (c.frame > 5 && c.frame < 14 && c.y + c.vy > 0.0) {
        if (c.f3138 > 0) {
            c.y = 0.0;
            c.stopMotion();
            c.frame = 14;
            c.timer = 0;
            return;
        }
        if (c.f3138 === 0) {
            c.vx = bounceVx;
            c.vy = bounceVy;
            c.ay = 0.04;
            c.f3138 = c.f3138 + 1;
            c.y = 0.0;
            c.w16c = 0;
        }
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (!partialD168 || c.frame < 6 || c.frame === 7 || c.frame === 10) c.d168 = 0;
        if (c.frame === 6) {
            c.vx = diveVx;
            c.vy = diveVy;
        }
        if (c.frame === 14) c.frame = c.frame - 8;
        if (c.frame >= cnt) {
            c.onStateChange();
            c.state = 0;
            c.faceOpponent();
        }
    }
}
function state271(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.w16c = 0x63;
        c.vx = -0.8;
        c.vy = -1.0;
        c.stopMotion();
        c.ay = 0.025;
    }
    if (c.frame > 5) c.vy = c.vy + c.ay;
    airDiveTail(c, dur, cnt, -0.5, -1.2, 2.5, 2.5, true);
}
function state272(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.w16c = 0x63;
        c.vx = -0.8;
        c.vy = -1.0;
        c.ay = 0.025;
    }
    c.vy = c.vy + c.ay;
    airDiveTail(c, dur, cnt, -0.5, -1.5, 3.2, 2.2, true);
}
function state273(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    const f = openSpawnFrame();
    if (c.frame === 0 && c.timer === 0) {
        rfCost(c);
        effect21(c, f);
        c.w16c = 0x63;
        c.vx = -0.8;
        c.vy = -1.0;
        c.ay = 0.025;
    }
    c.vy = c.vy + c.ay;
    airDiveTail(c, dur, cnt, -1.0, -1.2, 2.5, 2.5, false);
}
registerStates({
    249: state249,
    250: state250,
    251: state251,
    252: state252,
    253: state253,
    254: state254,
    255: state255,
    256: state256,
    257: state257,
    258: state258,
    259: state259,
    260: state260,
    261: state261,
    262: state262,
    263: state263,
    264: state264,
    265: state265,
    266: state266,
    267: state267,
    268: state268,
    269: state269,
    270: state270,
    271: state271,
    272: state272,
    273: state273
});
function shotStart(c, i, vy) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 4.0;
        ch.vy = vy;
        ch.hitsLeft = 1;
    }
    ch.timer++;
    if ((ch.hitState === 3 || !(ch.y < 0.0)) && c.a314c[i] === 0) {
        ch.frame = 1;
        c.a314c[i] = 1;
        ch.timer = 0;
        ch.hitState = 0;
        ch.vx = 0.0;
        ch.vy = 0.0;
    }
}
function shotTo404(c, i) {
    const ch = c.children[i];
    ch.frame = 0;
    ch.timer = 0;
    ch.hitState = 0;
    ch.vx = -1.0;
    ch.vy = -2.0;
    ch.pattern = 0x194;
}
function shotEnd(c, i) {
    const ch = c.children[i];
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) c.freeChild(i);
    }
    if (ch.x < -100.0 || ch.x > 800.0 || ch.y < -480.0) c.freeChild(i);
}
function child400(c, i) {
    const ch = c.children[i];
    shotStart(c, i, 2.0);
    if (ch.hitState === 2 || ch.hitState === 4) shotTo404(c, i);
    shotEnd(c, i);
}
function child401(c, i) {
    const ch = c.children[i];
    shotStart(c, i, 1.3);
    if (ch.hitState === 2 || ch.hitState === 4) shotTo404(c, i);
    shotEnd(c, i);
}
function child402(c, i) {
    const ch = c.children[i];
    shotStart(c, i, 2.0);
    if (ch.hitState === 4) {
        ch.frame = 0;
        ch.timer = 0;
        ch.hitState = 0;
        ch.vy = -2.0;
        ch.vx = -1.0;
        ch.pattern = 0x194;
    }
    if (ch.hitState === 2) {
        ch.frame = 0;
        ch.timer = 0;
        ch.hitState = 0;
        ch.vx = 0.2;
        ch.vy = -3.5;
        ch.pattern = 0x193;
    }
    shotEnd(c, i);
}
function child403(c, i) {
    const ch = c.children[i];
    ch.vy = ch.vy + 0.04;
    if (ch.vy > 0.0) ch.hitsLeft = 1;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
    if (ch.hitState > 1 || ch.y > 0.0) {
        ch.frame = 0;
        ch.timer = 0;
        ch.hitState = 0;
        ch.vy = -2.0;
        ch.pattern = 0x194;
    }
}
function child404(c, i) {
    const ch = c.children[i];
    ch.vy = ch.vy + 0.05;
    ch.blend = 1;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
    if (ch.x < -100.0 || ch.x > 800.0 || ch.y > 0.0) c.freeChild(i);
}
function child409(c, i) {
    const ch = c.children[i];
    const f = childSpawnFrame;
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = 1.5;
        if (c.a314c[i] === 0) {
            ch.hitsLeft = 1;
            c.a314c[i] = c.a314c[i] + 1;
        }
        f.w04 = 0x1f;
        f.x = Math.trunc(ch.x);
        f.y = 0.0;
        f.b20 = 0;
        f.b21 = 1;
        f.d1c = isZero(ch.facing + 1);
        frameEffect(f);
    }
    ch.timer++;
    if (ch.hitState === 4 || ch.hitState === 5) {
        f.w04 = 0x19b;
        f.x = Math.trunc(ch.x);
        f.y = 0.0;
        f.b20 = 0;
        f.d00 = 1;
        f.b21 = 1;
        f.b18 = c.facing;
        frameChild(c, f);
        ch.frame = 0;
        ch.timer = 0;
        ch.hitState = 0;
        ch.vx = -0.8;
        ch.vy = -3.0;
        ch.pattern = 0x19a;
        return;
    }
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
    if (ch.x < -100.0 || ch.x > 740.0) {
        if (c.state !== 0xfc) {
            c.freeChild(i);
            c.f3144 = 0;
        }
    }
}
function child410(c, i) {
    const ch = c.children[i];
    if (ch.frame < 6) ch.vy = ch.vy + 0.04;
    if (!(ch.y + ch.vy < 0.0) && ch.frame < 6) {
        ch.timer = 0;
        ch.frame = 6;
        ch.vx = 0.0;
        ch.vy = 0.0;
        ch.y = 0.0;
        c.dblE8 = 1.5;
        const f = childSpawnFrame;
        f.w04 = 3;
        f.b2c = 7;
        f.x = Math.trunc(ch.x);
        f.y = 0.0;
        f.b18 = c.facing;
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
        return;
    }
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 6) ch.frame = ch.frame - 2;
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            ch.frame = 0;
            ch.timer = 0;
            ch.pattern = 0x19d;
        }
    }
}
function child411(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) {
        ch.vx = -0.7;
        ch.vy = -1.5;
    }
    ch.vy = ch.vy + 0.03;
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = ch.frame - 1;
    }
    if (ch.y > 100.0) c.freeChild(i);
}
function cancelTo410(c, i) {
    const ch = c.children[i];
    if (ch.hitState === 4 || ch.hitState === 5) {
        ch.frame = 0;
        ch.timer = 0;
        ch.hitState = 0;
        ch.vx = -0.8;
        ch.vy = -3.0;
        ch.pattern = 0x19a;
    }
}
function child413(c, i) {
    const ch = c.children[i];
    ch.timer++;
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        if (ch.frame === 3) {
            ch.vx = -6.0;
            ch.vy = -4.0;
        }
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = ch.frame - 1;
    }
    if (ch.x < -80.0 || ch.x > 720.0) {
        c.freeChild(i);
        c.f3144 = 0;
    }
}
function child414(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0 && c.a314c[i] === 0) {
        ch.vx = 2.3;
        ch.vy = 0.8;
        ch.hitsLeft = 1;
        c.a314c[i] = c.a314c[i] + 1;
    }
    ch.vy = ch.vy - 0.015;
    ch.timer++;
    cancelTo410(c, i);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) ch.frame = 0;
    }
    if (ch.x < -150.0 || ch.x > 790.0) {
        if (c.state !== 0x12c) {
            c.freeChild(i);
            c.f3144 = 0;
        }
    }
}
function child415(c, i) {
    const ch = c.children[i];
    const o = c.opponent;
    if (ch.frame === 0 && ch.timer === 0 && c.a314c[i] === 0) {
        ch.vx = 3.0;
        ch.vy = 0.0;
        ch.hitsLeft = 0;
        c.a314c[i] = c.a314c[i] + 1;
    }
    if (ch.x - o.x < 60.0 && ch.x - o.x > -60.0 && ch.frame < 3) {
        ch.frame = 0;
        ch.timer = 0;
        ch.pattern = 0x1a0;
        return;
    }
    if (ch.frame > 2) {
        ch.vx = ch.vx - 0.033;
        if (ch.vx < 0.0) ch.vx = 0.0;
    }
    ch.timer++;
    cancelTo410(c, i);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame === 3 && c.a314c[i] < 10) {
            c.a314c[i] = c.a314c[i] + 1;
            ch.frame = ch.frame - 2;
        }
        if (ch.frame >= childCount) {
            ch.frame = 0;
            ch.pattern = 0x19d;
        }
    }
}
function child416(c, i) {
    const ch = c.children[i];
    if (ch.frame === 0 && ch.timer === 0) ch.hitsLeft = 1;
    ch.vx = ch.vx - 0.04;
    if (ch.vx < 0.0) ch.vx = 0.0;
    ch.timer++;
    cancelTo410(c, i);
    if (ch.timer >= childDuration) {
        ch.timer = 0;
        ch.frame++;
        ch.hitState = 0;
        if (ch.frame >= childCount) {
            ch.frame = 0;
            ch.pattern = 0x19d;
        }
    }
}
registerChildren({
    400: child400,
    401: child401,
    402: child402,
    403: child403,
    404: child404,
    409: child409,
    410: child410,
    411: child411,
    413: child413,
    414: child414,
    415: child415,
    416: child416
});

export function __logicState(){return {HOLD};}

export function __installInitialRoots(s){
if(HOLD!==s["HOLD"])throw Error('INITIAL_CONST_IDENTITY:HOLD');
}
