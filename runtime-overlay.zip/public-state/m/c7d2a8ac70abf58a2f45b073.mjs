import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { HISTORY_LENGTH, NO_COMMAND } from "./c262f0bfe78a8c9d4e4f51e3.mjs";
function hist(c, i) {
    return c.history[i - (i >= HISTORY_LENGTH ? 1 : 0) * HISTORY_LENGTH];
}
function buttonCommand(base, v) {
    return base + ((v & 0xe0) > 0 ? 1 : 0) + ((v & 0xc0) > 0 ? 1 : 0) + ((v & 0x80) > 0 ? 1 : 0);
}
function clearBufferedInput(c) {
    c.bufferedA = 0;
    c.bufferedB = 0;
}
function cancelable(c) {
    return ((c.currentHit()?.defenseFlags ?? 0) & 8) > 0;
}
function priorityOk(c, target) {
    return (c.patterns[c.state]?.hdrB ?? 0) <= (c.patterns[target]?.hdrA ?? 0);
}
function cancelOk(c) {
    if (c.state >= 200 && c.d168 >= 2 && c.d168 !== 6) return true;
    return c.state < 200;
}
function rfOk(c) {
    return c.rfGauge >= 500.0 || c.rfBlue > 0;
}
function enter(c, s) {
    c.onStateChange();
    clearBufferedInput(c);
    c.state = s;
}
function normalOk(c, target) {
    return priorityOk(c, target) && cancelable(c) && cancelOk(c);
}
function specialOk(c, target) {
    return cancelable(c) && cancelOk(c) && priorityOk(c, target);
}
function fullGauge(c, value) {
    if (c.f3150 >= 10000) {
        c.frame = 7;
        c.timer = 0;
        c.f3150 = value;
    }
}
function crouchHeld(c) {
    return c.inputY === 1 || (c.bufferedA & 4) !== 0 || (c.bufferedB & 4) !== 0;
}
function standHeld(c) {
    return c.inputY === 0 || (c.bufferedA & 4) === 0 || (c.bufferedB & 4) === 0;
}
function oppThrowable(c) {
    return c.opponent.state < 50 || c.opponent.state > 156;
}
export function parseCommandKano(c) {
    c.command = NO_COMMAND;
    const idx = c.historyIndex;
    const end = idx + HISTORY_LENGTH;
    const left = c.facing === -1 ? 1 : 0;
    const BACK = 2 - left;
    const FWD = 1 + left;
    const DOWN_BACK = 6 - left;
    const DOWN_FWD = 5 + left;
    let step;
    let v;
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 5) {
            c.command = buttonCommand(0xaa, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 4) {
            if (v & 0xf0) {
                c.command = buttonCommand(0xa0, v);
                return;
            }
            step = 5;
        }
        if ((v & 0xf) === DOWN_FWD && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x69; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 4) {
            c.command = buttonCommand(0x78, v);
            return;
        }
        if ((v & 0xf) === DOWN_FWD && step === 3) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x78, v);
                return;
            }
            step = 4;
        }
        if ((v & 0xf) === DOWN_BACK && step === 2) step = 3;
        if ((v & 0xf) === BACK && step === 1) step = 2;
        if ((v & 0xf) === FWD && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x6e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x6e, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_BACK && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === BACK && step === 2) step = 3;
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 6) {
            c.command = buttonCommand(0x64, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 5) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x64, v);
                return;
            }
            step = 6;
        }
        if ((v & 0xf) === DOWN_FWD && step === 4) step = 5;
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === FWD && step === 2) step = 3;
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0 && c.meter >= 1000) step = 1;
    }
    step = 0;
    for(let i = idx + 0x78; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x3c, v);
            return;
        }
        if ((v & 0xf) === DOWN_BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x14, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x0a, v);
            return;
        }
        if ((v & 0xf) === FWD && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x0a, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_FWD && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x28, v);
            return;
        }
        if ((v & 0xf) === 4 && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x28, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === BACK && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0xf0 && step === 3) {
            c.command = buttonCommand(0x1e, v);
            return;
        }
        if ((v & 0xf) === BACK && step === 2) {
            if (v & 0xf0) {
                c.command = buttonCommand(0x1e, v);
                return;
            }
            step = 3;
        }
        if ((v & 0xf) === DOWN_BACK && step === 1) step = 2;
        if ((v & 0xf) === 4 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0xaf; i < end; i++){
        v = hist(c, i);
        if (v & 8 && step === 1) {
            c.command = 6;
            return;
        }
        if (!(v & 8) && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x80 && step === 4) {
            c.command = 53;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0 && c.state === 96) step = 1;
    }
    step = 0;
    for(let i = idx + 0x5a; i < end; i++){
        v = hist(c, i);
        if (v & 0x40 && step === 4) {
            c.command = 52;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x20 && step === 4) {
            c.command = 51;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if (v & 0x10 && step === 4) {
            c.command = 50;
            return;
        }
        if ((v & 0xf) === 4 && step === 3) step = 4;
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 4 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 1 && step === 3) {
            c.command = 1;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 1 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
    step = 0;
    for(let i = idx + 0x87; i < end; i++){
        v = hist(c, i);
        if ((v & 0xf) === 2 && step === 3) {
            c.command = 0;
            return;
        }
        if ((v & 0xf) === 0 && step === 2) step = 3;
        if ((v & 0xf) === 2 && step === 1) step = 2;
        if ((v & 0xf) === 0 && step === 0) step = 1;
    }
}
export function dispatchMovesKano(c) {
    if (c.state < 200) c.bufferedA = 0;
    if (c.bufferTimer > 0) {
        c.bufferTimer = c.bufferTimer - 1 & 0xff;
    } else {
        c.bufferedB = 0;
    }
    if (c.bufferedB === 0) c.bufferTimer = 0;
    if (c.command === 52) {
        const ok = c.rfGauge >= 500.0 && c.d168 > 1 || c.rfBlue > 0 && c.d168 > 1 && c.d168 !== 6;
        if (ok && cancelable(c) && priorityOk(c, 167)) {
            enter(c, 167);
            if (c.y < 0.0) c.state = 171;
            return;
        }
    }
    if (c.d15c < 2) {
        if (c.life < 3333 && (c.state === 168 || c.state === 169) && c.command === 173 && c.meter >= 3000 && c.y === 0.0 && specialOk(c, 315)) {
            enter(c, 315);
            return;
        }
        if (c.command === 112 && c.meter >= 3000 && c.y === 0.0 && specialOk(c, 314)) {
            enter(c, 314);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 111 && c.meter >= 2000 && c.y === 0.0 && specialOk(c, 313)) {
            enter(c, 313);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 110 && c.meter >= 1000 && c.y === 0.0 && specialOk(c, 312)) {
            enter(c, 312);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 102 && c.meter >= 3000 && c.y === 0.0 && specialOk(c, 305)) {
            enter(c, 305);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 101 && c.meter >= 2000 && c.y === 0.0 && specialOk(c, 304)) {
            enter(c, 304);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 100 && c.meter >= 1000 && c.y === 0.0 && specialOk(c, 303)) {
            enter(c, 303);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 172 && c.y === 0.0 && c.meter >= 3000 && specialOk(c, 308)) {
            enter(c, 308);
            return;
        }
        if ((c.command === 171 || c.command === 172) && c.y === 0.0 && c.meter >= 2000 && specialOk(c, 307)) {
            enter(c, 307);
            return;
        }
        if ((c.command === 170 || c.command === 171 || c.command === 172) && c.y === 0.0 && c.meter >= 1000 && specialOk(c, 306)) {
            enter(c, 306);
            return;
        }
        if (c.command === 51 && c.meter >= 2000 && c.y === 0.0 && specialOk(c, 309)) {
            enter(c, 309);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 122 && c.meter >= 3000 && c.y === 0.0 && specialOk(c, 302)) {
            enter(c, 302);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 121 && c.meter >= 2000 && c.y === 0.0 && specialOk(c, 301)) {
            enter(c, 301);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 120 && c.meter >= 1000 && c.y === 0.0 && specialOk(c, 300)) {
            enter(c, 300);
            fullGauge(c, 0);
            return;
        }
        if (c.command === 62 && specialOk(c, 262) && c.f3168 === 0 && c.y === 0.0) {
            enter(c, 262);
            fullGauge(c, 2500);
            return;
        }
        if (c.command === 61 && specialOk(c, 261) && c.f3168 === 0 && c.y === 0.0) {
            enter(c, 261);
            fullGauge(c, 5000);
            return;
        }
        if (c.command === 60 && specialOk(c, 260) && c.f3168 === 0 && c.y === 0.0) {
            enter(c, 260);
            fullGauge(c, 7500);
            return;
        }
        if (c.command === 32 && specialOk(c, 259) && c.f316c === 0 && c.y === 0.0) {
            enter(c, 259);
            fullGauge(c, 2500);
            return;
        }
        if (c.command === 31 && specialOk(c, 258) && c.f316c === 0 && c.y === 0.0) {
            enter(c, 258);
            fullGauge(c, 5000);
            return;
        }
        if (c.command === 30 && specialOk(c, 257) && c.f316c === 0 && c.y === 0.0) {
            enter(c, 257);
            fullGauge(c, 7500);
            return;
        }
        if (c.command === 12 && specialOk(c, 256) && c.f3170 === 0 && c.y === 0.0) {
            enter(c, 256);
            fullGauge(c, 2500);
            return;
        }
        if (c.command === 11 && specialOk(c, 255) && c.f3170 === 0 && c.y === 0.0) {
            enter(c, 255);
            fullGauge(c, 5000);
            return;
        }
        if (c.command === 10 && specialOk(c, 254) && c.f3170 === 0 && c.y === 0.0) {
            enter(c, 254);
            fullGauge(c, 7500);
            return;
        }
        if (c.command === 13 && rfOk(c) && specialOk(c, 251) && c.y === 0.0 && c.f3150 < 10000) {
            enter(c, 251);
            return;
        }
    }
    if (c.d15c < 1 && (c.command === 0 || c.command === 1)) {
        if (c.y < 0.0 && c.b159 < 1) {
            let dir = 1 - (c.command << 1);
            let dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 165) && c.state !== 170 && c.y < -40.0 && cancelable(c) && cancelOk(c)) {
                airDash(c, 165);
                return;
            }
            dir = 1 - (c.command << 1);
            dx = c.opponent.x - c.x;
            if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && priorityOk(c, 166) && c.state !== 170 && cancelable(c) && cancelOk(c)) {
                airDash(c, 166);
                return;
            }
        }
        if (c.y === 0.0 && cancelable(c)) {
            const dir = 1 - (c.command << 1);
            const dx = c.opponent.x - c.x;
            if ((dx * dir < 0.0 || dx === 0.0 && c.facing === dir * -1) && priorityOk(c, 163) && cancelOk(c)) {
                groundDash(c, 163, true);
                return;
            }
            if ((dx * dir > 0.0 || dx === 0.0 && c.facing === dir) && priorityOk(c, 164) && cancelOk(c)) {
                groundDash(c, 164, false);
                return;
            }
        }
    }
    if (c.d15c < 3 && c.command === 6 && cancelable(c) && c.y < 0.0 && c.b15a < 1 && priorityOk(c, 14) && cancelOk(c)) {
        c.onStateChange();
        clearBufferedInput(c);
        c.b15a = c.b15a + 1 & 0xff;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        return;
    }
    if (c.pressed[0] === 1 || c.bufferedA & 0x10 || c.bufferedB & 0x10) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 230);
            if (c.inputY === 1) c.state = 233;
            return;
        }
        if (c.y < 0.0) {
            if (c.y < -25.0 && c.inputY === 1 && normalOk(c, 213)) {
                enter(c, 213);
                return;
            }
            if (normalOk(c, 207)) enter(c, 207);
            return;
        }
        if (crouchHeld(c) && normalOk(c, 204)) {
            enter(c, 204);
            return;
        }
        if (standHeld(c) && normalOk(c, 200)) {
            enter(c, 200);
            return;
        }
    }
    if (c.pressed[1] === 1 || c.bufferedA & 0x20 || c.bufferedB & 0x20) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 231);
            if (c.inputY === 1) c.state = 234;
            return;
        }
        if (c.y < 0.0) {
            if (c.y < -30.0 && c.inputY === 1 && normalOk(c, 214)) {
                enter(c, 214);
                return;
            }
            if (normalOk(c, 208)) enter(c, 208);
            return;
        }
        if (crouchHeld(c) && normalOk(c, 205)) {
            enter(c, 205);
            return;
        }
        if (standHeld(c)) {
            if (priorityOk(c, 217) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 217);
                return;
            }
            if (priorityOk(c, 201) && cancelable(c) && c.x - c.opponent.x > -70.0 && c.x - c.opponent.x < 70.0 && cancelOk(c)) {
                enter(c, 201);
                return;
            }
            if (normalOk(c, 202)) {
                enter(c, 202);
                return;
            }
        }
    }
    if (c.pressed[2] === 1 || c.bufferedA & 0x40 || c.bufferedB & 0x40) {
        if (c.state === 163 && c.inputX !== -c.facing) {
            enter(c, 232);
            if (c.inputY === 1) c.state = 235;
            return;
        }
        if (c.y < 0.0) {
            if (c.inputX === c.facing && c.inputY === 0 && c.x - c.opponent.x > -100.0 && c.x - c.opponent.x < 100.0 && c.opponent.y < 0.0 && priorityOk(c, 248) && oppThrowable(c) && cancelable(c) && cancelOk(c)) {
                enter(c, 248);
                return;
            }
            if (c.y < -25.0 && c.inputY === 1 && normalOk(c, 215)) {
                enter(c, 215);
                return;
            }
            if (normalOk(c, 209)) {
                enter(c, 209);
                return;
            }
        }
        if (crouchHeld(c) && c.inputX === c.facing && normalOk(c, 212)) {
            enter(c, 212);
            return;
        }
        if (crouchHeld(c) && normalOk(c, 206)) {
            enter(c, 206);
            return;
        }
        if (standHeld(c)) {
            if (c.opponent.y === 0.0 && c.inputX !== 0 && c.x - c.opponent.x > -30.0 && c.x - c.opponent.x < 30.0 && priorityOk(c, 220) && oppThrowable(c) && cancelable(c) && cancelOk(c)) {
                enter(c, 220);
                return;
            }
            if (c.y === 0.0 && priorityOk(c, 210) && cancelable(c) && c.inputX === c.facing && cancelOk(c)) {
                enter(c, 210);
                return;
            }
            if (normalOk(c, 203)) {
                enter(c, 203);
                return;
            }
        }
    }
    if (c.d15c >= 2) return;
    if (c.pressed[3] === 1 || c.bufferedA & 0x80 || c.bufferedB & 0x80) {
        if (c.f3150 < 10000 && priorityOk(c, 250) && cancelable(c) && c.y === 0.0 && cancelOk(c)) {
            enter(c, 250);
        }
    }
}
function airDash(c, s) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    c.b159 = c.b159 + 1 & 0xff;
    c.b15a = c.b15a + 1 & 0xff;
    c.bufferedA = 0;
}
function groundDash(c, s, countB158) {
    if (c.state !== s) c.onStateChange();
    c.state = s;
    c.faceOpponent();
    if (countB158) c.b158 = c.b158 + 1 & 0xff;
    c.bufferedA = 0;
}
