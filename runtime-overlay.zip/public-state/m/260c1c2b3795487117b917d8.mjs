import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { registerStates, setDefaultStateHandler } from "./4bfdef0d515a63cf0e27cdb5.mjs";
import { frameEffect, openSpawnFrame } from "./7d17e301343a90178a9cad8e.mjs";
import { frameCount, frameDuration, ftol, s16 } from "./7596266716c972d06fe8897a.mjs";
const JUMP_GRAVITY = 0.045;
function advance(c, dur, cnt) {
    c.timer++;
    if (c.timer < dur) return false;
    c.timer = 0;
    c.frame++;
    return c.frame >= cnt;
}
function landFromHit(c) {
    c.y = 0.0;
    if (c.d12c !== 0) c.setState(0x61);
    else c.setState(0x62);
}
function wallPush(c, y, k) {
    if (c.x - 20.0 <= 0.0 || !(c.x + 20.0 < 639.0)) {
        c.pushToOpponent = (1.0 - (y < 0.0 ? 1 : 0) * k) * c.vx;
    } else {
        c.pushToOpponent = 0.0;
    }
}
function rfDrain(c, v) {
    if (c.rfBlue !== 0) c.rfGauge -= v;
}
const AIR_CANCEL_4 = {
    upChecksD15c: false,
    downEarlyReset: false,
    downFallThrough: false
};
const AIR_CANCEL_56 = {
    upChecksD15c: false,
    downEarlyReset: true,
    downFallThrough: false
};
const AIR_CANCEL_STD = {
    upChecksD15c: true,
    downEarlyReset: true,
    downFallThrough: false
};
const AIR_CANCEL_10 = {
    upChecksD15c: true,
    downEarlyReset: true,
    downFallThrough: true
};
function airCancel(c, v) {
    if (c.inputY === -1 && (!v.upChecksD15c || c.d15c < 3) && c.b15a < 2) {
        c.b15a++;
        c.state = 14;
        if (c.inputX === c.facing) c.state = 15;
        if (c.inputX === -c.facing) c.state = 16;
        c.d168 = 0;
        c.onStateChange();
        return true;
    }
    if (c.inputY === 1) {
        c.state = 9;
        if (v.downEarlyReset) c.onStateChange();
        if (c.b15a < 2 && c.inputX !== 0 && c.d15c < 3) {
            c.b15a++;
            if (c.inputX === c.facing) c.state = 18;
            if (c.inputX === -c.facing) c.state = 20;
            c.d168 = 0;
            c.onStateChange();
            return true;
        }
        if (!v.downEarlyReset) {
            c.onStateChange();
            return true;
        }
        if (!v.downFallThrough) return true;
    }
    if (c.b15a < 2 && c.d15c < 3) {
        if (c.inputX === c.facing) {
            c.state = 17;
            c.b15a++;
            c.onStateChange();
            c.d168 = 0;
            return true;
        }
        if (c.inputX === -c.facing) {
            c.state = 19;
            c.b15a++;
            c.onStateChange();
            c.d168 = 0;
            return true;
        }
    }
    return false;
}
function jumpLanding(c) {
    if (c.y + c.vy >= 0.0 && c.frame > 3) {
        c.y = 0.0;
        c.seRequest = 9;
        c.faceOpponent();
        c.setState(13);
    }
}
function stateDefault(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.vx = 0.0;
    c.vy = 0.0;
    if (advance(c, dur, cnt)) c.frame = 0;
}
function walk(c, vx) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.b158 = 0;
    c.vx = vx;
    c.vy = 0.0;
    if (advance(c, dur, cnt)) c.frame = 0;
}
function state3(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.frame = 0;
}
function jump(c, variant, vx, gravityAfter) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.faceOpponent();
        c.vx = 0.0;
    }
    c.f3140++;
    if (c.f3140 > c.f3148 && airCancel(c, variant)) return;
    if (c.frame === 3 && c.timer === 0) {
        c.ay = JUMP_GRAVITY;
        c.vy = -2.5;
        if (vx !== null) c.vx = vx;
        c.voiceRequest = 0;
    }
    if (c.frame > gravityAfter) c.vy += c.ay;
    if (advance(c, dur, cnt)) c.setState(10);
    jumpLanding(c);
}
function transition(c, next) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(next);
}
function state9(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    c.f3140++;
    if (c.f3140 > 0 && airCancel(c, AIR_CANCEL_STD)) return;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.setState(13);
    }
}
function state10(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vy += c.ay;
    c.b158 = 0;
    if (c.f3138 === 0) {
        c.vx *= 0.3;
        c.f3138++;
    }
    if (c.vy > 0.4) c.vy = 0.4;
    if (airCancel(c, AIR_CANCEL_10)) return;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0) {
        c.y = 0.0;
        c.seRequest = 9;
        c.setState(13);
    }
}
function state13(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    c.vx = 0.0;
    c.vy = 0.0;
    c.b158 = 0;
    c.faceOpponent();
    if (advance(c, dur, cnt)) c.setState(c.inputY === 1 ? 3 : 7);
}
function airMove(c, startFrame, vy, vx, fall) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.vy = 0.0;
    }
    c.f3140++;
    if (c.f3140 > c.f3148 && airCancel(c, AIR_CANCEL_STD)) return;
    if (c.frame === startFrame && c.timer === 0) {
        c.ay = JUMP_GRAVITY;
        c.vy = vy;
        c.vx = vx;
        c.voiceRequest = 0;
    }
    if (c.frame > startFrame - 1) c.vy += fall === null ? c.ay : fall;
    if (advance(c, dur, cnt)) c.setState(10);
    jumpLanding(c);
}
function state47(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    if (c.frame === 0 && c.timer === 0) {
        c.vx = 0.0;
        c.ay = 0.035;
    }
    c.vy += c.ay;
    if (c.y + c.vy > 0.0 && c.frame < 2) {
        c.timer = 0;
        c.frame = 2;
        c.seRequest = 7;
        c.y = 0.0;
        c.vy = 0.0;
        c.ay = 0.0;
        c.vx = 0.0;
    }
    c.timer++;
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame === 2) c.frame = c.frame - 2 & 0xffff;
        if (c.frame >= cnt) c.frame = c.frame - 1 & 0xffff;
    }
}
function hitStand(c, meter, k, guard, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + meter);
        c.vx = (2.0 - c.opponent.proration / 10000.0) * k;
        rfDrain(c, guard);
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.vx += 0.06;
    if (c.vx > 0.0) c.vx = 0.0;
    wallPush(c, c.y, 0.2);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 0);
        else c.setState(3);
    }
}
function hitAir(c, wall, mix, clamp, ay) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (wall && c.frame > 0 && c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + 30);
        c.vx = c.knockX;
        c.vy = mix ? c.vy * 0.75 + c.knockY : c.knockY;
        if (clamp !== null) {
            if (c.vy < clamp) c.vy = clamp;
            else if (c.vy > -0.5) c.vy = -0.5;
        }
        c.ay = ay;
    }
    if (!(c.vy > 0.0)) {
        c.frame = 1;
        c.timer = 0;
    }
    if (c.vy >= 0.0 && c.frame <= 1) {
        c.frame = 2;
        c.timer = 0;
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = c.frame - 2 & 0xffff;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function state68(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    c.timer++;
    if (c.wallBlock() !== 0) {
        c.setState(0x46);
        return;
    }
    if (c.timer >= dur) {
        c.timer = 0;
        c.frame++;
        if (c.frame >= cnt) c.frame = c.frame - 2 & 0xffff;
    }
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state69(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 1.5);
    c.meter = s16(c.meter + 3);
    c.vx = c.knockX;
    c.vy = c.knockY;
    if (advance(c, dur, cnt)) c.frame = c.frame - 2 & 0xffff;
    if (c.y + c.vy >= 0.0) landFromHit(c);
}
function state70(c) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    if (c.frame === 0 && c.timer === 0 && c.f3138 === 0) {
        c.meter = s16(c.meter + 30);
        c.f3138++;
        c.hitstun = s16(c.hitstun + 120);
        c.vx = 0.5;
        c.vy = -2.5;
        c.ay = 0.025;
        c.seRequest = 0x1f;
        const f = openSpawnFrame();
        f.w04 = 0;
        f.x = ftol(c.x);
        f.y = ftol(c.y);
        f.b20 = 2;
        f.b21 = 1;
        frameEffect(f);
    }
    c.vy += c.ay;
    if (advance(c, dur, cnt)) c.frame = 0;
    if (c.y + c.vy >= 0.0 && c.frame > 1) landFromHit(c);
}
function grounded(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.8);
    c.b158 = 0;
    c.vx = 0.0;
    c.vy = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
function slide(c, standUp) {
    const dur = frameDuration(c);
    const cnt = frameCount(c);
    rfDrain(c, 0.6);
    c.b158 = 0;
    if (c.frame === 0 && c.timer === 0) {
        c.meter = s16(c.meter + 30);
        rfDrain(c, 30.0);
        c.vx = 2.2;
    }
    c.vy = 0.0;
    c.y = 0.0;
    c.ay = 0.0;
    c.ax = 0.06;
    c.vx -= c.ax;
    if (c.vx < 0.0) c.vx = 0.0;
    wallPush(c, c.opponent.y, 0.25);
    if (advance(c, dur, cnt)) {
        if (standUp) c.setState(c.inputY === 1 ? 3 : 7);
        else c.setState(3);
    }
}
setDefaultStateHandler(stateDefault);
registerStates({
    1: (c)=>walk(c, 0.8),
    2: (c)=>walk(c, -0.8),
    3: state3,
    4: (c)=>jump(c, AIR_CANCEL_4, null, 4),
    5: (c)=>jump(c, AIR_CANCEL_56, 1.5, 6),
    6: (c)=>jump(c, AIR_CANCEL_56, -1.5, 6),
    7: (c)=>transition(c, 0),
    8: (c)=>transition(c, 3),
    9: state9,
    10: state10,
    13: state13,
    14: (c)=>airMove(c, 3, -3.5, 0.0, null),
    15: (c)=>airMove(c, 3, -2.5, 1.5, null),
    16: (c)=>airMove(c, 2, -2.5, -1.5, null),
    17: (c)=>airMove(c, 3, -0.5, 2.0, 0.01),
    18: (c)=>airMove(c, 3, -0.5, 1.5, null),
    19: (c)=>airMove(c, 2, -0.5, -2.0, 0.01),
    20: (c)=>airMove(c, 2, -0.5, -1.5, null),
    47: state47,
    50: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    51: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    52: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    53: (c)=>hitStand(c, 10, -1.1, 10.0, true),
    54: (c)=>hitStand(c, 15, -1.5, 20.0, true),
    55: (c)=>hitStand(c, 20, -1.8, 30.0, true),
    56: (c)=>hitStand(c, 10, -1.1, 10.0, false),
    57: (c)=>hitStand(c, 15, -1.5, 20.0, false),
    58: (c)=>hitStand(c, 20, -1.8, 30.0, false),
    59: (c)=>hitAir(c, false, true, -2.0, 0.032),
    60: (c)=>hitAir(c, false, true, -4.0, 0.032),
    61: (c)=>hitAir(c, false, true, -6.0, 0.032),
    62: (c)=>hitAir(c, false, true, null, 0.032),
    63: (c)=>hitAir(c, false, false, null, 0.032),
    64: (c)=>hitAir(c, true, true, -2.0, 0.032),
    65: (c)=>hitAir(c, true, true, -4.0, 0.032),
    66: (c)=>hitAir(c, true, true, null, 0.032),
    67: (c)=>hitAir(c, true, false, null, 0.032),
    68: state68,
    69: state69,
    70: state70,
    71: (c)=>hitAir(c, false, false, null, 0.072),
    72: (c)=>grounded(c, true),
    73: (c)=>grounded(c, true),
    74: (c)=>grounded(c, false),
    75: (c)=>slide(c, true),
    76: (c)=>slide(c, true),
    77: (c)=>slide(c, false)
});

export function __logicState(){return {AIR_CANCEL_4,AIR_CANCEL_56,AIR_CANCEL_STD,AIR_CANCEL_10};}

export function __installInitialRoots(s){
if(AIR_CANCEL_4!==s["AIR_CANCEL_4"])throw Error('INITIAL_CONST_IDENTITY:AIR_CANCEL_4');
if(AIR_CANCEL_56!==s["AIR_CANCEL_56"])throw Error('INITIAL_CONST_IDENTITY:AIR_CANCEL_56');
if(AIR_CANCEL_STD!==s["AIR_CANCEL_STD"])throw Error('INITIAL_CONST_IDENTITY:AIR_CANCEL_STD');
if(AIR_CANCEL_10!==s["AIR_CANCEL_10"])throw Error('INITIAL_CONST_IDENTITY:AIR_CANCEL_10');
}
