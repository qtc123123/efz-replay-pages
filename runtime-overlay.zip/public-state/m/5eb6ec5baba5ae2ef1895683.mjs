import {session as __session,numerics as __numerics} from "./d2882f15591f302cc6d00380.mjs";
import { InputBit, setTouchMask, setVirtualKey } from "./06124acd5a2cf7a08d774a8d.mjs";
import { t } from "./416e92328b12eb2fb0e976da.mjs";
const PREF_KEY = "efz.touchPad";
export function isTouchDevice() {
    return matchMedia("(pointer: coarse)").matches;
}
export function loadTouchPadPref() {
    try {
        const v = localStorage.getItem(PREF_KEY);
        if (v !== null) return v === "1";
    } catch  {}
    return true;
}
export function saveTouchPadPref(on) {
    try {
        localStorage.setItem(PREF_KEY, on ? "1" : "0");
    } catch  {}
}
function isInstalledApp() {
    return matchMedia("(display-mode: fullscreen), (display-mode: standalone)").matches || navigator.standalone === true;
}
export function enterFullscreen() {
    const el = document.documentElement;
    if (!el.requestFullscreen || document.fullscreenElement || isInstalledApp()) return;
    el.requestFullscreen({
        navigationUI: "hide"
    }).catch(()=>{
        window.addEventListener("pointerup", ()=>{
            if (!document.fullscreenElement) void el.requestFullscreen({
                navigationUI: "hide"
            }).catch(()=>undefined);
        }, {
            once: true
        });
    });
}
const DIRECTIONS = [
    InputBit.Right,
    InputBit.Right | InputBit.Down,
    InputBit.Down,
    InputBit.Left | InputBit.Down,
    InputBit.Left,
    InputBit.Left | InputBit.Up,
    InputBit.Up,
    InputBit.Right | InputBit.Up
];
const DEAD_ZONE = 0.2;
const BUTTON_REACH = 1.5;
const BUTTON_CHORD = 1.25;
const CHORD_REACH = 0.85;
const PAD_ALPHA = 0.45;
function clamp(min, value, max) {
    return Math.min(max, Math.max(min, value));
}
function safeAreaInsets() {
    const probe = document.createElement("div");
    probe.style.cssText = "position:fixed;visibility:hidden;pointer-events:none;" + "padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)";
    document.body.append(probe);
    const cs = getComputedStyle(probe);
    const insets = {
        top: parseFloat(cs.paddingTop) || 0,
        right: parseFloat(cs.paddingRight) || 0,
        bottom: parseFloat(cs.paddingBottom) || 0,
        left: parseFloat(cs.paddingLeft) || 0
    };
    probe.remove();
    return insets;
}
let visibleKeys = [];
let onFnKeysChange = null;
export function setTouchFunctionKeys(keys) {
    if (keys.length === visibleKeys.length && keys.every((k, i)=>k === visibleKeys[i])) return;
    visibleKeys = keys;
    onFnKeysChange?.();
}
function inRect(r, x, y, pad) {
    return x >= r.x - pad && x <= r.x + r.w + pad && y >= r.y - pad && y <= r.y + r.h + pad;
}
export function showTouchPad() {
    document.body.classList.add("touch-pad");
    document.querySelector('meta[name="viewport"]')?.setAttribute("content", "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover");
    const canvas = document.createElement("canvas");
    canvas.id = "touchpad";
    document.body.append(canvas);
    const ctx = canvas.getContext("2d");
    let layout;
    const labels = [
        t("btnA"),
        t("btnB"),
        t("btnC"),
        t("btnD")
    ];
    const placeFunctionKeys = ()=>{
        const { w, h } = layout.esc;
        const gap = 6;
        const cols = layout.fkeyCols;
        layout.fkeys = visibleKeys.map((code, i)=>{
            const row = Math.floor(i / cols);
            const inRow = Math.min(cols, visibleKeys.length - row * cols);
            const col = cols - inRow + i % cols;
            return {
                code,
                x: layout.fkeyRight - w * cols - gap * (cols - 1) + col * (w + gap),
                y: layout.fkeyTop + row * (h + gap),
                w,
                h
            };
        });
    };
    const relayout = ()=>{
        const w = window.innerWidth;
        const h = window.innerHeight;
        const vmin = Math.min(w, h) / 100;
        const stickR = clamp(130, 38 * vmin, 220) / 2;
        const btn = clamp(56, 16 * vmin, 90);
        const gap = Math.max(12, 3 * vmin);
        const inset = safeAreaInsets();
        const portrait = h > w;
        const bottom = h - gap - inset.bottom - (portrait ? btn : 0);
        const keysTop = portrait ? inset.top + w * 3 / 4 + gap : gap + inset.top;
        const boxRight = w - gap - inset.right;
        const cx = boxRight - btn * 1.5;
        const cy = bottom - btn * 1.5;
        const r = btn / 2;
        layout = {
            stick: {
                x: gap + inset.left + stickR,
                y: bottom - stickR,
                r: stickR
            },
            buttons: [
                {
                    bit: InputBit.A,
                    label: labels[0],
                    x: cx + btn,
                    y: cy,
                    r
                },
                {
                    bit: InputBit.B,
                    label: labels[1],
                    x: cx,
                    y: cy - btn,
                    r
                },
                {
                    bit: InputBit.C,
                    label: labels[2],
                    x: cx - btn,
                    y: cy,
                    r
                },
                {
                    bit: InputBit.D,
                    label: labels[3],
                    x: cx,
                    y: cy + btn,
                    r
                }
            ],
            esc: {
                x: gap + inset.left,
                y: keysTop,
                w: 56,
                h: 30
            },
            fkeys: [],
            fkeyRight: w - gap - inset.right,
            fkeyTop: keysTop,
            fkeyCols: portrait ? 3 : 2,
            width: w
        };
        placeFunctionKeys();
        const dpr = window.devicePixelRatio || 1;
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        requestDraw();
    };
    let stickPointer = null;
    let escPointer = null;
    let dirMask = 0;
    let knobX = 0;
    let knobY = 0;
    const buttonPointers = new Map();
    const fkeyPointers = new Map();
    const releaseFunctionKeys = ()=>{
        for (const code of fkeyPointers.values())setVirtualKey(code, false);
        fkeyPointers.clear();
    };
    onFnKeysChange = ()=>{
        for (const [id, code] of fkeyPointers){
            if (!visibleKeys.includes(code)) {
                fkeyPointers.delete(id);
                setVirtualKey(code, false);
            }
        }
        placeFunctionKeys();
        requestDraw();
    };
    const currentMask = ()=>{
        let mask = dirMask;
        for (const bits of buttonPointers.values())mask |= bits;
        return mask;
    };
    let drawPending = false;
    const requestDraw = ()=>{
        if (drawPending) return;
        drawPending = true;
        requestAnimationFrame(draw);
    };
    const circle = (x, y, r, fill)=>{
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fillStyle = fill;
        ctx.fill();
        ctx.stroke();
    };
    const draw = ()=>{
        drawPending = false;
        const { stick, buttons, esc } = layout;
        const mask = currentMask();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.globalAlpha = PAD_ALPHA;
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 2;
        circle(stick.x, stick.y, stick.r - 1, "rgb(255 255 255 / 0.12)");
        ctx.beginPath();
        ctx.arc(stick.x + knobX, stick.y + knobY, stick.r * 0.4, 0, Math.PI * 2);
        ctx.fillStyle = "rgb(255 255 255 / 0.6)";
        ctx.fill();
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        for (const b of buttons){
            const active = (mask & b.bit) !== 0;
            circle(b.x, b.y, b.r - 1, active ? "rgb(255 255 255 / 0.55)" : "rgb(255 255 255 / 0.12)");
            ctx.fillStyle = active ? "#000" : "#fff";
            ctx.font = `600 ${Math.round(b.r * 0.72)}px system-ui, sans-serif`;
            ctx.fillText(b.label, b.x, b.y);
        }
        ctx.beginPath();
        ctx.roundRect(esc.x, esc.y, esc.w, esc.h, 6);
        ctx.fillStyle = escPointer !== null ? "rgb(255 255 255 / 0.55)" : "rgb(255 255 255 / 0.12)";
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = escPointer !== null ? "#000" : "#fff";
        ctx.font = "600 14px system-ui, sans-serif";
        ctx.fillText("ESC", esc.x + esc.w / 2, esc.y + esc.h / 2);
        {
            const held = new Set(fkeyPointers.values());
            for (const k of layout.fkeys){
                const active = held.has(k.code);
                ctx.beginPath();
                ctx.roundRect(k.x, k.y, k.w, k.h, 6);
                ctx.fillStyle = active ? "rgb(255 255 255 / 0.55)" : "rgb(255 255 255 / 0.12)";
                ctx.fill();
                ctx.stroke();
                ctx.fillStyle = active ? "#000" : "#fff";
                ctx.font = "600 14px system-ui, sans-serif";
                ctx.fillText(k.code, k.x + k.w / 2, k.y + k.h / 2);
            }
        }
    };
    const update = ()=>{
        setTouchMask(currentMask());
        requestDraw();
    };
    const inEsc = (x, y)=>inRect(layout.esc, x, y, 8);
    const fkeyAt = (x, y)=>{
        return layout.fkeys.find((k)=>inRect(k, x, y, 3))?.code ?? null;
    };
    const moveStick = (x, y)=>{
        const { stick } = layout;
        let dx = x - stick.x;
        let dy = y - stick.y;
        const dist = Math.hypot(dx, dy);
        if (dist > stick.r) {
            dx *= stick.r / dist;
            dy *= stick.r / dist;
        }
        knobX = dx;
        knobY = dy;
        if (dist < stick.r * DEAD_ZONE) {
            dirMask = 0;
        } else {
            const sector = Math.round(__numerics.atan2(dy, dx) / (Math.PI / 4));
            dirMask = DIRECTIONS[(sector + 8) % 8];
        }
        update();
    };
    const buttonsAt = (x, y)=>{
        const hits = layout.buttons.map((b)=>({
                bit: b.bit,
                d: Math.hypot(x - b.x, y - b.y),
                size: b.r * 2
            })).sort((a, b)=>a.d - b.d);
        const [first, second] = hits;
        if (first.d > first.size * BUTTON_REACH) return 0;
        let bits = first.bit;
        if (second.d <= first.d * BUTTON_CHORD && second.d <= second.size * CHORD_REACH) bits |= second.bit;
        return bits;
    };
    canvas.addEventListener("pointerdown", (e)=>{
        e.preventDefault();
        canvas.setPointerCapture(e.pointerId);
        const x = e.clientX;
        const y = e.clientY;
        const fkey = fkeyAt(x, y);
        if (fkey) {
            fkeyPointers.set(e.pointerId, fkey);
            setVirtualKey(fkey, true);
            requestDraw();
        } else if (inEsc(x, y)) {
            escPointer = e.pointerId;
            setVirtualKey("Escape", true);
            requestDraw();
        } else if (x < layout.width / 2) {
            if (stickPointer !== null) return;
            stickPointer = e.pointerId;
            moveStick(x, y);
        } else {
            buttonPointers.set(e.pointerId, buttonsAt(x, y));
            update();
        }
    });
    canvas.addEventListener("pointermove", (e)=>{
        if (e.pointerId === stickPointer) {
            moveStick(e.clientX, e.clientY);
        } else if (buttonPointers.has(e.pointerId)) {
            const bits = buttonsAt(e.clientX, e.clientY);
            if (bits === buttonPointers.get(e.pointerId)) return;
            buttonPointers.set(e.pointerId, bits);
            update();
        }
    });
    const release = (e)=>{
        const fkey = fkeyPointers.get(e.pointerId);
        if (fkey !== undefined) {
            fkeyPointers.delete(e.pointerId);
            if (![
                ...fkeyPointers.values()
            ].includes(fkey)) setVirtualKey(fkey, false);
            requestDraw();
        } else if (e.pointerId === escPointer) {
            escPointer = null;
            setVirtualKey("Escape", false);
            requestDraw();
        } else if (e.pointerId === stickPointer) {
            stickPointer = null;
            dirMask = 0;
            knobX = knobY = 0;
            update();
        } else if (buttonPointers.delete(e.pointerId)) {
            update();
        }
    };
    canvas.addEventListener("pointerup", release);
    canvas.addEventListener("pointercancel", release);
    const releaseAll = ()=>{
        releaseFunctionKeys();
        buttonPointers.clear();
        stickPointer = null;
        escPointer = null;
        dirMask = 0;
        knobX = knobY = 0;
        update();
        setVirtualKey("Escape", false);
    };
    window.addEventListener("blur", releaseAll);
    document.addEventListener("visibilitychange", ()=>{
        if (document.hidden) releaseAll();
    });
    canvas.addEventListener("contextmenu", (e)=>e.preventDefault());
    for (const type of [
        "touchstart",
        "touchmove",
        "touchend"
    ]){
        canvas.addEventListener(type, (e)=>e.preventDefault(), {
            passive: false
        });
    }
    canvas.addEventListener("dblclick", (e)=>e.preventDefault());
    relayout();
    window.addEventListener("resize", relayout);
    document.addEventListener("fullscreenchange", relayout);
}

export function __logicState(){return {DIRECTIONS,visibleKeys,onFnKeysChange};}
