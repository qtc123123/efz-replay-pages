import {installPublicBattleWorker}from"./m/8dd8694a80af3e8a424bd2cb.mjs";
import {createBrowserBattleSession}from"./m/86dd0c0c06d9f1ac6d70df9f.mjs?v=d863b15f992dec38013c90412b0b6eef7db8585deacfb5baf42a060d7425c64a";
installPublicBattleWorker(self,{createSession:createBrowserBattleSession});
