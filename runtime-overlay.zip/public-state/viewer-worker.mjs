import {installPublicBattleWorker}from"./m/8dd8694a80af3e8a424bd2cb.mjs";
import {createBrowserBattleSession}from"./m/86dd0c0c06d9f1ac6d70df9f.mjs?v=c13cfa2dcf31a4cfd118d100a45c2fd14ff6e99ffbf5839d80d7585247bff215";
installPublicBattleWorker(self,{createSession:createBrowserBattleSession});
