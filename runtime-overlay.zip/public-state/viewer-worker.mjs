import {installPublicBattleWorker}from"./m/8dd8694a80af3e8a424bd2cb.mjs";
import {createBrowserBattleSession}from"./m/86dd0c0c06d9f1ac6d70df9f.mjs";
installPublicBattleWorker(self,{createSession:createBrowserBattleSession});
