// Header presentation only: reuse the ordinary page language preference/helper.
export function mountSiteHeader(document,language,window=globalThis.window){
 const header=document.getElementById('site-header'),select=document.getElementById('language'),help=document.getElementById('help'),button=document.getElementById('help-open');
 if(!header||!select||!help||!button)return ()=>{};
 function apply(){header.lang=language.current();select.value=language.current();for(const n of header.querySelectorAll('[data-i18n]'))n.textContent=language.t(n.dataset.i18n);for(const n of header.querySelectorAll('[data-i18n-aria-label]'))n.setAttribute('aria-label',language.t(n.dataset.i18nAriaLabel));}
 function change(){language.set(select.value);apply();}
 function open(){help.open=true;help.scrollIntoView({block:'nearest',behavior:window?.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}
 select.addEventListener('change',change);button.addEventListener('click',open);apply();return ()=>{select.removeEventListener('change',change);button.removeEventListener('click',open);};
}
if(typeof document!=='undefined'){
 const {createPageLanguage}=await import('../src/pages/page-language.mjs');let storage=null;try{storage=window.localStorage;}catch{}
 mountSiteHeader(document,createPageLanguage({storage,languages:window.navigator?.languages??[]}));
}
