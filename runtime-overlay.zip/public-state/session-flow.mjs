/** Session identity survives game changes. Generation fences every asynchronous boundary.
 * All native/asset/audio ownership is delegated to reset/start; a reset begins synchronously.
 */
export function createSessionFlow(io){
 let revision=0,sid=null,active=null,closed=false,flight=null;
 const current=n=>!closed&&n===revision;
 async function run(n){
  try{
   const rows=await io.catalog();if(!current(n))return;io.show(rows,sid);
   if(!sid)return;
   const session=rows.find(r=>r.session_id===sid);
   if(!session||['unavailable','native-only'].includes(session.state)){
    if(active){active=null;await io.reset();if(!current(n))return;}
    io.pause();io.note(!session?'Selected session closed. Choose another session.':'Selected session is unavailable for browser playback.');return;
   }
   io.metadata?.(session);
   if(active&&!active.finished){await io.append();if(current(n))io.healthy?.();return;}
   if(!session.watchable||!session.game_id){io.note(session.state==='waiting-for-game'?'Host is waiting for a game.':'Between games — staying connected.');return;}
   if(active?.id===session.game_id)return;
   const manifest=await io.manifest(session.session_id);if(!current(n))return;
   const descriptor=manifest.games.find(g=>g.id===session.game_id);
   if(!descriptor){io.note('Waiting for validated current-game metadata…');return;}
   await io.reset();if(!current(n))return;
   active={id:descriptor.id,finished:false};
   try{await io.start(session,descriptor);if(!current(n))return;}
   catch(error){if(current(n)){active=null;await io.reset();if(current(n))throw error;}}
  }catch(error){if(current(n)){io.pause();io.note('Spectating paused. Retrying the connection…');io.unavailable?.();}}
 }
 function refresh(){if(closed)return Promise.resolve();if(flight?.revision===revision)return flight.promise;const n=revision,promise=run(n);flight={revision:n,promise};return promise.finally(()=>{if(flight?.promise===promise)flight=null;});}
 return Object.freeze({selected:()=>sid,active:()=>active?.id??null,refresh,
 async choose(id){if(!/^[a-f0-9]{32}$/.test(id))throw Error('Invalid session ID.');if(!closed&&sid===id)return refresh();closed=false;sid=id;active=null;const n=++revision;await io.reset();if(current(n))await refresh();},
 complete(id){if(active?.id===id)active.finished=true;},
 async reconnect(){closed=false;active=null;const n=++revision;await io.reset();if(current(n))await refresh();},
 async suspend(){closed=true;revision++;active=null;await io.reset();},
 async close(){closed=true;revision++;sid=null;active=null;await io.reset();}
 });
}
