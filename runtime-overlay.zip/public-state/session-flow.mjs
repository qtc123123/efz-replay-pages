/** Session identity survives game changes. Generation fences every asynchronous boundary.
 * All native/asset/audio ownership is delegated to reset/start; a reset begins synchronously.
 */
export function createSessionFlow(io){
 let revision=0,sid=null,active=null,closed=false,flight=null;
 const current=n=>!closed&&n===revision;
 async function run(n){
  let phase='catalog';
  try{
   const rows=await io.catalog();if(!current(n))return;io.show(rows,sid);
   if(!sid){io.note(rows.length?'Choose a session or paste a host/player IP:port.':'No current sessions. Paste a host/player IP:port to connect.');return;}
   const session=rows.find(r=>r.session_id===sid);
   if(!session||['unavailable','native-only'].includes(session.state)){
    if(active){active=null;await io.reset();if(!current(n))return;}
    io.pause();io.note(!session?'Selected session closed. Choose another session.':'Selected session is unavailable for browser playback.');return;
   }
   io.metadata?.(session);
   if(active&&!active.finished){await io.append();if(current(n))io.healthy?.();return;}
   if(!session.watchable||!session.game_id){io.note(session.state==='waiting-for-game'?'Host is waiting for a game.':'Between games — staying connected.');return;}
   if(active?.id===session.game_id)return;
   phase='prepare';const manifest=await io.manifest(session.session_id);if(!current(n))return;
   const descriptor=manifest.games.find(g=>g.id===session.game_id);
   if(!descriptor){io.note('Waiting for validated current-game metadata…');return;}
   await io.reset();if(!current(n))return;
   active={id:descriptor.id,finished:false,started:false};
   try{await io.start(session,descriptor);if(!current(n))return;active.started=true;}
   catch(error){if(current(n)){active=null;await io.reset();if(current(n))throw error;}}
  }catch(error){if(current(n)){io.pause();const codes=['ASSETS_SNAPSHOT','AUDIO_MODULES','WORKER_INIT','INPUTS','WORKER_TIMEOUT','WORKER_MODULE','WORKER_INIT_FAILED','WORKER_PROTOCOL'],code=codes.includes(error?.viewerCode)?error.viewerCode:'PREPARATION_FAILED',reason=['resources','artifact','palette','engine','unknown'].includes(error?.viewerReason)?'/'+error.viewerReason:'',where=['catalog','common-resources','battle-resources','ready'].includes(error?.viewerPhase)?'@'+error.viewerPhase:'';io.note((active&&!active.finished&&(io.hasPlayback?.()??active.started))?'Playback paused because the connection was lost. Retrying…':phase==='prepare'?`Selected game could not be prepared (${code}${reason}${where}). Retrying…`:'Spectating service is unavailable. Please try Reconnect.');io.unavailable?.(phase==='prepare'?{kind:'preparation',code,...(reason?{reason:reason.slice(1)}:{}),...(where?{phase:where.slice(1)}:{})}:undefined);}}
 }
 function refresh(){if(closed)return Promise.resolve();if(flight?.revision===revision)return flight.promise;const n=revision,promise=run(n);flight={revision:n,promise};return promise.finally(()=>{if(flight?.promise===promise)flight=null;});}
 return Object.freeze({selected:()=>sid,active:()=>active?.id??null,refresh,
 async choose(id){if(!/^[a-f0-9]{32}$/.test(id))throw Error('Invalid session ID.');if(!closed&&sid===id)return refresh();io.selection?.(id);closed=false;sid=id;active=null;const n=++revision;io.note('Connecting to selected session…');await io.reset();if(current(n))await refresh();},
 complete(id){if(active?.id===id)active.finished=true;},
 async reconnect(){closed=false;active=null;const n=++revision;io.note('Connecting to spectating service…');await io.reset();if(current(n))await refresh();},
 async suspend(){closed=true;revision++;active=null;await io.reset();},
 async close(){closed=true;revision++;sid=null;active=null;await io.reset();}
 });
}
