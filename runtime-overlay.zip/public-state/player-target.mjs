/** Player target is input to fixed-relay admission, never the relay/service origin. */
const opaque=/^[a-f0-9]{32}$/;
const special=[['0.0.0.0',8],['10.0.0.0',8],['100.64.0.0',10],['127.0.0.0',8],['169.254.0.0',16],['172.16.0.0',12],['192.0.0.0',24],['192.0.2.0',24],['192.31.196.0',24],['192.52.193.0',24],['192.88.99.0',24],['192.168.0.0',16],['192.175.48.0',24],['198.18.0.0',15],['198.51.100.0',24],['203.0.113.0',24],['224.0.0.0',4],['240.0.0.0',4]];
const numeric=ip=>ip.split('.').reduce((n,p)=>n*256+Number(p),0);
const targetError=()=>Error('Enter a public numeric IPv4:port, using port 1024–65535.');
export function parsePlayerTarget(value){
 if(typeof value!=='string'||value.length>64)throw targetError();
 const target=value.trim(),match=/^((?:0|[1-9][0-9]{0,2})(?:\.(?:0|[1-9][0-9]{0,2})){3}):([1-9][0-9]{0,4})$/.exec(target);
 if(!match)throw targetError();const ip=match[1],parts=ip.split('.').map(Number),port=Number(match[2]),number=numeric(ip);
 if(parts.some(p=>p>255)||[0,255].includes(parts[3])||port<1024||port>65535||[1900,3702,5353,5355,11211].includes(port)||['168.63.129.16','16.192.153.4'].includes(ip)||special.some(([base,bits])=>Math.floor(number/2**(32-bits))===Math.floor(numeric(base)/2**(32-bits))))throw targetError();
 return target;
}

const responseFields=['reason','request_id','retry_after_ms','schema','session_id','state'];
const accepted=new Map([['pending','pending'],['waiting-for-game','verified-waiting'],['initialized','native-initialized'],['waiting-unverified','waiting-unverified'],['unreachable','unreachable'],['unsupported','unsupported'],['unavailable','unavailable']]);
const failures=new Map([[400,['invalid-request','invalid-endpoint']],[403,['untrusted-proxy']],[404,['unknown-request']],[409,['request-conflict']],[429,['rate-limited','request-limit','owner-capacity','target-owned','capacity']],[503,['disabled','closed','busy','clock-invalid','unavailable']]]);
function protocolError(){const error=Error('The spectating service returned an invalid response.');error.name='WatchProtocolError';return error;}
export function parseWatchResult(value,id,{status=200}={}){
 const good=value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join(',')===responseFields.join(',');
 if(!good||!opaque.test(id)||value.schema!=='efz-watch-result/1'||(value.request_id!==id&&!(status!==200&&value.request_id===null))||!(value.session_id===null||typeof value.session_id==='string'&&opaque.test(value.session_id))||!Number.isSafeInteger(value.retry_after_ms)||value.retry_after_ms<0||value.retry_after_ms>60000)throw protocolError();
 if(status===200){if(accepted.get(value.state)!==value.reason)throw protocolError();if(['pending','waiting-for-game','initialized','waiting-unverified'].includes(value.state)&&value.session_id===null)throw protocolError();}
 else {const capacity=['owner-capacity','target-owned','capacity'].includes(value.reason);if(!failures.get(status)?.includes(value.reason)||value.state!==(capacity?'capacity':'unavailable')||value.session_id!==null)throw protocolError();}
 return Object.freeze({...value});
}
export function createWatchTransport(origin,{fetcher=fetch}={}){
 const base=new URL(origin);if(base.protocol!=='https:'||base.username||base.password||base.pathname!=='/'||base.search||base.hash)throw Error('A fixed HTTPS relay origin is required.');
 async function send(path,body,signal){
  if(!opaque.test(body.request_id))throw protocolError();const encoded=JSON.stringify(body);if(new TextEncoder().encode(encoded).length>256)throw protocolError();
  const response=await fetcher(base.origin+path,{method:'POST',headers:{'Content-Type':'application/json'},body:encoded,credentials:'omit',redirect:'error',cache:'no-store',signal:AbortSignal.any([...(signal?[signal]:[]),AbortSignal.timeout(15000)])});
  if(!response.body||!/^application\/json(?:\s*;|$)/i.test(response.headers.get('content-type')??''))throw protocolError();
  const reader=response.body.getReader(),parts=[];let size=0;
  try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>1024)throw protocolError();parts.push(value);}}catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
  const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
  let json;try{json=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{throw protocolError();}return parseWatchResult(json,body.request_id,{status:response.status});
 }
 return Object.freeze({request(endpoint,id,signal){return send('/api/watch',{request_id:id,endpoint:parsePlayerTarget(endpoint)},signal);},status(id,signal){return send('/api/watch/status',{request_id:id},signal);}});
}
const messages={connecting:'Connecting to the player through the spectating service…',pending:'Checking the host’s native spectating connection…','waiting-unverified':'Waiting for the host to provide verified game information…','waiting-for-game':'Host is waiting for a game.','initialized':'Waiting for the selected session to become available…',unreachable:'The host could not be reached. Check the player IP:port.',unsupported:'This host does not support the required spectating protocol.',capacity:'Spectating capacity is currently full. Try again later.',unavailable:'Spectating service is unavailable. Reconnect to check this request.',error:'The spectating request could not be completed safely. Please reconnect.','pending-timeout':'Still waiting for host verification. Reconnect to check this same request.',connected:'Connected to the selected session.',cancelled:''};
const terminal=new Set(['unreachable','unsupported','unavailable','capacity']);
function randomId(){return Array.from(crypto.getRandomValues(new Uint8Array(16)),v=>v.toString(16).padStart(2,'0')).join('');}
function waitFor(ms,signal){return new Promise((resolve,reject)=>{if(signal.aborted){reject(signal.reason);return;}const timer=setTimeout(done,ms);function done(){signal.removeEventListener('abort',abort);resolve();}function abort(){clearTimeout(timer);signal.removeEventListener('abort',abort);reject(signal.reason);}signal.addEventListener('abort',abort,{once:true});});}
/** One observation budget covers retirement, admission HTTP, status and catalog.
 * Playback preparation takes over its existing separate timeout after exact-SID lookup. */
function observationBudget(io,abort){
 const now=io.now??(()=>performance.now()),deadline=now()+120000,timeout=new AbortController();
 let expired=false,closed=false;
 const expire=()=>{if(closed||expired)return;expired=true;const error=Error('Host verification observation timed out.');error.name='WatchObservationTimeout';timeout.abort(error);};
 const timer=(io.deadlineSchedule??setTimeout)(expire,120000),signal=AbortSignal.any([abort.signal,timeout.signal]);
 const remaining=()=>deadline-now();
 function guard(){if(!closed&&remaining()<=0)expire();if(signal.aborted)throw signal.reason;}
 async function run(action){
  guard();let listener;
  const interrupted=new Promise((resolve,reject)=>{listener=()=>reject(signal.reason);signal.addEventListener('abort',listener,{once:true});});
  try{const result=await Promise.race([Promise.resolve().then(()=>{guard();return action(signal);}),interrupted]);guard();return result;}
  finally{signal.removeEventListener('abort',listener);}
 }
 return {run,remaining,expired:()=>expired,close(){if(!closed){closed=true;(io.deadlineClear??clearTimeout)(timer);}}};
}
/** All target/request identity is local to this owner. Cancellation is client-local;
 * it never claims to release an already accepted native registration. */
export function createTargetConnection(io){
 let intent=null,flight=null,revision=0;
 const current=(n,value)=>n===revision&&intent===value;
 const emit=(kind,busy=false)=>io.onState?.({kind,busy,message:messages[kind]??messages.error});
 function cancel({preserve=false}={}){const binding=intent?.binding&&!intent?.bound;if(intent)intent.binding=false;revision++;flight?.abort.abort();flight=null;let retirement;try{if(binding)retirement=io.cancelBinding?.();}catch(error){retirement=Promise.reject(error);}const retired=Promise.resolve(retirement);retired.catch(()=>{});if(!preserve)intent=null;emit('cancelled');return retired;}
 function run(value){
  const n=++revision,abort=new AbortController(),budget=observationBudget(io,abort);
  emit('connecting',true);
  let retirement;try{retirement=io.reset();}catch{budget.close();emit('unavailable');return Promise.resolve();}
  const promise=(async()=>{
   try{
    await budget.run(()=>retirement);if(!current(n,value))return;
    for(;;){
     const result=await budget.run(signal=>value.acknowledged?io.status(value.id,signal):io.request(value.endpoint,value.id,signal));if(!current(n,value))return;
     // Transports validate HTTP-specific errors; injected adapters still cannot bind mismatched IDs.
     if((result?.request_id!==value.id&&!(result?.request_id===null&&result?.session_id===null&&terminal.has(result?.state)))||result?.schema!=='efz-watch-result/1'||!(result.session_id===null||typeof result.session_id==='string'&&opaque.test(result.session_id))||!Object.hasOwn(messages,result.state))throw protocolError();
     value.acknowledged=value.acknowledged||result.session_id!==null;value.result=result;emit(result.state,!terminal.has(result.state));
     if(terminal.has(result.state))return;
     if(result.session_id&&await budget.run(signal=>io.lookup(result.session_id,signal))){if(!current(n,value))return;budget.close();value.binding=true;await io.choose(result.session_id);if(!current(n,value))return;value.binding=false;value.bound=result.session_id;emit('connected');return;}
     if(!current(n,value))return;
     const remaining=budget.remaining();
     await budget.run(signal=>(io.wait??waitFor)(Math.min(remaining,Math.max(1000,Math.min(10000,result.retry_after_ms))),signal));if(!current(n,value))return;
    }
   }catch(error){if(current(n,value))emit(budget.expired()?'pending-timeout':error?.name==='WatchProtocolError'?'error':'unavailable');}
   finally{budget.close();if(flight?.promise===promise)flight=null;}
  })();
  flight={promise,abort};return promise;
 }
 function connect(input){
  let endpoint;try{endpoint=parsePlayerTarget(input);}catch(error){io.onState?.({kind:'invalid',busy:false,message:error.message});return Promise.resolve();}
  if(intent?.endpoint===endpoint){if(flight)return flight.promise;if(intent.bound)return Promise.resolve();return run(intent);}
  cancel();const id=(io.createId??randomId)();if(typeof id!=='string'||!opaque.test(id))throw protocolError();intent={endpoint,id,acknowledged:false,bound:null};return run(intent);
 }
 function edit(input){let target;try{target=parsePlayerTarget(input);}catch{}if(intent&&intent.endpoint!==target)cancel();}
 return Object.freeze({connect,edit,retry:()=>intent?(flight?.promise??run(intent)):Promise.resolve(),cancel,hasIntent:()=>intent!==null,isBound:()=>Boolean(intent?.bound)});
}

/** Native form semantics handle both button and Enter; ordinary paste needs no API. */
export function bindTargetForm(form,input,connection){
 const submit=event=>{event.preventDefault();void connection.connect(input.value);};
 const edit=()=>connection.edit(input.value);
 form.addEventListener('submit',submit);input.addEventListener('input',edit);
 return Object.freeze({dispose(){form.removeEventListener('submit',submit);input.removeEventListener('input',edit);}});
}

export function renderTargetState({form,input,button,status},state){
 form.setAttribute('aria-busy',String(state.busy));input.setAttribute('aria-invalid',String(state.kind==='invalid'));button.disabled=state.busy;status.textContent=state.message;
}
