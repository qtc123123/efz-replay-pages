// Presentation-only scene. No game runtime, game state, or RNG imports.
// C: sub_5807A0 offsets 1336/1340/1344; sub_581870 layer order.
export const WIDTH=320,HEIGHT=240;
export function sampleFrame(frame=59){
 if(!Number.isFinite(frame))throw Error('finite frame required');
 const c=60-Math.min(59,Math.max(0,Math.floor(frame))),r=0.01745328888888889;
 return Object.freeze({counter:c,skyY:95-Math.trunc(Math.cos(c*1.5*r)*-140),rearY:240-Math.trunc((Math.cos(c*r)-.5)*160),frontY:240-Math.trunc((Math.cos(c*r)-.5)*260)});
}
export function drawScene(context,sky,objects,frame=59){
 const s=sampleFrame(frame);context.imageSmoothingEnabled=false;context.clearRect(0,0,320,240);
 context.drawImage(sky,0,s.skyY,320,240,0,0,320,240);
 context.drawImage(objects,0,348,320,95,0,s.rearY,320,95);
 context.drawImage(objects,0,212,320,136,0,s.frontY,320,136);
 return s;
}
// WinMain gates scene updates on alternating 16/15ms intervals. This isolated
// presentation scheduler preserves that nominal cadence, not OS stall jitter.
export function elapsedFrame(ms){const t=Math.max(0,ms);return Math.min(59,Math.max(0,Math.floor(t/31)*2+(t%31>=16?1:0)-1));}
// A finite entrance, not an invented perpetual parallax animation.
export function mountScene(canvas,{skyUrl,objectsUrl,reducedMotion=matchMedia('(prefers-reduced-motion: reduce)').matches}={}){
 let disposed=false,raf=0;const context=canvas.getContext('2d');canvas.width=320;canvas.height=240;
 const load=url=>new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=reject;image.src=url});
 const ready=Promise.all([load(skyUrl),load(objectsUrl)]).then(([sky,objects])=>{if(disposed)return;const start=performance.now();function paint(now){if(disposed)return;const frame=reducedMotion?59:elapsedFrame(now-start);drawScene(context,sky,objects,frame);if(frame<59)raf=requestAnimationFrame(paint)}paint(start)});
 return {ready,dispose(){disposed=true;cancelAnimationFrame(raf)}};
}
