import {normalPath,sha256} from './assets.mjs';
import {CHARACTER_RESOURCE_NAMES} from './asset-selection.mjs';

const SCHEMA='miracle-encrypted-assets/1',SHA=/^[a-f0-9]{64}$/,BGM=/^wave\/bgm\/bgm[0-9]{2}\.wav$/;
const MEDIA_SCHEMA='miracle-encrypted-assets/2';
export const ENCRYPTED_ASSET_LIMITS=Object.freeze({manifestBytes:4*1024*1024,files:20000,
 plainObjectBytes:64*1024*1024,cipherObjectBytes:64*1024*1024+128*1024,totalPlainBytes:512*1024*1024,
 residentPlainBytes:256*1024*1024,parallel:4,pending:64});
const L=ENCRYPTED_ASSET_LIMITS,encoder=new TextEncoder();
const typedPrototype=Object.getPrototypeOf(Uint8Array.prototype);
const typedTag=Object.getOwnPropertyDescriptor(typedPrototype,Symbol.toStringTag).get;
const typedLength=Object.getOwnPropertyDescriptor(typedPrototype,'byteLength').get;
const typedBuffer=Object.getOwnPropertyDescriptor(typedPrototype,'buffer').get;
const resizable=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get;
const need=(ok,message)=>{if(!ok)throw Error('encrypted assets: '+message);};
const uint=(n,max)=>Number.isSafeInteger(n)&&n>=0&&!Object.is(n,-0)&&n<=max;
function fields(value,keys,optional=[]){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain record required');
 const actual=Reflect.ownKeys(value);need(actual.length<=keys.length+optional.length&&keys.every(k=>actual.includes(k))&&actual.every(k=>keys.includes(k)||optional.includes(k)),'record fields');
 const owned={};for(const key of actual){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'accessor refused');owned[key]=d.value;}return owned;
}
function decode64(value,length){
 need(typeof value==='string'&&value.length===Math.ceil(length*8/6)&&/^[A-Za-z0-9_-]+$/.test(value),'base64url encoding');
 const base=value.replaceAll('-','+').replaceAll('_','/'),raw=atob(base+'='.repeat((4-base.length%4)%4));
 const bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));
 need(bytes.length===length&&btoa(raw).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'')===value,'canonical base64url required');return bytes;
}
function ownKey(value){
 if(typeof value==='string')return decode64(value,32);
 need(ArrayBuffer.isView(value)&&typedTag.call(value)==='Uint8Array','32-byte key required');
 const buffer=typedBuffer.call(value);need(typedLength.call(value)===32&&Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&!(resizable?.call(buffer)),'32-byte fixed key required');
 const owned=new Uint8Array(32);Uint8Array.prototype.set.call(owned,value);return owned;
}

/** Original effect/voice ranges; sparse missing files remain absent. */
export function isSoundAssetPath(path){
 if(typeof path!=='string')return false;
 const effect=/^wave\/se\/([0-9]{2})\.wav$/.exec(path);if(effect)return Number(effect[1])<=64;
 const voice=/^([^/]+)\/wave\/([0-9]{2})\.wav$/.exec(path);
 return !!voice&&CHARACTER_RESOURCE_NAMES.includes(voice[1])&&Number(voice[2])<=49;
}

/** No key, IO or engine is needed to validate this data-only deployment index. */
export function validateEncryptedAssetManifest(value){
 const manifest=fields(value,['schema','cipher','compression','files']);
 need([SCHEMA,MEDIA_SCHEMA].includes(manifest.schema)&&manifest.cipher==='AES-256-GCM'&&manifest.compression==='gzip','manifest profile');
 need(Array.isArray(manifest.files)&&manifest.files.length<=L.files&&Reflect.ownKeys(manifest.files).length===manifest.files.length+1,'manifest files');
 const paths=new Set(),plain=new Map(),cipher=new Map(),ivs=new Map(),files=[];let total=0;
 for(let i=0;i<manifest.files.length;i++){
  const d=Object.getOwnPropertyDescriptor(manifest.files,String(i));need(d&&'value'in d&&d.enumerable,'manifest array entry');
  const e=fields(d.value,['path','sha256','bytes','object']),path=normalPath(e.path);
  need(path===e.path&&!paths.has(path)&&/\.(dat|pat|pal|wav)$/.test(path),'asset path');paths.add(path);
  need(typeof e.sha256==='string'&&SHA.test(e.sha256)&&uint(e.bytes,L.plainObjectBytes),'plaintext extent/digest');total+=e.bytes;need(total<=L.totalPlainBytes,'plaintext capacity');
  if(path.endsWith('.wav')&&!BGM.test(path)){
   if(manifest.schema===SCHEMA)need(e.object===null,'audio payload must be unavailable');
   else need(isSoundAssetPath(path),'unsupported sound path');
  }
  else need(e.object!==null,'simulation or selected music payload required');
  let object=null;
  if(e.object!==null){
   const o=fields(e.object,['sha256','bytes','iv']);need(typeof o.sha256==='string'&&SHA.test(o.sha256)&&uint(o.bytes,L.cipherObjectBytes)&&o.bytes>=16,'ciphertext extent/digest');decode64(o.iv,12);
   object=Object.freeze(o);const identity=e.sha256+'\0'+e.bytes,descriptor=JSON.stringify(o);
   need(!cipher.has(o.sha256)||cipher.get(o.sha256)===identity+'\0'+descriptor,'conflicting ciphertext identity');cipher.set(o.sha256,identity+'\0'+descriptor);
   need(!ivs.has(o.iv)||ivs.get(o.iv)===o.sha256,'IV reuse');ivs.set(o.iv,o.sha256);
  }
  const previous=plain.get(e.sha256);need(!previous||previous.bytes===e.bytes,'conflicting plaintext extent');
  if(previous?.object&&object)need(JSON.stringify(previous.object)===JSON.stringify(object),'conflicting plaintext object');
  plain.set(e.sha256,{bytes:e.bytes,object:object??previous?.object??null});files.push(Object.freeze({path,sha256:e.sha256,bytes:e.bytes,object}));
 }
 // v2 extends sound availability only. Object encryption/AAD deliberately
 // remains v1, allowing authenticated existing ciphertext to retain identity.
 const result=Object.freeze({schema:manifest.schema,cipher:'AES-256-GCM',compression:'gzip',files:Object.freeze(files)});
 need(encoder.encode(JSON.stringify(result)).length<=L.manifestBytes,'manifest metadata capacity');return result;
}

async function fetchCipher(url,object,fetcher,signal){
 const response=await fetcher(url,{signal,credentials:'same-origin',redirect:'error'});
 need(response?.ok&&response.body,'ciphertext HTTP response');
 const declared=response.headers.get('content-length');
 const encoding=response.headers.get('content-encoding')?.trim().toLowerCase();
 // Fetch decodes HTTP content encodings, but Content-Length describes the
 // encoded response. Enforce the manifest's decoded size and digest below.
 if((!encoding||encoding==='identity')&&declared!==null&&(!/^[0-9]+$/.test(declared)||Number(declared)!==object.bytes)){await response.body.cancel();throw Error('encrypted assets: ciphertext extent');}
 const bytes=new Uint8Array(object.bytes),reader=response.body.getReader();let position=0;
 try{
  for(;;){signal.throwIfAborted();const {done,value}=await reader.read();if(done)break;
   need(ArrayBuffer.isView(value)&&typedTag.call(value)==='Uint8Array','response byte chunk');const length=typedLength.call(value);
   need(position+length<=bytes.length,'ciphertext extent');bytes.set(value,position);position+=length;
  }
 }catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
 need(position===bytes.length,'ciphertext extent');need(await sha256(bytes)===object.sha256,'ciphertext digest');return bytes;
}
async function inflateBounded(compressed,expected,signal){
 need(typeof DecompressionStream==='function','gzip decompressor unavailable');let offset=0;
 // Small input chunks also bound the decoder's work before each output check.
 const source=new ReadableStream({pull(controller){if(offset===compressed.length){controller.close();return;}
  const end=Math.min(offset+16384,compressed.length);controller.enqueue(compressed.subarray(offset,end));offset=end;}});
 const reader=source.pipeThrough(new DecompressionStream('gzip')).getReader(),out=new Uint8Array(expected);let position=0;
 const abort=()=>{void reader.cancel().catch(()=>{});};signal.addEventListener('abort',abort,{once:true});
 try{
  for(;;){signal.throwIfAborted();const {done,value}=await reader.read();signal.throwIfAborted();if(done)break;
   need(position+value.length<=expected,'gzip plaintext extent');out.set(value,position);position+=value.length;
  }
  need(position===expected,'gzip plaintext extent');return out;
 }catch(error){await reader.cancel().catch(()=>{});out.fill(0);throw error;}
 finally{signal.removeEventListener('abort',abort);reader.releaseLock();}
}

/** One selected battle manifest; metadata existence survives cold/omitted audio
 * bodies. Only authenticated, length- and hash-checked plaintext enters bytes(). */
export class EncryptedAssetCatalog{
 #entries;#root;#fetch;#keyBytes;#keyPromise=null;#loaded=new Map();#pending=new Map();#queue=[];#running=0;#disposed=false;#abort=new AbortController();
 constructor(value,root,options){
  const manifest=validateEncryptedAssetManifest(value),config=fields(options,['key'],['fetcher']);
  // A deployment index can describe many battles and metadata-only sounds.
  // Bound this selected owner's possible retained plaintext separately. The
  // validated manifest guarantees one identity for each ciphertext descriptor.
  const objects=new Set();let resident=0;
  for(const entry of manifest.files)if(entry.object&&!objects.has(entry.object.sha256)){
   objects.add(entry.object.sha256);resident+=entry.bytes;need(resident<=L.residentPlainBytes,'resident plaintext capacity');
  }
  need(typeof root==='string'&&root.length<=4096,'asset root');this.#root=new URL(root);
  need(['https:','http:'].includes(this.#root.protocol)&&this.#root.pathname.endsWith('/')&&!this.#root.search&&!this.#root.hash&&!this.#root.username&&!this.#root.password,'asset root');
  this.#fetch=config.fetcher??globalThis.fetch;need(typeof this.#fetch==='function','fetcher required');this.#keyBytes=ownKey(config.key);
  this.#entries=new Map(manifest.files.map(e=>[e.path,e]));
 }
 #check(){need(!this.#disposed,'catalog disposed');}
 has(path){return this.#entries.has(normalPath(path));}
 paths(){return [...this.#entries.keys()];}
 isLoaded(path){const e=this.#entries.get(normalPath(path));return !!e?.object&&this.#loaded.has(e.sha256);}
 bytes(path){this.#check();const e=this.#entries.get(normalPath(path)),bytes=e?.object&&this.#loaded.get(e.sha256);need(bytes,'asset not loaded');return bytes.slice();}
 load(path){
  try{this.#check();const e=this.#entries.get(normalPath(path));need(e,'asset missing');need(e.object,'asset payload unavailable');
   if(this.#loaded.has(e.sha256))return Promise.resolve();if(this.#pending.has(e.sha256))return this.#pending.get(e.sha256).promise;
   need(this.#pending.size<L.pending,'pending load capacity');let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});
   const job={entry:e,promise,resolve,reject};this.#pending.set(e.sha256,job);this.#queue.push(job);this.#pump();return promise;
  }catch(error){return Promise.reject(error);}
 }
 #pump(){while(!this.#disposed&&this.#running<L.parallel&&this.#queue.length){const job=this.#queue.shift();this.#running++;void this.#run(job);}}
 async #run(job){
  let error;try{await this.#download(job.entry);}catch(failure){error=failure;}
  this.#running--;this.#pending.delete(job.entry.sha256);this.#pump();if(error)job.reject(error);else job.resolve();
 }
 async #download(entry){
  const encrypted=await fetchCipher(new URL('objects/'+entry.object.sha256+'.bin',this.#root),entry.object,this.#fetch,this.#abort.signal);this.#check();
  if(!this.#keyPromise){const bytes=this.#keyBytes.slice();this.#keyPromise=crypto.subtle.importKey('raw',bytes,{name:'AES-GCM'},false,['decrypt']).finally(()=>bytes.fill(0));}
  const key=await this.#keyPromise;this.#check();
  const compressed=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:decode64(entry.object.iv,12),tagLength:128,
   additionalData:encoder.encode(SCHEMA+'\0'+entry.sha256+'\0'+entry.bytes)},key,encrypted));this.#check();
  const plain=await inflateBounded(compressed,entry.bytes,this.#abort.signal);this.#check();
  need(await sha256(plain)===entry.sha256,'plaintext digest');this.#check();this.#loaded.set(entry.sha256,plain);
 }
 async #loadPaths(paths){let next=0;try{this.#check();await Promise.all(Array.from({length:Math.min(L.parallel,paths.length)},async()=>{while(next<paths.length)await this.load(paths[next++]);}));}
  catch(error){this.dispose();throw error;}}
 loadForSimulation(){return this.#loadPaths(this.paths().filter(path=>!path.endsWith('.wav')));}
 loadAll(){return this.#loadPaths(this.paths());}
 dispose(){
  if(this.#disposed)return;this.#disposed=true;this.#abort.abort();this.#keyBytes.fill(0);this.#keyPromise=null;
  for(const bytes of this.#loaded.values())bytes.fill(0);this.#loaded.clear();
  for(const job of this.#queue){this.#pending.delete(job.entry.sha256);job.reject(Error('encrypted assets: catalog disposed'));}this.#queue=[];
 }
}
