/** Read-only complete-recording analysis. No engine calls or retained frame/event
 * arrays: each traversal owns only its coverage and current combat episode. */
const MAX_FRAMES=1000000,MAX_EVENTS=64;
const PHASES=new Set(['loading','intro','round-transition','round-ko','combat','finish','cleanup']);
const STAGES=new Set(['entry','render','post-intro','round-judge','post-effects','post-stage','complete']);
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
const need=(ok,message)=>{if(!ok)throw Error('Round analysis: '+message);};
export function validateRoundSummary(value,{frames,winRounds}={}){
 const keys=['schema','frames','winRounds','roundsPlayed','matchStatus',...(Object.hasOwn(value??{},'roundStarts')?['roundStarts']:[])];
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain summary required');
 const own=Reflect.ownKeys(value);need(own.length===keys.length&&keys.every(key=>own.includes(key)),'summary fields');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'summary data fields');out[key]=d.value;}
 need(['finished','interrupted','unknown'].includes(out.matchStatus),'match status');
 need(out.schema==='efz-round-summary/1'&&integer(out.frames,1,MAX_FRAMES)&&integer(out.winRounds,1,5)&&integer(out.roundsPlayed,0,out.frames*MAX_EVENTS),'summary extent/version');
 need((frames===undefined||out.frames===frames)&&(winRounds===undefined||out.winRounds===winRounds),'summary configuration/coverage');if(out.roundStarts!==undefined){out.roundStarts=validateStarts(out.roundStarts,out.frames);need(out.roundStarts.length<=out.roundsPlayed,'round marker count');}return Object.freeze(out);
}
function validateStarts(value,frames){
 need(Array.isArray(value)&&value.length<=256&&Reflect.ownKeys(value).length===value.length+1,'round marker capacity');let last=0;return Object.freeze(Array.from({length:value.length},(_,i)=>{const d=Object.getOwnPropertyDescriptor(value,String(i));need(d&&'value'in d&&integer(d.value,last+1,frames),'round marker order');last=d.value;return last;}));
}
export function createRoundAccumulator({markers=false}={}){
 let starts=[],observing=0;
 let coveredThrough=0,phase=null,round=null,roundsPlayed=0,valid=true;
 function transition(nextPhase,nextRound){
  need(PHASES.has(nextPhase)&&integer(nextRound,0,0xffffffff),'phase observation');
  // A changed label while still in combat does not establish a new episode.
  // Source hooks must expose the intervening noncombat transition, or unknown.
  need(phase!=='combat'||nextPhase!=='combat'||nextRound===round,'ambiguous combat label');
  if(nextPhase==='combat'&&phase!=='combat'){roundsPlayed++;if(markers&&starts.at(-1)!==observing){need(starts.length<256,'round marker capacity');starts.push(observing);}}
  phase=nextPhase;round=nextRound;
 }
 function observe(result){
  if(!valid)return;
  try{
   need(result&&['advanced','end'].includes(result.kind)&&result.nextFrame===coveredThrough+1&&integer(result.nextFrame,1,MAX_FRAMES),'contiguous complete update');
   observing=result.nextFrame;const o=result.observation;need(o&&o.nextUpdate===result.nextFrame&&Array.isArray(o.engineEvents)&&o.engineEvents.length<=MAX_EVENTS,'complete phase coverage');
   if(coveredThrough===0)need(o.engineEvents[0]?.stage==='entry','initial phase coverage');
   for(const event of o.engineEvents){need(event&&STAGES.has(event.stage)&&(event.innerTick===null||integer(event.innerTick,-1,MAX_FRAMES)),'ordered engine event');transition(event.phase,event.round);}
   need(o.phase===phase&&o.round===round,'missing phase transition');coveredThrough=result.nextFrame;
  }catch{valid=false;}
 }
 function complete(frames,winRounds,terminalState){
  if(!valid||coveredThrough!==frames)return null;
  try{
   let matchStatus='unknown';
   if(terminalState?.nextFrame===frames&&terminalState.failed===false){
    const current=terminalState.characters;
    const players=current===undefined||Array.isArray(current)&&current.length===2&&current.every(p=>p===null)?terminalState.lastCharacters:current;
    // Missing characters at cleanup may use the engine's retained last-live
    // score. Malformed current data never silently falls back to another score.
    if(Array.isArray(players)&&players.length===2&&players.every(p=>p&&integer(p.wins,0,5)))matchStatus=players.some(p=>p.wins>=winRounds)?'finished':'interrupted';
   }
   return validateRoundSummary({schema:'efz-round-summary/1',frames,winRounds,roundsPlayed,matchStatus,...markers?{roundStarts:starts}:{}},{frames,winRounds});
  }catch{return null;}
 }
 function capture(){return Object.freeze({schema:'efz-round-accumulator/1',coveredThrough,phase,round,roundsPlayed,valid,...markers?{roundStarts:Object.freeze([...starts])}:{}});}
 function restore(value,nextUpdate){
  const keys=['schema','coveredThrough','phase','round','roundsPlayed','valid',...(Object.hasOwn(value??{},'roundStarts')?['roundStarts']:[])];
  need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value))&&Reflect.ownKeys(value).length===keys.length,'checkpoint shape');
  const v={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'checkpoint data fields');v[key]=d.value;}
  need(v.schema==='efz-round-accumulator/1'&&integer(nextUpdate,0,MAX_FRAMES)&&integer(v.coveredThrough,0,nextUpdate)&&typeof v.valid==='boolean','checkpoint coverage');
  need(!v.valid||v.coveredThrough===nextUpdate,'checkpoint boundary');
  need(v.phase===null||PHASES.has(v.phase),'checkpoint phase');need(v.round===null||integer(v.round,0,0xffffffff),'checkpoint round');
  need(integer(v.roundsPlayed,0,MAX_FRAMES*MAX_EVENTS),'checkpoint count');
  starts=v.roundStarts===undefined?[]:[...validateStarts(v.roundStarts,v.coveredThrough)];
  coveredThrough=v.coveredThrough;phase=v.phase;round=v.round;roundsPlayed=v.roundsPlayed;valid=v.valid;
 }
 return Object.freeze({observe,complete,capture,restore});
}
