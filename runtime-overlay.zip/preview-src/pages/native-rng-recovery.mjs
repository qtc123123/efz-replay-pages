/** Candidate inference only, NOT replay admission or original-native qualification.
 * Callers must establish actual RAND-call ordinals, then validate every original
 * RNG witness and exact EOF in a fresh replay under the inferred seed. Inference
 * never crosses an untaped gap: visual RAND calls can change their own schedule.
 */
const MODULUS=0x80000000,INVERSE=968044885,MAX_OBSERVATIONS=32;
const need=(ok,message)=>{if(!ok)throw Error('Native RNG recovery: '+message);};
const uint=(n,max)=>Number.isInteger(n)&&!Object.is(n,-0)&&n>=0&&n<=max;
function data(object,key){const d=Object.getOwnPropertyDescriptor(object,key);need(d&&'value'in d&&d.enumerable,'accessor or missing field');return d.value;}
function validate(value){
 need(Array.isArray(value)&&Object.getPrototypeOf(value)===Array.prototype,'plain observation array');
 need(value.length<=MAX_OBSERVATIONS,'at most 32 observations');
 need(Reflect.ownKeys(value).length===value.length+1,'array fields');
 const owned=[];let previous=0;
 for(let i=0;i<value.length;i++){
  const r=data(value,String(i));need(r&&[Object.prototype,null].includes(Object.getPrototypeOf(r)),'plain observation');
  const keys=Reflect.ownKeys(r);need(keys.length===2&&keys.includes('ordinal')&&keys.includes('value'),'observation fields');
  const ordinal=data(r,'ordinal'),output=data(r,'value');
  need(uint(ordinal,0xffffffff)&&ordinal>previous,'strictly increasing positive uint32 ordinal');need(uint(output,32767),'uint15 output');
  owned.push({ordinal,value:output});previous=ordinal;
 }
 return owned;
}
/** Return a seed canonical modulo 2^31; the hidden high bit never affects any
 * future CRT 15-bit output. Invalid input throws; insufficient evidence refuses.
 * `observations` reports only the initial consecutive prefix actually considered.
 */
export function recoverNativeCrtSeed(observations){
 const owned=validate(observations);
 const unavailable=(reason,count)=>Object.freeze({kind:'unavailable',reason,observations:count,qualified:false});
 if(!owned.length)return unavailable('no-evidence',0);
 if(owned[0].ordinal!==1)return unavailable('unknown-initial-callgap',0);
 let count=1;while(count<owned.length&&owned[count].ordinal===count+1)count++;
 if(count<3)return unavailable(count<owned.length?'unknown-initial-callgap':'ambiguous',count);
 let matches=0,firstState=0;
 for(let low=0;low<65536;low++){
  const initial=owned[0].value*65536+low;let state=initial,consistent=true;
  for(let i=1;i<count;i++){
   state=(Math.imul(state,214013)+2531011)&0x7fffffff;
   if((state>>>16)!==owned[i].value){consistent=false;break;}
  }
  if(consistent){matches++;firstState=initial;}
 }
 if(matches!==1)return unavailable(matches?'ambiguous':'inconsistent',count);
 // 214013 * INVERSE === 1 modulo 2^31; imul gives exact low 32 bits.
 const seed=Math.imul(firstState-2531011,INVERSE)&0x7fffffff;
 return Object.freeze({kind:'candidate',seed,observations:count,stateModulus:MODULUS,qualified:false});
}
