/** Read-only labels at native renderer bar centers (320x240 coordinates).
 * HP: x18..138 /182..302 y18..24; SP:y224..228; RF:y232..234.
 * Label glyphs may extend above/below the two-pixel RF fill, never move bars. */
export function numericHud(stats,prepared){
 const hud=prepared?.hud;if(stats?.availability!=='live'||hud?.visible!==true||!Array.isArray(hud.players)||hud.players.length!==2)return [];
 return hud.players.flatMap((p,side)=>['hp','sp','rf'].map((field,i)=>{
  const value=p?.[field];if(!Number.isFinite(value))throw Error('Unavailable HUD value');
  return Object.freeze({side,field,x:side?320-[78,86,109][i]:[78,86,109][i],y:[21,226,233][i],text:Number.isInteger(value)?String(value):value.toFixed(1).replace(/\.0$/,''),raw:value});
 }));
}
