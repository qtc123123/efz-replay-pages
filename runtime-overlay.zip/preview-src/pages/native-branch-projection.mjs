/** Exact native-input projection for a separate training branch.
 * Keeps every ordered inner pair and outer auxiliary word. Never stores RNG,
 * guesses missing controls, or exposes mutable projection storage. The raw
 * transfer record is mutable typed storage; admission always copies it. */
const MAX_UPDATES=1000000,CHUNK=1024,STRIDE=256;
export const NATIVE_BRANCH_SCHEMA='efz-native-branch/1';
const need=(ok,message)=>{if(!ok)throw Error('Native branch: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
function record(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain record');
 const own=Reflect.ownKeys(value);need(own.length===keys.length&&keys.every(key=>own.includes(key)),'fields');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'accessor');out[key]=d.value;}return out;
}
function list(value,max){
 need(Array.isArray(value)&&Object.getPrototypeOf(value)===Array.prototype&&value.length<=max&&Reflect.ownKeys(value).length===value.length+1,'dense bounded array');
 const out=[];for(let i=0;i<value.length;i++){const d=Object.getOwnPropertyDescriptor(value,String(i));need(d&&'value'in d&&d.enumerable,'array accessor');out.push(d.value);}return out;
}
const typed=Object.getPrototypeOf(Uint8Array.prototype),get=name=>Object.getOwnPropertyDescriptor(typed,name).get;
const bufferLength=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'byteLength').get,bufferResizable=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get;
function copyStorage(value,C,maximum){
 need(value&&Object.getPrototypeOf(value)===C.prototype,'typed storage');
 const buffer=get('buffer').call(value),size=get('byteLength').call(value),offset=get('byteOffset').call(value),length=get('length').call(value);
 need(Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&!bufferResizable?.call(buffer)&&offset===0&&size===bufferLength.call(buffer)&&length<=maximum,'fixed storage extent');
 // Intrinsics avoid caller-owned buffer/constructor/species accessors.
 const out=new C(length);C.prototype.set.call(out,value);return out;
}
export function createNativeBranchBuilder(options={}){
 const o=record(options,Object.hasOwn(options,'maxUpdates')?['maxUpdates']:[]),maxUpdates=Object.hasOwn(o,'maxUpdates')?o.maxUpdates:MAX_UPDATES;
 need(integer(maxUpdates,1,MAX_UPDATES),'capacity');let chunks=[],frames=0,ticks=0,auxTotal=0,closed=false;
 function append(value){
  need(!closed,'builder closed');need(frames<maxUpdates,'capacity');const p=record(value,['nextUpdate','reads','aux']);need(p.nextUpdate===frames+1,'update order');
  const reads=list(p.reads,6),aux=list(p.aux,2);need(reads.length%2===0,'ordered pairs');need(aux.length===2||aux.length===0&&reads.length===0,'auxiliary count requires two words or empty cleanup');
  const words=reads.map((value,i)=>{const r=record(value,['innerTick','side','word']);need(integer(r.innerTick,0,2)&&integer(r.side,0,1)&&r.innerTick===Math.floor(i/2)&&r.side===i%2&&integer(r.word,0,255),'read order/word');return r.word;});
  need(aux.every(word=>integer(word,0,65535)),'auxiliary word');
  // Only mutate the builder after the complete update has passed admission.
  const index=Math.floor(frames/CHUNK),slot=frames%CHUNK;
  const chunk=chunks[index]??(chunks[index]={counts:new Uint8Array(CHUNK),masks:new Uint8Array(CHUNK*6),auxCounts:new Uint8Array(CHUNK),auxWords:new Uint16Array(CHUNK*2)});
  chunk.counts[slot]=words.length/2;chunk.masks.set(words,slot*6);chunk.auxCounts[slot]=aux.length;chunk.auxWords.set(aux,slot*2);
  ticks+=words.length/2;auxTotal+=aux.length;frames++;
 }
 function finish(){
  need(!closed,'builder closed');need(frames>0,'empty projection');closed=true;
  const counts=new Uint8Array(frames),masks=new Uint8Array(ticks*2),auxCounts=new Uint8Array(frames),auxWords=new Uint16Array(auxTotal);let sample=0,auxOffset=0;
  for(let i=0;i<frames;i++){const c=chunks[Math.floor(i/CHUNK)],slot=i%CHUNK,count=c.counts[slot],auxCount=c.auxCounts[slot];counts[i]=count;auxCounts[i]=auxCount;masks.set(c.masks.subarray(slot*6,slot*6+count*2),sample*2);auxWords.set(c.auxWords.subarray(slot*2,slot*2+auxCount),auxOffset);sample+=count;auxOffset+=auxCount;}
  chunks=[];return Object.freeze({schema:NATIVE_BRANCH_SCHEMA,counts,masks,auxCounts,auxWords});
 }
 return Object.freeze({append,finish,dispose(){closed=true;chunks=[];},inspect:()=>Object.freeze({updates:frames,ticks,closed})});
}
export function createNativeBranchProjection(raw,frames){
 need(integer(frames,1,MAX_UPDATES),'frame extent');const value=record(raw,['schema','counts','masks','auxCounts','auxWords']);need(value.schema===NATIVE_BRANCH_SCHEMA,'schema');
 const counts=copyStorage(value.counts,Uint8Array,frames),auxCounts=copyStorage(value.auxCounts,Uint8Array,frames);need(counts.length===frames&&auxCounts.length===frames,'count extent');
 const prefixes=new Uint32Array(Math.ceil(frames/STRIDE)),auxPrefixes=new Uint32Array(prefixes.length);let ticks=0,auxTotal=0;
 for(let i=0;i<frames;i++){
  if(i%STRIDE===0){prefixes[i/STRIDE]=ticks;auxPrefixes[i/STRIDE]=auxTotal;}
  need(counts[i]<=3,'tick count');need(auxCounts[i]===2||auxCounts[i]===0&&counts[i]===0,'auxiliary count');ticks+=counts[i];auxTotal+=auxCounts[i];
 }
 const masks=copyStorage(value.masks,Uint8Array,ticks*2),auxWords=copyStorage(value.auxWords,Uint16Array,auxTotal);need(masks.length===ticks*2&&auxWords.length===auxTotal,'word extent');
 function offset(nextUpdate,counts,prefix,total){if(nextUpdate===frames)return total;const block=Math.floor(nextUpdate/STRIDE);let out=prefix[block];for(let i=block*STRIDE;i<nextUpdate;i++)out+=counts[i];return out;}
 function sampleOffset(nextUpdate){need(integer(nextUpdate,0,frames),'sample boundary');return offset(nextUpdate,counts,prefixes,ticks);}
 function pairAtTick(tick){need(integer(tick,0,ticks-1),'tick boundary');return Object.freeze([masks[tick*2],masks[tick*2+1]]);}
 return Object.freeze({schema:NATIVE_BRANCH_SCHEMA,frames,ticks,bytes:counts.byteLength+masks.byteLength+auxCounts.byteLength+auxWords.byteLength+prefixes.byteLength+auxPrefixes.byteLength,sampleOffset,pairAtTick,
  samples(update){need(integer(update,0,frames-1),'update boundary');const first=sampleOffset(update);return Object.freeze(Array.from({length:counts[update]},(_,i)=>pairAtTick(first+i)));},
  aux(update){need(integer(update,0,frames-1),'update boundary');const first=offset(update,auxCounts,auxPrefixes,auxTotal);return Object.freeze(Array.from({length:auxCounts[update]},(_,i)=>auxWords[first+i]));}
 });
}
