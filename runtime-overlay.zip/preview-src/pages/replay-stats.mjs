/** Read-only Pages telemetry. N consumes inputs [0,N); sourceUpdate is the
 * zero-based update that actually supplied the actor values, independently of
 * the prepared image's originUpdate. There is no actor snapshot at boundary 0. */
export const REPLAY_STATS_SCHEMA='efz-local-stats/1';
const need=(ok,message)=>{if(!ok)throw Error('Replay statistics: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
const finite=(n,min,max)=>typeof n==='number'&&Number.isFinite(n)&&n>=min&&n<=max;
function record(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain record required');
 const names=Reflect.ownKeys(value);need(names.length===keys.length&&keys.every(key=>names.includes(key)),'fields');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'accessor refused');out[key]=d.value;}return out;
}
export function emptyReplayStats(nextUpdate=0){
 need(integer(nextUpdate,0,1000000),'boundary');
 return Object.freeze({schema:REPLAY_STATS_SCHEMA,nextUpdate,sourceUpdate:null,availability:'none',players:null});
}
export function validateReplayStats(value,nextUpdate,initialization=null){
 const s=record(value,['schema','nextUpdate','sourceUpdate','availability','players']);
 need(s.schema===REPLAY_STATS_SCHEMA&&integer(nextUpdate,0,1000000)&&s.nextUpdate===nextUpdate,'boundary/schema');
 need(['none','live','last-live'].includes(s.availability),'availability');
 if(s.availability==='none'){
  need(s.sourceUpdate===null&&s.players===null,'unavailable actor values');return emptyReplayStats(nextUpdate);
 }
 need(nextUpdate>0&&integer(s.sourceUpdate,0,nextUpdate-1),'actor origin boundary');
 need(s.availability==='live'?s.sourceUpdate===nextUpdate-1:s.sourceUpdate<nextUpdate-1,'carried origin boundary');
 need(Array.isArray(s.players)&&s.players.length===2&&Reflect.ownKeys(s.players).length===3,'two players required');
 const players=[0,1].map(side=>{
  const descriptor=Object.getOwnPropertyDescriptor(s.players,String(side));need(descriptor&&'value'in descriptor,'player accessor refused');
  const p=record(descriptor.value,['character','color','hp','sp','rf','rfBlue','wins']);
  need(integer(p.character,0,24)&&integer(p.color,0,5),'fighter identity');
  if(initialization)need(p.character===initialization.characters[side]&&p.color===initialization.palettes[side],'fighter initialization');
  // HP is raw, not clamped to the ordinary 9999 baseline: Makoto can heal to
  // 10000 and KO damage can leave it negative. Bar clamping is UI-only.
  need(finite(p.hp,-2147483648,2147483647),'HP');
  need(finite(p.sp,0,3000),'SP');need(finite(p.rf,0,1000)&&typeof p.rfBlue==='boolean','RF/mode');
  need(integer(p.wins,0,initialization?.winRounds??3),'wins');
  return Object.freeze(p);
 });
 return Object.freeze({...s,players:Object.freeze(players)});
}
