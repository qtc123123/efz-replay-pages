import {createReplayCheckpointCache} from './replay-checkpoint-cache.mjs';
import {validateRoundSummary} from './replay-rounds.mjs';
import {createReplayClient,inspectPageReplay,REPLAY_PAGE_LIMITS} from './replay-session.mjs';
import {validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {validateReplayStats,emptyReplayStats} from './replay-stats.mjs';
import {validateReplayTraining,emptyReplayTraining} from './replay-training.mjs';
import {initialReplayMusicState} from './replay-music.mjs';
import {validateGameTranslation} from './game-translation.mjs';
import {createNativeInputIndex} from './native-input-index.mjs';
import {createNativeTakeoverPreparation} from './native-takeover-preparation.mjs';
import {createNativeReplayIndex} from './native-replay-index.mjs';

const need=(ok,message)=>{if(!ok)throw Error('Replay: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
const cancelled=()=>Error('Replay seek cancelled');

// Page-session metadata only: no keys, recordings, mutable game state or snapshots.
const admissionCaches=new WeakMap();
export function createNativeAdmissionCache({maxBytes=32*1024*1024}={}){
 need(integer(maxBytes,4096,32*1024*1024),'native cache byte capacity');
 const state={entries:new Map(),epoch:0,bytes:0,maxBytes};
 const handle=Object.freeze({clear(){state.entries.clear();state.bytes=0;state.epoch++;},inspect:()=>Object.freeze({entries:state.entries.size,capacity:32,bytes:state.bytes,maxBytes:state.maxBytes})});
 admissionCaches.set(handle,state);return handle;
}
const admissionWeight=result=>4096+(result.inputIndex?.bytes??0);
const digest=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');

/** Owns replay custody and the two Worker roles. onFrame may await painting.
 * prepareCommit may await preparation but must not write visible image/stats.
 * onCommit is the final synchronous image/stat write: it must not return a
 * Promise or retain delayed writes. It runs with owner promotion in one turn.
 * Both callbacks receive isCurrent(). onTerminalPresented notifies only after
 * a current ordinary terminal frame finishes painting and analysis promotion;
 * seek commits do not notify it. Physical audio remains page-owned. */
export function createReplayController({createWorker,onFrame=()=>{},prepareCommit=()=>{},onCommit=()=>{},onStatus=()=>{},onProgress=()=>{},onError=()=>{},onAnalysis=()=>{},onTerminalPresented=()=>{},onCheckpointError=()=>{},seekTimeoutMs=REPLAY_PAGE_LIMITS.seekMilliseconds,checkpoints=false,checkpointEngineHash=null,checkpointInterval=128,checkpointDelayMs=32,admissionCache=null,nativeTakeoverEngineHash=null}={}){
 need(typeof createWorker==='function'&&typeof prepareCommit==='function'&&typeof onCommit==='function'&&typeof onAnalysis==='function'&&typeof onTerminalPresented==='function'&&typeof onCheckpointError==='function'&&integer(seekTimeoutMs,1,600000),'controller dependencies');
 need(typeof checkpoints==='boolean'&&integer(checkpointInterval,1,4096)&&integer(checkpointDelayMs,1,1000),'checkpoint configuration');
 if(admissionCache!==null)need(admissionCaches.has(admissionCache),'native admission cache');
 if(checkpoints||admissionCache!==null)need(typeof checkpointEngineHash==='string'&&/^[a-f0-9]{64}$/.test(checkpointEngineHash),'checkpoint engine identity');
 need(nativeTakeoverEngineHash===null||typeof nativeTakeoverEngineHash==='string'&&/^[a-f0-9]{64}$/.test(nativeTakeoverEngineHash),'native takeover engine identity');
 need(Object.prototype.toString.call(onCommit)!=='[object AsyncFunction]','onCommit must be synchronous; use prepareCommit for asynchronous preparation');
 let branch=null,branchSequence=0,preparation=null;
 let replayId=0,generation=0,revision=0,intent=0,disposed=false,stored=null,meta=null,active=null,candidate=null,indexing=null,audio={};
 let checkpointCache=null,checkpointIdentity=null,builder=null,builderTimer=null,checkpointActive=true,checkpointDisabled=false,checkpointIssue=null,creditSequence=0;
 const retirements=new Set();let retirementFailure=null;
 function trackRetirement(value){const p=Promise.resolve(value);retirements.add(p);p.then(()=>retirements.delete(p),error=>{retirements.delete(p);retirementFailure=error;});return p;}
 function destroy(record){if(!record)return Promise.resolve();if(!record.retirement){try{record.retirement=trackRetirement(record.client.dispose());}catch(error){record.retirement=trackRetirement(Promise.reject(error));}}return record.retirement;}
 async function drainRetirements(){await Promise.all([...retirements]);if(retirementFailure)throw retirementFailure;}
 const emptyCache=Object.freeze({retired:true,entries:0,ownedBytes:0,reservedBytes:0,reservations:0,pins:0,provisionalEntries:0});
 function disableCheckpoints(error,phase='capture'){checkpointDisabled=true;checkpointCache?.retire();checkpointIssue=Object.freeze({phase,message:String(error?.message??error).slice(0,500)});onCheckpointError(checkpointIssue);}
 function stopPassive(record=active){
  const pending=record?.passive;if(!pending)return record?.passiveClosing;
  record.passive=null;
  const closing=Promise.resolve(record.client.cancelCheckpoint(pending.creditId));record.passiveClosing=closing;
  const finish=()=>{pending.cache.cancel(pending.token);pending.token=null;if(record.passiveClosing===closing){record.passiveClosing=null;armPassive(record);}};
  closing.then(finish,error=>{retirementFailure=error;checkpointDisabled=true;checkpointIssue=Object.freeze({phase:'cleanup',message:String(error?.message??error).slice(0,500)});if(record===active&&!disposed)onCheckpointError(checkpointIssue);});return closing;
 }
 function armPassive(record=active){
  if(stored?.nativeRecovery||preparation||branch||candidate?.branchTransition||!checkpoints||!checkpointActive||checkpointDisabled||disposed||!record||record!==active||candidate||builder||record.passive||record.passiveClosing||!checkpointCache||record.status?.state==='ended')return;
  const cache=checkpointCache,token=cache.reserve();if(!token)return;
  const creditId=++creditSequence,pending={cache,token,creditId};record.passive=pending;
  const owns=()=>!disposed&&record===active&&record.passive===pending&&checkpointCache===cache;
  try{record.client.armCheckpoint({creditId,interval:checkpointInterval},{
   onCapture:capture=>{if(!owns()){cache.cancel(token);return;}record.passive=null;cache.accept(token,capture);pending.token=null;armPassive(record);},
   onFailure:error=>{if(!owns()){cache.cancel(token);return;}record.passive=null;cache.cancel(token);pending.token=null;disableCheckpoints(error);}
  });}catch(error){record.passive=null;cache.cancel(token);pending.token=null;disableCheckpoints(error);}
 }
 function cleanupFailed(error){checkpointDisabled=true;checkpointIssue=Object.freeze({phase:'cleanup',message:String(error?.message??error).slice(0,500)});if(!disposed)onCheckpointError(checkpointIssue);}
 function stopBuilder(){
  if(builderTimer!==null)clearTimeout(builderTimer);builderTimer=null;
  const old=builder;builder=null;if(!old)return;
  if(old.timer!==undefined)clearTimeout(old.timer);old.wake?.();old.wake=null;
  const release=()=>{old.cache.cancel(old.reservation);old.reservation=null;old.pin?.release();old.pin=null;};void destroy(old.record).then(release,cleanupFailed);
 }
 function retireCheckpoints(){stopPassive();stopBuilder();checkpointCache?.retire();checkpointCache=null;checkpointIdentity=null;checkpointDisabled=false;checkpointIssue=null;}
 function scheduleBuilder(){
  if(stored?.nativeRecovery||preparation||branch||candidate?.branchTransition||!checkpoints||!checkpointActive||checkpointDisabled||disposed||!checkpointCache||meta?.format!=='revival-pairs'||!active?.presentation?.image||active.status.state!=='paused'||candidate||builder||builderTimer!==null)return;
  builderTimer=setTimeout(()=>{builderTimer=null;void buildCheckpoints();},checkpointDelayMs);
 }
 async function buildCheckpoints(){
  try{await drainRetirements();}catch(error){disableCheckpoints(error,'cleanup');return;}
  if(stored?.nativeRecovery||preparation||branch||builder||disposed||!checkpointActive||checkpointDisabled||!checkpointCache||!active||candidate||active.status.state!=='paused')return;
  stopPassive();const cache=checkpointCache,record=make(revision),job={cache,record,reservation:null,pin:null,phase:'initialization'};builder=job;
  const current=()=>!disposed&&builder===job&&checkpointCache===cache&&checkpointActive&&!candidate;
  try{
   await record.client.init({...stored,checkpointIdentity,checkpointBuilder:true});if(!current())return;
   // A foreground snapshot ahead of a hole cannot help Previous. Fill the
   // missing grid anchor before the displayed frame before extending the tail.
   const end=meta.frames-1,wanted=Math.max(0,Math.floor((active.status.nextFrame-1)/checkpointInterval)*checkpointInterval);
   job.pin=cache.pin(wanted);let boundary=job.pin?.capture?.nextUpdate??0,stopAt=wanted;
   if(boundary>=wanted){job.pin?.release();job.pin=cache.pin(end);boundary=job.pin?.capture?.nextUpdate??0;stopAt=end;}
   while(current()&&boundary<stopAt){
    const target=Math.min(stopAt,(Math.floor(boundary/checkpointInterval)+1)*checkpointInterval);
    job.reservation=cache.reserve();if(!job.reservation)break;
    const starting=job.pin?.capture??null;job.phase='simulation';
    await record.client.prepareSeek(target,starting);if(!current())return;
    job.pin?.release();job.pin=null;
    await record.client.commitSeek(target);if(!current())return;
    job.phase='capture';const capture=await record.client.capture();if(!current())return;
    const accepted=cache.accept(job.reservation,capture);job.reservation=null;boundary=target;
    if(accepted&&boundary===stopAt&&stopAt<end)job.followUp=true;
    if(boundary<stopAt)await new Promise(resolve=>{job.wake=resolve;job.timer=setTimeout(()=>{job.timer=null;job.wake=null;resolve();},checkpointDelayMs);});
   }
  }catch(error){if(current()){disableCheckpoints(error,job.phase);}}
  finally{
   if(job.timer!==undefined)clearTimeout(job.timer);job.wake?.();job.wake=null;
   try{await destroy(record);cache.cancel(job.reservation);job.reservation=null;job.pin?.release();job.pin=null;}
   catch(error){cleanupFailed(error);}const followUp=current()&&job.followUp;if(builder===job)builder=null;armPassive();
   // A builder can only seek forward. Retire it before filling the tail with
   // another producer, and never restart after cancellation or cleanup failure.
   if(followUp)scheduleBuilder();
  }
 }
 function setCheckpointActive(value){need(typeof value==='boolean','checkpoint activity');checkpointActive=value;if(!value){stopPassive();stopBuilder();}else{armPassive();scheduleBuilder();}}
 const status=()=>Object.freeze({...active?.status,...(active?{replayId:active.replayId,generation:active.generation,seekRevision:active.seekRevision}:{}),branch,nativeRecovery:meta?.nativeRecovery??null,preparingNativeTakeover:preparation!==null,seeking:candidate!==null||preparation!==null,target:candidate?.target??preparation?.anchor??null});
 function promoteAnalysis(record,value){
  if(branch||!value||disposed||record!==active||!meta)return;
  const summary=validateRoundSummary(value,{frames:meta.frames,winRounds:meta.initialization.winRounds});
  if(meta.analysis&&Object.keys(summary).every(key=>summary[key]===meta.analysis[key]))return;
  meta=Object.freeze({...meta,analysis:summary});onAnalysis(summary);
 }
 function publish(){if(active)onStatus(branch?Object.freeze({...active.status,branch}):active.status);}
 function silence(){intent++;audio.sounds?.pause();audio.music?.pause();}
 function make(seekRevision,payload=stored){
  need(generation<Number.MAX_SAFE_INTEGER,'worker generation capacity');const record={replayId,generation:++generation,seekRevision,status:null,client:null};
  record.client=createReplayClient(createWorker(payload?.nativeRecovery?'replay-native-takeover':undefined),{generation:record.generation,replayId,seekRevision,
   onStatus:s=>{record.status=s;if(record===active&&!disposed){if(s.state==='branch-ended'){stopPassive(record);silence();}publish();}},
   onFrame:async frame=>{
    if(record!==active||disposed)return;
    if(frame.result.stats)validateReplayStats(frame.result.stats,frame.status.nextFrame,meta.initialization);
    validateReplayTraining(frame.result.training,frame.status.nextFrame,meta.initialization,frame.image);
    // Paused/terminal frames only acknowledge the sound cursor. Do this
    // before awaiting paint so an older Step cannot cancel a newer Play.
    if(frame.status.state!=='playing'){audio.sounds?.present?.(frame);audio.music?.present?.(frame);}
    await onFrame(frame);if(record===active&&!disposed){
     record.presentation=Object.freeze({...frame,stats:frame.result.stats,training:frame.result.training});scheduleBuilder();
     if(frame.status.state==='playing'){audio.sounds?.present?.(frame);audio.music?.present?.(frame);}
          if(!branch&&frame.status.state==='ended'){
      stopPassive(record);
      promoteAnalysis(record,frame.result.analysis);
      // Analysis observers may synchronously replace/dispose this owner too.
      if(record===active&&!disposed)onTerminalPresented(frame);
     }
    }
   },
   onProgress:p=>{if(candidate?.record===record&&!disposed)onProgress(Object.freeze({...p,state:'seeking',cancelable:true}));},
   onError:error=>{if(record===active&&!disposed){retireCheckpoints();silence();onError(error);}}
  });return record;
 }
 function releaseSeekOwnership(transaction){transaction.pin?.release();transaction.pin=null;transaction.cache?.cancel(transaction.reservation);transaction.reservation=null;}
 function cancelSeek(){
  cancelNativePreparation();
  if(!candidate)return;const old=candidate;candidate=null;revision++;intent++;clearTimeout(old.timer);old.cancel(cancelled());void destroy(old.record).then(()=>releaseSeekOwnership(old),cleanupFailed);publish();
 }
 function cancelIndex(){const old=indexing;indexing=null;if(old)trackRetirement(old.dispose());}
 function retirePreparation(p){if(!p?.job)return Promise.resolve();if(!p.retirement)p.retirement=trackRetirement(p.job.dispose());return p.retirement;}
 function cancelNativePreparation(){const p=preparation;if(!p)return;preparation=null;intent++;p.cancel(cancelled());void retirePreparation(p).catch(cleanupFailed);publish();}
 async function prepareNativeTakeover(){
  need(nativeTakeoverEngineHash!==null,'native takeover package unavailable');
  need(!disposed&&stored&&meta?.format==='native-tape'&&active?.status?.state==='paused'&&!branch&&!candidate&&!preparation,'native preparation requires paused original replay');
  if(stored.nativeRecovery)return Object.freeze({kind:'qualified',...meta.nativeRecovery});
  const old=active,own=replayId,anchor=old.status.nextFrame;stopBuilder();stopPassive();silence();
  let rejectCancel;const cancellation=new Promise((_,reject)=>{rejectCancel=reject;});cancellation.catch(()=>{});
  const p={anchor,job:null,retirement:null,cancel:rejectCancel};preparation=p;
  const current=()=>!disposed&&preparation===p&&replayId===own&&active===old;
  async function work(){
   await old.client.pause();await stopPassive(old);await drainRetirements();if(!current())throw cancelled();
   const payload=stored;
   p.job=createNativeTakeoverPreparation(createWorker,payload,{engineHash:nativeTakeoverEngineHash,onProgress:value=>{if(current())onProgress(Object.freeze({...value,state:'preparing-native-takeover',cancelable:true}));}});
   const result=await p.job.result;await retirePreparation(p);if(!current())throw cancelled();
   if(result.kind==='unavailable'){meta=Object.freeze({...meta,nativeTakeover:Object.freeze({state:'unavailable',reason:result.reason})});return Object.freeze({kind:'unavailable',reason:result.reason});}
   need(result.kind==='qualified'&&result.profile==='efz402-native-recovered/1'&&result.engineHash===nativeTakeoverEngineHash,'native qualification identity');
   need(integer(result.frames,1,REPLAY_PAGE_LIMITS.frames)&&anchor<=result.frames,'native qualified extent');
   const descriptor=Object.freeze({profile:result.profile,seed:result.seed,recordingHash:result.recordingHash,engineHash:result.engineHash});
   const raw=result.projection,projection=Object.freeze({schema:raw.schema,counts:raw.counts.slice(),masks:raw.masks.slice(),auxCounts:raw.auxCounts.slice(),auxWords:raw.auxWords.slice()});
   const inputIndex=createNativeInputIndex({schema:'efz-native-inputs/1',counts:projection.counts,masks:projection.masks},result.frames);
   const nextStored={...stored,nativeFrames:result.frames,nativeTapeOffset:result.nativeTapeOffset,nativeRecovery:Object.freeze({...descriptor,projection})};
   const {analysis,nativeInputIndex,...priorMeta}=meta;
   const nextMeta=Object.freeze({...priorMeta,frames:result.frames,nativeTapeOffset:result.nativeTapeOffset,nativeInputIndex:inputIndex,nativeRecovery:descriptor,nativeTakeover:Object.freeze({state:'qualified'})});
   preparation=null;
   await seekOriginal(anchor,{recoveryTransition:{stored:nextStored,meta:nextMeta}});
   return Object.freeze({kind:'qualified',...descriptor});
  }
  try{publish();onProgress(Object.freeze({state:'preparing-native-takeover',phase:'discover',nextFrame:0,cancelable:true}));return await Promise.race([work(),cancellation]);}
  finally{if(preparation===p){preparation=null;publish();}void retirePreparation(p).catch(cleanupFailed);armPassive();scheduleBuilder();}
 }
 async function open(payload){
  need(!disposed,'controller disposed');branch=null;retireCheckpoints();cancelIndex();cancelSeek();silence();replayId++;revision++;const own=replayId;
  const previous=active;active=null;stored?.key?.fill?.(0);stored=null;meta=null;
  const retiring=destroy(previous);let owned=null,openAnalysis=null;const admission=admissionCaches.get(admissionCache),admissionEpoch=admission?.epoch;
  try{
   // Custody is synchronous: the caller can wipe its key immediately after open.
   need(payload&&payload.replayBytes instanceof Uint8Array,'replay bytes');
   const inspected=inspectPageReplay(payload.replayBytes,payload.winRounds);
   const bytes=Uint8Array.prototype.slice.call(payload.replayBytes),key=typeof payload.key==='string'?payload.key:payload.key?.slice();
   owned={replayBytes:bytes,key,encryptedManifest:validateEncryptedAssetManifest(payload.encryptedManifest),assetRoot:payload.assetRoot,winRounds:inspected.initialization.winRounds};
   if(Object.hasOwn(payload,'gameTranslation'))owned.gameTranslation=validateGameTranslation(payload.gameTranslation,owned.encryptedManifest);
   await retiring;await drainRetirements();
   if(disposed||own!==replayId)throw cancelled();
   stored=owned;meta=inspectPageReplay(bytes,owned.winRounds);if(meta.format==='native-tape')meta=Object.freeze({...meta,nativeTakeover:Object.freeze({state:'unprepared'})});
   if(checkpoints){
    const replayHash=await digest(bytes);if(disposed||own!==replayId)throw cancelled();
    const binding=JSON.stringify({open:own,replayHash,initialization:meta.initialization,engine:checkpointEngineHash,manifest:owned.encryptedManifest,translation:owned.gameTranslation??null});
    const identity=await digest(new TextEncoder().encode(binding));if(disposed||own!==replayId)throw cancelled();
    checkpointIdentity=identity;checkpointCache=createReplayCheckpointCache({identity,reservationBytes:16*1024*1024,maxInFlightBytes:32*1024*1024});
   }
   if(meta.format==='native-tape'){
    let admissionKey=null,result=null;
    if(admission){
     const replayHash=await digest(bytes);if(disposed||own!==replayId)throw cancelled();
     admissionKey=await digest(new TextEncoder().encode(JSON.stringify({replayHash,initialization:meta.initialization,engine:checkpointEngineHash,manifest:owned.encryptedManifest,translation:owned.gameTranslation??null,assetRoot:owned.assetRoot})));
     if(disposed||own!==replayId)throw cancelled();
     if(admission.epoch===admissionEpoch){result=admission.entries.get(admissionKey)??null;if(result){admission.entries.delete(admissionKey);admission.entries.set(admissionKey,result);}}
    }
    if(!result){
    const scanCache=checkpointCache;
    const checkpoint=scanCache?{identity:checkpointIdentity,interval:checkpointInterval,reserve:()=>checkpointActive&&!checkpointDisabled?scanCache.reserve():null,cancel:token=>scanCache.cancel(token),accept:(token,capture)=>scanCache.accept(token,capture,{provisional:true}),failed:error=>{if(!disposed&&own===replayId)disableCheckpoints(error);else scanCache.retire();}}:undefined;
    for(const inputHistory of [true,false]){
     const job=createNativeReplayIndex(createWorker('native-index'),owned,{checkpoint,inputHistory,onProgress:nextFrame=>{
      if(!disposed&&own===replayId)onProgress(Object.freeze({state:'indexing',nextFrame,cancelable:true}));
     }});indexing=job;
     try{result=await job.result;break;}
     catch(error){if(!inputHistory||error.nativeHistoryRequestRejected!==true||disposed||own!==replayId)throw error;}
     finally{if(indexing===job)indexing=null;}
    }
    if(disposed||own!==replayId)throw cancelled();
    scanCache?.admitProvisional();
    if(admission&&admission.epoch===admissionEpoch){const prior=admission.entries.get(admissionKey);if(prior)admission.bytes-=admissionWeight(prior);admission.entries.delete(admissionKey);admission.entries.set(admissionKey,result);admission.bytes+=admissionWeight(result);while(admission.entries.size>32||admission.bytes>admission.maxBytes){const first=admission.entries.keys().next().value;admission.bytes-=admissionWeight(admission.entries.get(first));admission.entries.delete(first);}}
    }
    openAnalysis=result.analysis??null;owned.nativeFrames=result.frames;owned.nativeTapeOffset=result.tapeOffset;meta=Object.freeze({...meta,frames:result.frames,nativeTapeOffset:result.tapeOffset,...result.inputIndex?{nativeInputIndex:result.inputIndex}:{}});
   }
   active=make(revision);const record=active;
   try{await record.client.init({...stored,...checkpointIdentity?{checkpointIdentity}:{}});if(disposed||record!==active)throw cancelled();record.presentation=Object.freeze({replayId:record.replayId,generation:record.generation,seekRevision:record.seekRevision,status:record.status,stats:emptyReplayStats(),training:emptyReplayTraining(),image:null});bindMusic();promoteAnalysis(record,openAnalysis);armPassive(record);return record.status;}
   catch(error){if(record===active){active=null;stored=null;meta=null;}await destroy(record);throw error;}
  }catch(error){owned?.key?.fill?.(0);if(own===replayId&&!active){retireCheckpoints();stored=null;meta=null;}await retiring;throw error;}
 }
 function bindMusic(){
  if(!active?.status||!audio.music?.prepareSeekCommit)return;
  const nextFrame=active.status.nextFrame,musicState=nextFrame===0?initialReplayMusicState():active.presentation?.result?.musicState;
  audio.music.prepareSeekCommit({replayId:active.replayId,generation:active.generation,seekRevision:active.seekRevision,nextFrame,musicState})();
 }
 function setAudio(owners={}){audio={sounds:owners.sounds??null,music:owners.music??null};bindMusic();}
 function play({beforeAdvance=null}={}){
  try{
   need(!disposed&&active&&active.status?.state==='paused'&&!candidate&&!preparation,'play requires paused replay');stopBuilder();armPassive();const own=active,serial=++intent;
   // Both browser resume calls run synchronously in the caller's click gesture.
   const sounds=audio.sounds?.play(),music=audio.music?.play();
   return Promise.all([sounds,music,drainRetirements(),beforeAdvance]).then(()=>{if(disposed||active!==own||serial!==intent||candidate||preparation)return status();return own.client.play();})
    .catch(error=>{if(active===own&&serial===intent)silence();throw error;});
  }catch(error){return Promise.reject(error);}
 }
 async function pause(){silence();if(candidate)candidate.resume=false;const own=active;if(!own||disposed)return status();await own.client.pause();scheduleBuilder();return status();}
 async function step(){need(!disposed&&active&&!candidate&&!preparation,'step unavailable');stopBuilder();armPassive();const own=active;silence();const serial=intent;await drainRetirements();if(disposed||active!==own||serial!==intent||candidate||preparation)return status();return own.client.step();}
 async function seekOriginal(targetNextUpdate,{resume=false,restartMusic=false,branchTransition=false,nextBranch=null,recoveryTransition=null}={}){
  need(!disposed&&active&&stored&&meta,'seek requires replay');const seekStored=recoveryTransition?.stored??stored,seekMeta=recoveryTransition?.meta??meta;need(integer(targetNextUpdate,0,meta.frames),'seek target');need(targetNextUpdate<=seekMeta.frames,'recovered target exceeds recording');need(typeof resume==='boolean'&&typeof restartMusic==='boolean','seek options');
  stopPassive();stopBuilder();cancelSeek();silence();const old=active,ownReplay=replayId,seekRevision=++revision;
  let rejectCancel;const cancellation=new Promise((_,reject)=>{rejectCancel=reject;});cancellation.catch(()=>{});
  const transaction={record:null,pin:null,reservation:null,branchTransition,nextBranch,cache:branchTransition||recoveryTransition||stored.nativeRecovery?null:checkpointCache,target:targetNextUpdate,resume,cancel:rejectCancel,timer:null,presentationAborted:false};candidate=transaction;
  const owns=()=>!disposed&&candidate===transaction&&replayId===ownReplay&&revision===seekRevision;
  const current=()=>owns()&&!transaction.presentationAborted;
  transaction.timer=setTimeout(()=>{if(!current())return;rejectCancel(Error('Replay seek deadline exceeded'));void destroy(transaction.record).catch(()=>{});},seekTimeoutMs);
  async function work(){
   await old.client.pause();await stopPassive(old);await drainRetirements();if(!current())throw cancelled();
   let record=make(seekRevision,seekStored);transaction.record=record;
   await record.client.init({...seekStored,...checkpointIdentity&&!nextBranch&&!seekStored.nativeRecovery?{checkpointIdentity,checkpointBuilder:true}:{}});if(!current())throw cancelled();
   transaction.reservation=transaction.cache?.reserve()??null;
   if(transaction.reservation)transaction.pin=transaction.cache.pin(targetNextUpdate);
   // A long paused seek also retains the preceding interval, so immediate
   // Previous does not depend on idle background warming. Reuse the existing
   // multi-leg checkpoint capability; neither intermediate commit paints UI.
   const preceding=Math.floor((targetNextUpdate-1)/checkpointInterval)*checkpointInterval;
   const firstTarget=transaction.reservation&&preceding>0&&targetNextUpdate-(transaction.pin?.capture?.nextUpdate??0)>checkpointInterval*2?preceding:targetNextUpdate;
   let ready;
   try{ready=await record.client.prepareSeek(firstTarget,transaction.pin?.capture??null);}
   catch(error){
    if(!current()||!transaction.pin?.capture||!String(error.message).startsWith('Checkpoint restore rejected:'))throw error;
    checkpointIssue=Object.freeze({phase:'restore',message:String(error?.message??error).slice(0,500)});onCheckpointError(checkpointIssue);
    transaction.cache.remove(transaction.pin.capture);transaction.pin.release();transaction.pin=null;
    await destroy(record);if(!current())throw cancelled();
    record=make(seekRevision,seekStored);transaction.record=record;await record.client.init({...seekStored,...checkpointIdentity&&!nextBranch&&!seekStored.nativeRecovery?{checkpointIdentity,checkpointBuilder:true}:{}});if(!current())throw cancelled();
    ready=await record.client.prepareSeek(firstTarget);
   }
   if(!current())throw cancelled();
   if(firstTarget!==targetNextUpdate){
    await record.client.commitSeek(firstTarget);if(!current())throw cancelled();
    try{const capture=await record.client.capture();if(!current())throw cancelled();transaction.cache.accept(transaction.reservation,capture);transaction.reservation=null;}
    catch(error){if(!current())throw error;transaction.cache.cancel(transaction.reservation);transaction.reservation=null;disableCheckpoints(error);}
    transaction.reservation=transaction.cache?.reserve()??null;
    ready=await record.client.prepareSeek(targetNextUpdate);if(!current())throw cancelled();
   }
   const stats=validateReplayStats(ready.stats,targetNextUpdate,meta.initialization);
   const training=validateReplayTraining(ready.training,targetNextUpdate,meta.initialization,ready.image);
   await old.client.whenPainted();if(!current())throw cancelled();
   const shown=Object.freeze({...ready,stats,training,isCurrent:current});
   await prepareCommit(shown);if(!current())throw cancelled();
   // Validate the worker's typed transition before modifying the display.
   await record.client.commitSeek(targetNextUpdate);if(!current())throw cancelled();
   if(nextBranch){await record.client.beginTakeover(nextBranch);if(!current())throw cancelled();}
   // Captures are legal only after the Worker releases its seek-ready barrier.
   if(transaction.reservation&&targetNextUpdate>0&&targetNextUpdate<meta.frames){
    try{const capture=await record.client.capture();if(!current())throw cancelled();transaction.cache.accept(transaction.reservation,capture);transaction.reservation=null;}
    catch(error){if(!current())throw error;transaction.cache.cancel(transaction.reservation);transaction.reservation=null;disableCheckpoints(error);}
   }
   const descriptor={replayId:record.replayId,generation:record.generation,seekRevision:record.seekRevision,nextFrame:targetNextUpdate};
   let commitAudio=()=>{};
   if(audio.sounds?.prepareSeekCommit)commitAudio=audio.sounds.prepareSeekCommit(descriptor);
   else audio.sounds?.commitSeek?.(descriptor);
   const commitMusic=audio.music?.prepareSeekCommit?.({...descriptor,musicState:targetNextUpdate===0?initialReplayMusicState():ready.result?.musicState,restartMusic})??(()=>{});
   // No await is allowed between the final visible write and promotion.
   try{
    const result=onCommit(shown);
    if(result&&typeof result.then==='function'){
     Promise.resolve(result).catch(()=>{});
     throw Error('Replay: onCommit must be synchronous; use prepareCommit');
    }
    if(!current())throw cancelled();
   }catch(error){
    transaction.presentationAborted=true;
    const retained=()=>!disposed&&replayId===ownReplay&&active===old;
    if(retained()){
     const restored=onCommit(Object.freeze({...old.presentation,status:old.status,isCurrent:retained}));
     if(restored&&typeof restored.then==='function')Promise.resolve(restored).catch(()=>{});
    }
    throw error;
   }
   commitMusic();commitAudio();
   record.presentation=shown;active=record;if(recoveryTransition){stored=seekStored;meta=seekMeta;retireCheckpoints();}if(branchTransition)branch=nextBranch;candidate=null;clearTimeout(transaction.timer);publish();promoteAnalysis(record,ready.result?.analysis);await destroy(old);armPassive(record);
   if(transaction.resume&&active.status.state==='paused')await play();return status();
  }
  try{return await Promise.race([work(),cancellation]);}
  catch(error){
   if(owns()){candidate=null;clearTimeout(transaction.timer);await destroy(transaction.record);publish();}
   throw error;
  }finally{clearTimeout(transaction.timer);if(transaction.record&&transaction.record!==active)void destroy(transaction.record).then(()=>releaseSeekOwnership(transaction),cleanupFailed);else releaseSeekOwnership(transaction);scheduleBuilder();}
 }
 function seek(target,options){need(!branch,'return to replay before seeking');return seekOriginal(target,options);}
 async function beginTakeover(side){
  need(meta?.format==='revival-pairs'||meta?.format==='native-tape'&&stored?.nativeRecovery,'takeover requires a Revival paired recording or successful native RNG qualification');
  need(side===0||side===1,'takeover side');
  need(!branch&&!candidate&&!preparation&&active?.status?.state==='paused','takeover requires paused original replay');
  const anchor=active.status.nextFrame;need(anchor<meta.frames,'takeover requires opponent inputs');
  const nextBranch=Object.freeze({branchId:++branchSequence,side,anchor});
  return seekOriginal(anchor,{branchTransition:true,nextBranch});
 }
 async function retryTakeover(){
  need(branch,'no takeover to retry');
  const nextBranch=Object.freeze({...branch,branchId:++branchSequence});
  return seekOriginal(branch.anchor,{branchTransition:true,nextBranch});
 }
 async function returnToReplay(){need(branch,'no takeover to return from');return seekOriginal(branch.anchor,{branchTransition:true});}
 function setTakeoverInput(mask){
  need(branch&&!candidate&&active&&!disposed,'takeover input unavailable');
  return active.client.setTakeoverInput({branchId:branch.branchId,mask});
 }
 async function dispose(){
  if(disposed)return;retireCheckpoints();cancelIndex();cancelSeek();disposed=true;intent++;silence();const old=active;active=null;replayId++;stored?.key?.fill?.(0);stored=null;meta=null;await destroy(old);await drainRetirements();
 }
 return Object.freeze({open,prepareNativeTakeover,setAudio,play,pause,step,seek,cancelSeek,dispose,status,beginTakeover,retryTakeover,returnToReplay,setTakeoverInput,setCheckpointActive,checkpointStatus:()=>Object.freeze({...checkpointCache?.inspect()??emptyCache,disabled:checkpointDisabled,issue:checkpointIssue}),metadata:()=>meta});
}
