export function createAudioCapture(context,output){
 if(typeof context?.createMediaStreamDestination!=='function')throw Error('Audio recording output unavailable');
 const destination=context.createMediaStreamDestination();let closed=false;
 try{output.connect(destination);}catch(error){destination.stream.getTracks().forEach(t=>t.stop());throw error;}
 return Object.freeze({stream:destination.stream,close(){if(closed)return;closed=true;try{output.disconnect(destination);}finally{destination.stream.getTracks().forEach(t=>t.stop());}}});
}
