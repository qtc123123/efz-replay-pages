import {createNativeInputBuilder,createNativeInputIndex} from './native-input-index.mjs';
import {createRoundAccumulator,validateRoundSummary} from './replay-rounds.mjs';
import {yieldReplayTask,inspectPageReplay,createPageReplayCatalog,bindCheckpointCatalog,validateCheckpointResult,REPLAY_PAGE_LIMITS as L} from './replay-session.mjs';
import {validateLocalTapeEnd} from '../local-replay-inspector.mjs';
import {validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {validateGameTranslation} from './game-translation.mjs';

const need=(ok,message)=>{if(!ok)throw Error('Native replay: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
function record(value,required,optional=[]){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain message required');
 const keys=Reflect.ownKeys(value);need(required.every(key=>keys.includes(key))&&keys.every(key=>required.includes(key)||optional.includes(key)),'message fields');
 const result={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'accessor refused');result[key]=d.value;}return result;
}
function ownPayload(value){
 const p=record(value,['replayBytes','encryptedManifest','assetRoot','key'],['winRounds','gameTranslation']);
 const meta=inspectPageReplay(p.replayBytes,p.winRounds);need(meta.format==='native-tape','native tape required');
 need(typeof p.assetRoot==='string'&&p.assetRoot.length<=4096,'asset root');
 const key=p.key;need(typeof key==='string'&&key.length<=256||key instanceof Uint8Array&&key.length===32&&Object.getPrototypeOf(key.buffer)===ArrayBuffer.prototype&&!key.buffer.resizable,'key extent');
 const owned={replayBytes:Uint8Array.prototype.slice.call(p.replayBytes),encryptedManifest:validateEncryptedAssetManifest(p.encryptedManifest),
  assetRoot:p.assetRoot,key:typeof key==='string'?key:Uint8Array.prototype.slice.call(key),winRounds:meta.initialization.winRounds};
 if(Object.hasOwn(p,'gameTranslation'))owned.gameTranslation=validateGameTranslation(p.gameTranslation,owned.encryptedManifest);
 return {meta,owned};
}

function validateCapture(capture,next){
 need(capture&&[Object.prototype,null].includes(Object.getPrototypeOf(capture)),'checkpoint record');
 const keys=Reflect.ownKeys(capture);need(keys.length<=64&&keys.every(k=>typeof k==='string'&&!['__proto__','constructor','prototype'].includes(k)),'checkpoint fields');
 for(const key of keys){const d=Object.getOwnPropertyDescriptor(capture,key);need(d&&'value'in d&&d.enumerable,'checkpoint accessor');}
 need(capture.nextUpdate===next,'checkpoint boundary');
 let size=0;
 for(const name of ['stateBytes','presentationBytes']){
  const bytes=capture[name];need(bytes instanceof Uint8Array&&Object.getPrototypeOf(bytes)===Uint8Array.prototype&&Object.getPrototypeOf(bytes.buffer)===ArrayBuffer.prototype&&!bytes.buffer.resizable&&bytes.byteOffset===0&&bytes.byteLength===bytes.buffer.byteLength&&bytes.byteLength>0,'checkpoint fixed bytes');size+=bytes.byteLength;
 }
 need(size<=3*1024*1024&&capture.stateBytes.buffer!==capture.presentationBytes.buffer,'checkpoint extent');
}

/** Every scan executes the same complete updates and stateful render calls as
 * playback. It never derives duration from the number of contextual words. */
export async function scanLocalTape(meta,engine,{clock=()=>performance.now(),yieldTask=yieldReplayTask,onProgress=()=>{},cancelled=()=>false,checkpoint=null,collectInputs=true,rasterAcceleration=true}={}){
 need(meta?.format==='native-tape'&&typeof engine?.advance==='function'&&typeof engine?.inspect==='function','scan dependencies');
 need(typeof rasterAcceleration==='boolean','raster acceleration');
 const fastRaster=rasterAcceleration&&typeof engine.advanceNativeIndex==='function'&&(!checkpoint||checkpoint.interval===128);
 const started=clock(),rounds=createRoundAccumulator({markers:true}),inputs=collectInputs&&typeof engine.nativeInputs==='function'?createNativeInputBuilder():null;let next=0,captureEnabled=checkpoint!==null;
 if(checkpoint)need(typeof checkpoint.identity==='string'&&/^[a-f0-9]{64}$/.test(checkpoint.identity)&&integer(checkpoint.interval,1,4096)&&typeof checkpoint.requestCredit==='function'&&typeof checkpoint.onCapture==='function'&&typeof checkpoint.failed==='function','checkpoint dependencies');
 const complete=(state,tapeOffset)=>{const analysis=rounds.complete(next,meta.initialization.winRounds,state);return Object.freeze({frames:next,tapeOffset,...analysis?{analysis}:{},...inputs?{inputIndex:inputs.finish()}:{}});};
 try{while(next<L.frames){
  const began=clock();let count=0;
  do{
   need(!cancelled(),'scan cancelled');need(Number.isFinite(clock())&&clock()-started<=L.seekMilliseconds,'scan deadline');
   const result=await (fastRaster?engine.advanceNativeIndex(next,{pixels:!!checkpoint&&(next+1)%checkpoint.interval===0}):engine.advance(next));
   need(result&&['advanced','end'].includes(result.kind)&&result.nextFrame===next+1,'complete update boundary');next++;count++;rounds.observe(result);if(inputs)inputs.append(engine.nativeInputs());
   if(result.kind==='end'){
    const final=engine.inspect();
    need(result.observation?.sceneId===8&&final.ended===true&&final.failed===false&&final.endTimer===200&&
     final.lastCharacters?.some(player=>player.wins===meta.initialization.winRounds),'natural match finish required');
    const tapeOffset=validateLocalTapeEnd(meta,final.tapeOffset);
    need(!cancelled(),'scan cancelled');return complete(final,tapeOffset);
   }
   need(result.observation?.sceneId===3,'unsupported battle scene');
   // A user may stop recording between complete updates without a KO. Never
   // probe a further update at exact EOF: the core's missing-word guard is for
   // partial updates, not a requirement to invent a natural match finish.
   const boundary=engine.inspect();
   if(boundary.tapeOffset===meta.nativeEnd){
    need(boundary.nextFrame===next&&boundary.failed===false&&boundary.ended===false,'invalid recording boundary');
    const tapeOffset=validateLocalTapeEnd(meta,boundary.tapeOffset);
    need(!cancelled(),'scan cancelled');return complete(boundary,tapeOffset);
   }
   // Reserve capacity before invoking the encoder. Capture-only failures do
   // not conceal an advance failure and retire all provisional acceleration.
   if(captureEnabled&&next%checkpoint.interval===0){
    try{
     const granted=await checkpoint.requestCredit(next);need(typeof granted==='boolean','checkpoint credit');
     need(!cancelled(),'scan cancelled');
     if(granted){
      need(typeof engine.captureBattle==='function','checkpoint capture unavailable');
      const capture=await engine.captureBattle();need(!cancelled(),'scan cancelled');
      validateCapture(capture,next);
      const resultData=validateCheckpointResult(result,meta.initialization);
      await checkpoint.onCapture({...capture,identity:checkpoint.identity,result:resultData,rounds:rounds.capture()},next);
     }
    }catch(error){captureEnabled=false;await checkpoint.failed(error,next);}
    need(!cancelled(),'scan cancelled');
   }
  }while(next<L.frames&&count<L.nativeScanBatchUpdates&&clock()-began<L.seekSliceMilliseconds);
  onProgress(next);await yieldTask();
 }
 throw Error('Native replay: recording capacity exceeded');}finally{inputs?.dispose();}
}

export function installNativeReplayIndexer(scope,{createNativeReplay,fetcher=globalThis.fetch,clock,yieldTask}={}){
 need(scope&&typeof scope.postMessage==='function'&&typeof createNativeReplay==='function','worker dependencies');
 let started=false,stopped=false,assets=null,engine=null,active=null,credit=null;
 const release=()=>{const old=engine,catalog=assets;engine=null;assets=null;try{old?.dispose();}finally{catalog?.dispose();}};
 async function run(raw){
  let output,owned;
  try{
   const request=record(raw,['type','replayBytes','encryptedManifest','assetRoot','key'],['winRounds','gameTranslation','checkpointIdentity','checkpointInterval','inputHistory']);
   need(request.type==='index-native','message type');delete request.type;
   const checkpointIdentity=request.checkpointIdentity,checkpointInterval=request.checkpointInterval,inputHistory=request.inputHistory;
   need(inputHistory===undefined||inputHistory===1,'input history version');delete request.inputHistory;
   delete request.checkpointIdentity;delete request.checkpointInterval;
   if(checkpointIdentity!==undefined)need(typeof checkpointIdentity==='string'&&/^[a-f0-9]{64}$/.test(checkpointIdentity)&&integer(checkpointInterval,1,4096),'checkpoint configuration');
   else need(checkpointInterval===undefined,'checkpoint identity required');
   const admission=ownPayload(request);owned=admission.owned;
   assets=createPageReplayCatalog(owned.encryptedManifest,admission.meta.initialization,owned.assetRoot,owned.key,fetcher,scope.location?.href,owned.gameTranslation);
   owned.key.fill?.(0);if(checkpointIdentity!==undefined)assets=await bindCheckpointCatalog(assets,owned.encryptedManifest,owned.gameTranslation);if(stopped)return;await assets.loadForSimulation();if(stopped)return;
   engine=await createNativeReplay(admission.meta.initialization,assets,admission.meta.nativeTape());if(stopped)return;
   const result=await scanLocalTape(admission.meta,engine,{clock,yieldTask,collectInputs:inputHistory===1,cancelled:()=>stopped,
    onProgress:nextFrame=>{if(!stopped)scope.postMessage({type:'native-index-progress',nextFrame});},
    checkpoint:checkpointIdentity===undefined?null:{identity:checkpointIdentity,interval:checkpointInterval,
     requestCredit:nextFrame=>new Promise(resolve=>{if(stopped){resolve(false);return;}credit={nextFrame,resolve};scope.postMessage({type:'native-checkpoint-credit',nextFrame});}),
     onCapture:(capture,nextFrame)=>{if(!stopped)scope.postMessage({type:'native-checkpoint',nextFrame,capture},[capture.stateBytes.buffer,capture.presentationBytes.buffer]);},
     failed:(_error,nextFrame)=>{if(!stopped)scope.postMessage({type:'native-checkpoint-failed',nextFrame});}
    }});
   output={type:'native-index',...result};
  }catch(error){output={type:'native-index-error',message:String(error?.message??error).slice(0,500)};}
  finally{owned?.key?.fill?.(0);try{release();}catch(error){output={type:'native-index-error',message:String(error?.message??error).slice(0,500)};}}
  if(!stopped&&output)scope.postMessage(output,output.inputIndex?[output.inputIndex.counts.buffer,output.inputIndex.masks.buffer]:[]);
 }
 scope.onmessage=({data})=>{
  if(stopped)return;
  if(started){
   if(!credit)return;const waiting=credit;credit=null;
   let granted=false;try{const p=record(data,['type','nextFrame','granted']);granted=p.type==='native-checkpoint-credit'&&p.nextFrame===waiting.nextFrame&&typeof p.granted==='boolean'&&p.granted;}catch{}
   waiting.resolve(granted);return;
  }
  started=true;active=run(data);
 };
 return Object.freeze({async dispose(){stopped=true;const waiting=credit;credit=null;waiting?.resolve(false);if(!engine)assets?.dispose();await active;release();}});
}

/** Own a disposable preparation Worker. It never transfers the controller's
 * retained replay/key buffers, and its result belongs only to this job. */
export function createNativeReplayIndex(worker,payload,{onProgress=()=>{},timeoutMs=180000,checkpoint=null,inputHistory=true}={}){
 let admission;
 try{need(worker&&typeof worker.postMessage==='function'&&integer(timeoutMs,1,600000)&&typeof inputHistory==='boolean','client dependencies');admission=ownPayload(payload);if(checkpoint)need(typeof checkpoint.identity==='string'&&/^[a-f0-9]{64}$/.test(checkpoint.identity)&&integer(checkpoint.interval,1,4096)&&['reserve','cancel','accept','failed'].every(k=>typeof checkpoint[k]==='function'),'checkpoint callbacks');}
 catch(error){worker?.terminate?.();throw error;}
 const {meta,owned}=admission;let finished=false,lastProgress=0,resolve,reject,reservation=null,creditFrame=null,lastCredit=0,captureEnabled=checkpoint!==null;
 const result=new Promise((a,b)=>{resolve=a;reject=b;});
 let timer,retirement=null;
 function clearCredit(){const token=reservation;reservation=null;creditFrame=null;if(token!==null)try{checkpoint.cancel(token);}catch{/* Optional cache hooks cannot prevent Worker retirement. */}}
 function captureFailed(error){clearCredit();captureEnabled=false;try{checkpoint?.failed(error);}catch{}}
 function finish(error,value){
  if(finished)return retirement;finished=true;clearTimeout(timer);worker.removeEventListener('message',receive);worker.removeEventListener('error',broken);
  let closing;try{closing=Promise.resolve(worker.terminate());}catch(cause){closing=Promise.reject(cause);}
  // A transferred key is detached; a failed post may leave the temporary view.
  if(owned.key instanceof Uint8Array&&owned.key.byteLength)owned.key.fill(0);
  retirement=closing.then(()=>{
   clearCredit();if(error)reject(error);else resolve(value);
  },cause=>{
   // Termination rejection does not establish quiescence. Keep any credit
   // charged; the controller must fence replacement and report this failure.
   const failed=Error('Native replay: Worker termination failed: '+String(cause?.message??cause));reject(failed);throw failed;
  });
  retirement.catch(()=>{});return retirement;
 }
 function receive({data}){
  if(finished)return;
  try{
   need(data&&typeof data.type==='string','message type');
   if(data.type==='native-checkpoint-credit'){
    const p=record(data,['type','nextFrame']);need(checkpoint&&integer(p.nextFrame,1,L.frames)&&p.nextFrame>lastCredit&&reservation===null,'checkpoint credit sequence');lastCredit=p.nextFrame;
    if(captureEnabled){try{reservation=checkpoint.reserve()??null;}catch(error){captureFailed(error);}}
    const granted=reservation!==null;if(granted)creditFrame=p.nextFrame;
    worker.postMessage({type:'native-checkpoint-credit',nextFrame:p.nextFrame,granted});return;
   }
   if(data.type==='native-checkpoint-failed'){
    const p=record(data,['type','nextFrame']);need(checkpoint&&p.nextFrame===lastCredit,'checkpoint failure boundary');captureFailed(Error('Native replay checkpoint capture unavailable'));return;
   }
   if(data.type==='native-checkpoint'){
    const p=record(data,['type','nextFrame','capture']);need(checkpoint&&reservation!==null&&p.nextFrame===creditFrame,'unsolicited checkpoint');
    try{
     validateCapture(p.capture,p.nextFrame);need(p.capture.identity===checkpoint.identity,'checkpoint identity');
     validateCheckpointResult(p.capture.result,meta.initialization);const rounds=createRoundAccumulator();rounds.restore(p.capture.rounds,p.nextFrame);
     const token=reservation;reservation=null;creditFrame=null;try{checkpoint.accept(token,p.capture);}finally{checkpoint.cancel(token);}
    }catch(error){captureFailed(error);}return;
   }
   if(data.type==='native-index-progress'){
    const p=record(data,['type','nextFrame']);need(integer(p.nextFrame,1,L.frames)&&p.nextFrame>=lastProgress,'progress extent');lastProgress=p.nextFrame;onProgress(p.nextFrame);return;
   }
   if(data.type==='native-index-error'){const p=record(data,['type','message']);need(typeof p.message==='string'&&p.message.length<=500,'error extent');const error=Error(p.message);if(inputHistory&&p.message==='Native replay: message fields'&&lastProgress===0&&lastCredit===0)error.nativeHistoryRequestRejected=true;throw error;}
   const p=record(data,['type','frames','tapeOffset'],['analysis','inputIndex']);need(p.type==='native-index'&&integer(p.frames,1,L.frames)&&p.frames>=lastProgress&&p.frames>lastCredit,'indexed extent');
   validateLocalTapeEnd(meta,p.tapeOffset);const analysis=Object.hasOwn(p,'analysis')?validateRoundSummary(p.analysis,{frames:p.frames,winRounds:meta.initialization.winRounds}):null;
   need(inputHistory||!Object.hasOwn(p,'inputIndex'),'unrequested input history');
   const inputIndex=Object.hasOwn(p,'inputIndex')?createNativeInputIndex(p.inputIndex,p.frames):null;
   finish(null,Object.freeze({frames:p.frames,tapeOffset:p.tapeOffset,...analysis?{analysis}:{},...inputIndex?{inputIndex}:{}}));
  }catch(error){finish(error);}
 }
 const broken=()=>finish(Error('Native replay: preparation Worker failed'));
 worker.addEventListener('message',receive);worker.addEventListener('error',broken);
 timer=setTimeout(()=>finish(Error('Native replay: preparation deadline exceeded')),timeoutMs);
 try{worker.postMessage({type:'index-native',...owned,...inputHistory?{inputHistory:1}:{},...checkpoint?{checkpointIdentity:checkpoint.identity,checkpointInterval:checkpoint.interval}:{}},[owned.replayBytes.buffer,...owned.key instanceof Uint8Array?[owned.key.buffer]:[]]);}
 catch(error){finish(error);}
 return Object.freeze({result,dispose:()=>finish(Error('Native replay scan cancelled'))});
}
