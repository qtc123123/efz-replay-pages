import {replayFilename} from './replay-filename.mjs';
import {DEFAULT_FILTERS,queryLibrary,playerOptions,formatReplaySize} from './replay-library-query.mjs';
import {validateRoundSummary} from './replay-rounds.mjs';
export {replayFilename} from './replay-filename.mjs';
export {DEFAULT_FILTERS,queryLibrary,playerOptions,formatReplaySize} from './replay-library-query.mjs';
export function replayDuration(frames){if(!Number.isSafeInteger(frames)||frames<1)return '-';const seconds=Math.floor(frames/64);return String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');}
// Keep the public legacy listing shape; enhanced callers use queryLibrary.
export function libraryListing(entries,path=[],options={}){const {matched,canReorder,...listing}=queryLibrary(entries,path,options);return listing;}
function completeAnalysis(entry){
 const analysis=entry.analysis;if(!analysis||analysis.sha256!==entry.sha256||typeof analysis.engineHash!=='string'||!/^[a-f0-9]{64}$/.test(analysis.engineHash))return null;
 const {sha256,engineHash,...summary}=analysis;
 try{return validateRoundSummary(summary,{frames:entry.frames});}catch{return null;}
}
export function createReplayLibraryView({document,library,onOpen,icon,preview=async()=>null,names,fullNames=names,translate=x=>x}={}){
 const $=id=>document.getElementById(id);let folder=[],query='',page=0,revision=0,disposed=false,timer=null,last=null,previewObserver=null,filters={...DEFAULT_FILTERS},sort='playlist',expanded=false;
 const make=(tag,text,className)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(className)n.className=className;return n;};
 const button=(label,action,className='quiet-button')=>{const b=make('button',label,className);b.type='button';b.addEventListener('click',action);return b;};
 function paint(canvas,picture){canvas.width=picture.width;canvas.height=picture.height;const ctx=canvas.getContext('2d'),data=ctx.createImageData(picture.width,picture.height);data.data.set(picture.data);ctx.putImageData(data,0,0);}
 const filterControls=[['p1Player','library-p1-player'],['p1Character','library-p1-character'],['p2Player','library-p2-player'],['p2Character','library-p2-character'],['stage','library-stage'],['format','library-format'],['rounds','library-rounds'],['duration','library-duration']];
 function options(id,values,selected){
  const control=$(id),signature=JSON.stringify(values);
  // Never replace the native select itself, or churn its option tree on a
  // normal result refresh. Keyboard focus and exact nickname text survive.
  if(control.libraryOptions!==signature){control.replaceChildren(...values.map(([value,label,title])=>{const option=make('option',label);option.value=String(value);if(title)option.title=title;return option;}));control.libraryOptions=signature;}
  control.value=selected===null?'':String(selected);control.title=values.find(([value])=>String(value)===control.value)?.[1]??'';
 }
 function refreshControls(entries){
  const players=playerOptions(entries,folder);
  for(const [key,id,side] of [['p1Player','library-p1-player','p1'],['p2Player','library-p2-player','p2']]){
   const values=[...players[side]];if(filters[key]!==null&&!values.includes(filters[key]))values.push(filters[key]);
   values.sort();options(id,[['',translate('Any player')],...values.map(name=>[name,name,name])],filters[key]);
  }
  const characters=Array.from({length:names.length},(_,id)=>{const name=fullNames[id]??String(id),duplicate=fullNames.filter?.(n=>n===name).length>1;return [id,name+(duplicate?' ['+id+']':''),translate('Recorded character ID {id}').replace('{id}',id)];});
  for(const [key,id] of [['p1Character','library-p1-character'],['p2Character','library-p2-character']])options(id,[['',translate('Any character')],...characters],filters[key]);
  options('library-stage',[['',translate('Any stage')],...Array.from({length:23},(_,id)=>[id,translate('Stage {stage}').replace('{stage}',String(id+1).padStart(2,'0')),translate('Recorded stage ID {stage}').replace('{stage}',id)])],filters.stage);
  options('library-format',[['',translate('Any format')],['Vanilla',translate('Vanilla')],['Revival',translate('Revival')]],filters.format);
  options('library-rounds',[['any','Any round count'],['0','0'],['1','1'],['2','2'],['3','3'],['4','4'],['ge5','5+'],['known','Known'],['unknown','Unknown']].map(([v,l])=>[v,translate(l)]),filters.rounds);
  options('library-duration',[['any','Any duration'],['lt1','Under 1 min'],['1to3','1–3 min'],['3to5','3–5 min'],['ge5','5+ min'],['known','Known'],['unknown','Unknown']].map(([v,l])=>[v,translate(l)]),filters.duration);
  options('library-sort',[['playlist','Playlist order'],['date-desc','Date · newest first'],['date-asc','Date · oldest first'],['duration-asc','Duration · shortest first'],['duration-desc','Duration · longest first'],['rounds-asc','Rounds · fewest first'],['rounds-desc','Rounds · most first'],['size-asc','File size · smallest first'],['size-desc','File size · largest first'],['name-asc','Filename · A–Z'],['name-desc','Filename · Z–A']].map(([v,l])=>[v,translate(l)]),sort);
  $('library-filter-toggle').setAttribute('aria-expanded',String(expanded));$('library-filter-panel').hidden=!expanded;
 }
 function reset({collapse=false}={}){filters={...DEFAULT_FILTERS};sort='playlist';page=0;if(collapse)expanded=false;render();}
 function navigate(path){folder=[...path];page=0;render();}
 function render(state=library.snapshot()){
  if(disposed)return;last=state;const focusKey=document.activeElement?.libraryFocusKey,focusNodes=new Map(),remember=(node,key)=>{node.libraryFocusKey=key;focusNodes.set(key,node);return node;};const own=++revision;previewObserver?.disconnect();previewObserver=null;const previewJobs=new WeakMap();
  if(typeof IntersectionObserver==='function')previewObserver=new IntersectionObserver(changes=>{for(const item of changes)if(item.isIntersecting){previewObserver?.unobserve(item.target);previewJobs.get(item.target)?.();previewJobs.delete(item.target);}},{rootMargin:'160px'});
  if(folder.length&&!state.entries.some(e=>folder.every((v,i)=>e.path[i]===v)))folder=[];
  refreshControls(state.entries);const listing=queryLibrary(state.entries,folder,{query,page,filters,sort});page=listing.page;
  const crumbs=[remember(button(translate('All recordings'),()=>navigate([]),'library-crumb'),'folder:[]')];
  folder.forEach((name,i)=>crumbs.push(remember(button(name,()=>navigate(folder.slice(0,i+1)),'library-crumb'),'folder:'+JSON.stringify(folder.slice(0,i+1)))));$('library-breadcrumbs').replaceChildren(...crumbs);
  const cards=[];
  for(const f of listing.folders){const b=remember(button('',()=>navigate(f.path),'library-folder'),'folder:'+JSON.stringify(f.path));b.appendChild(make('span','▱','folder-symbol'));const info=make('span');info.appendChild(make('strong',f.name));info.appendChild(make('small',translate('{count} recordings').replace('{count}',f.count)));b.appendChild(info);cards.push(b);}
  if(listing.folders.length&&listing.files.length)cards.push(make('div',undefined,'library-folder-break'));
  for(const e of listing.files){
   const card=make('article',undefined,'replay-card'+(e.id===state.selectedId?' selected':'')),open=remember(button('',()=>onOpen(e.id),'replay-card-open'),'open:'+e.id);open.disabled=!!e.error;open.setAttribute('aria-label',translate('Open')+' '+e.name);open.title=[...e.path,e.name].join(' / ');
   if(Number.isInteger(e.stage)){
    const background=make('canvas',undefined,'library-stage-preview');background.setAttribute('aria-hidden','true');card.appendChild(background);
    const show=()=>Promise.resolve().then(()=>preview(e.stage)).then(picture=>{if(!disposed&&own===revision&&picture){paint(background,picture);card.classList.add('has-stage-preview');}}).catch(()=>{});
    if(previewObserver){previewJobs.set(card,show);previewObserver.observe(card);}else if(cards.length<8)void show();
   }
   const pair=make('span',undefined,'library-fighters');
   e.characters.forEach((character,index)=>{const side=make('span',undefined,'library-fighter'),canvas=make('canvas',undefined,index===1?'library-portrait-p2':undefined);canvas.width=41;canvas.height=25;canvas.setAttribute('aria-label',fullNames[character]??String(character));side.title=fullNames[character]??String(character);side.appendChild(canvas);pair.appendChild(side);
    Promise.resolve().then(()=>icon(character)).then(picture=>{if(!disposed&&own===revision&&picture)paint(canvas,picture);}).catch(()=>{});
   });open.appendChild(pair);const filename=replayFilename(e.name);open.appendChild(make('strong',filename?filename.players.join(' vs '):e.name,'library-file-name'));
   if(filename?.recordedAt){const date=make('time',filename.recordedAt,'library-recorded-at');date.dateTime=filename.recordedAt.replace(' ','T');date.title=translate('Recorded time from filename; timezone unspecified');open.appendChild(date);} 
   const details=make('span',undefined,'library-card-meta');details.appendChild(make('span',replayDuration(e.frames),'library-duration'));if(e.format)details.appendChild(make('span',e.format,'format-badge'));if(filename?.sequence)details.appendChild(make('span','#'+filename.sequence,'library-sequence'));if(e.error)details.appendChild(make('span',e.error,'library-entry-error'));open.appendChild(details);
   const recording=make('span',undefined,'library-recording-meta'),analysis=completeAnalysis(e),rounds=make('span',translate('Rounds: {count}').replace('{count}',analysis?.roundsPlayed??'-'),'library-rounds');rounds.title=translate(analysis?'Rounds that began, including an unfinished final round.':'Round count is unknown until complete analysis with these settings.');recording.appendChild(rounds);
   const size=make('span',formatReplaySize(e.size),'library-file-size');size.title=Number.isSafeInteger(e.size)&&e.size>=0?translate('{bytes} bytes').replace('{bytes}',e.size.toLocaleString(document.documentElement?.lang==='ja'?'ja-JP':'en-US')):translate('File size unknown');recording.appendChild(size);open.appendChild(recording);
   if(analysis?.matchStatus==='interrupted'&&e.interrupted===true){const tag=make('span',translate('Interrupted'),'library-interrupted');tag.title=translate('The recording ends before a match winner under the selected win target.');open.appendChild(tag);}card.appendChild(open);
   if(!listing.canReorder&&e.path.length)card.appendChild(make('small',e.path.join(' / '),'library-provenance'));
   const actions=make('div',undefined,'library-card-actions');
   if(listing.canReorder)for(const [label,delta] of [['↑',-1],['↓',1]]){const b=remember(button(label,()=>library.move(e.id,delta)),'move:'+delta+':'+e.id);b.setAttribute('aria-label',translate(delta<0?'Move earlier':'Move later')+' '+e.name);actions.appendChild(b);}
   const remove=remember(button('×',()=>library.remove(e.id)),'remove:'+e.id);remove.setAttribute('aria-label',translate('Remove')+' '+e.name);actions.appendChild(remove);card.appendChild(actions);cards.push(card);
  }
  if(!cards.length){const empty=make('div',undefined,'library-empty');empty.appendChild(make('p',translate(state.entries.length?'No matching recordings':'Add recordings, a folder or an archive to begin.')));if(state.entries.length){const clear=remember(button(translate('Reset filters'),()=>reset()),'empty-reset');clear.title=translate('Resets filters and sort; keeps search text.');empty.appendChild(clear);}cards.push(empty);}
  $('library-grid').replaceChildren(...cards);
  $('library-summary').textContent=translate('{matched} / {count} recordings').replace('{matched}',listing.matched).replace('{count}',state.entries.length);
  $('library-import-status').textContent=state.importing?translate('Reading archive…')+' '+(state.progress?.path??''):'';
  $('library-cancel').hidden=!state.importing;$('library-clear').disabled=!state.entries.length&&!state.importing;
  $('library-errors').hidden=!state.errors.length;$('library-error-list').replaceChildren(...state.errors.map(e=>make('li',(e.path?e.path+': ':'')+e.message)));
  $('library-page').textContent=(page+1)+' / '+listing.totalPages;$('library-page-prev').disabled=page===0;$('library-page-next').disabled=page>=listing.totalPages-1;
  $('library-pagination').hidden=listing.totalPages===1;
  if(focusKey)(focusNodes.get(focusKey)??$('library-filter-toggle')).focus?.({preventScroll:true});
 }
 function schedule(state){last=state;if(timer===null)timer=setTimeout(()=>{timer=null;render(last);},40);}
 // CSS changes the panel's row; move the same tools node at the breakpoint
 // so native Tab order follows the visible search-before-filters mobile layout.
 const layoutQuery=document.defaultView?.matchMedia?.('(max-width:600px)');
 function layoutControls(){const root=$('library-controls'),tools=$('library-tools');if(!root?.insertBefore||!tools)return;const focus=document.activeElement;root.insertBefore(tools,layoutQuery.matches?$('library-filter-toggle'):null);if(root.contains?.(focus))focus?.focus?.({preventScroll:true});}
 if(layoutQuery){layoutControls();layoutQuery.addEventListener('change',layoutControls);}
 $('library-filter-toggle').addEventListener('click',()=>{expanded=!expanded;refreshControls(library.snapshot().entries);});
 $('library-filter-reset').addEventListener('click',()=>reset());
 for(const [key,id] of filterControls)$(id).addEventListener('change',()=>{const value=$(id).value;filters[key]=['p1Character','p2Character','stage'].includes(key)?value===''?null:Number(value):['rounds','duration'].includes(key)?value:value===''?null:value;page=0;render();});
 $('library-sort').addEventListener('change',()=>{sort=$('library-sort').value;page=0;render();});
 $('library-search').addEventListener('input',()=>{query=$('library-search').value;page=0;render();});
 $('library-page-prev').addEventListener('click',()=>{page--;render();});$('library-page-next').addEventListener('click',()=>{page++;render();});
 $('library-cancel').addEventListener('click',()=>library.cancel());render();
 return Object.freeze({render,schedule,reset,dispose(){disposed=true;revision++;layoutQuery?.removeEventListener('change',layoutControls);previewObserver?.disconnect();clearTimeout(timer);}});
}
