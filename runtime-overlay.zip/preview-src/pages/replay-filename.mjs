// Filename metadata is a display hint, never gameplay/admission authority.
// Observed JP corpus: YYYYMMDD-HHMM nickname (Character) vs nickname (Character).
const FILENAME_CHARACTERS=new Set(['Akane','Akiko','Ayu','Doppel','Doppel Nanase','EX Nanase','ExNanase','Ikumi','Kanna','Kano','Kaori','Mai','Makoto','Mayu','Minagi','Mio','Misaki','Mishio','Misuzu','Nagamori','Mizuka','NayukiA','NayukiS','Nayuki','NayukiB','Rumi','Nanase','Sayuri','Shiori','Unknown','UNKNOWN','mizukaB']);
export function replayFilename(name){
 if(typeof name!=='string'||name.length>512||!name.toLowerCase().endsWith('.rep'))return null;
 const stem=name.slice(0,-4),match=/^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})? (.+) \(([^()]*)\) vs (.+) \(([^()]*)\)$/.exec(stem);
 if(match){
  const [,year,month,day,hour,minute,second,p1,c1,p2,c2]=match,values=[+year,+month,+day,+hour,+minute,+(second??0)],date=new Date(Date.UTC(values[0],values[1]-1,values[2],values[3],values[4],values[5]));
  if(values[0]<1900||date.getUTCFullYear()!==values[0]||date.getUTCMonth()+1!==values[1]||date.getUTCDate()!==values[2]||date.getUTCHours()!==values[3]||date.getUTCMinutes()!==values[4]||date.getUTCSeconds()!==values[5]||!FILENAME_CHARACTERS.has(c1)||!FILENAME_CHARACTERS.has(c2)||!p1.trim()||!p2.trim())return null;
  return {players:[p1,p2],recordedAt:year+'-'+month+'-'+day+' '+hour+':'+minute+(second?':'+second:''),sequence:null};
 }
 // Do not reinterpret an unfamiliar/invalid date prefix as a player nickname.
 if(/^\d{4}/.test(stem))return null;
 const parts=stem.split(' vs ');if(parts.length!==2||!parts.every(x=>x.trim()))return null;
 const numbered=/^(.*) \((\d{1,4})\)$/.exec(parts[1]);
 return {players:[parts[0],numbered?numbered[1]:parts[1]],recordedAt:null,sequence:numbered?.[2]??null};
}
