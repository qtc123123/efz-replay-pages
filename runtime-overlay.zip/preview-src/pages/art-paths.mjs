import {CHARACTER_RESOURCE_NAMES} from '../asset-selection.mjs';

export const INTERFACE_ART_PATHS=Object.freeze(['system/title.dat','system/title_ob.dat','system/replay_bg.dat',
 'system/replay.dat','system/chr_sel_bg.dat','system/chr_sel_ob.dat','system/object.dat'].sort());
export const PORTRAIT_ART_PATHS=Object.freeze([...new Set(CHARACTER_RESOURCE_NAMES)].map(name=>'system/'+name+'/'+name+'.dat').sort());
export const GAME_ART_PATHS=Object.freeze([...INTERFACE_ART_PATHS,...PORTRAIT_ART_PATHS].sort());
export const isGameArtPath=path=>GAME_ART_PATHS.includes(path);
export function portraitArtPath(character){
 if(!Number.isInteger(character)||character<0||character>=CHARACTER_RESOURCE_NAMES.length)throw Error('Art: character outside supported range');
 const name=CHARACTER_RESOURCE_NAMES[character];return 'system/'+name+'/'+name+'.dat';
}

// Pinned t6 selection grid: three columns, eight staggered rows. These are
// authored icon pixels, not resized full-body portraits. ID24 has no grid cell.
const SELECTION_IDS=Object.freeze([6,0,4,7,5,11,1,10,3,8,2,9,23,20,21,14,12,18,17,15,13,16,-1,19]);
export function selectionIconCrop(character){
 if(!Number.isInteger(character)||character<0||character>24)throw Error('Art: unsupported selection character');
 const cell=SELECTION_IDS.indexOf(character===22?10:character);if(cell<0)return null;
 const row=Math.floor(cell/3);return {x:1+40*(cell%3)+(row%2===0?6:0),y:10+26*row,width:41,height:25};
}
