import {EncryptedAssetCatalog,validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {normalPath} from '../assets.mjs';

const need=(ok,message)=>{if(!ok)throw Error('Game translation: '+message);};
export const GAME_TRANSLATION_PATHS=Object.freeze(['akiko/akiko.dat','kano/kano.dat','minagi/minagi.dat',
 'mio/mio.dat','misuzu/misuzu.dat','system/chr_sel_ob.dat','system/replay.dat']);

/** Presentation files only. Patterns, palettes, resource existence and game
 * parameters remain those of the original authenticated deployment. */
export function validateGameTranslationManifest(value){
 const manifest=validateEncryptedAssetManifest(value);
 need(manifest.files.length>0&&manifest.files.length<=GAME_TRANSLATION_PATHS.length,'graphic inventory');
 need(manifest.files.every(entry=>GAME_TRANSLATION_PATHS.includes(entry.path)&&entry.object&&entry.bytes<=8*1024*1024),'unsupported graphic replacement');
 need(manifest.files.reduce((sum,entry)=>sum+entry.bytes,0)<=32*1024*1024,'graphic capacity');
 return manifest;
}
export function validateGameTranslation(value,baseManifest){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'descriptor');
 const keys=Reflect.ownKeys(value);need(keys.length===2&&keys.includes('manifest')&&keys.includes('assetRoot'),'descriptor fields');
 const fields={};for(const key of keys){const field=Object.getOwnPropertyDescriptor(value,key);need(field&&field.enumerable&&'value'in field,'descriptor accessor');fields[key]=field.value;}
 const manifest=validateGameTranslationManifest(fields.manifest),assetRoot=fields.assetRoot;
 need(typeof assetRoot==='string'&&assetRoot.length<=4096,'asset root');let root;
 try{root=new URL(assetRoot);}catch{throw Error('Game translation: asset root');}
 need(['https:','http:'].includes(root.protocol)&&root.pathname.endsWith('/')&&!root.username&&!root.password&&!root.search&&!root.hash,'asset root');
 if(baseManifest){const original=new Set(validateEncryptedAssetManifest(baseManifest).files.map(entry=>entry.path));
  need(manifest.files.every(entry=>original.has(entry.path)),'replacement has no original graphic');}
 return Object.freeze({manifest,assetRoot:root.href});
}

function header(bytes){
 need(bytes instanceof Uint8Array&&bytes.length>=5&&bytes.length<=8*1024*1024,'DAT byte extent');
 const offset=1+3*bytes[0];need(bytes[0]>0&&offset+4<=bytes.length,'DAT palette/header');return offset;
}
function sameBytes(a,b,start,end,message){for(let i=start;i<end;i++)need(a[i]===b[i],message);}
function geometry(bytes,offset){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),frames=[];let pos=offset,total=0,firstKey=null;
 // Character DATs use the pinned core's threshold-0x80 RLE. Count source
 // bytes without allocating sprites; repeat counts cross rows and any repeat
 // remainder at an image boundary is discarded by the original decoder.
 while(pos<bytes.length){
  need(pos+4<=bytes.length&&frames.length<4096,'DAT image header/count');
  const width=view.getUint16(pos,true),height=view.getUint16(pos+2,true),pixels=width*height;pos+=4;
  need(width<=4096&&height<=4096&&pixels<=4*1024*1024,'DAT image dimensions');total+=pixels;need(total<=64*1024*1024,'DAT decoded capacity');
  let produced=0;
  while(produced<pixels){need(pos<bytes.length,'truncated DAT image');const value=bytes[pos++];
   if(firstKey===null&&frames.length===0)firstKey=value<=128?value:0;
   produced+=value<=128?1:value-128;
  }
  frames.push(width,height);
 }
 need(frames.length>0,'empty DAT sequence');return {frames,firstKey};
}

/** A file-swap translation can change pixels and RLE length, but cannot change
 * palette inputs, sprite count/dimensions or the shared transparency key. */
export function validateGameTranslationBytes(path,original,translated){
 need(GAME_TRANSLATION_PATHS.includes(path),'unsupported graphic replacement');
 const offset=header(original);need(header(translated)===offset,'DAT palette count');
 sameBytes(original,translated,0,offset,'DAT palette differs');
 if(path.startsWith('system/')){
  need(original.length===translated.length,'atlas extent differs');
  sameBytes(original,translated,offset,offset+4,'atlas dimensions differ');
  const view=new DataView(original.buffer,original.byteOffset,original.byteLength),width=view.getUint16(offset,true),height=view.getUint16(offset+2,true);
  const end=offset+4+width*height;need(width>0&&height>0&&width<=4096&&height<=4096&&width*height<=4*1024*1024&&end<=original.length,'atlas dimensions');
  sameBytes(original,translated,end,original.length,'atlas trailing bytes differ');
 }else{
  const a=geometry(original,offset),b=geometry(translated,offset);
  need(a.firstKey===b.firstKey,'DAT first-sprite color key differs');need(a.frames.length===b.frames.length&&a.frames.every((value,index)=>value===b.frames[index]),'DAT image dimensions/count differ');
 }
}

/** Selected resources only; existence and ordering are delegated to the base.
 * Original bytes are retained for validation and unchanged resources. The two
 * authenticated catalogs keep separate roots, keys and cancellation owners. */
export function createGameTranslationCatalog(base,raw,{key,fetcher=globalThis.fetch}){
 const descriptor=validateGameTranslation(raw),files=descriptor.manifest.files.filter(entry=>base.has(entry.path));
 const replacement=new EncryptedAssetCatalog({...descriptor.manifest,files},descriptor.assetRoot,{key,fetcher});
 const selected=new Set(files.map(entry=>entry.path)),validated=new Set(),pending=new Map();let disposed=false;
 const check=()=>need(!disposed,'catalog disposed');
 function dispose(){if(disposed)return;disposed=true;validated.clear();pending.clear();replacement.dispose();base.dispose();}
 function load(path){
  try{
   check();const name=normalPath(path);if(!selected.has(name))return base.load(name);
   if(validated.has(name))return Promise.resolve();if(pending.has(name))return pending.get(name);
   const work=(async()=>{
    await Promise.all([base.load(name),replacement.load(name)]);check();
    const original=base.bytes(name),translated=replacement.bytes(name);
    try{validateGameTranslationBytes(name,original,translated);check();validated.add(name);}finally{original.fill(0);translated.fill(0);}
   })().catch(error=>{dispose();throw error;}).finally(()=>pending.delete(name));pending.set(name,work);return work;
  }catch(error){return Promise.reject(error);}
 }
 async function loadPaths(paths){let next=0;try{check();await Promise.all(Array.from({length:Math.min(4,paths.length)},async()=>{while(next<paths.length)await load(paths[next++]);}));}catch(error){dispose();throw error;}}
 return Object.freeze({has:path=>base.has(path),paths:()=>base.paths(),
  isLoaded:path=>{const name=normalPath(path);return selected.has(name)?validated.has(name):base.isLoaded(name);},
  bytes:path=>{check();const name=normalPath(path);if(!selected.has(name))return base.bytes(name);need(validated.has(name),'graphic not loaded');return replacement.bytes(name);},
  load,loadForSimulation:()=>loadPaths(base.paths().filter(path=>!path.endsWith('.wav'))),loadAll:()=>loadPaths(base.paths()),dispose});
}
