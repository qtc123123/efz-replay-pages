import {decodeIndexedGameDat,indexedToRgba} from './indexed-art.mjs';

/** Decode the first bounded raw interface image. Indices and original key are
 * retained until the final presentation boundary; battle decoding is separate.
 * Authored trailing data is identified but never interpreted as animation. */
export function decodeGameDat(bytes,options){
 return indexedToRgba(decodeIndexedGameDat(bytes),options);
}
