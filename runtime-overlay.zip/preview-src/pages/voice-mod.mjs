import {validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {CHARACTER_RESOURCE_NAMES} from '../asset-selection.mjs';

/** Optional character audio. This index never changes game resource existence. */
export function validateVoiceModManifest(value){
 const manifest=validateEncryptedAssetManifest(value);
 if(manifest.schema!=='miracle-encrypted-assets/2'||manifest.files.length<1||manifest.files.length>512||
  manifest.files.reduce((n,e)=>n+e.bytes,0)>64*1024*1024||
  !manifest.files.every(e=>e.object&&/^[a-z]+\/wave\/[0-9]{2}\.wav$/.test(e.path)&&CHARACTER_RESOURCE_NAMES.includes(e.path.split('/')[0])))
  throw Error('Voice mod: encrypted character sound replacements required');
 return manifest;
}
