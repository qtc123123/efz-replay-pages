const valid=n=>Number.isSafeInteger(n)&&n>=1&&n<=1000000;
const need=(ok,message)=>{if(!ok)throw Error(message);};
export function createReplayStudy(frames){
 need(valid(frames),'Replay extent unavailable');let a=null,b=null,looping=false,last=0,phase=null;const starts=new Set();
 const boundary=n=>{need(valid(n)&&n<=frames,'Invalid replay boundary');return n;};
 function range(){return a!==null&&b!==null?Object.freeze({in:a,out:b}):null;}
 return Object.freeze({
  jump:(at,delta)=>{boundary(at);need(Number.isSafeInteger(delta),'Invalid jump');return Math.max(1,Math.min(frames,at+delta));},
  mark:(which,at)=>{boundary(at);need(which==='in'||which==='out','Invalid clip point');need(which==='in'?b===null||at<b:a===null||at>a,'Clip out must follow clip in');if(which==='in')a=at;else b=at;},
  points:()=>Object.freeze({in:a,out:b}),range,
  exportRange:()=>Object.freeze({in:a??1,out:b??frames}),
  clear:()=>{a=b=null;looping=false;},
  loop:value=>{need(typeof value==='boolean','Invalid loop setting');need(!value||range()!==null,'Set both clip points first');looping=value;},
  isLooping:()=>looping,loopTarget:at=>looping&&at>=b?a:null,
  observe:(at,events)=>{boundary(at);if(!Array.isArray(events)||events.length>64)return;if(at!==last+1)phase=null;
   for(const event of events){if(!event||!['loading','intro','round-transition','round-ko','combat','finish','cleanup'].includes(event.phase)){phase=null;continue;}if(event.phase==='combat'&&phase!==null&&phase!=='combat')starts.add(at);phase=event.phase;}last=at;},
  setMarkers:values=>{need(Array.isArray(values)&&values.length<=256,'Invalid round markers');let prev=0;for(const at of values){boundary(at);need(at>prev,'Invalid round marker order');prev=at;}for(const at of values)starts.add(at);},
  markers:()=>[...starts].sort((x,y)=>x-y),
  round:(at,direction)=>{boundary(at);need(direction===1||direction===-1,'Invalid round direction');const sorted=[...starts].sort((x,y)=>x-y);return direction===1?sorted.find(n=>n>at)??null:sorted.reverse().find(n=>n<at)??null;}
 });
}
export function integerScale(width,height,mode){
 need(Number.isFinite(width)&&width>0&&Number.isFinite(height)&&height>0,'Invalid display bounds');
 need(['auto','fit','1','2','3','4'].includes(mode),'Invalid picture scale');if(mode==='fit')return null;
 const fit=Math.min(width,height*4/3),available=Math.floor(fit/320),multiple=mode==='auto'?available:Math.min(available,Number(mode));
 return Math.min(fit,Math.max(1,multiple)*320);
}
