import {EncryptedAssetCatalog,validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {decodeGameDat} from './game-art.mjs';
import {decodeIndexedGameDat,indexedToRgba} from './indexed-art.mjs';
import {renderTitleReplay,renderReplayPanel,renderControlRow,renderFighterPanel,renderGameChrome} from './menu-scene.mjs';
import {isGameArtPath,portraitArtPath,selectionIconCrop} from './art-paths.mjs';
import {validateGameTranslation,createGameTranslationCatalog} from './game-translation.mjs';

// t6.render uses the original 41×25 disabled-cell silhouette at (138,96).
// Its transparency excludes adjacent staggered cells inside the bounding box.
export function renderSelectionIcon(image,character){
 const crop=selectionIconCrop(character);if(!crop)return null;
 const picture=indexedToRgba(image,{transparent:'top-left',crop});
 const mask=indexedToRgba(image,{transparent:'top-left',crop:{x:138,y:96,width:41,height:25}});
 for(let at=0;at<picture.data.length;at+=4)if(mask.data[at+3]===0)picture.data.fill(0,at,at+4);
 return picture;
}

/** Interface media belongs to the page, never to the simulation's catalog.
 * The catalog owns the copied key; decoded RGBA is returned only while live. */
export function createReplayArt({manifest,assetRoot,key,fetcher=globalThis.fetch,gameTranslation}){
 const full=validateEncryptedAssetManifest(manifest);
 const translation=gameTranslation===undefined?null:validateGameTranslation(gameTranslation,full);
 const base=new EncryptedAssetCatalog({...full,files:full.files.filter(entry=>isGameArtPath(entry.path))},assetRoot,{key,fetcher});
 const catalog=translation?createGameTranslationCatalog(base,translation,{key,fetcher}):base;
 const stageCatalog=new EncryptedAssetCatalog({...full,files:full.files.filter(entry=>/^system\/bg\/bg(?:0[0-9]|1[0-9]|2[0-2])\.dat$/.test(entry.path))},assetRoot,{key,fetcher});
 let disposed=false;const scenes=new Map(),stagePreviews=new Map();
 async function load(path,options){
  if(disposed)throw Error('Art: owner disposed');
  if(!isGameArtPath(path))throw Error('Art: unsupported interface art path');
  await catalog.load(path);if(disposed)throw Error('Art: owner disposed');
  const bytes=catalog.bytes(path);
  try{return decodeGameDat(bytes,options);}finally{bytes.fill(0);}
 }
 async function portrait(character,color){
  if(!Number.isInteger(color)||color<0||color>5)throw Error('Art: unsupported portrait palette');
  return load(portraitArtPath(character),{paletteOffset:color*40,transparent:'top-left'});
 }
 // Only explicitly requested bounded allowlist resources become indexed data.
 // No portrait is fetched until portrait() is explicitly called after replay
 // admission. A failed pending load is removable; disposal fences late work.
 function indexed(path){
  if(disposed)return Promise.reject(Error('Art: owner disposed'));
  if(!scenes.has(path)){
   const pending=(async()=>{await catalog.load(path);if(disposed)throw Error('Art: owner disposed');const bytes=catalog.bytes(path);
    try{return decodeIndexedGameDat(bytes);}finally{bytes.fill(0);}
   })();scenes.set(path,pending);pending.catch(()=>{if(scenes.get(path)===pending)scenes.delete(path);});
  }
  return scenes.get(path);
 }
 async function titleReplay(options){
  const [background,objects]=await Promise.all([indexed('system/title.dat'),indexed('system/title_ob.dat')]);
  if(disposed)throw Error('Art: owner disposed');return renderTitleReplay(background,objects,options);
 }
 async function replayPanel(options){
  const [background,objects]=await Promise.all([indexed('system/replay_bg.dat'),indexed('system/replay.dat')]);
  if(disposed)throw Error('Art: owner disposed');return renderReplayPanel(background,objects,options);
 }
 async function controlRow(options){const objects=await indexed('system/title_ob.dat');if(disposed)throw Error('Art: owner disposed');return renderControlRow(objects,options);}
 async function fighterPanel(character,color,side,options={}){
  if(!Number.isInteger(color)||color<0||color>5)throw Error('Art: unsupported portrait palette');
  const [background,objects,portrait]=await Promise.all([indexed('system/chr_sel_bg.dat'),indexed('system/chr_sel_ob.dat'),indexed(portraitArtPath(character))]);
  if(disposed)throw Error('Art: owner disposed');return renderFighterPanel(background,objects,portrait,{...options,character,color,side});
 }
 async function selectionIcon(character){
  const crop=selectionIconCrop(character);if(!crop)return portrait(character,0);
  const image=await indexed('system/chr_sel_ob.dat');if(disposed)throw Error('Art: owner disposed');
  return renderSelectionIcon(image,character);
 }
 function stagePreview(stage){
  if(disposed)return Promise.reject(Error('Art: owner disposed'));
  if(!Number.isInteger(stage)||stage<0||stage>22)return Promise.reject(Error('Art: unsupported stage'));
  if(!stagePreviews.has(stage)){
   const pending=(async()=>{const path='system/bg/bg'+String(stage).padStart(2,'0')+'.dat';await stageCatalog.load(path);if(disposed)throw Error('Art: owner disposed');
    const bytes=stageCatalog.bytes(path);let original;
    try{original=decodeGameDat(bytes);const ratio=Math.min(1,160/original.width,120/original.height),width=Math.max(1,Math.floor(original.width*ratio)),height=Math.max(1,Math.floor(original.height*ratio)),data=new Uint8ClampedArray(width*height*4);
     for(let y=0;y<height;y++)for(let x=0;x<width;x++){const source=(Math.floor(y/ratio)*original.width+Math.floor(x/ratio))*4;data.set(original.data.subarray(source,source+4),(y*width+x)*4);}
     if(disposed)throw Error('Art: owner disposed');return {width,height,data};
    }finally{bytes.fill(0);original?.data.fill(0);}
   })();stagePreviews.set(stage,pending);pending.catch(()=>{if(stagePreviews.get(stage)===pending)stagePreviews.delete(stage);});
  }
  return stagePreviews.get(stage);
 }
 async function chrome(){
  const images=await Promise.all(['system/chr_sel_bg.dat','system/chr_sel_ob.dat','system/title.dat','system/object.dat'].map(indexed));
  if(disposed)throw Error('Art: owner disposed');return renderGameChrome(...images);
 }
 function dispose(){if(disposed)return;disposed=true;scenes.clear();stagePreviews.clear();stageCatalog.dispose();catalog.dispose();}
 return Object.freeze({load,portrait,titleReplay,replayPanel,controlRow,fighterPanel,selectionIcon,stagePreview,chrome,dispose});
}
