/** Recorded controls, not the core's pressed edges/command history. The pinned
 * rr.readInput maps 1/2/4/8 to world right/left/down/up and 16..128 to held
 * A..D. History is a cursor-relative window of immutable admitted replay pairs;
 * it never polls the simulation or accumulates events during playback. */
const need=(ok,message)=>{if(!ok)throw Error('Recorded inputs: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
// Same bounded local command vocabulary as validateLocalReplayPair: do not
// discard high bytes or admit other auxiliary bits just for presentation.
const inputWord=word=>need(integer(word,0,0x23ff)&&!(word&~0x23ff),'input word');
const directionBits=Object.freeze([[8,'up','↑'],[4,'down','↓'],[2,'left','←'],[1,'right','→']]);
const diagonals=Object.freeze({9:'↗',10:'↖',5:'↘',6:'↙'});
export function decodeRecordedInput(word){
 inputWord(word);
 const directions=directionBits.filter(([bit])=>word&bit),buttons=['A','B','C','D'].filter((_,i)=>word&(16<<i));
 const commands=[[0x100,'F4'],[0x200,'F5'],[0x2000,'Escape']].filter(([bit])=>word&bit).map(([,label])=>label);
 const arrow=diagonals[word&15]??directions.map(([, ,glyph])=>glyph).join('');
 return Object.freeze({word,directions:Object.freeze(directions.map(([,name])=>name)),buttons:Object.freeze(buttons),label:[arrow,...buttons,...commands].filter(Boolean).join(' ')||'·'});
}
export function formatReplayTime(nextUpdate){
 need(integer(nextUpdate,0,1000000),'time boundary');const ms=Math.floor(nextUpdate*1000/64),seconds=Math.floor(ms/1000);
 return String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0')+'.'+String(ms%1000).padStart(3,'0');
}
export function sampleRecordedInputs(meta,nextUpdate,{windowUpdates=128,maxRows=8}={}){
 need(meta&&integer(meta.frames,1,1000000)&&(meta.format==='native-tape'||typeof meta.pair==='function'),'admitted recording');
 need(integer(nextUpdate,0,meta.frames),'cursor boundary');need(integer(windowUpdates,1,512),'history window');need(integer(maxRows,1,32),'history rows');
 const windowStart=Math.max(0,nextUpdate-windowUpdates);
 if(meta.format==='native-tape')return sampleNativeInputs(meta,nextUpdate,{windowUpdates,maxRows});
 if(nextUpdate===0)return Object.freeze({nextUpdate,sourceUpdate:null,windowStart,players:null});
 const runs=[[],[]];let previous=null;
 if(windowStart>0)previous=meta.pair(windowStart-1);
 for(let update=windowStart;update<nextUpdate;update++){
  const pair=meta.pair(update);need(Array.isArray(pair)&&pair.length===2,'recorded pair');
  pair.forEach((word,side)=>{
   inputWord(word);const last=runs[side].at(-1);
   if(last&&last.word===word){last.endUpdate=update+1;last.updates++;}
   else runs[side].push({word,startUpdate:update,endUpdate:update+1,targetNextUpdate:update+1,updates:1,truncated:update===windowStart&&previous?.[side]===word});
  });
 }
 const players=Object.freeze(runs.map(rows=>Object.freeze({...decodeRecordedInput(rows.at(-1).word),rows:Object.freeze(rows.slice(-maxRows).reverse().map(row=>Object.freeze({...decodeRecordedInput(row.word),...row})))})));
 return Object.freeze({nextUpdate,sourceUpdate:nextUpdate-1,windowStart,players});
}

function sampleNativeInputs(meta,nextUpdate,{windowUpdates,maxRows}){
 const index=meta.nativeInputIndex,emptyStart=Math.max(0,nextUpdate-windowUpdates);
 if(!index)return Object.freeze({nextUpdate,sourceUpdate:null,windowStart:emptyStart,players:null,unavailable:'native-tape'});
 need(index.schema==='efz-native-inputs/1'&&index.frames===meta.frames&&typeof index.window==='function'&&typeof index.sourceBefore==='function'&&typeof index.samples==='function','native index');
 const sourceUpdate=index.sourceBefore(nextUpdate);
 if(sourceUpdate===null)return Object.freeze({nextUpdate,sourceUpdate:null,windowStart:emptyStart,players:null,unit:'input-ticks',lastObserved:false});
 const end=sourceUpdate+1,windowStart=Math.max(0,end-windowUpdates),previousUpdate=index.sourceBefore(windowStart),previous=previousUpdate===null?null:index.samples(previousUpdate).at(-1),runs=[[],[]];
 for(const sample of index.window(windowStart,end))sample.pair.forEach((word,side)=>{
  inputWord(word);const last=runs[side].at(-1);
  if(last&&last.word===word){last.endUpdate=sample.update+1;last.endTick=sample.tick+1;last.ticks++;}
  else runs[side].push({word,startUpdate:sample.update,endUpdate:sample.update+1,targetNextUpdate:sample.update+1,innerTick:sample.innerTick,startTick:sample.tick,endTick:sample.tick+1,ticks:1,truncated:runs[side].length===0&&previous?.[side]===word,key:sample.tick+':'+word});
 });
 const players=Object.freeze(runs.map(rows=>Object.freeze({...decodeRecordedInput(rows.at(-1).word),rows:Object.freeze(rows.slice(-maxRows).reverse().map(row=>Object.freeze({...decodeRecordedInput(row.word),...row})))})));
 return Object.freeze({nextUpdate,sourceUpdate,windowStart,players,unit:'input-ticks',lastObserved:sourceUpdate!==nextUpdate-1});
}
