import {EncryptedAssetCatalog,validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {decodeIndexedGameDat,indexedToRgba} from './indexed-art.mjs';

export const LOADING_ART_PATHS=Object.freeze(Array.from({length:175},(_,i)=>'system/nl/nl'+String(i).padStart(3,'0')+'.dat'));
export function validateLoadingManifest(value){
 const manifest=validateEncryptedAssetManifest(value);
 if(manifest.files.length!==175||!manifest.files.every(entry=>LOADING_ART_PATHS.includes(entry.path)&&entry.object))throw Error('Loading art: complete original illustration inventory required');
 return manifest;
}
// Presentation randomness is independent of the replay Worker and its RNG tape.
export function chooseLoadingIllustration(random=()=>globalThis.crypto.getRandomValues(new Uint32Array(1))[0]/4294967296){
 const value=random();if(!Number.isFinite(value)||value<0||value>=1)throw Error('Loading art: invalid random selection');
 return Math.floor(value*175);
}
export function createLoadingArt({manifest,assetRoot,key,fetcher=globalThis.fetch}){
 const catalog=new EncryptedAssetCatalog(validateLoadingManifest(manifest),assetRoot,{key,fetcher});let disposed=false;
 async function picture(index){
  if(disposed)throw Error('Loading art: owner disposed');
  if(!Number.isInteger(index)||index<0||index>=175)throw Error('Loading art: invalid illustration');
  const path=LOADING_ART_PATHS[index];await catalog.load(path);if(disposed)throw Error('Loading art: owner disposed');
  const bytes=catalog.bytes(path);
  try{
   const image=decodeIndexedGameDat(bytes);
   if(image.width!==320||image.height!==240||image.paletteCount!==254)throw Error('Loading art: unsupported original illustration format');
   // Original loading scene: indices +1, palette 0..253 -> 1..254, opaque
   // 320x240 blit. Reserved palette entries remain black, including wrap to 0.
   const palette=new Uint8Array(1024);palette.set(image.palette.subarray(0,254*4),4);
   for(let i=0;i<image.pixels.length;i++)image.pixels[i]=(image.pixels[i]+1)&255;
   return {...indexedToRgba({...image,palette,paletteCount:256}),path};
  }finally{bytes.fill(0);}
 }
 return Object.freeze({picture,dispose(){if(disposed)return;disposed=true;catalog.dispose();}});
}
