/** Derived, read-only native control history. No RNG/aux words or game state. */
const MAX_UPDATES=1000000,STRIDE=256,CHUNK=1024;
const need=(ok,message)=>{if(!ok)throw Error('Native inputs: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
function record(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain record');const own=Reflect.ownKeys(value);need(own.length===keys.length&&keys.every(k=>own.includes(k)),'fields');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'accessor');out[key]=d.value;}return out;
}
const typed=Object.getPrototypeOf(Uint8Array.prototype),get=name=>Object.getOwnPropertyDescriptor(typed,name).get;
function bytes(value,maximum){
 need(value&&Object.getPrototypeOf(value)===Uint8Array.prototype,'byte array');
 const buffer=get('buffer').call(value),length=get('byteLength').call(value),offset=get('byteOffset').call(value);
 need(Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&!Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get.call(buffer)&&offset===0&&length===Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'byteLength').get.call(buffer)&&length<=maximum,'fixed storage extent');
 const owned=new Uint8Array(length);Uint8Array.prototype.set.call(owned,value);return owned;
}
export function createNativeInputBuilder({maxUpdates=MAX_UPDATES}={}){
 need(integer(maxUpdates,1,MAX_UPDATES),'capacity');let chunks=[],frames=0,ticks=0,closed=false;
 function append(value){
  need(!closed,'builder closed');need(frames<maxUpdates,'capacity');const p=record(value,['nextUpdate','reads']);need(p.nextUpdate===frames+1,'update order');
  need(Array.isArray(p.reads)&&Object.getPrototypeOf(p.reads)===Array.prototype&&p.reads.length<=6&&p.reads.length%2===0&&Reflect.ownKeys(p.reads).length===p.reads.length+1,'ordered pairs');
  const words=[];for(let i=0;i<p.reads.length;i++){const d=Object.getOwnPropertyDescriptor(p.reads,String(i));need(d&&'value'in d&&d.enumerable,'read accessor');const r=record(d.value,['innerTick','side','word']);need(r.innerTick===Math.floor(i/2)&&r.side===i%2&&integer(r.word,0,255),'read order/word');words.push(r.word);}
  const chunkIndex=Math.floor(frames/CHUNK),slot=frames%CHUNK;const chunk=chunks[chunkIndex]??(chunks[chunkIndex]={counts:new Uint8Array(CHUNK),masks:new Uint8Array(CHUNK*6)});
  chunk.counts[slot]=words.length/2;chunk.masks.set(words,slot*6);ticks+=words.length/2;frames++;
 }
 function finish(){
  need(!closed,'builder closed');need(frames>0,'empty index');closed=true;const counts=new Uint8Array(frames),masks=new Uint8Array(ticks*2);let cursor=0;
  for(let update=0;update<frames;update++){const chunk=chunks[Math.floor(update/CHUNK)],slot=update%CHUNK,count=chunk.counts[slot];counts[update]=count;masks.set(chunk.masks.subarray(slot*6,slot*6+count*2),cursor);cursor+=count*2;}
  chunks=[];return Object.freeze({schema:'efz-native-inputs/1',counts,masks});
 }
 return Object.freeze({append,finish,dispose(){closed=true;chunks=[];},inspect:()=>Object.freeze({updates:frames,ticks,closed})});
}
export function createNativeInputIndex(raw,frames){
 need(integer(frames,1,MAX_UPDATES),'frame extent');const value=record(raw,['schema','counts','masks']);need(value.schema==='efz-native-inputs/1','schema');
 const counts=bytes(value.counts,MAX_UPDATES),masks=bytes(value.masks,MAX_UPDATES*6);need(counts.length===frames,'count extent');
 const prefix=new Uint32Array(Math.ceil(frames/STRIDE)),previous=new Int32Array(prefix.length);let ticks=0,last=-1;
 for(let i=0;i<frames;i++){if(i%STRIDE===0){prefix[i/STRIDE]=ticks;previous[i/STRIDE]=last;}need(counts[i]<=3,'tick count');ticks+=counts[i];if(counts[i])last=i;}
 need(masks.length===ticks*2,'mask extent');
 function offset(update){if(update===frames)return ticks;const block=Math.floor(update/STRIDE);let out=prefix[block];for(let i=block*STRIDE;i<update;i++)out+=counts[i];return out;}
 function window(start,end){
  need(integer(start,0,frames)&&integer(end,start,frames)&&end-start<=512,'window extent');let tick=offset(start);const rows=[];
  for(let update=start;update<end;update++)for(let innerTick=0;innerTick<counts[update];innerTick++,tick++)rows.push(Object.freeze({update,innerTick,tick,pair:Object.freeze([masks[tick*2],masks[tick*2+1]])}));return Object.freeze(rows);
 }
 function sourceBefore(next){need(integer(next,0,frames),'cursor boundary');if(!next)return null;const block=Math.floor((next-1)/STRIDE);for(let i=next-1;i>=block*STRIDE;i--)if(counts[i])return i;return previous[block]<0?null:previous[block];}
 return Object.freeze({schema:value.schema,frames,ticks,bytes:counts.byteLength+masks.byteLength+prefix.byteLength+previous.byteLength,window,sourceBefore,
  samples(update){need(integer(update,0,frames-1),'sample boundary');return Object.freeze(window(update,update+1).map(row=>row.pair));}});
}
