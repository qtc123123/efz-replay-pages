/** External collision overlay. These are the training reference's base-layer
 * colors: body yellow, hurt green, attack red. Attack geometry can remain after
 * an attack connected; it is not a promise that the move can still damage.
 * Coordinates already include the pinned core's r8 transform and camera. */
export const TRAINING_BOX_COLORS=Object.freeze({body:'#ffdc00',hurt:'#00dc00',attack:'#ff2828'});
export function prepareHitboxOverlay(training,image){
 const p=training?.prepared;
 if(!p&&!image)return Object.freeze({originUpdate:null,boxes:Object.freeze([])});
 if(!p||!image||!['originUpdate','renderOrdinal','phase','round'].every(key=>p[key]===image[key]))throw Error('Hitbox overlay: prepared image origin mismatch');
 const boxes=[];
 for(const entity of p.entities)for(const r of entity.rectangles){
  if(r.kind==='hurt'&&!entity.hurtActive||r.kind==='body'&&entity.slot!==-1)continue;
  boxes.push(Object.freeze({side:entity.side,slot:entity.slot,...r,color:TRAINING_BOX_COLORS[r.kind]}));
 }
 return Object.freeze({originUpdate:p.originUpdate,boxes:Object.freeze(boxes)});
}
export function paintHitboxOverlay(context,training,image,enabled=true){
 // Validate the pairing before touching a previously valid display.
 const layer=prepareHitboxOverlay(training,image);context.clearRect(0,0,320,240);
 if(!enabled||!layer.boxes.length)return layer;
 context.save();
 try{
  for(const box of layer.boxes){
   const {left,top,right,bottom,color}=box,width=right-left,height=bottom-top;
   context.fillStyle=color;context.globalAlpha=.12;context.fillRect(left,top,width,height);context.globalAlpha=1;
   // One original-resolution pixel; Canvas clips off-screen edges naturally.
   context.fillRect(left,top,width,1);context.fillRect(left,bottom-1,width,1);
   context.fillRect(left,top,1,height);context.fillRect(right-1,top,1,height);
  }
 }finally{context.restore();}
 return layer;
}
