/** Bounded real-time browser capture. Requests 64 fps, but never promises
 * constant-rate encoding or offline deterministic timestamps. */
export function createVideoCapture({canvas,audioTracks,Recorder=globalThis.MediaRecorder,Stream=globalThis.MediaStream,maxBytes=128*1024*1024,onError=()=>{}}){
 const mime=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'].find(t=>Recorder?.isTypeSupported?.(t));
 if(!mime||!canvas?.captureStream||!Stream)throw Error('Video recording is not supported by this browser');
 if(!Array.isArray(audioTracks)||!Number.isSafeInteger(maxBytes)||maxBytes<1)throw Error('Invalid video capture settings');
 const video=canvas.captureStream(64);let recorder;
 try{recorder=new Recorder(new Stream([...video.getVideoTracks(),...audioTracks]),{mimeType:mime,videoBitsPerSecond:4000000,audioBitsPerSecond:128000});}catch(error){video.getTracks().forEach(t=>t.stop());throw error;}
 let stopTimer=null;
 let chunks=[],size=0,error=null,started=false,closed=false,finishPromise=null,resolve,reject;
 const done=new Promise((yes,no)=>{resolve=yes;reject=no;});done.catch(()=>{});
 const clean=()=>{if(closed)return;closed=true;clearTimeout(stopTimer);video.getTracks().forEach(t=>t.stop());recorder.ondataavailable=recorder.onerror=recorder.onstop=null;};
 const stop=()=>{if(recorder.state!=='inactive')recorder.stop();else{clean();error?reject(error):resolve(new Blob(chunks,{type:mime}));chunks=[];}};
 recorder.ondataavailable=event=>{if(closed||error)return;if(size+event.data.size>maxBytes){error=Error('Video exceeds the 128 MiB capture limit');chunks=[];onError(error);stop();return;}size+=event.data.size;chunks.push(event.data);};
 recorder.onerror=event=>{error=Error(event.error?.message??'Video encoder failed');chunks=[];onError(error);try{stop();}catch{clean();reject(error);}};
 recorder.onstop=()=>{const blob=error?null:new Blob(chunks,{type:mime});chunks=[];clean();error?reject(error):resolve(blob);};
 return Object.freeze({start(){if(started||closed)throw Error('Capture already started');started=true;try{recorder.start(1000);}catch(e){error=e;clean();reject(e);throw e;}},
 finish(){if(!finishPromise){finishPromise=done;if(!closed)stopTimer=setTimeout(()=>{error??=Error('Video encoder did not finish');clean();chunks=[];reject(error);onError(error);},5000);if(!started&&!error)error=Error('Capture has not started');try{stop();}catch(e){error=e;clean();reject(e);}}return finishPromise;},
 cancel(){error??=Error('Video export cancelled');chunks=[];try{stop();}finally{clean();reject(error);}},get mimeType(){return mime;}});
}

/** Copy the visible input glyph cells, not hidden full-history rows. */
export function paintVideoInputs(context,screenRect,cells,style){
 if(!screenRect||screenRect.width<=0||screenRect.height<=0)return;
 const xScale=640/screenRect.width,yScale=480/screenRect.height;
 context.save();try{context.textAlign='left';context.textBaseline='middle';context.fillStyle='#fff';context.strokeStyle='#071018';context.lineWidth=2;
  for(const cell of Array.from(cells).slice(0,56)){const css=style(cell);if(css.display==='none'||css.visibility==='hidden')continue;const rect=cell.getBoundingClientRect();if(rect.height<=0)continue;
   const size=parseFloat(css.fontSize)*yScale;if(!Number.isFinite(size)||size<=0)continue;context.font=(css.fontWeight||'500')+' '+size+'px '+(css.fontFamily||'monospace');
   const x=(rect.left-screenRect.left)*xScale,y=(rect.top-screenRect.top+rect.height/2)*yScale;context.strokeText(cell.textContent,x,y);context.fillText(cell.textContent,x,y);
  }
 }finally{context.restore();}
}
