// Application views are deliberately separate from replay/Worker identity.
// History contains no local filenames, bytes, credentials or playback position.
const routes=new Set(['replays','replay','watch']);
export function appRoute(hash){
 const value=typeof hash==='string'&&hash.startsWith('#/')?hash.slice(2):'';
 return routes.has(value)?value:'replays';
}
export function createAppNavigation({readHash,writeHash,subscribe,leaveReplay,render}){
 let route=appRoute(readHash()),disposed=false;
 function change(next,write=false,replace=false){
  if(disposed)return;
  if(!routes.has(next))throw Error('Unsupported application route');
  if(next===route)return;
  const previous=route;
  // The host synchronously invalidates pending playback/seek intent before hide.
  if(previous==='replay')leaveReplay();
  route=next;
  if(write)writeHash('#/'+route,replace);
  render(route,previous);
 }
 const unsubscribe=subscribe(()=>change(appRoute(readHash())));
 render(route,null);
 return Object.freeze({
  current:()=>route,
  go:(next,{replace=false}={})=>change(next,true,replace),
  dispose(){if(disposed)return;disposed=true;unsubscribe();},
 });
}
