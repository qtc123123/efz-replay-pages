export const PLAYER_SETTINGS_KEY='efz-replay-settings-v1';
const boolean=value=>typeof value==='boolean';
const volume=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0&&value<=1;
const fields={volume,effectsVolume:volume,muted:boolean,hitboxes:boolean,inputs:boolean,details:boolean,
 winRounds:value=>Number.isInteger(value)&&value>=1&&value<=3,backgroundPlayback:boolean};
function selected(value){
 const result={};if(!value||typeof value!=='object'||Array.isArray(value))return result;
 for(const [key,valid]of Object.entries(fields)){
  const own=Object.getOwnPropertyDescriptor(value,key);
  if(own&&'value'in own&&valid(own.value))result[key]=own.value;
 }
 return result;
}
/** Missing or invalid fields leave the page's existing defaults in place. */
export function readPlayerPreferences(storage){
 try{
  const raw=storage?.getItem(PLAYER_SETTINGS_KEY);if(typeof raw!=='string'||raw.length>4096)return Object.freeze({});
  const saved=JSON.parse(raw);return Object.freeze(saved?.version===1?selected(saved.values):{});
 }catch{return Object.freeze({});}
}
export function writePlayerPreferences(storage,value){
 try{if(!storage)return false;storage.setItem(PLAYER_SETTINGS_KEY,JSON.stringify({version:1,values:selected(value)}));return true;}
 catch{return false;}
}
