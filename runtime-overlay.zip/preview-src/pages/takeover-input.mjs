import {defaultInputSettings,validateInputSettings,INPUT_ACTIONS} from './input-settings.mjs';
/** Browser device owner. The engine receives a single latched byte per update. */
export function createTakeoverInput({settings=defaultInputSettings(),onSafetyPause=()=>{},window=globalThis.window,document=globalThis.document,navigator=globalThis.navigator}={}){
 let config=validateInputSettings(settings),active=null,disposed=false,seenPad=null;const held=new Set(),listeners=[];
 const listen=(target,type,fn)=>{target?.addEventListener(type,fn);listeners.push(()=>target?.removeEventListener(type,fn));};
 const clear=()=>{held.clear();};
 const suspend=()=>{clear();active=null;seenPad=null;};
 const safety=reason=>{if(active===null)return;suspend();onSafetyPause(reason);};
 const editable=t=>t?.isContentEditable||['INPUT','SELECT','TEXTAREA'].includes(t?.tagName);
 function down(e){if(disposed||active===null||editable(e.target)||e.ctrlKey||e.metaKey||e.altKey)return;if(Object.values(config.controls.keyboard).includes(e.code)){held.add(e.code);e.preventDefault();}}
 function up(e){held.delete(e.code);}
 listen(window,'keydown',down);listen(window,'keyup',up);listen(window,'blur',()=>safety('Window lost focus'));
 listen(document,'visibilitychange',()=>{if(document.hidden)safety('Page hidden');});
 listen(window,'gamepaddisconnected',e=>{if(active!==null&&config.controls.gamepad.index===e.gamepad?.index)safety('Controller disconnected');});
 const available=()=>window?.isSecureContext!==false&&typeof navigator?.getGamepads==='function';
 function pads(){try{return available()?navigator.getGamepads():[];}catch{return [];}}
 return Object.freeze({
  enable(side){if(disposed)throw Error('Input owner disposed');if(side!==0&&side!==1)throw Error('Invalid player');suspend();active=side;const g=config.controls.gamepad,p=pads()[g.index];if(p?.connected!==false&&p)seenPad={index:g.index,id:p.id};return Object.freeze({gamepadAvailable:available(),reason:available()?'Press a controller button to expose it to the browser.':'Controller API unavailable. Use HTTPS and a supported browser; keyboard still works.'});},
  sample(side){if(disposed||active!==side)return 0;const p=config.controls;let mask=0;for(const [i,a]of INPUT_ACTIONS.entries())if(held.has(p.keyboard[a]))mask|=1<<i;
   const g=p.gamepad;if(g.index===null)return mask;const pad=pads()[g.index];
   if(seenPad&&(!pad||pad.connected===false||pad.id!==seenPad.id)){safety('Controller disconnected or changed');return 0;}
   if(!pad||pad.connected===false)return mask;
   seenPad={index:g.index,id:pad.id};for(const [i,a]of INPUT_ACTIONS.entries())if(pad.buttons?.[g.buttons[a]]?.pressed)mask|=1<<i;
   if(g.stick){const x=(pad.axes?.[g.axisX]??0)*(g.invertX?-1:1),y=(pad.axes?.[g.axisY]??0)*(g.invertY?-1:1);if(x>p.deadzone)mask|=1;if(x< -p.deadzone)mask|=2;if(y>p.deadzone)mask|=4;if(y< -p.deadzone)mask|=8;}return mask;
  },clear,suspend,active:()=>active!==null,
  updateSettings(value){config=validateInputSettings(value);safety('Controls changed');clear();},
  dispose(){if(disposed)return;disposed=true;suspend();listeners.splice(0).forEach(f=>f());}
 });
}
