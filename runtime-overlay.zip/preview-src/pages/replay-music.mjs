import {createAudioCapture} from './replay-audio-capture.mjs';
import {EncryptedAssetCatalog,validateEncryptedAssetManifest} from '../encrypted-assets.mjs';

const MAX_WAVE=64*1024*1024,BGM=/^wave\/bgm\/bgm[0-9]{2}\.wav$/;
const typed=Object.getPrototypeOf(Uint8Array.prototype),tag=Object.getOwnPropertyDescriptor(typed,Symbol.toStringTag).get;
const length=Object.getOwnPropertyDescriptor(typed,'byteLength').get,backing=Object.getOwnPropertyDescriptor(typed,'buffer').get;
const resizable=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get;
const need=(ok,message)=>{if(!ok)throw Error('Music: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
function pick(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain record required');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'record field/accessor');out[key]=d.value;}return out;
}
export function initialReplayMusicState(){return Object.freeze({schema:'efz-local-music/1',nextUpdate:0,volume:0,stopped:false});}
export function validateReplayMusicState(value,nextUpdate){
 const s=fields(value,['schema','nextUpdate','volume','stopped']);
 need(s.schema==='efz-local-music/1'&&integer(s.nextUpdate,0,1000000)&&s.nextUpdate===nextUpdate&&integer(s.volume,-10000,0)&&typeof s.stopped==='boolean','native music state');
 return Object.freeze(s);
}
function ownBytes(value){
 need(ArrayBuffer.isView(value)&&tag.call(value)==='Uint8Array','WAV bytes required');
 const buffer=backing.call(value),size=length.call(value);
 need(Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&!resizable?.call(buffer)&&size>=44&&size<=MAX_WAVE,'fixed WAV extent');
 const result=new Uint8Array(size);Uint8Array.prototype.set.call(result,value);return result;
}
function fields(value,required,optional=[]){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain options required');
 const keys=Reflect.ownKeys(value);need(required.every(k=>keys.includes(k))&&keys.every(k=>required.includes(k)||optional.includes(k)),'option fields');
 const result={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'option accessor');result[key]=d.value;}return result;
}

/** Bounded RIFF parsing. Authored cue/adtl/ltxt markers are read only from their
 * declared chunks, never by scanning PCM for coincidental magic strings. */
export function inspectMusicWave(input){
 const bytes=ownBytes(input),view=new DataView(bytes.buffer),four=at=>String.fromCharCode(...bytes.subarray(at,at+4));
 need(four(0)==='RIFF'&&view.getUint32(4,true)+8===bytes.length&&four(8)==='WAVE','RIFF/WAVE extent');
 let format=null,dataBytes=null,cue=null,label=null,count=0;
 function chunks(start,end,visit){
  for(let offset=start;offset<end;){
   need(++count<=256&&offset+8<=end,'chunk header/count');const size=view.getUint32(offset+4,true),body=offset+8,next=body+size+(size&1);
   need(next<=end,'chunk extent');visit(four(offset),body,size);offset=next;
  }
 }
 chunks(12,bytes.length,(name,at,size)=>{
  if(name==='fmt '){
   need(!format&&(size===16||size===18),'PCM format chunk');
   const code=view.getUint16(at,true),channels=view.getUint16(at+2,true),rate=view.getUint32(at+4,true),byteRate=view.getUint32(at+8,true),align=view.getUint16(at+12,true),bits=view.getUint16(at+14,true);
   need(code===1&&channels===2&&bits===16&&rate>=8000&&rate<=192000&&align===4&&byteRate===rate*4,'supported stereo PCM16 format');
   if(size===18)need(view.getUint16(at+16,true)===0,'PCM extension');format={sampleRate:rate,channels,bitsPerSample:bits};
  }else if(name==='data'){
   need(dataBytes===null&&size>0&&size%4===0,'PCM data extent');dataBytes=size;
  }else if(name==='cue '){
   need(!cue&&size===28&&view.getUint32(at,true)===1,'single cue point required');
   const id=view.getUint32(at+4,true),position=view.getUint32(at+8,true),sample=view.getUint32(at+24,true);
   need(id>0&&four(at+12)==='data'&&view.getUint32(at+16,true)===0&&view.getUint32(at+20,true)===0&&position===sample,'cue identity/position');cue={id,start:sample};
  }else if(name==='LIST'){
   need(size>=4,'LIST extent');if(four(at)!=='adtl')return;
   chunks(at+4,at+size,(kind,body,extent)=>{
    if(kind!=='ltxt')return;need(!label&&extent===20,'single ltxt loop required');
    need(four(body+8)==='rgn ','loop purpose');label={id:view.getUint32(body,true),length:view.getUint32(body+4,true)};
   });
  }
 });
 need(format&&dataBytes!==null,'PCM format/data required');const frames=dataBytes/4;
 need(Boolean(cue)===Boolean(label),'incomplete authored loop');
 const start=cue?.start??0,end=cue?cue.start+label.length:frames;
 need((!cue||cue.id===label.id)&&start>=0&&start<end&&end<=frames,'authored loop range/identity');
 return Object.freeze({...format,frames,duration:frames/format.sampleRate,loopStartFrame:start,loopEndFrame:end,
  loopStart:start/format.sampleRate,loopEnd:end/format.sampleRate});
}

/** Page-owned presentation audio. It consumes accepted output state but cannot
 * advance, seed or rewind simulation. Only the selected track is prepared;
 * effect/voice bodies and every other stage track remain untouched. */
export function createReplayMusic(value){
 const options=fields(value,['manifest','assetRoot','key','path'],['fetcher','createAudioContext']);
 need(typeof options.path==='string'&&BGM.test(options.path),'selected stage music path');
 const manifest=validateEncryptedAssetManifest(options.manifest),selected=manifest.files.find(e=>e.path===options.path);
 need(selected?.object,'selected encrypted music missing');const selectedPath=selected.path;
 const catalog=new EncryptedAssetCatalog({...manifest,files:[selected]},options.assetRoot,{key:options.key,fetcher:options.fetcher??globalThis.fetch});
 const createContext=options.createAudioContext??(()=>{const Type=globalThis.AudioContext??globalThis.webkitAudioContext;need(typeof Type==='function','audio output unavailable');return new Type();});
 need(typeof createContext==='function','audio context factory');
 // The catalog has already made its own key copy. Do not retain the caller's
 // raw options/manifest/key in this owner's operational data.
 delete options.key;delete options.manifest;
 let context=null,gain=null,source=null,buffer=null,metadata=null,loadPromise=null,loading=false;
 let disposed=false,closePromise=null,failure=null,wanted=false,intent=0,offset=0,startedAt=0,volume=0.5;
 let nativeVolume=0,nativeStopped=false,binding=null,lastFrame=0,bindingRevision=0;
 const outputGain=()=>volume*(nativeVolume===-10000?0:10**(nativeVolume/2000));
 function writeGain(){if(gain)gain.gain.setValueAtTime(outputGain(),context.currentTime);}
 function position(){
  if(!source||!metadata)return offset;const elapsed=Math.max(0,context.currentTime-startedAt),next=offset+elapsed;
  return next<metadata.loopEnd?next:metadata.loopStart+(next-metadata.loopEnd)%(metadata.loopEnd-metadata.loopStart);
 }
 function status(){return Object.freeze({state:disposed?'disposed':failure?'failed':source?'playing':loading?'loading':buffer?'paused':'idle',
  loaded:buffer!==null,offset:position(),volume,nativeVolume,nativeStopped,nextFrame:lastFrame});}
 function detach(){
  const node=source;if(!node)return;offset=position();source=null;node.onended=null;
  let error;try{node.stop();}catch(cause){error=cause;}try{node.disconnect();}catch(cause){error??=cause;}
  if(error){failure=error;throw error;}
 }
 function pause(){if(disposed)return status();wanted=false;intent++;detach();return status();}
 function stop(){if(disposed)return status();wanted=false;intent++;try{detach();}finally{offset=0;}return status();}
 function setVolume(next){need(!disposed&&typeof next==='number'&&Number.isFinite(next)&&next>=0&&next<=1,'volume must be between zero and one');
  volume=next;writeGain();return volume;}
 function present(raw){
  if(disposed)return status();need(binding,'music timeline binding required');
  const ids=pick(raw,['replayId','generation','seekRevision']);
  if(ids.replayId!==binding.replayId||ids.generation!==binding.generation||ids.seekRevision!==binding.seekRevision)return status();
  const frame=pick(raw,['status','result']),s=pick(frame.status,['state','nextFrame']),r=pick(frame.result,['nextFrame','musicState']);
  need(integer(s.nextFrame,1,1000000)&&s.nextFrame===lastFrame+1&&r.nextFrame===s.nextFrame&&['paused','playing','ended'].includes(s.state),'music frame boundary');
  const native=validateReplayMusicState(r.musicState,s.nextFrame);
  nativeVolume=native.volume;nativeStopped=native.stopped;lastFrame=s.nextFrame;writeGain();
  if(nativeStopped||s.state==='ended')stop();else if(s.state!=='playing')pause();return status();
 }
 function prepareSeekCommit(raw){
  need(!disposed&&!failure,'music owner unavailable');
  const c=fields(raw,['replayId','generation','seekRevision','nextFrame','musicState'],['restartMusic']);
  need(!Object.hasOwn(c,'restartMusic')||typeof c.restartMusic==='boolean','music restart flag');
  need(integer(c.replayId,1,Number.MAX_SAFE_INTEGER)&&integer(c.generation,1,Number.MAX_SAFE_INTEGER)&&integer(c.seekRevision,0,Number.MAX_SAFE_INTEGER)&&integer(c.nextFrame,0,1000000),'music binding identity');
  need(!binding||c.replayId===binding.replayId&&c.generation>binding.generation&&c.seekRevision>binding.seekRevision,'music binding progression');
  const native=validateReplayMusicState(c.musicState,c.nextFrame);let committed=false;
  // All fallible physical work precedes the host's visible commit. Retain the
  // old accepted level and identity if preparation/paint is abandoned.
  pause();const revision=++bindingRevision;
  return ()=>{
   if(disposed||committed||revision!==bindingRevision)return status();
   committed=true;binding=Object.freeze({replayId:c.replayId,generation:c.generation,seekRevision:c.seekRevision});
   lastFrame=c.nextFrame;nativeVolume=native.volume;nativeStopped=native.stopped;
   // Restart may target the first gameplay image rather than initialization.
   // Ordinary seeks keep the offset; an abandoned Restart must also retain it.
   if(c.nextFrame===0||c.restartMusic)offset=0;return status();
  };
 }
 function ensureLoaded(){
  if(loadPromise)return loadPromise;loading=true;
  loadPromise=(async()=>{
   let plain;
   try{
    await catalog.load(selectedPath);need(!disposed,'music owner disposed');plain=catalog.bytes(selectedPath);
    const info=inspectMusicWave(plain),decoded=await context.decodeAudioData(plain.slice().buffer);
    need(!disposed,'music owner disposed');
    need(decoded&&decoded.numberOfChannels===info.channels&&Number.isFinite(decoded.sampleRate)&&decoded.sampleRate>0&&
     Number.isFinite(decoded.duration)&&Math.abs(decoded.duration-info.duration)<=1/Math.min(decoded.sampleRate,info.sampleRate),'decoded music extent');
    metadata=info;buffer=decoded;return decoded;
   }finally{plain?.fill(0);catalog.dispose();loading=false;}
  })();loadPromise.catch(()=>{});return loadPromise;
 }
 function ensureContext(){
  if(context)return;
  context=createContext();need(context&&typeof context.resume==='function'&&typeof context.decodeAudioData==='function','audio context unavailable');
  gain=context.createGain();gain.connect(context.destination);writeGain();
 }
 function prepare(){
  try{
   need(!disposed,'music owner disposed');need(!failure,'music owner failed');ensureContext();
   return ensureLoaded().then(()=>status()).catch(error=>{if(!disposed){failure=error;wanted=false;catalog.dispose();}throw error;});
  }catch(error){if(!disposed)failure=error;return Promise.reject(error);}
 }
 function play(){
  try{
   need(!disposed,'music owner disposed');need(!failure,'music owner failed');wanted=true;const own=++intent;
   ensureContext();
   // Invoke resume before the first await so browser activation belongs to the
   // user's Play gesture rather than a later fetch/decode completion.
   const resumed=Promise.resolve(context.resume());
   return resumed.then(async()=>{
    need(!disposed,'music owner disposed');if(own!==intent||!wanted)return status();
    await ensureLoaded();need(!disposed,'music owner disposed');
    if(own!==intent||!wanted||source||nativeStopped)return status();writeGain();const node=context.createBufferSource();
    node.buffer=buffer;node.loop=true;node.loopStart=metadata.loopStart;node.loopEnd=metadata.loopEnd;
    node.connect(gain);source=node;startedAt=context.currentTime;
    node.onended=()=>{if(source!==node)return;source=null;wanted=false;offset=0;try{node.disconnect();}catch(error){failure=error;}};
    try{node.start(0,offset);}catch(error){try{detach();}catch{}throw error;}return status();
   }).catch(error=>{
    if(disposed)throw error;
    // An earlier Play may finish after Pause or a newer activation. Its late
    // error is obsolete for both the owner and the page's status message.
    if(own!==intent)return status();failure=error;wanted=false;catalog.dispose();throw error;
   });
  }catch(error){if(!disposed)failure=error;return Promise.reject(error);}
 }
 const captureTaps=new Set();
 function captureAudio(){need(!disposed,'audio owner disposed');ensureContext();const tap=createAudioCapture(context,gain);captureTaps.add(tap);return {stream:tap.stream,close(){tap.close();captureTaps.delete(tap);}};}
 function dispose(){
  if(closePromise)return closePromise;for(const tap of captureTaps)tap.close();captureTaps.clear();disposed=true;wanted=false;intent++;
  closePromise=(async()=>{
   let error;try{detach();}catch(cause){error=cause;}catalog.dispose();buffer=null;metadata=null;
   try{if(context)await context.close();}catch(cause){error=cause;}
   try{gain?.disconnect();}catch(cause){error??=cause;}context=null;gain=null;offset=0;
   if(error)throw error;
  })();return closePromise;
 }
 return Object.freeze({captureAudio,prepare,play,pause,stop,setVolume,present,prepareSeekCommit,dispose,status});
}
