// Presentation-only visibility. This owner never touches replay state or audio.
export function createPlayerControls({render,pinned,setTimer=setTimeout,clearTimer=clearTimeout,delay=1000}){
 let visible=true,timer=null,disposed=false;
 const clear=()=>{if(timer!==null)clearTimer(timer);timer=null;};
 function refresh(){
  if(disposed)return;
  if(pinned()){clear();if(!visible){visible=true;render(true);}return;}
  if(visible&&timer===null)timer=setTimer(()=>{timer=null;hide();},delay);
 }
 function reveal(){if(disposed)return;clear();visible=true;render(true);refresh();}
 function hide(manual=false){if(disposed)return;if(!manual&&pinned()){refresh();return;}clear();visible=false;render(false);}
 render(true);
 return Object.freeze({reveal,refresh,toggle:()=>visible?hide(true):reveal(),dispose(){disposed=true;clear();}});
}
