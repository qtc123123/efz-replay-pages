import {EncryptedAssetCatalog,validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {decodeIndexedGameDat,indexedToRgba} from './indexed-art.mjs';

export function validateBackgroundManifest(value){
 const manifest=validateEncryptedAssetManifest(value),entry=manifest.files[0];
 if(manifest.files.length!==1||entry.path!=='system/chr_sel_bg.dat'||!entry.object)throw Error('Background: one original character-selection texture required');
 return manifest;
}
function offset(value){if(!Number.isFinite(value)||value<0||value>320)throw Error('Background: invalid scroll offset');return value;}
// Uploaded EFZ.EXE: update 0x649650, double at this+0x450, +0.2 then >320
// reset; render 0x64B0D0 truncates to integer and deliberately skips strip1 at319.
// Evidence/bytes and host cadence limits: docs/qualification/CITY_BACKGROUND_2026-10-28.md.
export function advanceSelectionOffset(value){const next=offset(value)+.2;return next>320?0:next;}
export function selectionBackgroundSlices(value){
 const x=Math.trunc(offset(value)),slices=[];
 if(x<319)slices.push({sourceX:x,x:0,width:320-x});
 if(x>0)slices.push({sourceX:0,x:320-x,width:x});
 return slices;
}
export function createSelectionBackground({manifest,assetRoot,key,fetcher=globalThis.fetch}){
 const catalog=new EncryptedAssetCatalog(validateBackgroundManifest(manifest),assetRoot,{key,fetcher});let disposed=false;
 async function picture(){
  if(disposed)throw Error('Background: owner disposed');await catalog.load('system/chr_sel_bg.dat');if(disposed)throw Error('Background: owner disposed');
  const bytes=catalog.bytes('system/chr_sel_bg.dat');
  try{
   const image=decodeIndexedGameDat(bytes);
   if(image.width!==320||image.height!==240||image.paletteCount!==254||image.pixels.some(index=>index>=160))throw Error('Background: unsupported original city format');
   // Constructor maps source colors0..159 to palette1..160; loader adds1 to
   // each pixel, so the opaque result retains exactly the original RGB bytes.
   return indexedToRgba(image);
  }finally{bytes.fill(0);}
 }
 return Object.freeze({picture,dispose(){if(disposed)return;disposed=true;catalog.dispose();}});
}
