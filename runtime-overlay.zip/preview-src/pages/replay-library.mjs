import {validateRoundSummary} from './replay-rounds.mjs';
/** Session-only metadata/source custody; extracted replay copies use a bounded
 * LRU. Original user Files remain local sources, not eager expanded replay Blobs. */
const MAX_CACHE_BYTES=64*1024*1024,MAX_ENTRIES=20000,MAX_REPLAY_BYTES=64*1024*1024;
const need=(ok,message)=>{if(!ok)throw Error('Library: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&n>=min&&n<=max;
const digest=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
function components(parts){return Array.isArray(parts)&&parts.length<=64&&parts.every(p=>typeof p==='string'&&p.length>0&&p.length<=512&&!['.','..'].includes(p)&&!/[\\/\x00-\x1f\x7f]/.test(p));}
function locatorParts(parts){
 need(Array.isArray(parts)&&parts.length<=5,'invalid source locator');
 return parts.map(part=>{
  need(part&&integer(part.index,0,19999)&&typeof part.path==='string'&&part.path.length>0&&part.path.length<=1024&&!/[\x00-\x1f\x7f]/.test(part.path),'invalid source locator');
  const path=part.path.replaceAll('\\','/');need(!path.startsWith('/')&&!/^[A-Za-z]:/.test(path)&&components(path.split('/')),'invalid source locator path');
  return {index:part.index,path:part.path};
 });
}
function admitted(raw){
 need(raw&&typeof raw.id==='string'&&raw.id.length<=200&&components(raw.path)&&typeof raw.name==='string'&&components([raw.name]),'invalid entry path');
 need(integer(raw.size,1,MAX_REPLAY_BYTES)&&typeof raw.sha256==='string'&&/^[a-f0-9]{64}$/.test(raw.sha256),'invalid entry extent');
 const error=raw.error===null?null:String(raw.error??'Invalid replay').slice(0,500);
 if(!error){need(['Vanilla','Revival'].includes(raw.format)&&Array.isArray(raw.characters)&&raw.characters.length===2&&raw.characters.every(x=>integer(x,0,24))&&Array.isArray(raw.palettes)&&raw.palettes.length===2&&raw.palettes.every(x=>integer(x,0,5))&&integer(raw.stage,0,22),'invalid replay metadata');need(raw.frames===null||integer(raw.frames,1,1000000),'invalid duration');}
 return {name:raw.name,path:[...raw.path],size:raw.size,sha256:raw.sha256,characters:error?[]:[...raw.characters],palettes:error?[]:[...raw.palettes],stage:error?null:raw.stage,format:error?null:raw.format,frames:error?null:raw.frames,roundsPlayed:null,interrupted:null,analysis:null,error};
}
function aborted(){const error=Error('Extraction canceled');error.name='AbortError';return error;}
export function createReplayLibrary({createWorker,onChange=()=>{},timeoutMs=120000,cacheBytes=MAX_CACHE_BYTES}={}){
 need(typeof createWorker==='function'&&typeof onChange==='function','dependencies');need(integer(cacheBytes,0,MAX_CACHE_BYTES),'cache limit');
 let entries=[],selectedId=null,bytes=0,sequence=0,epoch=0,job=null,extraction=null,disposed=false,revision=0,notifyTimer=null,custody=0,analysisContext=null;
 const pool=new Map(),byId=new Map(),hashRefs=new Map(),fileIds=new WeakMap(),errors=[];
 function snapshot(){return Object.freeze({entries:entries.map(({source,key,...e})=>Object.freeze({...e,path:[...e.path],locator:e.locator.map(part=>({...part})),characters:[...e.characters],palettes:[...e.palettes]})),selectedId,bytes,importing:!!job,extractingId:extraction?.id??null,progress:job?.progress??null,errors:[...errors],revision});}
 function emit(){clearTimeout(notifyTimer);notifyTimer=null;revision++;onChange(snapshot());}
 function schedule(){if(notifyTimer===null)notifyTimer=setTimeout(emit,32);}
 function fail(path,message){if(errors.length<100)errors.push({path:String(path??'').slice(0,2048),message:String(message).slice(0,500)});}
 function dropCache(key){const value=pool.get(key);if(value){pool.delete(key);bytes-=value.size;}}
 function cached(key){const value=pool.get(key);if(value){pool.delete(key);pool.set(key,value);}return value;}
 function cache(key,blob){
  dropCache(key);if(blob.size>cacheBytes)return;
  while(bytes+blob.size>cacheBytes&&pool.size)dropCache(pool.keys().next().value);
  pool.set(key,blob);bytes+=blob.size;
 }
 function ownFile(row,blob){const file=new File([blob],row.name,{type:'application/octet-stream'});fileIds.set(file,row.id);return file;}
 function retain(row){const known=hashRefs.get(row.key);if(known){need(known.size===row.size,'duplicate extent mismatch');known.refs++;}else hashRefs.set(row.key,{size:row.size,refs:1});entries.push(row);byId.set(row.id,row);}
 function finish(owner){if(job!==owner)return;job=null;clearTimeout(owner.timer);owner.worker.removeEventListener('message',owner.receive);owner.worker.removeEventListener('error',owner.broken);owner.worker.terminate();owner.resolve();emit();}
 function cancel(){if(job)finish(job);}
 function finishExtraction(owner,error,file){
  if(extraction!==owner)return;extraction=null;clearTimeout(owner.timer);owner.worker.removeEventListener('message',owner.receive);owner.worker.removeEventListener('error',owner.broken);owner.worker.terminate();
  if(error)owner.reject(error);else owner.resolve(file);emit();
 }
 function cancelExtraction(){if(extraction)finishExtraction(extraction,aborted());}
 function install(raw,buffer,prefix,sources){
  need(entries.length<MAX_ENTRIES,'recording limit reached');need(buffer===undefined,'metadata import must not transfer replay bodies');const row=admitted(raw);
  need(integer(raw.sourceIndex,0,sources.length-1),'invalid source index');const locator=locatorParts(raw.locator),id=prefix+':'+raw.id;need(!byId.has(id),'duplicate entry identifier');
  retain({...row,id,key:row.sha256,sourceIndex:raw.sourceIndex,locator,source:sources[raw.sourceIndex]});
 }
 function importFiles(files){
  need(!disposed,'disposed');need(Array.isArray(files)&&files.length>0&&files.length<=MAX_ENTRIES,'input files');need(files.every(file=>file&&typeof file.arrayBuffer==='function'),'source files');cancel();
  const worker=createWorker(),owner={worker,sources:[...files],progress:null,resolve:null,timer:null};job=owner;const prefix='import-'+(++epoch),promise=new Promise(resolve=>owner.resolve=resolve);
  owner.receive=({data})=>{if(job!==owner||disposed)return;try{
   need(data&&typeof data.type==='string','worker message');
   if(data.type==='entry')install(data.entry,data.buffer,prefix,owner.sources);
   else if(data.type==='error')fail(data.path,data.message);
   else if(data.type==='progress')owner.progress={entries:integer(data.entries,0,20000)?data.entries:0,path:String(data.path??'').slice(0,2048)};
   else if(data.type==='done'){finish(owner);return;}
   else throw Error('Unknown import response');schedule();
  }catch(error){fail('',error.message);finish(owner);}};
  owner.broken=()=>{if(job===owner){fail('','Archive worker failed');finish(owner);}};
  worker.addEventListener('message',owner.receive);worker.addEventListener('error',owner.broken);
  owner.timer=setTimeout(()=>{if(job===owner){fail('','Import time limit reached');finish(owner);}},timeoutMs);
  try{worker.postMessage({type:'import',files:files.map(file=>({file,path:file.webkitRelativePath||file.name}))});emit();}catch(error){fail('',error.message);finish(owner);}return promise;
 }
 function remembered(file){const id=fileIds.get(file);if(id&&byId.has(id))return id;fileIds.delete(file);return null;}
 async function rememberFile(file,meta,input){
  need(!disposed,'disposed');if(remembered(file))return remembered(file);
  need(file&&integer(file.size,1,MAX_REPLAY_BYTES),'recording capacity');const own=custody,data=input??new Uint8Array(await file.arrayBuffer());need(data instanceof Uint8Array&&data.byteLength===file.size,'recording extent');const key=await digest(data);
  need(!disposed&&own===custody,'library changed during admission');if(remembered(file))return remembered(file);
  const existing=entries.find(e=>e.key===key&&e.path.length===0&&e.name===file.name);if(existing){fileIds.set(file,existing.id);return existing.id;}
  need(entries.length<MAX_ENTRIES,'recording count limit reached');const init=meta.initialization;need(init,'recording metadata');
  const id='direct-'+(++sequence),row=admitted({id,name:file.name,path:[],size:file.size,sha256:key,characters:[...init.characters],palettes:[...init.palettes],stage:init.stage,format:meta.format==='revival-pairs'||meta.extensionOffset!=null?'Revival':'Vanilla',frames:meta.frames??null,error:null});
  retain({...row,id,key,source:file,sourceIndex:0,locator:[]});cache(key,new Blob([data]));fileIds.set(file,id);emit();return id;
 }
 async function file(id){
  need(!disposed,'disposed');cancelExtraction();const row=byId.get(id);need(row,'recording missing');need(!row.error,row.error);const blob=cached(row.key);if(blob){need(blob.size===row.size,'cached replay extent');return ownFile(row,blob);}
  const worker=createWorker(),owner={id,worker,resolve:null,reject:null,timer:null,verifying:false},own=custody;extraction=owner;
  const promise=new Promise((resolve,reject)=>{owner.resolve=resolve;owner.reject=reject;});
  owner.receive=async({data})=>{
   if(extraction!==owner||disposed||owner.verifying)return;
   try{
    need(data&&typeof data.type==='string','invalid extraction response');
    if(data.type==='extract-error')throw Error(String(data.message||'Extraction failed').slice(0,500));
    need(data.type==='extracted'&&data.buffer instanceof ArrayBuffer&&data.buffer.byteLength===row.size,'invalid extracted replay extent');owner.verifying=true;
    need(await digest(data.buffer)===row.sha256,'extracted replay SHA-256 digest mismatch');
    if(extraction!==owner||disposed||own!==custody||byId.get(id)!==row)return;
    const value=new Blob([data.buffer]);cache(row.key,value);finishExtraction(owner,null,ownFile(row,value));
   }catch(error){if(extraction===owner)finishExtraction(owner,error);}
  };
  owner.broken=()=>{if(extraction===owner)finishExtraction(owner,Error('Archive extraction worker failed'));};
  worker.addEventListener('message',owner.receive);worker.addEventListener('error',owner.broken);owner.timer=setTimeout(()=>{if(extraction===owner)finishExtraction(owner,Error('Extraction time limit reached'));},timeoutMs);
  try{worker.postMessage({type:'extract',file:row.source,locator:row.locator.map(part=>({...part})),sha256:row.sha256,size:row.size});emit();}catch(error){finishExtraction(owner,error);}return promise;
 }
 function select(id){need(byId.has(id)&&!byId.get(id).error,'playable recording required');selectedId=id;emit();}
 function neighbor(delta){need(delta===1||delta===-1,'direction');const valid=entries.filter(x=>!x.error),at=valid.findIndex(x=>x.id===selectedId);if(at<0)return null;return valid[at+delta]?.id??null;}
 function move(id,delta){need(delta===1||delta===-1,'direction');const i=entries.findIndex(e=>e.id===id),j=i+delta;if(i<0||j<0||j>=entries.length)return;[entries[i],entries[j]]=[entries[j],entries[i]];emit();}
 function remove(id){
  const at=entries.findIndex(e=>e.id===id);if(at<0)return;if(extraction?.id===id)cancelExtraction();const [row]=entries.splice(at,1);byId.delete(id);const known=hashRefs.get(row.key);if(--known.refs===0){hashRefs.delete(row.key);dropCache(row.key);}if(selectedId===id)selectedId=null;emit();
 }
 function updateDuration(id,frames){need(integer(frames,1,1000000),'duration');const row=byId.get(id);if(row&&row.frames!==frames){row.frames=frames;if(row.analysis&&row.analysis.frames!==frames){row.analysis=null;row.roundsPlayed=null;row.interrupted=null;}emit();}}
 function analysisFields(value,keys){
  need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain analysis required');const own=Reflect.ownKeys(value);need(own.length===keys.length&&keys.every(key=>own.includes(key)),'analysis fields');
  const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'analysis data fields');out[key]=d.value;}return out;
 }
 function configureAnalysis(value){
  need(!disposed,'disposed');const context=analysisFields(value,['engineHash','winRounds']);need(typeof context.engineHash==='string'&&/^[a-f0-9]{64}$/.test(context.engineHash)&&integer(context.winRounds,1,5)&&!Object.is(context.winRounds,-0),'analysis configuration');
  if(analysisContext?.engineHash===context.engineHash&&analysisContext.winRounds===context.winRounds)return;
  analysisContext=Object.freeze(context);let changed=false;
  for(const row of entries)if(row.analysis&&(row.analysis.engineHash!==context.engineHash||row.analysis.winRounds!==context.winRounds)){row.analysis=null;row.roundsPlayed=null;row.interrupted=null;changed=true;}
  if(changed)emit();
 }
 function updateAnalysis(id,value){
  const row=byId.get(id);if(disposed||!row||row.error)return false;
  const p=analysisFields(value,['schema','frames','winRounds','roundsPlayed','matchStatus','sha256','engineHash']);
  const {sha256,engineHash,...raw}=p,summary=validateRoundSummary(raw);
  need(typeof sha256==='string'&&/^[a-f0-9]{64}$/.test(sha256)&&typeof engineHash==='string'&&/^[a-f0-9]{64}$/.test(engineHash),'analysis provenance');
  if(!analysisContext||sha256!==row.sha256||engineHash!==analysisContext.engineHash||summary.winRounds!==analysisContext.winRounds||row.frames!==null&&summary.frames!==row.frames)return false;
  const analysis=Object.freeze({...summary,sha256,engineHash});
  if(row.analysis&&Object.keys(analysis).every(key=>analysis[key]===row.analysis[key]))return true;
  // The accepted complete traversal proves its extent too. Publish it in the
  // same snapshot, independently of unrelated audio/art preparation.
  row.frames=analysis.frames;row.analysis=analysis;row.roundsPlayed=analysis.roundsPlayed;row.interrupted=analysis.matchStatus==='unknown'?null:analysis.matchStatus==='interrupted';emit();return true;
 }
 function clear(){custody++;cancel();cancelExtraction();entries=[];byId.clear();hashRefs.clear();pool.clear();bytes=0;selectedId=null;errors.length=0;emit();}
 function dispose(){if(disposed)return;clear();disposed=true;}
 return Object.freeze({snapshot,importFiles,cancel,cancelExtraction,rememberFile,file,select,neighbor,move,remove,updateDuration,configureAnalysis,updateAnalysis,clear,dispose});
}
