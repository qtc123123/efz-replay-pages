// Runs only in a disposable import Worker in the page. This module is also
// directly testable; it has no game-engine, network-upload or storage authority.
import {inspectLocalReplay} from '../local-replay-inspector.mjs';

export const ARCHIVE_IMPORT_LIMITS=Object.freeze({archiveBytes:128*1024*1024,replayBytes:64*1024*1024,
 depth:4,entries:20000,expandedBytes:4*1024*1024*1024,archiveMilliseconds:120000});
const need=(condition,message)=>{if(!condition)throw Error(message);};
const replayName=name=>/\.rep$/i.test(name);
const archiveName=name=>/\.(?:zip|rar|7z|7zip)$/i.test(name);
const multipartName=name=>/(?:\.part\d+\.rar|\.r\d\d|\.z\d\d|\.(?:7z|zip)\.\d{3,})$/i.test(name);
const digest=async data=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',data)),value=>value.toString(16).padStart(2,'0')).join('');
const yieldTurn=()=>new Promise(resolve=>setTimeout(resolve,0));
const boundedText=(value,limit)=>String(value??'').replace(/[\x00-\x1f\x7f]/g,' ').slice(0,limit);

/** Components, never object keys or filesystem paths. Both archive separators
 * are accepted, but absolute paths, traversal and ambiguous empty parts are not. */
export function archivePath(value,{directory=false}={}){
 need(typeof value==='string'&&value.length>0&&value.length<=1024&&!/[\x00-\x1f\x7f]/.test(value),'Unsafe archive path');
 const normalized=value.replaceAll('\\','/');
 need(!normalized.startsWith('/')&&!/^[A-Za-z]:/.test(normalized),'Unsafe absolute archive path');
 const clean=directory&&normalized.endsWith('/')?normalized.slice(0,-1):normalized,parts=clean.split('/');
 need(parts.length<=64&&parts.every(part=>part.length>0&&part.length<=255&&part!=='.'&&part!=='..'),'Unsafe archive path components');
 return parts;
}
export function archiveFormat(bytes){
 if(!(bytes instanceof Uint8Array))return null;
 const starts=signature=>bytes.length>=signature.length&&signature.every((value,index)=>bytes[index]===value);
 if(starts([80,75,3,4])||starts([80,75,5,6]))return 'zip';
 if(starts([82,97,114,33,26,7,0])||starts([82,97,114,33,26,7,1,0]))return 'rar';
 if(starts([55,122,188,175,39,28]))return '7z';
 return null;
}
function configuredLimits(value={}){
 const limits={...ARCHIVE_IMPORT_LIMITS};
 for(const [key,maximum]of Object.entries(limits))if(value[key]!==undefined){need(Number.isSafeInteger(value[key])&&value[key]>=0&&value[key]<=maximum,'Invalid import limit');limits[key]=value[key];}
 return limits;
}
function metadata(bytes){
 try{const result=inspectLocalReplay(bytes),init=result.initialization;return {characters:[...init.characters],palettes:[...init.palettes],stage:init.stage,
  format:result.format==='revival-pairs'||result.extensionOffset!=null?'Revival':'Vanilla',frames:result.frames,error:null};}
 catch(error){return {characters:[],palettes:[],stage:null,format:null,frames:null,error:boundedText(error.message||error,512)};}
}
let decoderPromise;
async function defaultDecoder(){
 decoderPromise??=import('../../vendor/libarchive/reader.mjs').then(module=>module.createArchiveDecoder());
 return decoderPromise;
}

/** One import operation. post(message, transfers) mirrors Worker.postMessage.
 * The page must terminate the Worker to cancel/preempt synchronous WASM and
 * enforce its wall-clock watchdog; a worker-side timer cannot interrupt WASM.
 * decode/limits/now are dependency seams for deterministic resource tests. */
export async function importArchiveFiles(files,{post=()=>{},decode,limits:requestedLimits,now=()=>performance.now(),yieldControl=yieldTurn}={}){
 const limits=configuredLimits(requestedLimits),hashes=new Map();
 let entries=0,bytes=0,skipped=0,visited=0,declared=0,actual=0,errors=0,suppressed=0,lastProgress=-Infinity,stopped=false;
 const emitError=(path,error)=>{if(errors++<100)post({type:'error',path:boundedText(path,1024),message:boundedText(error.message||error,512)});else suppressed++;};
 const progress=path=>{const time=now();if(time-lastProgress>=100){post({type:'progress',entries,bytes,path:boundedText(path,1024)});lastProgress=time;}};
 const stop=message=>{stopped=true;throw Error(message);};
 const visit=()=>{if(++visited>limits.entries)stop('Visited entry limit exceeded');};
 const expand=(size,kind)=>{
  need(Number.isSafeInteger(size)&&size>=0,'Invalid declared archive entry size');
  if(kind==='declared'){if(declared+size>limits.expandedBytes)stop('Declared expanded-work limit exceeded');declared+=size;}
  else {if(actual+size>limits.expandedBytes)stop('Actual expanded-work limit exceeded');actual+=size;}
 };
 const emitReplay=async(data,path,sourceIndex,locator)=>{
  if(data.byteLength===0){skipped++;return;}
  need(data.byteLength<=limits.replayBytes,'Replay byte limit exceeded');
  const sha256=await digest(data);
  const known=hashes.has(sha256);
  const info=known?hashes.get(sha256):metadata(data),size=data.byteLength;
  const entry={id:String(++entries),path:path.slice(0,-1),name:path.at(-1),size,sha256,sourceIndex,locator:locator.map(part=>({...part})),...info};
  if(!known){hashes.set(sha256,info);bytes+=size;}
  post({type:'entry',entry});
  progress(path.join('/'));
 };
 const processArchive=async(data,path,depth,sourceIndex,locator)=>{
  need(data.byteLength<=limits.archiveBytes,'Archive byte limit exceeded');need(depth<=limits.depth,'Nested archive depth limit exceeded');
  need(archiveFormat(data),'Unsupported or mismatched archive signature');
  const started=now(),reader=decode||await defaultDecoder();let ordinal=-1;
  for await(const item of reader(data)){
   if(stopped)break;ordinal++;visit();if(visited%32===0)await yieldControl();need(now()-started<=limits.archiveMilliseconds,'Archive time limit exceeded');
   let itemPath=path;
   try{
    const parts=archivePath(item.path,{directory:item.type==='directory'});itemPath=[...path,...parts];
    need(itemPath.length<=64&&itemPath.join('/').length<=1024,'Archive provenance path limit exceeded');
    need(!item.encrypted,'Encrypted archives/entries are not supported');
    need(item.type==='file'||item.type==='directory','Archive links and special entry types are not supported');
    if(item.type==='directory'){skipped++;await item.skip?.();continue;}
    expand(item.size,'declared');
    const name=itemPath.at(-1);
    if(multipartName(name))throw Error('Multipart archives are not supported');
    if(replayName(name)&&item.size===0){skipped++;await item.skip?.();continue;}
    if(!replayName(name)&&!archiveName(name)){skipped++;await item.skip?.();continue;}
    need(item.size<=(replayName(name)?limits.replayBytes:limits.archiveBytes),(replayName(name)?'Replay':'Archive')+' byte limit exceeded');
    if(archiveName(name))need(depth<limits.depth,'Nested archive depth limit exceeded');
    const child=await item.read();need(child instanceof Uint8Array&&child.byteLength===item.size,'Archive entry actual size mismatch');expand(child.byteLength,'actual');
    const childLocator=[...locator,{index:ordinal,path:item.path}];
    if(archiveName(name))await processArchive(child,itemPath,depth+1,sourceIndex,childLocator);else await emitReplay(child,itemPath,sourceIndex,childLocator);
   }catch(error){emitError(itemPath.join('/'),error);await item.skip?.();if(stopped)break;}
   progress(itemPath.join('/'));
  }
 };
 try{
  need(Array.isArray(files),'Import files must be an array');
  for(let sourceIndex=0;sourceIndex<files.length;sourceIndex++){
   const record=files[sourceIndex];if(stopped)break;let path=[];
   try{
    visit();const file=record?.file??record;path=archivePath(record?.file?record.path??(file.webkitRelativePath||file.name):file.webkitRelativePath||file.name);
    need(file&&typeof file.arrayBuffer==='function'&&Number.isSafeInteger(file.size)&&file.size>=0,'Invalid local file');
    const name=path.at(-1);need(!multipartName(name),'Multipart archives are not supported');
    need(file.size<=(replayName(name)?limits.replayBytes:limits.archiveBytes),(replayName(name)?'Replay':'Archive')+' byte limit exceeded');
    if(replayName(name)&&file.size===0){skipped++;continue;}
    const data=new Uint8Array(await file.arrayBuffer());need(data.byteLength===file.size,'Local file size changed');
    expand(data.byteLength,'declared');expand(data.byteLength,'actual');
    if(archiveName(name)||archiveFormat(data))await processArchive(data,path,0,sourceIndex,[]);
    else if(replayName(name))await emitReplay(data,path,sourceIndex,[]);
    else {skipped++;emitError(path.join('/'),'Unsupported file; choose .rep, ZIP, RAR or 7z');}
   }catch(error){emitError(path.join('/'),error);}
  }
 }catch(error){emitError('',error);}
 if(suppressed)post({type:'error',path:'',message:`${suppressed} additional import errors omitted`});
 const result={entries,bytes,skipped};post({type:'done',...result});return result;
}


/** Reopen only a selected source/ordinal chain. Solid archives may require
 * decompressing preceding data; this is bounded work, not true random access.
 * No unselected replay bodies are retained or returned to the page. */
export async function extractArchiveReplay(request,{decode,limits:requestedLimits,now=()=>performance.now(),yieldControl=yieldTurn}={}){
 const limits=configuredLimits(requestedLimits),{file,locator,sha256,size}=request??{},started=now();
 need(file&&typeof file.arrayBuffer==='function'&&Number.isSafeInteger(file.size)&&file.size>=0,'Invalid extraction source');
 need(Array.isArray(locator)&&locator.length<=limits.depth+1,'Invalid extraction locator depth');
 for(const part of locator){need(part&&Number.isSafeInteger(part.index)&&part.index>=0&&part.index<limits.entries,'Invalid extraction locator ordinal');archivePath(part.path);}
 need(typeof sha256==='string'&&/^[a-f0-9]{64}$/.test(sha256)&&Number.isSafeInteger(size)&&size>0&&size<=limits.replayBytes,'Invalid extraction replay extent/digest');
 need(file.size<=(locator.length?limits.archiveBytes:limits.replayBytes),'Extraction source byte limit exceeded');
 let visited=0,declared=file.size,actual=file.size;
 const work=(count,kind)=>{need(Number.isSafeInteger(count)&&count>=0,'Invalid extraction declared size');if(kind==='declared'){declared+=count;need(declared<=limits.expandedBytes,'Extraction declared expanded-work limit exceeded');}else{actual+=count;need(actual<=limits.expandedBytes,'Extraction actual expanded-work limit exceeded');}};
 const check=async()=>{need(++visited<=limits.entries,'Extraction visited entry limit exceeded');need(now()-started<=limits.archiveMilliseconds,'Extraction time limit exceeded');if(visited%32===0)await yieldControl();};
 const extract=async(bytes,level)=>{
  if(level===locator.length)return bytes;
  need(bytes.length<=limits.archiveBytes&&archiveFormat(bytes),'Invalid extraction archive signature/extent');
  const target=locator[level],reader=decode||await defaultDecoder();let ordinal=-1;
  for await(const item of reader(bytes)){
   ordinal++;await check();work(item.size,'declared');
   if(ordinal!==target.index){await item.skip?.();continue;}
   need(item.path===target.path,'Extraction locator path mismatch');archivePath(item.path);
   need(item.type==='file'&&!item.encrypted,'Extraction links, encrypted or special entries are not supported');
   const last=level===locator.length-1;need(last?replayName(item.path):archiveName(item.path),'Extraction locator archive/replay type mismatch');
   need(item.size<=(last?limits.replayBytes:limits.archiveBytes),'Extraction entry byte limit exceeded');
   if(last)need(item.size===size,'Extraction declared replay size mismatch');
   const child=await item.read();need(child instanceof Uint8Array&&child.byteLength===item.size,'Extraction actual size mismatch');work(child.byteLength,'actual');
   return extract(child,level+1);
  }
  throw Error('Extraction locator entry missing');
 };
 const input=new Uint8Array(await file.arrayBuffer());need(input.byteLength===file.size,'Extraction source size changed');const data=await extract(input,0);
 need(data.byteLength===size,'Extracted replay size mismatch');need(await digest(data)===sha256,'Extracted replay SHA-256 digest mismatch');
 return data.byteOffset===0&&data.byteLength===data.buffer.byteLength?data.buffer:data.slice().buffer;
}
