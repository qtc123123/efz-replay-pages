// Presentation-only raw DAT support. Source O/T/I/E/K at pinned upstream
// fcdbd920af0b746badf56ad3af62446d1007329ea4ad630453f3b4adde6980ff.
// No format guessing, RLE, PAT or trailing-payload interpretation is performed.
const MAX_BYTES=8*1024*1024,MAX_SIDE=4096,MAX_PIXELS=4*1024*1024;
export function artInteger(value,min,max,label){
 if(!Number.isSafeInteger(value)||value<min||value>max)throw Error('invalid game DAT '+label+' (integer required)');return value;
}
export function decodeIndexedGameDat(bytes){
 if(!(bytes instanceof Uint8Array))throw TypeError('game DAT bytes must be Uint8Array');
 if(bytes.byteLength<5||bytes.byteLength>MAX_BYTES)throw Error('invalid game DAT size');
 const paletteCount=bytes[0],header=1+paletteCount*3;
 if(paletteCount===0||header+4>bytes.byteLength)throw Error('truncated game DAT palette/header');
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),width=view.getUint16(header,true),height=view.getUint16(header+2,true);
 artInteger(width,1,MAX_SIDE,'dimensions');artInteger(height,1,MAX_SIDE,'dimensions');
 if(width*height>MAX_PIXELS)throw Error('invalid game DAT dimensions');
 const at=header+4,bytesConsumed=at+width*height;if(bytesConsumed>bytes.byteLength)throw Error('truncated game DAT raw pixels');
 const pixels=new Uint8Array(width*height),palette=new Uint8Array(1024);
 for(let row=0;row<height;row++)pixels.set(bytes.subarray(at+(height-1-row)*width,at+(height-row)*width),row*width);
 for(let i=0;i<paletteCount;i++){palette[4*i]=bytes[3+3*i];palette[4*i+1]=bytes[2+3*i];palette[4*i+2]=bytes[1+3*i];}
 return {width,height,pixels,palette,paletteCount,keyIndex:pixels[0],bytesConsumed,trailingBytes:bytes.byteLength-bytesConsumed};
}
function raster(image){
 if(!image||!(image.pixels instanceof Uint8Array))throw Error('invalid indexed art raster');
 artInteger(image.width,1,MAX_SIDE,'dimensions');artInteger(image.height,1,MAX_SIDE,'dimensions');
 if(image.width*image.height>MAX_PIXELS||image.pixels.length!==image.width*image.height)throw Error('invalid indexed art raster extent');
}
export function indexedToRgba(image,{palette=image.palette,paletteCount=image.paletteCount??256,paletteOffset=0,transparent=false,crop}={}){
 raster(image);artInteger(paletteCount,1,256,'palette count');artInteger(paletteOffset,0,paletteCount-1,'palette offset');
 if(!(palette instanceof Uint8Array)||palette.length!==1024)throw Error('invalid indexed art palette');
 if(transparent!==false&&transparent!=='top-left')throw Error('unsupported game DAT transparency mode');
 let x=0,y=0,width=image.width,height=image.height;
 if(crop!==undefined){
  if(!crop||typeof crop!=='object')throw Error('invalid game DAT crop');
  x=artInteger(crop.x,0,image.width-1,'crop x');y=artInteger(crop.y,0,image.height-1,'crop y');
  width=artInteger(crop.width,1,image.width-x,'crop width');height=artInteger(crop.height,1,image.height-y,'crop height');
 }
 const key=transparent==='top-left'?image.keyIndex??image.pixels[0]:-1,data=new Uint8ClampedArray(width*height*4);
 for(let row=0;row<height;row++)for(let column=0;column<width;column++){
  const index=image.pixels[(row+y)*image.width+x+column];if(index===key)continue;
  const color=paletteOffset+index;if(color>=paletteCount)throw Error('game DAT pixel references unavailable palette color');
  const destination=(row*width+column)*4;data[destination]=palette[4*color];data[destination+1]=palette[4*color+1];data[destination+2]=palette[4*color+2];data[destination+3]=255;
 }
 return {width,height,data};
}
/** Source K clipping/mirror order, including its key=0 opaque convention.
 * Coordinates are integer native pixels. indexOffset is the loader O offset;
 * key is supplied in source indices so callers retain the original key. */
export function blitIndexed(target,source,{src={x:0,y:0,width:source.width,height:source.height},x,y,key=null,mirror=false,indexOffset=0}){
 raster(target);raster(source);for(const [label,value]of Object.entries({x,y,srcX:src.x,srcY:src.y,width:src.width,height:src.height}))artInteger(value,-8192,8192,label);
 artInteger(indexOffset,0,255,'palette offset');if(key!==null)artInteger(key,0,255,'key');if(typeof mirror!=='boolean')throw Error('invalid indexed mirror');
 let left=x,top=y,right=x+src.width,bottom=y+src.height,sl=src.x,st=src.y,sr=src.x+src.width,sb=src.y+src.height;const originalRight=sr;
 if(!(top<bottom&&left<right&&st<sb&&sl<sr))return;
 if(top<0){st-=top;top=0;}if(left<0){sl-=left;left=0;}
 if(bottom>target.height){sb-=bottom-target.height;bottom=target.height;}if(right>target.width){sr-=right-target.width;right=target.width;}
 if(mirror){const l=originalRight-sr,r=originalRight-sl;sl=l;sr=r;}
 if(!(top<bottom&&left<right&&st<sb&&sl<sr))return;
 const width=right-left,height=bottom-top,mappedKey=key===null?null:(key+indexOffset)&255,flip=mirror&&mappedKey!==null&&mappedKey!==0;
 for(let row=0;row<height;row++){
  const sy=st+row;if(sy<0||sy>=source.height)continue;
  for(let column=0;column<width;column++){
   const sx=sl+(flip?width-1-column:column);if(sx<0||sx>=source.width)continue;
   const value=(source.pixels[sy*source.width+sx]+indexOffset)&255;
   if(mappedKey===null||mappedKey===0||value!==mappedKey)target.pixels[(top+row)*target.width+left+column]=value;
  }
 }
}
