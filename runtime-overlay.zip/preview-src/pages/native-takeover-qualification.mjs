/** Full recovered-profile traversal, not a transferable admission token.
 * The caller must bind its fresh engine, meta, seed and hashes to the same bytes.
 * No receipt is returned on cancellation, partial EOF or any mismatched RNG word. */
import {validateLocalTapeEnd} from '../local-replay-inspector.mjs';
import {createNativeBranchBuilder} from './native-branch-projection.mjs';
import {recoverNativeCrtSeed} from './native-rng-recovery.mjs';
const need=(ok,message)=>{if(!ok)throw Error('Native qualification: '+message);};
const uint=(n,max=0xffffffff)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=0&&n<=max;
function record(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'record');const own=Reflect.ownKeys(value);need(own.length===keys.length&&keys.every(k=>own.includes(k)),'fields');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'accessor');out[key]=d.value;}return out;
}
function dense(value,max){need(Array.isArray(value)&&Object.getPrototypeOf(value)===Array.prototype&&value.length<=max&&Reflect.ownKeys(value).length===value.length+1,'array extent');return Array.from({length:value.length},(_,i)=>{const d=Object.getOwnPropertyDescriptor(value,String(i));need(d&&'value'in d&&d.enumerable,'array accessor');return d.value;});}
export async function scanRecoveredNative(meta,engine,{seed,recordingHash,engineHash,maxUpdates=1000000,clock=()=>performance.now(),deadlineMilliseconds=180000,yieldTask=()=>new Promise(resolve=>setTimeout(resolve,0)),cancelled=()=>false,onProgress=()=>{}}={}){
 need(meta?.format==='native-tape'&&typeof engine?.advance==='function'&&typeof engine.inspect==='function'&&typeof engine.nativeRngEvidence==='function'&&typeof engine.nativeBranchSamples==='function'&&typeof engine.recoveredNativeIdentity==='function','dependencies');
 need(uint(seed,0x7fffffff)&&uint(maxUpdates,1000000)&&maxUpdates>0&&Number.isFinite(deadlineMilliseconds)&&deadlineMilliseconds>0,'options');
 need(/^[a-f0-9]{64}$/.test(recordingHash)&&/^[a-f0-9]{64}$/.test(engineHash),'identity');
 const identity=record(engine.recoveredNativeIdentity(),['seed','profile']);need(identity.seed===seed&&identity.profile==='efz402-native-recovered/1','recovered seed differs or profile mismatch');
 const builder=createNativeBranchBuilder({maxUpdates}),prefix=[],started=clock();need(Number.isFinite(started),'clock');let next=0,rngReads=0,lastOrdinal=0,lastCalls=0;
 const check=()=>{need(!cancelled(),'cancelled');const now=clock();need(Number.isFinite(now)&&now>=started&&now-started<=deadlineMilliseconds,'deadline');};
 try{while(next<maxUpdates){
  check();const result=await engine.advance(next);check();
  need(result&&['advanced','end'].includes(result.kind)&&result.nextFrame===next+1,'complete boundary');
  const state=engine.inspect();need(state.nextFrame===next+1&&state.failed===false&&typeof state.ended==='boolean','engine boundary');
  const evidence=record(engine.nativeRngEvidence(),['nextUpdate','xCalls','reads']);need(evidence.nextUpdate===next+1&&uint(evidence.xCalls)&&evidence.xCalls>=lastCalls,'RNG boundary');
  for(const raw of dense(evidence.reads,4096)){
   const r=record(raw,['ordinal','value','generated']);need(uint(r.ordinal)&&r.ordinal>lastOrdinal&&r.ordinal>lastCalls&&r.ordinal<=evidence.xCalls&&uint(r.value,32767)&&uint(r.generated,32767),'RNG order/value');
   need(r.value===r.generated,`RNG_MISMATCH update=${next} ordinal=${r.ordinal} recorded=${r.value} generated=${r.generated}`);
   if(prefix.length<32)prefix.push({ordinal:r.ordinal,value:r.value});lastOrdinal=r.ordinal;rngReads++;
  }
  lastCalls=evidence.xCalls;builder.append(engine.nativeBranchSamples());next++;
  let completion=null,tapeOffset=null;
  if(result.kind==='end'){
   need(result.observation?.sceneId===8&&state.ended===true&&state.endTimer===200&&state.lastCharacters?.some(p=>p.wins===meta.initialization.winRounds),'natural finish');
   tapeOffset=validateLocalTapeEnd(meta,state.tapeOffset);completion='natural-end';
  }else{
   need(result.observation?.sceneId===3&&state.ended===false,'battle boundary');
   if(state.tapeOffset===meta.nativeEnd){tapeOffset=validateLocalTapeEnd(meta,state.tapeOffset);completion='recording-ended';}
   else need(uint(state.tapeOffset,meta.nativeEnd)&&state.tapeOffset>=12&&state.tapeOffset%2===0,'tape boundary');
  }
  if(completion){
   check();const candidate=recoverNativeCrtSeed(prefix);need(candidate.kind==='candidate','RNG recovery '+candidate.reason);need(candidate.seed===seed,'recovered seed differs');
   return Object.freeze({schema:'efz-native-recovered-scan/1',profile:'efz402-native-recovered/1',seed,recordingHash,engineHash,frames:next,nativeTapeOffset:tapeOffset,rngReads,rngCalls:lastCalls,completion,projection:builder.finish()});
  }
  if(next%64===0){onProgress(next);await yieldTask();}
 }
 throw Error('Native qualification: update capacity');
 }finally{builder.dispose();}
}
