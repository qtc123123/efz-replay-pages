const integer=(n,min=0)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min;
const need=(ok,message)=>{if(!ok)throw Error('Replay checkpoint cache: '+message);};
const typed=Object.getPrototypeOf(Uint8Array.prototype);
const typedBuffer=Object.getOwnPropertyDescriptor(typed,'buffer').get;
const typedLength=Object.getOwnPropertyDescriptor(typed,'byteLength').get;
const typedOffset=Object.getOwnPropertyDescriptor(typed,'byteOffset').get;
const bufferLength=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'byteLength').get;
const resizable=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get;
const METADATA_LIMIT=1024*1024;

/** A reservation precedes encoding/transfer. Buffers passed to accept become
 * cache-owned: producers must neither mutate nor detach them afterward. Metadata
 * is copied within the reservation. Byte accounting includes conservative
 * metadata charges, not the browser's engine/GC overhead or producer resources. */
export function createReplayCheckpointCache({identity,maxBytes=32*1024*1024,maxEntries=32,maxInFlightBytes=8*1024*1024,maxCaptureBytes=4*1024*1024,reservationBytes=maxCaptureBytes}={}){
 need(typeof identity==='string'&&identity.length>0&&identity.length<=4096,'identity');
 for(const n of [maxBytes,maxEntries,maxInFlightBytes,maxCaptureBytes,reservationBytes])need(integer(n,1),'positive limits');
 need(maxCaptureBytes<=maxBytes&&maxCaptureBytes<=reservationBytes&&reservationBytes<=maxInFlightBytes&&maxEntries<=4096,'compatible limits');
 let retired=false,ownedBytes=0,reservedBytes=0,sequence=0;
 const reservations=new Set(),entries=new Map(),all=new Set(),originals=new WeakMap();
 const cancel=token=>{if(!reservations.delete(token))return false;reservedBytes-=reservationBytes;return true;};
 function reserve(){
  if(retired||reservedBytes+reservationBytes>maxInFlightBytes)return null;
  const token=Object.freeze({});reservations.add(token);reservedBytes+=reservationBytes;return token;
 }
 function own(raw){
  let metadataBytes=0,nodes=0,totalBytes=0;const visiting=new Set();
  const charge=n=>{metadataBytes+=n;need(metadataBytes<=METADATA_LIMIT&&metadataBytes+totalBytes<=maxCaptureBytes,'metadata capacity');};
  function metadata(value,depth=0){
   need(depth<=24&&++nodes<=65536,'metadata complexity');
   if(value===null||typeof value==='boolean'){charge(8);return value;}
   if(typeof value==='number'){need(Number.isFinite(value),'finite metadata');charge(8);return value;}
   if(typeof value==='string'){charge(value.length*2+8);return value;}
   need(value&&typeof value==='object'&&!visiting.has(value),'metadata shape/cycle');
   const array=Array.isArray(value);need(array||[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain metadata');
   if(array)need(value.length<=65536,'metadata array extent');
   const keys=Reflect.ownKeys(value);need(keys.length<=(array?65537:256),'metadata fields');
   visiting.add(value);charge(32);const out=array?[]:{};
   if(array)need(keys.length===value.length+1,'dense metadata array');
   for(const key of keys){
    if(array&&key==='length')continue;
    need(typeof key==='string'&&key.length<=128&&!['__proto__','prototype','constructor'].includes(key),'metadata key');
    if(array)need(/^(0|[1-9][0-9]*)$/.test(key)&&Number(key)<value.length,'metadata array key');
    const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'metadata accessor');charge(key.length*2+8);out[key]=metadata(d.value,depth+1);
   }
   visiting.delete(value);return Object.freeze(out);
  }
  need(raw&&[Object.prototype,null].includes(Object.getPrototypeOf(raw)),'capture record');
  const keys=Reflect.ownKeys(raw);need(keys.length<=64&&keys.every(k=>typeof k==='string'),'capture fields');
  const values={};
  for(const key of keys){const d=Object.getOwnPropertyDescriptor(raw,key);need(d&&'value'in d&&d.enumerable,'capture accessor');need(!['__proto__','prototype','constructor'].includes(key),'capture key');values[key]=d.value;}
  need(values.identity===identity&&integer(values.nextUpdate,1),'capture identity/boundary');
  for(const key of ['stateBytes','presentationBytes']){
   const b=values[key];need(b&&Object.getPrototypeOf(b)===Uint8Array.prototype,'fixed bytes');
   const buffer=typedBuffer.call(b),size=typedLength.call(b);
   need(Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&Reflect.ownKeys(buffer).length===0&&!resizable?.call(buffer)&&size>0&&typedOffset.call(b)===0&&size===bufferLength.call(buffer),'owned byte extent');
   totalBytes+=size;need(totalBytes<=maxCaptureBytes,'capture capacity');
  }
  need(typedBuffer.call(values.stateBytes)!==typedBuffer.call(values.presentationBytes),'distinct capture buffers');
  const result={};
  for(const key of keys){charge(key.length*2+8);result[key]=['stateBytes','presentationBytes'].includes(key)?new Uint8Array(typedBuffer.call(values[key])):metadata(values[key]);}
  return {capture:Object.freeze(result),size:totalBytes+metadataBytes};
 }
 function drop(entry){
  if(entries.get(entry.nextUpdate)===entry)entries.delete(entry.nextUpdate);
  entry.retained=false;
  if(entry.pins===0){all.delete(entry);ownedBytes-=entry.size;entry.capture=null;}
 }
 function victim(){
  const sorted=[...entries.values()].sort((a,b)=>a.nextUpdate-b.nextUpdate);
  // Preserve the earliest and newest anchors when possible. Thin the closest
  // interior neighbor gap first, with oldest boundary as a deterministic tie.
  const candidates=sorted.filter(e=>e.pins===0);if(!candidates.length)return null;
  const interior=candidates.filter(e=>e!==sorted[0]&&e!==sorted.at(-1));
  if(interior.length)return interior.reduce((best,e)=>{
   const at=sorted.indexOf(e),gap=sorted[at+1].nextUpdate-sorted[at-1].nextUpdate;
   return !best||gap<best.gap?{entry:e,gap}:best;
  },null).entry;
  return candidates[0];
 }
 function accept(token,raw,{provisional=false}={}){
  if(retired||!reservations.has(token))return false;
  try{
   need(typeof provisional==='boolean','provisional flag');const owned=own(raw),nextUpdate=owned.capture.nextUpdate;
   const duplicate=entries.get(nextUpdate);if(duplicate?.pins)return false;
   // Check whether reclaimable space exists before evicting anything. A failed
   // insertion must not throw away useful anchors when all space is pinned.
   const pinned=[...all].filter(e=>e.pins>0);
   if(pinned.length+1>maxEntries||pinned.reduce((n,e)=>n+e.size,0)+owned.size>maxBytes)return false;
   if(duplicate)drop(duplicate);
   while(all.size>=maxEntries||ownedBytes+owned.size>maxBytes){const e=victim();if(!e)return false;drop(e);}
   const entry={id:++sequence,nextUpdate,capture:owned.capture,size:owned.size,pins:0,retained:true,provisional};
   entries.set(nextUpdate,entry);all.add(entry);originals.set(raw,entry.id);originals.set(entry.capture,entry.id);ownedBytes+=entry.size;return true;
  }catch{return false;}finally{cancel(token);}
 }
 function pin(target){
  if(retired||!integer(target))return null;
  let entry=null;for(const e of entries.values())if(!e.provisional&&e.nextUpdate<=target&&(!entry||e.nextUpdate>entry.nextUpdate))entry=e;
  if(!entry)return null;entry.pins++;let released=false;
  return Object.freeze({get capture(){return released?null:entry.capture;},release(){
   if(released)return;released=true;if(retired)return;entry.pins--;
   if(!entry.retained&&entry.pins===0){all.delete(entry);ownedBytes-=entry.size;entry.capture=null;}
  }});
 }
 function remove(capture){
  const id=capture&&typeof capture==='object'?originals.get(capture):undefined;
  for(const e of entries.values())if(e.id===id){drop(e);return true;}return false;
 }
 function admitProvisional(){if(!retired)for(const e of entries.values())e.provisional=false;}
 function retire(){
  if(retired)return;retired=true;
  for(const e of all){e.capture=null;e.pins=0;e.retained=false;}
  entries.clear();all.clear();reservations.clear();ownedBytes=0;reservedBytes=0;
 }
 const inspect=()=>Object.freeze({retired,entries:entries.size,ownedBytes,reservedBytes,reservations:reservations.size,
  pins:[...all].reduce((n,e)=>n+e.pins,0),provisionalEntries:[...entries.values()].filter(e=>e.provisional).length});
 return Object.freeze({reserve,cancel,accept,pin,remove,admitProvisional,retire,inspect});
}
