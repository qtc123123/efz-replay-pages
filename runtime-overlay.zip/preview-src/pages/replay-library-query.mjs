import {replayFilename} from './replay-filename.mjs';

const PAGE_SIZE=48;
export const DEFAULT_FILTERS=Object.freeze({p1Player:null,p2Player:null,p1Character:null,p2Character:null,stage:null,format:null,rounds:'any',duration:'any'});
const integer=(value,min=0)=>Number.isSafeInteger(value)&&value>=min;
const compare=(a,b)=>a<b?-1:a>b?1:0;
const validEntry=entry=>entry&&typeof entry==='object'&&typeof entry.name==='string'&&Array.isArray(entry.path)&&entry.path.every(part=>typeof part==='string');
const inFolder=(entry,folder)=>validEntry(entry)&&folder.every((part,index)=>entry.path[index]===part);
const duration=entry=>integer(entry.frames,1)?entry.frames:null;
const rounds=entry=>integer(entry.roundsPlayed)?entry.roundsPlayed:null;
const size=entry=>integer(entry.size)?entry.size:null;

/** Exact parser strings, scoped independently of all active view predicates.
 * Code-point sorting never folds case or normalizes/merges Unicode nicknames. */
export function playerOptions(entries,folder=[]){
 const p1=new Set(),p2=new Set();
 for(const entry of entries){if(!inFolder(entry,folder))continue;const parsed=replayFilename(entry.name);if(parsed){p1.add(parsed.players[0]);p2.add(parsed.players[1]);}}
 return {p1:[...p1].sort(compare),p2:[...p2].sort(compare)};
}

function durationMatches(value,bucket){
 if(bucket==='any')return true;
 if(bucket==='unknown')return value===null;
 if(value===null)return false;
 if(bucket==='known')return true;
 if(bucket==='lt1')return value<3840;
 if(bucket==='1to3')return value>=3840&&value<11520;
 if(bucket==='3to5')return value>=11520&&value<19200;
 if(bucket==='ge5')return value>=19200;
 return false;
}
function roundsMatch(value,bucket){
 if(bucket==='any')return true;
 if(bucket==='unknown')return value===null;
 if(value===null)return false;
 if(bucket==='known')return true;
 if(bucket==='ge5')return value>=5;
 return ['0','1','2','3','4'].includes(bucket)&&value===Number(bucket);
}
function matches(entry,filters){
 if(filters.p1Player!==null||filters.p2Player!==null){const parsed=replayFilename(entry.name);if(!parsed||filters.p1Player!==null&&parsed.players[0]!==filters.p1Player||filters.p2Player!==null&&parsed.players[1]!==filters.p2Player)return false;}
 if(filters.p1Character!==null&&entry.characters?.[0]!==filters.p1Character)return false;
 if(filters.p2Character!==null&&entry.characters?.[1]!==filters.p2Character)return false;
 if(filters.stage!==null&&entry.stage!==filters.stage)return false;
 if(filters.format!==null&&entry.format!==filters.format)return false;
 return durationMatches(duration(entry),filters.duration)&&roundsMatch(rounds(entry),filters.rounds);
}
function date(entry){
 const recordedAt=replayFilename(entry.name)?.recordedAt;
 // Compare validated local calendar fields, never parse in the machine timezone.
 return recordedAt?(recordedAt.length===16?recordedAt+':00':recordedAt):null;
}
function sortFiles(files,sort){
 const [metric,direction]=String(sort).split('-');
 const value={date,duration,rounds,size,name:entry=>entry.name}[metric];
 if(!value||!['asc','desc'].includes(direction))return files;
 const sign=direction==='desc'?-1:1;
 return files.map((entry,index)=>({entry,index,value:value(entry)})).sort((a,b)=>{
  // Unknown always trails known values; reversing must never reverse the ties.
  if(a.value===null||b.value===null)return a.value===b.value?a.index-b.index:a.value===null?1:-1;
  const order=metric==='name'?a.value.localeCompare(b.value):compare(a.value,b.value);
  return order*sign||a.index-b.index;
 }).map(item=>item.entry);
}

/** Pure view projection only: returned file references remain in library custody.
 * `total` preserves the legacy count of listed files before pagination;
 * `matched` counts matching files throughout the current subtree (even folders).
 * Sorting alone preserves grouping. Search/predicates flatten only this subtree.
 * Callers reset page on control changes; this function clamps the requested page.
 */
export function queryLibrary(entries,folder=[],{query='',page=0,filters=DEFAULT_FILTERS,sort='playlist'}={}){
 const active={};for(const [key,value] of Object.entries(DEFAULT_FILTERS))active[key]=filters?.[key]===undefined?value:filters[key];
 const search=String(query).toLocaleLowerCase(),hasFilters=Object.keys(DEFAULT_FILTERS).some(key=>active[key]!==DEFAULT_FILTERS[key]),recursive=!!search||hasFilters;
 const folders=new Map(),files=[];let matched=0;
 for(const entry of entries){
  if(!inFolder(entry,folder))continue;
  if(search&&![...entry.path,entry.name].join('/').toLocaleLowerCase().includes(search))continue;
  if(!matches(entry,active))continue;
  matched++;
  if(entry.path.length>folder.length&&!recursive){const name=entry.path[folder.length];folders.set(name,(folders.get(name)??0)+1);}else files.push(entry);
 }
 const sortedFolders=[...folders].sort(([a],[b])=>a.localeCompare(b)).map(([name,count])=>({name,count,path:[...folder,name]})),sortedFiles=sortFiles(files,sort);
 const totalPages=Math.max(1,Math.ceil((sortedFolders.length+sortedFiles.length)/PAGE_SIZE)),requestedPage=Number.isFinite(page)?Math.floor(page):0,selectedPage=Math.min(Math.max(0,requestedPage),totalPages-1),start=selectedPage*PAGE_SIZE,end=start+PAGE_SIZE;
 return {folders:sortedFolders.slice(start,end),files:sortedFiles.slice(Math.max(0,start-sortedFolders.length),Math.max(0,end-sortedFolders.length)),total:sortedFiles.length,totalPages,page:selectedPage,matched,canReorder:sort==='playlist'&&!recursive};
}

/** Compact binary byte units; the UI supplies localized exact bytes in its title. */
export function formatReplaySize(bytes){
 if(!integer(bytes))return '-';
 const units=['B','KiB','MiB','GiB','TiB','PiB'];let value=bytes,unit=0;
 while(value>=1024&&unit<units.length-1){value/=1024;unit++;}
 return (unit?value.toFixed(1).replace(/\.0$/,''):String(value))+' '+units[unit];
}
