import {inspectPageReplay,createPageReplayCatalog,yieldReplayTask} from './replay-session.mjs';
import {validateLocalTapeEnd} from '../local-replay-inspector.mjs';
import {validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {validateGameTranslation} from './game-translation.mjs';
import {createNativeBranchProjection} from './native-branch-projection.mjs';
import {recoverNativeCrtSeed} from './native-rng-recovery.mjs';
import {scanRecoveredNative} from './native-takeover-qualification.mjs';
const need=(ok,s)=>{if(!ok)throw Error('Native takeover preparation: '+s);};
const integer=(v,min=0,max=0xffffffff)=>Number.isSafeInteger(v)&&!Object.is(v,-0)&&v>=min&&v<=max;
const hash=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
function record(v,required,optional=[]){need(v&&[Object.prototype,null].includes(Object.getPrototypeOf(v)),'plain record');const keys=Reflect.ownKeys(v);need(required.every(k=>keys.includes(k))&&keys.every(k=>required.includes(k)||optional.includes(k)),'record fields');const out={};for(const k of keys){const d=Object.getOwnPropertyDescriptor(v,k);need(d&&'value'in d&&d.enumerable,'accessor');out[k]=d.value;}return out;}
const typed=Object.getPrototypeOf(Uint8Array.prototype),getLength=Object.getOwnPropertyDescriptor(typed,'length').get,getBuffer=Object.getOwnPropertyDescriptor(typed,'buffer').get,getResizable=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get;
function copyTyped(v,C){const n=getLength.call(v),out=new C(n);C.prototype.set.call(out,v);return out;}
function keyCopy(v){if(typeof v==='string'){need(v.length<=256,'key');return v;}need(Object.getPrototypeOf(v??{})===Uint8Array.prototype&&getLength.call(v)===32,'key');const b=getBuffer.call(v);need(Object.getPrototypeOf(b)===ArrayBuffer.prototype&&!getResizable?.call(b),'key buffer');return copyTyped(v,Uint8Array);}
const wipe=v=>{if(v instanceof Uint8Array&&getLength.call(v))Uint8Array.prototype.fill.call(v,0);};
export async function nativeRecordingHash(bytes){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),n=>n.toString(16).padStart(2,'0')).join('');}
function projectionCopy(raw,frames){createNativeBranchProjection(raw,frames);const out={schema:raw.schema};for(const k of ['counts','masks','auxCounts','auxWords'])out[k]=copyTyped(raw[k],k==='auxWords'?Uint16Array:Uint8Array);return Object.freeze(out);}
export function validateNativeRecovery(value,{frames,engineHash,recordingHash}={}){
 const p=record(value,['profile','seed','recordingHash','engineHash','projection']);need(p.profile==='efz402-native-recovered/1'&&integer(p.seed,0,0x7fffffff)&&hash(p.recordingHash)&&hash(p.engineHash),'recovered identity');
 need(engineHash===undefined||p.engineHash===engineHash,'engine identity');need(recordingHash===undefined||p.recordingHash===recordingHash,'recording identity');need(integer(frames,1,1000000),'frame extent');return Object.freeze({...p,projection:projectionCopy(p.projection,frames)});
}
function ownPayload(value){
 const p=record(value,['replayBytes','encryptedManifest','assetRoot','key','nativeFrames','nativeTapeOffset'],['winRounds','gameTranslation']);const meta=inspectPageReplay(p.replayBytes,p.winRounds);need(meta.format==='native-tape','native tape required');need(integer(p.nativeFrames,1,1000000),'prepared extent');validateLocalTapeEnd(meta,p.nativeTapeOffset);need(typeof p.assetRoot==='string'&&p.assetRoot.length<=4096,'asset root');
 const owned={replayBytes:copyTyped(p.replayBytes,Uint8Array),encryptedManifest:validateEncryptedAssetManifest(p.encryptedManifest),assetRoot:p.assetRoot,key:keyCopy(p.key),winRounds:meta.initialization.winRounds,nativeFrames:p.nativeFrames,nativeTapeOffset:p.nativeTapeOffset};if(Object.hasOwn(p,'gameTranslation'))owned.gameTranslation=validateGameTranslation(p.gameTranslation,owned.encryptedManifest);return {meta,owned};
}
export async function discoverNativeSeed(meta,engine,{maxUpdates=1000000,clock=()=>performance.now(),yieldTask=yieldReplayTask,cancelled=()=>false,onProgress=()=>{}}={}){
 const observations=[],started=clock();let next=0,last=0;
 while(next<maxUpdates){need(!cancelled(),'cancelled');need(clock()-started<=180000,'discovery deadline');const result=await engine.advance(next);need(!cancelled(),'cancelled');need(result&&['advanced','end'].includes(result.kind)&&result.nextFrame===++next,'discovery boundary');const evidence=engine.nativeRngEvidence();need(evidence.nextUpdate===next&&integer(evidence.xCalls)&&Array.isArray(evidence.reads)&&evidence.reads.length<=4096,'discovery evidence');
  for(const r of evidence.reads){need(integer(r.ordinal,1)&&r.ordinal>last&&r.ordinal<=evidence.xCalls&&integer(r.value,0,32767),'discovery RNG order');last=r.ordinal;observations.push({ordinal:r.ordinal,value:r.value});const found=recoverNativeCrtSeed(observations);if(found.kind==='candidate'||found.reason==='unknown-initial-callgap'||observations.length===32)return found;}
  if(result.kind==='end'||engine.inspect().tapeOffset===meta.nativeEnd)return recoverNativeCrtSeed(observations);
  if(next%16===0){onProgress(next);await yieldTask();}
 }
 return Object.freeze({kind:'unavailable',reason:'discovery-capacity'});
}
export function installNativeTakeoverPreparationWorker(scope,{createRecoveredNativeReplay,engineHash,fetcher=globalThis.fetch,clock,yieldTask}={}){
 need(typeof createRecoveredNativeReplay==='function'&&hash(engineHash),'worker dependencies');let started=false,stopped=false,assets=null,engine=null,active=null;
 async function run(raw){let output,owned;try{
  const p=record(raw,['type','phase','engineHash','payload'],['seed']);need(p.type==='prepare-native-takeover'&&['discover','qualify'].includes(p.phase)&&p.engineHash===engineHash,'worker request');need(p.phase==='discover'?p.seed===undefined:integer(p.seed,0,0x7fffffff),'phase seed');const admitted=ownPayload(p.payload);owned=admitted.owned;wipe(p.payload.key);const recordingHash=await nativeRecordingHash(owned.replayBytes);if(stopped)return;
  assets=createPageReplayCatalog(owned.encryptedManifest,admitted.meta.initialization,owned.assetRoot,owned.key,fetcher,scope.location?.href,owned.gameTranslation);wipe(owned.key);await assets.loadForSimulation();if(stopped)return;
  engine=await createRecoveredNativeReplay(admitted.meta.initialization,assets,admitted.meta.nativeTape(),{seed:p.phase==='discover'?1:p.seed});if(stopped)return;
  const progress=nextFrame=>{if(!stopped)scope.postMessage({type:'native-takeover-progress',phase:p.phase,nextFrame});};
  if(p.phase==='discover'){const r=await discoverNativeSeed(admitted.meta,engine,{maxUpdates:owned.nativeFrames,clock,yieldTask,cancelled:()=>stopped,onProgress:progress});output={type:'native-takeover-result',phase:p.phase,engineHash,recordingHash,result:r};}
  else{const r=await scanRecoveredNative(admitted.meta,engine,{seed:p.seed,recordingHash,engineHash,maxUpdates:owned.nativeFrames,clock,yieldTask,cancelled:()=>stopped,onProgress:progress});need(r.frames===owned.nativeFrames&&r.nativeTapeOffset===owned.nativeTapeOffset,'prepared extent changed');output={type:'native-takeover-result',phase:p.phase,engineHash,recordingHash,result:{kind:'qualified',...r}};}
 }catch(e){output={type:'native-takeover-error',message:String(e?.message??e).slice(0,500)};}
 finally{wipe(owned?.key);try{engine?.dispose();}catch(e){output={type:'native-takeover-error',message:String(e?.message??e).slice(0,500)};}finally{try{assets?.dispose();}catch(e){output={type:'native-takeover-error',message:String(e?.message??e).slice(0,500)};}engine=null;assets=null;}}
 if(!stopped&&output)scope.postMessage(output);
 }
 scope.onmessage=({data})=>{if(started||stopped)return;started=true;active=run(data);};return Object.freeze({async dispose(){stopped=true;if(!engine)assets?.dispose();await active;}});
}
/** Each phase owns a fresh Worker. Completion waits for retirement, including
 * discovery, before another phase can acquire the retained recording/key copy. */
export function createNativeTakeoverPreparation(createWorker,payload,{engineHash,onProgress=()=>{},timeoutMs=180000}={}){
 need(typeof createWorker==='function'&&hash(engineHash)&&integer(timeoutMs,1,600000),'client dependencies');const {meta,owned}=ownPayload(payload);let stopped=false,current=null,closing=Promise.resolve();
 function phase(name,seed,recordingHash){return new Promise((resolve,reject)=>{
  if(stopped){reject(Error('Native takeover preparation cancelled'));return;}let worker;try{worker=createWorker('native-takeover-prepare');need(worker&&typeof worker.postMessage==='function','worker factory');}catch(e){reject(e);return;}
  let finished=false,lastProgress=0,timer;
  const finish=(error,value)=>{if(finished)return closing;finished=true;clearTimeout(timer);worker.removeEventListener('message',receive);worker.removeEventListener('error',broken);let retired;try{retired=Promise.resolve(worker.terminate());}catch(e){retired=Promise.reject(e);}closing=retired.then(()=>{if(current?.worker===worker)current=null;if(error||stopped)reject(error??Error('Native takeover preparation cancelled'));else resolve(value);},cause=>{reject(cause);throw cause;});closing.catch(()=>{});return closing;};
  const broken=()=>finish(Error('Native takeover preparation Worker failed'));
  const receive=({data})=>{if(finished||stopped)return;try{const m=record(data,['type'],['phase','nextFrame','engineHash','recordingHash','result','message']);if(m.type==='native-takeover-progress'){record(m,['type','phase','nextFrame']);need(m.phase===name&&integer(m.nextFrame,lastProgress,owned.nativeFrames),'progress');lastProgress=m.nextFrame;onProgress({phase:name,nextFrame:m.nextFrame});return;}if(m.type==='native-takeover-error'){record(m,['type','message']);need(typeof m.message==='string'&&m.message.length<=500,'error');finish(null,{kind:'unavailable',reason:m.message});return;}record(m,['type','phase','engineHash','recordingHash','result']);need(m.type==='native-takeover-result'&&m.phase===name&&m.engineHash===engineHash&&m.recordingHash===recordingHash,'result identity');finish(null,m.result);}catch(e){finish(e);}};
  current={worker,finish};worker.addEventListener('message',receive);worker.addEventListener('error',broken);timer=setTimeout(()=>finish(Error('Native takeover preparation timed out')),timeoutMs);
  let copy;try{copy=ownPayload(owned).owned;worker.postMessage({type:'prepare-native-takeover',phase:name,engineHash,payload:copy,...seed===undefined?{}:{seed}},[copy.replayBytes.buffer,...copy.key instanceof Uint8Array?[copy.key.buffer]:[]]);}catch(e){finish(e);}finally{wipe(copy?.key);}
 });}
 const result=(async()=>{try{const recordingHash=await nativeRecordingHash(owned.replayBytes);if(stopped)throw Error('Native takeover preparation cancelled');const discovery=record(await phase('discover',undefined,recordingHash),['kind'],['seed','reason','observations','stateModulus','qualified']);need(discovery&&['candidate','unavailable'].includes(discovery.kind),'discovery result');if(discovery.kind==='unavailable'){need(typeof discovery.reason==='string'&&discovery.reason.length<=500,'unavailable reason');return Object.freeze({kind:'unavailable',reason:discovery.reason});}record(discovery,['kind','seed','observations','stateModulus','qualified']);need(integer(discovery.seed,0,0x7fffffff)&&integer(discovery.observations,3,32)&&discovery.stateModulus===2147483648&&discovery.qualified===false,'candidate metadata');const receipt=await phase('qualify',discovery.seed,recordingHash);if(receipt?.kind==='unavailable'){need(typeof receipt.reason==='string'&&receipt.reason.length<=500,'unavailable reason');return Object.freeze(receipt);}
  const r=record(receipt,['kind','schema','profile','seed','recordingHash','engineHash','frames','nativeTapeOffset','rngReads','rngCalls','completion','projection']);need(r.kind==='qualified'&&r.schema==='efz-native-recovered-scan/1'&&r.seed===discovery.seed&&r.frames===owned.nativeFrames&&r.nativeTapeOffset===owned.nativeTapeOffset&&integer(r.rngReads,3)&&integer(r.rngCalls,r.rngReads)&&['natural-end','recording-ended'].includes(r.completion),'qualified receipt');validateLocalTapeEnd(meta,r.nativeTapeOffset);const recovery=validateNativeRecovery({profile:r.profile,seed:r.seed,recordingHash:r.recordingHash,engineHash:r.engineHash,projection:r.projection},{frames:r.frames,engineHash,recordingHash});return Object.freeze({...r,projection:recovery.projection});
 }finally{wipe(owned.key);}})();
 return Object.freeze({result,async dispose(){stopped=true;wipe(owned.key);if(current)await current.finish(Error('Native takeover preparation cancelled'));else await closing;}});
}
