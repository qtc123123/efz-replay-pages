/** Pages-only read-only projection of the pinned JS actor and PAT collision
 * fields. Coordinates reproduce r8, not a sprite bounding box or native-address
 * snapshot. See TRAINING_PROJECTION.md for source identities and limitations. */
export const REPLAY_TRAINING_SCHEMA='efz-local-training/1';
export const REPLAY_TRAINING_LIMITS=Object.freeze({entities:130,rectanglesPerEntity:10,bytes:1024*1024});
const need=(ok,message)=>{if(!ok)throw Error('Replay training: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
const finite=n=>typeof n==='number'&&Number.isFinite(n)&&Math.abs(n)<=2147483647;
function record(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain record');const own=Reflect.ownKeys(value);need(own.length===keys.length&&keys.every(k=>own.includes(k)),'fields');
 const out={};for(const k of keys){const d=Object.getOwnPropertyDescriptor(value,k);need(d&&'value'in d&&d.enumerable,'accessor refused');out[k]=d.value;}return out;
}
function array(value,max,exact=null){need(Array.isArray(value)&&value.length<=max&&(exact===null||value.length===exact)&&Reflect.ownKeys(value).length===value.length+1,'array extent');
 return Array.from({length:value.length},(_,i)=>{const d=Object.getOwnPropertyDescriptor(value,String(i));need(d&&'value'in d&&d.enumerable,'array accessor');return d.value;});}
const PLAYER_KEYS=['character','state','frame','timer','x','y','facing','comboCount','comboDisplay','comboDamage','comboTimer','maxCombo','maxComboDamage','proration','displayProration','untech','hitstop','freeze','guardGauge'];
const ENTITY_KEYS=['side','slot','pattern','frame','facing','x','y','attackFlags','defenseFlags','attackActive','hurtActive','rectangles'];
export function emptyReplayTraining(nextUpdate=0){need(integer(nextUpdate,0,1000000),'boundary');return Object.freeze({schema:REPLAY_TRAINING_SCHEMA,nextUpdate,sourceUpdate:null,availability:'none',players:null,prepared:null});}
function player(p){return Object.freeze({character:p.id,state:p.state,frame:p.frame,timer:p.timer,x:p.x,y:p.y,facing:p.facing,
 comboCount:p.comboCount,comboDisplay:p.comboDisplay,comboDamage:p.comboDamage,comboTimer:p.comboTimer,maxCombo:p.maxCombo,maxComboDamage:p.maxComboDamage,
 proration:p.proration,displayProration:p.dblF8,untech:p.hitstun,hitstop:p.hitstop,freeze:p.freeze,guardGauge:p.guardGauge});}
/** r8 original signed-origin transform: ±0.5 precedes truncation. */
function rect(raw,frame,x,y,facing,camera,kind,index){
 const top=Math.trunc(y-frame.offsetY+raw.top)+210+camera.y,bottom=Math.trunc(y-frame.offsetY+raw.bottom)+210+camera.y;
 const left=(facing===1?Math.trunc(x-.5-frame.offsetX+raw.left):Math.trunc(x+.5+frame.offsetX-raw.right))+camera.x;
 const right=(facing===1?Math.trunc(x-.5-frame.offsetX+raw.right):Math.trunc(x+.5+frame.offsetX-raw.left))+camera.x;
 return right>left&&bottom>top?Object.freeze({kind,index,left,top,right,bottom}):null;
}
export function capturePreparedTraining(actors,camera,metadata){
 const ownedCamera=Object.freeze({x:camera.x,y:camera.y}),entities=[];
 function entity(owner,side,slot,p,pattern){
  const frame=owner.patterns[pattern]?.frames[p.frame],hit=owner.patterns[pattern]?.hits[p.frame];if(!frame||!hit)return;
  const rectangles=[],add=(raw,kind,index)=>{const r=rect(raw,frame,p.x,p.y,p.facing,ownedCamera,kind,index);if(r)rectangles.push(r);};
  if(slot===-1)add(hit.body,'body',0);
  hit.hurt.forEach((r,i)=>add(r,'hurt',i));hit.attack.forEach((r,i)=>add(r,'attack',i));
  entities.push(Object.freeze({side,slot,pattern,frame:p.frame,facing:p.facing,x:p.x,y:p.y,attackFlags:hit.attackFlags,defenseFlags:hit.defenseFlags,
   attackActive:slot===-1?owner.d168===0&&owner.w16c>0:p.hitState===0&&p.hitsLeft>0,hurtActive:!(hit.defenseFlags&32),rectangles:Object.freeze(rectangles)}));
 }
 actors.forEach((p,side)=>{if(!p)return;entity(p,side,-1,p,p.state);
  // The original aM/drawChildren traversal owns the ring order and liveness.
  let visited=0;for(let slot=p.childTail;slot!==p.childHead;slot=(slot+1)%64){need(++visited<=64,'projectile ring');if(p.childActive[slot])entity(p,side,slot,p.children[slot],p.children[slot].pattern);}
 });
 const hud=metadata.hud===undefined?{}:{hud:Object.freeze({visible:metadata.hud.visible,players:metadata.hud.players===null?null:Object.freeze(metadata.hud.players.map(p=>Object.freeze({...p})))})};
 return Object.freeze({...metadata,...hud,camera:ownedCamera,entities:Object.freeze(entities)});
}
export function captureReplayTraining(nextUpdate,actors,prepared,previous=emptyReplayTraining()){
 const live=actors.length===2&&actors.every(Boolean),players=live?Object.freeze(actors.map(player)):previous.players;
 return Object.freeze({schema:REPLAY_TRAINING_SCHEMA,nextUpdate,sourceUpdate:live?nextUpdate-1:previous.sourceUpdate,availability:live?'live':players?'last-live':'none',players,prepared});
}
export function validateReplayTraining(value,nextUpdate,initialization=null,image=null){
 const s=record(value,['schema','nextUpdate','sourceUpdate','availability','players','prepared']);
 need(s.schema===REPLAY_TRAINING_SCHEMA&&integer(nextUpdate,0,1000000)&&s.nextUpdate===nextUpdate,'boundary/schema');
 need(['none','live','last-live'].includes(s.availability),'availability');let players=null;
 if(s.availability==='none')need(s.sourceUpdate===null&&s.players===null,'absent actors');
 else{
  need(nextUpdate>0&&integer(s.sourceUpdate,0,nextUpdate-1)&&(s.availability==='live'?s.sourceUpdate===nextUpdate-1:s.sourceUpdate<nextUpdate-1),'actor origin');
  players=Object.freeze(array(s.players,2,2).map((raw,side)=>{const p=record(raw,PLAYER_KEYS);
   need(integer(p.character,0,24)&&(!initialization||p.character===initialization.characters[side]),'actor identity');
   need(p.facing===1||p.facing===-1,'actor facing');for(const k of PLAYER_KEYS.filter(k=>!['character','facing'].includes(k)))need(finite(p[k]),'actor '+k);
   need(integer(p.state,0,65535)&&integer(p.frame,0,65535),'actor animation');return Object.freeze(p);
  }));
 }
 let prepared=null;
 if(s.prepared!==null){
  const p=record(s.prepared,['originUpdate','renderOrdinal','phase','round','camera','entities',...(Object.hasOwn(s.prepared,'hud')?['hud']:[])]);
  if(p.hud!==undefined){const hud=record(p.hud,['visible','players']);need(typeof hud.visible==='boolean','HUD visibility');need(hud.players!==null||hud.visible===false,'absent HUD actors');const values=hud.players===null?null:Object.freeze(array(hud.players,2,2).map(value=>{const v=record(value,['hp','sp','rf']);need(typeof v.hp==='number'&&Number.isFinite(v.hp)&&v.hp>=-2147483648&&v.hp<=2147483647&&finite(v.sp)&&v.sp>=0&&v.sp<=3000&&finite(v.rf)&&v.rf>=0&&v.rf<=1000,'HUD values');return Object.freeze(v);}));p.hud=Object.freeze({visible:hud.visible,players:values});}
  need(integer(p.originUpdate,0,nextUpdate-1)&&integer(p.renderOrdinal,0,0xffffffff)&&integer(p.round,0,0xffffffff)&&['intro','round-transition','round-ko','combat','finish'].includes(p.phase),'prepared origin');
  if(image)need(['originUpdate','renderOrdinal','phase','round'].every(k=>p[k]===image[k]),'prepared image origin');
  const camera=record(p.camera,['x','y']);need(finite(camera.x)&&finite(camera.y),'camera');
  const keys=new Set(),entities=Object.freeze(array(p.entities,130).map(raw=>{const e=record(raw,ENTITY_KEYS);
   need(integer(e.side,0,1)&&integer(e.slot,-1,63)&&!keys.has(e.side+':'+e.slot),'entity identity');keys.add(e.side+':'+e.slot);
   need(integer(e.pattern,0,65535)&&integer(e.frame,0,65535)&&[-1,0,1].includes(e.facing)&&finite(e.x)&&finite(e.y),'entity pose');
   need(integer(e.attackFlags,0,65535)&&integer(e.defenseFlags,0,65535)&&typeof e.attackActive==='boolean'&&typeof e.hurtActive==='boolean','entity flags');
   const slots=new Set(),rectangles=Object.freeze(array(e.rectangles,10).map(raw=>{const r=record(raw,['kind','index','left','top','right','bottom']);
    need(['body','hurt','attack'].includes(r.kind)&&integer(r.index,0,r.kind==='body'?0:r.kind==='hurt'?4:3)&&!slots.has(r.kind+':'+r.index),'rectangle identity');slots.add(r.kind+':'+r.index);
    need(e.slot===-1||r.kind!=='body','projectile push refused');need(['left','top','right','bottom'].every(k=>finite(r[k]))&&r.right>r.left&&r.bottom>r.top,'rectangle extent');return Object.freeze(r);
   }));return Object.freeze({...e,rectangles});
  }));prepared=Object.freeze({...p,camera:Object.freeze(camera),entities});
 }else need(!image||nextUpdate===0,'prepared image missing');
 need(nextUpdate!==0||s.availability==='none'&&prepared===null,'initial boundary');
 return Object.freeze({...s,players,prepared});
}
