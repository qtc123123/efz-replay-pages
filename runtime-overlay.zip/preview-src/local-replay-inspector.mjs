// Local file admission. The service's strict Revival inspector is deliberately
// unchanged: native tapes are a separate input authority, not generated pairs.
import {inspectExtendedReplay} from './revival.mjs';
import {integer} from './spectator-profile.mjs';
import {validateLocalReplayPair,LOCAL_REPLAY_PROFILE,LOCAL_TAPE_PROFILE,validateLocalReplayInitialization,validateLocalTapeInitialization} from './local-replay-profile.mjs';

const FOOTERS=Object.freeze([
 Object.freeze({bytes:480,words:Object.freeze([0,9999,0,0,0,0,0,0])}),
 Object.freeze({bytes:240,words:Object.freeze([0,0,0,9999])})
]);
const need=(ok,message)=>{if(!ok)throw Error('Replay: '+message);};
function matchesFooter(view,start,footer){
 if(start<12||start%2)return false;
 for(let i=0;i<footer.bytes/2;i++)if(view.getUint16(start+2*i,true)!==footer.words[i%footer.words.length])return false;
 return true;
}
function initialization(view,profile,seed,winRounds){
 need(view.getUint16(4,true)===104,'unsupported marker104 header');
 const value={profile,characters:[view.getUint16(0,true),view.getUint16(2,true)],stage:view.getUint16(6,true),
  palettes:[view.getUint16(8,true),view.getUint16(10,true)],seed,winRounds};
 return profile===LOCAL_TAPE_PROFILE?validateLocalTapeInitialization(value):validateLocalReplayInitialization(value);
}

export function inspectLocalReplay(input,winRounds=2){
 need(input instanceof Uint8Array&&input.length>=14&&input.length<=64*1024*1024&&input.length%2===0,'recording extent (no battle data or incomplete word)');
 const bytes=new Uint8Array(input),view=new DataView(bytes.buffer);
 let nativeEnd=bytes.length,extensionOffset=null,paddingBytes=0;
 if(view.getInt32(bytes.length-4,true)===-1){
  need(bytes.length>=30,'extension extent');
  extensionOffset=view.getUint32(bytes.length-8,true);
  need(extensionOffset>=252&&extensionOffset<=bytes.length-16&&extensionOffset%2===0,'extension extent');
  const seed=view.getUint32(extensionOffset,true),words=view.getUint32(extensionOffset+4,true);
  need(words%2===0&&extensionOffset+16+words*2===bytes.length,'paired extension extent equation');
  const footer=FOOTERS.find(item=>extensionOffset>=12+item.bytes&&matchesFooter(view,extensionOffset-item.bytes,item));
  need(footer,'extension padding mismatch');paddingBytes=footer.bytes;nativeEnd=extensionOffset-paddingBytes;
  if(seed!==0||words!==0){
   integer(seed,1,2147483646,'saved RNG state');need(words>0,'paired extension extent equation');
   const init=initialization(view,LOCAL_REPLAY_PROFILE,seed,winRounds),frames=words/2,pairsOffset=extensionOffset+8;
   need(frames<=1000000,'recording capacity');
   // Reuse the existing strict path for the current format. The additional
   // layout is admitted only by its complete byte pattern and extent equation.
   const modern=paddingBytes===480?inspectExtendedReplay(bytes):null;
   const pair=modern?frame=>modern.pair(frame):frame=>{
    integer(frame,0,frames-1,'frame outside recording');
    return [view.getUint16(pairsOffset+4*frame,true),view.getUint16(pairsOffset+4*frame+2,true)];
   };
   for(let frame=0;frame<frames;frame++)validateLocalReplayPair(pair(frame));
   return Object.freeze({format:'revival-pairs',seed,words,frames,extensionOffset,paddingBytes,nativeEnd,pairsOffset,headerBytes:12,
    initialization:init,pair,nativeTape:()=>bytes.slice(0,nativeEnd)});
  }
 }
 need(nativeEnd>=14,'recording extent (no battle data)');
 const init=initialization(view,LOCAL_TAPE_PROFILE,1,winRounds);
 return Object.freeze({format:'native-tape',frames:null,extensionOffset,paddingBytes,nativeEnd,headerBytes:12,
  initialization:init,nativeTape:()=>bytes.slice(0,nativeEnd)});
}

/** Validate trailing bytes only after a genuine match finish. */
export function validateLocalTapeEnd(meta,offset){
 need(meta?.format==='native-tape'&&Number.isSafeInteger(offset)&&offset>=12&&offset%2===0,'native terminal offset');
 const tape=meta.nativeTape();need(offset<=tape.length,'native terminal extent');
 if(offset===tape.length)return offset;
 const remainder=tape.length-offset,view=new DataView(tape.buffer);
 need(meta.extensionOffset===null&&FOOTERS.some(footer=>remainder===footer.bytes&&matchesFooter(view,offset,footer)),
  'recording has unused data after the match; check the rounds-to-win setting');
 return offset;
}

