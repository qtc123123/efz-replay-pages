// Local-only bounded fork of graph-codec.mjs; service implementation stays unchanged.
// Identical wire semantics, with a 512 KiB graph/buffer ceiling before allocation.
// Versioned data graph. Field IDs/order and receiver types come only from the
// checked-in schema. No constructors, executable payloads or sender references.
const LIMIT=512*1024, MAX_OBJECTS=4096, MAX_BUFFER=512*1024;
const ARRAYS={Uint8Array,Int8Array,Uint16Array,Int16Array,Uint32Array,Int32Array,Float64Array,Float32Array};
const enc=new TextEncoder(),dec=new TextDecoder('utf-8',{fatal:true});
function need(ok,field){if(!ok)throw Error('CHECKPOINT_GRAPH: '+field);}
class Writer {
 constructor(){this.bytes=new Uint8Array(256*1024);this.view=new DataView(this.bytes.buffer);this.pos=0;}
 room(n){need(Number.isSafeInteger(n)&&n>=0&&this.pos+n<=LIMIT,'extent');if(this.pos+n>this.bytes.length){const b=new Uint8Array(Math.min(LIMIT,Math.max(this.bytes.length*2,this.pos+n)));b.set(this.bytes);this.bytes=b;this.view=new DataView(b.buffer);}}
 u8(n){this.room(1);this.view.setUint8(this.pos++,n);}
 u16(n){this.room(2);this.view.setUint16(this.pos,n,true);this.pos+=2;}
 u32(n){this.room(4);this.view.setUint32(this.pos,n,true);this.pos+=4;}
 f64(n){this.room(8);this.view.setFloat64(this.pos,n,true);this.pos+=8;}
 raw(b){this.room(b.length);this.bytes.set(b,this.pos);this.pos+=b.length;}
 done(){return this.bytes.slice(0,this.pos);}
}
class Reader {
 constructor(bytes){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.pos=0;}
 room(n){need(n>=0&&this.pos+n<=this.bytes.length,'truncated');}
 u8(){this.room(1);return this.view.getUint8(this.pos++);}
 u16(){this.room(2);const v=this.view.getUint16(this.pos,true);this.pos+=2;return v;}
 u32(){this.room(4);const v=this.view.getUint32(this.pos,true);this.pos+=4;return v;}
 f64(){this.room(8);const v=this.view.getFloat64(this.pos,true);this.pos+=8;need(Number.isFinite(v),'nonfinite');return v;}
 raw(n){this.room(n);const v=this.bytes.subarray(this.pos,this.pos+n);this.pos+=n;return v;}
}
function environment(schema,bindings,hash){
 need(schema?.format==='efz-battle-graph/1'&&/^[a-f0-9]{64}$/.test(hash),'schema');
 need(new Uint8Array(new Uint16Array([1]).buffer)[0]===1,'numeric policy requires little endian');
 const names=['$buffer',...Object.keys(schema.types)],types=[{kind:'buffer'},...Object.values(schema.types)];
 need(names.length<65536&&schema.types[schema.root],'types');
 return {names,types,ids:new Map(names.map((n,i)=>[n,i])),bindings,hash,schema};
}
function own(object,key){const d=Object.getOwnPropertyDescriptor(object,key);need(d&&'value'in d&&d.enumerable,'field '+key);return d.value;}
function fieldShape(object,fields){const keys=Reflect.ownKeys(object);need(keys.length===fields.length&&keys.every(k=>fields.includes(k)),'unknown/missing field');}
function prototype(env,type){const p=env.bindings.prototypes[type.prototype];need(p!==undefined,'receiver prototype');return p;}
function arrayDef(type,index){return type.items?.[index]??type.element;}
function arrayLength(type,length){need(Number.isSafeInteger(length)&&length===(type.items?.length??type.length),'array length');}
function scalar(value,def){
 if(def==='f64'||def==='host-f64')need(typeof value==='number'&&Number.isFinite(value),'number');
 else if(def==='bool')need(typeof value==='boolean','boolean');
 else if(def==='string')need(typeof value==='string'&&enc.encode(value).length<=256&&dec.decode(enc.encode(value))===value,'string');
 else if(def==='null')need(value===null,'null');
 else need(false,'field schema');
}

/** All graph enumeration is constrained by explicit schema fields and extents. */
export function encodeGraph(root,schema,bindings,hash){
 const env=environment(schema,bindings,hash),objects=[],seen=new Map();
 function add(value,name){
  need(value!==null&&typeof value==='object','reference');need(env.ids.has(name),'reference type');
  if(seen.has(value)){const old=seen.get(value);need(old.name===name,'incompatible alias');return old.id;}
  need(objects.length<MAX_OBJECTS,'object count');const id=objects.length+1;seen.set(value,{id,name});objects.push({value,name});return id;
 }
 function scan(value,def){
  if(typeof def==='string'){scalar(value,def);return;}
  if(def.nullable&&value===null)return;
  if(def.external){need(Object.hasOwn(bindings.resources,def.external)&&value===bindings.resources[def.external],'resource binding');return;}
  need(def.ref,'field schema');add(value,def.ref);
 }
 add(root,schema.root);
 for(let index=0;index<objects.length;index++){
  const {value,name}=objects[index],type=env.types[env.ids.get(name)];
  if(type.kind==='buffer'){need(Object.getPrototypeOf(value)===ArrayBuffer.prototype&&value.byteLength<=MAX_BUFFER&&Reflect.ownKeys(value).length===0,'buffer');continue;}
  if(type.kind==='typed'){
   const C=ARRAYS[type.array];need(C&&Object.getPrototypeOf(value)===C.prototype&&value.length===type.length,'typed extent/type');
   need(Reflect.ownKeys(value).length===value.length,'typed properties');
   if(C===Float64Array||C===Float32Array)need(value.every(Number.isFinite),'nonfinite typed value');
   add(value.buffer,'$buffer');continue;
  }
  if(type.kind==='array'){
   need(Array.isArray(value)&&Object.getPrototypeOf(value)===Array.prototype,'array');arrayLength(type,value.length);
   need(Reflect.ownKeys(value).length===value.length+1,'array fields');for(let i=0;i<value.length;i++)scan(own(value,String(i)),arrayDef(type,i));continue;
  }
  need(type.kind==='record'&&Object.getPrototypeOf(value)===prototype(env,type),'record prototype');
  const fields=Object.keys(type.fields);fieldShape(value,fields);for(const key of fields)scan(own(value,key),type.fields[key]);
 }
 const w=new Writer();w.raw(enc.encode('EFZC'));w.u16(1);w.u16(0);w.raw(Uint8Array.from(hash.match(/../g),v=>parseInt(v,16)));w.u32(objects.length);w.u32(1);
 function write(value,def){
  if(typeof def==='string'){
   if(def==='f64'||def==='host-f64')w.f64(def==='host-f64'?0:value);
   else if(def==='bool')w.u8(Number(value));
   else if(def==='string'){const b=enc.encode(value);w.u16(b.length);w.raw(b);}return;
  }
  if(def.nullable){w.u8(value===null?0:1);if(value===null)return;}
  if(!def.external)w.u32(seen.get(value).id);
 }
 for(const {value,name}of objects){
  const type=env.types[env.ids.get(name)];w.u16(env.ids.get(name));const sizeAt=w.pos;w.u32(0);const begin=w.pos;
  if(type.kind==='buffer'){w.u32(value.byteLength);w.raw(new Uint8Array(value));}
  else if(type.kind==='typed'){w.u32(seen.get(value.buffer).id);w.u32(value.byteOffset);w.u32(value.length);}
  else if(type.kind==='array'){w.u32(value.length);for(let i=0;i<value.length;i++)write(value[i],arrayDef(type,i));}
  else for(const [key,def]of Object.entries(type.fields))write(value[key],def);
  w.view.setUint32(sizeAt,w.pos-begin,true);
 }
 return w.done();
}

/** Decode in an isolated graph; two passes allocate shells then rebind all refs. */
export function decodeGraph(input,schema,bindings,hash){
 const env=environment(schema,bindings,hash);
 need(input instanceof Uint8Array&&input.byteLength>=48&&input.byteLength<=LIMIT&&Object.getPrototypeOf(input.buffer)===ArrayBuffer.prototype,'input extent');
 const r=new Reader(input),magic=dec.decode(r.raw(4));need(magic==='EFZC'&&r.u16()===1&&r.u16()===0,'header');
 need(Array.from(r.raw(32),v=>v.toString(16).padStart(2,'0')).join('')===hash,'schema hash');
 const count=r.u32(),rootID=r.u32();need(count>0&&count<=MAX_OBJECTS&&rootID===1,'directory');
 const nodes=[];
 // Directory bounds are validated before any allocation dependent on the data.
 for(let i=0;i<count;i++){const id=r.u16(),size=r.u32();need(id<env.types.length,'type id');nodes.push({name:env.names[id],type:env.types[id],data:r.raw(size),object:null});}
 need(r.pos===input.byteLength&&nodes[0].name===schema.root,'trailing bytes/root');
 // Bound aggregate JS property/array slots before allocating any graph shell.
 // A short malformed directory must not allocate thousands of large arrays
 // before its missing field bytes are discovered in the second pass.
 let slots=0,declaredBuffers=0;
 for(const node of nodes){
  const {type}=node,p=new Reader(node.data);
  if(type.kind==='array'){const length=p.u32();arrayLength(type,length);slots+=length;}
  else if(type.kind==='record')slots+=Object.keys(type.fields).length;
  else if(type.kind==='buffer'){const n=p.u32();declaredBuffers+=n;need(n<=MAX_BUFFER&&declaredBuffers<=LIMIT&&p.bytes.length===n+4,'buffer extent');}
  need(slots<=65536,'allocation budget');
 }
 let totalBuffer=0;
 for(const node of nodes){
  const {type}=node,p=new Reader(node.data);
  if(type.kind==='buffer'){const n=p.u32();totalBuffer+=n;need(n<=MAX_BUFFER&&totalBuffer<=LIMIT&&p.bytes.length===n+4,'buffer extent');node.object=p.raw(n).slice().buffer;}
  else if(type.kind==='record')node.object=Object.create(prototype(env,type));
  else if(type.kind==='array'){const length=p.u32();arrayLength(type,length);node.object=new Array(length);}
  else need(type.kind==='typed','type kind');
 }
 function ref(id,name){need(id>0&&id<=nodes.length&&nodes[id-1].name===name&&nodes[id-1].object!==null,'reference id/type');return nodes[id-1].object;}
 // Buffers are now owned; typed views use receiver builtins and validated ranges.
 for(const node of nodes)if(node.type.kind==='typed'){
  const p=new Reader(node.data),buffer=ref(p.u32(),'$buffer'),offset=p.u32(),length=p.u32(),C=ARRAYS[node.type.array];
  need(C&&length===node.type.length&&offset%C.BYTES_PER_ELEMENT===0&&offset+length*C.BYTES_PER_ELEMENT<=buffer.byteLength&&p.pos===p.bytes.length,'typed view');
  node.object=new C(buffer,offset,length);
  if(C===Float64Array||C===Float32Array)need(node.object.every(Number.isFinite),'nonfinite typed value');
 }
 function read(p,def){
  if(typeof def==='string'){
   if(def==='f64')return p.f64();
   if(def==='host-f64'){need(Object.is(p.f64(),0),'host metric encoding');return 0;}
   if(def==='bool'){const b=p.u8();need(b<=1,'boolean');return !!b;}
   if(def==='null')return null;
   if(def==='string'){const n=p.u16();need(n<=256,'string extent');try{return dec.decode(p.raw(n));}catch{need(false,'utf8');}}
   need(false,'field schema');
  }
  if(def.nullable){const n=p.u8();need(n<=1,'presence');if(n===0)return null;}
  if(def.external){need(Object.hasOwn(bindings.resources,def.external),'external binding');return bindings.resources[def.external];}
  return ref(p.u32(),def.ref);
 }
 for(const node of nodes){const p=new Reader(node.data),{type,object}=node;
  if(type.kind==='record')for(const [key,def]of Object.entries(type.fields))Object.defineProperty(object,key,{value:read(p,def),enumerable:true,writable:true,configurable:true});
  else if(type.kind==='array'){p.u32();for(let i=0;i<object.length;i++)object[i]=read(p,arrayDef(type,i));}
  else continue;
  need(p.pos===p.bytes.length,'record extent');
 }
 const root=nodes[0].object,canonical=encodeGraph(root,schema,bindings,hash);
 need(canonical.length===input.length&&canonical.every((b,i)=>b===input[i]),'noncanonical/unreachable graph');
 return root;
}
