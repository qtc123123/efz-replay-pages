const SHA=/^[a-f0-9]{64}$/;
export function normalPath(value){
 if(typeof value!=='string'||!value||value.length>240||/[\x00-\x1f:%?#]/.test(value))throw Error('invalid virtual path');
 const path=value.replaceAll('\\','/').toLowerCase();
 if(path.startsWith('/')||path.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('invalid virtual path');return path;
}
export async function sha256(bytes){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(v=>v.toString(16).padStart(2,'0')).join('');}
export async function fetchExact(url,size,hash,{fetcher=fetch,signal}={}){
 if(!Number.isSafeInteger(size)||size<0||size>64*1024*1024||!SHA.test(hash))throw Error('invalid object extent/digest');
 const response=await fetcher(url,{signal,credentials:'same-origin',redirect:'error'});
 if(!response.ok||!response.body)throw Error('object HTTP '+response.status);
 const declared=response.headers.get('content-length');if(declared!==null&&Number(declared)>size){await response.body.cancel();throw Error('object extent');}
 const reader=response.body.getReader(),bytes=new Uint8Array(size);let pos=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;if(pos+value.length>size)throw Error('object extent');bytes.set(value,pos);pos+=value.length;}}
 catch(e){await reader.cancel().catch(()=>{});throw e;}finally{reader.releaseLock();}
 if(pos!==size)throw Error('object extent');if(await sha256(bytes)!==hash)throw Error('object digest');return bytes;
}
export class AssetCatalog {
 #entries=new Map(); #loaded=new Map(); #pending=new Map(); #root; #fetch; #disposed=false; #abort=new AbortController();
 constructor(manifest,root,{fetcher=fetch,maxBytes=256*1024*1024}={}){
  this.#root=new URL(root);if(!['https:','http:'].includes(this.#root.protocol)||!this.#root.pathname.endsWith('/')||this.#root.search||this.#root.hash||this.#root.username||this.#root.password)throw Error('asset root');
  if(manifest?.schema!=='miracle-assets/0'||!Array.isArray(manifest.files)||manifest.files.length>20000||!Number.isSafeInteger(maxBytes)||maxBytes<1)throw Error('asset manifest');
  let total=0;for(const entry of manifest.files){const path=normalPath(entry.path);if(this.#entries.has(path)||!SHA.test(entry.sha256)||!Number.isSafeInteger(entry.bytes)||entry.bytes<0||entry.bytes>64*1024*1024)throw Error('asset entry');total+=entry.bytes;if(total>maxBytes)throw Error('asset capacity');this.#entries.set(path,Object.freeze({sha256:entry.sha256,bytes:entry.bytes}));}
  this.#fetch=fetcher;
 }
 has(path){return this.#entries.has(normalPath(path));}
 isLoaded(path){return this.#loaded.has(normalPath(path));}
 paths(){return [...this.#entries.keys()];}
 bytes(path){const b=this.#loaded.get(normalPath(path));if(!b)throw Error('asset not loaded: '+path);return b.slice();}
 async load(path){
  path=normalPath(path);if(this.#disposed)throw Error('catalog disposed');if(!this.#entries.has(path))throw Error('asset missing: '+path);
  if(this.#loaded.has(path))return;if(this.#pending.has(path))return this.#pending.get(path);
  const e=this.#entries.get(path);
  const task=(async()=>{const b=await fetchExact(new URL('objects/'+e.sha256,this.#root),e.bytes,e.sha256,{fetcher:this.#fetch,signal:this.#abort.signal});if(this.#disposed)throw Error('catalog disposed');this.#loaded.set(path,b);})();
  this.#pending.set(path,task);try{await task;}finally{this.#pending.delete(path);}
 }
 async loadForSimulation(){return this.#loadPaths(this.paths().filter(p=>!p.endsWith('.wav')));}
 async loadAll(){return this.#loadPaths(this.paths());}
 async #loadPaths(paths){let next=0;try{await Promise.all(Array.from({length:Math.min(4,paths.length)},async()=>{while(next<paths.length)await this.load(paths[next++]);}));}catch(e){this.dispose();throw e;}}
 dispose(){this.#disposed=true;this.#abort.abort();this.#loaded.clear();}
}
