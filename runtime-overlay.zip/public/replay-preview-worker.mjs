import {createLocalReplaySpectator as createSpectator,createLocalTapeReplay as createNativeReplay} from '../generated/efz-engine.mjs';
import {installReplayWorker} from '../preview-src/pages/replay-session.mjs';

installReplayWorker(self,{createSpectator,createNativeReplay});
