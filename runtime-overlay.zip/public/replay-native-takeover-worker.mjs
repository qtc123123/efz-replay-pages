import {createLocalReplaySpectator as createSpectator,createRecoveredNativeReplay} from '../native-generated/efz-engine.mjs';
import {GENERATED_ENGINE_HASH as recoveredEngineHash} from '../native-generated/checkpoint-build.mjs';
import {installReplayWorker} from '../preview-src/pages/replay-session.mjs';
installReplayWorker(self,{createSpectator,createRecoveredNativeReplay,recoveredEngineHash});
