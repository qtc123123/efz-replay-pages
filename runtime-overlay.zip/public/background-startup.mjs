import {createSelectionBackground,validateBackgroundManifest} from '../src/pages/selection-background.mjs';
import {resourceKey as deploymentResourceKey} from '../deployment/resource-access.mjs';

// Optional build-bound metadata lets this one small encrypted texture start
// without waiting for the replay module graph or unrelated deployment manifests.
export function createStartupBackground({document,window,resourceKey,fetcher=globalThis.fetch,assetRoot=new URL('../deployment/background/',import.meta.url).href}){
 const node=document.getElementById('page-background-bootstrap');if(!node)return null;
 if(node.textContent.length>16384)throw Error('Background bootstrap: descriptor extent');
 const descriptor=JSON.parse(node.textContent),keys=Object.keys(descriptor);
 if(keys.length!==3||!['resourceManifestSHA256','backgroundManifestSHA256','manifest'].every(k=>keys.includes(k))||
  !/^[a-f0-9]{64}$/.test(descriptor.resourceManifestSHA256)||!/^[a-f0-9]{64}$/.test(descriptor.backgroundManifestSHA256)||typeof descriptor.manifest!=='string')throw Error('Background bootstrap: descriptor');
 let disposed=false,owner=null,image=null;
 const check=()=>{if(disposed)throw Error('Background bootstrap disposed');};
 const pending=(async()=>{
  const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(descriptor.manifest)));
  if(Array.from(digest,b=>b.toString(16).padStart(2,'0')).join('')!==descriptor.backgroundManifestSHA256)throw Error('Background bootstrap: manifest digest');
  check();const manifest=validateBackgroundManifest(JSON.parse(descriptor.manifest)),key=resourceKey(descriptor.resourceManifestSHA256);
  try{owner=createSelectionBackground({manifest,assetRoot,key,fetcher});}finally{key.fill(0);}
  const picture=await owner.picture();
  if(disposed){picture.data.fill(0);check();}image=picture;
  const canvas=document.getElementById('page-background'),ctx=canvas?.getContext('2d');
  if(ctx){const rgba=ctx.createImageData(320,240);rgba.data.set(image.data);ctx.putImageData(rgba,0,0);}
  return image;
 })();
 // The main page may not have loaded yet when optional artwork fails.
 pending.catch(()=>{});
 function dispose(){if(disposed)return;disposed=true;owner?.dispose();image?.data.fill(0);image=null;window.removeEventListener('pagehide',dispose);}
 window.addEventListener('pagehide',dispose);
 return Object.freeze({matches:(resource,background)=>!disposed&&resource===descriptor.resourceManifestSHA256&&background===descriptor.backgroundManifestSHA256,
  picture:()=>disposed?Promise.reject(Error('Background bootstrap disposed')):pending,dispose});
}
export const startupBackground=(()=>{
 if(!globalThis.document)return null;
 try{return createStartupBackground({document:globalThis.document,window:globalThis.window,resourceKey:deploymentResourceKey});}catch{return null;}
})();
