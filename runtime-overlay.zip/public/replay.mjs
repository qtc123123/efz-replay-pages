import {createVideoCapture,paintVideoInputs} from '../src/pages/replay-video.mjs';
import {createReplayStudy,integerScale} from '../src/pages/replay-study.mjs';
import {numericHud} from '../src/pages/replay-hud.mjs';
import {startupBackground} from './background-startup.mjs';
import {validateReplayCheckpointProfile,supportsReplayCheckpoints} from '../src/pages/replay-checkpoint-profile.mjs';
import {createReplayLibrary} from '../src/pages/replay-library.mjs';
import {createReplayLibraryView} from '../src/pages/replay-library-view.mjs';
import {createPageLanguage} from '../src/pages/page-language.mjs';
import {readPlayerPreferences,writePlayerPreferences} from '../src/pages/player-preferences.mjs';
import {validateVoiceModManifest} from '../src/pages/voice-mod.mjs';
import {validateGameTranslationManifest} from '../src/pages/game-translation.mjs';
import {createSelectionBackground,validateBackgroundManifest,advanceSelectionOffset,selectionBackgroundSlices} from '../src/pages/selection-background.mjs';
import {createPlayerControls} from '../src/pages/player-controls.mjs';
import {createAppNavigation} from '../src/pages/app-navigation.mjs';
import {createReplayController} from '../src/pages/replay-controller.mjs';
import {createReplayIdentity} from '../src/pages/replay-identity.mjs';
import {validateReplayStats,emptyReplayStats} from '../src/pages/replay-stats.mjs';
import {validateReplayTraining,emptyReplayTraining} from '../src/pages/replay-training.mjs';
import {paintHitboxOverlay,prepareHitboxOverlay} from '../src/pages/replay-training-view.mjs';
import {sampleRecordedInputs,formatReplayTime} from '../src/pages/replay-input-history.mjs';
import {createReplayMusic} from '../src/pages/replay-music.mjs';
import {createReplaySounds} from '../src/pages/replay-sounds.mjs';
import {createReplayArt} from '../src/pages/replay-art.mjs';
import {createLoadingArt,chooseLoadingIllustration,validateLoadingManifest} from '../src/pages/loading-art.mjs';
import {createMenuMotion,setMenuMotionDirection,advanceMenuMotion,sampleMenuMotion,createMenuClock,advanceMenuClock} from '../src/pages/menu-scene.mjs';
import {GAME_ART_PATHS} from '../src/pages/art-paths.mjs';
import {STAGE_MUSIC_PATHS} from '../src/asset-selection.mjs';
import {resourceKey} from '../deployment/resource-access.mjs';

let analysisEngineHash=null;
let library=null,libraryView=null,activeLibraryId=null,libraryState={entries:[],selectedId:null},libraryPlayable=[];
let preferenceStorage=null;try{preferenceStorage=window.localStorage;}catch{}
const language=createPageLanguage({storage:preferenceStorage,languages:window.navigator?.languages??[window.navigator?.language??'en']});
let voiceAvailable=false,voiceEnabled=false;try{voiceEnabled=preferenceStorage?.getItem('efz-replay-voice-mod')==='true';}catch{}
const localizedText=new Map(),localizedAttributes=new Map(),tr=(key,values={})=>({key,values});
const translated=value=>value&&typeof value==='object'&&typeof value.key==='string'?language.t(value.key,Object.fromEntries(Object.entries(value.values).map(([key,item])=>[key,translated(item)]))):language.t(String(value));
const $=id=>document.getElementById(id),context=$('screen').getContext('2d',{alpha:false}),rgba=context.createImageData(320,240);
const NAMES=['Rumi','Ayu','Mai','Makoto','Akane','Mayu','Mizuka','Misaki','Shiori','Sayuri','Nayuki','Mio','Doppel','Kaori','Ikumi','Mishio','Akiko','Nayuki B','UNKNOWN','Kanna','Kano','Minagi','Nayuki','Misuzu','Mizuka'];
const configURL=new URL('../deployment/config.json',import.meta.url),pageAbort=new AbortController(),reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
let navigation=null,muted=false,overlayControls=null,keyboardControls=false,settingsTrigger=null,controlsPointer=false;
let generation=0,uiIntent=0,seekUiRevision=0,controller=null,music=null,sounds=null,art=null,loadingArt=null,current=null,initialization=null,activeFile=null,loading=false,starting=false,stepping=false,seeking=false,scrubbing=false,disposed=false,failed=false,deploymentPromise=null;
let terminalAutoNext=null;
let study=null,loopPending=false,lastStats=null,videoJob=null;
let menuMode='title',menuMotion=createMenuMotion({row:4}),menuClock=null,menuTimer=null,menuPaintRevision=0,titleSelected=false;
let replayMeta=null,lastTraining=emptyReplayTraining(),lastImage=null,fighterTimer=null,fighterClock=null,fighterRevision=0;
let fighterMotion={angle:90,nextAngle:90,scroll:0};
let fullscreenPending=false,fullscreenActive=false,restoreFullscreenFocus=false;
const historyRows=[new Map(),new Map()],historyOrder=['',''];
const text=(id,value)=>{localizedText.set(id,value);const node=$(id),content=translated(value);if(node.textContent!==content)node.textContent=content;};
const attribute=(id,name,value)=>{localizedAttributes.set(id+':'+name,{id,name,value});$(id).setAttribute(name,translated(value));};
language.apply(document);$('language').value=language.current();$('voice-mod').checked=voiceEnabled;attribute('progress','aria-valuetext','No replay');
const preferenceControls=[['volume','volume','number'],['effectsVolume','effects-volume','number'],['muted','mute-audio','boolean'],
 ['hitboxes','show-hitboxes','boolean'],['inputs','show-inputs','boolean'],['details','show-details','boolean'],
 ['winRounds','win-rounds','number'],['backgroundPlayback','background-playback','boolean']];
const savedPreferences=readPlayerPreferences(preferenceStorage);
for(const [key,id,type]of preferenceControls)if(Object.hasOwn(savedPreferences,key)){
 if(type==='boolean')$(id).checked=savedPreferences[key];else $(id).value=String(savedPreferences[key]);
}
muted=$('mute-audio').checked;
for(const [id,output]of [['volume','volume-value'],['effects-volume','effects-value']]){
 const percent=Math.round(Number($(id).value)*100)+'%';text(output,percent);attribute(id,'aria-valuetext',percent);
}
function rememberPreferences(){writePlayerPreferences(preferenceStorage,Object.fromEntries(preferenceControls.map(([key,id,type])=>[key,type==='boolean'?$(id).checked:Number($(id).value)])));}
const canPlayInCurrentTab=()=>!document.hidden||$('background-playback').checked;
const seconds=updates=>{const total=Math.floor(updates/64);return String(Math.floor(total/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');};
const decimal=value=>Number.isInteger(value)?String(value):value.toFixed(2).replace(/0+$/,'').replace(/\.$/,'');
function message(value,error=false){
 const exhausted=error&&typeof value==='string'&&/^NATIVE_REPLAY_EXHAUSTED frame=(\d+) offset=\d+ consumer=(?:aux|p0|p1|random)$/.exec(value);
 if(exhausted)value=tr('Recording data ends before the match finishes (after {frame} frames). The file may be incomplete or use an unsupported game version.',{frame:Number(exhausted[1]).toLocaleString()});
 text('status',value);$('status').classList.toggle('error',error);if(loading)text('loading-message',value);
}
function audioMessage(value,error=false){text('music-status',value);$('music-status').classList.toggle('error',error);}
function audioAction(action){for(const owner of [music,sounds])try{owner?.[action]();}catch(error){audioMessage(error.message,true);}}
function controls(){
 refreshStudy();
 const queueIndex=libraryPlayable.findIndex(e=>e.id===libraryState.selectedId);
 if($('queue-position')){$('queue-position').textContent=(queueIndex<0?0:queueIndex+1)+' / '+libraryPlayable.length;$('queue-prev').disabled=queueIndex<=0;$('queue-next').disabled=queueIndex<0||queueIndex>=libraryPlayable.length-1;}
 if(navigation){$('session-resume').hidden=!controller||!initialization;$('session-empty').hidden=!$('session-resume').hidden;text('session-name',activeFile?.name??'');$('watch-return').hidden=!controller||!initialization;}
 const available=controller&&current&&!loading&&!['failed','disposed'].includes(current.state),busy=starting||stepping||seeking||!!videoJob;
 $('play').hidden=!!(current?.state==='playing'||starting);$('pause').hidden=!$('play').hidden;
 $('play').disabled=!available||busy||current?.state!=='paused';$('pause').disabled=!available||stepping||seeking||!!videoJob;
 $('step').disabled=!available||busy||current?.state!=='paused';$('previous').disabled=!available||busy||current?.nextFrame<=1;
 $('restart').disabled=!available||busy;$('progress').disabled=!available||!!videoJob;
 $('seek-row').hidden=!seeking;
 $('cancel-extraction').hidden=!libraryState.extractingId;
 for(const [source,target]of [['restart','settings-restart'],['previous','settings-previous'],['step','settings-step']])$(target).disabled=$(source).disabled;
 overlayControls?.refresh();
 for(const rows of historyRows)for(const button of rows.values())button.disabled=!available||busy;
 document.documentElement.dataset.playerState=loading?'loading':seeking?'seeking':starting?'preparing':failed?'failed':current?.state??'empty';
}
function paintArt(id,picture){
 const canvas=$(id);canvas.width=picture.width;canvas.height=picture.height;
 const ctx=canvas.getContext('2d'),image=ctx.createImageData(picture.width,picture.height);image.data.set(picture.data);ctx.putImageData(image,0,0);
}
function stopFighters(){if(fighterTimer!==null)window.cancelAnimationFrame(fighterTimer);fighterTimer=null;fighterClock=null;fighterRevision++;}
async function drawFighters(revision=fighterRevision){
 const init=initialization,own=generation;if(!init||!art||disposed)return;
 const pictures=await Promise.all(init.characters.map((character,side)=>art.fighterPanel(character,init.palettes[side],side,{angle:fighterMotion.angle,scroll:fighterMotion.scroll})));
 if(revision!==fighterRevision||init!==initialization||own!==generation||disposed)return;
 for(const [side,suffix]of ['one','two'].entries())paintArt('portrait-'+suffix,pictures[side]);
}
async function fighterTick(now){
 fighterTimer=null;if(disposed||!initialization||document.hidden||reducedMotion.matches||navigation?.current()!=='replay')return;
 const own=fighterRevision;fighterClock=advanceMenuClock(fighterClock??createMenuClock(now),now);
 for(let count=0;count<Math.min(fighterClock.due,2);count++)fighterMotion={angle:Math.min(180,fighterMotion.nextAngle),nextAngle:Math.min(185,fighterMotion.nextAngle+5),scroll:(fighterMotion.scroll+1)%240};
 try{await drawFighters(own);}catch(error){if(own===fighterRevision&&!disposed)text('art-status',tr('Artwork unavailable: {error}',{error:error.message}));}
 if(own===fighterRevision&&!disposed&&initialization&&!document.hidden&&!reducedMotion.matches)fighterTimer=window.requestAnimationFrame(fighterTick);
}
function startFighters(){
 stopFighters();fighterMotion={angle:reducedMotion.matches?180:90,nextAngle:reducedMotion.matches?185:90,scroll:0};
 if(!reducedMotion.matches&&!document.hidden&&navigation?.current()==='replay'){fighterClock=createMenuClock(performance.now());fighterTimer=window.requestAnimationFrame(fighterTick);}
}
function stopMenu(){if(menuTimer!==null)window.cancelAnimationFrame(menuTimer);menuTimer=null;menuClock=null;menuPaintRevision++;}
async function drawMenu(){
 if(!art||disposed||$('placeholder').hidden||menuMode==='loading')return;
 const own=++menuPaintRevision,mode=menuMode,motion=menuMotion;
 try{
  const picture=mode==='title'?await art.titleReplay({selected:titleSelected}):await art.replayPanel({motion,selected:true});
  if(own!==menuPaintRevision||disposed||$('placeholder').hidden)return;
  paintArt('menu-art',picture);$('brand-fallback').hidden=true;
  $('title-open').hidden=mode!=='title';$('menu-line').hidden=mode==='title';
  if(mode==='replay')$('menu-line').style.top=(sampleMenuMotion(motion).selectedY/240*100)+'%';
 }catch(error){if(own===menuPaintRevision&&!disposed)text('art-status',tr('Artwork unavailable: {error}',{error:error.message}));}
}
function menuTick(now){
 menuTimer=null;if(disposed||document.hidden||reducedMotion.matches||$('placeholder').hidden)return;
 menuClock=advanceMenuClock(menuClock??createMenuClock(now),now);
 for(let count=0;count<Math.min(menuClock.due,2);count++)menuMotion=advanceMenuMotion(menuMotion);
 void drawMenu();if(menuMotion.phase===1||menuMotion.phase===3)menuTimer=window.requestAnimationFrame(menuTick);
}
function placeholder(label,{title=false,animate=false}={}){
 const keepMotion=!title&&!animate&&menuMode==='replay'&&!$('placeholder').hidden&&(menuMotion.phase===1||menuMotion.phase===3);
 if(!keepMotion)stopMenu();$('placeholder').hidden=false;$('placeholder').classList.remove('is-loading');menuMode=title?'title':'replay';text('menu-line',label);
 $('title-open').hidden=!title;$('menu-line').hidden=title;
 if(!title&&animate){menuMotion=setMenuMotionDirection(createMenuMotion({row:4}),'open');
  if(reducedMotion.matches||document.hidden){while(menuMotion.phase===1)menuMotion=advanceMenuMotion(menuMotion);}
  else{menuClock=createMenuClock(performance.now());menuTimer=window.requestAnimationFrame(menuTick);}
 }
 void drawMenu();
}
function loadingCover(){
 stopMenu();menuMode='loading';$('placeholder').hidden=false;$('placeholder').classList.add('is-loading');delete $('placeholder').dataset.illustration;
 $('menu-art').getContext('2d').clearRect(0,0,320,240);$('brand-fallback').hidden=true;$('menu-line').hidden=true;$('title-open').hidden=true;
}
async function showLoadingArt(info,own){
 if(!info.loadingManifest)return;
 if(!loadingArt){const key=resourceKey(info.config.manifestSha256);try{loadingArt=createLoadingArt({manifest:info.loadingManifest,assetRoot:new URL('./loading/',configURL).href,key});}finally{key.fill(0);}}
 const picture=await loadingArt.picture(chooseLoadingIllustration());
 if(own!==generation||disposed||!loading||menuMode!=='loading')return;
 paintArt('menu-art',picture);$('placeholder').dataset.illustration=picture.path;
}
function paint(image){
 if(!image){context.clearRect(0,0,320,240);text('image-origin','No battle image');placeholder('Ready · Play');return;}
 for(let n=0;n<76800;n++){const out=n*4,color=image.pixels[n]*4;
  rgba.data[out]=image.palette[color];rgba.data[out+1]=image.palette[color+1];rgba.data[out+2]=image.palette[color+2];rgba.data[out+3]=255;}
 context.putImageData(rgba,0,0);$('placeholder').hidden=true;stopMenu();
 text('image-origin',tr('Image: frame {frame}',{frame:(image.originUpdate+1).toLocaleString()}));
}
function showStats(raw){
 const stats=validateReplayStats(raw,raw.nextUpdate,initialization);lastStats=stats;paintNumbers();
 for(const [side,suffix] of ['one','two'].entries()){
  const p=stats.players?.[side];
  for(const field of ['hp','sp','rf']){
   text(field+'-'+suffix,p?decimal(p[field]):'—');$(field+'-'+suffix).title=p?String(p[field]):'';
  }
  text('rf-mode-'+suffix,p?(p.rfBlue?'RF · Blue':'RF · Normal'):'');text('wins-'+suffix,p?String(p.wins):'—');
 }
 text('stats-origin',stats.availability==='none'?'Values appear on the first frame':stats.availability==='last-live'?tr('Final values: frame {frame}',{frame:(stats.sourceUpdate+1).toLocaleString()}):tr('Values: frame {frame}',{frame:stats.nextUpdate.toLocaleString()}));
}
function showRecordedInputs(){
 // Portrait/header readiness is not frame/index admission. Apply saved overlay
 // intent only to the new replay's validated presentation and complete metadata.
 const visible=!!initialization&&!!lastImage&&!!replayMeta&&$('show-inputs').checked,sample=visible?sampleRecordedInputs(replayMeta,lastTraining.nextUpdate,{windowUpdates:512,maxRows:14}):null;
 for(const [side,suffix]of ['one','two'].entries()){
  const node=$('inputs-'+suffix),list=$('input-history-'+suffix),player=sample?.players?.[side],overlay=$('input-overlay-'+suffix);node.hidden=!visible;list.hidden=!visible;
  overlay.hidden=!visible||!lastImage;
  const overlayRows=player?.rows??[];
  const signature=language.current()+':'+overlayRows.map(row=>row.word+':'+row.updates+':'+row.truncated).join('|');
  if(overlay.dataset.inputs!==signature){overlay.dataset.inputs=signature;overlay.replaceChildren(...overlayRows.map(row=>{
   const run=document.createElement('div');run.className='recorded-glyphs';
   const symbols=document.createElement('span');symbols.className='recorded-symbols';symbols.textContent=row.word===0?'':row.label;
   const held=document.createElement('span');held.className='recorded-hold';held.textContent=(row.truncated?'≥':'')+row.updates;
   run.setAttribute('aria-label',translated(tr(row.truncated?'{input} held at least {frames} frames':'{input} held {frames} frames',{input:row.word===0?'Neutral':row.label,frames:row.updates})));
   run.appendChild(held);run.appendChild(symbols);return run;
  }));}
  text('inputs-'+suffix,sample?.unavailable?'Unavailable for native replays':player?player.label:'—');node.title=player?translated(tr('Recorded input: frame {frame}',{frame:sample.sourceUpdate+1})):translated(sample?.unavailable?'Native recordings do not contain a separate frame input history':'No recorded input yet');
  const rows=player?.rows??[],order=rows.map(row=>row.targetNextUpdate+':'+row.word).join(',');
  const children=rows.map(row=>{
   const key=row.targetNextUpdate+':'+row.word;let button=historyRows[side].get(key);
   if(!button){button=document.createElement('button');button.type='button';button.className='input-run';const own=generation;
    button.addEventListener('click',()=>{if(own===generation)return seek(row.targetNextUpdate);});historyRows[side].set(key,button);}
   const label=formatReplayTime(row.targetNextUpdate)+'  '+row.label+'  '+(row.truncated?'≥':'')+row.updates+'f';
   if(button.textContent!==label)button.textContent=label;
   button.disabled=loading||starting||stepping||seeking||!controller;
   button.title=translated(tr('Jump to frame {frame}; input held during frames {start}–{end}',{frame:row.targetNextUpdate,start:row.startUpdate+1,end:row.endUpdate}));
   return button;
  });
  if(historyOrder[side]!==order){list.replaceChildren(...children);historyOrder[side]=order;const live=new Set(rows.map(row=>row.targetNextUpdate+':'+row.word));for(const key of historyRows[side].keys())if(!live.has(key))historyRows[side].delete(key);}
 }
}
function refreshTraining(){
 $('training-info').hidden=!initialization||!$('training-settings').open;
 for(const id of ['analysis-open','player-settings'])$(id).setAttribute('aria-expanded',String($('training-settings').open));
 overlayControls?.refresh();
 $('training-info').classList.toggle('show-details',$('show-details').checked);
 const layer=paintHitboxOverlay($('hitbox-overlay').getContext('2d'),lastTraining,lastImage,$('show-hitboxes').checked);
 $('hitbox-legend').hidden=!initialization||!lastImage||!$('show-hitboxes').checked;
 for(const [side,suffix]of ['one','two'].entries()){
  const p=lastTraining.players?.[side];
  text('combo-'+suffix,p?decimal(p.comboCount):'—');
  text('damage-'+suffix,p?decimal(p.comboDamage):'—');
  text('max-combo-'+suffix,p?decimal(p.maxCombo)+' / '+decimal(p.maxComboDamage):'—');
  text('scaling-'+suffix,p?decimal(p.proration/100)+'%':'—');
  text('stun-'+suffix,p?decimal(p.untech)+' / '+decimal(p.hitstop)+' / '+decimal(p.freeze):'—');
  text('state-'+suffix,p?p.state+' / '+p.frame:'—');
  text('position-'+suffix,p?decimal(p.x)+', '+decimal(p.y)+(p.facing===1?' →':' ←'):'—');
  text('shown-combo-'+suffix,p?decimal(p.comboDisplay)+' / '+decimal(p.comboTimer):'—');
  $('damage-'+suffix).title=p?translated(tr('Engine current/last combo accumulator; raw {damage}',{damage:p.comboDamage})):'';
  $('scaling-'+suffix).title=p?translated(tr('Next scaling {value}/100',{value:p.proration})):'';
 }
 const actorOrigin=lastTraining.availability==='none'?'No player values yet':lastTraining.availability==='last-live'?tr('Final player values: frame {frame}',{frame:lastTraining.sourceUpdate+1}):tr('Player values: frame {frame}',{frame:lastTraining.nextUpdate});
 text('training-origin',initialization?tr(layer.originUpdate===null?'{values} · No hitboxes to show':'{values} · Hitboxes: frame {frame}',{values:actorOrigin,frame:layer.originUpdate+1}):'');
 showRecordedInputs();
}
function present(image,rawStats,rawTraining){
 // Validate every component before the synchronous visible commit.
 const stats=validateReplayStats(rawStats,rawStats.nextUpdate,initialization),training=validateReplayTraining(rawTraining,stats.nextUpdate,initialization,image);
 prepareHitboxOverlay(training,image);lastTraining=training;lastImage=image;
 paint(image);showStats(stats);refreshTraining();paintVideoFrame();
}
const identity=createReplayIdentity({
 clear(){
  stopFighters();study=null;lastStats=null;paintNumbers();initialization=null;replayMeta=null;lastTraining=emptyReplayTraining();lastImage=null;$('match-info').hidden=true;$('player').classList.remove('identified');
  for(const side of [0,1]){historyRows[side].clear();historyOrder[side]='';$('input-history-'+['one','two'][side]).replaceChildren();}
  for(const suffix of ['one','two']){text('fighter-'+suffix,'');text('palette-'+suffix,'');const canvas=$('portrait-'+suffix);canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);}
  text('match-stage','');showStats(emptyReplayStats());text('stats-origin','');refreshTraining();
 },
 display(init,pictures){
  initialization=init;for(const [side,suffix] of ['one','two'].entries()){
   text('fighter-'+suffix,NAMES[init.characters[side]]);text('palette-'+suffix,tr('Color {color}',{color:init.palettes[side]+1}));paintArt('portrait-'+suffix,pictures[side]);
  }
  text('match-stage',tr('Stage {stage} · First to {rounds}',{stage:String(init.stage+1).padStart(2,'0'),rounds:init.winRounds}));attribute('match-stage','title',tr('Recorded stage ID {stage}',{stage:init.stage}));
  $('match-info').hidden=false;$('player').classList.add('identified');showStats(emptyReplayStats());refreshTraining();startFighters();
 }
});
async function json(url,max,signal,expected=null){
 const response=await fetch(url,{signal,credentials:'omit',redirect:'error'});if(!response.ok||!response.body)throw Error('Deployment files are unavailable.');
 const reader=response.body.getReader(),parts=[];let size=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max)throw Error('Deployment file exceeds its limit.');parts.push(value);}}
 catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
 if(expected){const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(size!==expected.bytes||hash!==expected.sha256)throw Error('Deployment manifest integrity check failed.');}
 return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
function configuration(value){
 const modern=value?.schema==='miracle-replay-pages/3';
 const keys=['schema','manifestUrl','manifestSha256','manifestBytes','generatedEngineHash','qualification','audio','music','supported',...(modern?['effects','art']:[]),...['loading','background','voiceMod','translation','localCheckpoints'].filter(key=>Object.hasOwn(value??{},key))];
 const exact=(object,expected)=>object&&typeof object==='object'&&!Array.isArray(object)&&Object.keys(object).sort().join(',')===[...expected].sort().join(',');
 const range=(value,start,count)=>JSON.stringify(value)===JSON.stringify(Array.from({length:count},(_,i)=>start+i));
 if(!exact(value,keys)||!['miracle-replay-pages/2','miracle-replay-pages/3'].includes(value.schema)||value.manifestUrl!=='./assets/manifest.json'||
  !/^[a-f0-9]{64}$/.test(value.manifestSha256)||!/^[a-f0-9]{64}$/.test(value.generatedEngineHash)||
  !Number.isInteger(value.manifestBytes)||value.manifestBytes<1||value.manifestBytes>4*1024*1024||value.qualification!=='experimental'||
  !exact(value.audio,modern?['music','effects','voices']:['music','effects'])||value.audio.music!==true||value.audio.effects!==modern||modern&&value.audio.voices!==true||
  !exact(value.music,['paths','mime'])||JSON.stringify(value.music.paths)!==JSON.stringify(STAGE_MUSIC_PATHS)||value.music.mime!=='audio/wav'||
  !exact(value.supported,['characters','stages','palettes','winRounds','defaultWinRounds'])||!range(value.supported.characters,0,25)||!range(value.supported.stages,0,23)||
  !range(value.supported.palettes,0,6)||!range(value.supported.winRounds,1,3)||value.supported.defaultWinRounds!==2)
  throw Error('Unsupported deployment configuration.');
 if(modern&&(!exact(value.art,['paths'])||JSON.stringify(value.art.paths)!==JSON.stringify(GAME_ART_PATHS)||
  !exact(value.effects,['paths','mime'])||value.effects.mime!=='audio/wav'||!Array.isArray(value.effects.paths)||value.effects.paths.length<1||value.effects.paths.length>1300||
  value.effects.paths.some((path,i)=>typeof path!=='string'||path.length>100||!/^([a-z]+\/wave|wave\/se)\/[0-9]{2}\.wav$/.test(path)||i>0&&value.effects.paths[i-1]>=path)))
  throw Error('Unsupported sound/art configuration.');
 for(const kind of ['loading','background','voiceMod','translation'])if(Object.hasOwn(value,kind)){
  const entry=value[kind];if(!modern||!exact(entry,['manifestUrl','manifestSha256','manifestBytes'])||entry.manifestUrl!=='./'+(kind==='voiceMod'?'voice-mod':kind)+'/manifest.json'||
   !/^[a-f0-9]{64}$/.test(entry.manifestSha256)||!Number.isInteger(entry.manifestBytes)||entry.manifestBytes<1||entry.manifestBytes>4*1024*1024)throw Error('Unsupported '+kind+' illustration configuration.');
 }
 return Object.hasOwn(value,'localCheckpoints')?{...value,localCheckpoints:validateReplayCheckpointProfile(value.localCheckpoints)}:value;
}
function deployment(){
 if(!deploymentPromise)deploymentPromise=(async()=>{
  const localAbort=new AbortController(),stop=()=>localAbort.abort();pageAbort.signal.addEventListener('abort',stop,{once:true});const timer=setTimeout(stop,60000);
  try{
   const config=configuration(await json(configURL,65536,localAbort.signal));
   const manifest=await json(new URL(config.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.manifestSha256,bytes:config.manifestBytes});
   if(config.audio.effects){const paths=manifest.files?.filter(entry=>entry.path.endsWith('.wav')&&!entry.path.startsWith('wave/bgm/')).map(entry=>entry.path).sort();
    if(JSON.stringify(paths)!==JSON.stringify(config.effects.paths))throw Error('Sound resource declaration does not match the verified manifest.');}
   const loadingManifest=config.loading?validateLoadingManifest(await json(new URL(config.loading.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.loading.manifestSha256,bytes:config.loading.manifestBytes})):null;
   const backgroundManifest=config.background?validateBackgroundManifest(await json(new URL(config.background.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.background.manifestSha256,bytes:config.background.manifestBytes})):null;
   const voiceManifest=config.voiceMod?validateVoiceModManifest(await json(new URL(config.voiceMod.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.voiceMod.manifestSha256,bytes:config.voiceMod.manifestBytes})):null;
   const translationManifest=config.translation?validateGameTranslationManifest(await json(new URL(config.translation.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.translation.manifestSha256,bytes:config.translation.manifestBytes})):null;
   if(!disposed){analysisEngineHash=config.generatedEngineHash;library?.configureAnalysis({engineHash:analysisEngineHash,winRounds:Number($('win-rounds').value)});voiceAvailable=!!voiceManifest;$('voice-mod').disabled=!voiceManifest;$('voice-help').hidden=!voiceManifest;}
   return {config,manifest,loadingManifest,backgroundManifest,voiceManifest,translationManifest,assetRoot:new URL('./',new URL(config.manifestUrl,configURL)).href};
  }finally{clearTimeout(timer);pageAbort.signal.removeEventListener('abort',stop);}
 })().catch(error=>{deploymentPromise=null;throw error;});return deploymentPromise;
}
function gameTranslation(info){return language.current()==='en'&&info.translationManifest?{manifest:info.translationManifest,assetRoot:new URL('./translation/',configURL).href}:null;}
let artLanguage=null;
function artOwner(info){
 const selected=gameTranslation(info),identity=selected?'en':'original';if(art&&artLanguage!==identity){art.dispose();art=null;}
 if(art||!info.config.art)return art;artLanguage=identity;const key=resourceKey(info.config.manifestSha256);
 try{art=createReplayArt({manifest:info.manifest,assetRoot:info.assetRoot,key,...selected?{gameTranslation:selected}:{}});return art;}finally{key.fill(0);}
}
let backdropOwner=null,backdropTexture=null,backdropClock=null,backdropRequest=null,backdropOffset=0;
function stopBackdrop(){if(backdropRequest!==null)window.cancelAnimationFrame(backdropRequest);backdropRequest=null;backdropClock=null;}
function drawBackdrop(){
 if(!backdropTexture)return;const ctx=$('page-background').getContext('2d');
 // No clear: the native integer319 branch retains its previous leftmost strip.
 for(const {sourceX,x,width}of selectionBackgroundSlices(backdropOffset))ctx.drawImage(backdropTexture,sourceX,0,width,240,x,0,width,240);
}
function backdropTick(now){
 backdropRequest=null;if(disposed||document.hidden||document.fullscreenElement||reducedMotion.matches)return;
 backdropClock=advanceMenuClock(backdropClock,now);
 for(let i=0;i<backdropClock.due;i++){backdropOffset=advanceSelectionOffset(backdropOffset);drawBackdrop();}
 backdropRequest=window.requestAnimationFrame(backdropTick);
}
function refreshBackdrop(){
 stopBackdrop();if(!backdropTexture||disposed||document.hidden||document.fullscreenElement)return;
 drawBackdrop();if(!reducedMotion.matches){backdropClock=createMenuClock(performance.now());backdropRequest=window.requestAnimationFrame(backdropTick);}
}
async function prepareBackdrop(info){
 if(!info.backgroundManifest||backdropOwner)return;
 const key=resourceKey(info.config.manifestSha256);
 try{
  backdropOwner=startupBackground?.matches(info.config.manifestSha256,info.config.background.manifestSha256)?startupBackground:createSelectionBackground({manifest:info.backgroundManifest,assetRoot:new URL('./background/',configURL).href,key});
  const picture=await backdropOwner.picture();if(disposed)return;
  const texture=document.createElement('canvas');texture.width=320;texture.height=240;const ctx=texture.getContext('2d'),rgba=ctx.createImageData(320,240);rgba.data.set(picture.data);ctx.putImageData(rgba,0,0);
  backdropTexture=texture;refreshBackdrop();
 }finally{key.fill(0);}
}
async function landing(){
 try{
  const info=await deployment();if(disposed)return;const owner=artOwner(info);if(!owner)throw Error('This build has no menu artwork');
  await Promise.all([drawMenu(),prepareBackdrop(info).catch(error=>{if(!disposed)text('art-status',tr('Background unavailable: {error}',{error:error.message}));})]);
  const entry=await owner.replayPanel();if(disposed||owner!==art)return;
  // A decorative crop of the existing replay sky, outside its menu labels.
  paintArt('entry-art',{width:entry.width,height:64,data:entry.data.slice(30*entry.width*4,94*entry.width*4)});
  const chrome=await owner.chrome();if(disposed||owner!==art)return;paintArt('chrome-logo',chrome.logo);
  for(const [key,variable]of Object.entries({world:'world',logo:'logo',wingLeft:'wing-left',wingRight:'wing-right',hudRail:'hud-rail',hudTop:'hud-top',hpTrack:'hp-track',spTrack:'sp-track',rfTrack:'rf-track',rfBlueTrack:'rf-blue-track'})){
   const picture=chrome[key],canvas=document.createElement('canvas');canvas.width=picture.width;canvas.height=picture.height;
   const ctx=canvas.getContext('2d'),image=ctx.createImageData(picture.width,picture.height);image.data.set(picture.data);ctx.putImageData(image,0,0);
   document.documentElement.style.setProperty('--native-'+variable,'url("'+canvas.toDataURL()+'")');
  }
  for(const selected of [false,true]){
   const picture=await owner.controlRow({selected});if(disposed||owner!==art)return;
   const canvas=document.createElement('canvas');canvas.width=picture.width;canvas.height=picture.height;
   const ctx=canvas.getContext('2d'),image=ctx.createImageData(picture.width,picture.height);image.data.set(picture.data);ctx.putImageData(image,0,0);
   document.documentElement.style.setProperty(selected?'--native-selected':'--native-row','url("'+canvas.toDataURL()+'")');
  }
 }catch(error){if(!disposed)text('art-status',tr('Artwork unavailable: {error}',{error:error.message}));}
}
function update(status,own){
 const wasPlaying=current?.state==='playing';
 if(own!==generation||disposed)return;current=status;
 text('frame',seconds(status.nextFrame)+' / '+seconds(status.frames));text('boundary',tr('Frame {frame} / {total}',{frame:status.nextFrame.toLocaleString(),total:status.frames.toLocaleString()}));
 $('progress').min=1;$('progress').max=status.frames;if(!scrubbing&&!seeking)$('progress').value=status.nextFrame;
 attribute('progress','aria-valuetext',tr('{time}; frame {frame} of {total}',{time:seconds(status.nextFrame),frame:status.nextFrame,total:status.frames}));
 if(status.state==='ended'){
  starting=false;if(!seeking)uiIntent++;
  // Status arrives before painting. Retain eligibility, not permission to
  // replace: asynchronous terminal presentation and analysis must finish first.
  terminalAutoNext=wasPlaying&&!loading&&!seeking&&!stepping&&$('queue-auto').checked&&navigation?.current()==='replay'?{own,status,id:activeLibraryId,intent:uiIntent}:null;
  message('Recording ended');audioAction('stop');audioMessage('Recording ended');}
 else if(!loading&&!seeking&&!starting)message(status.state==='playing'?'Playing':status.nextFrame===0?'Ready':'Paused');
 controls();
}
function terminalPresented(frame,own,owner){
 if(videoJob||study?.isLooping())return;
 const pending=terminalAutoNext;
 if(!pending||pending.own!==own||pending.status!==frame.status)return;
 terminalAutoNext=null;
 if(disposed||own!==generation||controller!==owner||pending.intent!==uiIntent||current?.state!=='ended'||loading||seeking||activeLibraryId!==pending.id||libraryState.selectedId!==pending.id||!$('queue-auto').checked||navigation?.current()!=='replay')return;
 const next=library.neighbor(1);if(next)void openLibraryEntry(next,{autoplay:true});
}
async function retire(){
 cancelVideo();study=null;loopPending=false;
 uiIntent++;seekUiRevision++;terminalAutoNext=null;starting=false;stepping=false;seeking=false;
 const old=controller,oldMusic=music,oldSounds=sounds;controller=null;music=null;sounds=null;
 const results=await Promise.allSettled([old?.dispose(),oldMusic?.dispose(),oldSounds?.dispose()]);
 const bad=results.find(result=>result.status==='rejected');if(bad)throw bad.reason;
}
// Finish loading off-screen without starting the first simulation update there.
// Replacement and page disposal also release these waits; callers recheck custody.
const preparationViews=new Set();
function wakePreparationViews(){for(const check of preparationViews)check();}
function waitForReplayView(own){return new Promise(resolve=>{
 const check=()=>{if(own!==generation||disposed||navigation?.current()==='replay'&&!document.hidden){preparationViews.delete(check);resolve();}};
 preparationViews.add(check);check();
});}
let languageRestore=null;
async function openFile(file,selectionError=null,restore=null,{preserveRoute=false,libraryId=null}={}){
 if(disposed)return;
 cancelVideo();library?.cancelExtraction();
 if(!preserveRoute)navigation?.go('replay');languageRestore=restore;
 const own=++generation,token=identity.begin();let firstFrame=null,restoredFrame=null;wakePreparationViews();activeFile=libraryId?null:file;loading=true;failed=false;current=null;scrubbing=false;
 context.clearRect(0,0,320,240);text('image-origin','');text('frame','00:00 / 00:00');text('boundary','No replay');$('progress').value=0;attribute('progress','aria-valuetext','No replay');
 text('file-name',file?.name??'No replay');message('Validating replay…');loadingCover();controls();
 try{
  await retire();if(own!==generation||disposed)return;
  if(libraryId){
   if(navigation?.current()!=='replay')throw Object.assign(Error('Extraction canceled'),{name:'AbortError'});
   message('Extracting recording…');file=await library.file(libraryId);
   if(own!==generation||disposed)return;
   if(!library.snapshot().entries.some(entry=>entry.id===libraryId))throw Error('Recording removed');
   activeFile=file;message('Validating replay…');
  }
  if(selectionError)throw Error(selectionError);
  if(!file||!file.name.toLowerCase().endsWith('.rep')||file.size>64*1024*1024)throw Error('Choose a .rep file up to 64 MiB');
  const bytes=new Uint8Array(await file.arrayBuffer());if(own!==generation||disposed)return;
  const meta=identity.admit(bytes,Number($('win-rounds').value),token);
  const rememberedId=library?await library.rememberFile(file,meta,bytes):null;if(own!==generation||disposed)return;activeLibraryId=rememberedId;if(activeLibraryId)library.select(activeLibraryId);
  const info=await deployment();if(own!==generation||disposed)return;
  await showLoadingArt(info,own);if(own!==generation||disposed)return;
  const {config,manifest,assetRoot}=info,owner=artOwner(info);if(!owner)throw Error('Menu artwork is missing from this build');
  const analysisRow=library?.snapshot().entries.find(entry=>entry.id===rememberedId);
  // Freeze the original row identity/configuration with this page generation.
  // A late callback must never borrow a newer activeLibraryId or build.
  const analysisOwner=Object.freeze({id:rememberedId,sha256:analysisRow?.sha256,engineHash:config.generatedEngineHash,winRounds:meta.initialization.winRounds});
  library?.configureAnalysis({engineHash:analysisOwner.engineHash,winRounds:Number($('win-rounds').value)});
  const key=resourceKey(config.manifestSha256);let checkpointWarned=false;
  try{
   const candidate=createReplayController({checkpoints:!!config.localCheckpoints&&supportsReplayCheckpoints(config.localCheckpoints,meta),checkpointEngineHash:config.generatedEngineHash,
    onCheckpointError:issue=>{if(own!==generation||disposed||checkpointWarned)return;checkpointWarned=true;const phase=['capture','initialization','simulation','cleanup','restore'].includes(issue?.phase)?issue.phase:'unknown';console.warn('Replay checkpoint fallback ('+phase+'): acceleration unavailable; replay remains playable using exact resimulation.');},createWorker:kind=>new Worker(new URL(kind==='native-index'?'./native-replay-index-worker.mjs':'./replay-worker.mjs',import.meta.url),{type:'module'}),
    onFrame:frame=>{if(own===generation&&!disposed){study?.observe(frame.status.nextFrame,frame.result.observation?.engineEvents??[]);if(loading)firstFrame=frame;else present(frame.image,frame.result.stats,frame.result.training);refreshStudy();checkClipLoop(frame.status);checkVideoEnd(frame.status);}},
    onCommit:commit=>{if(own===generation&&!disposed&&commit.isCurrent()){if(loading)restoredFrame=commit;else present(commit.image,commit.stats,commit.training);$('progress').value=commit.status.nextFrame;}},
    onStatus:status=>update(status,own),
    onAnalysis:summary=>{if(own===generation&&!disposed&&controller===candidate&&analysisOwner.id&&summary.winRounds===analysisOwner.winRounds){if(summary.roundStarts)study?.setMarkers(summary.roundStarts);const {roundStarts,...counts}=summary;library.updateAnalysis(analysisOwner.id,{...counts,sha256:analysisOwner.sha256,engineHash:analysisOwner.engineHash});refreshStudy();}},
    onTerminalPresented:frame=>terminalPresented(frame,own,candidate),
    onProgress:progress=>{if(own===generation&&!disposed){if(progress.state==='indexing'){message(tr('Checking native replay… frame {frame}',{frame:progress.nextFrame.toLocaleString()}));return;}$('seek-progress').max=progress.targetNextUpdate||1;$('seek-progress').value=progress.nextFrame;text('seek-status',tr('Seeking {frame} / {target}',{frame:progress.nextFrame.toLocaleString(),target:progress.targetNextUpdate.toLocaleString()}));}},
    onError:error=>{if(own!==generation||disposed)return;cancelVideo();identity.fail(token);loading=false;starting=false;seeking=false;failed=true;current=null;uiIntent++;audioAction('stop');placeholder('',{title:true});message(error.message,true);controls();}
   });
   controller=candidate;candidate.setCheckpointActive(!document.hidden&&document.documentElement.dataset.route==='replay');
   // Header admission already identifies the characters and stage. Prepare
   // selected audio silently while native indexing runs in its own Worker.
   music=createReplayMusic({manifest,assetRoot,key,path:config.music.paths[meta.initialization.stage]});music.setVolume(muted?0:Number($('volume').value));
   if(config.audio.effects){sounds=createReplaySounds({manifest,assetRoot,key,characters:meta.initialization.characters,...info.voiceManifest?{voiceMod:{manifest:info.voiceManifest,assetRoot:new URL('./voice-mod/',configURL).href,enabled:voiceEnabled}}:{}});sounds.setVolume(muted?0:Number($('effects-volume').value));}
   const preparedMusic=music,preparedSounds=sounds;
   message('Loading battle…');
   // Attach rejection handlers to every branch immediately. Any failure retires
   // the scan and audio together; generation checks fence replacement results.
   await Promise.all([
    candidate.open({replayBytes:bytes,encryptedManifest:manifest,assetRoot,key,winRounds:meta.initialization.winRounds,...gameTranslation(info)?{gameTranslation:gameTranslation(info)}:{}}).then(()=>{
     if(own===generation&&!disposed&&controller===candidate&&loading&&!failed)message('Loading sounds and music…');
    }),
    preparedMusic.prepare(),preparedSounds?.prepare(),
    identity.show({portrait:(character,color,side)=>owner.fighterPanel(character,color,side,{angle:reducedMotion.matches?180:90,scroll:0})},token)
   ]);
   if(own!==generation||disposed)return;
   replayMeta=candidate.metadata();study=createReplayStudy(replayMeta.frames);if(replayMeta.analysis?.roundStarts)study.setMarkers(replayMeta.analysis.roundStarts);refreshStudy();
   if(analysisOwner.id&&replayMeta.frames)library.updateDuration(analysisOwner.id,replayMeta.frames);
   const ids=candidate.status();
   preparedSounds?.bindReplay({generation:ids.generation,replayId:ids.replayId,seekRevision:ids.seekRevision});
   candidate.setAudio({sounds:preparedSounds,music:preparedMusic});
   if(own!==generation||disposed)return;
   if(!restore)await waitForReplayView(own);if(own!==generation||disposed)return;
   if(restore){message('Restoring replay position…');await candidate.seek(restore.frame,{resume:false});}
   else{message('Preparing first frame…');await candidate.step();}
   if(!restore)await waitForReplayView(own);
   if(own!==generation||disposed)return;
   if(restore){if(!restoredFrame||restoredFrame.status.nextFrame!==restore.frame)throw Error('The replay position could not be restored');present(restoredFrame.image,restoredFrame.stats,restoredFrame.training);}
   else{if(!firstFrame||firstFrame.status.nextFrame!==1)throw Error('The first replay image is unavailable');present(firstFrame.image,firstFrame.result.stats,firstFrame.result.training);}
  }finally{key.fill(0);}
  if(own!==generation||disposed)return;
  loading=false;languageRestore=null;message(current?.state==='ended'?'Recording ended':current?.nextFrame===0?'Ready':'Paused');audioMessage('Audio ready');controls();
  if(restore?.resume&&canPlayInCurrentTab()&&navigation?.current()==='replay')await play();
 }catch(error){
  if(own!==generation||disposed)return;identity.fail(token);loading=false;failed=true;current=null;placeholder('',{title:true});
  message(error.name==='AbortError'?'Loading cancelled or timed out':error.message,true);await retire().catch(cleanup=>audioMessage(cleanup.message,true));controls();
 }
}
async function play(){
 if(!controller||loading||starting||stepping||seeking||current?.state!=='paused'||!canPlayInCurrentTab()||navigation?.current()!=='replay')return;
 const own=generation,intent=++uiIntent;starting=true;controls();message('Starting playback…');
 try{await controller.play();if(own===generation&&intent===uiIntent&&!disposed)audioMessage(sounds?(voiceEnabled&&voiceAvailable?'Music, effects & voices enabled':'Music and sound effects enabled'):'Music enabled');}
 catch(error){if(own===generation&&intent===uiIntent&&!disposed){audioAction('pause');message(error.message,true);audioMessage('Audio could not start',true);}}
 finally{if(own===generation&&intent===uiIntent){starting=false;if(current?.state==='playing'&&!loading&&!seeking)message('Playing');controls();}}
}
async function pause(){
 if(languageRestore)languageRestore.resume=false;uiIntent++;starting=false;const own=generation;
 try{await controller?.pause();if(own===generation&&!seeking)message('Paused');}catch(error){if(own===generation)message(error.message,true);}finally{controls();}
}
async function step(){
 if(!controller||loading||starting||stepping||seeking||current?.state!=='paused')return;
 uiIntent++;stepping=true;controls();const own=generation;
 try{await controller.step();}catch(error){if(own===generation)message(error.message,true);}finally{if(own===generation){stepping=false;controls();}}
}
async function seek(target,{restartMusic=false,exportOwner=null}={}){
 if(videoJob&&videoJob!==exportOwner)return;
 if(navigation?.current()!=='replay'||!controller||loading||starting||stepping||!current)return;
 target=Math.max(1,target);
 const own=generation,intent=++seekUiRevision;uiIntent++;starting=false;seeking=true;scrubbing=false;controls();message('Seeking…');
 $('seek-progress').max=target||1;$('seek-progress').value=0;text('seek-status',tr('Preparing seek to {target}',{target:target.toLocaleString()}));
 try{await controller.seek(target,{resume:false,restartMusic});if(own===generation&&intent===seekUiRevision&&!disposed){message(current?.state==='ended'?'Recording ended':'Paused');audioMessage('Audio ready');}}
 catch(error){if(own===generation&&intent===seekUiRevision&&!disposed)message(/cancelled/.test(error.message)?'Seek cancelled':error.message,!/cancelled/.test(error.message));}
 finally{if(own===generation&&intent===seekUiRevision&&!disposed){seeking=false;$('progress').value=current?.nextFrame??0;controls();}}
}
function restart(){return seek(1,{restartMusic:true});}
function cancelSeek(){uiIntent++;seekUiRevision++;controller?.cancelSeek();seeking=false;scrubbing=false;$('progress').value=current?.nextFrame??0;message('Seek cancelled');controls();}
function pickFile(){$('replay-file').value='';$('replay-file').click();}
async function openLibraryEntry(id,{autoplay=false}={}){
 try{const entry=libraryState.entries.find(entry=>entry.id===id);if(!entry||entry.error)return;library.select(id);const pending=openFile(entry,null,null,{libraryId:id}),own=generation,playIntent=uiIntent;await pending;if(autoplay&&$('queue-auto').checked&&playIntent===uiIntent&&own===generation&&!failed&&current?.state==='paused'&&navigation?.current()==='replay'&&canPlayInCurrentTab())await play();}
 catch(error){message(error.message,true);}
}
async function receiveFiles(files){
 const selected=Array.from(files??[]);if(!selected.length)return;
 if(selected.length===1&&/\.rep$/i.test(selected[0].name)&&!selected[0].webkitRelativePath){if(selected[0].size===0)return;return openFile(selected[0]);}
 navigation.go('replays');return library.importFiles(selected);
}
$('open-form').addEventListener('submit',event=>{event.preventDefault();return openFile($('replay-file').files?.[0]??activeFile);});
for(const id of ['entry-open','watch-open'])$(id).addEventListener('click',pickFile);
$('open-replay').addEventListener('click',pickFile);$('title-open').addEventListener('click',pickFile);
$('replay-file').addEventListener('change',()=>receiveFiles($('replay-file').files));
$('win-rounds').addEventListener('change',()=>{if(analysisEngineHash)library?.configureAnalysis({engineHash:analysisEngineHash,winRounds:Number($('win-rounds').value)});if(activeFile)return openFile(activeFile);});
for(const [event,selected] of [['pointerenter',true],['focus',true],['pointerleave',false],['blur',false]])$('title-open').addEventListener(event,()=>{titleSelected=selected;void drawMenu();});
$('play').addEventListener('click',play);$('pause').addEventListener('click',pause);$('step').addEventListener('click',step);
$('restart').addEventListener('click',restart);$('previous').addEventListener('click',()=>seek(Math.max(1,(current?.nextFrame??1)-1)));
$('cancel-seek').addEventListener('click',cancelSeek);
$('cancel-extraction').addEventListener('click',()=>library.cancelExtraction());
$('training-settings').addEventListener('toggle',refreshTraining);
for(const id of ['show-hitboxes','show-inputs','show-details'])$(id).addEventListener('change',refreshTraining);
$('progress').addEventListener('input',()=>{scrubbing=true;overlayControls?.refresh();text('frame',seconds(Number($('progress').value))+' / '+seconds(current?.frames??0));attribute('progress','aria-valuetext',tr('Jump to frame {frame}',{frame:$('progress').value}));});
$('progress').addEventListener('change',()=>{if(navigation?.current()!=='replay'){scrubbing=false;if(current)update(current,generation);return;}return seek(Number($('progress').value));});
$('progress').addEventListener('pointercancel',()=>{scrubbing=false;$('progress').value=current?.nextFrame??0;if(current)update(current,generation);});
for(const [id,label,owner] of [['volume','volume-value',()=>music],['effects-volume','effects-value',()=>sounds]])$(id).addEventListener('input',()=>{
 const value=Number($(id).value);text(label,Math.round(value*100)+'%');attribute(id,'aria-valuetext',Math.round(value*100)+'%');try{owner()?.setVolume(muted?0:value);}catch(error){audioMessage(error.message,true);}
});
function updateFullscreen(){
 const active=document.fullscreenElement===$('player'),button=$('fullscreen');
 button.hidden=typeof $('player').requestFullscreen!=='function'||document.fullscreenEnabled===false;
 button.disabled=fullscreenPending;text('fullscreen',active?'Exit fullscreen':'Fullscreen');
 button.setAttribute('aria-pressed',String(active));attribute('fullscreen','aria-label',active?'Exit fullscreen player':'Fullscreen player');
 attribute('fullscreen','title',active?'Exit fullscreen (F / Esc)':'Fullscreen (F)');
 if(active!==fullscreenActive){
  if(active){restoreFullscreenFocus=false;$('stage-shell').focus({preventScroll:true});}else if(fullscreenActive)restoreFullscreenFocus=true;
  fullscreenActive=active;
 }
 // Exit events can arrive while the requesting button is still disabled.
 if(restoreFullscreenFocus&&!fullscreenPending){restoreFullscreenFocus=false;
  const target=navigation?.current()==='watch'?$('nav-watch'):navigation?.current()==='replays'?$('nav-replays'):button;target.focus({preventScroll:true});}
 // A fullscreen request can finish after browser navigation hid its route.
 if(active&&navigation&&navigation.current()!=='replay')void document.exitFullscreen().catch(()=>message('Exit fullscreen to continue',true));
}
async function toggleFullscreen(){
 if(disposed||fullscreenPending||$('fullscreen').hidden)return;
 fullscreenPending=true;updateFullscreen();
 try{if(document.fullscreenElement)await document.exitFullscreen();else await $('player').requestFullscreen({navigationUI:'hide'});}
 catch{if(!disposed)message('Fullscreen is unavailable',true);}
 finally{fullscreenPending=false;if(!disposed)updateFullscreen();}
}
$('fullscreen').addEventListener('click',toggleFullscreen);
document.addEventListener('fullscreenchange',()=>{updateFullscreen();refreshBackdrop();});updateFullscreen();
document.addEventListener('keydown',event=>{
 if(event.code==='Tab'){keyboardControls=true;overlayControls?.reveal();}
 if(event.code==='Escape'&&videoJob){event.preventDefault();cancelVideo();return;}
 if(videoJob)return;
 if(event.code==='Escape'&&$('training-settings').open){event.preventDefault();closeSettings();return;}
 if(event.code==='Escape'&&$('sound-settings').open){event.preventDefault();closeSound();return;}
 if(event.code==='Escape'&&libraryState.extractingId){event.preventDefault();library.cancelExtraction();return;}
 if(event.code==='Escape'&&seeking){event.preventDefault();cancelSeek();return;}
 if(event.code==='Escape'&&document.fullscreenElement===$('player')){event.preventDefault();void toggleFullscreen();return;}
 if(event.ctrlKey||event.metaKey||event.altKey||event.repeat||event.target?.isContentEditable)return;
 if(['INPUT','SELECT','TEXTAREA'].includes(event.target?.tagName)&&!(event.code==='Space'&&event.target===$('progress')))return;
 if(navigation?.current()!=='replay')return;
 if(event.code==='KeyF'&&!$('fullscreen').hidden){event.preventDefault();void toggleFullscreen();return;}
 // Clicking the image or leaving fullscreen focuses a player button. Those
 // buttons must not swallow playback keys; editable/menu controls keep theirs.
 if(event.target?.closest?.('.player-menu'))return;
 const interactive=event.target?.closest?.('button,summary,a');
 if(interactive&&(!interactive.closest('#player')||interactive.tagName!=='BUTTON'))return;
 if(event.code==='Space'&&interactive&&!['toggle-controls','play','pause','fullscreen'].includes(interactive.id))return;
 if(event.code==='Space'&&controller&&!loading){event.preventDefault();void(current?.state==='playing'||starting?pause():play());}
 else if(event.shiftKey&&['ArrowLeft','ArrowRight'].includes(event.code)){event.preventDefault();void jumpStudy(event.code==='ArrowLeft'?-320:320);}
 else if(studyKey(event)){event.preventDefault();}
 else if(event.code==='ArrowRight'&&!$('step').disabled){event.preventDefault();void step();}
 else if(event.code==='ArrowLeft'&&!$('previous').disabled){event.preventDefault();void seek(Math.max(1,current.nextFrame-1));}
 else if(event.code==='Home'&&!$('restart').disabled){event.preventDefault();void restart();}
});
for(const event of ['dragenter','dragover'])$('stage-shell').addEventListener(event,e=>{e.preventDefault();});
$('stage-shell').addEventListener('drop',event=>{event.preventDefault();void receiveFiles(event.dataTransfer?.files);});
document.addEventListener('visibilitychange',()=>{controller?.setCheckpointActive(!document.hidden&&document.documentElement.dataset.route==='replay');refreshBackdrop();if(document.hidden){cancelVideo();stopMenu();stopFighters();if(!$('background-playback').checked){if(languageRestore)languageRestore.resume=false;uiIntent++;starting=false;audioAction('pause');void controller?.pause().catch(()=>{});}controls();}
 else{wakePreparationViews();if(initialization&&!reducedMotion.matches){fighterClock=createMenuClock(performance.now());fighterTimer=window.requestAnimationFrame(fighterTick);}
  if(!$('placeholder').hidden){menuClock=createMenuClock(performance.now());if(!reducedMotion.matches&&(menuMotion.phase===1||menuMotion.phase===3))menuTimer=window.requestAnimationFrame(menuTick);else void drawMenu();}}});
reducedMotion.addEventListener('change',()=>{refreshBackdrop();stopMenu();stopFighters();if(reducedMotion.matches){while(menuMotion.phase===1||menuMotion.phase===3)menuMotion=advanceMenuMotion(menuMotion);fighterMotion={angle:180,nextAngle:185,scroll:fighterMotion.scroll};void drawMenu();void drawFighters().catch(()=>{});}
 else if(initialization&&!document.hidden){fighterClock=createMenuClock(performance.now());fighterTimer=window.requestAnimationFrame(fighterTick);}});
window.addEventListener('pagehide',()=>{overlayControls?.dispose();navigation?.dispose();disposed=true;libraryView?.dispose();library?.dispose();generation++;stopBackdrop();backdropOwner?.dispose();backdropTexture=null;wakePreparationViews();stopMenu();pageAbort.abort();identity.begin();art?.dispose();loadingArt?.dispose();void retire().catch(()=>{});});
function suspendView(){
 cancelVideo();
 controller?.setCheckpointActive(false);
 library?.cancelExtraction();
 if(languageRestore)languageRestore.resume=false;
 // This fence is synchronous; a pending play/seek cannot regain hidden ownership.
 uiIntent++;starting=false;if(seeking)cancelSeek();audioAction('pause');closeSettings(false);closeSound(false);
 scrubbing=false;controlsPointer=false;if(current)update(current,generation);
 stopMenu();stopFighters();const owner=controller,own=generation;
 void owner?.pause().catch(error=>{if(!disposed&&own===generation&&owner===controller)message(error.message,true);});
}
function renderRoute(route){
 if(route!=='replay'&&document.fullscreenElement===$('player'))void document.exitFullscreen().catch(()=>message('Exit fullscreen to continue',true));
 $('replay-library').hidden=route!=='replays';$('replay-route').hidden=route!=='replay';$('watch-route').hidden=route!=='watch';
 $('nav-replays').setAttribute('aria-current',route==='watch'?'false':'page');
 $('nav-watch').setAttribute('aria-current',route==='watch'?'page':'false');
 document.documentElement.dataset.route=route;controller?.setCheckpointActive(route==='replay'&&!document.hidden);wakePreparationViews();
 if(route==='replay'&&art){void drawMenu();void drawFighters().catch(()=>{});}
 controls();
}
navigation=createAppNavigation({readHash:()=>window.location.hash,
 writeHash:(hash,replace)=>window.history[replace?'replaceState':'pushState']({view:hash.slice(2)},'',hash),
 subscribe:change=>{window.addEventListener('popstate',change);window.addEventListener('hashchange',change);return()=>{window.removeEventListener('popstate',change);window.removeEventListener('hashchange',change);};},
 leaveReplay:suspendView,render:renderRoute});
for(const [id,route]of [['nav-replays','replays'],['nav-watch','watch'],['back-replays','replays'],['watch-return','replay']])$(id).addEventListener('click',event=>{event.preventDefault();navigation.go(route);});
$('session-resume').addEventListener('click',()=>navigation.go('replay'));
function closeSettings(focus=true){
 $('training-settings').open=false;refreshTraining();if(focus)(settingsTrigger??$('analysis-open')).focus({preventScroll:true});overlayControls?.reveal();
}
function closeSound(focus=true){
 $('sound-settings').open=false;$('mute').setAttribute('aria-expanded','false');if(focus)$('mute').focus({preventScroll:true});overlayControls?.reveal();
}
for(const id of ['analysis-open','player-settings'])$(id).addEventListener('click',()=>{closeSound(false);settingsTrigger=$(id);const panel=$('training-settings');panel.open=!panel.open;refreshTraining();if(panel.open)$('analysis-toggle').focus({preventScroll:true});overlayControls?.reveal();});
$('close-analysis').addEventListener('click',event=>{event.preventDefault();closeSettings();});
$('close-sound').addEventListener('click',event=>{event.preventDefault();closeSound();});
$('sound-settings').addEventListener('toggle',()=>{$('mute').setAttribute('aria-expanded',String($('sound-settings').open));overlayControls?.refresh();});
document.addEventListener('pointerdown',event=>{if(event.target.closest('.player-menu,#mute,#player-settings,#analysis-open'))return;if($('training-settings').open)closeSettings(false);if($('sound-settings').open)closeSound(false);});
$('settings-restart').addEventListener('click',restart);$('settings-previous').addEventListener('click',()=>seek(Math.max(1,(current?.nextFrame??1)-1)));$('settings-step').addEventListener('click',step);
overlayControls=createPlayerControls({
 pinned:()=>navigation?.current()!=='replay'||current?.state!=='playing'||loading||seeking||scrubbing||controlsPointer||$('training-settings').open||$('sound-settings').open||keyboardControls&&!!document.activeElement?.closest?.('#playback-controls'),
 render:visible=>{if(!visible&&document.activeElement?.closest?.('#playback-controls'))$('toggle-controls').focus({preventScroll:true});$('player').classList.toggle('controls-visible',visible);attribute('toggle-controls','aria-label',visible?'Hide playback controls':'Show playback controls');}
});
$('toggle-controls').addEventListener('click',()=>{keyboardControls=false;overlayControls.toggle();});
$('playback-controls').addEventListener('pointerdown',()=>{controlsPointer=true;keyboardControls=false;overlayControls.reveal();});
$('playback-controls').addEventListener('pointermove',()=>overlayControls.reveal());
$('playback-controls').addEventListener('focusin',()=>overlayControls.reveal());
$('playback-controls').addEventListener('focusout',()=>queueMicrotask(()=>overlayControls.refresh()));
for(const event of ['pointerup','pointercancel'])document.addEventListener(event,()=>{if(controlsPointer){controlsPointer=false;overlayControls.reveal();}});
$('help-open').addEventListener('click',()=>{$('help').open=true;$('help').scrollIntoView({block:'nearest',behavior:reducedMotion.matches?'instant':'smooth'});});
$('mute').addEventListener('click',()=>{closeSettings(false);const panel=$('sound-settings');panel.open=!panel.open;$('mute').setAttribute('aria-expanded',String(panel.open));if(panel.open)$('sound-toggle').focus({preventScroll:true});overlayControls?.reveal();});
$('mute-audio').addEventListener('change',()=>{muted=$('mute-audio').checked;
 try{music?.setVolume(muted?0:Number($('volume').value));sounds?.setVolume(muted?0:Number($('effects-volume').value));}catch(error){audioMessage(error.message,true);}});
$('voice-mod').addEventListener('change',()=>{
 const previous=voiceEnabled;voiceEnabled=$('voice-mod').checked;
 try{sounds?.setVoiceMod(voiceEnabled);try{preferenceStorage?.setItem('efz-replay-voice-mod',String(voiceEnabled));}catch{}
  if(current?.state==='playing')audioMessage(voiceEnabled&&voiceAvailable?'Music, effects & voices enabled':'Music and sound effects enabled');
 }catch(error){voiceEnabled=previous;$('voice-mod').checked=previous;audioMessage(error.message,true);}
});
for(const [,id]of preferenceControls)$(id).addEventListener(['volume','effects-volume'].includes(id)?'input':'change',rememberPreferences);
$('background-playback').addEventListener('change',()=>{if(document.hidden&&!$('background-playback').checked)void pause();});
$('language').addEventListener('change',async()=>{
 const selected=$('language').value;if(selected===language.current())return;
 const retainPosition=()=>{const pending=seeking?controller?.status():null;return languageRestore??(pending?.seeking?{frame:pending.target,resume:false}:current&&!loading?{frame:current.nextFrame,resume:current.state==='playing'}:null);};
 let retained=retainPosition();const file=activeFile,own=generation,seekIntent=seekUiRevision,playIntent=uiIntent;
 language.set(selected);language.apply(document);libraryView?.render();
 for(const [id,value]of localizedText)text(id,value);
 for(const {id,name,value}of localizedAttributes.values())attribute(id,name,value);
 refreshTraining();updateFullscreen();
 try{
  const info=await deployment();if(disposed||own!==generation||file!==activeFile)return;
  if(info.translationManifest){
   if(file){
    // A seek cancellation or a newer target can arrive while the verified
    // deployment is being read. Honor that intent before replacing the Worker.
    if(seekIntent!==seekUiRevision)retained=retainPosition();
    if(retained&&playIntent!==uiIntent)retained={...retained,resume:false};
    return openFile(file,null,retained,{preserveRoute:true});
   }
   artOwner(info);await landing();
  }
 }catch(error){if(!disposed&&own===generation)message(error.message,true);}
});
library=createReplayLibrary({createWorker:()=>new Worker(new URL('./archive-import-worker.mjs',import.meta.url),{type:'module'}),onChange:state=>{if(disposed)return;libraryState=state;libraryPlayable=state.entries.filter(e=>!e.error);libraryView?.schedule(state);controls();}});
libraryView=createReplayLibraryView({document,library,onOpen:id=>openLibraryEntry(id),names:NAMES,fullNames:NAMES.map((name,id)=>id===12?'Doppel Nanase':name),translate:key=>language.t(key),preview:async stage=>{const info=await deployment();if(disposed)return null;return artOwner(info)?.stagePreview?.(stage)??null;},icon:async character=>{const info=await deployment();if(disposed)return null;return artOwner(info)?.selectionIcon?.(character)??null;}});
$('queue-auto').addEventListener('change',()=>{uiIntent++;});
$('library-add').addEventListener('click',pickFile);
$('library-folder').addEventListener('click',()=>{$('replay-folder').value='';$('replay-folder').click();});
$('replay-folder').addEventListener('change',()=>receiveFiles($('replay-folder').files));
$('library-clear').addEventListener('click',async()=>{const own=++generation;uiIntent++;loading=false;starting=false;failed=false;current=null;activeFile=null;activeLibraryId=null;wakePreparationViews();identity.begin();library.clear();libraryView?.reset({collapse:true});await retire();if(own!==generation||disposed)return;message('Open a .rep file');navigation.go('replays');controls();});
for(const [id,direction]of [['queue-prev',-1],['queue-next',1]])$(id).addEventListener('click',()=>{const next=library.neighbor(direction);if(next)return openLibraryEntry(next);});
for(const event of ['dragenter','dragover'])$('replay-library').addEventListener(event,e=>e.preventDefault());
$('replay-library').addEventListener('drop',event=>{event.preventDefault();void receiveFiles(event.dataTransfer?.files);});
identity.begin();controls();void landing();

function paintNumbers(){
 const ctx=$('numeric-hud').getContext('2d');ctx.clearRect(0,0,320,240);
 if(!$('show-numbers').checked)return;
 ctx.font='bold 6px monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineJoin='round';ctx.lineWidth=1.8;ctx.strokeStyle='#071018';ctx.fillStyle='#fff';
 for(const row of numericHud(lastStats,lastTraining.prepared)){ctx.strokeText(row.text,row.x,row.y);ctx.fillText(row.text,row.x,row.y);}
}
function refreshStudy(){
 const available=!videoJob&&!!study&&!!current&&!loading&&!seeking&&!starting&&!stepping&&!failed;
 for(const id of ['clip-in','clip-out','clip-clear','clip-export','jump-back','jump-forward','jump-back-one','jump-forward-one','round-index'])$(id).disabled=!available;
 $('round-prev').disabled=!available||study.round(current.nextFrame,-1)===null;
 $('round-next').disabled=!available||study.round(current.nextFrame,1)===null;
 $('clip-cancel').hidden=!videoJob;
 $('clip-loop').disabled=!available||!study.range();$('clip-loop').setAttribute('aria-pressed',String(study?.isLooping()??false));
 const points=study?.points();$('clip-range').textContent=points&&(points.in!==null||points.out!==null)?'In '+(points.in??'—')+' · Out '+(points.out??'—'):language.t('No clip selected');
 const markers=study?.markers()??[],signature=markers.join(',');
 if($('round-markers').dataset.markers!==signature){$('round-markers').dataset.markers=signature;$('round-markers').replaceChildren(...markers.map((at,i)=>{const b=document.createElement('button');b.type='button';b.textContent='R'+(i+1)+' · '+seconds(at);b.title='Observed round start: frame '+at;b.addEventListener('click',()=>{if(!b.disabled&&!videoJob)void seek(at);});return b;}));}
 for(const button of $('round-markers').children)button.disabled=!available;
}
async function jumpStudy(delta){if(!study||!current||loading)return;await seek(study.jump(current.nextFrame,delta));}
function markClip(which){try{study?.mark(which,current.nextFrame);refreshStudy();}catch(error){message(error.message,true);}}
async function checkClipLoop(status){
 const target=study?.loopTarget(status.nextFrame);if(videoJob||target===null||target===undefined||loopPending||loading||seeking||!['playing','ended'].includes(status.state))return;
 loopPending=true;const own=generation,model=study;
 try{const pending=seek(target),intent=uiIntent;await pending;if(own===generation&&intent===uiIntent&&study===model&&model.isLooping()&&canPlayInCurrentTab())await play();}
 finally{if(own===generation)loopPending=false;}
}
function resizeStudy(){const box=$('stage-viewport').getBoundingClientRect();if(!box.width)return;const full=document.fullscreenElement===$('player');const width=integerScale(box.width,full?box.height:window.innerHeight*.8,$('picture-scale').value);if(width===null){delete $('stage-shell').dataset.scaled;$('stage-shell').style.removeProperty('--study-width');}else{$('stage-shell').dataset.scaled='true';$('stage-shell').style.setProperty('--study-width',width+'px');}}
function studyKey(event){
 if(!study||!current||loading||seeking||starting||stepping)return false;
 const key=event.key;
 if(key==='{')markClip('in');else if(key==='}')markClip('out');
 else if(event.code==='BracketLeft')void seek(study.round(current.nextFrame,-1)??current.nextFrame);
 else if(event.code==='BracketRight')void seek(study.round(current.nextFrame,1)??current.nextFrame);
 else if(event.code==='KeyJ')void jumpStudy(-64);else if(event.code==='KeyK')void jumpStudy(64);
 else if(event.code==='Comma')void seek(study.jump(current.nextFrame,-1));else if(event.code==='Period')void step();
 else if(event.code==='End')void seek(current.frames);
 else if(event.code==='KeyL'){if(study.range())study.loop(!study.isLooping());refreshStudy();}
 else if(['KeyH','KeyI'].includes(event.code)){const node=$(event.code==='KeyH'?'show-hitboxes':'show-inputs');node.checked=!node.checked;node.dispatchEvent(new Event('change'));}
 else if(event.code==='KeyM'){$('mute-audio').checked=!$('mute-audio').checked;$('mute-audio').dispatchEvent(new Event('change'));}
 else if(event.code==='KeyB'){const node=$('volume');node.value=Number(node.value)>0?'0':'0.5';node.dispatchEvent(new Event('input'));}
 else if(['KeyN','KeyP'].includes(event.code)){const next=library.neighbor(event.code==='KeyN'?1:-1);if(next)void openLibraryEntry(next);}
 else return false;return true;
}
$('clip-in').addEventListener('click',()=>markClip('in'));$('clip-out').addEventListener('click',()=>markClip('out'));
$('clip-loop').addEventListener('click',()=>{try{study?.loop(!study.isLooping());refreshStudy();}catch(error){message(error.message,true);}});
$('clip-clear').addEventListener('click',()=>{study?.clear();refreshStudy();});
$('jump-back').addEventListener('click',()=>void jumpStudy(-320));$('jump-forward').addEventListener('click',()=>void jumpStudy(320));
for(const [id,d]of [['round-prev',-1],['round-next',1]])$(id).addEventListener('click',()=>{const at=study?.round(current.nextFrame,d);if(at)void seek(at);});
$('show-numbers').addEventListener('change',paintNumbers);$('picture-scale').addEventListener('change',resizeStudy);window.addEventListener('resize',resizeStudy);document.addEventListener('fullscreenchange',resizeStudy);

function paintVideoFrame(){
 const job=videoJob;if(!job||job.cancelled)return;
 const ctx=job.canvas.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,640,480);ctx.drawImage($('screen'),0,0,640,480);
 if($('show-hitboxes').checked)ctx.drawImage($('hitbox-overlay'),0,0,640,480);
 if($('show-numbers').checked)ctx.drawImage($('numeric-hud'),0,0,640,480);
 if($('show-inputs').checked)paintVideoInputs(ctx,$('screen').getBoundingClientRect(),document.querySelectorAll('.recorded-overlay:not([hidden]) .recorded-symbols, .recorded-overlay:not([hidden]) .recorded-hold'),node=>window.getComputedStyle(node));
}
function cleanVideo(job){
 clearTimeout(job.timer);for(const tap of job.taps??[])try{tap.close();}catch{}
 for(const source of job.sources??[])try{source.disconnect();}catch{}
 job.destination?.stream.getTracks().forEach(track=>track.stop());void job.mix?.close().catch(()=>{});
 if(videoJob===job){videoJob=null;refreshStudy();controls();}
}
function cancelVideo(){const job=videoJob;if(!job)return;job.cancelled=true;if(job.seekRevision===seekUiRevision&&controller?.status().seeking)cancelSeek();job.capture?.cancel();cleanVideo(job);text('clip-export-status',"Video export cancelled");void controller?.pause().catch(()=>{});}
async function finishVideo(job){
 if(videoJob!==job||job.finishing||job.cancelled)return;job.finishing=true;
 try{await controller?.pause();const blob=await job.capture.finish();if(videoJob!==job||job.cancelled||job.own!==generation)return;
  if(!blob.size)throw Error('The browser produced an empty video');
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='efz-clip-'+job.range.in+'-'+job.range.out+'.webm';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
  text('clip-export-status',"Video saved \u00b7 WebM \u00b7 real-time capture");
 }catch(error){if(!job.cancelled)$('clip-export-status').textContent=error.message;}finally{cleanVideo(job);}
}
function checkVideoEnd(status){const job=videoJob;if(!job||!job.capture||job.cancelled||job.finishing)return;
 $('clip-export-status').textContent='Recording '+Math.max(0,status.nextFrame-job.range.in)+' / '+(job.range.out-job.range.in)+' frames';
 if(status.nextFrame>=job.range.out||status.state==='ended')queueMicrotask(()=>void finishVideo(job));
}
async function exportVideo(){
 if(videoJob||!study||!current||loading||seeking)return;const range=study.range();
 if(!range){text('clip-export-status',"Set clip in and out first");return;}
 if(range.out-range.in>64*60){text('clip-export-status',"Select a clip of 60 seconds or less");return;}
 const job={own:generation,range,canvas:document.createElement('canvas'),taps:[],sources:[],cancelled:false,finishing:false};job.canvas.width=640;job.canvas.height=480;videoJob=job;study.loop(false);refreshStudy();
 try{
  const Type=window.AudioContext??window.webkitAudioContext;if(!Type)throw Error('Audio recording is unavailable');job.mix=new Type({sampleRate:48000});const audioReady=job.mix.resume();audioReady.catch(()=>{});job.timer=setTimeout(()=>{if(videoJob===job){cancelVideo();$('clip-export-status').textContent='Video preparation timed out';}},180000);
  text('clip-export-status',"Preparing video\u2026");await pause();if(job.cancelled||videoJob!==job||job.own!==generation)return;const preparing=seek(range.in,{exportOwner:job});job.seekRevision=seekUiRevision;await preparing;if(job.cancelled||videoJob!==job||job.own!==generation)return;
  if(current?.nextFrame!==range.in)throw Error('Could not prepare the clip start');
  await audioReady;
  if(job.cancelled||videoJob!==job){await job.mix.close();return;}
  job.destination=job.mix.createMediaStreamDestination();if(job.destination.stream.getAudioTracks().length!==1)throw Error('Audio recording track is unavailable');
  for(const owner of [music,sounds].filter(Boolean)){if(!owner.captureAudio)throw Error('Audio recording is unavailable');const tap=owner.captureAudio();job.taps.push(tap);const source=job.mix.createMediaStreamSource(tap.stream);source.connect(job.destination);job.sources.push(source);}
  paintVideoFrame();job.capture=createVideoCapture({canvas:job.canvas,audioTracks:job.destination.stream.getAudioTracks(),onError:error=>{if(videoJob===job){cancelVideo();$('clip-export-status').textContent=error.message;}}});job.capture.start();
  clearTimeout(job.timer);job.timer=setTimeout(()=>{if(videoJob===job){cancelVideo();$('clip-export-status').textContent='Export stopped: real-time capture exceeded 120 seconds';}},120000);
  await play();if(job.cancelled||videoJob!==job)return;if(!['playing','ended'].includes(current?.state))throw Error('Playback did not start for recording');
 }catch(error){job.capture?.cancel();if(!job.cancelled)$('clip-export-status').textContent=error.message;cleanVideo(job);}
}
$('clip-export').addEventListener('click',()=>void exportVideo());$('clip-cancel').addEventListener('click',cancelVideo);

$('round-index').addEventListener('click',async()=>{if(!study||!current||videoJob)return;const own=generation,at=current.nextFrame,model=study;model.loop(false);const pausing=pause(),pauseIntent=uiIntent;await pausing;if(own!==generation||model!==study||pauseIntent!==uiIntent||!current)return;const pending=seek(current.frames),intent=uiIntent;await pending;if(own!==generation||model!==study||intent!==uiIntent)return;if(current?.nextFrame!==current?.frames){message('Round analysis did not complete',true);return;}const summary=controller?.metadata()?.analysis;if(summary?.roundStarts)model.setMarkers(summary.roundStarts);await seek(at);refreshStudy();});

$('jump-back-one').addEventListener('click',()=>void jumpStudy(-64));$('jump-forward-one').addEventListener('click',()=>void jumpStudy(64));
