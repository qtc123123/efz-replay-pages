import {createRecoveredNativeReplay} from '../native-generated/efz-engine.mjs';
import {GENERATED_ENGINE_HASH as engineHash} from '../native-generated/checkpoint-build.mjs';
import {installNativeTakeoverPreparationWorker} from '../preview-src/pages/native-takeover-preparation.mjs';
installNativeTakeoverPreparationWorker(self,{createRecoveredNativeReplay,engineHash});
