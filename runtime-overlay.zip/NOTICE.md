# EFZ Replay Lab — Credits

**Site, Netplay support and Engine modifications by Aquatic.**

**Original web engine by [Mu-Tsun Tsai](https://github.com/MuTsunTsai/efz).**
Copyright © 2026 Mu-Tsun Tsai. All rights reserved. See the [original engine license](public/upstream-license.txt).

**English translation by SaltyBucket & fishshapedfish.**
The English option uses their replacement game artwork alongside the translated site interface.

**Voice recordings belong to their respective rights holders.**
The optional voice mod replaces selected sounds; original game audio is the default.

**Eternal Fighter Zero is created by Twilight Frontier.**
Original visual novels: **Kanon / AIR: Key (VISUAL ARTS)**; **MOON. / ONE ～輝く季節へ～: Tactics (NEXTON)**.
The game and its assets belong to their respective rights holders. All rights reserved.

EFZ Replay Lab is an independent project and is not affiliated with Twilight Frontier, VISUAL ARTS/Key or NEXTON/Tactics.

Third-party code and assets retain their original copyright notices and license terms.

## Original-title attribution sources

- [Kanon: official Key product page](https://key.visualarts.co.jp/product/kanon/).
- [AIR: official Key product page](https://key.visualarts.co.jp/product/air/).
- [NEXTON historical product catalog](https://nexton-net.jp/~nexton/product.htm): MOON. and ONE ～輝く季節へ～ were released under Tactics.

These credits distinguish original title/developer-brand attribution from later
remakes and do not assert ownership of every adaptation or audio edition.
The optional voice pack's original recording editions have not been independently
verified; visual-novel branding alone does not establish their attribution.
