// Experimental transport custody only: structural admission is not game fidelity.
const SCHEMA='efz-live-feed/1';
const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const SHA=/^[a-f0-9]{64}$/;
function fail(code){throw Object.assign(new Error(code),{code});}
const need=(ok,code='INVALID')=>{if(!ok)fail(code);};
const uint=(n,max,min=0)=>Number.isSafeInteger(n)&&n>=min&&n<=max;
const clone=value=>structuredClone(value);
function freeze(value){if(value&&typeof value==='object'){for(const v of Object.values(value))freeze(v);Object.freeze(value);}return value;}
// Inspect descriptors before reading any value; callers cannot supply getters,
// custom prototypes, sparse arrays, symbols, or unbounded recursive payloads.
function own(value){
 let budget=10000;
 function visit(v,depth){
  need(--budget>=0&&depth<=8);
  if(v===null||typeof v==='boolean')return v;
  if(typeof v==='number'){need(Number.isFinite(v));return v;}
  if(typeof v==='string'){need(v.length<=1024);return v;}
  need(typeof v==='object');const array=Array.isArray(v),proto=Object.getPrototypeOf(v);
  need(array?proto===Array.prototype:proto===Object.prototype||proto===null);
  const ds=Object.getOwnPropertyDescriptors(v),keys=Reflect.ownKeys(ds);
  need(keys.every(k=>typeof k==='string'));
  if(array){
   const length=ds.length;need(length&&Object.hasOwn(length,'value')&&uint(length.value,1024));
   need(keys.length===length.value+1);const out=[];
   for(let i=0;i<length.value;i++){const d=ds[String(i)];need(d&&Object.hasOwn(d,'value')&&d.enumerable);out.push(visit(d.value,depth+1));}return out;
  }
  need(keys.length<=16);const out={};
  for(const k of keys){need(k!=='__proto__');const d=ds[k];need(Object.hasOwn(d,'value')&&d.enumerable);out[k]=visit(d.value,depth+1);}return out;
 }
 return visit(value,0);
}
function exact(value,keys){need(value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join(',')===[...keys].sort().join(','));}
function namePair(names){need(names===null||Array.isArray(names)&&names.length===2&&names.every(n=>typeof n==='string'&&n.length<=80&&!/[\x00-\x1f\x7f]/.test(n)));return names;}
function numbers(pair,max,nullable=false){need(Array.isArray(pair)&&pair.length===2&&pair.every(n=>nullable&&n===null||uint(n,max)));}
function initialization(value){
 exact(value,['profile','characters','palettes','stage','seed','winRounds']);need(value.profile==='efz402-revival-local/1');
 numbers(value.characters,24);numbers(value.palettes,5);need(uint(value.stage,22)&&uint(value.seed,2147483646,1)&&uint(value.winRounds,3,1));return value;
}
function descriptor(value){
 const v=own(value);exact(v,['id','sourceStart','initialization','engineHash','names']);need(typeof v.id==='string'&&UUID.test(v.id));need(uint(v.sourceStart,1000000));
 need(typeof v.engineHash==='string'&&SHA.test(v.engineHash));initialization(v.initialization);namePair(v.names);return freeze({...v,clockOrigin:v.sourceStart});
}
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
function descriptorSame(a,b){return a.id===b.id&&a.sourceStart===b.sourceStart&&a.engineHash===b.engineHash&&same(a.names,b.names)&&
 a.initialization.profile===b.initialization.profile&&same(a.initialization.characters,b.initialization.characters)&&same(a.initialization.palettes,b.initialization.palettes)&&
 a.initialization.stage===b.initialization.stage&&a.initialization.seed===b.initialization.seed&&a.initialization.winRounds===b.initialization.winRounds;}

export const feedValidation=Object.freeze({fail,need,uint,clone,own,exact,namePair,numbers,descriptor,descriptorSame,UUID,SHA,SCHEMA,same});

export function validateBattleDescriptor(value){
 const v=own(value);exact(v,['id','sourceStart','clockOrigin','initialization','engineHash','names','availableFrames','terminal']);
 descriptor({id:v.id,sourceStart:v.sourceStart,initialization:v.initialization,engineHash:v.engineHash,names:v.names});
 need(v.clockOrigin===v.sourceStart&&uint(v.availableFrames,1152000));need(v.terminal===null||['complete','interrupted','error'].includes(v.terminal));return freeze(v);
}
export function validateFeedChunk(value,options){
 const o=own(options);need(o&&Object.keys(o).every(k=>['id','from'].includes(k))&&typeof o.id==='string'&&UUID.test(o.id));
 if(Object.hasOwn(o,'from'))need(uint(o.from,1152000));
 const v=own(value);exact(v,['schema','id','from','pairs','checks','availableFrames','terminal']);
 need(v.schema===SCHEMA&&v.id===o.id&&uint(v.availableFrames,1152000)&&uint(v.from,v.availableFrames));
 need(!Object.hasOwn(o,'from')||v.from===o.from);need(v.terminal===null||['complete','interrupted','error'].includes(v.terminal));
 need(Array.isArray(v.pairs)&&v.pairs.length<=1024&&Array.isArray(v.checks));const end=v.from+v.pairs.length;need(end<=v.availableFrames);
 for(const pair of v.pairs){numbers(pair,65535);need(pair.every(word=>(word&~0x23ff)===0));}
 let previous=-1;for(const check of v.checks){exact(check,['frame','sha256']);need(uint(check.frame,end-1,v.from)&&check.frame>previous&&typeof check.sha256==='string'&&SHA.test(check.sha256));previous=check.frame;}
 return freeze(v);
}
