// Narrow initial carry state observed across original BattleScene reuse. Applied
// once before the first update; never an instruction to overwrite later state.
export function validateBattleCarry(value,{sourceStart}={}){
 const need=(ok)=>{if(!ok)throw Error('BATTLE_CARRY: INVALID');};
 if(value===undefined)value={winner:0,fpsCount:0,fpsTime:0,fps:0};
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)));
 const ds=Object.getOwnPropertyDescriptors(value),keys=Reflect.ownKeys(ds),required=['winner','fpsCount','fpsTime','fps'],fields=[...required,'frameParity'];
 need(keys.length>=4&&keys.length<=5&&keys.every(k=>fields.includes(k))&&required.every(k=>keys.includes(k))&&keys.every(k=>Object.hasOwn(ds[k],'value')&&ds[k].enumerable));
 const out=Object.fromEntries(fields.map(k=>[k,Object.hasOwn(ds,k)?ds[k].value:0]));
 need(fields.every(k=>typeof out[k]==='number'&&Number.isFinite(out[k])&&!Object.is(out[k],-0)));
 need(out.winner===0||out.winner===1);
 need(out.frameParity===0||out.frameParity===1);
 need(['fpsCount','fps'].every(k=>Number.isSafeInteger(out[k])&&out[k]>=0&&out[k]<=1000000));
 need(out.fpsTime>=0&&out.fpsTime<=15625000);
 if(sourceStart!==undefined){need(Number.isSafeInteger(sourceStart)&&sourceStart>=0&&sourceStart<=1000000);need(out.fpsTime<=sourceStart*15.625);}
 return Object.freeze(out);
}
