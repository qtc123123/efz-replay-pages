// Experimental default battle boundary, not a claim that every character is qualified.
export const PROFILE='efz402-revival-normal/1';
export const ENGINE_SOURCE='fcdbd920af0b746badf56ad3af62446d1007329ea4ad630453f3b4adde6980ff';
export function integer(value,min,max,label){
 if(!Number.isInteger(value)||value<min||value>max)throw Error(label);return value;
}
export function validateInitialization(value){
 const keys=['profile','characters','palettes','stage','seed','winRounds'];
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!keys.includes(k))||value.profile!==PROFILE)throw Error('unsupported initialization profile');
 const pair=(v,max,label)=>{if(!Array.isArray(v)||v.length!==2)throw Error(label);return Object.freeze(v.map(x=>integer(x,0,max,label)));};
 const characters=pair(value.characters,24,'character'),palettes=pair(value.palettes,5,'palette');
 integer(value.stage,0,22,'stage');integer(value.seed,1,2147483646,'saved RNG state');
 if(value.winRounds!==2)throw Error('only default two-win initialization admitted');
 return Object.freeze({profile:PROFILE,characters,palettes,stage:value.stage,seed:value.seed,winRounds:2});
}
export function validatePair(pair){
 if(!Array.isArray(pair)||pair.length!==2)throw Error('input pair');
 pair.forEach(x=>integer(x,0,65535,'input word'));
 if(pair.some(x=>x>255))throw Error('auxiliary high-byte commands unsupported by this profile');
 return pair.slice();
}
