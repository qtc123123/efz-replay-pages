// Explicit experimental numerical ABI. No ambient Math modification or fallback.
export const EXPERIMENTAL_NUMERICS_PROFILE = 'efz-experimental-musl-wasm-v1';
export const EXPECTED_WASM_SHA256 = '62f78c8a740171ddc07e66ea7886cb13588bb9d0e47636502ee1a92447778f91';
export async function createExperimentalNumerics(bytes) {
  if (!(bytes instanceof Uint8Array)) throw new TypeError('numerics bytes must be Uint8Array');
  // Own the bytes before asynchronous validation: callers cannot mutate the
  // compiled payload between its digest check and compilation.
  const owned = new Uint8Array(bytes);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', owned));
  const sha = Array.from(digest, x => x.toString(16).padStart(2, '0')).join('');
  if (sha !== EXPECTED_WASM_SHA256) throw new Error('experimental numerics identity mismatch');
  const module = await WebAssembly.compile(owned);
  if (WebAssembly.Module.imports(module).length) throw new Error('numerics host imports forbidden');
  const instance = await WebAssembly.instantiate(module);
  const {efz_sin: sin, efz_cos: cos, efz_atan2: atan2, efz_pow: pow} = instance.exports;
  if (![sin, cos, atan2, pow].every(fn => typeof fn === 'function')) throw new Error('numerics exports missing');
  return Object.freeze({profile: EXPERIMENTAL_NUMERICS_PROFILE, sin, cos, atan2, pow});
}
