// One immutable full-session origin per fresh battle Worker. No host wall time.
let origin=0,bound=false,started=false;
export function bindLiveClockOrigin(value){
 if(bound||started||!Number.isSafeInteger(value)||value<0||value>1000000)throw Error('LIVE_CLOCK_ORIGIN');origin=value;bound=true;
}
export function createCompletedUpdateClock(){
 let completed=0,pending=null;const boundary=n=>{if(!Number.isInteger(n)||n<0||n>0xffffffff)throw Error('ENGINE_CLOCK: boundary');};const idle=()=>{if(pending!==null)throw Error('ENGINE_CLOCK: busy');};
 return Object.freeze({now:()=>(origin+(pending??completed))*15.625,snapshot(){idle();return completed;},
 begin(frame){idle();boundary(frame);if(frame!==completed||frame===0xffffffff)throw Error('ENGINE_CLOCK: boundary');started=true;pending=frame+1;},
 complete(next){boundary(next);if(pending===null||next!==pending)throw Error('ENGINE_CLOCK: boundary');completed=next;pending=null;},abort(){pending=null;},restore(next){idle();boundary(next);completed=next;}});
}
