import {createLocalReplaySpectator} from './engine/efz-engine.mjs';
import {createPageReplayCatalog} from '../src/pages/replay-session.mjs';
import {bindLiveClockOrigin} from './clock.mjs';
import {LIVE_ENGINE_HASH} from './build.mjs';
import {verifyViewerFrame} from './frame-hash.mjs';
import {installLiveWorker} from './worker-runtime.mjs';
installLiveWorker(self,{createEngine:createLocalReplaySpectator,
 createCatalog:(manifest,initialization,root,key,location)=>createPageReplayCatalog(manifest,initialization,root,key,undefined,location),
 bindClockOrigin:bindLiveClockOrigin,engineHash:LIVE_ENGINE_HASH,verifyFrame:verifyViewerFrame});
