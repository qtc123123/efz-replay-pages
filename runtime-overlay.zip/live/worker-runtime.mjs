import {createLivePlayback} from './viewer-core.mjs';
import {validateBattleDescriptor,validateFeedChunk} from './protocol.mjs';

const need=(ok,code)=>{if(!ok)throw Error('LIVE_WORKER: '+code);};
function fields(value,required,optional=[]){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'MESSAGE');
 const keys=Reflect.ownKeys(value);need(keys.length<=required.length+optional.length&&required.every(k=>keys.includes(k))&&keys.every(k=>required.includes(k)||optional.includes(k)),'FIELDS');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&Object.hasOwn(d,'value')&&d.enumerable,'ACCESSOR');out[key]=d.value;}return out;
}
// Asset manifest is data-only. Catalog remains responsible for format/path/root
// authorization; this boundary limits copying and refuses executable descriptors.
function ownManifest(value){
 let nodes=0,bytes=0;
 function copy(v,depth){
  need(++nodes<=100000&&depth<=12,'MANIFEST_BOUND');
  if(v===null||typeof v==='boolean')return v;
  if(typeof v==='number'){need(Number.isFinite(v),'MANIFEST_NUMBER');return v;}
  if(typeof v==='string'){bytes+=v.length*2;need(v.length<=4096&&bytes<=4194304,'MANIFEST_BOUND');return v;}
  need(v&&typeof v==='object','MANIFEST_DATA');const array=Array.isArray(v);
  need(array?Object.getPrototypeOf(v)===Array.prototype:[Object.prototype,null].includes(Object.getPrototypeOf(v)),'MANIFEST_DATA');
  const keys=Reflect.ownKeys(v);need(keys.every(k=>typeof k==='string'),'MANIFEST_DATA');
  if(array){need(v.length<=20000&&keys.length===v.length+1,'MANIFEST_BOUND');const out=[];for(let i=0;i<v.length;i++){const d=Object.getOwnPropertyDescriptor(v,String(i));need(d&&Object.hasOwn(d,'value')&&d.enumerable,'MANIFEST_ACCESSOR');out.push(copy(d.value,depth+1));}return out;}
  need(keys.length<=32,'MANIFEST_BOUND');const out={};for(const key of keys){need(key!=='__proto__','MANIFEST_DATA');const d=Object.getOwnPropertyDescriptor(v,key);need(d&&Object.hasOwn(d,'value')&&d.enumerable,'MANIFEST_ACCESSOR');out[key]=copy(d.value,depth+1);}return out;
 }return copy(value,0);
}
function command(value){
 const head=fields(value,['id','type'],['descriptor','manifest','assetRoot','key','chunk','count']);
 need(Number.isSafeInteger(head.id)&&head.id>0,'ID');need(typeof head.type==='string','TYPE');
 if(head.type==='init'){
  const v=fields(value,['id','type','descriptor','manifest','assetRoot','key']);
  need(typeof v.assetRoot==='string'&&v.assetRoot.length<=4096,'ASSET_ROOT');
  need(v.key instanceof Uint8Array&&Object.getPrototypeOf(v.key)===Uint8Array.prototype&&Reflect.ownKeys(v.key).length===32&&v.key.byteLength===32&&Object.getPrototypeOf(v.key.buffer)===ArrayBuffer.prototype,'KEY');
  return {...v,descriptor:validateBattleDescriptor(v.descriptor),manifest:ownManifest(v.manifest),key:v.key.slice()};
 }
 if(head.type==='append'){const v=fields(value,['id','type','chunk']);const c=fields(v.chunk,['schema','id','from','pairs','checks','availableFrames','terminal']);return {...v,chunk:validateFeedChunk(c,{id:c.id})};}
 if(head.type==='step'){const v=fields(value,['id','type'],['count']);const count=v.count??1;need(Number.isInteger(count)&&count>=1&&count<=16,'COUNT');return {...v,count};}
 need(head.type==='dispose','TYPE');return fields(value,['id','type']);
}
function ownedFrame(frame,silent){
 const image=frame.image;
 need(image&&image.width===320&&image.height===240&&image.pixels instanceof Uint8Array&&image.pixels.byteLength===76800&&image.palette instanceof Uint8Array&&image.palette.byteLength===1024,'IMAGE');
 const result=structuredClone(frame.result);if(silent&&result&&typeof result==='object')result.soundEvents=[];
 return {frame:frame.frame,nextFrame:frame.nextFrame,result,inspection:structuredClone(frame.inspection),image:{width:320,height:240,pixels:image.pixels.slice(),palette:image.palette.slice()}};
}

/** One dedicated Worker / one game. Public messages never import an engine URL. */
export function installLiveWorker(scope,{createEngine,createCatalog,bindClockOrigin,engineHash,verifyFrame}){
 need(scope&&typeof scope.postMessage==='function'&&typeof scope.addEventListener==='function'&&typeof scope.removeEventListener==='function','SCOPE');
 need([createEngine,createCatalog,bindClockOrigin,verifyFrame].every(f=>typeof f==='function')&&typeof engineHash==='string'&&/^[a-f0-9]{64}$/.test(engineHash),'DEPENDENCIES');
 let lastId=0,core=null,assets=null,current=null,closing=false,initialized=false,retirement=null,assetRetirement=null,coreRetirement=null,failure=null,disposeId=null,lastFrame=null,silent=false;
 const queue=[];
 const post=value=>{const image=value.value?.frame?.image;scope.postMessage(value,image?[image.pixels.buffer,image.palette.buffer]:[]);};
 function stopAssets(){
  if(!assets||assetRetirement)return assetRetirement;
  try{assetRetirement=Promise.resolve(assets.dispose());}catch(error){assetRetirement=Promise.reject(error);}
  assetRetirement.catch(()=>{});return assetRetirement;
 }
 function closeCore(){
  if(!core||coreRetirement)return coreRetirement;
  try{coreRetirement=Promise.resolve(core.close());}catch(error){coreRetirement=Promise.reject(error);}
  coreRetirement.catch(()=>{});return coreRetirement;
 }
 function errorMessage(id,error){
  const raw=String(error?.message??'failure');
  // Dependency errors may contain private paths/URLs or credentials. Only our
  // finite protocol codes are exposed; details remain in the caller's context.
  const message=/^LIVE_WORKER: [A-Z_]+$/.test(raw)?raw:'LIVE_WORKER: FAILED';
  try{scope.postMessage({id,type:'error',message,fatal:true});}catch{/* Posting itself failed; custody still closes. */}
 }
 function beginClose(){
  if(retirement)return retirement;closing=true;for(const item of queue)item.key?.fill(0);queue.length=0;
  stopAssets();closeCore();
  const pending=current;
  retirement=(async()=>{
   await pending?.catch(()=>{});stopAssets();closeCore();
   const results=await Promise.allSettled([assetRetirement,coreRetirement]);
   const failed=results.find(r=>r.status==='rejected');
   scope.removeEventListener('message',receive);
   if(failed){if(!failure)failure={id:disposeId??lastId,error:failed.reason};}
   if(failure)errorMessage(failure.id,failure.error);
   else if(disposeId!==null){try{post({id:disposeId,type:'result',operation:'dispose',value:{status:{state:'closed'}}});}catch(error){errorMessage(disposeId,error);}}
   if(failed)throw failed.reason;
  })();retirement.catch(()=>{});return retirement;
 }
 function fatal(id,error){if(!closing){failure={id,error};void beginClose();}}
 async function execute(message){
  if(message.type==='init'){
   need(!initialized,'ALREADY_INITIALIZED');initialized=true;need(message.descriptor.engineHash===engineHash,'ENGINE_HASH');
   core=createLivePlayback({descriptor:message.descriptor,
    createEngine:async()=>{
     try{
      assets=await createCatalog(message.manifest,message.descriptor.initialization,message.assetRoot,message.key,scope.location?.href);
     }finally{message.key.fill(0);}
     need(assets&&typeof assets.loadForSimulation==='function'&&typeof assets.dispose==='function','CATALOG');
     if(closing){stopAssets();throw Error('LIVE_WORKER: CLOSED');}
     await assets.loadForSimulation();if(closing)throw Error('LIVE_WORKER: CLOSED');
     bindClockOrigin(message.descriptor.clockOrigin);
     return createEngine(message.descriptor.initialization,assets,message.descriptor.battleCarry);
    },verifyFrame:value=>verifyFrame(value),onFrame:frame=>{if(!closing)lastFrame=ownedFrame(frame,silent);}});
   await core.prepare();if(!closing)post({id:message.id,type:'result',operation:'init',value:{status:core.status()}});return;
  }
  need(core&&initialized,'UNINITIALIZED');
  if(message.type==='append'){core.append(message.chunk);if(!closing)post({id:message.id,type:'result',operation:'append',value:{status:core.status()}});return;}
  lastFrame=null;silent=message.count>1;let result;
  for(let i=0;i<message.count&&!closing;i++){result=await core.step();if(result.kind!=='advanced')break;}
  if(!closing)post({id:message.id,type:'result',operation:'step',value:{status:core.status(),kind:result.kind,...(lastFrame?{frame:lastFrame}:{})}});
  lastFrame=null;
 }
 function pump(){
  if(current||closing||queue.length===0)return;const message=queue.shift();
  current=Promise.resolve().then(()=>execute(message));const running=current;
  running.then(()=>{},error=>{if(!closing)fatal(message.id,error);}).finally(()=>{message.key?.fill(0);if(current===running)current=null;pump();});
 }
 function receive(event){
  if(closing)return;let message,id=null;
  try{
   const raw=event.data;const d=raw&&typeof raw==='object'?Object.getOwnPropertyDescriptor(raw,'id'):null;if(d&&Object.hasOwn(d,'value')&&Number.isSafeInteger(d.value))id=d.value;
   message=command(raw);need(message.id>lastId,'ID_ORDER');lastId=message.id;
   if(message.type==='dispose'){disposeId=message.id;void beginClose();return;}
   need(queue.length+(current?1:0)<8,'QUEUE');queue.push(message);pump();
  }catch(error){message?.key?.fill(0);fatal(id,error);}
 }
 scope.addEventListener('message',receive);
 return Object.freeze({close:()=>beginClose()});
}
