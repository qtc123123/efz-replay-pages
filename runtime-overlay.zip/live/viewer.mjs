import {validateBattleDescriptor,validateFeedChunk} from './protocol.mjs';
import {LIVE_ENGINE_HASH} from './build.mjs';
const need=(ok,message)=>{if(!ok)throw Error(message);};
export function feedOrigin(value){const u=new URL(value);need(u.protocol==='https:'&&!u.username&&!u.password&&u.pathname==='/'&&!u.search&&!u.hash,'Use an HTTPS feed origin without credentials or a path.');return u.origin;}
export async function fetchJSON(url,{fetcher=fetch,signal,max=262144,expected=null}={}){
 const response=await fetcher(url,{signal,credentials:'omit',redirect:'error',cache:'no-store'});need(response.ok&&response.body,'Feed or resource request failed.');
 const reader=response.body.getReader(),parts=[];let size=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;need(size<=max,'Response exceeds its limit.');parts.push(value);}}catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let at=0;for(const p of parts){bytes.set(p,at);at+=p.length;}
 if(expected){const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');need(size===expected.bytes&&sha===expected.sha256,'Resource integrity check failed.');}
 return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
export function validateManifest(v){
 need(v?.schema==='efz-live-feed/1'&&v.experimental===true&&Array.isArray(v.games)&&v.games.length<=3,'Unsupported live feed.');
 const s=v.session;need(s&&['waiting','selection','playing','ended','error'].includes(s.state),'Invalid session status.');
 need(s.names===null||Array.isArray(s.names)&&s.names.length===2&&s.names.every(n=>typeof n==='string'&&n.length<=80&&!/[\x00-\x1f\x7f]/.test(n)),'Invalid names.');
 need(s.selection===null||s.selection&&['characters','palettes'].every(k=>Array.isArray(s.selection[k])&&s.selection[k].length===2&&s.selection[k].every(n=>n===null||Number.isInteger(n)&&n>=0&&n<=(k==='characters'?24:5)))&&(s.selection.stage===null||Number.isInteger(s.selection.stage)&&s.selection.stage>=0&&s.selection.stage<=22),'Invalid selection.');
 const games=v.games.map(validateBattleDescriptor);need(new Set(games.map(g=>g.id)).size===games.length,'Duplicate game.');return {...v,games};
}
export function createWorkerClient(worker,{timeout=90000}={}){
 let nextId=0,closed=false,retiring=null;const pending=new Map();
 function rejectAll(error){for(const p of pending.values()){clearTimeout(p.timer);p.reject(error);}pending.clear();}
 function finish(){closed=true;rejectAll(Error('Worker closed.'));worker.removeEventListener('message',message);worker.removeEventListener('error',failed);worker.removeEventListener('messageerror',failed);worker.terminate();}
 function failed(){finish();}
 function message({data}){const p=pending.get(data?.id);if(!p)return;if(data.type==='error'){clearTimeout(p.timer);pending.delete(data.id);p.reject(Error(data.message||'Worker failed.'));finish();return;}if(data.type!=='result'||data.operation!==p.type){p.reject(Error('Invalid worker response.'));finish();return;}clearTimeout(p.timer);pending.delete(data.id);p.resolve(data.value);}
 worker.addEventListener('message',message);worker.addEventListener('error',failed);worker.addEventListener('messageerror',failed);
 function send(type,payload={},duration=timeout){return new Promise((resolve,reject)=>{const id=++nextId,timer=setTimeout(()=>{pending.delete(id);reject(Error('Worker timed out.'));finish();},duration);pending.set(id,{type,resolve,reject,timer});try{worker.postMessage({id,type,...payload});}catch(error){clearTimeout(timer);pending.delete(id);reject(error);finish();}});}
 return Object.freeze({request(type,payload){if(closed)return Promise.reject(Error('Worker closed.'));if(pending.size>=2)return Promise.reject(Error('Worker busy.'));return send(type,payload);},close(){if(retiring)return retiring;if(closed)return Promise.resolve();closed=true;rejectAll(Error('Worker closed.'));retiring=send('dispose',{},3000).catch(()=>{}).finally(finish);return retiring;}});
}
export function rgbaPixels(image){need(image?.width===320&&image.height===240&&image.pixels instanceof Uint8Array&&image.pixels.length===76800&&image.palette instanceof Uint8Array&&image.palette.length===1024,'Invalid game image.');const out=new Uint8ClampedArray(307200);for(let i=0;i<76800;i++){const c=image.pixels[i]*4,o=i*4;out[o]=image.palette[c];out[o+1]=image.palette[c+1];out[o+2]=image.palette[c+2];out[o+3]=255;}return out;}

export function createLiveAudio({sounds,music}){
 let generation=1,seekRevision=0,nextFrame=0,muted=true,ready=false,closed=false,retiring=null,playing=false,preparing=null;
 const tasks=new Set(),ids=()=>({generation,replayId:1,seekRevision});
 const track=p=>{const promise=Promise.resolve(p);tasks.add(promise);promise.then(()=>tasks.delete(promise),()=>tasks.delete(promise));return promise;};
 sounds.bindReplay(ids());music.prepareSeekCommit({...ids(),nextFrame:0,musicState:{schema:'efz-local-music/1',nextUpdate:0,volume:0,stopped:false}})();sounds.setVolume(0);music.setVolume(0);
 function pause(){playing=false;sounds.pause();music.pause();}
 function resume(){if(closed||muted||!ready||playing)return Promise.resolve();playing=true;return track(Promise.all([sounds.play(),music.play()]));}
 return Object.freeze({
  status:()=>({muted,ready,closed}),
  prepare(){if(!preparing)preparing=track(Promise.all([sounds.prepare(),music.prepare()]).then(()=>{if(!closed)ready=true;}));return preparing;},
  enable(){need(!closed&&ready,'Audio is still preparing.');muted=false;sounds.setVolume(.7);music.setVolume(.5);return resume();},
  mute(){if(closed)return;muted=true;sounds.setVolume(0);music.setVolume(0);pause();},
  pause,
  resume,
  present(frame,{playing:visiblePlaying,silent=false}){
   if(closed)return;const n=frame.nextFrame;need(Number.isInteger(n)&&n>nextFrame,'Audio frame order.');
   if(silent||n!==nextFrame+1){pause();generation++;seekRevision++;sounds.prepareSeekCommit({...ids(),nextFrame:n})();music.prepareSeekCommit({...ids(),nextFrame:n,musicState:frame.result.musicState})();nextFrame=n;return;}
   const audible=visiblePlaying&&!muted&&ready;
   if(!audible&&playing)pause();
   const packet={...ids(),status:{state:audible?'playing':'paused',nextFrame:n},result:frame.result};sounds.present(packet);music.present(packet);nextFrame=n;
  },
  close(){if(retiring)return retiring;closed=true;muted=true;ready=false;try{pause();}catch{}const disposal=Promise.allSettled([Promise.resolve().then(()=>sounds.dispose()),Promise.resolve().then(()=>music.dispose())]);retiring=(async()=>{const results=await disposal;await Promise.allSettled([...tasks]);const failed=results.find(r=>r.status==='rejected');if(failed)throw failed.reason;})();return retiring;}
 });
}

export function stopLivePlayback(audio,stop){stop();audio?.pause();}
export async function resumeCurrentAudio(audio,isCurrent,onError){
 try{await audio?.resume();}catch{if(isCurrent())onError();}
}

export function renderPaletteWarning(element,descriptor){
 const sides=descriptor.paletteFallbackSides??[];
 need(Array.isArray(sides)&&sides.length<=2&&sides.every(side=>side===0||side===1)&&new Set(sides).size===sides.length,'Invalid palette provenance.');
 element.textContent=sides.length?`Custom palette unavailable for ${sides.slice().sort().map(side=>'P'+(side+1)).join('/')}; stock colours shown`:'';
 element.hidden=sides.length===0;
}

async function mount(){
 const $=id=>document.getElementById(id),canvas=$('screen'),context=canvas.getContext('2d',{alpha:false});
 let epoch=0,abort=null,owner=null,audio=null,origin=null,games=[],selected=null,buffered=0,available=0,frame=0,playing=false,busy=false,pollTimer=null,tickTimer=null,catchingUp=false,nextTick=0;
 const audioRetirements=new Set();
 function retireAudio(value){if(!value)return Promise.resolve();const result=value.close();audioRetirements.add(result);result.then(()=>audioRetirements.delete(result),()=>audioRetirements.delete(result));return result;}
 const note=text=>{$('status').textContent=text;};
 const characterNames=['Rumi','Ayu','Mai','Makoto','Akane','Mayu','Mizuka','Misaki','Shiori','Sayuri','Nayuki','Mio','Doppel','Kaori','Ikumi','Mishio','Akiko','Nayuki B','UNKNOWN','Kanna','Kano','Minagi','Nayuki','Misuzu','Mizuka'];
 const character=id=>characterNames[id]??`Character ${id}`;
 function stopTimers(){clearTimeout(pollTimer);clearTimeout(tickTimer);pollTimer=tickTimer=null;}
 async function disconnect(){const mine=++epoch;playing=false;catchingUp=false;stopTimers();abort?.abort();abort=null;const old=owner,oldAudio=audio;owner=null;audio=null;selected=null;busy=false;await Promise.allSettled([old?.close(),retireAudio(oldAudio),...audioRetirements]);if(mine!==epoch)return mine;$('play').disabled=true;$('catch-up').disabled=true;$('disconnect').disabled=true;$('sound').disabled=true;$('sound').textContent='🔇';$('sound').setAttribute('aria-pressed','false');renderPaletteWarning($('palette-warning'),{});return mine;}
 function request(url,options={}){return fetchJSON(url,{...options,signal:AbortSignal.any([abort.signal,AbortSignal.timeout(15000)])});}
 async function assets(signal){
  const configURL=new URL('../deployment/config.json',import.meta.url);const config=await fetchJSON(configURL,{signal,max:65536});
  need(['miracle-replay-pages/2','miracle-replay-pages/3'].includes(config.schema)&&config.manifestUrl==='./assets/manifest.json'&&/^[a-f0-9]{64}$/.test(config.manifestSha256)&&Number.isInteger(config.manifestBytes)&&config.manifestBytes>0&&config.manifestBytes<=4194304,'Unsupported resource configuration.');
  const manifest=await fetchJSON(new URL(config.manifestUrl,configURL),{signal,max:4194304,expected:{bytes:config.manifestBytes,sha256:config.manifestSha256}});
  const {resourceKey}=await import('../deployment/resource-access.mjs');return {manifest,key:resourceKey(config.manifestSha256),assetRoot:new URL('./assets/',configURL).href};
 }

 function audioFailed(mine){if(mine!==epoch)return;const old=audio;audio=null;$('sound').disabled=true;$('sound').textContent='🔇';$('audio-status').textContent='Audio unavailable; video continues.';void retireAudio(old).catch(()=>{});}
 async function setupAudio(data,descriptor,mine){
  try{
   const [{createReplaySounds},{createReplayMusic},{STAGE_MUSIC_PATHS}]=await Promise.all([import('../src/pages/replay-sounds.mjs'),import('../src/pages/replay-music.mjs'),import('../src/asset-selection.mjs')]);
   if(mine!==epoch)return;
   let sounds=null,music=null;
   try{sounds=createReplaySounds({...data,characters:descriptor.initialization.characters});music=createReplayMusic({...data,path:STAGE_MUSIC_PATHS[descriptor.initialization.stage]});audio=createLiveAudio({sounds,music});}
   catch(error){await Promise.allSettled([sounds?.dispose(),music?.dispose()]);throw error;}
   const current=audio;$('sound').disabled=true;$('audio-status').textContent='Preparing audio…';
   current.prepare().then(()=>{if(mine===epoch&&audio===current){$('sound').disabled=false;$('audio-status').textContent='Sound muted. Tap the speaker to enable.';}},()=>audioFailed(mine));
  }catch{audioFailed(mine);}
 }
 function render(f){context.putImageData(new ImageData(rgbaPixels(f.image),320,240),0,0);$('placeholder').hidden=true;const chars=f.inspection.characters?.every(Boolean)?f.inspection.characters:f.inspection.lastCharacters;if(chars)$('details').textContent=chars.map((c,i)=>`${selected.names?.[i]||`P${i+1}`} · HP ${Math.max(0,Math.ceil(c.life))} · SP ${Math.floor(c.meter)} · RF ${Math.floor(c.rf)} · Wins ${c.wins}`).join('  |  ');}
 function controls(){ $('play').textContent=playing?'Pause':'Play';$('position').textContent=`${(frame/64).toFixed(1)}s / ${(available/64).toFixed(1)}s received`; }
 async function step(count=catchingUp&&available-frame>32?16:1){if(!owner||busy||!playing)return;const mine=epoch,current=owner;busy=true;try{const value=await current.request('step',{count});if(mine!==epoch)return;frame=value.status.nextFrame;if(value.frame){render(value.frame);try{audio?.present(value.frame,{playing,silent:count>1});if(count===1&&playing&&audio?.status().ready&&!audio.status().muted)void audio.resume().catch(()=>audioFailed(mine));}catch{audioFailed(mine);}}if(value.kind==='waiting'){audio?.pause();note('Waiting for received inputs…');}else if(value.kind==='advanced')note(selected.terminal?'Playing received game':'Watching live game');else{playing=false;audio?.pause();note(value.kind==='complete'?'Game finished.':`Stream ${value.kind}.`);}controls();}catch(error){if(mine===epoch){playing=false;audio?.pause();note(error.message);}}finally{if(mine===epoch){busy=false;if(playing){if(catchingUp&&available-frame<=32)catchingUp=false;nextTick=Math.max(nextTick+1000/64,performance.now()-1000/64);tickTimer=setTimeout(()=>step(),catchingUp?0:Math.max(0,nextTick-performance.now()));}}}}
 async function append(){if(!owner||!selected)return;const mine=epoch,current=owner;const chunk=validateFeedChunk(await request(`${origin}/api/live/games/${selected.id}?from=${buffered}&limit=1024`),{id:selected.id,from:buffered});if(mine!==epoch)return;await current.request('append',{chunk});if(mine!==epoch)return;buffered+=chunk.pairs.length;available=chunk.availableFrames;selected={...selected,terminal:chunk.terminal};controls();return chunk.pairs.length;}
 async function choose(id){const descriptor=games.find(g=>g.id===id);if(!descriptor)return;const base=origin,mine=await disconnect();if(mine!==epoch)return;origin=base;abort=new AbortController();selected=descriptor;renderPaletteWarning($('palette-warning'),descriptor);buffered=frame=0;available=descriptor.availableFrames;note('Preparing selected game assets…');$('disconnect').disabled=false;try{need(descriptor.engineHash===LIVE_ENGINE_HASH,'This feed needs a different viewer build.');const data=await assets(AbortSignal.any([abort.signal,AbortSignal.timeout(90000)]));if(mine!==epoch){data.key.fill(0);return;}await setupAudio(data,descriptor,mine);if(mine!==epoch){data.key.fill(0);return;}owner=createWorkerClient(new Worker(new URL('./viewer-worker.mjs',import.meta.url),{type:'module'}));try{await owner.request('init',{descriptor,...data});}finally{data.key.fill(0);}if(mine!==epoch)return;await append();if(mine!==epoch)return;$('match').textContent=`${descriptor.names?.[0]||'P1'} vs ${descriptor.names?.[1]||'P2'} · ${descriptor.initialization.characters.map(character).join(' / ')} · Stage ${descriptor.initialization.stage}`;$('play').disabled=false;$('catch-up').disabled=false;playing=!document.hidden;nextTick=performance.now();controls();if(playing)step();pollTimer=setTimeout(()=>poll(mine),500);}catch(error){if(mine===epoch){note(error.message);const old=owner,oldAudio=audio;owner=null;audio=null;await Promise.allSettled([old?.close(),retireAudio(oldAudio),...audioRetirements]);}}}
 function list(manifest){games=manifest.games;const select=$('games'),previous=select.value;select.replaceChildren(...games.map(g=>{const option=document.createElement('option');option.value=g.id;option.textContent=`${g.names?.join(' vs ')||'Game'} · ${g.terminal??'live'}`;return option;}));if(games.some(g=>g.id===previous))select.value=previous;select.disabled=games.length===0;$('session').textContent=`Session: ${manifest.session.state}${manifest.session.names?' · '+manifest.session.names.join(' vs '):''}`;}
 async function poll(mine){if(mine!==epoch)return;try{const manifest=validateManifest(await request(`${origin}/api/live`));if(mine!==epoch)return;list(manifest);if(!selected&&games.length){await choose(games.at(-1).id);return;}if(selected){if(!games.some(g=>g.id===selected.id)){stopLivePlayback(audio,()=>{playing=false;});note('This game is no longer available. Choose another game.');}else if(buffered-frame<2048)await append();}}catch(error){if(mine===epoch){playing=false;audio?.pause();note(`Feed paused: ${error.message}`);controls();}}finally{if(mine===epoch)pollTimer=setTimeout(()=>poll(mine),buffered<available?100:1000);}}
 $('connect').addEventListener('submit',async event=>{event.preventDefault();const mine=await disconnect();if(mine!==epoch)return;try{origin=feedOrigin($('endpoint').value.trim());abort=new AbortController();$('disconnect').disabled=false;note('Connecting to experimental feed…');await poll(epoch);}catch(error){note(error.message);}});
 $('games').addEventListener('change',()=>choose($('games').value));$('disconnect').addEventListener('click',async()=>{const mine=await disconnect();if(mine===epoch){note('Disconnected.');controls();}});
 $('play').addEventListener('click',()=>{playing=!playing;controls();if(!playing)audio?.pause();else{const currentAudio=audio,mine=epoch;void resumeCurrentAudio(currentAudio,()=>mine===epoch&&audio===currentAudio,()=>audioFailed(mine));}if(playing&&!busy){clearTimeout(tickTimer);step();}});
 $('catch-up').addEventListener('click',()=>{audio?.pause();playing=true;catchingUp=true;nextTick=performance.now();clearTimeout(tickTimer);if(!busy)step(16);controls();});
 $('sound').addEventListener('click',()=>{if(!audio)return;const current=audio,mine=epoch;if(current.status().muted){const activated=current.enable();if(!playing)current.pause();void activated.then(()=>{if(mine===epoch&&audio===current&&!current.status().muted){$('sound').textContent='🔊';$('sound').setAttribute('aria-pressed','true');$('audio-status').textContent='Sound enabled.';}},()=>audioFailed(mine));}else{current.mute();$('sound').textContent='🔇';$('sound').setAttribute('aria-pressed','false');$('audio-status').textContent='Sound muted.';}});
 $('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await $('player').requestFullscreen();}catch{note('Fullscreen is unavailable in this browser.');}});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){audio?.pause();playing=false;clearTimeout(tickTimer);controls();}});window.addEventListener('pagehide',()=>void disconnect());
 const supplied=new URL(location.href).searchParams.get('feed');if(supplied){try{$('endpoint').value=feedOrigin(supplied);}catch{note('Invalid feed link.');}}
}
if(typeof document!=='undefined')mount().catch(()=>{const status=document.getElementById('status');if(status)status.textContent='The experimental viewer could not start.';});
