// Finite custody and playback budget for one experimental source session.
export const MAX_LIVE_FRAMES=524288;
export const MAX_LIVE_GAMES=32;
export const MAX_QUEUED_EVENTS=32768;
