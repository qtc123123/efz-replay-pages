import {MAX_LIVE_FRAMES} from './limits.mjs';
import {validateBattleDescriptor,validateFeedChunk} from './protocol.mjs';
const need=(ok,code)=>{if(!ok)throw Error('LIVE_VIEWER: '+code);};
const same=(a,b)=>a[0]===b[0]&&a[1]===b[1];
/** One owner, one battle, one fresh engine realm. No cross-game restoration. */
export function createLivePlayback({descriptor,createEngine,verifyFrame=async()=>true,onFrame=()=>{}}){
 const game=validateBattleDescriptor(descriptor);need(typeof createEngine==='function'&&typeof verifyFrame==='function'&&typeof onFrame==='function','DEPENDENCIES');
 const pairs=[],checks=new Map();let available=game.availableFrames,terminal=game.terminal,next=0,engine=null,state='new',preparing=null,inflight=null,retirement=null,closing=false;
 const api={
  descriptor:game,
  status(){return Object.freeze({state,nextFrame:next,bufferedFrames:pairs.length,availableFrames:available,terminal});},
  prepare(){
   need(state==='new'&&!closing,'STATE');state='loading';
   preparing=(async()=>{try{const candidate=await createEngine(game);if(closing){await candidate.dispose();return;}engine=candidate;state='ready';}catch(e){state='failed';throw e;}})();return preparing;
  },
  append(value){
   need(!closing&&state!=='failed','CLOSED_OR_FAILED');const chunk=validateFeedChunk(value,{id:game.id});need(chunk.id===game.id,'GAME');
   need(chunk.from<=pairs.length,'GAP');need(chunk.availableFrames>=available,'REGRESSION');need(chunk.from+chunk.pairs.length<=MAX_LIVE_FRAMES,'CAPACITY');
   need(terminal===null||chunk.terminal===terminal,'TERMINAL_CHANGE');
   for(let i=0;i<chunk.pairs.length&&chunk.from+i<pairs.length;i++)need(same(chunk.pairs[i],pairs[chunk.from+i]),'CONFLICT');
   for(const c of chunk.checks)need(!checks.has(c.frame)||checks.get(c.frame)===c.sha256,'CONFLICT');
   const extra=Math.max(0,chunk.from+chunk.pairs.length-pairs.length);if(extra)pairs.push(...chunk.pairs.slice(chunk.pairs.length-extra));
   for(const c of chunk.checks)checks.set(c.frame,c.sha256);available=chunk.availableFrames;terminal=chunk.terminal;return pairs.length;
  },
  async step(){
   need(!closing,'CLOSED');need(state!=='failed','FAILED');need(engine&&state==='ready'&&!inflight,'BUSY_OR_UNREADY');
   if(next===pairs.length){
    if(terminal!==null&&next===available){
     if(terminal==='complete'&&!engine.inspect().ended){state='failed';return Promise.reject(Error('LIVE_VIEWER: TERMINAL_MISMATCH'));}
     return Promise.resolve({kind:terminal});
    }
    return Promise.resolve({kind:'waiting'});
   }
   const frame=next,pair=pairs[frame].slice();
   inflight=(async()=>{try{
    const result=await engine.advance(frame,pair);if(closing)return {kind:'closed'};
    const inspection=engine.inspect(),image=engine.presentation(),expectedHash=checks.get(frame)??null;
    if(expectedHash!==null)need(await verifyFrame({frame,result,inspection,image,expectedHash}),'DESYNC');
    if(closing)return {kind:'closed'};
    next++;await onFrame({frame,nextFrame:next,result,inspection,image,expectedHash});return {kind:'advanced',nextFrame:next};
   }catch(e){state='failed';throw e;}finally{inflight=null;}})();return inflight;
  },
  close(){
   if(retirement)return retirement;closing=true;
   retirement=(async()=>{await preparing?.catch(()=>{});await inflight?.catch(()=>{});const old=engine;engine=null;try{await old?.dispose();}finally{pairs.length=0;checks.clear();state='closed';}})();return retirement;
  }
 };
 return Object.freeze(api);
}
