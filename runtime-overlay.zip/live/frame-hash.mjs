const need=(v,c)=>{if(!v)throw Error('LIVE_HASH: '+c);};
const keys=['id','life','wins','state','frame','timer','x','y','meter','rf'];
const f64=value=>{need(typeof value==='number'&&Number.isFinite(value),'NUMBER');const b=new ArrayBuffer(8);new DataView(b).setFloat64(0,value,true);return Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('');};
export async function hashBattleFrame(row){
 need(row&&Number.isSafeInteger(row.frame)&&row.frame>=0&&row.frame<=1000000,'FRAME');
 need(Array.isArray(row.characters)&&row.characters.length===2,'CHARACTERS');
 need(row.pixels instanceof Uint8Array&&row.pixels.length===76800&&row.palette instanceof Uint8Array&&row.palette.length===1024,'IMAGE');
 const canonical={schema:'efz-live-frame/1',frame:f64(row.frame),rng:f64(row.rng),draws:f64(row.draws),round:f64(row.round),roundOver:f64(row.roundOver),winner:f64(row.winner),intro:f64(row.intro),characters:row.characters.map(c=>Object.fromEntries(keys.map(k=>[k,f64(c[k])])))};
 const prefix=new TextEncoder().encode(JSON.stringify(canonical)),bytes=new Uint8Array(prefix.length+1+row.pixels.length+row.palette.length);bytes.set(prefix);bytes.set(row.pixels,prefix.length+1);bytes.set(row.palette,prefix.length+1+row.pixels.length);
 const hash=await crypto.subtle.digest('SHA-256',bytes);return Array.from(new Uint8Array(hash),x=>x.toString(16).padStart(2,'0')).join('');
}
export function viewerObservation({frame,inspection,image}){
 const chars=inspection.characters?.every(Boolean)?inspection.characters:inspection.lastCharacters;
 return {frame,rng:inspection.rng,draws:inspection.draws,round:inspection.round,roundOver:inspection.roundOver,winner:inspection.winner,intro:inspection.intro,characters:chars,pixels:image.pixels,palette:image.palette};
}
export const verifyViewerFrame=async value=>(await hashBattleFrame(viewerObservation(value)))===value.expectedHash;
