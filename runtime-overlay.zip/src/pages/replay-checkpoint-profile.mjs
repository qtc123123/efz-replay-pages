/** Generated-core qualification only; this is not original-native parity. */
export const REPLAY_CHECKPOINT_PROFILES=Object.freeze([
 Object.freeze({format:'revival-pairs',characters:Object.freeze([6,12]),stage:14,palettes:Object.freeze([1,0]),winRounds:2}),
 Object.freeze({format:'native-tape',characters:Object.freeze([6,20]),stage:0,palettes:Object.freeze([0,0]),winRounds:2}),
 Object.freeze({format:'revival-pairs',characters:Object.freeze([17,16]),stage:17,palettes:Object.freeze([0,0]),winRounds:2})
]);
const need=(ok)=>{if(!ok)throw Error('Replay checkpoint qualification marker invalid');};
function record(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value))&&Reflect.ownKeys(value).length===keys.length);
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable);out[key]=d.value;}return out;
}
function pair(value){need(Array.isArray(value)&&value.length===2&&Reflect.ownKeys(value).length===3);const out=[];for(let i=0;i<2;i++){const d=Object.getOwnPropertyDescriptor(value,String(i));need(d&&'value'in d&&Number.isSafeInteger(d.value));out.push(d.value);}return Object.freeze(out);}
export function validateReplayCheckpointProfile(value){
 const p=record(value,['schemaId','schemaSHA256','qualification','profiles']);need(p.schemaId==='efz402-local-battle/1'&&/^[a-f0-9]{64}$/.test(p.schemaSHA256)&&p.qualification==='bounded-local-generated-core/1');
 need(Array.isArray(p.profiles)&&p.profiles.length===REPLAY_CHECKPOINT_PROFILES.length&&Reflect.ownKeys(p.profiles).length===REPLAY_CHECKPOINT_PROFILES.length+1);
 const profiles=[];for(let i=0;i<REPLAY_CHECKPOINT_PROFILES.length;i++){const d=Object.getOwnPropertyDescriptor(p.profiles,String(i));need(d&&'value'in d);const v=record(d.value,['format','characters','stage','palettes','winRounds']);v.characters=pair(v.characters);v.palettes=pair(v.palettes);need(JSON.stringify(v)===JSON.stringify(REPLAY_CHECKPOINT_PROFILES[i]));profiles.push(Object.freeze(v));}
 return Object.freeze({...p,profiles:Object.freeze(profiles)});
}
export function supportsReplayCheckpoints(marker,meta){
 if(!marker||!meta?.initialization)return false;const i=meta.initialization;
 return marker.profiles.some(p=>p.format===meta.format&&p.stage===i.stage&&p.winRounds===i.winRounds&&p.characters.every((v,n)=>v===i.characters?.[n])&&p.palettes.every((v,n)=>v===i.palettes?.[n]));
}
