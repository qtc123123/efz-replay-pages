import {createReplayClient,inspectPageReplay} from '../src/pages/replay-session.mjs';
import {createReplayMusic} from '../src/pages/replay-music.mjs';
import {createReplaySounds} from '../src/pages/replay-sounds.mjs';
import {createReplayArt} from '../src/pages/replay-art.mjs';
import {GAME_ART_PATHS} from '../src/pages/art-paths.mjs';
import {STAGE_MUSIC_PATHS} from '../src/asset-selection.mjs';
import {resourceKey} from '../deployment/resource-access.mjs';

const $=id=>document.getElementById(id),context=$('screen').getContext('2d',{alpha:false}),rgba=context.createImageData(320,240);
const NAMES=['Nanase','Ayu','Mai','Makoto','Akane','Mayu','Mizuka','Misaki','Shiori','Sayuri','Nayuki','Mio','EX Nanase','Kaori','Ikumi','Mishio','Akiko','Nayuki B','Mizuka B','Kanna','Kano','Minagi','Nayuki','Misuzu','Mizuka'];
let generation=0,playIntent=0,client=null,music=null,sounds=null,art=null,loading=false,starting=false,stepping=false,current=null,disposed=false,deploymentPromise=null;
const configURL=new URL('../deployment/config.json',import.meta.url),pageAbort=new AbortController();
const seconds=updates=>{const total=Math.floor(updates/64);return String(Math.floor(total/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');};
function controls(){
 const usable=client&&!loading&&current&&!['ended','failed','disposed'].includes(current.state);
 $('open-replay').disabled=loading;$('replay-file').disabled=loading;$('win-rounds').disabled=loading;
 $('play').disabled=!usable||starting||stepping||current.state==='playing';$('pause').disabled=!usable||stepping||!starting&&current.state!=='playing';
 $('step').disabled=!usable||starting||stepping||current.state!=='paused';
}
function message(text,error=false){$('status').textContent=text;$('status').classList.toggle('error',error);}
function audioMessage(text,error=false){$('music-status').textContent=text;$('music-status').classList.toggle('error',error);}
function audioAction(action){for(const owner of [music,sounds])try{owner?.[action]();}catch(error){audioMessage(String(error?.message??error).slice(0,250),true);}}
function placeholder(text){$('placeholder').hidden=false;$('placeholder').querySelector('p').textContent=text;}
function paint(frame){
 const image=frame.image;for(let n=0;n<76800;n++){const out=n*4,color=image.pixels[n]*4;
  rgba.data[out]=image.palette[color];rgba.data[out+1]=image.palette[color+1];rgba.data[out+2]=image.palette[color+2];rgba.data[out+3]=255;}
 context.putImageData(rgba,0,0);$('placeholder').hidden=true;
}
function paintArt(id,picture){
 if(disposed||!picture)return;const canvas=$(id);if(!canvas)return;
 canvas.width=picture.width;canvas.height=picture.height;const target=canvas.getContext('2d'),pixels=target.createImageData(picture.width,picture.height);
 pixels.data.set(picture.data);target.putImageData(pixels,0,0);canvas.classList.add('loaded');
}
async function json(url,max,signal,expected=null){
 const response=await fetch(url,{signal,credentials:'omit',redirect:'error'});if(!response.ok||!response.body)throw Error('Deployment files are unavailable.');
 const reader=response.body.getReader(),parts=[];let size=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max)throw Error('Deployment file exceeds its limit.');parts.push(value);}}
 catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
 if(expected){const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(size!==expected.bytes||hash!==expected.sha256)throw Error('Deployment manifest integrity check failed.');}
 return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
function configuration(value){
 const modern=value?.schema==='miracle-replay-pages/3';
 const keys=['schema','manifestUrl','manifestSha256','manifestBytes','generatedEngineHash','qualification','audio','music','supported',...(modern?['effects','art']:[])];
 const exact=(object,expected)=>object&&typeof object==='object'&&!Array.isArray(object)&&Object.keys(object).sort().join(',')===[...expected].sort().join(',');
 const range=(value,start,count)=>JSON.stringify(value)===JSON.stringify(Array.from({length:count},(_,i)=>start+i));
 if(!exact(value,keys)||!['miracle-replay-pages/2','miracle-replay-pages/3'].includes(value.schema)||value.manifestUrl!=='./assets/manifest.json'||
  !/^[a-f0-9]{64}$/.test(value.manifestSha256)||!/^[a-f0-9]{64}$/.test(value.generatedEngineHash)||
  !Number.isInteger(value.manifestBytes)||value.manifestBytes<1||value.manifestBytes>4*1024*1024||value.qualification!=='experimental'||
  !exact(value.audio,modern?['music','effects','voices']:['music','effects'])||value.audio.music!==true||value.audio.effects!==modern||modern&&value.audio.voices!==true||
  !exact(value.music,['paths','mime'])||JSON.stringify(value.music.paths)!==JSON.stringify(STAGE_MUSIC_PATHS)||value.music.mime!=='audio/wav'||
  !exact(value.supported,['characters','stages','palettes','winRounds','defaultWinRounds'])||!range(value.supported.characters,0,25)||!range(value.supported.stages,0,23)||
  !range(value.supported.palettes,0,6)||!range(value.supported.winRounds,1,3)||value.supported.defaultWinRounds!==2)
  throw Error('Unsupported deployment configuration.');
 if(modern&&(!exact(value.art,['paths'])||JSON.stringify(value.art.paths)!==JSON.stringify(GAME_ART_PATHS)||
  !exact(value.effects,['paths','mime'])||value.effects.mime!=='audio/wav'||!Array.isArray(value.effects.paths)||value.effects.paths.length<1||value.effects.paths.length>1300||
  value.effects.paths.some((path,i)=>typeof path!=='string'||path.length>100||!/^([a-z]+\/wave|wave\/se)\/[0-9]{2}\.wav$/.test(path)||i>0&&value.effects.paths[i-1]>=path)))
  throw Error('Unsupported sound/art configuration.');return value;
}
function deployment(){
 if(!deploymentPromise)deploymentPromise=(async()=>{
  const localAbort=new AbortController(),stop=()=>localAbort.abort();pageAbort.signal.addEventListener('abort',stop,{once:true});const timer=setTimeout(stop,60000);
  try{
   const config=configuration(await json(configURL,65536,localAbort.signal));
   const manifest=await json(new URL(config.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.manifestSha256,bytes:config.manifestBytes});
   if(config.audio.effects){const paths=manifest.files?.filter(entry=>entry.path.endsWith('.wav')&&!entry.path.startsWith('wave/bgm/')).map(entry=>entry.path).sort();
    if(JSON.stringify(paths)!==JSON.stringify(config.effects.paths))throw Error('Sound resource declaration does not match the verified manifest.');}
   return {config,manifest,assetRoot:new URL('./',new URL(config.manifestUrl,configURL)).href};
  }finally{clearTimeout(timer);pageAbort.signal.removeEventListener('abort',stop);}
 })().catch(error=>{deploymentPromise=null;throw error;});return deploymentPromise;
}
function artOwner(info){
 if(art||!info.config.art)return art;const key=resourceKey(info.config.manifestSha256);
 try{art=createReplayArt({manifest:info.manifest,assetRoot:info.assetRoot,key});return art;}finally{key.fill(0);}
}
async function landing(){
 try{
  const info=await deployment();if(disposed)return;const owner=artOwner(info);if(!owner)return;
  const load=async(id,path,options)=>paintArt(id,await owner.load(path,options));
  await Promise.all([
   load('logo-art','system/title.dat',{crop:{x:0,y:16,width:320,height:120}}).then(()=>{$('brand-fallback').hidden=true;}),
   load('world-art','system/chr_sel_bg.dat'),load('idle-art','system/chr_sel_bg.dat',{crop:{x:0,y:240,width:320,height:240}}),
   load('replay-mark','system/title_ob.dat',{transparent:'top-left',crop:{x:0,y:154,width:120,height:14}}),
   load('wing-art','system/chr_sel_ob.dat',{transparent:'top-left',crop:{x:192,y:9,width:122,height:95}}),
   load('replay-glyph','system/replay.dat',{transparent:'top-left',crop:{x:0,y:0,width:40,height:8}}),
   load('sunset-art','system/replay_bg.dat',{crop:{x:0,y:30,width:320,height:86}}),
   owner.portrait(9,0).then(picture=>{if(!generation)paintArt('idle-left',picture);}),
   owner.portrait(4,0).then(picture=>{if(!generation)paintArt('idle-right',picture);})
  ]);
 }catch(error){if(!disposed)$('art-status').textContent='Artwork unavailable · '+String(error.message).slice(0,120);}
}
async function showMatch(meta,own,info){
 const init=meta.initialization;for(let side=0;side<2;side++){
  const suffix=side?'two':'one';$('fighter-'+suffix).textContent=NAMES[init.characters[side]];
  $('palette-'+suffix).textContent='COLOR '+String(init.palettes[side]+1).padStart(2,'0')+' / CHARACTER '+String(init.characters[side]).padStart(2,'0');
 }
 $('match-stage').textContent='STAGE '+String(init.stage).padStart(2,'0')+' · FIRST TO '+init.winRounds;
 const owner=artOwner(info);if(!owner)return;
 await Promise.all(init.characters.map(async(id,side)=>{const picture=await owner.portrait(id,init.palettes[side]);
  if(own===generation&&!disposed){paintArt(side?'portrait-two':'portrait-one',picture);paintArt(side?'idle-right':'idle-left',picture);}}));
}
function update(status,own){
 if(own!==generation||disposed)return;current=status;
 $('frame').textContent=seconds(status.nextFrame)+' / '+seconds(status.frames);$('frame').setAttribute('title','Update '+status.nextFrame.toLocaleString()+' / '+status.frames.toLocaleString());
 $('progress').max=status.frames;$('progress').value=status.nextFrame;
 if(status.state==='ended'){starting=false;playIntent++;message('Replay complete. One more round?');audioAction('stop');audioMessage('Playback complete. Game audio stopped.');}
 else if(status.state==='playing')message('Playing · '+status.nextFrame.toLocaleString()+' / '+status.frames.toLocaleString()+' updates');
 else if(status.state==='paused'&&!starting)message('Paused. Step advances one update.');controls();
}
async function retire(){
 playIntent++;starting=false;stepping=false;const previous=client,previousMusic=music,previousSounds=sounds;client=null;music=null;sounds=null;
 const tasks=[previous?.dispose(),Promise.resolve().then(()=>previousMusic?.dispose()),Promise.resolve().then(()=>previousSounds?.dispose())];
 const results=await Promise.allSettled(tasks);const failed=results.find(result=>result.status==='rejected');if(failed)throw failed.reason;
}
async function open(event){
 event.preventDefault();if(disposed)return;const file=$('replay-file').files?.[0];
 const own=++generation;loading=true;current=null;controls();message('Checking your replay…');placeholder('Opening your replay…');
 try{
  await retire();if(own!==generation||disposed)return;
  if(!file||!file.name.toLowerCase().endsWith('.rep')||file.size>64*1024*1024)throw Error('Choose a .rep file up to 64 MiB.');
  const bytes=new Uint8Array(await file.arrayBuffer()),meta=inspectPageReplay(bytes,Number($('win-rounds').value));if(own!==generation||disposed)return;
  const info=await deployment();if(own!==generation||disposed)return;const {config,manifest,assetRoot}=info;
  void showMatch(meta,own,info).catch(error=>{if(own===generation)$('art-status').textContent='Portrait unavailable · '+String(error.message).slice(0,120);});
  const key=resourceKey(config.manifestSha256);
  try{
   const worker=new Worker(new URL('./replay-worker.mjs',import.meta.url),{type:'module'});
   const candidate=createReplayClient(worker,{generation:own,
    onFrame:frame=>{if(own===generation&&!disposed){paint(frame);try{sounds?.present(frame);}catch(error){audioAction('pause');void client?.pause().catch(()=>{});message(error.message,true);audioMessage('Game audio stopped. Reopen the replay to retry.',true);}}},
    onStatus:s=>update(s,own),onError:error=>{if(own===generation&&!disposed){loading=false;starting=false;playIntent++;message(error.message,true);current={state:'failed'};audioAction('stop');controls();}}});
   client=candidate;message('Loading the battle…');
   music=createReplayMusic({manifest,assetRoot,key,path:config.music.paths[meta.initialization.stage]});music.setVolume(Number($('volume').value));
   if(config.audio.effects){sounds=createReplaySounds({manifest,assetRoot,key,characters:meta.initialization.characters,generation:own});sounds.setVolume(Number($('effects-volume').value));}
   const ready=candidate.init({replayBytes:bytes,encryptedManifest:manifest,assetRoot,key,winRounds:meta.initialization.winRounds});key.fill(0);await ready;
  }finally{key.fill(0);}
  if(own!==generation||disposed)return;loading=false;placeholder('Replay ready. Press Play.');
  message('Ready. Press Play to enter the battle.');audioMessage(sounds?'Music, effects & voices are ready to load.':'Music available · this older build has no effect audio.');controls();
 }catch(error){if(own!==generation||disposed)return;loading=false;message(error.name==='AbortError'?'Loading was cancelled or timed out.':error.message,true);
  placeholder('Replay could not be opened.');await retire().catch(cleanup=>audioMessage(cleanup.message,true));controls();}
}
async function play(){
 if(!client||loading||starting||stepping||current?.state!=='paused'||document.hidden)return;
 const own=generation,intent=++playIntent;starting=true;controls();message('Preparing game audio…');audioMessage('Loading this match’s music, effects & voices…');
 try{
  // Both resume calls happen in this click handler before any await.
  const soundReady=sounds?.play(),musicReady=music?.play();
  await Promise.all([soundReady,musicReady]);
  if(own!==generation||intent!==playIntent||disposed||document.hidden)return;
  starting=false;await client.play();if(own===generation&&intent===playIntent)audioMessage(sounds?'Music, effects & voices enabled.':'Stage music enabled.');
 }catch(error){if(own!==generation||intent!==playIntent||disposed)return;starting=false;audioAction('pause');message(error.message,true);audioMessage('Audio could not be prepared. Reopen the replay to retry.',true);}
 finally{if(own===generation)controls();}
}
async function pause(){
 playIntent++;starting=false;audioAction('pause');const own=generation;
 try{await client?.pause();if(own===generation)message('Paused. Step advances one update.');}catch(error){if(own===generation)message(error.message,true);}finally{controls();}
}
async function step(){
 if(!client||loading||starting||stepping||current?.state!=='paused')return;
 playIntent++;stepping=true;controls();audioAction('pause');const own=generation;
 try{await client.step();}catch(error){if(own===generation)message(error.message,true);}
 finally{if(own===generation){stepping=false;controls();}}
}
$('open-form').addEventListener('submit',open);
$('replay-file').addEventListener('change',()=>{$('file-name').textContent=$('replay-file').files?.[0]?.name??'No file selected';});
$('play').addEventListener('click',play);$('pause').addEventListener('click',pause);$('step').addEventListener('click',step);
$('volume').addEventListener('input',()=>{const value=Number($('volume').value);$('volume-value').textContent=Math.round(value*100)+'%';try{music?.setVolume(value);}catch(error){audioMessage(error.message,true);}});
$('effects-volume').addEventListener('input',()=>{const value=Number($('effects-volume').value);$('effects-value').textContent=Math.round(value*100)+'%';try{sounds?.setVolume(value);}catch(error){audioMessage(error.message,true);}});
$('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await $('viewer').requestFullscreen();}catch{message('Fullscreen is unavailable in this browser.',true);}});
if(typeof $('viewer').requestFullscreen!=='function')$('fullscreen').hidden=true;
document.addEventListener('keydown',event=>{if(event.ctrlKey||event.metaKey||event.altKey||event.repeat||['INPUT','SELECT','TEXTAREA','BUTTON','SUMMARY','A'].includes(event.target?.tagName))return;
 if(event.code==='Space'&&client&&!loading){event.preventDefault();void(current?.state==='playing'||starting?pause():play());}
 else if(event.code==='ArrowRight'&&!$('step').disabled){event.preventDefault();void step();}});
document.addEventListener('visibilitychange',()=>{if(document.hidden){playIntent++;starting=false;audioAction('pause');if(client)void client.pause().catch(()=>{});controls();}});
window.addEventListener('pagehide',()=>{disposed=true;generation++;pageAbort.abort();art?.dispose();void retire().catch(()=>{});});
controls();void landing();
