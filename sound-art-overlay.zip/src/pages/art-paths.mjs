import {CHARACTER_RESOURCE_NAMES} from '../asset-selection.mjs';

export const INTERFACE_ART_PATHS=Object.freeze(['system/title.dat','system/title_ob.dat','system/replay_bg.dat',
 'system/replay.dat','system/chr_sel_bg.dat','system/chr_sel_ob.dat'].sort());
export const PORTRAIT_ART_PATHS=Object.freeze([...new Set(CHARACTER_RESOURCE_NAMES)].map(name=>'system/'+name+'/'+name+'.dat').sort());
export const GAME_ART_PATHS=Object.freeze([...INTERFACE_ART_PATHS,...PORTRAIT_ART_PATHS].sort());
export const isGameArtPath=path=>GAME_ART_PATHS.includes(path);
export function portraitArtPath(character){
 if(!Number.isInteger(character)||character<0||character>=CHARACTER_RESOURCE_NAMES.length)throw Error('Art: character outside supported range');
 const name=CHARACTER_RESOURCE_NAMES[character];return 'system/'+name+'/'+name+'.dat';
}
