import {EncryptedAssetCatalog,validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {decodeGameDat} from './game-art.mjs';
import {isGameArtPath,portraitArtPath} from './art-paths.mjs';

/** Interface media belongs to the page, never to the simulation's catalog.
 * The catalog owns the copied key; decoded RGBA is returned only while live. */
export function createReplayArt({manifest,assetRoot,key,fetcher=globalThis.fetch}){
 const full=validateEncryptedAssetManifest(manifest);
 const catalog=new EncryptedAssetCatalog({...full,files:full.files.filter(entry=>isGameArtPath(entry.path))},assetRoot,{key,fetcher});
 let disposed=false;
 async function load(path,options){
  if(disposed)throw Error('Art: owner disposed');
  if(!isGameArtPath(path))throw Error('Art: unsupported interface art path');
  await catalog.load(path);if(disposed)throw Error('Art: owner disposed');
  const bytes=catalog.bytes(path);
  try{return decodeGameDat(bytes,options);}finally{bytes.fill(0);}
 }
 async function portrait(character,color){
  if(!Number.isInteger(color)||color<0||color>5)throw Error('Art: unsupported portrait palette');
  return load(portraitArtPath(character),{paletteOffset:color*40,transparent:'top-left'});
 }
 function dispose(){if(disposed)return;disposed=true;catalog.dispose();}
 return Object.freeze({load,portrait,dispose});
}
