// Static format observations from the permissioned upstream source:
// SHA-256 fcdbd920af0b746badf56ad3af62446d1007329ea4ad630453f3b4adde6980ff.
// Its T/O/I/E helpers read a palette-count byte, BGR triples, LE image
// dimensions, bottom-up raw pixels (compression argument 0), and a top-left
// color key. This presentation decoder is separate from battle simulation.
const MAX_BYTES=8*1024*1024,MAX_SIDE=4096,MAX_PIXELS=4*1024*1024;

function integer(value,min,max,label){
 if(!Number.isSafeInteger(value)||value<min||value>max)throw Error('invalid game DAT '+label);
 return value;
}

/**
 * Decode the first uncompressed interface/portrait DAT image into RGBA.
 * The caller supplies authenticated, decrypted bytes from the asset catalog.
 * RLE battle sprites and scene-wide palette composition are outside this API.
 * Authored trailing data is permitted; only the first image is selected.
 *
 * paletteOffset defaults to 0; character portraits select color * 40 (0..200).
 * transparent is false or 'top-left'. Crops use display-space coordinates and
 * retain the full source image's color key. All output allocations are bounded.
 */
export function decodeGameDat(bytes,{paletteOffset=0,transparent=false,crop}={}){
 if(!(bytes instanceof Uint8Array))throw TypeError('game DAT bytes must be Uint8Array');
 if(bytes.byteLength<5||bytes.byteLength>MAX_BYTES)throw Error('invalid game DAT size');
 const paletteCount=bytes[0],header=1+paletteCount*3;
 if(paletteCount===0||header+4>bytes.byteLength)throw Error('truncated game DAT palette/header');
 integer(paletteOffset,0,paletteCount-1,'palette offset');
 if(transparent!==false&&transparent!=='top-left')throw Error('unsupported game DAT transparency mode');
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
 const sourceWidth=view.getUint16(header,true),sourceHeight=view.getUint16(header+2,true);
 integer(sourceWidth,1,MAX_SIDE,'dimensions');integer(sourceHeight,1,MAX_SIDE,'dimensions');
 if(sourceWidth*sourceHeight>MAX_PIXELS)throw Error('invalid game DAT dimensions');
 const pixels=header+4;
 if(pixels+sourceWidth*sourceHeight>bytes.byteLength)throw Error('truncated game DAT raw pixels');

 let x=0,y=0,width=sourceWidth,height=sourceHeight;
 if(crop!==undefined){
  if(!crop||typeof crop!=='object')throw Error('invalid game DAT crop');
  x=integer(crop.x,0,sourceWidth-1,'crop x');y=integer(crop.y,0,sourceHeight-1,'crop y');
  width=integer(crop.width,1,sourceWidth-x,'crop width');height=integer(crop.height,1,sourceHeight-y,'crop height');
 }
 const key=transparent==='top-left'?bytes[pixels+(sourceHeight-1)*sourceWidth]:-1;
 const data=new Uint8ClampedArray(width*height*4);
 for(let row=0;row<height;row++){
  const source=pixels+(sourceHeight-1-y-row)*sourceWidth+x;
  for(let column=0;column<width;column++){
   const index=bytes[source+column];
   if(index===key)continue;
   const color=paletteOffset+index;
   if(color>=paletteCount)throw Error('game DAT pixel references unavailable palette color');
   const palette=1+color*3,destination=(row*width+column)*4;
   data[destination]=bytes[palette+2];data[destination+1]=bytes[palette+1];
   data[destination+2]=bytes[palette];data[destination+3]=255;
  }
 }
 return {width,height,data};
}
