import {EncryptedAssetCatalog,validateEncryptedAssetManifest,isSoundAssetPath} from '../encrypted-assets.mjs';
import {CHARACTER_RESOURCE_NAMES} from '../asset-selection.mjs';

const MAX_WAVE=64*1024*1024,MAX_DECODED=64*1024*1024,MAX_EVENTS=2048;
const typed=Object.getPrototypeOf(Uint8Array.prototype),tag=Object.getOwnPropertyDescriptor(typed,Symbol.toStringTag).get;
const length=Object.getOwnPropertyDescriptor(typed,'byteLength').get,backing=Object.getOwnPropertyDescriptor(typed,'buffer').get;
const resizable=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get;
const need=(ok,message)=>{if(!ok)throw Error('Sounds: '+message);};
const integer=(value,min,max)=>Number.isSafeInteger(value)&&!Object.is(value,-0)&&value>=min&&value<=max;
function fields(value,required,optional=[]){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain options/event required');
 const keys=Reflect.ownKeys(value);need(required.every(key=>keys.includes(key))&&keys.every(key=>required.includes(key)||optional.includes(key)),'option/event fields');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'accessor refused');out[key]=d.value;}return out;
}
function pick(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'frame record');const out={};
 for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'frame field/accessor');out[key]=d.value;}return out;
}
function ownBytes(value){
 need(ArrayBuffer.isView(value)&&tag.call(value)==='Uint8Array','WAV bytes required');const buffer=backing.call(value),size=length.call(value);
 need(Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&!resizable?.call(buffer)&&size>=44&&size<=MAX_WAVE,'fixed WAV extent');
 const copy=new Uint8Array(size);Uint8Array.prototype.set.call(copy,value);return copy;
}

/** The reviewed effect/voice corpus uses PCM8/PCM16, mono/stereo. Read declared
 * RIFF chunks; never inspect sample bytes as metadata or invent loop markers. */
export function inspectSoundWave(input){
 const bytes=ownBytes(input),view=new DataView(bytes.buffer),four=at=>String.fromCharCode(...bytes.subarray(at,at+4));
 const riffEnd=view.getUint32(4,true)+8;
 // se/11 contains trailing bytes outside its declared RIFF. They are not
 // samples. Several original PCM8 voices omit only the last data-pad byte.
 need(four(0)==='RIFF'&&riffEnd>=44&&riffEnd<=bytes.length&&four(8)==='WAVE','RIFF/WAVE extent');
 let format=null,dataBytes=null,count=0;
 for(let offset=12;offset<riffEnd;){
  need(++count<=256&&offset+8<=riffEnd,'chunk header/count');const name=four(offset),size=view.getUint32(offset+4,true),at=offset+8,end=at+size,next=end+(size&1);
  need(end<=riffEnd&&(next<=riffEnd||name==='data'&&end===riffEnd),'chunk extent');
  if(name==='fmt '){
   need(!format&&[16,18,40].includes(size),'PCM format chunk');
   const code=view.getUint16(at,true),channels=view.getUint16(at+2,true),sampleRate=view.getUint32(at+4,true),byteRate=view.getUint32(at+8,true),align=view.getUint16(at+12,true),bitsPerSample=view.getUint16(at+14,true);
   need(code===1&&[1,2].includes(channels)&&[8,16].includes(bitsPerSample)&&sampleRate>=8000&&sampleRate<=192000&&
    align===channels*bitsPerSample/8&&byteRate===sampleRate*align,'supported PCM format');
   // PCM code 1 uses the sixteen-byte base. Original editors left a forty-byte
   // fmt block or a nonzero WAVEFORMATEX cbSize; neither changes the PCM layout.
   format={channels,sampleRate,bitsPerSample,align};
  }else if(name==='data'){need(dataBytes===null&&size>0,'PCM data extent');dataBytes=size;}
  offset=Math.min(next,riffEnd);
 }
 need(format&&dataBytes!==null&&dataBytes%format.align===0,'PCM format/data required');const frames=dataBytes/format.align;
 return Object.freeze({channels:format.channels,sampleRate:format.sampleRate,bitsPerSample:format.bitsPerSample,frames,duration:frames/format.sampleRate});
}

/** Page-owned original effect/voice playback. The Worker reports already-run
 * output calls. This owner cannot advance, query or change simulation state.
 * Preparation decodes the selected sounds silently; a Play gesture resumes
 * output before simulation starts, avoiding late fetch/decode sound bursts. */
export function createReplaySounds(value){
 const options=fields(value,['manifest','assetRoot','key','characters','generation'],['replayId','seekRevision','fetcher','createAudioContext']);
 need(integer(options.generation,1,Number.MAX_SAFE_INTEGER),'generation');let generation=options.generation,replayId=options.replayId??null,seekRevision=options.seekRevision??0;
 need(replayId===null||integer(replayId,1,Number.MAX_SAFE_INTEGER)&&integer(seekRevision,0,Number.MAX_SAFE_INTEGER),'replay seek identity');
 need(Array.isArray(options.characters)&&options.characters.length===2&&Reflect.ownKeys(options.characters).length===3,'two character IDs required');
 const names=[];for(let side=0;side<2;side++){const d=Object.getOwnPropertyDescriptor(options.characters,String(side));need(d&&'value'in d&&integer(d.value,0,24),'character ID');names.push(CHARACTER_RESOURCE_NAMES[d.value]);}
 const manifest=validateEncryptedAssetManifest(options.manifest),selected=manifest.files.filter(entry=>isSoundAssetPath(entry.path)&&
  (entry.path.startsWith('wave/se/')||names.includes(entry.path.split('/')[0])));
 need(selected.length>0&&selected.length<=165,'selected sound inventory');need(selected.every(entry=>entry.object),'selected sound payload unavailable');
 const entries=new Map(selected.map(entry=>[entry.path,entry]));
 const catalog=new EncryptedAssetCatalog({...manifest,files:selected},options.assetRoot,{key:options.key,fetcher:options.fetcher??globalThis.fetch});
 // A fixed 48 kHz context keeps every reviewed character pair under the same
 // decoded-memory bound even when the output device defaults to 96/192 kHz.
 const createContext=options.createAudioContext??(()=>{const Type=globalThis.AudioContext??globalThis.webkitAudioContext;need(typeof Type==='function','audio output unavailable');return new Type({sampleRate:48000});});
 need(typeof createContext==='function','audio context factory');delete options.key;delete options.manifest;
 let context=null,master=null,loading=false,loaded=false,loadPromise=null,disposed=false,closePromise=null,failure=null;
 let wanted=false,intent=0,volume=1,lastFrame=0;const buffers=new Map(),active=new Map();
 const status=()=>Object.freeze({state:disposed?'disposed':failure?'failed':loading?'loading':wanted&&loaded?'playing':loaded?'paused':'idle',loaded,active:active.size,volume,nextFrame:lastFrame});
 function detach(path,stop=true){
  const voice=active.get(path);if(!voice)return;active.delete(path);voice.source.onended=null;let error;
  if(stop)try{voice.source.stop();}catch(cause){error=cause;}
  try{voice.source.disconnect();}catch(cause){error??=cause;}try{voice.gain.disconnect();}catch(cause){error??=cause;}
  if(error)throw error;
 }
 function detachAll(){let error;for(const path of [...active.keys()])try{detach(path);}catch(cause){error??=cause;}if(error)throw error;}
 function fail(error){failure=error;wanted=false;intent++;try{detachAll();}catch{}catalog.dispose();return error;}
 function pause(){
  if(disposed)return status();wanted=false;intent++;try{detachAll();}catch(error){throw fail(error);}return status();
 }
 const stop=()=>pause();
 function setVolume(next){
  need(!disposed&&typeof next==='number'&&Number.isFinite(next)&&next>=0&&next<=1,'volume must be between zero and one');
  volume=next;if(master)master.gain.setValueAtTime(volume,context.currentTime);return volume;
 }
 function ensureLoaded(){
  if(loadPromise)return loadPromise;loading=true;
  loadPromise=(async()=>{
   let decodedBytes=0;
   try{
    await catalog.loadAll();need(!disposed,'sound owner disposed');
    const decoded=new Map();
    for(const entry of selected){
     need(!disposed,'sound owner disposed');let buffer=decoded.get(entry.sha256);
     if(!buffer){
      const plain=catalog.bytes(entry.path);
      try{
       const info=inspectSoundWave(plain),expectedBytes=Math.ceil(info.duration*context.sampleRate)*info.channels*4;
       need(decodedBytes+expectedBytes<=MAX_DECODED,'decoded sound capacity');
       buffer=await context.decodeAudioData(plain.slice().buffer);need(!disposed,'sound owner disposed');
       need(buffer&&buffer.numberOfChannels===info.channels&&Number.isFinite(buffer.sampleRate)&&buffer.sampleRate>0&&
        integer(buffer.length,1,MAX_DECODED/4)&&Number.isFinite(buffer.duration)&&
        Math.abs(buffer.duration-info.duration)<=1/Math.min(buffer.sampleRate,info.sampleRate),'decoded sound extent');
       decodedBytes+=buffer.length*buffer.numberOfChannels*4;need(decodedBytes<=MAX_DECODED,'decoded sound capacity');decoded.set(entry.sha256,buffer);
      }finally{plain.fill(0);}
     }
     buffers.set(entry.path,buffer);
    }
    loaded=true;
   }finally{catalog.dispose();loading=false;}
  })();loadPromise.catch(()=>{});return loadPromise;
 }
 function ensureContext(){
  if(context)return;
  context=createContext();need(context&&typeof context.resume==='function'&&typeof context.decodeAudioData==='function'&&
   Number.isFinite(context.sampleRate)&&context.sampleRate>=8000&&context.sampleRate<=192000,'audio context unavailable');
  master=context.createGain();master.connect(context.destination);master.gain.setValueAtTime(volume,context.currentTime);
 }
 function prepare(){
  try{
   need(!disposed,'sound owner disposed');need(!failure,'sound owner failed');ensureContext();
   return ensureLoaded().then(()=>status()).catch(error=>{if(!disposed)fail(error);throw error;});
  }catch(error){if(!disposed)fail(error);return Promise.reject(error);}
 }
 function play(){
  try{
   need(!disposed,'sound owner disposed');need(!failure,'sound owner failed');wanted=true;const own=++intent;
   ensureContext();
   // Keep browser user activation: resume is called before the first await.
   const resumed=Promise.resolve(context.resume());
   return resumed.then(async()=>{
    need(!disposed,'sound owner disposed');if(own!==intent||!wanted)return status();
    await ensureLoaded();need(!disposed,'sound owner disposed');return status();
   }).catch(error=>{if(disposed)throw error;if(own!==intent)return status();throw fail(error);});
  }catch(error){if(!disposed)fail(error);return Promise.reject(error);}
 }
 function present(raw){
  if(disposed)return status();
  try{
   const header=pick(raw,['generation']);if(header.generation!==generation)return status();
   if(replayId!==null&&(raw.replayId!==replayId||raw.seekRevision!==seekRevision))return status();
   need(!failure,'sound owner failed');const frame=pick(raw,['status','result']),s=pick(frame.status,['state','nextFrame']),r=pick(frame.result,['nextFrame','soundEvents']);
   need(integer(s.nextFrame,1,1000000)&&s.nextFrame===lastFrame+1&&r.nextFrame===s.nextFrame&&['paused','playing','ended'].includes(s.state),'sound frame boundary');
   const input=r.soundEvents;need(Array.isArray(input)&&input.length<=MAX_EVENTS&&Reflect.ownKeys(input).length===input.length+1,'sound event capacity/array');
   const events=[];let tick=-1;
   for(let ordinal=0;ordinal<input.length;ordinal++){
    const d=Object.getOwnPropertyDescriptor(input,String(ordinal));need(d&&'value'in d&&d.enumerable,'sound event accessor');
    const event=fields(d.value,['update','ordinal','innerTick','kind','path','volume','pan']);
    need(event.update===s.nextFrame-1&&event.ordinal===ordinal&&integer(event.innerTick,-1,2)&&event.innerTick>=tick,'sound event order');tick=event.innerTick;
    need(entries.has(event.path)&&['effect','voice'].includes(event.kind)&&(event.kind==='effect')===event.path.startsWith('wave/se/')&&event.volume===-500&&event.pan===0,'sound path/gain/pan');events.push(event);
   }
   lastFrame=s.nextFrame;
   if(s.state!=='playing'){pause();return status();}if(!wanted)return status();need(loaded,'sound preparation incomplete');
   for(const event of events){
    detach(event.path);const gain=context.createGain(),source=context.createBufferSource();
    active.set(event.path,{source,gain});source.buffer=buffers.get(event.path);source.loop=false;
    gain.gain.setValueAtTime(Math.pow(10,event.volume/2000),context.currentTime);gain.connect(master);source.connect(gain);
    source.onended=()=>{if(active.get(event.path)?.source!==source)return;try{detach(event.path,false);}catch(error){fail(error);}};
    source.start(0);
   }
   return status();
  }catch(error){throw fail(error);}
 }
 function prepareSeekCommit(value){
  const c=fields(value,['replayId','generation','seekRevision','nextFrame']);
  need(!disposed&&integer(c.replayId,1,Number.MAX_SAFE_INTEGER)&&integer(c.generation,1,Number.MAX_SAFE_INTEGER)&&integer(c.seekRevision,0,Number.MAX_SAFE_INTEGER)&&integer(c.nextFrame,0,1000000),'seek commit identity/boundary');
  need(replayId===null||c.replayId===replayId,'different replay sound owner');
  need(c.generation>generation&&c.seekRevision>=seekRevision,'stale seek commit');
  pause();let committed=false;
  // No IO or validation after the host changes its displayed image. Disposal
  // during an asynchronous paint makes this abandoned owner's commit a no-op.
  return ()=>{if(!committed&&!disposed){committed=true;generation=c.generation;replayId=c.replayId;seekRevision=c.seekRevision;lastFrame=c.nextFrame;}return status();};
 }
 const commitSeek=value=>prepareSeekCommit(value)();
 function dispose(){
  if(closePromise)return closePromise;disposed=true;wanted=false;intent++;
  closePromise=(async()=>{
   let error;try{detachAll();}catch(cause){error=cause;}catalog.dispose();buffers.clear();loaded=false;
   try{if(context)await context.close();}catch(cause){error=cause;}
   try{master?.disconnect();}catch(cause){error??=cause;}context=null;master=null;
   if(error)throw error;
  })();return closePromise;
 }
 return Object.freeze({prepare,play,present,pause,stop,setVolume,prepareSeekCommit,commitSeek,dispose,status});
}
