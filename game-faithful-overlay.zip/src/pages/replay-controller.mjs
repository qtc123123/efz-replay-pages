import {createReplayClient,inspectPageReplay,REPLAY_PAGE_LIMITS} from './replay-session.mjs';
import {validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {validateReplayStats,emptyReplayStats} from './replay-stats.mjs';
import {validateReplayTraining,emptyReplayTraining} from './replay-training.mjs';

const need=(ok,message)=>{if(!ok)throw Error('Replay: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
const cancelled=()=>Error('Replay seek cancelled');

/** Owns replay custody and the two Worker roles. onFrame may await painting.
 * prepareCommit may await preparation but must not write visible image/stats.
 * onCommit is the final synchronous image/stat write: it must not return a
 * Promise or retain delayed writes. It runs with owner promotion in one turn.
 * Both callbacks receive isCurrent(). Physical audio remains page-owned. */
export function createReplayController({createWorker,onFrame=()=>{},prepareCommit=()=>{},onCommit=()=>{},onStatus=()=>{},onProgress=()=>{},onError=()=>{},seekTimeoutMs=REPLAY_PAGE_LIMITS.seekMilliseconds}={}){
 need(typeof createWorker==='function'&&typeof prepareCommit==='function'&&typeof onCommit==='function'&&integer(seekTimeoutMs,1,600000),'controller dependencies');
 need(Object.prototype.toString.call(onCommit)!=='[object AsyncFunction]','onCommit must be synchronous; use prepareCommit for asynchronous preparation');
 let replayId=0,generation=0,revision=0,intent=0,disposed=false,stored=null,meta=null,active=null,candidate=null,audio={};
 const status=()=>Object.freeze({...active?.status,...(active?{replayId:active.replayId,generation:active.generation,seekRevision:active.seekRevision}:{}),seeking:candidate!==null,target:candidate?.target??null});
 function publish(){if(active)onStatus(active.status);}
 function silence(restart=false){intent++;audio.sounds?.pause();if(restart)audio.music?.stop();else audio.music?.pause();}
 function make(seekRevision){
  need(generation<Number.MAX_SAFE_INTEGER,'worker generation capacity');const record={replayId,generation:++generation,seekRevision,status:null,client:null};
  record.client=createReplayClient(createWorker(),{generation:record.generation,replayId,seekRevision,
   onStatus:s=>{record.status=s;if(record===active&&!disposed)publish();},
   onFrame:async frame=>{
    if(record!==active||disposed)return;
    if(frame.result.stats)validateReplayStats(frame.result.stats,frame.status.nextFrame,meta.initialization);
    validateReplayTraining(frame.result.training,frame.status.nextFrame,meta.initialization,frame.image);
    // Paused/terminal frames only acknowledge the sound cursor. Do this
    // before awaiting paint so an older Step cannot cancel a newer Play.
    if(frame.status.state!=='playing')audio.sounds?.present?.(frame);
    await onFrame(frame);if(record===active&&!disposed){record.presentation=Object.freeze({...frame,stats:frame.result.stats,training:frame.result.training});if(frame.status.state==='playing')audio.sounds?.present?.(frame);}
   },
   onProgress:p=>{if(candidate?.record===record&&!disposed)onProgress(Object.freeze({...p,state:'seeking',cancelable:true}));},
   onError:error=>{if(record===active&&!disposed){silence();onError(error);}}
  });return record;
 }
 function cancelSeek(){
  if(!candidate)return;const old=candidate;candidate=null;revision++;intent++;clearTimeout(old.timer);old.cancel(cancelled());void old.record?.client.dispose();publish();
 }
 async function open(payload){
  need(!disposed,'controller disposed');cancelSeek();silence();replayId++;revision++;const own=replayId;
  const previous=active;active=null;stored?.key?.fill?.(0);stored=null;meta=null;
  const retiring=previous?.client.dispose();let owned=null;
  try{
   // Custody is synchronous: the caller can wipe its key immediately after open.
   need(payload&&payload.replayBytes instanceof Uint8Array,'replay bytes');
   const inspected=inspectPageReplay(payload.replayBytes,payload.winRounds);
   const bytes=Uint8Array.prototype.slice.call(payload.replayBytes),key=typeof payload.key==='string'?payload.key:payload.key?.slice();
   owned={replayBytes:bytes,key,encryptedManifest:validateEncryptedAssetManifest(payload.encryptedManifest),assetRoot:payload.assetRoot,winRounds:inspected.initialization.winRounds};
   await retiring;
   if(disposed||own!==replayId)throw cancelled();
   stored=owned;meta=inspectPageReplay(bytes,owned.winRounds);active=make(revision);const record=active;
   try{await record.client.init(stored);if(disposed||record!==active)throw cancelled();record.presentation=Object.freeze({replayId:record.replayId,generation:record.generation,seekRevision:record.seekRevision,status:record.status,stats:emptyReplayStats(),training:emptyReplayTraining(),image:null});return record.status;}
   catch(error){if(record===active){active=null;stored=null;meta=null;}await record.client.dispose();throw error;}
  }catch(error){owned?.key?.fill?.(0);await retiring;throw error;}
 }
 function setAudio(owners={}){audio={sounds:owners.sounds??null,music:owners.music??null};}
 function play(){
  try{
   need(!disposed&&active&&active.status?.state==='paused'&&!candidate,'play requires paused replay');const own=active,serial=++intent;
   // Both browser resume calls run synchronously in the caller's click gesture.
   const sounds=audio.sounds?.play(),music=audio.music?.play();
   return Promise.all([sounds,music]).then(()=>{if(disposed||active!==own||serial!==intent||candidate)return status();return own.client.play();})
    .catch(error=>{if(active===own&&serial===intent)silence();throw error;});
  }catch(error){return Promise.reject(error);}
 }
 async function pause(){silence();if(candidate)candidate.resume=false;const own=active;if(!own||disposed)return status();await own.client.pause();return status();}
 async function step(){need(!disposed&&active&&!candidate,'step unavailable');silence();return active.client.step();}
 async function seek(targetNextUpdate,{resume=false}={}){
  need(!disposed&&active&&stored&&meta,'seek requires replay');need(integer(targetNextUpdate,0,meta.frames),'seek target');need(typeof resume==='boolean','seek resume');
  cancelSeek();silence(true);const old=active,ownReplay=replayId,seekRevision=++revision;
  let rejectCancel;const cancellation=new Promise((_,reject)=>{rejectCancel=reject;});cancellation.catch(()=>{});
  const transaction={record:null,target:targetNextUpdate,resume,cancel:rejectCancel,timer:null,presentationAborted:false};candidate=transaction;
  const owns=()=>!disposed&&candidate===transaction&&replayId===ownReplay&&revision===seekRevision;
  const current=()=>owns()&&!transaction.presentationAborted;
  transaction.timer=setTimeout(()=>{if(!current())return;rejectCancel(Error('Replay seek deadline exceeded'));void transaction.record?.client.dispose();},seekTimeoutMs);
  async function work(){
   await old.client.pause();if(!current())throw cancelled();
   const record=make(seekRevision);transaction.record=record;
   await record.client.init(stored);if(!current())throw cancelled();
   const ready=await record.client.prepareSeek(targetNextUpdate);if(!current())throw cancelled();
   const stats=validateReplayStats(ready.stats,targetNextUpdate,meta.initialization);
   const training=validateReplayTraining(ready.training,targetNextUpdate,meta.initialization,ready.image);
   await old.client.whenPainted();if(!current())throw cancelled();
   const shown=Object.freeze({...ready,stats,training,isCurrent:current});
   await prepareCommit(shown);if(!current())throw cancelled();
   // Validate the worker's typed transition before modifying the display.
   await record.client.commitSeek(targetNextUpdate);if(!current())throw cancelled();
   const descriptor={replayId:record.replayId,generation:record.generation,seekRevision:record.seekRevision,nextFrame:targetNextUpdate};
   let commitAudio=()=>{};
   if(audio.sounds?.prepareSeekCommit)commitAudio=audio.sounds.prepareSeekCommit(descriptor);
   else audio.sounds?.commitSeek?.(descriptor);
   // No await is allowed between the final visible write and promotion.
   try{
    const result=onCommit(shown);
    if(result&&typeof result.then==='function'){
     Promise.resolve(result).catch(()=>{});
     throw Error('Replay: onCommit must be synchronous; use prepareCommit');
    }
    if(!current())throw cancelled();
   }catch(error){
    transaction.presentationAborted=true;
    const retained=()=>!disposed&&replayId===ownReplay&&active===old;
    if(retained()){
     const restored=onCommit(Object.freeze({...old.presentation,status:old.status,isCurrent:retained}));
     if(restored&&typeof restored.then==='function')Promise.resolve(restored).catch(()=>{});
    }
    throw error;
   }
   commitAudio();
   record.presentation=shown;active=record;candidate=null;clearTimeout(transaction.timer);publish();await old.client.dispose();
   if(transaction.resume&&active.status.state==='paused')await play();return status();
  }
  try{return await Promise.race([work(),cancellation]);}
  catch(error){
   if(owns()){candidate=null;clearTimeout(transaction.timer);await transaction.record?.client.dispose();publish();}
   throw error;
  }finally{clearTimeout(transaction.timer);}
 }
 async function dispose(){
  if(disposed)return;cancelSeek();disposed=true;intent++;silence();const old=active;active=null;replayId++;stored?.key?.fill?.(0);stored=null;meta=null;await old?.client.dispose();
 }
 return Object.freeze({open,setAudio,play,pause,step,seek,cancelSeek,dispose,status});
}
