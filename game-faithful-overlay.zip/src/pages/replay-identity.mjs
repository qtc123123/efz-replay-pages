import {inspectPageReplay} from './replay-session.mjs';

/** Presentation admission is the full supported parser, never header metadata.
 * begin() clears already-visible identity synchronously, before any file,
 * resource or Worker await. Every later portrait result belongs to its token. */
export function createReplayIdentity({clear,display}){
 if(typeof clear!=='function'||typeof display!=='function')throw Error('Replay identity: view callbacks required');
 let revision=0,admitted=null;
 function begin(){
  if(revision===Number.MAX_SAFE_INTEGER)throw Error('Replay identity: revision exhausted');
  revision++;admitted=null;clear();return revision;
 }
 function owns(token){return token===revision;}
 function admit(bytes,winRounds,token){
  if(!owns(token)||token===0)throw Error('Replay identity: obsolete admission');
  const meta=inspectPageReplay(bytes,winRounds);admitted=meta;return meta;
 }
 async function show(art,token){
  if(!owns(token)||!admitted)return false;
  const meta=admitted,init=meta.initialization;
  const pictures=await Promise.all(init.characters.map((character,side)=>art.portrait(character,init.palettes[side])));
  if(!owns(token)||admitted!==meta)return false;
  display(init,pictures);return true;
 }
 function fail(token){if(owns(token))begin();}
 return Object.freeze({begin,owns,admit,show,fail});
}
