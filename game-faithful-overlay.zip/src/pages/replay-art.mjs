import {EncryptedAssetCatalog,validateEncryptedAssetManifest} from '../encrypted-assets.mjs';
import {decodeGameDat} from './game-art.mjs';
import {decodeIndexedGameDat} from './indexed-art.mjs';
import {renderTitleReplay,renderReplayPanel,renderControlRow} from './menu-scene.mjs';
import {isGameArtPath,portraitArtPath} from './art-paths.mjs';

/** Interface media belongs to the page, never to the simulation's catalog.
 * The catalog owns the copied key; decoded RGBA is returned only while live. */
export function createReplayArt({manifest,assetRoot,key,fetcher=globalThis.fetch}){
 const full=validateEncryptedAssetManifest(manifest);
 const catalog=new EncryptedAssetCatalog({...full,files:full.files.filter(entry=>isGameArtPath(entry.path))},assetRoot,{key,fetcher});
 let disposed=false;const scenes=new Map();
 async function load(path,options){
  if(disposed)throw Error('Art: owner disposed');
  if(!isGameArtPath(path))throw Error('Art: unsupported interface art path');
  await catalog.load(path);if(disposed)throw Error('Art: owner disposed');
  const bytes=catalog.bytes(path);
  try{return decodeGameDat(bytes,options);}finally{bytes.fill(0);}
 }
 async function portrait(character,color){
  if(!Number.isInteger(color)||color<0||color>5)throw Error('Art: unsupported portrait palette');
  return load(portraitArtPath(character),{paletteOffset:color*40,transparent:'top-left'});
 }
 // Only the four bounded menu resources are retained as indexed scene data.
 // No portrait is fetched until portrait() is explicitly called after replay
 // admission. A failed pending load is removable; disposal fences late work.
 function indexed(path){
  if(disposed)return Promise.reject(Error('Art: owner disposed'));
  if(!scenes.has(path)){
   const pending=(async()=>{await catalog.load(path);if(disposed)throw Error('Art: owner disposed');const bytes=catalog.bytes(path);
    try{return decodeIndexedGameDat(bytes);}finally{bytes.fill(0);}
   })();scenes.set(path,pending);pending.catch(()=>{if(scenes.get(path)===pending)scenes.delete(path);});
  }
  return scenes.get(path);
 }
 async function titleReplay(options){
  const [background,objects]=await Promise.all([indexed('system/title.dat'),indexed('system/title_ob.dat')]);
  if(disposed)throw Error('Art: owner disposed');return renderTitleReplay(background,objects,options);
 }
 async function replayPanel(options){
  const [background,objects]=await Promise.all([indexed('system/replay_bg.dat'),indexed('system/replay.dat')]);
  if(disposed)throw Error('Art: owner disposed');return renderReplayPanel(background,objects,options);
 }
 async function controlRow(options){const objects=await indexed('system/title_ob.dat');if(disposed)throw Error('Art: owner disposed');return renderControlRow(objects,options);}
 function dispose(){if(disposed)return;disposed=true;scenes.clear();catalog.dispose();}
 return Object.freeze({load,portrait,titleReplay,replayPanel,controlRow,dispose});
}
