import {artInteger,indexedToRgba,blitIndexed} from './indexed-art.mjs';
// Directly inspected original pinned JS $P/$_/I/K/N. patchBundle does not
// modify these scenes. Source evidence and exclusions: docs/qualification/MENU_SCENES.md.
/** Source tj.advance deadline domain. The host calls this with performance.now
 * and drains due updates, bounded as tj.wait bounds its pending updates to two.
 * Recreate this clock after hiding/reduced motion rather than wall-clock jumps.
 * This is original-JS scheduling, not independently verified native cadence. */
const validClockTime=value=>Number.isFinite(value)&&value>=0&&value<Number.MAX_SAFE_INTEGER/4;
export function createMenuClock(now){
 if(!validClockTime(now))throw Error('invalid menu clock');
 return Object.freeze({interval:10,next:now,windowStart:Math.floor(now),count:0,due:0});
}
export function advanceMenuClock(state,now){
 if(!validClockTime(now)||!state||!validClockTime(state.next)||!validClockTime(state.windowStart)||!Number.isSafeInteger(state.count)||state.count<0)throw Error('invalid menu clock');
 artInteger(state.interval,0,255,'clock interval');let {interval,next,windowStart,count}=state,due=0;
 if(now-next>250)next=now;
 while(next<=now){
  due++;count++;const start=Math.floor(next);
  if(start-windowStart>=1000){if(count>64)interval=interval+1&255;count=0;windowStart=start;}
  next+=interval+.5;
 }
 return Object.freeze({interval,next,windowStart,count,due});
}
function dimensions(image,width,height,label){if(image.width!==width||image.height<height)throw Error('unsupported '+label+' art dimensions');}
function paletteBank(target,image,start,count){
 if(image.paletteCount<count)throw Error('insufficient scene palette');
 target.set(image.palette.subarray(0,4*count),4*start);
}
function frame(background,objects,objectColors){
 const pixels=new Uint8Array(320*240),palette=new Uint8Array(1024),image={width:320,height:240,pixels,palette,paletteCount:256};
 dimensions(background,320,240,'menu background');paletteBank(palette,background,1,192);paletteBank(palette,objects,193,objectColors);
 blitIndexed(image,background,{x:0,y:0,src:{x:0,y:0,width:320,height:240},indexOffset:1});return image;
}
function finish(image,fade){
 artInteger(fade,0,100,'fade');
 // Source N white fade, excluding global palette index255 just as its loop.
 if(fade!==100)for(let i=0;i<255;i++)for(let channel=0;channel<3;channel++){
  const at=4*i+channel,color=image.palette[at];image.palette[at]=color+Math.trunc((255-color)*(100-fade)/100)&255;
 }
 return indexedToRgba(image);
}
export function renderTitleReplay(background,objects,{selected=false,fade=100}={}){
 if(typeof selected!=='boolean')throw Error('invalid title selected state');dimensions(objects,120,196,'title object');
 const image=frame(background,objects,48);
 blitIndexed(image,objects,{x:195,y:186,src:{x:0,y:selected?154:56,width:120,height:14},key:objects.keyIndex,indexOffset:193});
 return finish(image,fade);
}
/** A web-control backing cropped entirely beyond the authored REPLAY glyphs.
 * The crop is intentionally a texture adaptation, not a stock game control. */
export function renderControlRow(objects,{selected=false}={}){
 if(typeof selected!=='boolean')throw Error('invalid control selected state');dimensions(objects,120,196,'title object');
 return indexedToRgba(objects,{transparent:'top-left',crop:{x:88,y:selected?154:56,width:32,height:14}});
}
function validMotion(state){
 if(!state||![0,1,2,3].includes(state.phase))throw Error('invalid menu motion phase');artInteger(state.row,0,8,'row');
 artInteger(state.slide,0,180,'slide');if(!Number.isFinite(state.scroll)||Math.abs(state.scroll)>256)throw Error('invalid menu scroll');return state;
}
export function createMenuMotion({row=0}={}){artInteger(row,0,8,'row');return Object.freeze({phase:0,row,slide:0,scroll:0});}
export function setMenuMotionDirection(state,direction){
 validMotion(state);if(!['open','close'].includes(direction))throw Error('invalid menu motion direction');return Object.freeze({...state,phase:direction==='open'?1:3});
}
export function advanceMenuMotion(state){
 validMotion(state);let {phase,row,slide,scroll}=state;
 // The increments are inside the original two-player loop. A terminal change
 // during the first iteration prevents a second increment. Keep float order.
 for(let player=0;player<2;player++){
  if(phase===1){slide+=2;scroll+=16*row/90;if(slide>180){slide=180;phase=2;}}
  else if(phase===3){slide-=2;scroll-=16*row/90;if(slide<0){slide=0;phase=0;}}
 }
 return Object.freeze({phase,row,slide,scroll});
}
export function sampleMenuMotion(state){
 validMotion(state);const displacement=Math.trunc(160-160*Math.cos(state.slide/57.29579143313326));
 return {displacement,selectedY:16*state.row+96-Math.trunc(state.scroll),submenuY:319-displacement+112};
}
/** Source-derived empty replay panel, for web loading/open transitions. It
 * omits file numbers/names and native playback/save/back labels. The visible
 * rail crops use actual atlas pixels to the right of those authored labels.
 * Its spatial motion matches $_; its web action semantics are an adaptation. */
export function renderReplayPanel(background,objects,{motion=createMenuMotion(),selected=true,fade=100}={}){
 dimensions(objects,320,960,'replay object');if(typeof selected!=='boolean')throw Error('invalid replay selected state');
 const image=frame(background,objects,62),sample=sampleMenuMotion(motion);
 // 240px blank authored rail, retained at its original x80 placement.
 blitIndexed(image,objects,{x:80,y:sample.selectedY,src:{x:80,y:(selected?92:252)+16*motion.row,width:240,height:16},key:objects.keyIndex,indexOffset:193});
 return finish(image,fade);
}
