/** Recorded controls, not the core's pressed edges/command history. The pinned
 * rr.readInput maps 1/2/4/8 to world right/left/down/up and 16..128 to held
 * A..D. History is a cursor-relative window of immutable admitted replay pairs;
 * it never polls the simulation or accumulates events during playback. */
const need=(ok,message)=>{if(!ok)throw Error('Recorded inputs: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
const directionBits=Object.freeze([[8,'up','↑'],[4,'down','↓'],[2,'left','←'],[1,'right','→']]);
const diagonals=Object.freeze({9:'↗',10:'↖',5:'↘',6:'↙'});
export function decodeRecordedInput(word){
 need(integer(word,0,255),'input word');
 const directions=directionBits.filter(([bit])=>word&bit),buttons=['A','B','C','D'].filter((_,i)=>word&(16<<i));
 const arrow=diagonals[word&15]??directions.map(([, ,glyph])=>glyph).join('');
 return Object.freeze({word,directions:Object.freeze(directions.map(([,name])=>name)),buttons:Object.freeze(buttons),label:[arrow,...buttons].filter(Boolean).join(' ')||'·'});
}
export function formatReplayTime(nextUpdate){
 need(integer(nextUpdate,0,1000000),'time boundary');const ms=Math.floor(nextUpdate*1000/64),seconds=Math.floor(ms/1000);
 return String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0')+'.'+String(ms%1000).padStart(3,'0');
}
export function sampleRecordedInputs(meta,nextUpdate,{windowUpdates=128,maxRows=8}={}){
 need(meta&&integer(meta.frames,1,1000000)&&typeof meta.pair==='function','admitted recording');
 need(integer(nextUpdate,0,meta.frames),'cursor boundary');need(integer(windowUpdates,1,512),'history window');need(integer(maxRows,1,32),'history rows');
 const windowStart=Math.max(0,nextUpdate-windowUpdates);
 if(nextUpdate===0)return Object.freeze({nextUpdate,sourceUpdate:null,windowStart,players:null});
 const runs=[[],[]];let previous=null;
 if(windowStart>0)previous=meta.pair(windowStart-1);
 for(let update=windowStart;update<nextUpdate;update++){
  const pair=meta.pair(update);need(Array.isArray(pair)&&pair.length===2,'recorded pair');
  pair.forEach((word,side)=>{
   need(integer(word,0,255),'input word');const last=runs[side].at(-1);
   if(last&&last.word===word){last.endUpdate=update+1;last.updates++;}
   else runs[side].push({word,startUpdate:update,endUpdate:update+1,targetNextUpdate:update+1,updates:1,truncated:update===windowStart&&previous?.[side]===word});
  });
 }
 const players=Object.freeze(runs.map(rows=>Object.freeze({...decodeRecordedInput(rows.at(-1).word),rows:Object.freeze(rows.slice(-maxRows).reverse().map(row=>Object.freeze({...decodeRecordedInput(row.word),...row})))})));
 return Object.freeze({nextUpdate,sourceUpdate:nextUpdate-1,windowStart,players});
}
