import {inspectExtendedReplay} from '../revival.mjs';
import {validatePair} from '../spectator-profile.mjs';
import {validateLocalReplayInitialization,LOCAL_REPLAY_PROFILE} from '../local-replay-profile.mjs';
import {EncryptedAssetCatalog,validateEncryptedAssetManifest,isSoundAssetPath} from '../encrypted-assets.mjs';
import {selectAssetPaths,isBattleAssetPath,STAGE_MUSIC_PATHS} from '../asset-selection.mjs';
import {isGameArtPath} from './art-paths.mjs';
import {validateReplayStats,emptyReplayStats} from './replay-stats.mjs';
import {validateReplayTraining,emptyReplayTraining} from './replay-training.mjs';

export const REPLAY_PAGE_LIMITS=Object.freeze({replayBytes:64*1024*1024,frames:1000000,pendingCommands:8,seekBatchUpdates:16,seekSliceMilliseconds:8,seekMilliseconds:120000,frameMilliseconds:1000/64});
const L=REPLAY_PAGE_LIMITS,typed=Object.getPrototypeOf(Uint8Array.prototype);
const tag=Object.getOwnPropertyDescriptor(typed,Symbol.toStringTag).get,length=Object.getOwnPropertyDescriptor(typed,'byteLength').get;
const backing=Object.getOwnPropertyDescriptor(typed,'buffer').get,resizable=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get;
const need=(ok,message)=>{if(!ok)throw Error('Replay: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
function fields(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain message required');
 const own=Reflect.ownKeys(value);need(own.length===keys.length&&keys.every(key=>own.includes(key)),'message fields');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'accessor refused');out[key]=d.value;}return out;
}
function bytes(value,max,exact=null){
 need(ArrayBuffer.isView(value)&&tag.call(value)==='Uint8Array','byte buffer required');
 const buffer=backing.call(value),size=length.call(value);
 need(Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&!resizable?.call(buffer)&&size<=max&&(exact===null||size===exact),'fixed byte extent');
 const result=new Uint8Array(size);Uint8Array.prototype.set.call(result,value);return result;
}
function data(value,depth=0,budget={left:65536}){
 need(depth<=16,'observation depth');
 if(value===null||typeof value==='boolean'){budget.left-=4;need(budget.left>=0,'observation capacity');return value;}
 if(typeof value==='number'){need(Number.isFinite(value),'finite observation required');budget.left-=16;need(budget.left>=0,'observation capacity');return value;}
 if(typeof value==='string'){budget.left-=value.length*3+2;need(budget.left>=0,'observation capacity');return value;}
 if(Array.isArray(value)){need(value.length<=4096&&Reflect.ownKeys(value).length===value.length+1,'observation array');
  return Object.freeze(Array.from({length:value.length},(_,i)=>{const d=Object.getOwnPropertyDescriptor(value,String(i));need(d&&'value'in d,'observation accessor');return data(d.value,depth+1,budget);}));}
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'observation record');const out={},keys=Reflect.ownKeys(value);
 need(keys.length<=64&&keys.every(key=>typeof key==='string'&&key.length<=128&&!['__proto__','prototype','constructor'].includes(key)),'observation keys');
 for(const key of keys){budget.left-=key.length*3+4;const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'observation accessor');out[key]=data(d.value,depth+1,budget);}return Object.freeze(out);
}
function resultData(value,initialization=null,image=null){
 const training=Object.getOwnPropertyDescriptor(value??{},'training');
 if(training){
  need('value'in training&&training.enumerable,'training accessor');
  const descriptors=Object.getOwnPropertyDescriptors(value);delete descriptors.training;
  const result=resultData(Object.create(Object.getPrototypeOf(value),descriptors),initialization,image);
  // Independent fixed schema/count bounds admit the legitimate 130-entity
  // projectile ring without weakening the generic 64 KiB observation limit.
  return Object.freeze({...result,training:validateReplayTraining(training.value,result.nextFrame,initialization,image)});
 }

 const sound=Object.getOwnPropertyDescriptor(value??{},'soundEvents');
 if(!sound)return data(value);
 need('value'in sound&&sound.enumerable,'sound event accessor');
 const descriptors=Object.getOwnPropertyDescriptors(value);delete descriptors.soundEvents;
 const result=data(Object.create(Object.getPrototypeOf(value),descriptors));
 const raw=sound.value;need(Array.isArray(raw)&&raw.length<=2048&&Reflect.ownKeys(raw).length===raw.length+1,'sound event capacity');
 // Dense legitimate sound arrays have their own bound. The original 64 KiB
 // observation limit still applies to every other part of the core result.
 const events=data(raw,0,{left:768*1024});let previousTick=-1;
 for(let ordinal=0;ordinal<events.length;ordinal++){
  const event=fields(events[ordinal],['update','ordinal','innerTick','kind','path','volume','pan']);
  need(event.update===result.nextFrame-1&&event.ordinal===ordinal&&integer(event.innerTick,-1,2)&&event.innerTick>=previousTick,'sound event order');
  need(isSoundAssetPath(event.path)&&['effect','voice'].includes(event.kind)&&(event.kind==='effect')===event.path.startsWith('wave/se/')&&event.volume===-500&&event.pan===0,'sound event descriptor');
  previousTick=event.innerTick;
 }
 return Object.freeze({...result,soundEvents:events});
}
function prepared(value,next){
 const p=fields(value,['width','height','pixels','palette','nextFrame','originUpdate','domain','renderOrdinal','phase','round']);
 need(p.width===320&&p.height===240&&p.nextFrame===next&&integer(p.originUpdate,0,next-1)&&p.domain==='segment'&&
  integer(p.renderOrdinal,0,0xffffffff)&&integer(p.round,0,0xffffffff)&&['intro','round-transition','round-ko','combat','finish'].includes(p.phase),'prepared image descriptor');
 return Object.freeze({...p,pixels:bytes(p.pixels,76800,76800),palette:bytes(p.palette,1024,1024)});
}
function status(value){
 const s=fields(value,['state','nextFrame','frames']);need(integer(s.frames,1,L.frames)&&integer(s.nextFrame,0,s.frames)&&
  ['paused','playing','ended','disposed','failed'].includes(s.state),'status');need(s.state!=='ended'||s.nextFrame===s.frames,'terminal boundary');return Object.freeze(s);
}
export function inspectPageReplay(input,winRounds=2){
 // Inspect owns the complete byte view. Reject shared/resizable sources first.
 need(ArrayBuffer.isView(input)&&tag.call(input)==='Uint8Array','local .rep bytes required');const buffer=backing.call(input);
 need(Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&!resizable?.call(buffer),'fixed replay bytes required');
 const meta=inspectExtendedReplay(input);
 need(meta.frames<=L.frames,'recording capacity');
 const initialization=validateLocalReplayInitialization({...meta.initialization,profile:LOCAL_REPLAY_PROFILE,winRounds});
 for(let frame=0;frame<meta.frames;frame++)validatePair(meta.pair(frame));return Object.freeze({...meta,initialization});
}
function selectedCatalog(manifest,initialization,root,key,fetcher,location){
 const full=validateEncryptedAssetManifest(manifest);
 // Music has its own browser owner. Even its existence metadata stays outside
 // the battle catalog, preserving the previously qualified gameplay closure.
 need(full.files.every(file=>isBattleAssetPath(file.path)||STAGE_MUSIC_PATHS.includes(file.path)||isGameArtPath(file.path)),'unsupported resource pack');
 const paths=new Set(selectAssetPaths(initialization,full.files.map(file=>file.path)));
 const owned={...full,files:full.files.filter(file=>paths.has(file.path))};
 need(typeof root==='string'&&root.length<=4096,'asset root');
 const url=new URL(root);need(['https:','http:'].includes(url.protocol)&&!url.username&&!url.password&&!url.search&&!url.hash&&url.pathname.endsWith('/'),'asset root');
 if(location&&['https:','http:'].includes(new URL(location).protocol))need(url.href===new URL('../deployment/assets/',location).href,'project asset root');
 return new EncryptedAssetCatalog(owned,url.href,{key,fetcher});
}

/** One fresh realm per local recording. These controls never change the core's
 * update/render cadence or construct a post-intro state. The scheduler admits
 * one complete update, then waits for its prepared-image acknowledgment. */
export function installReplayWorker(scope,{createSpectator,fetcher=globalThis.fetch,clock=()=>performance.now(),schedule=setTimeout,cancel=clearTimeout}={}){
 need(scope&&typeof scope.postMessage==='function'&&typeof createSpectator==='function','worker dependencies');
 let replayId=null,seekRevision=0,seekReady=null,seeking=false;
 let generation=0,lastId=0,meta=null,assets=null,engine=null,initializing=null,active=null,closing=null;
 let ready=false,playing=false,ended=false,disposed=false,failed=false,next=0,timer=null,due=0,playId=0,delivery=0,inFlight=0,commands=0;
 const identity=()=>replayId===null?{}:{replayId,seekRevision};
 const current=()=>Object.freeze({state:failed?'failed':disposed?'disposed':ended?'ended':playing?'playing':'paused',nextFrame:next,frames:meta?.frames??0});
 const clear=()=>{if(timer!==null)cancel(timer);timer=null;};
 const reply=(id,operation)=>scope.postMessage({type:'result',generation,...identity(),id,operation,status:current(),...(operation==='init'?{initialization:meta.initialization}:{})});
 const error=(id,cause,fatal=false)=>scope.postMessage({type:'error',generation,...identity(),id,message:String(cause?.message??'replay failed').slice(0,500),fatal});
 function dispose(){
  if(closing)return closing;disposed=true;playing=false;clear();
  // Abort cold fetches immediately, but keep a live update's resources owned
  // until its complete boundary has returned. Its late image is suppressed.
  if(!ready)assets?.dispose();
  closing=(async()=>{await initializing?.catch(()=>{});await active?.catch(()=>{});const old=engine;engine=null;old?.dispose();assets?.dispose();})();return closing;
 }
 async function fatal(id,cause){failed=true;try{await dispose();}catch(cleanup){cause=Error(String(cause?.message??cause)+'; cleanup: '+String(cleanup.message));}error(id,cause,true);}
 function arm(){
  if(!ready||!playing||disposed||ended||failed||active||inFlight||seeking||seekReady!==null||timer!==null)return;
  const now=clock();need(Number.isFinite(now),'clock');if(now-due>L.frameMilliseconds*4)due=now;
  timer=schedule(()=>{timer=null;if(playing&&!inFlight&&!disposed&&!active)void update(playId,false);},Math.max(0,due-now));
 }
 async function advance(id,hidden=false){
  const result=await engine.advance(next,meta.pair(next));if(disposed)return;
  need(result&&['advanced','end'].includes(result.kind)&&result.nextFrame===next+1,'complete update boundary');next++;
  ended=result.kind==='end';need(ended===(next===meta.frames),'recording extent does not match natural engine cleanup');
  if(result.observation?.sceneId!==undefined)need(result.observation.sceneId===(ended?8:3),'unsupported battle scene');
  if(ended)playing=false;
  if(replayId!==null||Object.hasOwn(result,'stats'))validateReplayStats(result.stats,next,meta.initialization);
  if(replayId!==null)need(Object.hasOwn(result,'training'),'training required');
  if(hidden){const owned=resultData(result,meta.initialization);return Object.hasOwn(owned,'soundEvents')?Object.freeze({...owned,soundEvents:Object.freeze([])}):owned;}
  const image=prepared(engine.presentation(),next),owned=resultData(result,meta.initialization,image);need(delivery<Number.MAX_SAFE_INTEGER,'presentation counter');
  inFlight=++delivery;scope.postMessage({type:'frame',generation,...identity(),id,presentationId:inFlight,status:current(),result:owned,image},[image.pixels.buffer,image.palette.buffer]);
  due+=L.frameMilliseconds;
 }
 async function update(id,command){
  const work=advance(id);active=work;
  try{await work;if(!disposed&&command)reply(id,'step');}catch(cause){await fatal(id,cause);}
  finally{if(active===work)active=null;if(!disposed)arm();}
 }
 async function seek(id,target){
  seeking=true;const started=clock();let owned=null;
  try{
   while(next<target){
    const begin=clock();let count=0;
    do{
     need(clock()-started<=L.seekMilliseconds,'seek deadline');
     const work=advance(id,true);active=work;
     try{owned=await work;}finally{if(active===work)active=null;}
     if(disposed)return;count++;
    }while(next<target&&count<L.seekBatchUpdates&&clock()-begin<L.seekSliceMilliseconds);
    scope.postMessage({type:'seek-progress',generation,...identity(),id,nextFrame:next,targetNextUpdate:target});
    if(next<target)await new Promise(resolve=>schedule(resolve,0));
    if(disposed)return;
   }
   seekReady=target;
   const image=target===0?null:prepared(engine.presentation(),next);
   const stats=validateReplayStats(engine.statistics?.()??owned?.stats??(target===0?emptyReplayStats():null),next,meta.initialization);
   const training=validateReplayTraining(engine.training?.()??owned?.training??(target===0?emptyReplayTraining():null),next,meta.initialization,image);
   scope.postMessage({type:'seek-ready',generation,...identity(),id,status:current(),targetNextUpdate:target,
    result:owned,stats,training,image},image?[image.pixels.buffer,image.palette.buffer]:[]);
  }catch(cause){await fatal(id,cause);}finally{seeking=false;}
 }
 async function initialize(message){
  meta=inspectPageReplay(message.replayBytes,message.winRounds);
  assets=selectedCatalog(message.encryptedManifest,meta.initialization,message.assetRoot,message.key,fetcher,scope.location?.href);
  await assets.loadForSimulation();if(disposed)return;
  const candidate=await createSpectator(meta.initialization,assets);
  if(disposed){candidate.dispose();return;}engine=candidate;ready=true;
 }
 scope.onmessage=({data:raw})=>{
  let message;
  try{
   need(raw&&[Object.prototype,null].includes(Object.getPrototypeOf(raw)),'message');
   const descriptors=Object.getOwnPropertyDescriptors(raw);need(['type','generation'].every(key=>descriptors[key]&&'value'in descriptors[key]),'message header');
   const type=descriptors.type.value,g=descriptors.generation.value;
   if(type==='ack'){
    message=fields(raw,['type','generation','presentationId',...replayId===null?[]:['replayId','seekRevision']]);
    if(replayId!==null&&(message.replayId!==replayId||message.seekRevision!==seekRevision))return;
    if(g===generation&&inFlight&&message.presentationId===inFlight){inFlight=0;arm();}return;
   }
   need(descriptors.id&&'value'in descriptors.id,'request identity');const id=descriptors.id.value;
   if(!integer(id,1,Number.MAX_SAFE_INTEGER)||!integer(g,1,Number.MAX_SAFE_INTEGER)||id<=lastId||generation&&g!==generation)return;
   const ids=Object.hasOwn(raw,'replayId')?['replayId','seekRevision']:[];
   message=fields(raw,type==='init'?['type','id','generation','replayBytes','encryptedManifest','assetRoot','key',...Object.hasOwn(raw,'winRounds')?['winRounds']:[],...ids]:['type','id','generation',...ids,...['seek','commit'].includes(type)?['targetNextUpdate']:[]]);
   if(ids.length){need(integer(message.replayId,1,Number.MAX_SAFE_INTEGER)&&integer(message.seekRevision,0,Number.MAX_SAFE_INTEGER),'replay seek identity');}
   if(generation&&(message.replayId!==replayId||message.seekRevision!==seekRevision)&&replayId!==null)return;
   lastId=id;
   if(type==='init'){
    if(generation){error(id,Error('Replace the Worker to open another replay'));return;}generation=g;replayId=message.replayId??null;seekRevision=message.seekRevision??0;
    initializing=initialize(message);void initializing.then(()=>{if(!disposed)reply(id,'init');},cause=>{if(!disposed)void fatal(id,cause);});return;
   }
   if(!generation)return;
   if(type==='dispose'){void dispose().then(()=>reply(id,'dispose'),cause=>error(id,cause,true));return;}
   need(commands<L.pendingCommands,'control capacity');need(ready&&!disposed&&!failed,'worker not ready');
   if(type==='seek'){
    need(replayId!==null&&!playing&&!active&&!inFlight&&!seeking&&seekReady===null&&next===0&&delivery===0,'seek requires fresh paused worker');
    need(integer(message.targetNextUpdate,0,meta.frames),'seek target');void seek(id,message.targetNextUpdate);return;
   }
   if(type==='commit'){
    need(!seeking&&seekReady!==null&&message.targetNextUpdate===seekReady&&next===seekReady,'seek commit boundary');seekReady=null;reply(id,type);return;
   }
   need(!seeking&&seekReady===null,'seek commit required');
   need(['play','pause','step'].includes(type),'unsupported control');
   if(type==='play'){need(!ended,'recording ended');playing=true;playId=id;due=clock();reply(id,type);arm();return;}
   if(type==='pause'){
    playing=false;clear();commands++;void Promise.resolve(active).then(()=>{if(!disposed)reply(id,type);},cause=>error(id,cause,true)).finally(()=>commands--);return;
   }
   need(!ended,'recording ended');need(!playing&&!active&&!inFlight,'step requires a paused acknowledged boundary');void update(id,true);
  }catch(cause){const id=message?.id??Object.getOwnPropertyDescriptor(raw??{},'id')?.value;if(generation&&integer(id,1,Number.MAX_SAFE_INTEGER))error(id,cause,false);}
 };
 return Object.freeze({dispose,status:current});
}

/** Main-thread owner. A replaced/closed worker cannot deliver or acknowledge a
 * later image. Frames are owned and painted before returning the single credit. */
export function createReplayClient(worker,{generation,replayId=null,seekRevision=0,onFrame=()=>{},onStatus=()=>{},onProgress=()=>{},onError=()=>{}}={}){
 need(integer(generation,1,Number.MAX_SAFE_INTEGER)&&worker&&typeof worker.postMessage==='function','client identity');
 need(replayId===null||integer(replayId,1,Number.MAX_SAFE_INTEGER)&&integer(seekRevision,0,Number.MAX_SAFE_INTEGER),'client replay seek identity');
 const identity=replayId===null?{}:{replayId,seekRevision},identityKeys=Object.keys(identity);
 let readyTarget=null,initialization=null,admittedFrames=null,paintPromise=Promise.resolve();
 let nextId=0,closed=false,initialised=false,lastImage=0,lastDelivery=0,delivering=false,closePromise=null;
 const pending=new Map();
 function fail(cause){if(closed)return;try{onError(cause);}finally{void dispose(cause);}}
 function dispose(cause=Error('Replay client disposed')){
  if(closePromise)return closePromise;closed=true;
  worker.removeEventListener('message',receive);worker.removeEventListener('error',broken);
  for(const p of pending.values()){clearTimeout(p.timer);p.reject(cause);}pending.clear();
  try{closePromise=Promise.resolve(worker.terminate());}catch(error){closePromise=Promise.reject(error);}return closePromise;
 }
 function request(type,payload={}){
  try{
   need(!closed,'client disposed');need(pending.size<L.pendingCommands,'pending control capacity');need(nextId<Number.MAX_SAFE_INTEGER,'request counter');
   let owned=payload,transfer=[];
   if(type==='init'){
    need(!initialised,'replace the Worker for another replay');const p=fields(payload,['replayBytes','encryptedManifest','assetRoot','key',...Object.hasOwn(payload,'winRounds')?['winRounds']:[]]);
    const meta=inspectPageReplay(p.replayBytes,p.winRounds);initialization=meta.initialization;admittedFrames=meta.frames;owned={replayBytes:bytes(p.replayBytes,L.replayBytes),encryptedManifest:validateEncryptedAssetManifest(p.encryptedManifest),assetRoot:p.assetRoot,winRounds:meta.initialization.winRounds,
     key:typeof p.key==='string'?p.key:bytes(p.key,32,32)};need(typeof p.assetRoot==='string'&&p.assetRoot.length<=4096,'asset root');
    transfer=[owned.replayBytes.buffer,...owned.key instanceof Uint8Array?[owned.key.buffer]:[]];initialised=true;
   }else need(initialised,'client not initialized');
   const id=++nextId;let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});
   const timer=setTimeout(()=>fail(Error('Replay worker request timed out')),type==='init'?60000:type==='seek'?L.seekMilliseconds:5000);
   pending.set(id,{type,target:owned.targetNextUpdate,resolve,reject,timer});try{worker.postMessage({type,generation,...identity,id,...owned},transfer);}catch(error){clearTimeout(timer);pending.delete(id);reject(error);fail(error);}return promise;
  }catch(error){return Promise.reject(error);}
 }
 async function receive({data:raw}){
  if(closed||raw?.generation!==generation||replayId!==null&&(raw?.replayId!==replayId||raw?.seekRevision!==seekRevision))return;
  try{
   if(raw.type==='frame'){
    need(!delivering,'duplicate presentation while painting');delivering=true;
    const m=fields(raw,['type','generation','id','presentationId','status','result','image',...identityKeys]);
    need(integer(m.id,1,nextId)&&m.presentationId===lastDelivery+1,'presentation identity');
    const s=status(m.status);need(s.nextFrame===lastImage+1,'presentation boundary');
    const image=prepared(m.image,s.nextFrame),result=resultData(m.result,initialization,image);need(result.nextFrame===s.nextFrame,'result boundary');
    if(replayId!==null)need(Object.hasOwn(result,'training'),'training required');
    if(replayId!==null||Object.hasOwn(result,'stats'))validateReplayStats(result.stats,s.nextFrame,initialization);
    const frame=Object.freeze({...m,status:s,result,image});
    lastDelivery=m.presentationId;lastImage=s.nextFrame;onStatus(s);paintPromise=Promise.resolve(onFrame(frame));await paintPromise;
    if(!closed)worker.postMessage({type:'ack',generation,...identity,presentationId:m.presentationId});return;
   }
   const p=pending.get(raw.id);
   if(raw.type==='seek-progress'){
    const m=fields(raw,['type','generation','id','nextFrame','targetNextUpdate',...identityKeys]);
    need(p?.type==='seek'&&m.targetNextUpdate===p.target&&integer(m.nextFrame,0,p.target),'seek progress boundary');onProgress(Object.freeze(m));return;
   }
   if(raw.type==='seek-ready'){
    const m=fields(raw,['type','generation','id','targetNextUpdate','status','result','stats','training','image',...identityKeys]);
    const s=status(m.status);need(p?.type==='seek'&&m.targetNextUpdate===p.target&&s.frames===admittedFrames&&s.nextFrame===p.target&&s.state===(p.target===admittedFrames?'ended':'paused'),'seek ready boundary');
    need(p.target!==0||m.image===null&&m.result===null,'initial seek image');
    const image=p.target===0?null:prepared(m.image,p.target);
    const result=m.result===null?null:resultData(m.result,initialization,image);need(p.target===0?result===null:result?.nextFrame===p.target,'seek result boundary');
    const stats=validateReplayStats(m.stats,p.target,initialization);
    const training=validateReplayTraining(m.training,p.target,initialization,image);
    const ready=Object.freeze({...m,status:s,result,stats,training,image});
    readyTarget=p.target;clearTimeout(p.timer);pending.delete(m.id);p.resolve(ready);return;
   }
   if(raw.type==='error'){
    const m=fields(raw,['type','generation','id','message','fatal',...identityKeys]);need(typeof m.message==='string'&&m.message.length<=500&&typeof m.fatal==='boolean','worker error');
    const error=Error(m.message);if(p){clearTimeout(p.timer);pending.delete(m.id);p.reject(error);}if(m.fatal)fail(error);return;
   }
   need(raw.type==='result'&&p,'unexpected worker result');
   const m=fields(raw,p.type==='init'?['type','generation','id','operation','status','initialization',...identityKeys]:['type','generation','id','operation','status',...identityKeys]);
   need(m.operation===p.type,'response operation');const s=status(m.status);
   if(p.type==='commit'){
    need(s.frames===admittedFrames&&s.nextFrame===p.target&&s.state===(p.target===admittedFrames?'ended':'paused'),'seek commit response boundary/extent');
    lastImage=p.target;lastDelivery=0;readyTarget=null;
   }
   onStatus(s);clearTimeout(p.timer);pending.delete(m.id);p.resolve(s);
  }catch(error){fail(error);}finally{if(raw.type==='frame')delivering=false;}
 }
 const broken=()=>fail(Error('Replay worker failed to start or stopped unexpectedly'));
 worker.addEventListener('message',receive);worker.addEventListener('error',broken);
 return Object.freeze({init:value=>request('init',value),
  prepareSeek:targetNextUpdate=>request('seek',{targetNextUpdate}),
  commitSeek:targetNextUpdate=>{if(readyTarget!==targetNextUpdate)return Promise.reject(Error('Replay: unmatched seek commit'));return request('commit',{targetNextUpdate});},
  whenPainted:()=>paintPromise,play:()=>request('play'),pause:()=>request('pause'),step:()=>request('step'),dispose:()=>dispose()});
}
