import {createSelectionBackground,validateBackgroundManifest,advanceSelectionOffset,selectionBackgroundSlices} from '../src/pages/selection-background.mjs';
import {createPlayerControls} from '../src/pages/player-controls.mjs';
import {createAppNavigation} from '../src/pages/app-navigation.mjs';
import {createReplayController} from '../src/pages/replay-controller.mjs';
import {createReplayIdentity} from '../src/pages/replay-identity.mjs';
import {validateReplayStats,emptyReplayStats} from '../src/pages/replay-stats.mjs';
import {validateReplayTraining,emptyReplayTraining} from '../src/pages/replay-training.mjs';
import {paintHitboxOverlay,prepareHitboxOverlay} from '../src/pages/replay-training-view.mjs';
import {sampleRecordedInputs,formatReplayTime} from '../src/pages/replay-input-history.mjs';
import {createReplayMusic} from '../src/pages/replay-music.mjs';
import {createReplaySounds} from '../src/pages/replay-sounds.mjs';
import {createReplayArt} from '../src/pages/replay-art.mjs';
import {createLoadingArt,chooseLoadingIllustration,validateLoadingManifest} from '../src/pages/loading-art.mjs';
import {createMenuMotion,setMenuMotionDirection,advanceMenuMotion,sampleMenuMotion,createMenuClock,advanceMenuClock} from '../src/pages/menu-scene.mjs';
import {GAME_ART_PATHS} from '../src/pages/art-paths.mjs';
import {STAGE_MUSIC_PATHS} from '../src/asset-selection.mjs';
import {resourceKey} from '../deployment/resource-access.mjs';

const $=id=>document.getElementById(id),context=$('screen').getContext('2d',{alpha:false}),rgba=context.createImageData(320,240);
const NAMES=['Nanase','Ayu','Mai','Makoto','Akane','Mayu','Mizuka','Misaki','Shiori','Sayuri','Nayuki','Mio','EX Nanase','Kaori','Ikumi','Mishio','Akiko','Nayuki B','Mizuka B','Kanna','Kano','Minagi','Nayuki','Misuzu','Mizuka'];
const configURL=new URL('../deployment/config.json',import.meta.url),pageAbort=new AbortController(),reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
let navigation=null,muted=false,overlayControls=null,keyboardControls=false,settingsTrigger=null,controlsPointer=false;
let generation=0,uiIntent=0,seekUiRevision=0,controller=null,music=null,sounds=null,art=null,loadingArt=null,current=null,initialization=null,activeFile=null,loading=false,starting=false,stepping=false,seeking=false,scrubbing=false,disposed=false,failed=false,deploymentPromise=null;
let menuMode='title',menuMotion=createMenuMotion({row:4}),menuClock=null,menuTimer=null,menuPaintRevision=0,titleSelected=false;
let replayMeta=null,lastTraining=emptyReplayTraining(),lastImage=null,fighterTimer=null,fighterClock=null,fighterRevision=0;
let fighterMotion={angle:90,nextAngle:90,scroll:0};
let fullscreenPending=false,fullscreenActive=false,restoreFullscreenFocus=false;
const historyRows=[new Map(),new Map()],historyOrder=['',''];
const text=(id,value)=>{const node=$(id),content=String(value);if(node.textContent!==content)node.textContent=content;};
const seconds=updates=>{const total=Math.floor(updates/64);return String(Math.floor(total/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');};
const decimal=value=>Number.isInteger(value)?String(value):value.toFixed(2).replace(/0+$/,'').replace(/\.$/,'');
function message(value,error=false){text('status',value);$('status').classList.toggle('error',error);if(loading)text('loading-message',value);}
function audioMessage(value,error=false){text('music-status',value);$('music-status').classList.toggle('error',error);}
function audioAction(action){for(const owner of [music,sounds])try{owner?.[action]();}catch(error){audioMessage(error.message,true);}}
function controls(){
 if(navigation){$('session-resume').hidden=!controller||!initialization;$('session-empty').hidden=!$('session-resume').hidden;text('session-name',activeFile?.name??'');$('watch-return').hidden=!controller||!initialization;}
 const available=controller&&current&&!loading&&!['failed','disposed'].includes(current.state),busy=starting||stepping||seeking;
 $('play').hidden=!!(current?.state==='playing'||starting);$('pause').hidden=!$('play').hidden;
 $('play').disabled=!available||busy||current?.state!=='paused';$('pause').disabled=!available||stepping||seeking;
 $('step').disabled=!available||busy||current?.state!=='paused';$('previous').disabled=!available||busy||current?.nextFrame===0;
 $('restart').disabled=!available||busy||current?.nextFrame===0;$('progress').disabled=!available;
 $('seek-row').hidden=!seeking;
 for(const [source,target]of [['restart','settings-restart'],['previous','settings-previous'],['step','settings-step']])$(target).disabled=$(source).disabled;
 overlayControls?.refresh();
 for(const rows of historyRows)for(const button of rows.values())button.disabled=!available||busy;
 document.documentElement.dataset.playerState=loading?'loading':seeking?'seeking':starting?'preparing':failed?'failed':current?.state??'empty';
}
function paintArt(id,picture){
 const canvas=$(id);canvas.width=picture.width;canvas.height=picture.height;
 const ctx=canvas.getContext('2d'),image=ctx.createImageData(picture.width,picture.height);image.data.set(picture.data);ctx.putImageData(image,0,0);
}
function stopFighters(){if(fighterTimer!==null)window.cancelAnimationFrame(fighterTimer);fighterTimer=null;fighterClock=null;fighterRevision++;}
async function drawFighters(revision=fighterRevision){
 const init=initialization,own=generation;if(!init||!art||disposed)return;
 const pictures=await Promise.all(init.characters.map((character,side)=>art.fighterPanel(character,init.palettes[side],side,{angle:fighterMotion.angle,scroll:fighterMotion.scroll})));
 if(revision!==fighterRevision||init!==initialization||own!==generation||disposed)return;
 for(const [side,suffix]of ['one','two'].entries())paintArt('portrait-'+suffix,pictures[side]);
}
async function fighterTick(now){
 fighterTimer=null;if(disposed||!initialization||document.hidden||reducedMotion.matches||navigation?.current()!=='replay')return;
 const own=fighterRevision;fighterClock=advanceMenuClock(fighterClock??createMenuClock(now),now);
 for(let count=0;count<Math.min(fighterClock.due,2);count++)fighterMotion={angle:Math.min(180,fighterMotion.nextAngle),nextAngle:Math.min(185,fighterMotion.nextAngle+5),scroll:(fighterMotion.scroll+1)%240};
 try{await drawFighters(own);}catch(error){if(own===fighterRevision&&!disposed)text('art-status','Artwork unavailable: '+error.message);}
 if(own===fighterRevision&&!disposed&&initialization&&!document.hidden&&!reducedMotion.matches)fighterTimer=window.requestAnimationFrame(fighterTick);
}
function startFighters(){
 stopFighters();fighterMotion={angle:reducedMotion.matches?180:90,nextAngle:reducedMotion.matches?185:90,scroll:0};
 if(!reducedMotion.matches&&!document.hidden&&navigation?.current()==='replay'){fighterClock=createMenuClock(performance.now());fighterTimer=window.requestAnimationFrame(fighterTick);}
}
function stopMenu(){if(menuTimer!==null)window.cancelAnimationFrame(menuTimer);menuTimer=null;menuClock=null;menuPaintRevision++;}
async function drawMenu(){
 if(!art||disposed||$('placeholder').hidden||menuMode==='loading')return;
 const own=++menuPaintRevision,mode=menuMode,motion=menuMotion;
 try{
  const picture=mode==='title'?await art.titleReplay({selected:titleSelected}):await art.replayPanel({motion,selected:true});
  if(own!==menuPaintRevision||disposed||$('placeholder').hidden)return;
  paintArt('menu-art',picture);$('brand-fallback').hidden=true;
  $('title-open').hidden=mode!=='title';$('menu-line').hidden=mode==='title';
  if(mode==='replay')$('menu-line').style.top=(sampleMenuMotion(motion).selectedY/240*100)+'%';
 }catch(error){if(own===menuPaintRevision&&!disposed)text('art-status','Artwork unavailable: '+error.message);}
}
function menuTick(now){
 menuTimer=null;if(disposed||document.hidden||reducedMotion.matches||$('placeholder').hidden)return;
 menuClock=advanceMenuClock(menuClock??createMenuClock(now),now);
 for(let count=0;count<Math.min(menuClock.due,2);count++)menuMotion=advanceMenuMotion(menuMotion);
 void drawMenu();if(menuMotion.phase===1||menuMotion.phase===3)menuTimer=window.requestAnimationFrame(menuTick);
}
function placeholder(label,{title=false,animate=false}={}){
 const keepMotion=!title&&!animate&&menuMode==='replay'&&!$('placeholder').hidden&&(menuMotion.phase===1||menuMotion.phase===3);
 if(!keepMotion)stopMenu();$('placeholder').hidden=false;$('placeholder').classList.remove('is-loading');menuMode=title?'title':'replay';text('menu-line',label);
 $('title-open').hidden=!title;$('menu-line').hidden=title;
 if(!title&&animate){menuMotion=setMenuMotionDirection(createMenuMotion({row:4}),'open');
  if(reducedMotion.matches||document.hidden){while(menuMotion.phase===1)menuMotion=advanceMenuMotion(menuMotion);}
  else{menuClock=createMenuClock(performance.now());menuTimer=window.requestAnimationFrame(menuTick);}
 }
 void drawMenu();
}
function loadingCover(){
 stopMenu();menuMode='loading';$('placeholder').hidden=false;$('placeholder').classList.add('is-loading');delete $('placeholder').dataset.illustration;
 $('menu-art').getContext('2d').clearRect(0,0,320,240);$('brand-fallback').hidden=true;$('menu-line').hidden=true;$('title-open').hidden=true;
}
async function showLoadingArt(info,own){
 if(!info.loadingManifest)return;
 if(!loadingArt){const key=resourceKey(info.config.manifestSha256);try{loadingArt=createLoadingArt({manifest:info.loadingManifest,assetRoot:new URL('./loading/',configURL).href,key});}finally{key.fill(0);}}
 const picture=await loadingArt.picture(chooseLoadingIllustration());
 if(own!==generation||disposed||!loading||menuMode!=='loading')return;
 paintArt('menu-art',picture);$('placeholder').dataset.illustration=picture.path;
}
function paint(image){
 if(!image){context.clearRect(0,0,320,240);text('image-origin','No battle image');placeholder('Ready · Play');return;}
 for(let n=0;n<76800;n++){const out=n*4,color=image.pixels[n]*4;
  rgba.data[out]=image.palette[color];rgba.data[out+1]=image.palette[color+1];rgba.data[out+2]=image.palette[color+2];rgba.data[out+3]=255;}
 context.putImageData(rgba,0,0);$('placeholder').hidden=true;stopMenu();
 text('image-origin','Image: update '+image.originUpdate.toLocaleString());
}
function showStats(raw){
 const stats=validateReplayStats(raw,raw.nextUpdate,initialization);
 for(const [side,suffix] of ['one','two'].entries()){
  const p=stats.players?.[side];
  for(const field of ['hp','sp','rf']){
   text(field+'-'+suffix,p?decimal(p[field]):'—');$(field+'-'+suffix).title=p?String(p[field]):'';
  }
  text('rf-mode-'+suffix,p?(p.rfBlue?'RF · Blue':'RF · Normal'):'');text('wins-'+suffix,p?String(p.wins):'—');
 }
 text('stats-origin',stats.availability==='none'?'Values appear after the first update':stats.availability==='last-live'?'Final values: update '+stats.sourceUpdate.toLocaleString()+' (boundary '+(stats.sourceUpdate+1).toLocaleString()+')':'Values: boundary '+stats.nextUpdate.toLocaleString());
}
function showRecordedInputs(){
 const visible=!!initialization&&$('show-inputs').checked,sample=visible&&replayMeta?sampleRecordedInputs(replayMeta,lastTraining.nextUpdate,{windowUpdates:512,maxRows:14}):null;
 for(const [side,suffix]of ['one','two'].entries()){
  const node=$('inputs-'+suffix),list=$('input-history-'+suffix),player=sample?.players?.[side],overlay=$('input-overlay-'+suffix);node.hidden=!visible;list.hidden=!visible;
  overlay.hidden=!visible||!lastImage;
  const overlayRows=player?.rows??[];
  const signature=overlayRows.map(row=>row.word+':'+row.updates+':'+row.truncated).join('|');
  if(overlay.dataset.inputs!==signature){overlay.dataset.inputs=signature;overlay.replaceChildren(...overlayRows.map(row=>{
   const run=document.createElement('div');run.className='recorded-glyphs';
   const symbols=document.createElement('span');symbols.className='recorded-symbols';symbols.textContent=row.word===0?'':row.label;
   const held=document.createElement('span');held.className='recorded-hold';held.textContent=(row.truncated?'≥':'')+row.updates;
   run.setAttribute('aria-label',(row.word===0?'Neutral':row.label)+' held '+(row.truncated?'at least ':'')+row.updates+' frames');
   run.appendChild(held);run.appendChild(symbols);return run;
  }));}
  text('inputs-'+suffix,player?player.label:'—');node.title=player?'Recorded update '+sample.sourceUpdate+'; raw word '+player.word:'No consumed input';
  const rows=player?.rows??[],order=rows.map(row=>row.targetNextUpdate+':'+row.word).join(',');
  const children=rows.map(row=>{
   const key=row.targetNextUpdate+':'+row.word;let button=historyRows[side].get(key);
   if(!button){button=document.createElement('button');button.type='button';button.className='input-run';const own=generation;
    button.addEventListener('click',()=>{if(own===generation)return seek(row.targetNextUpdate);});historyRows[side].set(key,button);}
   const label=formatReplayTime(row.targetNextUpdate)+'  '+row.label+'  '+(row.truncated?'≥':'')+row.updates+'u';
   if(button.textContent!==label)button.textContent=label;
   button.disabled=loading||starting||stepping||seeking||!controller;
   button.title='Seek to boundary '+row.targetNextUpdate+'; recorded updates '+row.startUpdate+'–'+(row.endUpdate-1);
   return button;
  });
  if(historyOrder[side]!==order){list.replaceChildren(...children);historyOrder[side]=order;const live=new Set(rows.map(row=>row.targetNextUpdate+':'+row.word));for(const key of historyRows[side].keys())if(!live.has(key))historyRows[side].delete(key);}
 }
}
function refreshTraining(){
 $('training-info').hidden=!initialization||!$('training-settings').open;
 for(const id of ['analysis-open','player-settings'])$(id).setAttribute('aria-expanded',String($('training-settings').open));
 overlayControls?.refresh();
 $('training-info').classList.toggle('show-details',$('show-details').checked);
 const layer=paintHitboxOverlay($('hitbox-overlay').getContext('2d'),lastTraining,lastImage,$('show-hitboxes').checked);
 $('hitbox-legend').hidden=!initialization||!$('show-hitboxes').checked;
 for(const [side,suffix]of ['one','two'].entries()){
  const p=lastTraining.players?.[side];
  text('combo-'+suffix,p?decimal(p.comboCount):'—');
  text('damage-'+suffix,p?decimal(p.comboDamage):'—');
  text('max-combo-'+suffix,p?decimal(p.maxCombo)+' / '+decimal(p.maxComboDamage):'—');
  text('scaling-'+suffix,p?decimal(p.proration/100)+'%':'—');
  text('stun-'+suffix,p?decimal(p.untech)+' / '+decimal(p.hitstop)+' / '+decimal(p.freeze):'—');
  text('state-'+suffix,p?p.state+' / '+p.frame:'—');
  text('position-'+suffix,p?decimal(p.x)+', '+decimal(p.y)+(p.facing===1?' →':' ←'):'—');
  text('shown-combo-'+suffix,p?decimal(p.comboDisplay)+' / '+decimal(p.comboTimer):'—');
  $('damage-'+suffix).title=p?'Engine current/last combo accumulator; raw '+p.comboDamage:'';
  $('scaling-'+suffix).title=p?'Next scaling '+p.proration+'/100':'';
 }
 const actorOrigin=lastTraining.availability==='none'?'No actor values':lastTraining.availability==='last-live'?'Final actor values: update '+lastTraining.sourceUpdate:'Actor values: boundary '+lastTraining.nextUpdate;
 text('training-origin',initialization?actorOrigin+(layer.originUpdate===null?' · No collision image':' · Boxes: image update '+layer.originUpdate):'');
 showRecordedInputs();
}
function present(image,rawStats,rawTraining){
 // Validate every component before the synchronous visible commit.
 const stats=validateReplayStats(rawStats,rawStats.nextUpdate,initialization),training=validateReplayTraining(rawTraining,stats.nextUpdate,initialization,image);
 prepareHitboxOverlay(training,image);lastTraining=training;lastImage=image;
 paint(image);showStats(stats);refreshTraining();
}
const identity=createReplayIdentity({
 clear(){
  stopFighters();initialization=null;replayMeta=null;lastTraining=emptyReplayTraining();lastImage=null;$('match-info').hidden=true;$('player').classList.remove('identified');
  for(const side of [0,1]){historyRows[side].clear();historyOrder[side]='';$('input-history-'+['one','two'][side]).replaceChildren();}
  for(const suffix of ['one','two']){text('fighter-'+suffix,'');text('palette-'+suffix,'');const canvas=$('portrait-'+suffix);canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);}
  text('match-stage','');showStats(emptyReplayStats());text('stats-origin','');refreshTraining();
 },
 display(init,pictures){
  initialization=init;for(const [side,suffix] of ['one','two'].entries()){
   text('fighter-'+suffix,NAMES[init.characters[side]]);text('palette-'+suffix,'Color '+(init.palettes[side]+1));paintArt('portrait-'+suffix,pictures[side]);
  }
  text('match-stage','Stage '+String(init.stage+1).padStart(2,'0')+' · First to '+init.winRounds);$('match-stage').title='Recorded stage ID '+init.stage;
  $('match-info').hidden=false;$('player').classList.add('identified');showStats(emptyReplayStats());refreshTraining();startFighters();
 }
});
async function json(url,max,signal,expected=null){
 const response=await fetch(url,{signal,credentials:'omit',redirect:'error'});if(!response.ok||!response.body)throw Error('Deployment files are unavailable.');
 const reader=response.body.getReader(),parts=[];let size=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max)throw Error('Deployment file exceeds its limit.');parts.push(value);}}
 catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
 if(expected){const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(size!==expected.bytes||hash!==expected.sha256)throw Error('Deployment manifest integrity check failed.');}
 return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
function configuration(value){
 const modern=value?.schema==='miracle-replay-pages/3';
 const keys=['schema','manifestUrl','manifestSha256','manifestBytes','generatedEngineHash','qualification','audio','music','supported',...(modern?['effects','art']:[]),...['loading','background'].filter(key=>Object.hasOwn(value??{},key))];
 const exact=(object,expected)=>object&&typeof object==='object'&&!Array.isArray(object)&&Object.keys(object).sort().join(',')===[...expected].sort().join(',');
 const range=(value,start,count)=>JSON.stringify(value)===JSON.stringify(Array.from({length:count},(_,i)=>start+i));
 if(!exact(value,keys)||!['miracle-replay-pages/2','miracle-replay-pages/3'].includes(value.schema)||value.manifestUrl!=='./assets/manifest.json'||
  !/^[a-f0-9]{64}$/.test(value.manifestSha256)||!/^[a-f0-9]{64}$/.test(value.generatedEngineHash)||
  !Number.isInteger(value.manifestBytes)||value.manifestBytes<1||value.manifestBytes>4*1024*1024||value.qualification!=='experimental'||
  !exact(value.audio,modern?['music','effects','voices']:['music','effects'])||value.audio.music!==true||value.audio.effects!==modern||modern&&value.audio.voices!==true||
  !exact(value.music,['paths','mime'])||JSON.stringify(value.music.paths)!==JSON.stringify(STAGE_MUSIC_PATHS)||value.music.mime!=='audio/wav'||
  !exact(value.supported,['characters','stages','palettes','winRounds','defaultWinRounds'])||!range(value.supported.characters,0,25)||!range(value.supported.stages,0,23)||
  !range(value.supported.palettes,0,6)||!range(value.supported.winRounds,1,3)||value.supported.defaultWinRounds!==2)
  throw Error('Unsupported deployment configuration.');
 if(modern&&(!exact(value.art,['paths'])||JSON.stringify(value.art.paths)!==JSON.stringify(GAME_ART_PATHS)||
  !exact(value.effects,['paths','mime'])||value.effects.mime!=='audio/wav'||!Array.isArray(value.effects.paths)||value.effects.paths.length<1||value.effects.paths.length>1300||
  value.effects.paths.some((path,i)=>typeof path!=='string'||path.length>100||!/^([a-z]+\/wave|wave\/se)\/[0-9]{2}\.wav$/.test(path)||i>0&&value.effects.paths[i-1]>=path)))
  throw Error('Unsupported sound/art configuration.');
 for(const kind of ['loading','background'])if(Object.hasOwn(value,kind)){
  const entry=value[kind];if(!modern||!exact(entry,['manifestUrl','manifestSha256','manifestBytes'])||entry.manifestUrl!=='./'+kind+'/manifest.json'||
   !/^[a-f0-9]{64}$/.test(entry.manifestSha256)||!Number.isInteger(entry.manifestBytes)||entry.manifestBytes<1||entry.manifestBytes>4*1024*1024)throw Error('Unsupported '+kind+' illustration configuration.');
 }
 return value;
}
function deployment(){
 if(!deploymentPromise)deploymentPromise=(async()=>{
  const localAbort=new AbortController(),stop=()=>localAbort.abort();pageAbort.signal.addEventListener('abort',stop,{once:true});const timer=setTimeout(stop,60000);
  try{
   const config=configuration(await json(configURL,65536,localAbort.signal));
   const manifest=await json(new URL(config.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.manifestSha256,bytes:config.manifestBytes});
   if(config.audio.effects){const paths=manifest.files?.filter(entry=>entry.path.endsWith('.wav')&&!entry.path.startsWith('wave/bgm/')).map(entry=>entry.path).sort();
    if(JSON.stringify(paths)!==JSON.stringify(config.effects.paths))throw Error('Sound resource declaration does not match the verified manifest.');}
   const loadingManifest=config.loading?validateLoadingManifest(await json(new URL(config.loading.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.loading.manifestSha256,bytes:config.loading.manifestBytes})):null;
   const backgroundManifest=config.background?validateBackgroundManifest(await json(new URL(config.background.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.background.manifestSha256,bytes:config.background.manifestBytes})):null;
   return {config,manifest,loadingManifest,backgroundManifest,assetRoot:new URL('./',new URL(config.manifestUrl,configURL)).href};
  }finally{clearTimeout(timer);pageAbort.signal.removeEventListener('abort',stop);}
 })().catch(error=>{deploymentPromise=null;throw error;});return deploymentPromise;
}
function artOwner(info){
 if(art||!info.config.art)return art;const key=resourceKey(info.config.manifestSha256);
 try{art=createReplayArt({manifest:info.manifest,assetRoot:info.assetRoot,key});return art;}finally{key.fill(0);}
}
let backdropOwner=null,backdropTexture=null,backdropClock=null,backdropRequest=null,backdropOffset=0;
function stopBackdrop(){if(backdropRequest!==null)window.cancelAnimationFrame(backdropRequest);backdropRequest=null;backdropClock=null;}
function drawBackdrop(){
 if(!backdropTexture)return;const ctx=$('page-background').getContext('2d');
 // No clear: the native integer319 branch retains its previous leftmost strip.
 for(const {sourceX,x,width}of selectionBackgroundSlices(backdropOffset))ctx.drawImage(backdropTexture,sourceX,0,width,240,x,0,width,240);
}
function backdropTick(now){
 backdropRequest=null;if(disposed||document.hidden||document.fullscreenElement||reducedMotion.matches)return;
 backdropClock=advanceMenuClock(backdropClock,now);
 for(let i=0;i<backdropClock.due;i++){backdropOffset=advanceSelectionOffset(backdropOffset);drawBackdrop();}
 backdropRequest=window.requestAnimationFrame(backdropTick);
}
function refreshBackdrop(){
 stopBackdrop();if(!backdropTexture||disposed||document.hidden||document.fullscreenElement)return;
 drawBackdrop();if(!reducedMotion.matches){backdropClock=createMenuClock(performance.now());backdropRequest=window.requestAnimationFrame(backdropTick);}
}
async function prepareBackdrop(info){
 if(!info.backgroundManifest||backdropOwner)return;
 const key=resourceKey(info.config.manifestSha256);
 try{
  backdropOwner=createSelectionBackground({manifest:info.backgroundManifest,assetRoot:new URL('./background/',configURL).href,key});
  const picture=await backdropOwner.picture();if(disposed)return;
  const texture=document.createElement('canvas');texture.width=320;texture.height=240;const ctx=texture.getContext('2d'),rgba=ctx.createImageData(320,240);rgba.data.set(picture.data);ctx.putImageData(rgba,0,0);
  backdropTexture=texture;refreshBackdrop();
 }finally{key.fill(0);}
}
async function landing(){
 try{
  const info=await deployment();if(disposed)return;const owner=artOwner(info);if(!owner)throw Error('This build has no menu artwork');
  await Promise.all([drawMenu(),prepareBackdrop(info).catch(error=>{if(!disposed)text('art-status','Background unavailable: '+error.message);})]);
  const entry=await owner.replayPanel();if(disposed)return;
  // A decorative crop of the existing replay sky, outside its menu labels.
  paintArt('entry-art',{width:entry.width,height:64,data:entry.data.slice(30*entry.width*4,94*entry.width*4)});
  const chrome=await owner.chrome();if(disposed)return;paintArt('chrome-logo',chrome.logo);
  for(const [key,variable]of Object.entries({world:'world',logo:'logo',wingLeft:'wing-left',wingRight:'wing-right',hudRail:'hud-rail',hudTop:'hud-top',hpTrack:'hp-track',spTrack:'sp-track',rfTrack:'rf-track',rfBlueTrack:'rf-blue-track'})){
   const picture=chrome[key],canvas=document.createElement('canvas');canvas.width=picture.width;canvas.height=picture.height;
   const ctx=canvas.getContext('2d'),image=ctx.createImageData(picture.width,picture.height);image.data.set(picture.data);ctx.putImageData(image,0,0);
   document.documentElement.style.setProperty('--native-'+variable,'url("'+canvas.toDataURL()+'")');
  }
  for(const selected of [false,true]){
   const picture=await owner.controlRow({selected});if(disposed)return;
   const canvas=document.createElement('canvas');canvas.width=picture.width;canvas.height=picture.height;
   const ctx=canvas.getContext('2d'),image=ctx.createImageData(picture.width,picture.height);image.data.set(picture.data);ctx.putImageData(image,0,0);
   document.documentElement.style.setProperty(selected?'--native-selected':'--native-row','url("'+canvas.toDataURL()+'")');
  }
 }catch(error){if(!disposed)text('art-status','Artwork unavailable: '+error.message);}
}
function update(status,own){
 if(own!==generation||disposed)return;current=status;
 text('frame',seconds(status.nextFrame)+' / '+seconds(status.frames));text('boundary','Update '+status.nextFrame.toLocaleString()+' / '+status.frames.toLocaleString());
 $('progress').max=status.frames;if(!scrubbing&&!seeking)$('progress').value=status.nextFrame;
 $('progress').setAttribute('aria-valuetext',seconds(status.nextFrame)+'; update '+status.nextFrame+' of '+status.frames);
 if(status.state==='ended'){starting=false;if(!seeking)uiIntent++;message('Replay complete');audioAction('stop');audioMessage('Playback complete');}
 else if(!loading&&!seeking&&!starting)message(status.state==='playing'?'Playing':status.nextFrame===0?'Ready':'Paused');
 controls();
}
async function retire(){
 uiIntent++;seekUiRevision++;starting=false;stepping=false;seeking=false;
 const old=controller,oldMusic=music,oldSounds=sounds;controller=null;music=null;sounds=null;
 const results=await Promise.allSettled([old?.dispose(),oldMusic?.dispose(),oldSounds?.dispose()]);
 const bad=results.find(result=>result.status==='rejected');if(bad)throw bad.reason;
}
// Finish loading off-screen without starting the first simulation update there.
// Replacement and page disposal also release these waits; callers recheck custody.
const preparationViews=new Set();
function wakePreparationViews(){for(const check of preparationViews)check();}
function waitForReplayView(own){return new Promise(resolve=>{
 const check=()=>{if(own!==generation||disposed||navigation?.current()==='replay'&&!document.hidden){preparationViews.delete(check);resolve();}};
 preparationViews.add(check);check();
});}
async function openFile(file,selectionError=null){
 if(disposed)return;
 navigation?.go('replay');
 const own=++generation,token=identity.begin();let firstFrame=null;wakePreparationViews();activeFile=file;loading=true;failed=false;current=null;scrubbing=false;
 context.clearRect(0,0,320,240);text('image-origin','');text('frame','00:00 / 00:00');text('boundary','No replay');$('progress').value=0;
 text('file-name',file?.name??'No replay');message('Validating replay…');loadingCover();controls();
 try{
  await retire();if(own!==generation||disposed)return;
  if(selectionError)throw Error(selectionError);
  if(!file||!file.name.toLowerCase().endsWith('.rep')||file.size>64*1024*1024)throw Error('Choose a .rep file up to 64 MiB');
  const bytes=new Uint8Array(await file.arrayBuffer());if(own!==generation||disposed)return;
  const meta=identity.admit(bytes,Number($('win-rounds').value),token);replayMeta=meta;
  const info=await deployment();if(own!==generation||disposed)return;
  await showLoadingArt(info,own);if(own!==generation||disposed)return;
  const {config,manifest,assetRoot}=info,owner=artOwner(info);if(!owner)throw Error('Menu artwork is missing from this build');
  const key=resourceKey(config.manifestSha256);
  try{
   const candidate=createReplayController({createWorker:()=>new Worker(new URL('./replay-worker.mjs',import.meta.url),{type:'module'}),
    onFrame:frame=>{if(own===generation&&!disposed){if(loading)firstFrame=frame;else present(frame.image,frame.result.stats,frame.result.training);}},
    onCommit:commit=>{if(own===generation&&!disposed&&commit.isCurrent()){present(commit.image,commit.stats,commit.training);$('progress').value=commit.status.nextFrame;}},
    onStatus:status=>update(status,own),
    onProgress:progress=>{if(own===generation&&!disposed){$('seek-progress').max=progress.targetNextUpdate||1;$('seek-progress').value=progress.nextFrame;text('seek-status','Seeking '+progress.nextFrame.toLocaleString()+' / '+progress.targetNextUpdate.toLocaleString());}},
    onError:error=>{if(own!==generation||disposed)return;identity.fail(token);loading=false;starting=false;seeking=false;failed=true;current=null;uiIntent++;audioAction('stop');placeholder('',{title:true});message(error.message,true);controls();}
   });
   controller=candidate;message('Loading battle…');await candidate.open({replayBytes:bytes,encryptedManifest:manifest,assetRoot,key,winRounds:meta.initialization.winRounds});
   if(own!==generation||disposed)return;
   music=createReplayMusic({manifest,assetRoot,key,path:config.music.paths[meta.initialization.stage]});music.setVolume(muted?0:Number($('volume').value));
   const ids=candidate.status();
   if(config.audio.effects){sounds=createReplaySounds({manifest,assetRoot,key,characters:meta.initialization.characters,generation:ids.generation,replayId:ids.replayId,seekRevision:ids.seekRevision});sounds.setVolume(muted?0:Number($('effects-volume').value));}
   candidate.setAudio({sounds,music});message('Loading sounds and music…');
   await Promise.all([music.prepare(),sounds?.prepare(),identity.show({portrait:(character,color,side)=>owner.fighterPanel(character,color,side,{angle:reducedMotion.matches?180:90,scroll:0})},token)]);
   if(own!==generation||disposed)return;
   await waitForReplayView(own);if(own!==generation||disposed)return;
   message('Preparing first frame…');await candidate.step();
   await waitForReplayView(own);
   if(own!==generation||disposed)return;
   if(!firstFrame||firstFrame.status.nextFrame!==1)throw Error('The first replay image is unavailable');
   present(firstFrame.image,firstFrame.result.stats,firstFrame.result.training);
  }finally{key.fill(0);}
  if(own!==generation||disposed)return;
  loading=false;message('Paused');audioMessage('Audio ready');controls();
 }catch(error){
  if(own!==generation||disposed)return;identity.fail(token);loading=false;failed=true;current=null;placeholder('',{title:true});
  message(error.name==='AbortError'?'Loading cancelled or timed out':error.message,true);await retire().catch(cleanup=>audioMessage(cleanup.message,true));controls();
 }
}
async function play(){
 if(!controller||loading||starting||stepping||seeking||current?.state!=='paused'||document.hidden||navigation?.current()!=='replay')return;
 const own=generation,intent=++uiIntent;starting=true;controls();message('Starting playback…');
 try{await controller.play();if(own===generation&&intent===uiIntent&&!disposed)audioMessage(sounds?'Music, effects & voices enabled':'Music enabled');}
 catch(error){if(own===generation&&intent===uiIntent&&!disposed){audioAction('pause');message(error.message,true);audioMessage('Audio could not start',true);}}
 finally{if(own===generation&&intent===uiIntent){starting=false;controls();}}
}
async function pause(){
 uiIntent++;starting=false;const own=generation;
 try{await controller?.pause();if(own===generation&&!seeking)message('Paused');}catch(error){if(own===generation)message(error.message,true);}finally{controls();}
}
async function step(){
 if(!controller||loading||starting||stepping||seeking||current?.state!=='paused')return;
 uiIntent++;stepping=true;controls();const own=generation;
 try{await controller.step();}catch(error){if(own===generation)message(error.message,true);}finally{if(own===generation){stepping=false;controls();}}
}
async function seek(target){
 if(navigation?.current()!=='replay'||!controller||loading||starting||stepping||!current)return;
 const own=generation,intent=++seekUiRevision;uiIntent++;starting=false;seeking=true;scrubbing=false;controls();message('Seeking…');
 $('seek-progress').max=target||1;$('seek-progress').value=0;text('seek-status','Preparing seek to '+target.toLocaleString());
 try{await controller.seek(target,{resume:false});if(own===generation&&intent===seekUiRevision&&!disposed){message(current?.state==='ended'?'Replay complete':target===0?'Ready':'Paused');audioMessage('Music restarts with Play');}}
 catch(error){if(own===generation&&intent===seekUiRevision&&!disposed)message(/cancelled/.test(error.message)?'Seek cancelled':error.message,!/cancelled/.test(error.message));}
 finally{if(own===generation&&intent===seekUiRevision&&!disposed){seeking=false;$('progress').value=current?.nextFrame??0;controls();}}
}
function cancelSeek(){uiIntent++;seekUiRevision++;controller?.cancelSeek();seeking=false;scrubbing=false;$('progress').value=current?.nextFrame??0;message('Seek cancelled');controls();}
function pickFile(){$('replay-file').value='';$('replay-file').click();}
$('open-form').addEventListener('submit',event=>{event.preventDefault();return openFile($('replay-file').files?.[0]??activeFile);});
for(const id of ['entry-open','watch-open'])$(id).addEventListener('click',pickFile);
$('open-replay').addEventListener('click',pickFile);$('title-open').addEventListener('click',pickFile);
$('replay-file').addEventListener('change',()=>{const file=$('replay-file').files?.[0];if(file)return openFile(file);});
$('win-rounds').addEventListener('change',()=>{if(activeFile)return openFile(activeFile);});
for(const [event,selected] of [['pointerenter',true],['focus',true],['pointerleave',false],['blur',false]])$('title-open').addEventListener(event,()=>{titleSelected=selected;void drawMenu();});
$('play').addEventListener('click',play);$('pause').addEventListener('click',pause);$('step').addEventListener('click',step);
$('restart').addEventListener('click',()=>seek(0));$('previous').addEventListener('click',()=>seek(Math.max(0,(current?.nextFrame??0)-1)));
$('cancel-seek').addEventListener('click',cancelSeek);
$('training-settings').addEventListener('toggle',refreshTraining);
for(const id of ['show-hitboxes','show-inputs','show-details'])$(id).addEventListener('change',refreshTraining);
$('progress').addEventListener('input',()=>{scrubbing=true;overlayControls?.refresh();text('frame',seconds(Number($('progress').value))+' / '+seconds(current?.frames??0));$('progress').setAttribute('aria-valuetext','Seek to update '+$('progress').value);});
$('progress').addEventListener('change',()=>{if(navigation?.current()!=='replay'){scrubbing=false;if(current)update(current,generation);return;}return seek(Number($('progress').value));});
$('progress').addEventListener('pointercancel',()=>{scrubbing=false;$('progress').value=current?.nextFrame??0;if(current)update(current,generation);});
for(const [id,label,owner] of [['volume','volume-value',()=>music],['effects-volume','effects-value',()=>sounds]])$(id).addEventListener('input',()=>{
 const value=Number($(id).value);text(label,Math.round(value*100)+'%');try{owner()?.setVolume(muted?0:value);}catch(error){audioMessage(error.message,true);}
});
function updateFullscreen(){
 const active=document.fullscreenElement===$('player'),button=$('fullscreen');
 button.hidden=typeof $('player').requestFullscreen!=='function'||document.fullscreenEnabled===false;
 button.disabled=fullscreenPending;text('fullscreen',active?'Exit fullscreen':'Fullscreen');
 button.setAttribute('aria-pressed',String(active));button.setAttribute('aria-label',active?'Exit fullscreen player':'Fullscreen player');
 button.title=active?'Exit fullscreen (F / Esc)':'Fullscreen (F)';
 if(active!==fullscreenActive){
  if(active){restoreFullscreenFocus=false;$('stage-shell').focus({preventScroll:true});}else if(fullscreenActive)restoreFullscreenFocus=true;
  fullscreenActive=active;
 }
 // Exit events can arrive while the requesting button is still disabled.
 if(restoreFullscreenFocus&&!fullscreenPending){restoreFullscreenFocus=false;
  const target=navigation?.current()==='watch'?$('nav-watch'):navigation?.current()==='replays'?$('nav-replays'):button;target.focus({preventScroll:true});}
 // A fullscreen request can finish after browser navigation hid its route.
 if(active&&navigation&&navigation.current()!=='replay')void document.exitFullscreen().catch(()=>message('Exit fullscreen to continue',true));
}
async function toggleFullscreen(){
 if(disposed||fullscreenPending||$('fullscreen').hidden)return;
 fullscreenPending=true;updateFullscreen();
 try{if(document.fullscreenElement)await document.exitFullscreen();else await $('player').requestFullscreen({navigationUI:'hide'});}
 catch{if(!disposed)message('Fullscreen is unavailable',true);}
 finally{fullscreenPending=false;if(!disposed)updateFullscreen();}
}
$('fullscreen').addEventListener('click',toggleFullscreen);
document.addEventListener('fullscreenchange',()=>{updateFullscreen();refreshBackdrop();});updateFullscreen();
document.addEventListener('keydown',event=>{
 if(event.code==='Tab'){keyboardControls=true;overlayControls?.reveal();}
 if(event.code==='Escape'&&$('training-settings').open){event.preventDefault();closeSettings();return;}
 if(event.code==='Escape'&&$('sound-settings').open){event.preventDefault();closeSound();return;}
 if(event.code==='Escape'&&seeking){event.preventDefault();cancelSeek();return;}
 if(event.code==='Escape'&&document.fullscreenElement===$('player')){event.preventDefault();void toggleFullscreen();return;}
 if(event.ctrlKey||event.metaKey||event.altKey||event.repeat||event.target?.isContentEditable||['INPUT','SELECT','TEXTAREA'].includes(event.target?.tagName))return;
 if(navigation?.current()!=='replay')return;
 if(event.code==='KeyF'&&!$('fullscreen').hidden){event.preventDefault();void toggleFullscreen();return;}
 if(['BUTTON','SUMMARY','A'].includes(event.target?.tagName))return;
 if(event.code==='Space'&&controller&&!loading){event.preventDefault();void(current?.state==='playing'||starting?pause():play());}
 else if(event.code==='ArrowRight'&&!$('step').disabled){event.preventDefault();void step();}
 else if(event.code==='ArrowLeft'&&!$('previous').disabled){event.preventDefault();void seek(Math.max(0,current.nextFrame-1));}
 else if(event.code==='Home'&&!$('restart').disabled){event.preventDefault();void seek(0);}
});
for(const event of ['dragenter','dragover'])$('stage-shell').addEventListener(event,e=>{e.preventDefault();});
$('stage-shell').addEventListener('drop',event=>{event.preventDefault();const files=event.dataTransfer?.files;if(files?.length===1)void openFile(files[0]);else if(files?.length)void openFile(null,'Drop one .rep file');});
document.addEventListener('visibilitychange',()=>{refreshBackdrop();if(document.hidden){stopMenu();stopFighters();uiIntent++;starting=false;audioAction('pause');void controller?.pause().catch(()=>{});controls();}
 else{wakePreparationViews();if(initialization&&!reducedMotion.matches){fighterClock=createMenuClock(performance.now());fighterTimer=window.requestAnimationFrame(fighterTick);}
  if(!$('placeholder').hidden){menuClock=createMenuClock(performance.now());if(!reducedMotion.matches&&(menuMotion.phase===1||menuMotion.phase===3))menuTimer=window.requestAnimationFrame(menuTick);else void drawMenu();}}});
reducedMotion.addEventListener('change',()=>{refreshBackdrop();stopMenu();stopFighters();if(reducedMotion.matches){while(menuMotion.phase===1||menuMotion.phase===3)menuMotion=advanceMenuMotion(menuMotion);fighterMotion={angle:180,nextAngle:185,scroll:fighterMotion.scroll};void drawMenu();void drawFighters().catch(()=>{});}
 else if(initialization&&!document.hidden){fighterClock=createMenuClock(performance.now());fighterTimer=window.requestAnimationFrame(fighterTick);}});
window.addEventListener('pagehide',()=>{overlayControls?.dispose();navigation?.dispose();disposed=true;generation++;stopBackdrop();backdropOwner?.dispose();backdropTexture=null;wakePreparationViews();stopMenu();pageAbort.abort();identity.begin();art?.dispose();loadingArt?.dispose();void retire().catch(()=>{});});
function suspendView(){
 // This fence is synchronous; a pending play/seek cannot regain hidden ownership.
 uiIntent++;starting=false;if(seeking)cancelSeek();audioAction('pause');closeSettings(false);closeSound(false);
 scrubbing=false;controlsPointer=false;if(current)update(current,generation);
 stopMenu();stopFighters();const owner=controller,own=generation;
 void owner?.pause().catch(error=>{if(!disposed&&own===generation&&owner===controller)message(error.message,true);});
}
function renderRoute(route){
 if(route!=='replay'&&document.fullscreenElement===$('player'))void document.exitFullscreen().catch(()=>message('Exit fullscreen to continue',true));
 $('replay-library').hidden=route!=='replays';$('replay-route').hidden=route!=='replay';$('watch-route').hidden=route!=='watch';
 $('nav-replays').setAttribute('aria-current',route==='watch'?'false':'page');
 $('nav-watch').setAttribute('aria-current',route==='watch'?'page':'false');
 document.documentElement.dataset.route=route;wakePreparationViews();
 if(route==='replay'&&art){void drawMenu();void drawFighters().catch(()=>{});}
 controls();
}
navigation=createAppNavigation({readHash:()=>window.location.hash,
 writeHash:(hash,replace)=>window.history[replace?'replaceState':'pushState']({view:hash.slice(2)},'',hash),
 subscribe:change=>{window.addEventListener('popstate',change);window.addEventListener('hashchange',change);return()=>{window.removeEventListener('popstate',change);window.removeEventListener('hashchange',change);};},
 leaveReplay:suspendView,render:renderRoute});
for(const [id,route]of [['nav-replays','replays'],['nav-watch','watch'],['back-replays','replays'],['watch-return','replay']])$(id).addEventListener('click',event=>{event.preventDefault();navigation.go(route);});
$('session-resume').addEventListener('click',()=>navigation.go('replay'));
function closeSettings(focus=true){
 $('training-settings').open=false;refreshTraining();if(focus)(settingsTrigger??$('analysis-open')).focus({preventScroll:true});overlayControls?.reveal();
}
function closeSound(focus=true){
 $('sound-settings').open=false;$('mute').setAttribute('aria-expanded','false');if(focus)$('mute').focus({preventScroll:true});overlayControls?.reveal();
}
for(const id of ['analysis-open','player-settings'])$(id).addEventListener('click',()=>{closeSound(false);settingsTrigger=$(id);const panel=$('training-settings');panel.open=!panel.open;refreshTraining();if(panel.open)$('analysis-toggle').focus({preventScroll:true});overlayControls?.reveal();});
$('close-analysis').addEventListener('click',event=>{event.preventDefault();closeSettings();});
$('close-sound').addEventListener('click',event=>{event.preventDefault();closeSound();});
$('sound-settings').addEventListener('toggle',()=>{$('mute').setAttribute('aria-expanded',String($('sound-settings').open));overlayControls?.refresh();});
document.addEventListener('pointerdown',event=>{if(event.target.closest('.player-menu,#mute,#player-settings,#analysis-open'))return;if($('training-settings').open)closeSettings(false);if($('sound-settings').open)closeSound(false);});
$('settings-restart').addEventListener('click',()=>seek(0));$('settings-previous').addEventListener('click',()=>seek(Math.max(0,(current?.nextFrame??0)-1)));$('settings-step').addEventListener('click',step);
overlayControls=createPlayerControls({
 pinned:()=>navigation?.current()!=='replay'||current?.state!=='playing'||loading||seeking||scrubbing||controlsPointer||$('training-settings').open||$('sound-settings').open||keyboardControls&&!!document.activeElement?.closest?.('#playback-controls'),
 render:visible=>{if(!visible&&document.activeElement?.closest?.('#playback-controls'))$('toggle-controls').focus({preventScroll:true});$('player').classList.toggle('controls-visible',visible);$('toggle-controls').setAttribute('aria-label',visible?'Hide playback controls':'Show playback controls');}
});
$('toggle-controls').addEventListener('click',()=>{keyboardControls=false;overlayControls.toggle();});
$('playback-controls').addEventListener('pointerdown',()=>{controlsPointer=true;keyboardControls=false;overlayControls.reveal();});
$('playback-controls').addEventListener('pointermove',()=>overlayControls.reveal());
$('playback-controls').addEventListener('focusin',()=>overlayControls.reveal());
$('playback-controls').addEventListener('focusout',()=>queueMicrotask(()=>overlayControls.refresh()));
for(const event of ['pointerup','pointercancel'])document.addEventListener(event,()=>{if(controlsPointer){controlsPointer=false;overlayControls.reveal();}});
$('help-open').addEventListener('click',()=>{$('help').open=true;$('help').scrollIntoView({block:'nearest',behavior:reducedMotion.matches?'instant':'smooth'});});
$('mute').addEventListener('click',()=>{closeSettings(false);const panel=$('sound-settings');panel.open=!panel.open;$('mute').setAttribute('aria-expanded',String(panel.open));if(panel.open)$('sound-toggle').focus({preventScroll:true});overlayControls?.reveal();});
$('mute-audio').addEventListener('change',()=>{muted=$('mute-audio').checked;
 try{music?.setVolume(muted?0:Number($('volume').value));sounds?.setVolume(muted?0:Number($('effects-volume').value));}catch(error){audioMessage(error.message,true);}});
identity.begin();controls();void landing();
