import {createReplayController} from '../src/pages/replay-controller.mjs';
import {createReplayIdentity} from '../src/pages/replay-identity.mjs';
import {validateReplayStats,emptyReplayStats} from '../src/pages/replay-stats.mjs';
import {createReplayMusic} from '../src/pages/replay-music.mjs';
import {createReplaySounds} from '../src/pages/replay-sounds.mjs';
import {createReplayArt} from '../src/pages/replay-art.mjs';
import {createMenuMotion,setMenuMotionDirection,advanceMenuMotion,sampleMenuMotion,createMenuClock,advanceMenuClock} from '../src/pages/menu-scene.mjs';
import {GAME_ART_PATHS} from '../src/pages/art-paths.mjs';
import {STAGE_MUSIC_PATHS} from '../src/asset-selection.mjs';
import {resourceKey} from '../deployment/resource-access.mjs';

const $=id=>document.getElementById(id),context=$('screen').getContext('2d',{alpha:false}),rgba=context.createImageData(320,240);
const NAMES=['Nanase','Ayu','Mai','Makoto','Akane','Mayu','Mizuka','Misaki','Shiori','Sayuri','Nayuki','Mio','EX Nanase','Kaori','Ikumi','Mishio','Akiko','Nayuki B','Mizuka B','Kanna','Kano','Minagi','Nayuki','Misuzu','Mizuka'];
const configURL=new URL('../deployment/config.json',import.meta.url),pageAbort=new AbortController(),reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
let generation=0,uiIntent=0,seekUiRevision=0,controller=null,music=null,sounds=null,art=null,current=null,initialization=null,activeFile=null,loading=false,starting=false,stepping=false,seeking=false,scrubbing=false,disposed=false,failed=false,deploymentPromise=null;
let menuMode='title',menuMotion=createMenuMotion({row:4}),menuClock=null,menuTimer=null,menuPaintRevision=0,titleSelected=false;
const text=(id,value)=>{const node=$(id),content=String(value);if(node.textContent!==content)node.textContent=content;};
const seconds=updates=>{const total=Math.floor(updates/64);return String(Math.floor(total/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');};
const decimal=value=>Number.isInteger(value)?String(value):value.toFixed(2).replace(/0+$/,'').replace(/\.$/,'');
function message(value,error=false){text('status',value);$('status').classList.toggle('error',error);}
function audioMessage(value,error=false){text('music-status',value);$('music-status').classList.toggle('error',error);}
function audioAction(action){for(const owner of [music,sounds])try{owner?.[action]();}catch(error){audioMessage(error.message,true);}}
function controls(){
 const available=controller&&current&&!loading&&!['failed','disposed'].includes(current.state),busy=starting||stepping||seeking;
 $('play').hidden=!!(current?.state==='playing'||starting);$('pause').hidden=!$('play').hidden;
 $('play').disabled=!available||busy||current?.state!=='paused';$('pause').disabled=!available||stepping||seeking;
 $('step').disabled=!available||busy||current?.state!=='paused';$('previous').disabled=!available||busy||current?.nextFrame===0;
 $('restart').disabled=!available||busy||current?.nextFrame===0;$('progress').disabled=!available;
 $('seek-row').hidden=!seeking;
 document.documentElement.dataset.playerState=loading?'loading':seeking?'seeking':starting?'preparing':failed?'failed':current?.state??'empty';
}
function paintArt(id,picture){
 const canvas=$(id);canvas.width=picture.width;canvas.height=picture.height;
 const ctx=canvas.getContext('2d'),image=ctx.createImageData(picture.width,picture.height);image.data.set(picture.data);ctx.putImageData(image,0,0);
}
function stopMenu(){if(menuTimer!==null)window.cancelAnimationFrame(menuTimer);menuTimer=null;menuClock=null;menuPaintRevision++;}
async function drawMenu(){
 if(!art||disposed||$('placeholder').hidden)return;
 const own=++menuPaintRevision,mode=menuMode,motion=menuMotion;
 try{
  const picture=mode==='title'?await art.titleReplay({selected:titleSelected}):await art.replayPanel({motion,selected:true});
  if(own!==menuPaintRevision||disposed||$('placeholder').hidden)return;
  paintArt('menu-art',picture);$('brand-fallback').hidden=true;
  $('title-open').hidden=mode!=='title';$('menu-line').hidden=mode==='title';
  if(mode==='replay')$('menu-line').style.top=(sampleMenuMotion(motion).selectedY/240*100)+'%';
 }catch(error){if(own===menuPaintRevision&&!disposed)text('art-status','Artwork unavailable: '+error.message);}
}
function menuTick(now){
 menuTimer=null;if(disposed||document.hidden||reducedMotion.matches||$('placeholder').hidden)return;
 menuClock=advanceMenuClock(menuClock??createMenuClock(now),now);
 for(let count=0;count<Math.min(menuClock.due,2);count++)menuMotion=advanceMenuMotion(menuMotion);
 void drawMenu();if(menuMotion.phase===1||menuMotion.phase===3)menuTimer=window.requestAnimationFrame(menuTick);
}
function placeholder(label,{title=false,animate=false}={}){
 const keepMotion=!title&&!animate&&menuMode==='replay'&&!$('placeholder').hidden&&(menuMotion.phase===1||menuMotion.phase===3);
 if(!keepMotion)stopMenu();$('placeholder').hidden=false;menuMode=title?'title':'replay';text('menu-line',label);
 $('title-open').hidden=!title;$('menu-line').hidden=title;
 if(!title&&animate){menuMotion=setMenuMotionDirection(createMenuMotion({row:4}),'open');
  if(reducedMotion.matches||document.hidden){while(menuMotion.phase===1)menuMotion=advanceMenuMotion(menuMotion);}
  else{menuClock=createMenuClock(performance.now());menuTimer=window.requestAnimationFrame(menuTick);}
 }
 void drawMenu();
}
function paint(image){
 if(!image){context.clearRect(0,0,320,240);text('image-origin','No battle image');placeholder('Ready · Play');return;}
 for(let n=0;n<76800;n++){const out=n*4,color=image.pixels[n]*4;
  rgba.data[out]=image.palette[color];rgba.data[out+1]=image.palette[color+1];rgba.data[out+2]=image.palette[color+2];rgba.data[out+3]=255;}
 context.putImageData(rgba,0,0);$('placeholder').hidden=true;stopMenu();
 text('image-origin','Image: update '+image.originUpdate.toLocaleString());
}
function showStats(raw){
 const stats=validateReplayStats(raw,raw.nextUpdate,initialization);
 for(const [side,suffix] of ['one','two'].entries()){
  const p=stats.players?.[side];
  for(const field of ['hp','sp','rf']){
   text(field+'-'+suffix,p?decimal(p[field]):'—');$(field+'-'+suffix).title=p?String(p[field]):'';
   $(field+'-bar-'+suffix).style.width=p?Math.max(0,Math.min(100,p[field]/({hp:9999,sp:3000,rf:1000}[field])*100))+'%':'0%';
  }
  $('rf-bar-'+suffix).classList.toggle('blue',!!p?.rfBlue);
  text('rf-mode-'+suffix,p?(p.rfBlue?'RF · Blue':'RF · Normal'):'');text('wins-'+suffix,p?'Wins '+p.wins+' / '+initialization.winRounds:'Wins —');
 }
 text('stats-origin',stats.availability==='none'?'Values appear after the first update':stats.availability==='last-live'?'Final values: update '+stats.sourceUpdate.toLocaleString()+' (boundary '+(stats.sourceUpdate+1).toLocaleString()+')':'Values: boundary '+stats.nextUpdate.toLocaleString());
}
const identity=createReplayIdentity({
 clear(){
  initialization=null;$('match-info').hidden=true;$('player').classList.remove('identified');
  for(const suffix of ['one','two']){text('fighter-'+suffix,'');text('palette-'+suffix,'');const canvas=$('portrait-'+suffix);canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);}
  text('match-stage','');showStats(emptyReplayStats());text('stats-origin','');
 },
 display(init,pictures){
  initialization=init;for(const [side,suffix] of ['one','two'].entries()){
   text('fighter-'+suffix,NAMES[init.characters[side]]);text('palette-'+suffix,'Color '+(init.palettes[side]+1));paintArt('portrait-'+suffix,pictures[side]);
  }
  text('match-stage','Stage '+String(init.stage+1).padStart(2,'0')+' · First to '+init.winRounds);$('match-stage').title='Recorded stage ID '+init.stage;
  $('match-info').hidden=false;$('player').classList.add('identified');showStats(emptyReplayStats());
 }
});
async function json(url,max,signal,expected=null){
 const response=await fetch(url,{signal,credentials:'omit',redirect:'error'});if(!response.ok||!response.body)throw Error('Deployment files are unavailable.');
 const reader=response.body.getReader(),parts=[];let size=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max)throw Error('Deployment file exceeds its limit.');parts.push(value);}}
 catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
 if(expected){const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(size!==expected.bytes||hash!==expected.sha256)throw Error('Deployment manifest integrity check failed.');}
 return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
function configuration(value){
 const modern=value?.schema==='miracle-replay-pages/3';
 const keys=['schema','manifestUrl','manifestSha256','manifestBytes','generatedEngineHash','qualification','audio','music','supported',...(modern?['effects','art']:[])];
 const exact=(object,expected)=>object&&typeof object==='object'&&!Array.isArray(object)&&Object.keys(object).sort().join(',')===[...expected].sort().join(',');
 const range=(value,start,count)=>JSON.stringify(value)===JSON.stringify(Array.from({length:count},(_,i)=>start+i));
 if(!exact(value,keys)||!['miracle-replay-pages/2','miracle-replay-pages/3'].includes(value.schema)||value.manifestUrl!=='./assets/manifest.json'||
  !/^[a-f0-9]{64}$/.test(value.manifestSha256)||!/^[a-f0-9]{64}$/.test(value.generatedEngineHash)||
  !Number.isInteger(value.manifestBytes)||value.manifestBytes<1||value.manifestBytes>4*1024*1024||value.qualification!=='experimental'||
  !exact(value.audio,modern?['music','effects','voices']:['music','effects'])||value.audio.music!==true||value.audio.effects!==modern||modern&&value.audio.voices!==true||
  !exact(value.music,['paths','mime'])||JSON.stringify(value.music.paths)!==JSON.stringify(STAGE_MUSIC_PATHS)||value.music.mime!=='audio/wav'||
  !exact(value.supported,['characters','stages','palettes','winRounds','defaultWinRounds'])||!range(value.supported.characters,0,25)||!range(value.supported.stages,0,23)||
  !range(value.supported.palettes,0,6)||!range(value.supported.winRounds,1,3)||value.supported.defaultWinRounds!==2)
  throw Error('Unsupported deployment configuration.');
 if(modern&&(!exact(value.art,['paths'])||JSON.stringify(value.art.paths)!==JSON.stringify(GAME_ART_PATHS)||
  !exact(value.effects,['paths','mime'])||value.effects.mime!=='audio/wav'||!Array.isArray(value.effects.paths)||value.effects.paths.length<1||value.effects.paths.length>1300||
  value.effects.paths.some((path,i)=>typeof path!=='string'||path.length>100||!/^([a-z]+\/wave|wave\/se)\/[0-9]{2}\.wav$/.test(path)||i>0&&value.effects.paths[i-1]>=path)))
  throw Error('Unsupported sound/art configuration.');return value;
}
function deployment(){
 if(!deploymentPromise)deploymentPromise=(async()=>{
  const localAbort=new AbortController(),stop=()=>localAbort.abort();pageAbort.signal.addEventListener('abort',stop,{once:true});const timer=setTimeout(stop,60000);
  try{
   const config=configuration(await json(configURL,65536,localAbort.signal));
   const manifest=await json(new URL(config.manifestUrl,configURL),4*1024*1024,localAbort.signal,{sha256:config.manifestSha256,bytes:config.manifestBytes});
   if(config.audio.effects){const paths=manifest.files?.filter(entry=>entry.path.endsWith('.wav')&&!entry.path.startsWith('wave/bgm/')).map(entry=>entry.path).sort();
    if(JSON.stringify(paths)!==JSON.stringify(config.effects.paths))throw Error('Sound resource declaration does not match the verified manifest.');}
   return {config,manifest,assetRoot:new URL('./',new URL(config.manifestUrl,configURL)).href};
  }finally{clearTimeout(timer);pageAbort.signal.removeEventListener('abort',stop);}
 })().catch(error=>{deploymentPromise=null;throw error;});return deploymentPromise;
}
function artOwner(info){
 if(art||!info.config.art)return art;const key=resourceKey(info.config.manifestSha256);
 try{art=createReplayArt({manifest:info.manifest,assetRoot:info.assetRoot,key});return art;}finally{key.fill(0);}
}
async function landing(){
 try{
  const info=await deployment();if(disposed)return;const owner=artOwner(info);if(!owner)throw Error('This build has no menu artwork');
  await drawMenu();
  for(const selected of [false,true]){
   const picture=await owner.controlRow({selected});if(disposed)return;
   const canvas=document.createElement('canvas');canvas.width=picture.width;canvas.height=picture.height;
   const ctx=canvas.getContext('2d'),image=ctx.createImageData(picture.width,picture.height);image.data.set(picture.data);ctx.putImageData(image,0,0);
   document.documentElement.style.setProperty(selected?'--native-selected':'--native-row','url("'+canvas.toDataURL()+'")');
  }
 }catch(error){if(!disposed)text('art-status','Artwork unavailable: '+error.message);}
}
function update(status,own){
 if(own!==generation||disposed)return;current=status;
 text('frame',seconds(status.nextFrame)+' / '+seconds(status.frames));text('boundary','Update '+status.nextFrame.toLocaleString()+' / '+status.frames.toLocaleString());
 $('progress').max=status.frames;if(!scrubbing&&!seeking)$('progress').value=status.nextFrame;
 $('progress').setAttribute('aria-valuetext',seconds(status.nextFrame)+'; update '+status.nextFrame+' of '+status.frames);
 if(status.state==='ended'){starting=false;if(!seeking)uiIntent++;message('Replay complete');audioAction('stop');audioMessage('Playback complete');}
 else if(!loading&&!seeking&&!starting)message(status.state==='playing'?'Playing':status.nextFrame===0?'Ready':'Paused');
 controls();
}
async function retire(){
 uiIntent++;seekUiRevision++;starting=false;stepping=false;seeking=false;
 const old=controller,oldMusic=music,oldSounds=sounds;controller=null;music=null;sounds=null;
 const results=await Promise.allSettled([old?.dispose(),oldMusic?.dispose(),oldSounds?.dispose()]);
 const bad=results.find(result=>result.status==='rejected');if(bad)throw bad.reason;
}
async function openFile(file,selectionError=null){
 if(disposed)return;
 const own=++generation,token=identity.begin();activeFile=file;loading=true;failed=false;current=null;scrubbing=false;
 context.clearRect(0,0,320,240);text('image-origin','');text('frame','00:00 / 00:00');text('boundary','No replay');$('progress').value=0;
 text('file-name',file?.name??'No replay');message('Validating replay…');placeholder('Loading…',{animate:true});controls();
 try{
  await retire();if(own!==generation||disposed)return;
  if(selectionError)throw Error(selectionError);
  if(!file||!file.name.toLowerCase().endsWith('.rep')||file.size>64*1024*1024)throw Error('Choose a .rep file up to 64 MiB');
  const bytes=new Uint8Array(await file.arrayBuffer());if(own!==generation||disposed)return;
  const meta=identity.admit(bytes,Number($('win-rounds').value),token),info=await deployment();if(own!==generation||disposed)return;
  const {config,manifest,assetRoot}=info,owner=artOwner(info);if(!owner)throw Error('Menu artwork is missing from this build');
  const key=resourceKey(config.manifestSha256);
  try{
   const candidate=createReplayController({createWorker:()=>new Worker(new URL('./replay-worker.mjs',import.meta.url),{type:'module'}),
    onFrame:frame=>{if(own===generation&&!disposed){paint(frame.image);showStats(frame.result.stats);}},
    onCommit:commit=>{if(own===generation&&!disposed&&commit.isCurrent()){paint(commit.image);showStats(commit.stats);$('progress').value=commit.status.nextFrame;}},
    onStatus:status=>update(status,own),
    onProgress:progress=>{if(own===generation&&!disposed){$('seek-progress').max=progress.targetNextUpdate||1;$('seek-progress').value=progress.nextFrame;text('seek-status','Seeking '+progress.nextFrame.toLocaleString()+' / '+progress.targetNextUpdate.toLocaleString());}},
    onError:error=>{if(own!==generation||disposed)return;identity.fail(token);loading=false;starting=false;seeking=false;failed=true;current=null;uiIntent++;audioAction('stop');placeholder('',{title:true});message(error.message,true);controls();}
   });
   controller=candidate;message('Loading battle…');await candidate.open({replayBytes:bytes,encryptedManifest:manifest,assetRoot,key,winRounds:meta.initialization.winRounds});
   if(own!==generation||disposed)return;
   music=createReplayMusic({manifest,assetRoot,key,path:config.music.paths[meta.initialization.stage]});music.setVolume(Number($('volume').value));
   const ids=candidate.status();
   if(config.audio.effects){sounds=createReplaySounds({manifest,assetRoot,key,characters:meta.initialization.characters,generation:ids.generation,replayId:ids.replayId,seekRevision:ids.seekRevision});sounds.setVolume(Number($('effects-volume').value));}
   candidate.setAudio({sounds,music});await identity.show(owner,token);
  }finally{key.fill(0);}
  if(own!==generation||disposed)return;
  loading=false;placeholder('Ready · Play');message('Ready');audioMessage('Audio starts with Play');controls();
 }catch(error){
  if(own!==generation||disposed)return;identity.fail(token);loading=false;failed=true;current=null;placeholder('',{title:true});
  message(error.name==='AbortError'?'Loading cancelled or timed out':error.message,true);await retire().catch(cleanup=>audioMessage(cleanup.message,true));controls();
 }
}
async function play(){
 if(!controller||loading||starting||stepping||seeking||current?.state!=='paused'||document.hidden)return;
 const own=generation,intent=++uiIntent;starting=true;controls();message('Preparing audio…');
 try{await controller.play();if(own===generation&&intent===uiIntent&&!disposed)audioMessage(sounds?'Music, effects & voices enabled':'Music enabled');}
 catch(error){if(own===generation&&intent===uiIntent&&!disposed){audioAction('pause');message(error.message,true);audioMessage('Audio could not start',true);}}
 finally{if(own===generation&&intent===uiIntent){starting=false;controls();}}
}
async function pause(){
 uiIntent++;starting=false;const own=generation;
 try{await controller?.pause();if(own===generation&&!seeking)message('Paused');}catch(error){if(own===generation)message(error.message,true);}finally{controls();}
}
async function step(){
 if(!controller||loading||starting||stepping||seeking||current?.state!=='paused')return;
 uiIntent++;stepping=true;controls();const own=generation;
 try{await controller.step();}catch(error){if(own===generation)message(error.message,true);}finally{if(own===generation){stepping=false;controls();}}
}
async function seek(target){
 if(!controller||loading||starting||stepping||!current)return;
 const own=generation,intent=++seekUiRevision;uiIntent++;starting=false;seeking=true;scrubbing=false;controls();message('Seeking…');
 $('seek-progress').max=target||1;$('seek-progress').value=0;text('seek-status','Preparing seek to '+target.toLocaleString());
 try{await controller.seek(target,{resume:false});if(own===generation&&intent===seekUiRevision&&!disposed){message(current?.state==='ended'?'Replay complete':target===0?'Ready':'Paused');audioMessage('Music restarts with Play');}}
 catch(error){if(own===generation&&intent===seekUiRevision&&!disposed)message(/cancelled/.test(error.message)?'Seek cancelled':error.message,!/cancelled/.test(error.message));}
 finally{if(own===generation&&intent===seekUiRevision&&!disposed){seeking=false;$('progress').value=current?.nextFrame??0;controls();}}
}
function cancelSeek(){uiIntent++;seekUiRevision++;controller?.cancelSeek();seeking=false;scrubbing=false;$('progress').value=current?.nextFrame??0;message('Seek cancelled');controls();}
function pickFile(){$('replay-file').value='';$('replay-file').click();}
$('open-form').addEventListener('submit',event=>{event.preventDefault();return openFile($('replay-file').files?.[0]??activeFile);});
$('open-replay').addEventListener('click',pickFile);$('title-open').addEventListener('click',pickFile);
$('replay-file').addEventListener('change',()=>{const file=$('replay-file').files?.[0];if(file)return openFile(file);});
$('win-rounds').addEventListener('change',()=>{if(activeFile)return openFile(activeFile);});
for(const [event,selected] of [['pointerenter',true],['focus',true],['pointerleave',false],['blur',false]])$('title-open').addEventListener(event,()=>{titleSelected=selected;void drawMenu();});
$('play').addEventListener('click',play);$('pause').addEventListener('click',pause);$('step').addEventListener('click',step);
$('restart').addEventListener('click',()=>seek(0));$('previous').addEventListener('click',()=>seek(Math.max(0,(current?.nextFrame??0)-1)));
$('cancel-seek').addEventListener('click',cancelSeek);
$('progress').addEventListener('input',()=>{scrubbing=true;text('frame',seconds(Number($('progress').value))+' / '+seconds(current?.frames??0));$('progress').setAttribute('aria-valuetext','Seek to update '+$('progress').value);});
$('progress').addEventListener('change',()=>seek(Number($('progress').value)));
for(const [id,label,owner] of [['volume','volume-value',()=>music],['effects-volume','effects-value',()=>sounds]])$(id).addEventListener('input',()=>{
 const value=Number($(id).value);text(label,Math.round(value*100)+'%');try{owner()?.setVolume(value);}catch(error){audioMessage(error.message,true);}
});
$('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await $('viewer').requestFullscreen();}catch{message('Fullscreen is unavailable',true);}});
if(typeof $('viewer').requestFullscreen!=='function')$('fullscreen').hidden=true;
document.addEventListener('keydown',event=>{
 if(event.code==='Escape'&&seeking){event.preventDefault();cancelSeek();return;}
 if(event.ctrlKey||event.metaKey||event.altKey||event.repeat||['INPUT','SELECT','TEXTAREA','BUTTON','SUMMARY','A'].includes(event.target?.tagName))return;
 if(event.code==='Space'&&controller&&!loading){event.preventDefault();void(current?.state==='playing'||starting?pause():play());}
 else if(event.code==='ArrowRight'&&!$('step').disabled){event.preventDefault();void step();}
 else if(event.code==='ArrowLeft'&&!$('previous').disabled){event.preventDefault();void seek(Math.max(0,current.nextFrame-1));}
 else if(event.code==='Home'&&!$('restart').disabled){event.preventDefault();void seek(0);}
});
for(const event of ['dragenter','dragover'])$('stage-shell').addEventListener(event,e=>{e.preventDefault();});
$('stage-shell').addEventListener('drop',event=>{event.preventDefault();const files=event.dataTransfer?.files;if(files?.length===1)void openFile(files[0]);else if(files?.length)void openFile(null,'Drop one .rep file');});
document.addEventListener('visibilitychange',()=>{if(document.hidden){stopMenu();uiIntent++;starting=false;audioAction('pause');void controller?.pause().catch(()=>{});controls();}
 else if(!$('placeholder').hidden){menuClock=createMenuClock(performance.now());if(!reducedMotion.matches&&(menuMotion.phase===1||menuMotion.phase===3))menuTimer=window.requestAnimationFrame(menuTick);else void drawMenu();}});
reducedMotion.addEventListener('change',()=>{stopMenu();if(reducedMotion.matches){while(menuMotion.phase===1||menuMotion.phase===3)menuMotion=advanceMenuMotion(menuMotion);void drawMenu();}});
window.addEventListener('pagehide',()=>{disposed=true;generation++;stopMenu();pageAbort.abort();identity.begin();art?.dispose();void retire().catch(()=>{});});
identity.begin();controls();void landing();
