# EFZ Replay Lab — Credits

**Site, Netplay support and Engine modification by Aquatic.**

**Original web engine by [Mu-Tsun Tsai](https://github.com/MuTsunTsai/efz).**
Copyright © 2026 Mu-Tsun Tsai. All rights reserved. See the [original engine license](public/upstream-license.txt).

**Eternal Fighter Zero is created by Twilight Frontier.**
The game and its original assets belong to their respective rights holders. All rights reserved.

EFZ Replay Lab is an independent project and is not affiliated with Team Shanghai Alice or Twilight Frontier.

Third-party code and assets retain their original copyright notices and license terms.
