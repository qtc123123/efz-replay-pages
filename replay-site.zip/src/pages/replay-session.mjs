import {inspectExtendedReplay} from '../revival.mjs';
import {validatePair} from '../spectator-profile.mjs';
import {EncryptedAssetCatalog,validateEncryptedAssetManifest} from '../encrypted-assets.mjs';

export const REPLAY_PAGE_LIMITS=Object.freeze({replayBytes:64*1024*1024,frames:1000000,pendingCommands:8,frameMilliseconds:1000/64});
const L=REPLAY_PAGE_LIMITS,typed=Object.getPrototypeOf(Uint8Array.prototype);
const tag=Object.getOwnPropertyDescriptor(typed,Symbol.toStringTag).get,length=Object.getOwnPropertyDescriptor(typed,'byteLength').get;
const backing=Object.getOwnPropertyDescriptor(typed,'buffer').get,resizable=Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,'resizable')?.get;
const need=(ok,message)=>{if(!ok)throw Error('Replay: '+message);};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
const required=Object.freeze(['system/object.dat','system/effect/effect.dat','system/effect/effect.pat','system/bg/bg17.dat','system/bg/bg17b.dat',
 'nayukib/nayukib.dat','nayukib/nayukib.pat','akiko/akiko.dat','akiko/akiko.pat']);
function fields(value,keys){
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'plain message required');
 const own=Reflect.ownKeys(value);need(own.length===keys.length&&keys.every(key=>own.includes(key)),'message fields');
 const out={};for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'accessor refused');out[key]=d.value;}return out;
}
function bytes(value,max,exact=null){
 need(ArrayBuffer.isView(value)&&tag.call(value)==='Uint8Array','byte buffer required');
 const buffer=backing.call(value),size=length.call(value);
 need(Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&!resizable?.call(buffer)&&size<=max&&(exact===null||size===exact),'fixed byte extent');
 const result=new Uint8Array(size);Uint8Array.prototype.set.call(result,value);return result;
}
function data(value,depth=0,budget={left:65536}){
 need(depth<=16,'observation depth');
 if(value===null||typeof value==='boolean'){budget.left-=4;need(budget.left>=0,'observation capacity');return value;}
 if(typeof value==='number'){need(Number.isFinite(value),'finite observation required');budget.left-=16;need(budget.left>=0,'observation capacity');return value;}
 if(typeof value==='string'){budget.left-=value.length*3+2;need(budget.left>=0,'observation capacity');return value;}
 if(Array.isArray(value)){need(value.length<=4096&&Reflect.ownKeys(value).length===value.length+1,'observation array');
  return Object.freeze(Array.from({length:value.length},(_,i)=>{const d=Object.getOwnPropertyDescriptor(value,String(i));need(d&&'value'in d,'observation accessor');return data(d.value,depth+1,budget);}));}
 need(value&&[Object.prototype,null].includes(Object.getPrototypeOf(value)),'observation record');const out={},keys=Reflect.ownKeys(value);
 need(keys.length<=64&&keys.every(key=>typeof key==='string'&&key.length<=128&&!['__proto__','prototype','constructor'].includes(key)),'observation keys');
 for(const key of keys){budget.left-=key.length*3+4;const d=Object.getOwnPropertyDescriptor(value,key);need(d&&'value'in d&&d.enumerable,'observation accessor');out[key]=data(d.value,depth+1,budget);}return Object.freeze(out);
}
function prepared(value,next){
 const p=fields(value,['width','height','pixels','palette','nextFrame','originUpdate','domain','renderOrdinal','phase','round']);
 need(p.width===320&&p.height===240&&p.nextFrame===next&&integer(p.originUpdate,0,next-1)&&p.domain==='segment'&&
  integer(p.renderOrdinal,0,0xffffffff)&&integer(p.round,0,0xffffffff)&&['intro','round-transition','round-ko','combat','finish'].includes(p.phase),'prepared image descriptor');
 return Object.freeze({...p,pixels:bytes(p.pixels,76800,76800),palette:bytes(p.palette,1024,1024)});
}
function status(value){
 const s=fields(value,['state','nextFrame','frames']);need(integer(s.frames,1,L.frames)&&integer(s.nextFrame,0,s.frames)&&
  ['paused','playing','ended','disposed','failed'].includes(s.state),'status');need(s.state!=='ended'||s.nextFrame===s.frames,'terminal boundary');return Object.freeze(s);
}
export function inspectPageReplay(input){
 // Inspect owns the complete byte view. Reject shared/resizable sources first.
 need(ArrayBuffer.isView(input)&&tag.call(input)==='Uint8Array','local .rep bytes required');const buffer=backing.call(input);
 need(Object.getPrototypeOf(buffer)===ArrayBuffer.prototype&&!resizable?.call(buffer),'fixed replay bytes required');
 const meta=inspectExtendedReplay(input),i=meta.initialization;
 need(meta.frames<=L.frames,'recording capacity');
 need(i.characters[0]===17&&i.characters[1]===16&&i.stage===17&&i.palettes[0]===0&&i.palettes[1]===0&&i.winRounds===2,
  'this resource pack supports only characters17/16, stage17, palettes0/0 and two-win battles');
 for(let frame=0;frame<meta.frames;frame++)validatePair(meta.pair(frame));return meta;
}
function selectedCatalog(manifest,root,key,fetcher,location){
 const full=validateEncryptedAssetManifest(manifest);
 // Music has its own browser owner. Even its existence metadata stays outside
 // the battle catalog, preserving the previously qualified gameplay closure.
 const owned={...full,files:full.files.filter(file=>!file.path.startsWith('wave/bgm/'))},paths=new Set(owned.files.map(file=>file.path));
 need(required.every(path=>paths.has(path)),'required battle resources missing');
 for(const path of paths){
  const selected=/\.(dat|pat|pal|wav)$/.test(path)&&['nayukib/','akiko/','system/bg/bg17/'].some(prefix=>path.startsWith(prefix));
  const sound=path.startsWith('wave/se/')&&path.endsWith('.wav');
  need(required.includes(path)||selected||sound,'unsupported resource pack');
 }
 need(typeof root==='string'&&root.length<=4096,'asset root');
 const url=new URL(root);need(['https:','http:'].includes(url.protocol)&&!url.username&&!url.password&&!url.search&&!url.hash&&url.pathname.endsWith('/'),'asset root');
 if(location&&['https:','http:'].includes(new URL(location).protocol))need(url.href===new URL('../deployment/assets/',location).href,'project asset root');
 return new EncryptedAssetCatalog(owned,url.href,{key,fetcher});
}

/** One fresh realm per local recording. These controls never change the core's
 * update/render cadence or construct a post-intro state. The scheduler admits
 * one complete update, then waits for its prepared-image acknowledgment. */
export function installReplayWorker(scope,{createSpectator,fetcher=globalThis.fetch,clock=()=>performance.now(),schedule=setTimeout,cancel=clearTimeout}={}){
 need(scope&&typeof scope.postMessage==='function'&&typeof createSpectator==='function','worker dependencies');
 let generation=0,lastId=0,meta=null,assets=null,engine=null,initializing=null,active=null,closing=null;
 let ready=false,playing=false,ended=false,disposed=false,failed=false,next=0,timer=null,due=0,playId=0,delivery=0,inFlight=0,commands=0;
 const current=()=>Object.freeze({state:failed?'failed':disposed?'disposed':ended?'ended':playing?'playing':'paused',nextFrame:next,frames:meta?.frames??0});
 const clear=()=>{if(timer!==null)cancel(timer);timer=null;};
 const reply=(id,operation)=>scope.postMessage({type:'result',generation,id,operation,status:current(),...(operation==='init'?{initialization:meta.initialization}:{})});
 const error=(id,cause,fatal=false)=>scope.postMessage({type:'error',generation,id,message:String(cause?.message??'replay failed').slice(0,500),fatal});
 function dispose(){
  if(closing)return closing;disposed=true;playing=false;clear();
  // Abort cold fetches immediately, but keep a live update's resources owned
  // until its complete boundary has returned. Its late image is suppressed.
  if(!ready)assets?.dispose();
  closing=(async()=>{await initializing?.catch(()=>{});await active?.catch(()=>{});const old=engine;engine=null;old?.dispose();assets?.dispose();})();return closing;
 }
 async function fatal(id,cause){failed=true;try{await dispose();}catch(cleanup){cause=Error(String(cause?.message??cause)+'; cleanup: '+String(cleanup.message));}error(id,cause,true);}
 function arm(){
  if(!ready||!playing||disposed||ended||failed||active||inFlight||timer!==null)return;
  const now=clock();need(Number.isFinite(now),'clock');if(now-due>L.frameMilliseconds*4)due=now;
  timer=schedule(()=>{timer=null;if(playing&&!inFlight&&!disposed&&!active)void update(playId,false);},Math.max(0,due-now));
 }
 async function advance(id){
  const result=await engine.advance(next,meta.pair(next));if(disposed)return;
  need(result&&['advanced','end'].includes(result.kind)&&result.nextFrame===next+1,'complete update boundary');next++;
  ended=result.kind==='end';need(ended===(next===meta.frames),'recording extent does not match natural engine cleanup');
  if(result.observation?.sceneId!==undefined)need(result.observation.sceneId===(ended?8:3),'unsupported battle scene');
  if(ended)playing=false;
  const image=prepared(engine.presentation(),next),owned=data(result);need(delivery<Number.MAX_SAFE_INTEGER,'presentation counter');
  inFlight=++delivery;scope.postMessage({type:'frame',generation,id,presentationId:inFlight,status:current(),result:owned,image},[image.pixels.buffer,image.palette.buffer]);
  due+=L.frameMilliseconds;
 }
 async function update(id,command){
  const work=advance(id);active=work;
  try{await work;if(!disposed&&command)reply(id,'step');}catch(cause){await fatal(id,cause);}
  finally{if(active===work)active=null;if(!disposed)arm();}
 }
 async function initialize(message){
  meta=inspectPageReplay(message.replayBytes);
  assets=selectedCatalog(message.encryptedManifest,message.assetRoot,message.key,fetcher,scope.location?.href);
  await assets.loadForSimulation();if(disposed)return;
  const candidate=await createSpectator(meta.initialization,assets);
  if(disposed){candidate.dispose();return;}engine=candidate;ready=true;
 }
 scope.onmessage=({data:raw})=>{
  let message;
  try{
   need(raw&&[Object.prototype,null].includes(Object.getPrototypeOf(raw)),'message');
   const descriptors=Object.getOwnPropertyDescriptors(raw);need(['type','generation'].every(key=>descriptors[key]&&'value'in descriptors[key]),'message header');
   const type=descriptors.type.value,g=descriptors.generation.value;
   if(type==='ack'){
    message=fields(raw,['type','generation','presentationId']);
    if(g===generation&&inFlight&&message.presentationId===inFlight){inFlight=0;arm();}return;
   }
   need(descriptors.id&&'value'in descriptors.id,'request identity');const id=descriptors.id.value;
   if(!integer(id,1,Number.MAX_SAFE_INTEGER)||!integer(g,1,Number.MAX_SAFE_INTEGER)||id<=lastId||generation&&g!==generation)return;
   message=fields(raw,type==='init'?['type','id','generation','replayBytes','encryptedManifest','assetRoot','key']:['type','id','generation']);
   lastId=id;
   if(type==='init'){
    if(generation){error(id,Error('Replace the Worker to open another replay'));return;}generation=g;
    initializing=initialize(message);void initializing.then(()=>{if(!disposed)reply(id,'init');},cause=>{if(!disposed)void fatal(id,cause);});return;
   }
   if(!generation)return;
   if(type==='dispose'){void dispose().then(()=>reply(id,'dispose'),cause=>error(id,cause,true));return;}
   need(commands<L.pendingCommands,'control capacity');need(ready&&!disposed&&!failed,'worker not ready');
   need(['play','pause','step'].includes(type),'unsupported control');
   if(type==='play'){need(!ended,'recording ended');playing=true;playId=id;due=clock();reply(id,type);arm();return;}
   if(type==='pause'){
    playing=false;clear();commands++;void Promise.resolve(active).then(()=>{if(!disposed)reply(id,type);},cause=>error(id,cause,true)).finally(()=>commands--);return;
   }
   need(!ended,'recording ended');need(!playing&&!active&&!inFlight,'step requires a paused acknowledged boundary');void update(id,true);
  }catch(cause){const id=message?.id??Object.getOwnPropertyDescriptor(raw??{},'id')?.value;if(generation&&integer(id,1,Number.MAX_SAFE_INTEGER))error(id,cause,false);}
 };
 return Object.freeze({dispose,status:current});
}

/** Main-thread owner. A replaced/closed worker cannot deliver or acknowledge a
 * later image. Frames are owned and painted before returning the single credit. */
export function createReplayClient(worker,{generation,onFrame=()=>{},onStatus=()=>{},onError=()=>{}}={}){
 need(integer(generation,1,Number.MAX_SAFE_INTEGER)&&worker&&typeof worker.postMessage==='function','client identity');
 let nextId=0,closed=false,initialised=false,lastImage=0,lastDelivery=0,delivering=false,closePromise=null;
 const pending=new Map();
 function fail(cause){if(closed)return;try{onError(cause);}finally{void dispose(cause);}}
 function dispose(cause=Error('Replay client disposed')){
  if(closePromise)return closePromise;closed=true;
  worker.removeEventListener('message',receive);worker.removeEventListener('error',broken);
  for(const p of pending.values()){clearTimeout(p.timer);p.reject(cause);}pending.clear();
  try{closePromise=Promise.resolve(worker.terminate());}catch(error){closePromise=Promise.reject(error);}return closePromise;
 }
 function request(type,payload={}){
  try{
   need(!closed,'client disposed');need(pending.size<L.pendingCommands,'pending control capacity');need(nextId<Number.MAX_SAFE_INTEGER,'request counter');
   let owned=payload,transfer=[];
   if(type==='init'){
    need(!initialised,'replace the Worker for another replay');const p=fields(payload,['replayBytes','encryptedManifest','assetRoot','key']);
    inspectPageReplay(p.replayBytes);owned={replayBytes:bytes(p.replayBytes,L.replayBytes),encryptedManifest:validateEncryptedAssetManifest(p.encryptedManifest),assetRoot:p.assetRoot,
     key:typeof p.key==='string'?p.key:bytes(p.key,32,32)};need(typeof p.assetRoot==='string'&&p.assetRoot.length<=4096,'asset root');
    transfer=[owned.replayBytes.buffer,...owned.key instanceof Uint8Array?[owned.key.buffer]:[]];initialised=true;
   }else need(initialised,'client not initialized');
   const id=++nextId;let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});
   const timer=setTimeout(()=>fail(Error('Replay worker request timed out')),type==='init'?60000:5000);
   pending.set(id,{type,resolve,reject,timer});try{worker.postMessage({type,generation,id,...owned},transfer);}catch(error){clearTimeout(timer);pending.delete(id);reject(error);fail(error);}return promise;
  }catch(error){return Promise.reject(error);}
 }
 async function receive({data:raw}){
  if(closed||raw?.generation!==generation)return;
  try{
   if(raw.type==='frame'){
    need(!delivering,'duplicate presentation while painting');delivering=true;
    const m=fields(raw,['type','generation','id','presentationId','status','result','image']);
    need(integer(m.id,1,nextId)&&m.presentationId===lastDelivery+1,'presentation identity');
    const s=status(m.status);need(s.nextFrame===lastImage+1,'presentation boundary');
    const frame=Object.freeze({...m,status:s,result:data(m.result),image:prepared(m.image,s.nextFrame)});
    lastDelivery=m.presentationId;lastImage=s.nextFrame;onStatus(s);await onFrame(frame);
    if(!closed)worker.postMessage({type:'ack',generation,presentationId:m.presentationId});return;
   }
   const p=pending.get(raw.id);if(raw.type==='error'){
    const m=fields(raw,['type','generation','id','message','fatal']);need(typeof m.message==='string'&&m.message.length<=500&&typeof m.fatal==='boolean','worker error');
    const error=Error(m.message);if(p){clearTimeout(p.timer);pending.delete(m.id);p.reject(error);}if(m.fatal)fail(error);return;
   }
   need(raw.type==='result'&&p,'unexpected worker result');
   const m=fields(raw,p.type==='init'?['type','generation','id','operation','status','initialization']:['type','generation','id','operation','status']);
   need(m.operation===p.type,'response operation');const s=status(m.status);onStatus(s);clearTimeout(p.timer);pending.delete(m.id);p.resolve(s);
  }catch(error){fail(error);}finally{if(raw.type==='frame')delivering=false;}
 }
 const broken=()=>fail(Error('Replay worker failed to start or stopped unexpectedly'));
 worker.addEventListener('message',receive);worker.addEventListener('error',broken);
 return Object.freeze({init:value=>request('init',value),play:()=>request('play'),pause:()=>request('pause'),step:()=>request('step'),dispose:()=>dispose()});
}
