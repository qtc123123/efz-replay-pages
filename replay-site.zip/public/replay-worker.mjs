import {createSpectator} from '../generated/efz-engine.mjs';
import {installReplayWorker} from '../src/pages/replay-session.mjs';

installReplayWorker(self,{createSpectator});
