import {createReplayClient,inspectPageReplay} from '../src/pages/replay-session.mjs';
import {createReplayMusic} from '../src/pages/replay-music.mjs';
import {resourceKey} from '../deployment/resource-access.mjs';

const $=id=>document.getElementById(id),context=$('screen').getContext('2d',{alpha:false}),rgba=context.createImageData(320,240);
let generation=0,client=null,music=null,loading=false,current=null,abort=null,disposed=false,musicBlocked=false;
const configURL=new URL('../deployment/config.json',import.meta.url);
function controls(){const usable=client&&!loading&&current&&!['ended','failed','disposed'].includes(current.state);
 $('open-replay').disabled=loading;$('replay-file').disabled=loading;
 $('play').disabled=!usable||current.state==='playing';$('pause').disabled=!usable||current.state!=='playing';$('step').disabled=!usable||current.state!=='paused';}
function message(text,error=false){$('status').textContent=text;$('status').classList.toggle('error',error);}
function musicMessage(text,error=false){$('music-status').textContent=text;$('music-status').classList.toggle('error',error);}
function musicError(error){musicMessage('Music unavailable: '+String(error?.message??error).slice(0,300)+'. Replay continues.',true);}
function musicAction(action){try{return music?.[action]();}catch(error){musicError(error);}}
function paint(frame){const image=frame.image;for(let n=0;n<76800;n++){const out=n*4,color=image.pixels[n]*4;
 rgba.data[out]=image.palette[color];rgba.data[out+1]=image.palette[color+1];rgba.data[out+2]=image.palette[color+2];rgba.data[out+3]=255;}
 context.putImageData(rgba,0,0);$('placeholder').hidden=true;}
async function json(url,max,signal,expected=null){
 const response=await fetch(url,{signal,credentials:'omit',redirect:'error'});if(!response.ok||!response.body)throw Error('Deployment files are unavailable.');
 const reader=response.body.getReader(),parts=[];let size=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max)throw Error('Deployment file exceeds its limit.');parts.push(value);}}
 catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}
 if(expected){const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(size!==expected.bytes||hash!==expected.sha256)throw Error('Deployment manifest integrity check failed.');}
 return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
function configuration(value){
 const keys=['schema','manifestUrl','manifestSha256','manifestBytes','generatedEngineHash','qualification','audio','music','supported'];
 const exact=(object,expected)=>object&&typeof object==='object'&&!Array.isArray(object)&&Object.keys(object).sort().join(',')===expected.sort().join(',');
 if(!value||Object.keys(value).sort().join(',')!==keys.sort().join(',')||value.schema!=='miracle-replay-pages/1'||value.manifestUrl!=='./assets/manifest.json'||
  !/^[a-f0-9]{64}$/.test(value.manifestSha256)||!/^[a-f0-9]{64}$/.test(value.generatedEngineHash)||
  !Number.isInteger(value.manifestBytes)||value.manifestBytes<1||value.manifestBytes>4*1024*1024||value.qualification!=='experimental'||
  !exact(value.audio,['music','effects'])||value.audio.music!==true||value.audio.effects!==false||
  !exact(value.music,['stage','path','mime'])||value.music.stage!==17||value.music.path!=='wave/bgm/bgm27.wav'||value.music.mime!=='audio/wav'||
  !exact(value.supported,['characters','stage','winRounds'])||JSON.stringify(value.supported.characters)!=='[17,16]'||value.supported.stage!==17||value.supported.winRounds!==2)
  throw Error('Unsupported deployment configuration.');return value;
}
function update(status,own){if(own!==generation||disposed)return;current=status;$('frame').textContent='Update '+status.nextFrame.toLocaleString()+' / '+status.frames.toLocaleString();
 $('progress').max=status.frames;$('progress').value=status.nextFrame;
 if(status.state==='ended'){message('Replay complete.');musicAction('stop');musicMessage('Music stopped · effects silent');}
 else if(status.state==='playing')message('Playing local replay.');else if(status.state==='paused')message('Paused. Play continues; Step advances one complete update.');controls();}
async function retire(){const previous=client,previousMusic=music;client=null;music=null;abort?.abort();abort=null;
 const audio=Promise.resolve().then(()=>previousMusic?.dispose()).catch(error=>{musicBlocked=true;musicError(error);});
 await Promise.all([previous?.dispose(),audio]);}
async function open(event){
 event.preventDefault();if(disposed)return;const file=$('replay-file').files?.[0];
 const own=++generation;loading=true;current=null;controls();message('Checking the local replay…');
 $('placeholder').hidden=false;$('placeholder').querySelector('p').textContent='Opening your replay…';
 try{
  await retire();if(own!==generation||disposed)return;
  if(!file||!file.name.toLowerCase().endsWith('.rep')||file.size>64*1024*1024)throw Error('Choose a .rep file up to 64 MiB.');
  const bytes=new Uint8Array(await file.arrayBuffer());inspectPageReplay(bytes);if(own!==generation||disposed)return;
  abort=new AbortController();const signal=abort.signal,timer=setTimeout(()=>abort?.abort(),60000);
  let config,manifest;
  try{config=configuration(await json(configURL,65536,signal));manifest=await json(new URL(config.manifestUrl,configURL),4*1024*1024,signal,{sha256:config.manifestSha256,bytes:config.manifestBytes});}
  finally{clearTimeout(timer);}
  if(own!==generation||disposed)return;const assetRoot=new URL('./',new URL(config.manifestUrl,configURL)).href;
  const key=resourceKey(config.manifestSha256);
  try{
   const worker=new Worker(new URL('./replay-worker.mjs',import.meta.url),{type:'module'});
   const candidate=createReplayClient(worker,{generation:own,onFrame:frame=>{if(own===generation&&!disposed)paint(frame);},onStatus:s=>update(s,own),
    onError:error=>{if(own===generation&&!disposed){loading=false;message(error.message,true);current={state:'failed'};musicAction('stop');controls();}}});
   client=candidate;message('Loading battle resources…');
   if(!musicBlocked)try{music=createReplayMusic({manifest,assetRoot,key,path:config.music.path});music.setVolume(Number($('volume').value));}catch(error){musicError(error);}
   const ready=candidate.init({replayBytes:bytes,encryptedManifest:manifest,assetRoot,key});key.fill(0);await ready;
  }finally{key.fill(0);}
  if(own!==generation||disposed)return;loading=false;$('placeholder').querySelector('p').textContent='Replay ready. Press Play.';
  message('Ready. Press Play to enter the battle.');if(music)musicMessage('Selected-stage music loads when you press Play · effects silent');controls();
 }catch(error){if(own!==generation||disposed)return;loading=false;message(error.name==='AbortError'?'Loading was cancelled or timed out.':error.message,true);
  $('placeholder').querySelector('p').textContent='Replay could not be opened.';await retire().catch(()=>{});controls();}
}
$('open-form').addEventListener('submit',open);
$('replay-file').addEventListener('change',()=>{$('file-name').textContent=$('replay-file').files?.[0]?.name??'No replay selected';});
$('play').addEventListener('click',()=>{const own=generation;if(!client)return;
 void client.play().catch(error=>{if(own===generation)message(error.message,true);});
 if(music)try{musicMessage('Loading selected-stage music…');void Promise.resolve(music.play()).then(()=>{if(own===generation&&current?.state==='playing')musicMessage('Stage music enabled · effects silent');},error=>{if(own===generation)musicError(error);});}catch(error){musicError(error);}});
$('pause').addEventListener('click',()=>{const own=generation;void client?.pause().catch(error=>{if(own===generation)message(error.message,true);});musicAction('pause');});
$('step').addEventListener('click',()=>{const own=generation;void client?.step().catch(error=>{if(own===generation)message(error.message,true);});musicAction('pause');});
$('volume').addEventListener('input',()=>{try{music?.setVolume(Number($('volume').value));}catch(error){musicError(error);}});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&client){void client.pause().catch(()=>{});musicAction('pause');}});
window.addEventListener('pagehide',()=>{disposed=true;generation++;void retire().catch(()=>{});});
controls();
