# Source notices and permission boundaries

The engine derives from **Mu-Tsun Tsai / MuTsunTsai/efz**. Copyright © 2026 Mu-Tsun Tsai; original rights and notices are retained. Read the [unchanged upstream license](public/upstream-license.txt). No new license is assigned to that code.

The user reported: “You can also upload the JS script since the owner gave us a permissions.” This private implementation relies on that user-reported permission; no written grant was supplied to expand its scope. Public rehosting, modification/distribution scope and game-media distribution must be reviewed before a public release. The existing repository [permission record](../docs/provenance/PERMISSIONS.md) remains authoritative evidence of what was reported, not a universal grant.

Build input: `MuTsunTsai/efz` commit `c49ffc31b4588705c65433fe2fd59d627388f7ff`, `static/js/index.fc2ffa1d78.js`, 1,654,731 bytes.

- SHA-256: `fcdbd920af0b746badf56ad3af62446d1007329ea4ad630453f3b4adde6980ff`
- Git blob: `40ec9c4533f93d7fcfb6947d33c38c51de92576d`

The raw source cache is unchanged. Reproducible build-time edits are recorded in `tools/patches.mjs`; the generated module retains the original legal strings and this attribution. Build outputs have separate hashes. The original source increment excluded executable, decompilation, private recording and game-media payloads. Synthetic test resources are deliberately not representative game media.

On 2026-10-26 the user additionally requested encrypted selected gameplay resources and selected-stage music in the private repository, followed by a Pages test build. The `deployment/assets/` pack contains ten authenticated ciphertext objects derived from those supplied resources, including only stage 17's `bgm27.wav`. Original resource rights are unchanged; encryption does not assign a new license. Plaintext resources, the separate decryption key, private recordings, native binaries and the full generated engine remain outside Git. The page loads the selected music independently of simulation; it does not include the complete music library.

The architectural reference is soku.cleista.cc. No code or assets from that service were copied. Miracle's pinned source informed integration boundaries; no native Miracle implementation is forked into this slice. Acorn 8.15.0 is a build dependency with its own MIT license retained in the installed package.
